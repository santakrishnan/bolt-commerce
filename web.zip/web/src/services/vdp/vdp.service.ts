import { cacheLife } from "next/cache";
import { ArrowServerError, createArrowServerClient } from "~/lib/arrow/server-api";
import type { VehicleData, VinData } from "./types";
import {
  MOCK_FEATURES_BY_ID,
  MOCK_HISTORY_DATA_BY_VIN,
  MOCK_PRICE_HISTORY_BY_VIN,
  MOCK_PRICING_BY_VIN,
  MOCK_RATING_BY_ID,
  MOCK_SPECS_BY_ID,
  MOCK_VEHICLE_STATUS_BY_ID,
  MOCK_VEHICLES_BY_VIN,
} from "./vdp.mocks";

let _client: ReturnType<typeof createArrowServerClient> | null = null;

function getVdpClient() {
  if (!_client) {
    _client = createArrowServerClient({
      baseUrl: process.env.VDP_SERVICE_URL ?? "",
      authToken: process.env.VDP_API_KEY,
      serviceName: "VDPService",
      timeout: 10_000,
      retries: 1,
    });
  }
  return _client;
}

function isMockMode(): boolean {
  return !process.env.VDP_SERVICE_URL || process.env.USE_MOCK_VDP === "true";
}

function getMockVinData(vin: string): VinData {
  const vehicle = MOCK_VEHICLES_BY_VIN[vin];
  if (!vehicle) {
    throw new Error(`Vehicle with VIN ${vin} not found`);
  }

  const { price, originalPrice, year, make, model } = vehicle;

  return {
    vehicle,
    pricing: MOCK_PRICING_BY_VIN[vin] ?? {
      currentPrice: price,
      avgPrice: originalPrice,
      daysOnSite: 0,
      views: 0,
      saves: 0,
    },
    priceHistory: MOCK_PRICE_HISTORY_BY_VIN[vin] ?? [],
    history: MOCK_HISTORY_DATA_BY_VIN[vin] ?? {
      vin,
      vehicleDescription: `${year} ${make} ${model}`,
      damageReported: 0,
      previousOwners: 0,
      servicesOnRecord: 0,
      repairsReported: 0,
      ownerTypes: [],
      lastOdometerReading: 0,
    },
  };
}

function getMockVehicleData(id: string): VehicleData {
  return {
    specs: MOCK_SPECS_BY_ID[id] ?? [],
    features: MOCK_FEATURES_BY_ID[id] ?? [],
    featuresInitialCount: 4,
    rating: MOCK_RATING_BY_ID[id] ?? {
      rating: 0,
      reviewCount: 0,
      distribution: [],
    },
    vehicleStatus: MOCK_VEHICLE_STATUS_BY_ID[id] ?? {
      noLongerAvailable: false,
      historyReportPending: false,
      inspectionInProgress: false,
      limitedPhotos: false,
    },
  };
}

export async function fetchVinData(vin: string): Promise<VinData> {
  "use cache";
  cacheLife({ stale: 300, revalidate: 300, expire: 3600 });

  if (isMockMode()) {
    return getMockVinData(vin);
  }

  try {
    return await getVdpClient().get<VinData>(`/vdp/vehicles/${vin}`);
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[VDPService] Upstream error (vin-data):", error.message);
    } else {
      console.error("[VDPService] Unexpected error (vin-data):", error);
    }
    return getMockVinData(vin);
  }
}

export async function fetchVehicleData(id: string): Promise<VehicleData> {
  "use cache";
  cacheLife({ stale: 300, revalidate: 300, expire: 3600 });

  if (isMockMode()) {
    return getMockVehicleData(id);
  }

  try {
    return await getVdpClient().get<VehicleData>(`/vdp/vehicle-details/${id}`);
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[VDPService] Upstream error (vehicle-data):", error.message);
    } else {
      console.error("[VDPService] Unexpected error (vehicle-data):", error);
    }
    return getMockVehicleData(id);
  }
}
