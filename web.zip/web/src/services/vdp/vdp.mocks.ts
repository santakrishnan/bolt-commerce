import { mockVehicles, type Vehicle as SearchVehicle } from "~/lib/search/mock-vehicles";
import type {
  FeatureCategory,
  HistoryData,
  PriceHistoryEntry,
  PricingData,
  RatingData,
  VehicleData,
  VehicleDetail,
  VehicleSpecData,
  VehicleStatusData,
} from "./types";

const PRIORITY_VIN = "5TDFZRBH5RS100015";
// const MAX_VDP_MOCKS = 3;
const MILES_SUFFIX_REGEX = /mi$/i;

function toTitleCase(value: string): string {
  return value
    .split("-")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function normalizeImage(image: string | string[]): string[] {
  return Array.isArray(image) ? image : [image];
}

function parseDealerInfo(milesField: string): { name: string; distance: string } {
  const [nameRaw, distanceRaw] = milesField.split(" - ");
  return {
    name: nameRaw ?? "Toyota Dealer",
    distance: distanceRaw ?? "0.0mi",
  };
}

function extractMiles(odometer: string): string {
  return odometer.replace(MILES_SUFFIX_REGEX, "");
}

function hashString(value: string): number {
  let hash = 0;
  for (let i = 0; i < value.length; i += 1) {
    hash = (hash * 31 + value.charCodeAt(i)) % 2_147_483_647;
  }
  return Math.abs(hash);
}

function pickByKey<T>(pool: T[], key: string): T {
  return pool[hashString(key) % pool.length] as T;
}

function resolveDrivetrain(vehicle: SearchVehicle): string {
  const model = vehicle.model.toLowerCase();
  if (model.includes("tacoma") || model.includes("tundra") || model.includes("4runner")) {
    return "4WD";
  }
  if (model.includes("rav4") || model.includes("highlander") || model.includes("venza")) {
    return "AWD";
  }
  return "FWD";
}

function resolveMpg(vehicle: SearchVehicle): string {
  const variant = vehicle.variant.toLowerCase();
  const model = vehicle.model.toLowerCase();
  if (variant.includes("hybrid") || model.includes("prius") || model.includes("venza")) {
    return "36-35";
  }
  if (model.includes("tundra")) {
    return "17-22";
  }
  if (model.includes("tacoma")) {
    return "18-24";
  }
  return "28-39";
}

function resolveHighlights(vehicle: SearchVehicle): string[] {
  const variant = vehicle.variant.toLowerCase();
  if (variant.includes("hybrid")) {
    return [
      "Hybrid Powertrain",
      "Toyota Safety Sense",
      "Apple CarPlay/Android Auto",
      "Adaptive Cruise Control",
      "Blind Spot Monitor",
      "Power Liftgate",
    ];
  }
  if (vehicle.model.includes("tacoma") || vehicle.model.includes("tundra")) {
    return [
      "Tow Package",
      "Multi-Terrain Select",
      "Apple CarPlay/Android Auto",
      "Blind Spot Monitor",
      "360 Camera",
      "LED Headlights",
    ];
  }
  return [
    "Toyota Safety Sense",
    "Apple CarPlay/Android Auto",
    "Lane Assist",
    "Rear Cross Traffic Alert",
    "Wireless Charging",
    "JBL Premium Audio",
  ];
}

const locationPool = [
  "Fort Worth, TX 76116",
  "Dallas, TX 75001",
  "Grapevine, TX 76051",
  "Irving, TX 75062",
];

const prioritizedVehicles = [...mockVehicles].sort((a, b) => {
  if (a.vin === PRIORITY_VIN) {
    return -1;
  }
  if (b.vin === PRIORITY_VIN) {
    return 1;
  }
  return 0;
});
// .slice(0, MAX_VDP_MOCKS);

export const MOCK_VEHICLES_BY_VIN: Record<string, VehicleDetail> = prioritizedVehicles.reduce(
  (acc, vehicle) => {
    const dealerInfo = parseDealerInfo(vehicle.miles);
    const id = String(vehicle.id);
    acc[vehicle.vin] = {
      id,
      title: vehicle.title,
      year: vehicle.year,
      make: toTitleCase(vehicle.make),
      model: toTitleCase(vehicle.model),
      trim: toTitleCase(vehicle.variant),
      price: vehicle.price,
      originalPrice: vehicle.oldPrice ?? vehicle.price,
      condition: vehicle.labels[0] ?? "Fair Price",
      warranty: true,
      inspected: true,
      miles: extractMiles(vehicle.odometer),
      drivetrain: resolveDrivetrain(vehicle),
      mpg: resolveMpg(vehicle),
      stock: `VDP${id.padStart(5, "0")}`,
      vin: vehicle.vin,
      exteriorColor: vehicle.extColorName,
      interiorColor: vehicle.intColorName,
      dealer: {
        name: dealerInfo.name,
        location: pickByKey(locationPool, vehicle.vin),
        distance: dealerInfo.distance,
      },
      images: normalizeImage(vehicle.image),
      highlights: resolveHighlights(vehicle),
    };
    return acc;
  },
  {} as Record<string, VehicleDetail>
);

export const MOCK_PRICING_BY_VIN: Record<string, PricingData> = prioritizedVehicles.reduce(
  (acc, vehicle) => {
    const spread = 1200 + (hashString(vehicle.vin) % 2600);
    acc[vehicle.vin] = {
      currentPrice: vehicle.price,
      avgPrice: vehicle.oldPrice ?? vehicle.price + spread,
      daysOnSite: 3 + (hashString(`${vehicle.vin}-days`) % 28),
      views: 200 + (hashString(`${vehicle.vin}-views`) % 900),
      saves: 10 + (hashString(`${vehicle.vin}-saves`) % 220),
    };
    return acc;
  },
  {} as Record<string, PricingData>
);

export const MOCK_PRICE_HISTORY_BY_VIN: Record<string, PriceHistoryEntry[]> =
  prioritizedVehicles.reduce(
    (acc, vehicle) => {
      const currentPrice = vehicle.price;
      const oldPrice = vehicle.oldPrice ?? currentPrice + 1800;
      const step1 = Math.round((oldPrice - currentPrice) * 0.55);
      const step2 = Math.round((oldPrice - currentPrice) * 0.8);
      acc[vehicle.vin] = [
        { date: "2026-03-01", price: currentPrice, change: 0 },
        { date: "2026-02-10", price: oldPrice - step1, change: -step1 },
        {
          date: "2026-01-15",
          price: oldPrice - Math.round(step2),
          change: -Math.round(step2 - step1),
        },
        {
          date: "2025-12-05",
          price: oldPrice,
          change: -Math.round(oldPrice - (oldPrice - step2)),
        },
      ];
      return acc;
    },
    {} as Record<string, PriceHistoryEntry[]>
  );

export const MOCK_HISTORY_DATA_BY_VIN: Record<string, HistoryData> = prioritizedVehicles.reduce(
  (acc, vehicle) => {
    const ownerTypes = Array.from({ length: Math.max(1, vehicle.owners) }, () => "Personal");
    acc[vehicle.vin] = {
      vin: vehicle.vin,
      vehicleDescription: `${vehicle.year} ${toTitleCase(vehicle.make)} ${toTitleCase(vehicle.model)}`,
      damageReported: hashString(`${vehicle.vin}-damage`) % 2,
      previousOwners: vehicle.owners,
      servicesOnRecord: 1 + (hashString(`${vehicle.vin}-service`) % 6),
      repairsReported: hashString(`${vehicle.vin}-repair`) % 2,
      ownerTypes,
      lastOdometerReading: Number.parseInt(extractMiles(vehicle.odometer).replace(/,/g, ""), 10),
    };
    return acc;
  },
  {} as Record<string, HistoryData>
);

const specTemplates: VehicleSpecData[][] = [
  [
    { key: "engine", label: "Engine", value: "2.5L I4" },
    { key: "fuel-type", label: "Fuel Type", value: "Gas" },
    { key: "transmission", label: "Transmission", value: "8-Speed Automatic" },
  ],
  [
    { key: "engine", label: "Engine", value: "2.5L I4 Hybrid" },
    { key: "fuel-type", label: "Fuel Type", value: "Hybrid" },
    { key: "transmission", label: "Transmission", value: "eCVT" },
  ],
  [
    { key: "engine", label: "Engine", value: "3.5L V6" },
    { key: "fuel-type", label: "Fuel Type", value: "Gas" },
    { key: "transmission", label: "Transmission", value: "10-Speed Automatic" },
  ],
];

const featureTemplates: FeatureCategory[][] = [
  [
    { name: "Safety", features: ["Blind Spot Monitor", "Lane Keep Assist", "Adaptive Cruise"] },
    { name: "Comfort", features: ["Heated Seats", "Dual-Zone Climate", "Power Liftgate"] },
  ],
  [
    { name: "Technology", features: ["Wireless CarPlay", "Digital Cluster", "JBL Audio"] },
    { name: "Convenience", features: ["Remote Start", "Wireless Charging", "Panoramic Roof"] },
  ],
  [
    { name: "Off-Road", features: ["4WD", "Drive Modes", "Hill Start Assist"] },
    { name: "Utility", features: ["Tow Package", "Bed Lighting", "Trailer Sway Control"] },
  ],
];

const ratingTemplates: RatingData[] = [
  {
    rating: 4.8,
    reviewCount: 128,
    distribution: [
      { id: "5", stars: 5, count: 98 },
      { id: "4", stars: 4, count: 22 },
      { id: "3", stars: 3, count: 6 },
      { id: "2", stars: 2, count: 1 },
      { id: "1", stars: 1, count: 1 },
    ],
  },
  {
    rating: 4.6,
    reviewCount: 94,
    distribution: [
      { id: "5", stars: 5, count: 66 },
      { id: "4", stars: 4, count: 20 },
      { id: "3", stars: 3, count: 6 },
      { id: "2", stars: 2, count: 1 },
      { id: "1", stars: 1, count: 1 },
    ],
  },
  {
    rating: 4.9,
    reviewCount: 176,
    distribution: [
      { id: "5", stars: 5, count: 144 },
      { id: "4", stars: 4, count: 24 },
      { id: "3", stars: 3, count: 6 },
      { id: "2", stars: 2, count: 1 },
      { id: "1", stars: 1, count: 1 },
    ],
  },
];

const statusTemplates: VehicleStatusData[] = [
  {
    noLongerAvailable: false,
    historyReportPending: false,
    inspectionInProgress: false,
    limitedPhotos: false,
  },
  {
    noLongerAvailable: false,
    historyReportPending: true,
    inspectionInProgress: false,
    limitedPhotos: true,
  },
  {
    noLongerAvailable: false,
    historyReportPending: false,
    inspectionInProgress: true,
    limitedPhotos: false,
  },
];

const vehicleDataById = prioritizedVehicles.reduce(
  (acc, vehicle) => {
    const id = String(vehicle.id);
    const specs = pickByKey(specTemplates, `${id}-specs`).map((item) => ({ ...item }));
    const features = pickByKey(featureTemplates, `${id}-features`).map((group) => ({
      name: group.name,
      features: [...group.features],
    }));
    const rating = pickByKey(ratingTemplates, `${id}-rating`);
    const status = pickByKey(statusTemplates, `${id}-status`);
    acc[id] = {
      specs,
      features,
      featuresInitialCount: 4,
      rating: {
        rating: rating.rating,
        reviewCount: rating.reviewCount,
        distribution: rating.distribution.map((d) => ({ ...d })),
      },
      vehicleStatus: { ...status },
    };
    return acc;
  },
  {} as Record<string, VehicleData>
);

export const MOCK_SPECS_BY_ID: Record<string, VehicleSpecData[]> = Object.fromEntries(
  Object.entries(vehicleDataById).map(([id, data]) => [id, data.specs])
);
export const MOCK_FEATURES_BY_ID: Record<string, FeatureCategory[]> = Object.fromEntries(
  Object.entries(vehicleDataById).map(([id, data]) => [id, data.features])
);
export const MOCK_RATING_BY_ID: Record<string, RatingData> = Object.fromEntries(
  Object.entries(vehicleDataById).map(([id, data]) => [id, data.rating])
);
export const MOCK_VEHICLE_STATUS_BY_ID: Record<string, VehicleStatusData> = Object.fromEntries(
  Object.entries(vehicleDataById).map(([id, data]) => [id, data.vehicleStatus])
);
