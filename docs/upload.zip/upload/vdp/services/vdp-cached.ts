/**
 * Cache-optimized VDP data functions for direct page-level use.
 *
 * These compose the VIN-only cached service functions into the shapes
 * the VDP page needs, bypassing the API proxy route. Cache keys contain
 * only the VIN — no per-request headers — so entries are shared across
 * all users viewing the same vehicle.
 */

import type { DealerNotes } from "@shared/data/dealer/dealer-data";
import { cacheLife, cacheTag } from "next/cache";
import { buildDealerNotes } from "./dealer-notes";
import { fetchVehicleDataCached, fetchVinDataCached } from "./vdp.service";
import type { VehicleBundle } from "./vdp-api";

/**
 * Cached per VIN — fetches vinData then vehicleData (sequential dependency:
 * vehicleData requires `vinData.vehicle.id`).
 */
export async function getVehicleBundleCached(vin: string): Promise<VehicleBundle> {
  "use cache";
  cacheLife("vdp");
  cacheTag("vdp", `bundle-${vin}`);

  const vinData = await fetchVinDataCached(vin);
  const vehicleData = await fetchVehicleDataCached(vinData.vehicle.id);
  return { vinData, vehicleData };
}

/** Cached per VIN — builds dealer notes from VIN data. */
export async function getDealerNotesCached(vin: string): Promise<DealerNotes> {
  "use cache";
  cacheLife("vdp");
  cacheTag("vdp", `dealer-${vin}`);

  const vinData = await fetchVinDataCached(vin);
  return buildDealerNotes(vinData);
}
