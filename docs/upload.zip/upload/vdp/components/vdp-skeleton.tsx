/* -------------------------------------------------------------------------- */
/*  VDP Suspense skeleton — lightweight placeholder that prevents CLS while  */
/*  vehicle data streams in. Matches the VDP two-column layout.              */
/* -------------------------------------------------------------------------- */

function SkeletonBlock({ className }: { className?: string }) {
  return <div className={`animate-pulse rounded-lg bg-foreground/5 ${className}`} />;
}

/** Full VDP skeleton: image carousel + right rail details + tabs + dealer */
export function VdpSkeleton() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <main className="flex-1">
        {/* Hero area: carousel + right rail */}
        <div className="mx-auto max-w-(--container-2xl) px-4 py-12 sm:px-6 lg:px-20">
          {/* Back link + breadcrumb */}
          <div className="mb-6 flex items-center justify-between">
            <SkeletonBlock className="h-5 w-40" />
            <SkeletonBlock className="h-5 w-24" />
          </div>

          <div className="flex flex-col lg:grid lg:grid-cols-[minmax(0,1fr)_392px] lg:items-start lg:gap-(--spacing-10)">
            {/* Left — Image carousel */}
            <div className="flex min-w-0 flex-col gap-(--spacing-md)">
              <SkeletonBlock className="aspect-[4/3] w-full lg:aspect-auto lg:h-[518px]" />
              {/* Thumbnail strip (desktop) */}
              <div className="hidden gap-(--spacing-md) lg:flex">
                <SkeletonBlock className="h-(--size-thumbnail) w-(--size-thumbnail)" />
                <SkeletonBlock className="h-(--size-thumbnail) w-(--size-thumbnail)" />
                <SkeletonBlock className="h-(--size-thumbnail) w-(--size-thumbnail)" />
                <SkeletonBlock className="h-(--size-thumbnail) w-(--size-thumbnail)" />
              </div>
            </div>

            {/* Right — Details rail */}
            <div className="mt-(--spacing-md) flex w-full flex-col gap-(--spacing-lg) lg:mt-0">
              {/* Title + price */}
              <div className="flex flex-col gap-(--spacing-sm)">
                <SkeletonBlock className="h-8 w-3/4" />
                <SkeletonBlock className="h-7 w-32" />
              </div>
              {/* Badges */}
              <div className="grid grid-cols-3 gap-(--spacing-xs)">
                <SkeletonBlock className="h-10" />
                <SkeletonBlock className="h-10" />
                <SkeletonBlock className="h-10" />
              </div>
              <SkeletonBlock className="h-px w-full" />
              {/* Specs grid */}
              <div className="grid grid-cols-3 gap-(--spacing-xs)">
                <SkeletonBlock className="h-14" />
                <SkeletonBlock className="h-14" />
                <SkeletonBlock className="h-14" />
              </div>
              <SkeletonBlock className="h-px w-full" />
              {/* Colors */}
              <div className="flex gap-(--spacing-xs)">
                <SkeletonBlock className="h-16 flex-1" />
                <SkeletonBlock className="h-16 flex-1" />
              </div>
              <SkeletonBlock className="h-px w-full" />
              {/* Promotion cards */}
              <SkeletonBlock className="h-12 w-full" />
              <SkeletonBlock className="h-12 w-full" />
              {/* Dealer info */}
              <div className="flex items-center gap-(--spacing-sm)">
                <SkeletonBlock className="h-10 w-10 rounded-full" />
                <div className="flex flex-1 flex-col gap-1">
                  <SkeletonBlock className="h-4 w-40" />
                  <SkeletonBlock className="h-3 w-28" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs section */}
        <div className="w-full bg-gray-100 pt-4 pb-10 lg:py-(--spacing-4xl)">
          <div className="mx-auto max-w-(--container-2xl) px-6 sm:px-6 lg:px-20">
            {/* Tab headers */}
            <div className="mb-6 flex gap-(--spacing-lg)">
              <SkeletonBlock className="h-10 w-24" />
              <SkeletonBlock className="h-10 w-24" />
              <SkeletonBlock className="h-10 w-24" />
              <SkeletonBlock className="h-10 w-24" />
            </div>
            {/* Tab content */}
            <SkeletonBlock className="h-64 w-full" />
            {/* Rating */}
            <div className="mt-6">
              <SkeletonBlock className="h-40 w-full" />
            </div>
            {/* Dealer notes */}
            <div className="mt-6">
              <SkeletonBlock className="h-32 w-full" />
            </div>
          </div>
        </div>

        {/* Dealer info card */}
        <div className="mx-auto max-w-(--container-2xl) px-6 sm:px-6 lg:px-(--spacing-4xl)">
          <SkeletonBlock className="my-8 h-48 w-full" />
        </div>
      </main>
    </div>
  );
}
