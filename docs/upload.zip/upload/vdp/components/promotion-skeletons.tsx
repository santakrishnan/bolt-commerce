/* Suspense fallbacks for server-rendered promotion card slots. */

function SkeletonBlock({ className }: { className?: string }) {
  return <div className={`animate-pulse rounded-lg bg-foreground/5 ${className}`} />;
}

/** Skeleton for the prequal + trade-in promotion area. */
export function PromotionCardsSkeleton() {
  return (
    <div className="flex flex-col gap-(--spacing-md)">
      <SkeletonBlock className="h-12 w-full" />
      <SkeletonBlock className="h-12 w-full" />
    </div>
  );
}

/** Skeleton for the test drive card area. */
export function TestDriveCardSkeleton() {
  return <SkeletonBlock className="h-12 w-full" />;
}
