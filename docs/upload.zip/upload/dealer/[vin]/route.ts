import { extractArrowIds, extractForwardHeaders } from "@features/tracking/lib/server-api";
import { buildDealerNotes } from "@features/vdp/services/dealer-notes";
import { fetchVinData } from "@features/vdp/services/vdp.service";
import { type NextRequest, NextResponse } from "next/server";

const isDev = process.env.NODE_ENV === "development";
function noop() {
  /* no-op */
}
const log = isDev ? console.log.bind(console, "[SearchDealerAPI]") : noop;

interface RouteContext {
  params: Promise<{ vin: string }>;
}

export async function GET(request: NextRequest, context: RouteContext) {
  try {
    const { vin } = await context.params;
    log("REQ", {
      method: request.method,
      path: request.nextUrl.pathname,
      vin,
      sessionId: request.headers.get("x-arrow-session-id"),
      fingerprintId: request.headers.get("x-arrow-fp-id"),
      profileId: request.headers.get("x-arrow-profile-id"),
    });

    if (!vin) {
      log("RES", { status: 400, code: "MISSING_VIN" });
      return NextResponse.json(
        { data: null, error: "VIN is required", code: "MISSING_VIN" },
        { status: 400 }
      );
    }

    const ids = extractArrowIds(request);
    const forwardHeaders = extractForwardHeaders(request);
    const vinData = await fetchVinData(vin, { ids, forwardHeaders });
    const dealerData = buildDealerNotes(vinData);
    log("RES", {
      status: 200,
      vin,
      dealerId: dealerData.dealer.id,
      dealerName: dealerData.dealer.name,
      vehicleImage: dealerData.vehicleImage,
    });

    return NextResponse.json({ data: dealerData });
  } catch (error) {
    console.error("[SearchDealerAPI] GET error:", error);
    return NextResponse.json(
      { data: null, error: "Failed to fetch dealer details", code: "INTERNAL_ERROR" },
      { status: 500 }
    );
  }
}
