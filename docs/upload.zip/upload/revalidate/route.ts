import { revalidateTag } from "next/cache";
import type { NextRequest } from "next/server";

/**
 * On-demand cache revalidation endpoint.
 *
 * Usage:
 *   POST /api/revalidate
 *   { "tag": "vin-1G1AF1F57A7192174", "secret": "..." }
 *
 * Tags:
 *   - "vdp"              → invalidates ALL VDP caches
 *   - "vin-<VIN>"         → invalidates one VIN's data
 *   - "bundle-<VIN>"      → invalidates one VIN's vehicle bundle
 *   - "dealer-<VIN>"      → invalidates one VIN's dealer notes
 */
export async function POST(request: NextRequest) {
  try {
    const { tag, secret } = await request.json();

    if (!secret || secret !== process.env.REVALIDATION_SECRET) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    if (!tag || typeof tag !== "string") {
      return Response.json({ error: "Missing or invalid tag" }, { status: 400 });
    }

    revalidateTag(tag, "max");
    return Response.json({ revalidated: true, tag, now: Date.now() });
  } catch {
    return Response.json({ error: "Invalid request body" }, { status: 400 });
  }
}
