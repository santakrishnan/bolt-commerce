import { SAVED_REGISTRY_STALE_TIME } from "@config/queries/constants";
import { getAllSavedVehicles } from "@features/favorites/services/saved-vehicles-api";
import { queryOptions, skipToken } from "@tanstack/react-query";

/**
 * Query key factory for saved vehicles.
 *
 * Centralises the query key and options so every consumer (FavoritesProvider,
 * header badge, favorites page, my-garage) reads from the same cache entry.
 *
 * `queryFn` calls the saved-registry proxy (`/api/saved-registry/vehicles`)
 * which forwards to the BED Saved Vehicle Service (currently mocked).
 */
export const savedVehicleQueries = {
  all: () =>
    queryOptions({
      queryKey: ["saved-vehicles"] as const,
      // skipToken prevents server-side execution during prerender (e.g. /_not-found)
      queryFn: typeof window === "undefined" ? skipToken : getAllSavedVehicles,
      // Show empty list while the first fetch runs — does NOT suppress the fetch
      // (unlike initialData which would treat [] as "fresh" for staleTime duration)
      placeholderData: [] as string[],
      staleTime: SAVED_REGISTRY_STALE_TIME,
    }),
} as const;
