import { cn } from "@tfs-ucmp/ui";

// ─── Config types ───────────────────────────────────────────────────────────

interface ResponsiveConfig {
  /** Desktop (lg: prefix, ≥ 1024 px) */
  desktop: string;
  /** 360 px+ — common Android small phones */
  m360?: string;
  /** 375 px+ — iPhone SE / 12 mini */
  m375?: string;
  /** 390 px+ — iPhone 14 / 15 Pro */
  m390?: string;
  /** 414 px+ — iPhone Plus / Max */
  m414?: string;
  /** 425 px+ */
  m425?: string;
  /** 480 px+ — wide phone / pre-tablet */
  m480?: string;
  /** Mobile-first (no responsive prefix) */
  mobile: string;
  // ── Tablet ladder
  /** 500–599 px */
  t500?: string;
  /** 600–699 px */
  t600?: string;
  /** 700–767 px */
  t700?: string;
  /** 900–1023 px — large tablet */
  t900?: string;
  /** Tablet (md: prefix, ≥ 768 px) */
  tablet: string;
}

interface RegionConfig {
  height: ResponsiveConfig;
  objectPosition: ResponsiveConfig;
  width: ResponsiveConfig;
}

// ─── Background image path ──────────────────────────────────────────────────

export const KNOWN_USER_DESKTOP_BG =
  "/images/hero-know-user-content/know-user-images/car-image-temporary.png";

// ─── Defaults ───────────────────────────────────────────────────────────────

const DEFAULT_WIDTH: ResponsiveConfig = {
  desktop: "lg:w-full",
  mobile: "w-full",
  tablet: "md:w-full",
};

const DEFAULT_REGION: RegionConfig = {
  height: { desktop: "lg:h-full", mobile: "h-[60vh]", tablet: "md:h-full" },
  objectPosition: {
    desktop: "lg:object-[72%_0%]",
    mobile: "object-[72%_0%]",
    tablet: "md:object-[72%_0%]",
    t500: "min-[500px]:object-[72%_0%]",
    t600: "min-[600px]:object-[72%_0%]",
    t700: "min-[700px]:object-[72%_0%]",
    t900: "min-[900px]:object-[72%_0%]",
  },
  width: DEFAULT_WIDTH,
};

const KNOWN_USER_OVERRIDES = {
  height: { desktop: "lg:h-full", mobile: "h-[45vh]", tablet: "md:h-[60vh]" },
  objectPosition: {
    desktop: "lg:object-[75%_0%]",
    mobile: "object-[84%_0%]",
    m360: "min-[360px]:object-[87%_0%]",
    m375: "min-[375px]:object-[95%_0%]",
    m390: "min-[390px]:object-[85%_0%]",
    m414: "min-[414px]:object-[84%_0%]",
    m425: "min-[425px]:object-[85%_0%]",
    m480: "min-[480px]:object-[82%_0%]",
    t500: "min-[500px]:object-[100%_0%]",
    t600: "min-[600px]:object-[85%_0%]",
    t700: "min-[700px]:object-[83%_0%]",
    tablet: "md:object-[90%_0%]",
    t900: "min-[900px]:object-[90%_0%]",
  },
} as const;

// ─── Per-region configs ─────────────────────────────────────────────────────

const REGION_CONFIGS: Record<string, RegionConfig> = {
  southeast: {
    height: { desktop: "lg:h-full", mobile: "h-[65vh]", tablet: "md:h-full" },
    objectPosition: {
      desktop: "lg:object-[52%_50%]",
      mobile: "object-[52%_0%]",
      t500: "min-[500px]:object-[52%_0%]",
      t600: "min-[600px]:object-[51%_0%]",
      t700: "min-[700px]:object-[51%_0%]",
      tablet: "md:object-[54%_0%]",
      t900: "min-[900px]:object-[55%_10%]",
    },
    width: DEFAULT_WIDTH,
  },
  southwest: {
    height: { desktop: "lg:h-full", mobile: "h-[56vh]", tablet: "md:h-full" },
    objectPosition: {
      desktop: "lg:object-[72%_52%]",
      mobile: "object-[72%_0%]",
      m360: "min-[360px]:object-[74%_0%]",
      m375: "min-[375px]:object-[76%_0%]",
      m390: "min-[390px]:object-[72%_0%]",
      m414: "min-[414px]:object-[72%_0%]",
      m425: "min-[425px]:object-[72%_0%]",
      m480: "min-[480px]:object-[85%_0%]",
      // Tablet steps
      t500: "min-[500px]:object-[99%_0%]",
      t600: "min-[600px]:object-[70%_0%]",
      t700: "min-[700px]:object-[75%_0%]",
      tablet: "min-[800px]:object-[72%_0%]",
      t900: "min-[900px]:object-[72%_10%]",
    },
    width: DEFAULT_WIDTH,
  },
  west: {
    height: { desktop: "lg:h-full", mobile: "h-[65vh]", tablet: "md:h-full" },
    objectPosition: {
      desktop: "lg:object-[50%_42%]",
      mobile: "object-[50%_0%]",
      t500: "min-[500px]:object-[50%_8%]",
      t600: "min-[600px]:object-[50%_16%]",
      t700: "min-[700px]:object-[50%_24%]",
      tablet: "md:object-[50%_32%]",
      t900: "min-[900px]:object-[50%_36%]",
    },
    width: DEFAULT_WIDTH,
  },
};

// ─── Resolver helpers ───────────────────────────────────────────────────────

function resolveResponsive(config: ResponsiveConfig): string {
  return cn(
    config.mobile,
    config.m360,
    config.m375,
    config.m390,
    config.m414,
    config.m425,
    config.m480,
    config.t500,
    config.t600,
    config.t700,
    config.t900,
    config.tablet,
    config.desktop
  );
}

export function resolveContainerWidthClass(backgroundImageKey: string): string {
  const region = REGION_CONFIGS[backgroundImageKey] ?? DEFAULT_REGION;
  return resolveResponsive(region.width);
}

export function resolveContainerHeightClass(
  effectiveKnownUser: boolean,
  backgroundImageKey: string,
  bannerHeightClass?: string
): string {
  if (bannerHeightClass) {
    return "h-full md:h-full lg:h-full";
  }
  if (effectiveKnownUser) {
    return resolveResponsive(KNOWN_USER_OVERRIDES.height);
  }
  const region = REGION_CONFIGS[backgroundImageKey] ?? DEFAULT_REGION;
  return resolveResponsive(region.height);
}

export function resolveObjectPositionClass(
  effectiveKnownUser: boolean,
  backgroundImageKey: string
): string {
  if (effectiveKnownUser) {
    return resolveResponsive(KNOWN_USER_OVERRIDES.objectPosition);
  }
  const region = REGION_CONFIGS[backgroundImageKey] ?? DEFAULT_REGION;
  return resolveResponsive(region.objectPosition);
}
