"use client";

import { useLocation } from "@shared/providers/location-provider";
import { cn } from "@tfs-ucmp/ui";
import Image from "next/image";
import type React from "react";
import {
  KNOWN_USER_DESKTOP_BG,
  resolveContainerHeightClass,
  resolveContainerWidthClass,
  resolveObjectPositionClass,
} from "./home-hero-static.config";
import type { HomeHeroStaticProps } from "./types";

export function HomeHeroStatic({
  isKnownUser = false,
  useLocationBackground = false,
  bannerHeightClass,
}: HomeHeroStaticProps): React.JSX.Element {
  const { state: locationState } = useLocation();
  const { backgroundImage, backgroundImageKey } = locationState;

  const effectiveKnownUser = isKnownUser && !useLocationBackground;

  const activeBg = effectiveKnownUser ? KNOWN_USER_DESKTOP_BG : backgroundImage;
  const imageObjectClass = resolveObjectPositionClass(effectiveKnownUser, backgroundImageKey);

  // If a bannerHeightClass was provided by the page (e.g. My Garage),
  // the outer `HomeHero` section should receive that explicit height and
  // this inner background container should fill it using `h-full`.
  const containerHeightClass = resolveContainerHeightClass(
    effectiveKnownUser,
    backgroundImageKey,
    bannerHeightClass
  );

  const containerWidthClass = resolveContainerWidthClass(backgroundImageKey);

  return (
    <section aria-label="Hero background" className="absolute inset-0 bg-black">
      <div
        className={cn(
          "absolute",
          containerWidthClass,
          bannerHeightClass ? "inset-x-0 top-0" : "inset-0",
          containerHeightClass,
          "hero-mobile-vignette relative"
        )}
      >
        <div className="hero-gradient-overlay pointer-events-none absolute inset-0 z-10" />
        <Image
          alt="Hero background"
          className={cn("object-cover", imageObjectClass)}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 100vw, (max-width: 1200px) 90vw, 1200px"
          src={activeBg}
        />
      </div>
    </section>
  );
}
