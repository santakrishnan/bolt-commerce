"use client";

import { ROUTES } from "@config/routes/constants";
import { AppButton } from "@shared/components/button";
import { Heading } from "@tfs-ucmp/ui";
import { useRouter } from "next/navigation";
import type React from "react";
import { DontMissOutCard, GreatStartCard, ReadyWhenYouAreCard } from "./known-user-cards";
import type { HomeHeroKnownUserContentProps } from "./types";

export function HomeHeroKnownUserContent({
  userName,
  isPreQualified = false,
  savedVehicle,
  preQualifiedVehicle,
  tradeInOffer,
  onBuyOnline,
  onScheduleTestDrive,
  onAcceptOffer,
  onContinueShopping,
  showCards = false,
  showSubtitle = true,
  showContinueShopping = false,
}: HomeHeroKnownUserContentProps) {
  const router = useRouter();

  const cards: React.ReactNode[] = [];

  if (showCards && savedVehicle) {
    cards.push(
      <GreatStartCard
        isPreQualified={isPreQualified}
        key="saved-vehicle"
        onBuyOnline={onBuyOnline}
        savedVehicle={savedVehicle}
      />
    );
  }

  if (showCards && preQualifiedVehicle) {
    cards.push(
      <ReadyWhenYouAreCard
        key="test-drive"
        onScheduleTestDrive={onScheduleTestDrive}
        preQualifiedVehicle={preQualifiedVehicle}
      />
    );
  }

  if (showCards && tradeInOffer) {
    cards.push(
      <DontMissOutCard key="trade-in" onAcceptOffer={onAcceptOffer} tradeInOffer={tradeInOffer} />
    );
  }

  return (
    <div className="flex w-full justify-center pt-[25vh] pb-0 md:pt-0 lg:pb-0">
      <div className="flex w-full max-w-[1440px] flex-col items-start">
        <div className="space-y-1 text-center md:space-y-2 md:text-left">
          <Heading
            className="w-full max-w-[715px] text-[length:var(--font-size-2xl)] text-white uppercase leading-[1.2] tracking-[-0.449px] md:leading-[44px] lg:text-[length:var(--font-size-2xl)] xl:text-[length:var(--font-size-4xl)]"
            level={1}
            weight="bold"
          >
            WELCOME BACK{userName ? `, ${userName.toUpperCase()}` : ""}!
          </Heading>
          {showSubtitle && (
            <p className="m w-full max-w-[400px] font-semibold text-[length:var(--font-size-sm)] text-white leading-[1.5] md:text-[length:var(--font-size-sm)] md:leading-[24px] lg:text-base">
              You're pre-qualified and off to a great start.
              <span className="inline sm:hidden"> </span>
              Your trade-in offer and saved vehicles are ready.
              <span className="inline sm:hidden"> </span>— Let's Schedule a test drive.
            </p>
          )}
        </div>

        {cards.length > 0 && (
          <>
            <div className="mt-[var(--spacing-lg)] flex w-full flex-col gap-[var(--spacing-xl)] md:hidden">
              {cards}
            </div>
            <div className="mt-[var(--spacing-lg)] hidden w-full gap-[var(--spacing-xs)] md:flex md:items-stretch">
              {cards}
            </div>
          </>
        )}

        {showContinueShopping && (
          <div className="flex w-full justify-center pt-[var(--spacing-lg)]">
            <div className="w-full md:w-1/3">
              <AppButton
                className="w-full bg-[var(--color-core-surfaces-card)]"
                onClick={() => {
                  onContinueShopping?.();
                  router.push(ROUTES.USED_CARS);
                }}
                size="md"
                variant="tertiary"
              >
                Continue Shopping
              </AppButton>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
