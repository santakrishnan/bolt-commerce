export interface ProcessStep {
  description: string;
  icon: "clipboard" | "refresh" | "search" | "shield";
  linkHref?: string;
  linkText?: string;
  title: string;
}

export interface BuyingProcessCardProps {
  steps: ProcessStep[];
}

export interface BuyingProcessCarouselProps {
  steps: ProcessStep[];
}
