/** Maps inspection feature icon keys to local SVG asset paths. */
export const INSPECTION_ICON_MAP: Record<string, string> = {
  "arrow-circle": "/images/arrow-inspected/icon-inspection.svg",
  "certified-document": "/images/arrow-inspected/icon-vin-check.svg",
  guarantee: "/images/arrow-inspected/icon-return.svg",
  "verified-badge": "/images/arrow-inspected/icon-no-damage.svg",
};
