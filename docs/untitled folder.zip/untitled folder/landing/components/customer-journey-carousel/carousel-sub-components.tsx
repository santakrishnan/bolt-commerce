import { AppButton } from "@shared/components/button";
import { useIsFullyVisible } from "@shared/hooks/use-is-fully-visible";
import { cn, Heading } from "@tfs-ucmp/ui";
import { motion } from "framer-motion";
import Image from "next/image";
import type {
  ImageContainerProps,
  NavigationDotsProps,
  SingleSlideCarouselProps,
  SlideContentProps,
  TextContainerProps,
  TextContentProps,
} from "./types";

// ─── SlideContent ───────────────────────────────────────────────────────────

export function SlideContent({ slide }: SlideContentProps) {
  return (
    <div className="h-full w-full">
      <div className="flex h-full w-full flex-col sm:hidden">
        <div className="relative h-[200px] w-full shrink-0">
          <Image
            alt={slide.title}
            className="object-cover"
            fill
            priority
            sizes="100vw"
            src={slide.image}
          />
        </div>
        <div className="flex-1 bg-black" />
      </div>

      <div className="relative hidden h-full w-full sm:block">
        <Image
          alt={slide.title}
          className="object-cover"
          fill
          priority
          sizes="100vw"
          src={slide.image}
        />
      </div>
    </div>
  );
}

// ─── TextContent ────────────────────────────────────────────────────────────

export function TextContent({ slide }: TextContentProps) {
  return (
    <div className="h-full w-full">
      <div className="flex h-full w-full flex-col sm:hidden">
        <div className="h-[200px] w-full shrink-0" />
        <div className="flex flex-1 flex-col justify-start px-6 pt-6 text-center text-white">
          <Heading
            className="mb-3 text-xl uppercase will-change-transform md:text-xl"
            level={2}
            weight="bold"
          >
            {slide.title}
          </Heading>
          <p className="mb-6 text-sm leading-relaxed will-change-transform">{slide.subtitle}</p>
          <div className="will-change-transform">
            <AppButton
              onClick={() => {
                // TODO: wire up slide CTA action
              }}
              size="md"
              variant="primary"
            >
              {slide.ctaText}
            </AppButton>
          </div>
        </div>
      </div>

      <div className="relative hidden h-full w-full sm:block">
        <div className="absolute inset-0 flex w-1/2 flex-col items-start justify-center gap-6 px-12 text-white lg:px-16 xl:w-[40%]">
          <Heading
            className="text-3xl uppercase leading-tight will-change-transform md:text-3xl lg:text-4xl"
            level={2}
            weight="bold"
          >
            {slide.title}
          </Heading>
          <p className="font-semibold text-sm leading-relaxed will-change-transform lg:text-base">
            {slide.subtitle}
          </p>
          <div className="will-change-transform">
            <AppButton
              onClick={() => {
                // TODO: wire up slide CTA action
              }}
              size="md"
              variant="primary"
            >
              {slide.ctaText}
            </AppButton>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── ImageContainer ─────────────────────────────────────────────────────────

export function ImageContainer({ style, zIndex, slide }: ImageContainerProps) {
  return (
    <div
      className="absolute inset-0 will-change-transform"
      style={{
        filter: style.filter,
        opacity: style.opacity,
        transform: style.transform,
        transition: style.transition,
        zIndex,
      }}
    >
      <SlideContent slide={slide} />
    </div>
  );
}

// ─── TextContainer ──────────────────────────────────────────────────────────

export function TextContainer({ style, zIndex, isActive, slide }: TextContainerProps) {
  const pointerEvents = isActive ? "auto" : "none";

  return (
    <div
      className="absolute inset-0 will-change-transform"
      style={{
        filter: style.filter,
        opacity: style.opacity,
        pointerEvents,
        transform: style.transform,
        transition: style.transition,
        zIndex,
      }}
    >
      <TextContent slide={slide} />
    </div>
  );
}

// ─── GradientOverlays ───────────────────────────────────────────────────────

export function GradientOverlays() {
  return (
    <>
      <div
        className="absolute inset-x-0 bottom-[260px] h-32 bg-linear-to-b from-transparent to-black sm:hidden"
        style={{ pointerEvents: "none", zIndex: 15 }}
      />
      <div
        className="absolute inset-0 hidden sm:block"
        style={{
          background: "linear-gradient(91.94deg, #000000 28.21%, rgba(0, 0, 0, 0) 50.16%)",
          pointerEvents: "none",
          zIndex: 15,
        }}
      />
    </>
  );
}

// ─── NavigationDots ─────────────────────────────────────────────────────────

export function NavigationDots({ slides, currentIndex, onDotClick }: NavigationDotsProps) {
  return (
    <div className="absolute right-0 bottom-6 left-0 z-30 flex justify-center gap-3 pt-0 sm:bottom-4">
      {slides.map((slide, i) => {
        const isActive = i === currentIndex;
        return (
          <button
            aria-label={`Go to slide ${i + 1}`}
            className={cn(
              "relative flex items-center justify-center border-none bg-transparent p-0",
              "h-4 w-4",
              isActive ? "" : "cursor-pointer"
            )}
            key={slide.id}
            onClick={() => onDotClick(i)}
            type="button"
          >
            <span
              className={cn(
                "block rounded-full transition-all",
                "h-2 w-2",
                isActive
                  ? "bg-white ring-1 ring-white ring-offset-2 ring-offset-black"
                  : "bg-white/40 hover:bg-white/60"
              )}
              style={{
                borderRadius: "var(--radius-md, 8px)",
              }}
            />
          </button>
        );
      })}
    </div>
  );
}

// ─── SingleSlideCarousel ────────────────────────────────────────────────────

export function SingleSlideCarousel({ className, slide }: SingleSlideCarouselProps) {
  const { ref: carouselRef, isFullyVisible } = useIsFullyVisible<HTMLDivElement>();

  return (
    <motion.div
      animate={{ opacity: isFullyVisible ? 1 : 0 }}
      className={cn("relative w-full", className)}
      initial={{ opacity: 0 }}
      ref={carouselRef}
      transition={{ duration: 0.6 }}
    >
      <div className="relative h-[460px] w-full overflow-hidden rounded-xl sm:h-[400px] lg:h-[500px]">
        <SlideContent slide={slide} />
        <GradientOverlays />
        <div className="absolute inset-0" style={{ zIndex: 25 }}>
          <TextContent slide={slide} />
        </div>
      </div>
    </motion.div>
  );
}
