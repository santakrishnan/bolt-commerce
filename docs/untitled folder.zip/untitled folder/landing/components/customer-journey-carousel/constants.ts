import type { StyleState } from "./types";

// ─── Timing ─────────────────────────────────────────────────────────────────

export const SLIDE_INTERVAL = 5000;
export const EXIT_DURATION = 600;
export const ENTER_DURATION = 600;

// ─── Default styles ─────────────────────────────────────────────────────────

export const DEFAULT_VISIBLE_STYLE: StyleState = {
  filter: "none",
  opacity: 1,
  transform: "none",
  transition: "none",
};

export const DEFAULT_HIDDEN_STYLE: StyleState = {
  filter: "none",
  opacity: 0,
  transform: "none",
  transition: "none",
};

// ─── Animation helpers ──────────────────────────────────────────────────────

export const getImageExitTransform = (): string => "scale(1.1)";
export const getImageEnterStartTransform = (): string => "scale(1.15)";
export const getTextExitTransform = (): string => "translateY(-40px)";
export const getTextEnterStartTransform = (): string => "translateY(50px)";
export const getExitFilter = (): string => "blur(4px)";
export const getEnterStartFilter = (): string => "blur(8px)";

export function getTransition(phase: "enter" | "exit"): string {
  const duration = phase === "exit" ? EXIT_DURATION : ENTER_DURATION;
  return `opacity ${duration + 200}ms ease-out, transform ${duration + 200}ms ease-out, filter ${duration}ms ease-out`;
}
