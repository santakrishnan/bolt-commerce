export type { CustomerJourneySlide } from "./carousel-data";
export { customerJourneySlides } from "./carousel-data";
export { CustomerJourneyCarousel } from "./customer-journey-carousel";
export type { PromotionFlags } from "./types";
