export * from "./types";
// landing.service uses cacheTag/cacheLife (server-only).
// Import directly: @features/landing/services/landing.service
