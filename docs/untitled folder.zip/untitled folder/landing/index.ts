// ── Public API for the landing feature ────────────────────────────────
// Only export symbols consumed outside the landing feature.
// Internal components (carousels, cards, sub-components) should be
// imported directly from their source files when needed.

// Arrow Inspected
export { ArrowInspectedSectionWrapper } from "./components/arrow-inspected";
// Buying Process
export { BuyingProcess } from "./components/buying-process";
export type { PromotionFlags } from "./components/customer-journey-carousel";
// Customer Journey Carousel
export { CustomerJourneyCarousel } from "./components/customer-journey-carousel";
// Home Hero
export { HomeHero } from "./components/home-hero";
// Vehicle Quick Links
export { VehicleQuickLinksGrid } from "./components/vehicle-quick-links";
// Vehicle Type Selector
export { VehicleTypeSelectorWrapper } from "./components/vehicle-type-selector";

// Services — landing.service uses cacheTag/cacheLife (server-only).
// Import directly: @features/landing/services/landing.service
