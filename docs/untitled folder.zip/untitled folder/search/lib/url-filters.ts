import type { FilterState } from "@features/search/components/filter-sidebar/types";

export type SearchSortOption = "recommended" | "low-high" | "high-low";

interface SearchUrlState {
  filterState: FilterState;
  labelFilter: string;
  page: number;
  searchQuery: string;
  sortOption: SearchSortOption;
}

export interface ParsedSearchUrlState {
  filterState: Partial<FilterState>;
  labelFilter?: string;
  page?: number;
  searchQuery?: string;
  sortOption?: SearchSortOption;
}

function parseCsv(value: string | null): string[] {
  if (!value) {
    return [];
  }
  return value
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

function parsePositiveInt(value: string | null): number | undefined {
  if (!value) {
    return undefined;
  }
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n : undefined;
}

function setIfValue(params: URLSearchParams, key: string, value: string) {
  if (value) {
    params.set(key, value);
  }
}

function _setCsv(params: URLSearchParams, key: string, value: string[]) {
  if (value.length > 0) {
    params.set(key, value.join(","));
  }
}

export function parseSearchUrlState(searchParams: URLSearchParams): ParsedSearchUrlState {
  const sort = searchParams.get("sort");
  const sortOption =
    sort === "recommended" || sort === "low-high" || sort === "high-low" ? sort : undefined;

  return {
    searchQuery: searchParams.get("q") ?? undefined,
    page: parsePositiveInt(searchParams.get("page")),
    sortOption,
    labelFilter: searchParams.get("label") ?? undefined,
    filterState: {
      selectedPriceQuick: searchParams.get("priceQuick") ?? undefined,
      selectedYearQuick: searchParams.get("yearQuick") ?? undefined,
      selectedMileage: searchParams.get("mileageQuick") ?? undefined,
      selectedBodyStyles: parseCsv(searchParams.get("bodyStyles")),
      selectedExteriorColors: parseCsv(searchParams.get("exteriorColors")),
      selectedInteriorColors: parseCsv(searchParams.get("interiorColors")),
      selectedFuelTypes: parseCsv(searchParams.get("fuelTypes")),
      selectedModels: parseCsv(searchParams.get("models")),
      selectedSafetyFeatures: parseCsv(searchParams.get("safetyFeatures")),
      selectedComfortFeatures: parseCsv(searchParams.get("comfortFeatures")),
      selectedTechFeatures: parseCsv(searchParams.get("techFeatures")),
      selectedExteriorFeatures: parseCsv(searchParams.get("exteriorFeatures")),
      selectedPerformanceFeatures: parseCsv(searchParams.get("performanceFeatures")),
      selectedSeatingCapacity: parseCsv(searchParams.get("seatingCapacity")),
      selectedDrivetrains: parseCsv(searchParams.get("drivetrains")),
      selectedTransmissions: parseCsv(searchParams.get("transmissions")),
      inspection160: searchParams.get("inspection") === "1",
    },
  };
}

export function serializeSearchUrlState(state: SearchUrlState): string {
  const params = new URLSearchParams();

  setIfValue(params, "q", state.searchQuery.trim());
  // setIfValue(params, "label", state.labelFilter.trim());

  // if (state.page > 1) {
  //   params.set("page", String(state.page));
  // }
  // if (state.sortOption !== "recommended") {
  //   params.set("sort", state.sortOption);
  // }

  // setIfValue(params, "priceQuick", state.filterState.selectedPriceQuick);
  // setIfValue(params, "yearQuick", state.filterState.selectedYearQuick);
  // setIfValue(params, "mileageQuick", state.filterState.selectedMileage);

  // setCsv(params, "bodyStyles", state.filterState.selectedBodyStyles);
  // setCsv(params, "exteriorColors", state.filterState.selectedExteriorColors);
  // setCsv(params, "interiorColors", state.filterState.selectedInteriorColors);
  // setCsv(params, "fuelTypes", state.filterState.selectedFuelTypes);
  // setCsv(params, "models", state.filterState.selectedModels);
  // setCsv(params, "safetyFeatures", state.filterState.selectedSafetyFeatures);
  // setCsv(params, "comfortFeatures", state.filterState.selectedComfortFeatures);
  // setCsv(params, "techFeatures", state.filterState.selectedTechFeatures);
  // setCsv(params, "exteriorFeatures", state.filterState.selectedExteriorFeatures);
  // setCsv(params, "performanceFeatures", state.filterState.selectedPerformanceFeatures);
  // setCsv(params, "seatingCapacity", state.filterState.selectedSeatingCapacity);
  // setCsv(params, "drivetrains", state.filterState.selectedDrivetrains);
  // setCsv(params, "transmissions", state.filterState.selectedTransmissions);

  // if (state.filterState.inspection160) {
  //   params.set("inspection", "1");
  // }

  return params.toString();
}
