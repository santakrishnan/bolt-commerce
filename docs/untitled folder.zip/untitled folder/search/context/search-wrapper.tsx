import type { FilterState } from "@features/search/components/filter-sidebar/types";
import { defaultFilterState } from "@features/search/components/filter-sidebar/types";
import { SearchClient } from "@features/search/context/search-client";
import { filterSections } from "@features/search/lib/filter-sections";
import { Suspense } from "react";
import { SearchProvider } from "./search-context";

interface SearchWrapperProps {
  initialBodyType?: string;
  initialSearchQuery?: string;
  initialUrlFilters?: Partial<FilterState>;
}

export function SearchWrapper({
  initialBodyType,
  initialSearchQuery,
  initialUrlFilters,
}: SearchWrapperProps = {}) {
  // Resolve the URL slug (e.g. "sedan") to the exact body style label (e.g. "Sedan" / "SUV")
  // This only applies to PATH-based body types (e.g. /used-cars/sedan), NOT query params.
  const initialBodyStyles: string[] = [];
  if (initialBodyType) {
    const match = filterSections.bodyStyle.find(
      (s) => s.toLowerCase() === initialBodyType.toLowerCase()
    );
    if (match) {
      initialBodyStyles.push(match);
    }
  }

  // Merge URL filter body styles with path-based body type
  if (initialUrlFilters?.selectedBodyStyles) {
    for (const bodyStyle of initialUrlFilters.selectedBodyStyles) {
      if (!initialBodyStyles.includes(bodyStyle)) {
        initialBodyStyles.push(bodyStyle);
      }
    }
  }

  // q= parameter is always treated as a plain text search query.
  // It fills the search bar and triggers the search API directly.
  // No mapping to filter chips or presets — the search service handles
  // query interpretation (e.g. "cars-under-$20,000" matches via TEXT_SEARCH_SHORTCUTS).
  const resolvedSearchQuery = initialSearchQuery ?? "";

  // Unique key so React fully remounts SearchClient whenever the filter context changes.
  // This ensures useState initializers re-run and stale state from a previous visit is cleared.
  const clientKey = `${initialBodyType ?? ""}|${initialSearchQuery ?? ""}|${JSON.stringify(initialUrlFilters ?? {})}`;

  return (
    <SearchProvider
      defaultFilterState={defaultFilterState}
      initialBodyStyles={initialBodyStyles}
      initialSearchQuery={resolvedSearchQuery}
      initialUrlFilters={initialUrlFilters}
      key={clientKey}
    >
      <Suspense fallback={null}>
        <SearchClient />
      </Suspense>
    </SearchProvider>
  );
}
