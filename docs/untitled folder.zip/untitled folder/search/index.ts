// ── Public API for the search feature ────────────────────────────────

// Components
export { FilterSidebar, type FilterState } from "./components/filter-sidebar";
// Search bar
export { SearchBar } from "./components/search-bar/search-bar";
export { SearchHero, type SearchHeroProps } from "./components/search-hero";
export {
  type ActiveFilter,
  VehicleResults,
  type VehicleResultsProps,
} from "./components/vehicle-results";
export { SearchClient } from "./context/search-client";
// Context
export { SearchHistoryProvider, useSearchHistory } from "./context/search-history-provider";
export { SearchWrapper } from "./context/search-wrapper";

// Hooks
export { useSearch } from "./hooks/use-search";
export { useSearchNavigation } from "./hooks/use-search-navigation";
export { type FilterSections, filterSections } from "./lib/filter-sections";
export { getVehicleFinancing } from "./lib/mock-financing-service";
export { buildAllAvailableFilters } from "./lib/mock-search-service";
// Lib (utilities needed by other features)
export { mockVehicles } from "./lib/mock-vehicles";
export {
  type ParsedSearchUrlState,
  parseSearchUrlState,
  serializeSearchUrlState,
} from "./lib/url-filters";
// Queries
export { searchHistoryQueries } from "./queries/search-history";
// Services
export { searchVehicles } from "./services/search.service";
export type { SearchPagination, SearchQuery, SearchResult, SearchVehicle } from "./services/types";
