import { render } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { useSingletonModal } from "../use-single-modal";

function Modal({ name, isOpen, onClose }: { name: string; isOpen: boolean; onClose: () => void }) {
  useSingletonModal("test-modal-event", isOpen, onClose);
  return <div data-testid={name}>{String(isOpen)}</div>;
}

describe("useSingletonModal", () => {
  it("dispatches when opened and other instances receive event and call onClose", () => {
    const aClose = vi.fn();
    const bClose = vi.fn();

    const spy = vi.spyOn(window, "dispatchEvent");

    const { rerender } = render(
      <>
        <Modal isOpen={false} name="a" onClose={aClose} />
        <Modal isOpen={true} name="b" onClose={bClose} />
      </>
    );

    // Open A — this should cause a dispatchEvent and cause B's onClose to be called
    rerender(
      <>
        <Modal isOpen={true} name="a" onClose={aClose} />
        <Modal isOpen={true} name="b" onClose={bClose} />
      </>
    );

    expect(spy).toHaveBeenCalled();
    expect(bClose).toHaveBeenCalled();
  });
});
