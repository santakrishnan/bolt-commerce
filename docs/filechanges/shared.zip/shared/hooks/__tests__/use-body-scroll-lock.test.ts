/**
 * Unit tests for useBodyScrollLock hook
 * @module shared/hooks/__tests__/use-body-scroll-lock
 */

import { renderHook } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { useBodyScrollLock } from "../use-body-scroll-lock";

describe("useBodyScrollLock", () => {
  let originalOverflow: string;

  beforeEach(() => {
    // Store original overflow value
    originalOverflow = document.body.style.overflow;
    // Reset to empty string for consistent test state
    document.body.style.overflow = "";
  });

  afterEach(() => {
    // Restore original overflow value
    document.body.style.overflow = originalOverflow;
  });

  it("sets overflow to hidden when locked is true", () => {
    renderHook(() => useBodyScrollLock(true));

    expect(document.body.style.overflow).toBe("hidden");
  });

  it("does not change overflow when locked is false", () => {
    document.body.style.overflow = "auto";

    renderHook(() => useBodyScrollLock(false));

    expect(document.body.style.overflow).toBe("auto");
  });

  it("restores original overflow value on unmount", () => {
    document.body.style.overflow = "scroll";

    const { unmount } = renderHook(() => useBodyScrollLock(true));

    expect(document.body.style.overflow).toBe("hidden");

    unmount();

    expect(document.body.style.overflow).toBe("scroll");
  });

  it("restores empty string overflow on unmount when original was empty", () => {
    document.body.style.overflow = "";

    const { unmount } = renderHook(() => useBodyScrollLock(true));

    expect(document.body.style.overflow).toBe("hidden");

    unmount();

    expect(document.body.style.overflow).toBe("");
  });

  it("updates overflow when locked changes from false to true", () => {
    const { rerender } = renderHook(({ locked }) => useBodyScrollLock(locked), {
      initialProps: { locked: false },
    });

    expect(document.body.style.overflow).toBe("");

    rerender({ locked: true });

    expect(document.body.style.overflow).toBe("hidden");
  });

  it("restores overflow when locked changes from true to false", () => {
    document.body.style.overflow = "visible";

    const { rerender } = renderHook(({ locked }) => useBodyScrollLock(locked), {
      initialProps: { locked: true },
    });

    expect(document.body.style.overflow).toBe("hidden");

    rerender({ locked: false });

    expect(document.body.style.overflow).toBe("visible");
  });

  it("handles multiple lock/unlock cycles", () => {
    document.body.style.overflow = "auto";

    const { rerender } = renderHook(({ locked }) => useBodyScrollLock(locked), {
      initialProps: { locked: false },
    });

    expect(document.body.style.overflow).toBe("auto");

    // Lock
    rerender({ locked: true });
    expect(document.body.style.overflow).toBe("hidden");

    // Unlock
    rerender({ locked: false });
    expect(document.body.style.overflow).toBe("auto");

    // Lock again
    rerender({ locked: true });
    expect(document.body.style.overflow).toBe("hidden");

    // Unlock again
    rerender({ locked: false });
    expect(document.body.style.overflow).toBe("auto");
  });

  it("preserves original overflow value through multiple locks", () => {
    document.body.style.overflow = "scroll";

    const { rerender, unmount } = renderHook(({ locked }) => useBodyScrollLock(locked), {
      initialProps: { locked: true },
    });

    expect(document.body.style.overflow).toBe("hidden");

    rerender({ locked: false });
    expect(document.body.style.overflow).toBe("scroll");

    rerender({ locked: true });
    expect(document.body.style.overflow).toBe("hidden");

    unmount();
    expect(document.body.style.overflow).toBe("scroll");
  });

  it("works with different overflow values", () => {
    const overflowValues = ["auto", "scroll", "visible", "clip", "overlay"];

    for (const value of overflowValues) {
      document.body.style.overflow = value;

      const { unmount } = renderHook(() => useBodyScrollLock(true));

      expect(document.body.style.overflow).toBe("hidden");

      unmount();

      expect(document.body.style.overflow).toBe(value);
    }
  });

  it("handles initial mount with locked true", () => {
    document.body.style.overflow = "auto";

    renderHook(() => useBodyScrollLock(true));

    expect(document.body.style.overflow).toBe("hidden");
  });

  it("handles initial mount with locked false", () => {
    document.body.style.overflow = "auto";

    renderHook(() => useBodyScrollLock(false));

    expect(document.body.style.overflow).toBe("auto");
  });

  it("does not interfere with other body styles", () => {
    document.body.style.backgroundColor = "red";
    document.body.style.margin = "10px";
    document.body.style.overflow = "auto";

    renderHook(() => useBodyScrollLock(true));

    expect(document.body.style.overflow).toBe("hidden");
    expect(document.body.style.backgroundColor).toBe("red");
    expect(document.body.style.margin).toBe("10px");
  });

  it("works with multiple instances - last one wins", () => {
    document.body.style.overflow = "auto";

    const { unmount: unmount1 } = renderHook(() => useBodyScrollLock(true));
    expect(document.body.style.overflow).toBe("hidden");

    const { unmount: unmount2 } = renderHook(() => useBodyScrollLock(false));
    // Second instance doesn't change it because locked is false
    expect(document.body.style.overflow).toBe("hidden");

    // Unmount first instance
    unmount1();
    // Should restore to what it was before first instance
    expect(document.body.style.overflow).toBe("auto");

    // Unmount second instance
    unmount2();
    // Should restore to what it was before second instance (which was "hidden" from first)
    expect(document.body.style.overflow).toBe("hidden");
  });

  it("captures overflow value at mount time, not at lock time", () => {
    document.body.style.overflow = "auto";

    const { rerender } = renderHook(({ locked }) => useBodyScrollLock(locked), {
      initialProps: { locked: false },
    });

    // Manually change overflow
    document.body.style.overflow = "scroll";

    // Lock it
    rerender({ locked: true });
    expect(document.body.style.overflow).toBe("hidden");

    // Unlock - should restore to "auto" (captured at mount), not "scroll"
    rerender({ locked: false });
    expect(document.body.style.overflow).toBe("auto");
  });

  it("handles rapid lock/unlock changes", () => {
    document.body.style.overflow = "visible";

    const { rerender } = renderHook(({ locked }) => useBodyScrollLock(locked), {
      initialProps: { locked: false },
    });

    // Rapid changes
    for (let i = 0; i < 10; i++) {
      rerender({ locked: true });
      expect(document.body.style.overflow).toBe("hidden");

      rerender({ locked: false });
      expect(document.body.style.overflow).toBe("visible");
    }
  });

  it("restores correct value when unmounting while locked", () => {
    document.body.style.overflow = "clip";

    const { unmount } = renderHook(() => useBodyScrollLock(true));

    expect(document.body.style.overflow).toBe("hidden");

    unmount();

    expect(document.body.style.overflow).toBe("clip");
  });

  it("restores correct value when unmounting while unlocked", () => {
    document.body.style.overflow = "overlay";

    const { unmount } = renderHook(() => useBodyScrollLock(false));

    expect(document.body.style.overflow).toBe("overlay");

    unmount();

    expect(document.body.style.overflow).toBe("overlay");
  });

  it("handles undefined overflow value", () => {
    // Remove overflow style completely
    document.body.style.removeProperty("overflow");

    const { unmount } = renderHook(() => useBodyScrollLock(true));

    expect(document.body.style.overflow).toBe("hidden");

    unmount();

    // Should restore to empty string (default)
    expect(document.body.style.overflow).toBe("");
  });
});
