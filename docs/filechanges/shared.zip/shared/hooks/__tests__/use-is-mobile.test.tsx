import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { useIsMobile } from "../use-is-mobile";

function Comp() {
  const isMobile = useIsMobile();
  return <div>{String(isMobile)}</div>;
}

describe("useIsMobile", () => {
  it("updates when window width crosses the MOBILE_BREAKPOINT", async () => {
    // start desktop
    window.innerWidth = 1200;
    const { rerender } = render(<Comp />);
    expect(screen.getByText("false")).toBeDefined();

    // switch to mobile
    window.innerWidth = 800;
    window.dispatchEvent(new Event("resize"));

    // render again to let effect run
    rerender(<Comp />);
    expect(await screen.findByText("true")).toBeDefined();
  });
});
