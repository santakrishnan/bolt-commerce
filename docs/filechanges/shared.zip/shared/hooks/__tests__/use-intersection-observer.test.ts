/**
 * Unit tests for useIntersectionObserver hook
 * @module shared/hooks/__tests__/use-intersection-observer
 */

import { renderHook } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { useIntersectionObserver } from "../use-intersection-observer";

describe("useIntersectionObserver", () => {
  let element: HTMLDivElement;
  let callback: ReturnType<typeof vi.fn>;
  let mockObserver: {
    observe: ReturnType<typeof vi.fn>;
    disconnect: ReturnType<typeof vi.fn>;
    unobserve: ReturnType<typeof vi.fn>;
    takeRecords: ReturnType<typeof vi.fn>;
  };

  beforeEach(() => {
    element = document.createElement("div");
    document.body.appendChild(element);
    callback = vi.fn();

    // Mock IntersectionObserver
    mockObserver = {
      observe: vi.fn(),
      disconnect: vi.fn(),
      unobserve: vi.fn(),
      takeRecords: vi.fn(() => []),
    };

    global.IntersectionObserver = vi.fn((cb) => {
      // Store callback for later invocation in tests
      (mockObserver as any).callback = cb;
      return mockObserver as any;
    }) as any;
  });

  afterEach(() => {
    document.body.removeChild(element);
    vi.clearAllMocks();
  });

  it("creates an IntersectionObserver and observes the element", () => {
    const ref = { current: element };
    renderHook(() => useIntersectionObserver(ref, callback));

    expect(global.IntersectionObserver).toHaveBeenCalledWith(callback, {});
    expect(mockObserver.observe).toHaveBeenCalledWith(element);
  });

  it("passes options to IntersectionObserver", () => {
    const ref = { current: element };
    const options = {
      root: null,
      rootMargin: "10px",
      threshold: 0.5,
    };

    renderHook(() => useIntersectionObserver(ref, callback, options));

    expect(global.IntersectionObserver).toHaveBeenCalledWith(callback, options);
  });

  it("does not create observer when ref is null", () => {
    const ref = { current: null };
    renderHook(() => useIntersectionObserver(ref, callback));

    expect(global.IntersectionObserver).not.toHaveBeenCalled();
    expect(mockObserver.observe).not.toHaveBeenCalled();
  });

  it("does not create observer when ref object itself is null", () => {
    renderHook(() => useIntersectionObserver(null, callback));

    expect(global.IntersectionObserver).not.toHaveBeenCalled();
    expect(mockObserver.observe).not.toHaveBeenCalled();
  });

  it("does not create observer when enabled is false", () => {
    const ref = { current: element };
    renderHook(() => useIntersectionObserver(ref, callback, { enabled: false }));

    expect(global.IntersectionObserver).not.toHaveBeenCalled();
    expect(mockObserver.observe).not.toHaveBeenCalled();
  });

  it("creates observer when enabled is true", () => {
    const ref = { current: element };
    renderHook(() => useIntersectionObserver(ref, callback, { enabled: true }));

    expect(global.IntersectionObserver).toHaveBeenCalledWith(callback, { enabled: true });
    expect(mockObserver.observe).toHaveBeenCalledWith(element);
  });

  it("creates observer when enabled is undefined (defaults to enabled)", () => {
    const ref = { current: element };
    renderHook(() => useIntersectionObserver(ref, callback, {}));

    expect(global.IntersectionObserver).toHaveBeenCalledWith(callback, {});
    expect(mockObserver.observe).toHaveBeenCalledWith(element);
  });

  it("disconnects observer on unmount", () => {
    const ref = { current: element };
    const { unmount } = renderHook(() => useIntersectionObserver(ref, callback));

    unmount();

    expect(mockObserver.disconnect).toHaveBeenCalledTimes(1);
  });

  it("does not disconnect if observer was never created", () => {
    const ref = { current: null };
    const { unmount } = renderHook(() => useIntersectionObserver(ref, callback));

    unmount();

    expect(mockObserver.disconnect).not.toHaveBeenCalled();
  });

  it("invokes callback when intersection occurs", () => {
    const ref = { current: element };
    renderHook(() => useIntersectionObserver(ref, callback));

    // Simulate intersection
    const entries: IntersectionObserverEntry[] = [
      {
        target: element,
        isIntersecting: true,
        intersectionRatio: 0.5,
        boundingClientRect: {} as DOMRectReadOnly,
        intersectionRect: {} as DOMRectReadOnly,
        rootBounds: null,
        time: Date.now(),
      } as IntersectionObserverEntry,
    ];

    const observerCallback = (mockObserver as any).callback;
    observerCallback(entries, mockObserver);

    expect(callback).toHaveBeenCalledWith(entries, mockObserver);
  });

  it("recreates observer when ref changes", () => {
    const ref = { current: element };
    const { rerender } = renderHook(() => useIntersectionObserver(ref, callback));

    expect(mockObserver.observe).toHaveBeenCalledTimes(1);
    expect(mockObserver.disconnect).not.toHaveBeenCalled();

    // Change ref to new element
    const newElement = document.createElement("div");
    document.body.appendChild(newElement);
    ref.current = newElement;

    rerender();

    expect(mockObserver.disconnect).toHaveBeenCalledTimes(1);
    expect(mockObserver.observe).toHaveBeenCalledTimes(2);
    expect(mockObserver.observe).toHaveBeenCalledWith(newElement);

    document.body.removeChild(newElement);
  });

  it("recreates observer when callback changes", () => {
    const ref = { current: element };
    const newCallback = vi.fn();

    const { rerender } = renderHook(({ cb }) => useIntersectionObserver(ref, cb), {
      initialProps: { cb: callback },
    });

    expect(global.IntersectionObserver).toHaveBeenCalledTimes(1);
    expect(global.IntersectionObserver).toHaveBeenCalledWith(callback, {});

    // Change callback
    rerender({ cb: newCallback });

    expect(mockObserver.disconnect).toHaveBeenCalledTimes(1);
    expect(global.IntersectionObserver).toHaveBeenCalledTimes(2);
    expect(global.IntersectionObserver).toHaveBeenCalledWith(newCallback, {});
  });

  it("recreates observer when options change", () => {
    const ref = { current: element };
    const options1 = { threshold: 0.5 };
    const options2 = { threshold: 0.8 };

    const { rerender } = renderHook(({ opts }) => useIntersectionObserver(ref, callback, opts), {
      initialProps: { opts: options1 },
    });

    expect(global.IntersectionObserver).toHaveBeenCalledWith(callback, options1);

    // Change options
    rerender({ opts: options2 });

    expect(mockObserver.disconnect).toHaveBeenCalledTimes(1);
    expect(global.IntersectionObserver).toHaveBeenCalledTimes(2);
    expect(global.IntersectionObserver).toHaveBeenCalledWith(callback, options2);
  });

  it("handles enabled changing from false to true", () => {
    const ref = { current: element };

    const { rerender } = renderHook(
      ({ enabled }) => useIntersectionObserver(ref, callback, { enabled }),
      { initialProps: { enabled: false } }
    );

    expect(global.IntersectionObserver).not.toHaveBeenCalled();

    // Enable observer
    rerender({ enabled: true });

    expect(global.IntersectionObserver).toHaveBeenCalledTimes(1);
    expect(mockObserver.observe).toHaveBeenCalledWith(element);
  });

  it("handles enabled changing from true to false", () => {
    const ref = { current: element };

    const { rerender } = renderHook(
      ({ enabled }) => useIntersectionObserver(ref, callback, { enabled }),
      { initialProps: { enabled: true } }
    );

    expect(global.IntersectionObserver).toHaveBeenCalledTimes(1);
    expect(mockObserver.observe).toHaveBeenCalledWith(element);

    // Disable observer
    rerender({ enabled: false });

    expect(mockObserver.disconnect).toHaveBeenCalledTimes(1);
    // No new observer created
    expect(global.IntersectionObserver).toHaveBeenCalledTimes(1);
  });

  it("works with multiple threshold values", () => {
    const ref = { current: element };
    const options = {
      threshold: [0, 0.25, 0.5, 0.75, 1],
    };

    renderHook(() => useIntersectionObserver(ref, callback, options));

    expect(global.IntersectionObserver).toHaveBeenCalledWith(callback, options);
  });

  it("works with custom root element", () => {
    const ref = { current: element };
    const rootElement = document.createElement("div");
    document.body.appendChild(rootElement);

    const options = {
      root: rootElement,
      rootMargin: "20px",
    };

    renderHook(() => useIntersectionObserver(ref, callback, options));

    expect(global.IntersectionObserver).toHaveBeenCalledWith(callback, options);

    document.body.removeChild(rootElement);
  });

  it("handles multiple intersection events", () => {
    const ref = { current: element };
    renderHook(() => useIntersectionObserver(ref, callback));

    const observerCallback = (mockObserver as any).callback;

    // First intersection
    const entries1: IntersectionObserverEntry[] = [
      {
        target: element,
        isIntersecting: true,
        intersectionRatio: 0.5,
      } as IntersectionObserverEntry,
    ];
    observerCallback(entries1, mockObserver);

    // Second intersection
    const entries2: IntersectionObserverEntry[] = [
      {
        target: element,
        isIntersecting: false,
        intersectionRatio: 0,
      } as IntersectionObserverEntry,
    ];
    observerCallback(entries2, mockObserver);

    expect(callback).toHaveBeenCalledTimes(2);
    expect(callback).toHaveBeenNthCalledWith(1, entries1, mockObserver);
    expect(callback).toHaveBeenNthCalledWith(2, entries2, mockObserver);
  });

  it("handles ref.current becoming null after initial setup", () => {
    const ref = { current: element };
    const { rerender } = renderHook(() => useIntersectionObserver(ref, callback));

    expect(mockObserver.observe).toHaveBeenCalledTimes(1);

    // Set ref.current to null
    ref.current = null;
    rerender();

    // Observer should be disconnected
    expect(mockObserver.disconnect).toHaveBeenCalledTimes(1);
  });

  it("passes all standard IntersectionObserver options", () => {
    const ref = { current: element };
    const options = {
      root: null,
      rootMargin: "10px 20px 30px 40px",
      threshold: [0, 0.5, 1],
      enabled: true,
    };

    renderHook(() => useIntersectionObserver(ref, callback, options));

    expect(global.IntersectionObserver).toHaveBeenCalledWith(callback, options);
  });
});
