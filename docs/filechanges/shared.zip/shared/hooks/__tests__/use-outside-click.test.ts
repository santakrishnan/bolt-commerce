/**
 * Unit tests for useOutsideClick hook
 * @module shared/hooks/__tests__/use-outside-click
 */

import { renderHook } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { useOutsideClick } from "../use-outside-click";

describe("useOutsideClick", () => {
  let container: HTMLDivElement;
  let innerElement: HTMLDivElement;
  let outsideElement: HTMLDivElement;
  let handler: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    // Create DOM structure for testing
    container = document.createElement("div");
    innerElement = document.createElement("div");
    outsideElement = document.createElement("div");

    container.appendChild(innerElement);
    document.body.appendChild(container);
    document.body.appendChild(outsideElement);

    handler = vi.fn();
  });

  afterEach(() => {
    document.body.removeChild(container);
    document.body.removeChild(outsideElement);
    vi.clearAllMocks();
  });

  it("calls handler when clicking outside the referenced element", () => {
    const ref = { current: container };
    renderHook(() => useOutsideClick(ref, handler));

    // Click outside
    const event = new MouseEvent("mousedown", { bubbles: true });
    Object.defineProperty(event, "target", { value: outsideElement, enumerable: true });
    outsideElement.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(1);
    expect(handler).toHaveBeenCalledWith(event);
  });

  it("does not call handler when clicking inside the referenced element", () => {
    const ref = { current: container };
    renderHook(() => useOutsideClick(ref, handler));

    // Click inside
    const event = new MouseEvent("mousedown", { bubbles: true });
    Object.defineProperty(event, "target", { value: innerElement, enumerable: true });
    innerElement.dispatchEvent(event);

    expect(handler).not.toHaveBeenCalled();
  });

  it("does not call handler when clicking on the referenced element itself", () => {
    const ref = { current: container };
    renderHook(() => useOutsideClick(ref, handler));

    // Click on the container itself
    const event = new MouseEvent("mousedown", { bubbles: true });
    Object.defineProperty(event, "target", { value: container, enumerable: true });
    container.dispatchEvent(event);

    expect(handler).not.toHaveBeenCalled();
  });

  it("does nothing when ref is null", () => {
    const ref = { current: null };
    renderHook(() => useOutsideClick(ref, handler));

    // Click anywhere
    const event = new MouseEvent("mousedown", { bubbles: true });
    Object.defineProperty(event, "target", { value: outsideElement, enumerable: true });
    outsideElement.dispatchEvent(event);

    expect(handler).not.toHaveBeenCalled();
  });

  it("does nothing when ref object itself is null", () => {
    renderHook(() => useOutsideClick(null, handler));

    // Click anywhere
    const event = new MouseEvent("mousedown", { bubbles: true });
    Object.defineProperty(event, "target", { value: outsideElement, enumerable: true });
    outsideElement.dispatchEvent(event);

    expect(handler).not.toHaveBeenCalled();
  });

  it("removes event listener on unmount", () => {
    const ref = { current: container };
    const removeEventListenerSpy = vi.spyOn(document, "removeEventListener");

    const { unmount } = renderHook(() => useOutsideClick(ref, handler));

    unmount();

    expect(removeEventListenerSpy).toHaveBeenCalledWith("mousedown", expect.any(Function));
    removeEventListenerSpy.mockRestore();
  });

  it("updates handler when ref changes", () => {
    const ref = { current: container };
    const { rerender } = renderHook(() => useOutsideClick(ref, handler));

    // Click outside with first handler
    let event = new MouseEvent("mousedown", { bubbles: true });
    Object.defineProperty(event, "target", { value: outsideElement, enumerable: true });
    outsideElement.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(1);

    // Change ref to a different element
    const newContainer = document.createElement("div");
    document.body.appendChild(newContainer);
    ref.current = newContainer;

    rerender();

    // Click on old container (now outside new ref)
    event = new MouseEvent("mousedown", { bubbles: true });
    Object.defineProperty(event, "target", { value: container, enumerable: true });
    container.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(2);

    document.body.removeChild(newContainer);
  });

  it("updates handler when handler function changes", () => {
    const ref = { current: container };
    const newHandler = vi.fn();

    const { rerender } = renderHook(({ handlerFn }) => useOutsideClick(ref, handlerFn), {
      initialProps: { handlerFn: handler },
    });

    // Click outside with first handler
    let event = new MouseEvent("mousedown", { bubbles: true });
    Object.defineProperty(event, "target", { value: outsideElement, enumerable: true });
    outsideElement.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(1);
    expect(newHandler).not.toHaveBeenCalled();

    // Update to new handler
    rerender({ handlerFn: newHandler });

    // Click outside with new handler
    event = new MouseEvent("mousedown", { bubbles: true });
    Object.defineProperty(event, "target", { value: outsideElement, enumerable: true });
    outsideElement.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(1); // Still 1
    expect(newHandler).toHaveBeenCalledTimes(1); // New handler called
  });

  it("handles ref.current becoming null after initial setup", () => {
    const ref = { current: container };
    renderHook(() => useOutsideClick(ref, handler));

    // Set ref.current to null
    ref.current = null;

    // Click anywhere - handler should not be called because ref.current is null
    const event = new MouseEvent("mousedown", { bubbles: true });
    Object.defineProperty(event, "target", { value: outsideElement, enumerable: true });
    outsideElement.dispatchEvent(event);

    // Handler is not called because the onClick function checks if el is null
    expect(handler).not.toHaveBeenCalled();
  });

  it("handles multiple clicks outside", () => {
    const ref = { current: container };
    renderHook(() => useOutsideClick(ref, handler));

    // First click
    let event = new MouseEvent("mousedown", { bubbles: true });
    Object.defineProperty(event, "target", { value: outsideElement, enumerable: true });
    outsideElement.dispatchEvent(event);

    // Second click
    event = new MouseEvent("mousedown", { bubbles: true });
    Object.defineProperty(event, "target", { value: outsideElement, enumerable: true });
    outsideElement.dispatchEvent(event);

    // Third click
    event = new MouseEvent("mousedown", { bubbles: true });
    Object.defineProperty(event, "target", { value: outsideElement, enumerable: true });
    outsideElement.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(3);
  });

  it("works with nested elements - clicking on deeply nested child does not trigger handler", () => {
    const ref = { current: container };
    const deeplyNested = document.createElement("span");
    innerElement.appendChild(deeplyNested);

    renderHook(() => useOutsideClick(ref, handler));

    // Click on deeply nested element
    const event = new MouseEvent("mousedown", { bubbles: true });
    Object.defineProperty(event, "target", { value: deeplyNested, enumerable: true });
    deeplyNested.dispatchEvent(event);

    expect(handler).not.toHaveBeenCalled();
  });

  it("adds event listener on mount", () => {
    const ref = { current: container };
    const addEventListenerSpy = vi.spyOn(document, "addEventListener");

    renderHook(() => useOutsideClick(ref, handler));

    expect(addEventListenerSpy).toHaveBeenCalledWith("mousedown", expect.any(Function));
    addEventListenerSpy.mockRestore();
  });

  it("does not add event listener when ref is null on mount", () => {
    const ref = { current: null };
    const addEventListenerSpy = vi.spyOn(document, "addEventListener");

    renderHook(() => useOutsideClick(ref, handler));

    expect(addEventListenerSpy).not.toHaveBeenCalled();
    addEventListenerSpy.mockRestore();
  });
});
