import { describe, expect, it, vi } from "vitest";

const fakeQueryClient = {
  cancelQueries: vi.fn().mockResolvedValue(undefined),
  getQueryData: vi.fn().mockReturnValue([{ id: "a" }]),
  setQueryData: vi.fn(),
  invalidateQueries: vi.fn(),
};

let capturedCfg: any = null;

vi.mock("@tanstack/react-query", () => ({
  useQueryClient: () => fakeQueryClient,
  useMutation: (cfg: any) => {
    capturedCfg = cfg;
    return {
      mutate: () => {
        /* noop for tests */
      },
    };
  },
}));

import { useOptimisticListMutation } from "../use-optimistic-list-mutation";

describe("useOptimisticListMutation", () => {
  it("registers mutation callbacks that interact with queryClient as expected", async () => {
    const updater = (current: any[], vars: any) => [...current, vars.item];

    // call the hook (mocks intercept useMutation/useQueryClient)
    useOptimisticListMutation({
      queryKey: ["test-key"],
      mutationFn: async () => [],
      updater,
    });

    expect(capturedCfg).not.toBeNull();

    // onMutate should cancel queries, snapshot previous and optimistically update
    const context = await capturedCfg.onMutate({ item: { id: "b" } });
    expect(fakeQueryClient.cancelQueries).toHaveBeenCalledWith({ queryKey: ["test-key"] });
    expect(fakeQueryClient.getQueryData).toHaveBeenCalledWith(["test-key"]);
    expect(fakeQueryClient.setQueryData).toHaveBeenCalledWith(["test-key"], expect.any(Array));
    expect(context.previous).toEqual([{ id: "a" }]);

    // onSuccess with server-returned array sets authoritative cache
    capturedCfg.onSuccess([{ id: "server" }]);
    expect(fakeQueryClient.setQueryData).toHaveBeenCalledWith(["test-key"], [{ id: "server" }]);

    // onError should rollback to previous if provided
    capturedCfg.onError(null, null, { previous: [{ id: "orig" }] });
    expect(fakeQueryClient.setQueryData).toHaveBeenCalledWith(["test-key"], [{ id: "orig" }]);

    // onSettled should mark queries stale without immediate refetch
    capturedCfg.onSettled();
    expect(fakeQueryClient.invalidateQueries).toHaveBeenCalledWith({
      queryKey: ["test-key"],
      refetchType: "none",
    });
  });
});
