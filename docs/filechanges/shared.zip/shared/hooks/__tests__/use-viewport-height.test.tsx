import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { useViewportHeight, useViewportHeightVar } from "../use-viewport-height";

function Comp() {
  const vh = useViewportHeight();
  const css = useViewportHeightVar();
  return (
    <div>
      <div data-testid="vh">{vh}</div>
      <div data-testid="css">{JSON.stringify(css)}</div>
    </div>
  );
}

describe("useViewportHeight", () => {
  it("computes viewport height minus header and updates on resize", () => {
    window.innerWidth = 800; // desktop header: 80
    window.innerHeight = 900;
    const { rerender } = render(<Comp />);

    expect(screen.getByTestId("vh").textContent).toBe(`${900 - 80}px`);
    expect(screen.getByTestId("css").textContent).toContain("--vh-minus-header");

    // switch to mobile widths and smaller height
    window.innerWidth = 500; // mobile header: 64
    window.innerHeight = 700;
    window.dispatchEvent(new Event("resize"));
    rerender(<Comp />);

    expect(screen.getByTestId("vh").textContent).toBe(`${700 - 64}px`);
  });
});
