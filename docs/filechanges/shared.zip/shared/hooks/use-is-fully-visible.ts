"use client";

import { useEffect, useRef, useState } from "react";

const VISIBILITY_THRESHOLDS = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.85, 0.9, 0.95, 1.0];

/**
 * Tracks whether a DOM element is fully visible in the viewport.
 *
 * Once the element becomes visible (bottom in viewport, intersecting,
 * and ≥ 85% visible), the flag latches to `true` and never resets.
 *
 * Returns a ref to attach to the target element and a boolean flag.
 */
export function useIsFullyVisible<T extends HTMLElement = HTMLDivElement>() {
  const ref = useRef<T>(null);
  const [isFullyVisible, setIsFullyVisible] = useState(false);

  useEffect(() => {
    const element = ref.current;
    if (!element) {
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry) {
          return;
        }

        const rect = entry.boundingClientRect;
        const viewportHeight = window.innerHeight || document.documentElement.clientHeight;
        const bottomIsVisible = rect.bottom <= viewportHeight;
        const isMostlyVisible = entry.intersectionRatio >= 0.85;

        if (bottomIsVisible && entry.isIntersecting && isMostlyVisible) {
          setIsFullyVisible(true);
        }
      },
      { threshold: VISIBILITY_THRESHOLDS, rootMargin: "0px" }
    );

    observer.observe(element);

    return () => {
      observer.disconnect();
    };
  }, []);

  return { ref, isFullyVisible };
}
