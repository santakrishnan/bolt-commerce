import { beforeEach, describe, expect, it, vi } from "vitest";

beforeEach(() => {
  // Ensure a clean module state between tests so the internal counters reset.
  vi.resetModules();
  // Reset document body styles
  document.body.style.overflow = "";
  document.body.style.paddingRight = "";
});

describe("body-scroll-lock", () => {
  it("locks and unlocks body scroll and compensates for scrollbar width", async () => {
    // fresh import to reset module-level state
    const mod = await import("../body-scroll-lock");
    const { lockBodyScroll, unlockBodyScroll } = mod;

    // Simulate a scrollbar width of 20px
    Object.defineProperty(document.documentElement, "clientWidth", {
      value: 1000,
      configurable: true,
    });
    // @ts-expect-error - jsdom allows writing innerWidth
    window.innerWidth = 1020;

    // Set initial body styles
    document.body.style.overflow = "auto";
    document.body.style.paddingRight = "5px";

    // Lock once: should set overflow hidden and add scrollbar width to paddingRight
    lockBodyScroll();
    expect(document.body.style.overflow).toBe("hidden");
    expect(document.body.style.paddingRight).toBe("25px");

    // Lock again: should increment count but not change styles
    lockBodyScroll();
    expect(document.body.style.overflow).toBe("hidden");
    expect(document.body.style.paddingRight).toBe("25px");

    // Unlock once: still locked (count > 0)
    unlockBodyScroll();
    expect(document.body.style.overflow).toBe("hidden");
    expect(document.body.style.paddingRight).toBe("25px");

    // Unlock final time: styles restored
    unlockBodyScroll();
    expect(document.body.style.overflow).toBe("auto");
    expect(document.body.style.paddingRight).toBe("5px");
  });

  it("does not adjust padding when scrollbar width is zero", async () => {
    const mod = await import("../body-scroll-lock");
    const { lockBodyScroll, unlockBodyScroll } = mod;

    // Simulate no scrollbar width
    Object.defineProperty(document.documentElement, "clientWidth", {
      value: 1000,
      configurable: true,
    });
    // @ts-expect-error
    window.innerWidth = 1000;

    document.body.style.overflow = "visible";
    document.body.style.paddingRight = "3px";

    lockBodyScroll();
    expect(document.body.style.overflow).toBe("hidden");
    // padding should remain unchanged when scrollbar width is 0
    expect(document.body.style.paddingRight).toBe("3px");

    unlockBodyScroll();
    expect(document.body.style.overflow).toBe("visible");
    expect(document.body.style.paddingRight).toBe("3px");
  });

  it("unlock when no locks is a no-op", async () => {
    const mod = await import("../body-scroll-lock");
    const { unlockBodyScroll } = mod;

    document.body.style.overflow = "orig";
    document.body.style.paddingRight = "7px";

    // Calling unlock when nothing is locked should not change styles
    unlockBodyScroll();
    expect(document.body.style.overflow).toBe("orig");
    expect(document.body.style.paddingRight).toBe("7px");
  });

  it("is a no-op when window is undefined", async () => {
    const mod = await import("../body-scroll-lock");
    const { lockBodyScroll, unlockBodyScroll } = mod;

    const savedWindow = (global as any).window;
    try {
      (global as any).window = undefined;

      document.body.style.overflow = "keep";
      document.body.style.paddingRight = "9px";

      // Should return early and not throw or modify styles
      expect(() => lockBodyScroll()).not.toThrow();
      expect(document.body.style.overflow).toBe("keep");
      expect(document.body.style.paddingRight).toBe("9px");

      expect(() => unlockBodyScroll()).not.toThrow();
      expect(document.body.style.overflow).toBe("keep");
      expect(document.body.style.paddingRight).toBe("9px");
    } finally {
      (global as any).window = savedWindow;
    }
  });

  it("handles non-numeric computed paddingRight gracefully", async () => {
    const mod = await import("../body-scroll-lock");
    const { lockBodyScroll, unlockBodyScroll } = mod;

    // simulate scrollbar width
    Object.defineProperty(document.documentElement, "clientWidth", {
      value: 1000,
      configurable: true,
    });
    // @ts-expect-error
    window.innerWidth = 1020;

    // Remove inline padding so getComputedStyle is used and mock it to return non-numeric
    document.body.style.paddingRight = "";
    const originalGetComputedStyle = window.getComputedStyle;
    // @ts-expect-error
    window.getComputedStyle = () => ({ paddingRight: "invalid" });

    try {
      lockBodyScroll();
      // computed padding was invalid -> treated as 0, so padding should be scrollbarWidth px
      expect(document.body.style.paddingRight).toBe("20px");
    } finally {
      // restore
      // @ts-expect-error
      window.getComputedStyle = originalGetComputedStyle;
      unlockBodyScroll();
    }
  });
});
