import { beforeEach, describe, expect, it } from "vitest";
import * as idbModule from "../indexeddb";

// Create a small fake IndexedDB implementation for tests.
function createFakeIndexedDB(options: { errorKey?: string } = {}) {
  const stores: Record<string, Map<any, any>> = {};

  function makeReq(fn: () => any) {
    const req: any = { result: undefined, onsuccess: null, onerror: null, error: null };
    setTimeout(() => {
      try {
        req.result = fn();
        if (req.onsuccess) {
          req.onsuccess();
        }
      } catch (err) {
        req.error = err;
        if (req.onerror) {
          req.onerror();
        }
      }
    }, 0);
    return req;
  }

  return {
    open(_name: string, _version: number) {
      const req: any = { result: null, onupgradeneeded: null, onsuccess: null, onerror: null };

      const db = {
        objectStoreNames: {
          contains: (n: string) => Object.hasOwn(stores, n),
        },
        createObjectStore: (n: string) => {
          if (!stores[n]) {
            stores[n] = new Map();
          }
        },
        transaction: (storeName: string) => {
          if (!stores[storeName]) {
            stores[storeName] = new Map();
          }
          const map = stores[storeName];
          return {
            objectStore: () => ({
              get: (key: any) =>
                makeReq(() => {
                  if (key === options.errorKey) {
                    throw new Error("get error");
                  }
                  const v = map.has(key) ? { key, value: map.get(key) } : undefined;
                  return v;
                }),
              put: (obj: { key: any; value: any }) =>
                makeReq(() => {
                  if (obj.key === options.errorKey) {
                    throw new Error("put error");
                  }
                  map.set(obj.key, obj.value);
                  return undefined;
                }),
              delete: (key: any) =>
                makeReq(() => {
                  if (key === options.errorKey) {
                    throw new Error("delete error");
                  }
                  map.delete(key);
                  return undefined;
                }),
            }),
          };
        },
      } as any;

      req.result = db;
      // Simulate upgrade then success asynchronously
      setTimeout(() => {
        if (req.onupgradeneeded) {
          req.onupgradeneeded();
        }
        if (req.onsuccess) {
          req.onsuccess();
        }
      }, 0);

      return req;
    },
  };
}

describe("indexeddb helper", () => {
  beforeEach(() => {
    // default fake without errors
    // @ts-expect-error - assign to global
    global.indexedDB = createFakeIndexedDB();
  });

  it("sets and gets a simple value", async () => {
    await idbModule.idbSet("x", 123);
    const got = await idbModule.idbGet<number>("x");
    expect(got).toBe(123);
  });

  it("returns undefined for missing keys", async () => {
    const v = await idbModule.idbGet("not-there");
    expect(v).toBeUndefined();
  });

  it("deletes a key", async () => {
    await idbModule.idbSet("to-delete", "value");
    let v = await idbModule.idbGet("to-delete");
    expect(v).toBe("value");
    await idbModule.idbDel("to-delete");
    v = await idbModule.idbGet("to-delete");
    expect(v).toBeUndefined();
  });

  it("rejects when the underlying request errors (get)", async () => {
    // Replace global.indexedDB with an error-producing fake for a specific key
    // @ts-expect-error
    global.indexedDB = createFakeIndexedDB({ errorKey: "boom" });

    await expect(idbModule.idbGet("boom")).rejects.toThrow("get error");
  });

  it("rejects when the underlying request errors (put)", async () => {
    // @ts-expect-error
    global.indexedDB = createFakeIndexedDB({ errorKey: "boom-put" });
    await expect(idbModule.idbSet("boom-put", 1)).rejects.toThrow("put error");
  });

  it("rejects when the underlying request errors (delete)", async () => {
    // @ts-expect-error
    global.indexedDB = createFakeIndexedDB({ errorKey: "boom-del" });
    await expect(idbModule.idbDel("boom-del")).rejects.toThrow("delete error");
  });

  it("default export exposes helpers", () => {
    expect(idbModule.default).toHaveProperty("idbGet");
    expect(idbModule.default).toHaveProperty("idbSet");
    expect(idbModule.default).toHaveProperty("idbDel");
  });
});
