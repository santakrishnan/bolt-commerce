import { beforeEach, describe, expect, it, vi } from "vitest";
import * as cookieCache from "../cookie-cache";

// Helper to control document.cookie getter/setter in tests
let cookieGetterValue = "";
let lastCookieSet = "";
function installCookieMock(initial = "") {
  cookieGetterValue = initial;
  lastCookieSet = "";
  Object.defineProperty(document, "cookie", {
    configurable: true,
    get() {
      return cookieGetterValue;
    },
    set(v: string) {
      lastCookieSet = v;
    },
  });
}

describe("cookie-cache utilities", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    // remove any existing cookieStore implementation
    // @ts-expect-error
    try {
      Object.defineProperty((global as any).window, "cookieStore", {
        configurable: true,
        value: undefined,
      });
    } catch {
      // ignore: some test environments expose readonly window properties
    }
    installCookieMock("");
    cookieCache.clearCookieCache();
  });

  it("parses cookies and returns values via getCookie/getAllCookies/hasCookie", () => {
    installCookieMock("a=1; b=two=2; empty=; encoded=%20");

    expect(cookieCache.getCookie("a")).toBe("1");
    expect(cookieCache.getCookie("b")).toBe("two=2");
    expect(cookieCache.getCookie("empty")).toBe("");
    expect(cookieCache.getCookie("missing")).toBeNull();

    const all = cookieCache.getAllCookies();
    expect(all).toMatchObject({ a: "1", b: "two=2", empty: "", encoded: "%20" });
    expect(cookieCache.hasCookie("a")).toBe(true);
    expect(cookieCache.hasCookie("missing")).toBe(false);
  });

  it("uses cookieStore.set when available and updates cache", () => {
    const mockSet = vi.fn().mockResolvedValue(undefined);
    // @ts-expect-error
    try {
      Object.defineProperty(window, "cookieStore", { configurable: true, value: { set: mockSet } });
    } catch {
      // ignore: fallback if defineProperty isn't allowed in this environment
    }

    cookieCache.setCookie("x", "y", { maxAge: 5, path: "/p", sameSite: "Strict" });

    // cookieStore.set called with correct shape
    expect(mockSet).toHaveBeenCalled();
    const arg = (mockSet as any).mock.calls[0][0];
    expect(arg.name).toBe("x");
    expect(arg.value).toBe("y");
    expect(arg.path).toBe("/p");
    expect(arg.sameSite).toBe("strict");

    // Cache should reflect new value immediately
    expect(cookieCache.getCookie("x")).toBe("y");
  });

  it("falls back to document.cookie when cookieStore.set rejects and encodes attributes", async () => {
    const mockSet = vi.fn().mockRejectedValue(new Error("nope"));
    // @ts-expect-error
    try {
      Object.defineProperty(window, "cookieStore", { configurable: true, value: { set: mockSet } });
    } catch {
      // ignore: fallback if defineProperty isn't allowed in this environment
    }

    installCookieMock("");

    const expires = new Date(Date.UTC(2030, 0, 1, 0, 0, 0));
    cookieCache.setCookie("z name", "v;val", {
      expires,
      path: "/q",
      sameSite: "None",
      secure: true,
    });

    // cookieStore.set attempted and rejected
    expect(mockSet).toHaveBeenCalled();

    // Wait a tick for the cookieStore.catch fallback to run
    await new Promise((r) => setTimeout(r, 0));

    // Fallback wrote to document.cookie (string should include encoded name/value and attributes)
    expect(lastCookieSet).toContain(`${encodeURIComponent("z name")}=`);
    expect(lastCookieSet).toContain("path=/q");
    expect(lastCookieSet).toContain("SameSite=None");

    // Cache updated regardless
    expect(cookieCache.getCookie("z name")).toBe("v;val");
  });

  it("removes cookie via cookieStore.delete and updates cache", () => {
    const mockDelete = vi.fn().mockResolvedValue(undefined);
    // @ts-expect-error
    try {
      Object.defineProperty(window, "cookieStore", {
        configurable: true,
        value: { delete: mockDelete },
      });
    } catch {
      // ignore: fallback if defineProperty isn't allowed in this environment
    }

    // Prime the cache
    cookieCache.setCookie("todelete", "1");
    expect(cookieCache.getCookie("todelete")).toBe("1");

    cookieCache.removeCookie("todelete", { path: "/" });
    expect(mockDelete).toHaveBeenCalledWith({ name: "todelete", path: "/" });
    expect(cookieCache.getCookie("todelete")).toBeNull();
  });

  it("falls back to document.cookie when delete rejects and expires cookie", async () => {
    const mockDelete = vi.fn().mockRejectedValue(new Error("nope"));
    // @ts-expect-error
    try {
      Object.defineProperty(window, "cookieStore", {
        configurable: true,
        value: { delete: mockDelete },
      });
    } catch {
      // ignore: fallback if defineProperty isn't allowed in this environment
    }

    // Prime the cache
    cookieCache.setCookie("old", "v");
    expect(cookieCache.getCookie("old")).toBe("v");

    cookieCache.removeCookie("old", { path: "/p" });

    // Wait a tick for the cookieStore.catch fallback to run
    await new Promise((r) => setTimeout(r, 0));

    // Fallback wrote a cookie string expiring the cookie (max-age or expires present)
    expect(lastCookieSet).toContain("max-age=-1");
    expect(lastCookieSet).toContain("path=/p");
    expect(cookieCache.getCookie("old")).toBeNull();
  });

  it("clearCookieCache invalidates cache", () => {
    installCookieMock("A=1");
    expect(cookieCache.getCookie("A")).toBe("1");

    // Simulate external change: document.cookie now different
    installCookieMock("A=2");

    // Cache still holds old value until invalidated
    expect(cookieCache.getCookie("A")).toBe("1");

    // Manually clear cache
    cookieCache.clearCookieCache();
    expect(cookieCache.getCookie("A")).toBe("2");
  });

  it("visibilitychange invalidates cache when page becomes visible", () => {
    // Start fresh for this test
    installCookieMock("B=1");
    expect(cookieCache.getCookie("B")).toBe("1");

    // change underlying cookie and simulate visibility change
    installCookieMock("B=9");
    Object.defineProperty(document, "visibilityState", {
      configurable: true,
      get: () => "visible",
    });
    document.dispatchEvent(new Event("visibilitychange"));

    // After visibilitychange the cache should have been cleared and reflect new value
    expect(cookieCache.getCookie("B")).toBe("9");
  });

  it("setCookie falls back to document.cookie when cookieStore is absent", () => {
    // Ensure no cookieStore present
    // @ts-expect-error
    try {
      Object.defineProperty(window, "cookieStore", { configurable: true, value: undefined });
    } catch {
      // ignore: fallback if defineProperty isn't allowed in this environment
    }
    installCookieMock("");

    cookieCache.setCookie("noapi", "val", {
      maxAge: 10,
      path: "/x",
      secure: true,
      sameSite: "Lax",
    });

    // Fallback should synchronously write to document.cookie
    expect(lastCookieSet).toContain("max-age=10");
    expect(lastCookieSet).toContain("path=/x");
    expect(cookieCache.getCookie("noapi")).toBe("val");
  });

  it("removeCookie falls back to document.cookie when cookieStore is absent", () => {
    // Ensure no cookieStore present
    // @ts-expect-error
    try {
      Object.defineProperty(window, "cookieStore", { configurable: true, value: undefined });
    } catch {
      // ignore: fallback if defineProperty isn't allowed in this environment
    }

    // prime cache
    installCookieMock("");
    cookieCache.setCookie("noapi-delete", "v");
    expect(cookieCache.getCookie("noapi-delete")).toBe("v");

    cookieCache.removeCookie("noapi-delete", { path: "/del" });
    expect(lastCookieSet).toContain("max-age=-1");
    expect(lastCookieSet).toContain("path=/del");
    expect(cookieCache.getCookie("noapi-delete")).toBeNull();
  });

  it("parseCookies handles errors gracefully", () => {
    // Make document.cookie getter throw
    Object.defineProperty(document, "cookie", {
      configurable: true,
      get() {
        throw new Error("boom");
      },
    });

    cookieCache.clearCookieCache();
    expect(cookieCache.getCookie("anything")).toBeNull();
  });

  it("setCookie returns early when window is undefined", () => {
    // Temporarily remove window
    // @ts-expect-error
    const orig = global.window;
    // @ts-expect-error
    global.window = undefined as any;

    expect(() => cookieCache.setCookie("a", "b")).not.toThrow();

    // Restore window
    // @ts-expect-error
    global.window = orig;
  });

  it("setCookie catches synchronous cookieStore access errors and falls back", () => {
    // cookieStore accessor throws when accessed
    Object.defineProperty(window, "cookieStore", {
      configurable: true,
      get() {
        throw new Error("access error");
      },
    });

    installCookieMock("");
    cookieCache.setCookie("syncthrow", "v", { path: "/throw" });

    // Fallback should write to document.cookie
    expect(lastCookieSet).toContain("path=/throw");
    expect(cookieCache.getCookie("syncthrow")).toBe("v");
  });

  it("removeCookie catches synchronous cookieStore access errors and falls back", () => {
    Object.defineProperty(window, "cookieStore", {
      configurable: true,
      get() {
        throw new Error("access error");
      },
    });

    installCookieMock("");
    cookieCache.setCookie("syncdel", "v");
    cookieCache.removeCookie("syncdel", { path: "/pd" });

    expect(lastCookieSet).toContain("path=/pd");
    expect(cookieCache.getCookie("syncdel")).toBeNull();
  });

  it("parseCookies returns empty when document is undefined", () => {
    // Temporarily remove document
    // @ts-expect-error
    const origDoc = global.document;
    // @ts-expect-error
    global.document = undefined as any;

    cookieCache.clearCookieCache();
    expect(cookieCache.getCookie("no-doc")).toBeNull();

    // Restore document
    // @ts-expect-error
    global.document = origDoc;
  });

  it("getAllCookies populates cache when empty", () => {
    cookieCache.clearCookieCache();
    installCookieMock("k=1");
    const all = cookieCache.getAllCookies();
    expect(all.k).toBe("1");
  });

  it("setCookie fallback with missing document returns early from setViaDom but still updates cache", () => {
    // ensure no cookieStore
    // @ts-expect-error
    try {
      Object.defineProperty(window, "cookieStore", { configurable: true, value: undefined });
    } catch {
      // ignore: fallback if defineProperty isn't allowed in this environment
    }

    // remove document so setViaDom early returns
    // @ts-expect-error
    const origDoc2 = global.document;
    // @ts-expect-error
    global.document = undefined as any;

    // ensure lastCookieSet is empty and don't call installCookieMock (document missing)
    // @ts-expect-error
    lastCookieSet = "";
    cookieCache.clearCookieCache();

    cookieCache.setCookie("nodoc", "val", { maxAge: 5, path: "/x" });

    // setViaDom didn't write to document.cookie because document was undefined
    expect(lastCookieSet).toBe("");
    // cache still updated
    expect(cookieCache.getCookie("nodoc")).toBe("val");

    // restore document
    // @ts-expect-error
    global.document = origDoc2;
  });
});
//End of file
