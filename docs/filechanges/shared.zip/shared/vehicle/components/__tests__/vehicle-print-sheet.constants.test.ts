import type { CSSProperties } from "react";
import { describe, expect, it } from "vitest";
import {
  badgeStyle,
  sectionStyle,
  sectionTitleStyle,
  specLabelStyle,
  specValueStyle,
} from "../vehicle-print-sheet.constants";

// Top-level regex constants to avoid performance warnings
const MARGIN_24PX_REGEX = /24px/;
const PADDING_14PX_REGEX = /14px/;
const HEX_COLOR_REGEX = /#[0-9a-f]{6}/i;
const BORDER_1PX_REGEX = /1px/;
const BORDER_SOLID_REGEX = /solid/;
const PIXEL_AND_PERCENT_REGEX = /\d+px/;

describe("VehiclePrintSheet Constants", () => {
  describe("Export verification", () => {
    it("exports badgeStyle constant", () => {
      expect(badgeStyle).toBeDefined();
      expect(typeof badgeStyle).toBe("object");
    });

    it("exports sectionStyle constant", () => {
      expect(sectionStyle).toBeDefined();
      expect(typeof sectionStyle).toBe("object");
    });

    it("exports sectionTitleStyle constant", () => {
      expect(sectionTitleStyle).toBeDefined();
      expect(typeof sectionTitleStyle).toBe("object");
    });

    it("exports specLabelStyle constant", () => {
      expect(specLabelStyle).toBeDefined();
      expect(typeof specLabelStyle).toBe("object");
    });

    it("exports specValueStyle constant", () => {
      expect(specValueStyle).toBeDefined();
      expect(typeof specValueStyle).toBe("object");
    });
  });

  describe("badgeStyle", () => {
    it("has padding property set to 4px 14px", () => {
      expect(badgeStyle.padding).toBe("4px 14px");
    });

    it("has rounded border radius of 20", () => {
      expect(badgeStyle.borderRadius).toBe(20);
    });

    it("has font size of 13", () => {
      expect(badgeStyle.fontSize).toBe(13);
    });

    it("has bold font weight of 600", () => {
      expect(badgeStyle.fontWeight).toBe(600);
    });

    it("has light gray border", () => {
      expect(badgeStyle.border).toBe("1px solid #d1d5db");
    });

    it("contains exactly 5 style properties", () => {
      const props = Object.keys(badgeStyle);
      expect(props).toHaveLength(5);
      expect(props).toContain("padding");
      expect(props).toContain("borderRadius");
      expect(props).toContain("fontSize");
      expect(props).toContain("fontWeight");
      expect(props).toContain("border");
    });

    it("uses pill shape styling (borderRadius=20)", () => {
      // borderRadius of 20 creates pill-shaped badges
      expect(badgeStyle.borderRadius).toBeGreaterThan(10);
    });
  });

  describe("sectionStyle", () => {
    it("has vertical margin of 24px", () => {
      expect(sectionStyle.margin).toBe("24px 0");
    });

    it("contains exactly 1 style property", () => {
      const props = Object.keys(sectionStyle);
      expect(props).toHaveLength(1);
      expect(props).toContain("margin");
    });

    it("provides spacing between sections", () => {
      // margin creates vertical space around section
      expect(sectionStyle.margin).toMatch(MARGIN_24PX_REGEX);
    });
  });

  describe("sectionTitleStyle", () => {
    it("has large font size of 18", () => {
      expect(sectionTitleStyle.fontSize).toBe(18);
    });

    it("has bold font weight of 600", () => {
      expect(sectionTitleStyle.fontWeight).toBe(600);
    });

    it("has margin bottom of 12", () => {
      expect(sectionTitleStyle.marginBottom).toBe(12);
    });

    it("has padding bottom of 8", () => {
      expect(sectionTitleStyle.paddingBottom).toBe(8);
    });

    it("has light gray bottom border", () => {
      expect(sectionTitleStyle.borderBottom).toBe("1px solid #e5e7eb");
    });

    it("contains exactly 5 style properties", () => {
      const props = Object.keys(sectionTitleStyle);
      expect(props).toHaveLength(5);
      expect(props).toContain("fontSize");
      expect(props).toContain("fontWeight");
      expect(props).toContain("marginBottom");
      expect(props).toContain("paddingBottom");
      expect(props).toContain("borderBottom");
    });

    it("creates visual hierarchy with larger font than spec labels", () => {
      const titleFontSize = sectionTitleStyle.fontSize;
      const labelFontSize = specLabelStyle.fontSize;
      if (typeof titleFontSize === "number" && typeof labelFontSize === "number") {
        expect(titleFontSize).toBeGreaterThan(labelFontSize);
      }
    });

    it("uses underline styling with border", () => {
      expect(sectionTitleStyle.borderBottom).toBeDefined();
      expect(sectionTitleStyle.paddingBottom).toBeGreaterThan(0);
    });
  });

  describe("specLabelStyle", () => {
    it("has small font size of 12", () => {
      expect(specLabelStyle.fontSize).toBe(12);
    });

    it("has medium gray text color", () => {
      expect(specLabelStyle.color).toBe("#6b7280");
    });

    it("has bold font weight of 600", () => {
      expect(specLabelStyle.fontWeight).toBe(600);
    });

    it("has uppercase text transformation", () => {
      expect(specLabelStyle.textTransform).toBe("uppercase");
    });

    it("has no margin", () => {
      expect(specLabelStyle.margin).toBe(0);
    });

    it("contains exactly 5 style properties", () => {
      const props = Object.keys(specLabelStyle);
      expect(props).toHaveLength(5);
      expect(props).toContain("fontSize");
      expect(props).toContain("color");
      expect(props).toContain("fontWeight");
      expect(props).toContain("textTransform");
      expect(props).toContain("margin");
    });

    it("uses gray tone that is darker than badges", () => {
      // #6b7280 (labels) vs #d1d5db (badge border)
      // Labels should be darker for readability
      expect(specLabelStyle.color).not.toBe("#d1d5db");
    });

    it("applies uppercase styling for visual emphasis", () => {
      expect(specLabelStyle.textTransform).toBe("uppercase");
    });
  });

  describe("specValueStyle", () => {
    it("has medium font size of 15", () => {
      expect(specValueStyle.fontSize).toBe(15);
    });

    it("has bold font weight of 600", () => {
      expect(specValueStyle.fontWeight).toBe(600);
    });

    it("has small top margin of 2", () => {
      expect(specValueStyle.marginTop).toBe(2);
    });

    it("has no overall margin (margin: 0)", () => {
      expect(specValueStyle.margin).toBe(0);
    });

    it("contains exactly 4 style properties", () => {
      const props = Object.keys(specValueStyle);
      expect(props).toHaveLength(4);
      expect(props).toContain("fontSize");
      expect(props).toContain("fontWeight");
      expect(props).toContain("marginTop");
      expect(props).toContain("margin");
    });

    it("is larger than spec label for hierarchy", () => {
      const valueFontSize = specValueStyle.fontSize;
      const labelFontSize = specLabelStyle.fontSize;
      if (typeof valueFontSize === "number" && typeof labelFontSize === "number") {
        expect(valueFontSize).toBeGreaterThan(labelFontSize);
      }
    });

    it("has small spacing above it (marginTop: 2)", () => {
      expect(specValueStyle.marginTop).toBeGreaterThan(0);
      expect(specValueStyle.marginTop).toBeLessThan(5);
    });
  });

  describe("Typography hierarchy", () => {
    it("section title is largest", () => {
      const sizes: (string | number | undefined)[] = [
        sectionTitleStyle.fontSize,
        specValueStyle.fontSize,
        badgeStyle.fontSize,
        specLabelStyle.fontSize,
      ];
      const numericSizes = sizes.filter((s): s is number => typeof s === "number");
      const max = Math.max(...numericSizes);
      expect(sectionTitleStyle.fontSize).toBe(max);
    });

    it("spec value is larger than spec label", () => {
      const valueFontSize = specValueStyle.fontSize;
      const labelFontSize = specLabelStyle.fontSize;
      if (typeof valueFontSize === "number" && typeof labelFontSize === "number") {
        expect(valueFontSize).toBeGreaterThan(labelFontSize);
      }
    });

    it("badge text is smaller than spec value", () => {
      const badgeFontSize = badgeStyle.fontSize;
      const valueFontSize = specValueStyle.fontSize;
      if (typeof badgeFontSize === "number" && typeof valueFontSize === "number") {
        expect(badgeFontSize).toBeLessThan(valueFontSize);
      }
    });

    it("spec label is smallest", () => {
      const sizes: (string | number | undefined)[] = [
        sectionTitleStyle.fontSize,
        specValueStyle.fontSize,
        badgeStyle.fontSize,
        specLabelStyle.fontSize,
      ];
      const numericSizes = sizes.filter((s): s is number => typeof s === "number");
      const min = Math.min(...numericSizes);
      expect(specLabelStyle.fontSize).toBe(min);
    });
  });

  describe("Font weight consistency", () => {
    it("all text styles use bold weight (600)", () => {
      expect(badgeStyle.fontWeight).toBe(600);
      expect(sectionTitleStyle.fontWeight).toBe(600);
      expect(specLabelStyle.fontWeight).toBe(600);
      expect(specValueStyle.fontWeight).toBe(600);
    });

    it("sectionStyle has no font weight (uses default)", () => {
      expect(sectionStyle.fontWeight).toBeUndefined();
    });
  });

  describe("Color usage", () => {
    it("badge uses light gray border", () => {
      expect(badgeStyle.border).toContain("#d1d5db");
    });

    it("section title uses light gray border", () => {
      expect(sectionTitleStyle.borderBottom).toContain("#e5e7eb");
    });

    it("spec label uses medium gray text", () => {
      expect(specLabelStyle.color).toBe("#6b7280");
    });

    it("spec value has no text color (uses default)", () => {
      expect(specValueStyle.color).toBeUndefined();
    });

    it("border colors are consistent gray tones", () => {
      // All grays from Tailwind palette
      const borderColors = [badgeStyle.border, sectionTitleStyle.borderBottom];
      for (const border of borderColors) {
        expect(border).toMatch(HEX_COLOR_REGEX);
      }
    });
  });

  describe("Spacing consistency", () => {
    it("badge has symmetric horizontal padding (14px each side)", () => {
      expect(badgeStyle.padding).toMatch(PADDING_14PX_REGEX);
    });

    it("section has vertical margin of 24px", () => {
      expect(sectionStyle.margin).toMatch(MARGIN_24PX_REGEX);
    });

    it("section title has padding and margin for spacing", () => {
      expect(sectionTitleStyle.marginBottom).toBeGreaterThan(0);
      expect(sectionTitleStyle.paddingBottom).toBeGreaterThan(0);
    });

    it("spec value has minimal top margin (2px)", () => {
      expect(specValueStyle.marginTop).toBe(2);
    });
  });

  describe("Border styling", () => {
    it("badge has 1px border", () => {
      expect(badgeStyle.border).toMatch(BORDER_1PX_REGEX);
    });

    it("section title has 1px bottom border", () => {
      expect(sectionTitleStyle.borderBottom).toMatch(BORDER_1PX_REGEX);
    });

    it("badge border is solid style", () => {
      expect(badgeStyle.border).toMatch(BORDER_SOLID_REGEX);
    });

    it("section title border is solid style", () => {
      expect(sectionTitleStyle.borderBottom).toMatch(BORDER_SOLID_REGEX);
    });
  });

  describe("Type safety", () => {
    it("badgeStyle matches CSSProperties type", () => {
      const typeCheck: CSSProperties = badgeStyle;
      expect(typeCheck).toBeDefined();
    });

    it("sectionStyle matches CSSProperties type", () => {
      const typeCheck: CSSProperties = sectionStyle;
      expect(typeCheck).toBeDefined();
    });

    it("sectionTitleStyle matches CSSProperties type", () => {
      const typeCheck: CSSProperties = sectionTitleStyle;
      expect(typeCheck).toBeDefined();
    });

    it("specLabelStyle matches CSSProperties type", () => {
      const typeCheck: CSSProperties = specLabelStyle;
      expect(typeCheck).toBeDefined();
    });

    it("specValueStyle matches CSSProperties type", () => {
      const typeCheck: CSSProperties = specValueStyle;
      expect(typeCheck).toBeDefined();
    });
  });

  describe("Practical usage scenarios", () => {
    it("badge style creates pill-shaped design elements", () => {
      // borderRadius creates rounded corners
      expect(badgeStyle.borderRadius).toBeGreaterThanOrEqual(20);
      // padding creates clickable area
      expect(badgeStyle.padding).toContain("px");
    });

    it("section style creates visual separation", () => {
      // Margin creates space between sections
      expect(sectionStyle.margin).toMatch(PIXEL_AND_PERCENT_REGEX);
    });

    it("section title style creates clear section headers", () => {
      // Font size and weight create visual hierarchy
      expect(sectionTitleStyle.fontSize).toBeGreaterThan(16);
      expect(sectionTitleStyle.fontWeight).toBeGreaterThan(500);
      // Border creates underline effect
      expect(sectionTitleStyle.borderBottom).toBeDefined();
    });

    it("spec label style creates readable field labels", () => {
      // Uppercase + color + small size = clear labels
      expect(specLabelStyle.textTransform).toBe("uppercase");
      expect(specLabelStyle.fontSize).toBeLessThan(14);
      expect(specLabelStyle.color).toBeDefined();
    });

    it("spec value style creates readable field values", () => {
      // Larger than label, bold, with minimal top margin
      const valueFontSize = specValueStyle.fontSize;
      const labelFontSize = specLabelStyle.fontSize;
      if (typeof valueFontSize === "number" && typeof labelFontSize === "number") {
        expect(valueFontSize).toBeGreaterThan(labelFontSize);
      }
      expect(specValueStyle.fontWeight).toBeGreaterThan(500);
      expect(specValueStyle.marginTop).toBeDefined();
    });
  });

  describe("Print-friendly considerations", () => {
    it("uses inline styles (appropriate for print window)", () => {
      // All constants are CSSProperties objects
      const styles = [badgeStyle, sectionStyle, sectionTitleStyle, specLabelStyle, specValueStyle];
      for (const style of styles) {
        expect(typeof style).toBe("object");
        expect(style).not.toBeNull();
      }
    });

    it("uses precise pixel values for consistent printing", () => {
      // Uses px units which are printer-friendly
      expect(badgeStyle.padding).toContain("px");
      expect(sectionStyle.margin).toContain("px");
      expect(sectionTitleStyle.fontSize).toBeGreaterThan(0);
    });

    it("uses web-safe colors for cross-platform printing", () => {
      // All colors are hex codes
      const colors = [badgeStyle.border, sectionTitleStyle.borderBottom, specLabelStyle.color];
      for (const color of colors) {
        if (color && typeof color === "string") {
          expect(color).toMatch(HEX_COLOR_REGEX);
        }
      }
    });
  });

  describe("Constants immutability", () => {
    it("all constants are objects that can be used with spread operator", () => {
      const badgeSpread = { ...badgeStyle };
      expect(badgeSpread).toEqual(badgeStyle);
    });

    it("constants reference same style object on multiple accesses", () => {
      const first = badgeStyle;
      const second = badgeStyle;
      // Same reference (not just equal values)
      expect(first).toBe(second);
    });
  });

  describe("Responsive design considerations", () => {
    it("uses absolute px values (no responsive units)", () => {
      // Constants don't use %, em, or rem - they're fixed sizes
      const allStyles = [
        badgeStyle,
        sectionStyle,
        sectionTitleStyle,
        specLabelStyle,
        specValueStyle,
      ];
      for (const style of allStyles) {
        const styleValues = Object.values(style);
        for (const value of styleValues) {
          if (typeof value === "string" && value.includes("px")) {
            expect(value).not.toContain("%");
            expect(value).not.toContain("em");
            expect(value).not.toContain("rem");
          }
        }
      }
    });

    it("badge size remains consistent for print", () => {
      // No responsive sizing needed for print
      expect(badgeStyle.padding).toBe("4px 14px");
      expect(badgeStyle.fontSize).toBe(13);
    });
  });

  describe("Performance characteristics", () => {
    it("constants are defined once and reused", () => {
      // No function calls or dynamic computations
      expect(typeof badgeStyle).not.toBe("function");
      expect(typeof sectionStyle).not.toBe("function");
    });

    it("each constant contains minimal properties", () => {
      const allStyles = [
        badgeStyle,
        sectionStyle,
        sectionTitleStyle,
        specLabelStyle,
        specValueStyle,
      ];
      for (const style of allStyles) {
        expect(Object.keys(style).length).toBeLessThanOrEqual(5);
      }
    });
  });
});
