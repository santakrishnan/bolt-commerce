import { describe, expect, it } from "vitest";
import { formatMileage, formatPrice } from "../formatters";

// Top-level regex constants
const USD_PREFIX_REGEX = /^\$/;
const FORMATTED_PRICE_REGEX = /^\$[\d,]+$/;
const MILEAGE_SUFFIX_REGEX = / mi$/;

describe("Vehicle Formatters", () => {
  describe("formatPrice", () => {
    it("formats basic positive price correctly", () => {
      expect(formatPrice(100)).toBe("$100");
    });

    it("formats price with thousands separator", () => {
      expect(formatPrice(1000)).toBe("$1,000");
    });

    it("formats large price with multiple separators", () => {
      expect(formatPrice(1_234_567)).toBe("$1,234,567");
    });

    it("formats zero price as $0", () => {
      expect(formatPrice(0)).toBe("$0");
    });

    it("formats small decimal value (rounds down)", () => {
      expect(formatPrice(99.99)).toBe("$100");
    });

    it("formats price with 0.1 decimal (no rounding needed)", () => {
      expect(formatPrice(100.1)).toBe("$100");
    });

    it("formats price with 0.5 decimal (rounds to nearest)", () => {
      expect(formatPrice(100.5)).toBe("$101");
    });

    it("formats very large price", () => {
      expect(formatPrice(999_999_999)).toBe("$999,999,999");
    });

    it("formats very small fractional price", () => {
      expect(formatPrice(0.1)).toBe("$0");
    });

    it("formats fractional price that rounds up", () => {
      expect(formatPrice(0.9)).toBe("$1");
    });

    it("handles common vehicle price ranges", () => {
      expect(formatPrice(24_999)).toBe("$24,999");
      expect(formatPrice(28_500)).toBe("$28,500");
      expect(formatPrice(32_000)).toBe("$32,000");
    });

    it("uses USD currency symbol", () => {
      const result = formatPrice(1000);
      expect(result).toMatch(USD_PREFIX_REGEX);
    });

    it("removes decimal places (maximumFractionDigits: 0)", () => {
      expect(formatPrice(1234.56)).toBe("$1,235");
      expect(formatPrice(1234.49)).toBe("$1,234");
    });

    it("formats luxury vehicle price", () => {
      expect(formatPrice(299_999_999)).toBe("$299,999,999");
    });

    it("formats minimum price tier", () => {
      expect(formatPrice(1)).toBe("$1");
    });
  });

  describe("formatMileage", () => {
    it("formats basic mileage with commas and 'mi' suffix", () => {
      expect(formatMileage("100")).toBe("100 mi");
    });

    it("formats mileage with thousands separator", () => {
      expect(formatMileage("10000")).toBe("10,000 mi");
    });

    it("formats large mileage value", () => {
      expect(formatMileage("150000")).toBe("150,000 mi");
    });

    it("formats mileage with existing commas", () => {
      expect(formatMileage("50,000")).toBe("50,000 mi");
    });

    it("returns original value when input is non-numeric", () => {
      expect(formatMileage("N/A")).toBe("N/A");
    });

    it("returns original value when input is empty string", () => {
      expect(formatMileage("")).toBe("");
    });

    it("handles mileage with 'mi' suffix in input", () => {
      expect(formatMileage("25000 mi")).toBe("25,000 mi");
    });

    it("handles mileage with spaces", () => {
      expect(formatMileage("25 000")).toBe("25,000 mi");
    });

    it("extracts numeric value from mixed input", () => {
      expect(formatMileage("approximately 45000 miles")).toBe("45,000 mi");
    });

    it("handles zero mileage", () => {
      expect(formatMileage("0")).toBe("0 mi");
    });

    it("handles very large mileage", () => {
      expect(formatMileage("999999")).toBe("999,999 mi");
    });

    it("returns original for fully non-numeric input", () => {
      expect(formatMileage("unknown")).toBe("unknown");
    });

    it("formats decimal mileage preserving decimal in output", () => {
      expect(formatMileage("45000.5")).toBe("45,000.5 mi");
    });

    it("handles mileage with leading zeros", () => {
      expect(formatMileage("00100")).toBe("100 mi");
    });

    it("handles common mileage patterns", () => {
      expect(formatMileage("32000")).toBe("32,000 mi");
      expect(formatMileage("45,000")).toBe("45,000 mi");
      expect(formatMileage("12345")).toBe("12,345 mi");
    });

    it("returns original for dashes only", () => {
      expect(formatMileage("—")).toBe("—");
    });

    it("extracts number from string with special characters", () => {
      expect(formatMileage("$45000!")).toBe("45,000 mi");
    });

    it("handles very small mileage", () => {
      expect(formatMileage("1")).toBe("1 mi");
    });

    it("handles mileage with multiple non-numeric segments", () => {
      expect(formatMileage("approx 50000 k km")).toBe("50,000 mi");
    });

    it("formats mileage with parentheses", () => {
      expect(formatMileage("(50000)")).toBe("50,000 mi");
    });

    it("handles trailing spaces", () => {
      expect(formatMileage("30000  ")).toBe("30,000 mi");
    });

    it("preserves non-numeric input unchanged", () => {
      const input = "Contact dealer for mileage";
      expect(formatMileage(input)).toBe(input);
    });
  });

  describe("Edge cases and integration", () => {
    it("price formatter handles JavaScript number precision edge cases", () => {
      expect(formatPrice(0.1 + 0.2)).toBe("$0");
    });

    it("mileage formatter handles common vehicle mileage ranges", () => {
      expect(formatMileage("32000")).toBe("32,000 mi");
      expect(formatMileage("150000")).toBe("150,000 mi");
      expect(formatMileage("250000")).toBe("250,000 mi");
    });

    it("mileage handles mixed quotes and characters", () => {
      expect(formatMileage('50,000"')).toBe("50,000 mi");
    });

    it("price formats currency consistently", () => {
      const prices = [100, 1000, 10_000, 100_000];
      for (const price of prices) {
        const formatted = formatPrice(price);
        expect(formatted).toMatch(FORMATTED_PRICE_REGEX);
      }
    });

    it("mileage always appends ' mi' suffix for valid numbers", () => {
      const validInputs = ["100", "1000", "50,000", "123456"];
      for (const input of validInputs) {
        const result = formatMileage(input);
        expect(result).toMatch(MILEAGE_SUFFIX_REGEX);
      }
    });

    it("mileage preserves original for invalid input", () => {
      const invalidInputs = ["N/A", "Unknown", "—", ""];
      for (const input of invalidInputs) {
        expect(formatMileage(input)).toBe(input);
      }
    });

    it("formatters are pure functions (same input produces same output)", () => {
      expect(formatPrice(5000)).toBe(formatPrice(5000));
      expect(formatMileage("45000")).toBe(formatMileage("45000"));
    });

    it("price formatter with negative number (edge case)", () => {
      const result = formatPrice(-100);
      expect(result).toContain("100");
    });

    it("mileage with only decimal point", () => {
      expect(formatMileage(".")).toBe(".");
    });

    it("mileage with scientific notation string (extracts only digits)", () => {
      // Regex /[^0-9.]/g removes 'e', so '1e5' becomes '15'
      expect(formatMileage("1e5")).toBe("15 mi");
    });

    it("handles typical dealer inventory scenarios", () => {
      // Used car with moderate mileage
      expect(formatMileage("47500")).toBe("47,500 mi");

      // New car scenario
      expect(formatMileage("12")).toBe("12 mi");

      // High-mileage vehicle
      expect(formatMileage("187500")).toBe("187,500 mi");

      // CPO vehicle
      expect(formatPrice(24_500)).toBe("$24,500");
    });
  });

  describe("Internationalization concerns", () => {
    it("price always uses USD formatting (en-US locale)", () => {
      const result = formatPrice(1234.56);
      // Should use comma as thousands separator (en-US), not period
      expect(result).toContain(",");
      expect(result).toContain("$");
    });

    it("number formatter uses en-US locale", () => {
      const result = formatMileage("1234567");
      // Should use comma separator for en-US
      expect(result).toContain(",");
    });
  });

  describe("Boundary conditions", () => {
    it("formatPrice with maximum safe integer", () => {
      const maxSafeInt = Number.MAX_SAFE_INTEGER;
      const result = formatPrice(maxSafeInt);
      expect(result).toMatch(FORMATTED_PRICE_REGEX);
    });

    it("formatMileage with maximum safe integer string", () => {
      const result = formatMileage("9007199254740991");
      expect(result).toMatch(MILEAGE_SUFFIX_REGEX);
    });

    it("formatMileage handles Infinity string", () => {
      expect(formatMileage("Infinity")).toBe("Infinity");
    });

    it("formatPrice with minimum positive value", () => {
      const result = formatPrice(Number.MIN_VALUE);
      expect(result).toMatch(USD_PREFIX_REGEX);
    });

    it("formatMileage with very long numeric string", () => {
      const longNumber = "12345678901234567890";
      const result = formatMileage(longNumber);
      expect(result).toMatch(MILEAGE_SUFFIX_REGEX);
    });
  });

  describe("Real-world scenarios", () => {
    it("formats dealer inventory prices correctly", () => {
      const prices = [
        { input: 28_500, expected: "$28,500" },
        { input: 24_999, expected: "$24,999" },
        { input: 32_000, expected: "$32,000" },
      ];
      for (const { input, expected } of prices) {
        expect(formatPrice(input)).toBe(expected);
      }
    });

    it("formats vehicle mileage for display", () => {
      const mileages = [
        { input: "32000", expected: "32,000 mi" },
        { input: "45,000", expected: "45,000 mi" },
        { input: "150000", expected: "150,000 mi" },
      ];
      for (const { input, expected } of mileages) {
        expect(formatMileage(input)).toBe(expected);
      }
    });

    it("handles missing mileage data gracefully", () => {
      expect(formatMileage("N/A")).toBe("N/A");
      expect(formatMileage("—")).toBe("—");
      expect(formatMileage("")).toBe("");
    });

    it("handles prices with fractional cents (rounds appropriately)", () => {
      expect(formatPrice(99.99)).toBe("$100");
      expect(formatPrice(100.49)).toBe("$100");
      expect(formatPrice(100.5)).toBe("$101");
    });
  });
});
