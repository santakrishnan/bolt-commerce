import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

// Mock next/image to a simple img so tests can inspect src
vi.mock("next/image", () => ({
  default: (props: any) => {
    return <span data-testid="next-image" role="img" {...props} />;
  },
}));

// Mock the shared Badge primitive so shadcn delegation can be asserted
vi.mock("@tfs-ucmp/ui", () => ({
  Badge: ({ children, ...props }: any) => (
    <div data-testid="shared-badge" {...props}>
      {children}
    </div>
  ),
}));

import CustomBadge from "../custom-badge";

describe("CustomBadge", () => {
  it("renders custom variant with iconSrc and text", () => {
    render(<CustomBadge iconSrc="custom.svg" text="Price" type="excellentPrice" />);
    const img = screen.getByTestId("next-image");
    expect(img).toHaveAttribute("src", "/images/badges/custom.svg");
    expect(screen.getByText("Price")).toBeInTheDocument();
  });

  it("suppresses the icon when icon is explicitly null", () => {
    render(<CustomBadge icon={null} text="NoIcon" type="excellentPrice" />);
    expect(screen.queryByTestId("next-image")).toBeNull();
    expect(screen.getByText("NoIcon")).toBeInTheDocument();
  });

  it("renders a lucide-style icon when a function component is passed", () => {
    const FakeIcon = (props: any) => <svg data-testid="lucide" {...props} />;
    render(<CustomBadge icon={FakeIcon as any} text="WithIcon" type="excellentPrice" />);
    expect(screen.getByTestId("lucide")).toBeInTheDocument();
    expect(screen.getByText("WithIcon")).toBeInTheDocument();
  });

  it("renders an arbitrary ReactNode as icon override", () => {
    render(
      <CustomBadge
        icon={<span data-testid="node-icon">I</span>}
        text="Node"
        type="excellentPrice"
      />
    );
    expect(screen.getByTestId("node-icon")).toBeInTheDocument();
    expect(screen.getByText("Node")).toBeInTheDocument();
  });

  it("renders masked default icon for matchingPercentage and shows label", () => {
    const { container } = render(<CustomBadge matchPercentage={87} type="matchingPercentage" />);
    expect(screen.getByText("87% Match")).toBeInTheDocument();

    // Masked icon renders a span with aria-hidden; verify it references the default SVG path
    const masked = container.querySelector('span[aria-hidden="true"]');
    expect(masked).toBeTruthy();
    const style = (masked as HTMLElement).style;
    const maskImage =
      style.maskImage || (style as any).webkitMaskImage || (style as any).WebkitMaskImage || "";
    expect(maskImage).toContain("/images/badges/low_price.svg");
  });

  it("renders custom variant with no default icon (preQualifies) and shows text without icon", () => {
    const { container } = render(<CustomBadge text="PreQual" type="preQualifies" />);
    expect(screen.getByText("PreQual")).toBeInTheDocument();
    // no next/image was rendered
    expect(screen.queryByTestId("next-image")).toBeNull();
    // no masked default icon should be present
    const masked = container.querySelector('span[aria-hidden="true"]');
    expect(masked).toBeNull();
  });

  it("pluralizes owner and expires labels correctly", () => {
    render(<CustomBadge ownerCount={1} type="owner" />);
    expect(screen.getByText("1 Owner")).toBeInTheDocument();
    render(<CustomBadge ownerCount={2} type="owner" />);
    expect(screen.getByText("2 Owners")).toBeInTheDocument();

    render(<CustomBadge expiresInDays={1} type="ExpiresAt" />);
    expect(screen.getByText("Expires in 1 day")).toBeInTheDocument();
    render(<CustomBadge expiresInDays={3} type="ExpiresAt" />);
    expect(screen.getByText("Expires in 3 days")).toBeInTheDocument();
  });

  it("respects iconPosition ordering (right vs left)", () => {
    const { container } = render(
      <CustomBadge
        icon={<span data-testid="node">I</span>}
        iconPosition="right"
        text="Label"
        type="excellentPrice"
      />
    );
    const span = container.querySelector("span");
    const content = span?.textContent ?? "";
    expect(content.indexOf("Label")).toBeLessThan(content.indexOf("I"));

    const { container: c2 } = render(
      <CustomBadge
        icon={<span data-testid="node2">J</span>}
        iconPosition="left"
        text="Label2"
        type="excellentPrice"
      />
    );
    const span2 = c2.querySelector("span");
    const content2 = span2?.textContent ?? "";
    expect(content2.indexOf("J")).toBeLessThan(content2.indexOf("Label2"));
  });

  it("delegates to the shared Badge for shadcn variants", () => {
    render(<CustomBadge text="Shared" type="default" />);
    expect(screen.getByTestId("shared-badge")).toBeInTheDocument();
    expect(screen.getByText("Shared")).toBeInTheDocument();
  });
});
