/**
 * @vitest-environment jsdom
 */

import { act, cleanup, fireEvent, render, screen, waitFor } from "@arrow/vitest-config/test-utils";
import * as matchers from "@testing-library/jest-dom/matchers";
import Image from "next/image";
import type React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

expect.extend(matchers);
afterEach(cleanup);

// ─── Mocks ────────────────────────────────────────────────────────────────────

vi.mock("next/image", async () => {
  const actual = await vi.importActual("next/image");
  return { __esModule: true, default: (actual as { default: unknown }).default };
});

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({
    children,
    onClick,
    "aria-label": ariaLabel,
    type,
  }: {
    children?: React.ReactNode;
    onClick?: (e: React.MouseEvent) => void;
    "aria-label"?: string;
    type?: "button" | "submit" | "reset";
  }) => (
    <button aria-label={ariaLabel} onClick={onClick} type={type ?? "button"}>
      {children}
    </button>
  ),
}));

let vehiclePrintSheetRenderer: (props: { vehicle: unknown }) => React.ReactElement | null = () =>
  null;

vi.mock("@shared/vehicle/components/vehicle-print-sheet", () => ({
  __esModule: true,
  VehiclePrintSheet: (props: { vehicle: unknown }) => vehiclePrintSheetRenderer(props),
}));

import { PrintButton } from "../print-button";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getPortal(): HTMLElement | null {
  return document.querySelector("[data-print-portal]");
}

/** Flush pending React state updates and effects. */
async function flushEffects() {
  await act(async () => {
    await Promise.resolve();
  });
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe("PrintButton", () => {
  beforeEach(() => {
    vi.stubGlobal("print", vi.fn());
    vehiclePrintSheetRenderer = () => null;
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    vi.useRealTimers();
  });

  // ── Rendering ──────────────────────────────────────────────────────────────

  it("renders a button with default aria-label", () => {
    render(<PrintButton />);
    expect(screen.getByRole("button", { name: "Print" })).toBeInTheDocument();
  });

  it("renders a button with a custom aria-label", () => {
    render(<PrintButton ariaLabel="Print details" />);
    expect(screen.getByRole("button", { name: "Print details" })).toBeInTheDocument();
  });

  it("renders the print icon image inside the button", () => {
    render(<PrintButton />);
    const img = screen.getByRole("img", { name: "Print" });
    expect(img).toBeInTheDocument();
    expect(img).toHaveAttribute("src", "/images/vdp/Vector_7.svg");
  });

  // ── Portal lifecycle ───────────────────────────────────────────────────────

  it("appends a print-portal div to body on mount", async () => {
    render(<PrintButton />);
    await flushEffects();
    expect(getPortal()).toBeInTheDocument();
  });

  it("removes the print-portal div from body on unmount", async () => {
    const { unmount } = render(<PrintButton />);
    await flushEffects();
    unmount();
    expect(getPortal()).not.toBeInTheDocument();
  });

  it("renders VehiclePrintSheet into portal when vehicle is provided", async () => {
    vehiclePrintSheetRenderer = () => <div data-testid="print-sheet" />;
    render(<PrintButton vehicle={{ title: "Test Car" }} />);
    await flushEffects();
    expect(screen.getByTestId("print-sheet")).toBeInTheDocument();
    expect(getPortal()?.contains(screen.getByTestId("print-sheet"))).toBe(true);
  });

  it("does not render VehiclePrintSheet without a vehicle prop", async () => {
    vehiclePrintSheetRenderer = () => <div data-testid="print-sheet" />;
    render(<PrintButton />);
    await flushEffects();
    expect(screen.queryByTestId("print-sheet")).not.toBeInTheDocument();
  });

  // ── Click behaviour without vehicle ───────────────────────────────────────

  it("calls window.print() directly when no vehicle is provided", () => {
    render(<PrintButton />);
    fireEvent.click(screen.getByRole("button", { name: "Print" }));
    expect(window.print).toHaveBeenCalledTimes(1);
  });

  it("stops event propagation on click", () => {
    render(<PrintButton />);
    const btn = screen.getByRole("button", { name: "Print" });

    // Dispatch a native click event and spy on its stopPropagation method.
    // React's SyntheticEvent.stopPropagation() delegates to nativeEvent.stopPropagation(),
    // so the spy confirms the call.
    const clickEvent = new MouseEvent("click", { bubbles: true, cancelable: true });
    vi.spyOn(clickEvent, "stopPropagation");

    btn.dispatchEvent(clickEvent);

    expect(clickEvent.stopPropagation).toHaveBeenCalled();
  });

  it("calls onClick prop when clicked", () => {
    const handleClick = vi.fn();
    render(<PrintButton onClick={handleClick} />);
    fireEvent.click(screen.getByRole("button", { name: "Print" }));
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it("does not throw when onClick prop is not provided", () => {
    render(<PrintButton />);
    expect(() => fireEvent.click(screen.getByRole("button", { name: "Print" }))).not.toThrow();
  });

  // ── waitForImages – no images in portal ───────────────────────────────────

  it("calls window.print() when portal contains no images", async () => {
    vehiclePrintSheetRenderer = () => <div data-testid="no-img" />;
    render(<PrintButton vehicle={{ title: "Car" }} />);
    await flushEffects();

    fireEvent.click(screen.getByRole("button", { name: "Print" }));

    await waitFor(() => expect(window.print).toHaveBeenCalledTimes(1));
  });

  // ── waitForImages – all images already complete ────────────────────────────

  it("calls window.print() when all portal images are already complete", async () => {
    vehiclePrintSheetRenderer = () => <Image alt="car" height={200} src="/car.jpg" width={200} />;
    render(<PrintButton vehicle={{ title: "Car" }} />);
    await flushEffects();

    const portal = getPortal() as HTMLElement;
    for (const img of Array.from(portal.querySelectorAll("img"))) {
      Object.defineProperty(img, "complete", { value: true, configurable: true });
    }

    fireEvent.click(screen.getByRole("button", { name: "Print" }));

    await waitFor(() => expect(window.print).toHaveBeenCalledTimes(1));
  });

  // ── waitForImages – image fires onload ────────────────────────────────────

  it("calls window.print() after portal image fires a load event", async () => {
    vehiclePrintSheetRenderer = () => (
      <Image alt="vehicle" height={200} src="/car.jpg" width={200} />
    );
    render(<PrintButton vehicle={{ title: "Car" }} />);
    await flushEffects();

    const portal = getPortal() as HTMLElement;
    const imgs = Array.from(portal.querySelectorAll("img"));

    for (const img of imgs) {
      Object.defineProperty(img, "complete", { value: false, configurable: true });
    }

    fireEvent.click(screen.getByRole("button", { name: "Print" }));

    for (const img of imgs) {
      img.dispatchEvent(new Event("load"));
    }

    await waitFor(() => expect(window.print).toHaveBeenCalledTimes(1));
  });

  // ── waitForImages – image fires onerror ───────────────────────────────────

  it("calls window.print() after portal image fires an error event", async () => {
    vehiclePrintSheetRenderer = () => (
      <Image alt="broken vehicle" height={200} src="/bad.jpg" width={200} />
    );
    render(<PrintButton vehicle={{ title: "Car" }} />);
    await flushEffects();

    const portal = getPortal() as HTMLElement;
    const imgs = Array.from(portal.querySelectorAll("img"));

    for (const img of imgs) {
      Object.defineProperty(img, "complete", { value: false, configurable: true });
    }

    fireEvent.click(screen.getByRole("button", { name: "Print" }));

    for (const img of imgs) {
      img.dispatchEvent(new Event("error"));
    }

    await waitFor(() => expect(window.print).toHaveBeenCalledTimes(1));
  });

  // ── waitForImages – safety timeout ────────────────────────────────────────

  it("calls window.print() via safety timeout when image never loads", async () => {
    vi.useFakeTimers();

    vehiclePrintSheetRenderer = () => (
      <Image alt="slow vehicle" height={200} src="/slow.jpg" width={200} />
    );
    render(<PrintButton vehicle={{ title: "Car" }} />);
    await flushEffects();

    const portal = getPortal() as HTMLElement;
    for (const img of Array.from(portal.querySelectorAll("img"))) {
      Object.defineProperty(img, "complete", { value: false, configurable: true });
    }

    fireEvent.click(screen.getByRole("button", { name: "Print" }));

    await act(async () => {
      vi.advanceTimersByTime(8000);
      await Promise.resolve();
      await Promise.resolve();
    });

    expect(window.print).toHaveBeenCalledTimes(1);
  });

  it("sanity: vehiclePrintSheetRenderer is a function", () => {
    expect(typeof vehiclePrintSheetRenderer).toBe("function");
  });
});
