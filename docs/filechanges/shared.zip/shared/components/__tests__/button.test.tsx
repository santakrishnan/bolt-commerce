// `React` import removed — JSX runtime handles it in tests.
import "@testing-library/jest-dom";
import { fireEvent, render } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

// Mock the external UI package so tests only verify our component behaviour
vi.mock("@tfs-ucmp/ui", () => {
  const React = require("react");
  return {
    cn: (...args: any[]) => args.flat().filter(Boolean).join(" "),
    Button: React.forwardRef(({ asChild, children, ...props }: any, ref: any) => {
      if (asChild) {
        return children;
      }
      return React.createElement("button", { ref, ...props }, children);
    }),
  };
});

import { AppButton } from "../button";

describe("AppButton", () => {
  it("renders children, forwards className and onClick, omits size/variant attributes", () => {
    const handle = vi.fn();
    const { container } = render(
      <AppButton className="extra" onClick={handle}>
        Click me
      </AppButton>
    );
    const btn = container.querySelector("button");
    expect(btn).toBeTruthy();
    expect(btn?.textContent).toContain("Click me");
    expect(btn).toHaveClass("extra");
    fireEvent.click(btn as Element);
    expect(handle).toHaveBeenCalled();
    expect(btn?.getAttribute("size")).toBe(null);
    expect(btn?.getAttribute("variant")).toBe(null);
  });

  it("renders icon on left and right in correct order", () => {
    const { container } = render(
      <AppButton icon={<span data-testid="icon">I</span>} iconPosition="left">
        Text
      </AppButton>
    );
    const html = container.querySelector("button")?.innerHTML ?? "";
    const iconIndex = html.indexOf('data-testid="icon"');
    const textIndex = html.indexOf("Text");
    expect(iconIndex).toBeGreaterThanOrEqual(0);
    expect(iconIndex).toBeLessThan(textIndex);

    const { container: c2 } = render(
      <AppButton icon={<span data-testid="icon">I</span>} iconPosition="right">
        Text
      </AppButton>
    );
    const html2 = c2.querySelector("button")?.innerHTML ?? "";
    const iconIndex2 = html2.indexOf('data-testid="icon"');
    const textIndex2 = html2.indexOf("Text");
    expect(iconIndex2).toBeGreaterThan(textIndex2);
  });

  it("when asChild=true renders the child element directly (no button wrapper)", () => {
    const { queryByTestId } = render(
      <AppButton asChild>
        <a data-testid="link" href="https://example.com/test-link">
          Link
        </a>
      </AppButton>
    );
    expect(queryByTestId("link")).toBeTruthy();
    expect(document.querySelector("button")).toBeNull();
  });

  it("forwards ref when provided via direct call", () => {
    const ref = { current: null } as any;
    // Call the component function directly so the `ref` prop is passed through as a normal prop
    const element = (AppButton as any)({ children: "Ref", ref });
    render(element);
    expect(ref.current).toBeInstanceOf(HTMLElement);
    expect(ref.current.textContent).toContain("Ref");
  });

  it("includes custom className when provided", () => {
    const custom = "my-extra";
    const { container } = render(
      <AppButton className={custom} size="lg" variant="secondary">
        Btn
      </AppButton>
    );
    const btn = container.querySelector("button");
    expect(btn).toBeTruthy();
    expect(btn).toHaveClass(custom);
  });
});
