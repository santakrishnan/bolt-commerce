/**
 * @vitest-environment jsdom
 */

import { act, cleanup, render, screen } from "@arrow/vitest-config/test-utils";
import * as matchers from "@testing-library/jest-dom/matchers";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

expect.extend(matchers);
afterEach(cleanup);

// ─── Top-level regex constants (biome: useTopLevelRegex) ──────────────────────

const DIGIT_RE = /\d/;
const ONE_THOUSAND_RE = /1.000/;
const THREE_SEVEN_RE = /3[.,]7/;

// ─── IntersectionObserver mock ────────────────────────────────────────────────

type IOCallback = (entries: IntersectionObserverEntry[]) => void;

let _ioCallback: IOCallback | null = null;
let _observedElement: Element | null = null;
const mockDisconnect = vi.fn();

vi.stubGlobal(
  "IntersectionObserver",
  vi.fn().mockImplementation((callback: IOCallback) => ({
    observe: (el: Element) => {
      _ioCallback = callback;
      _observedElement = el;
    },
    disconnect: mockDisconnect,
    unobserve: vi.fn(),
  }))
);

import { AnimatedCounter } from "../animated-counter";

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Simulate the element entering the viewport via the IntersectionObserver callback. */
async function triggerIntersection(isIntersecting: boolean) {
  if (_ioCallback && _observedElement) {
    await act(async () => {
      await Promise.resolve();
      (_ioCallback as IOCallback)([
        {
          isIntersecting,
          target: _observedElement as Element,
          boundingClientRect: {} as DOMRectReadOnly,
          intersectionRatio: isIntersecting ? 1 : 0,
          intersectionRect: {} as DOMRectReadOnly,
          rootBounds: null,
          time: 0,
        } as IntersectionObserverEntry,
      ]);
    });
  }
}

/** Advance the fake-timer clock to complete the animation and flush React updates. */
async function completeAnimation(duration: number) {
  await act(async () => {
    await Promise.resolve();
    vi.advanceTimersByTime(duration * 3);
  });
}

/** Flush pending React state updates and effects. */
async function flushEffects() {
  await act(async () => {
    await Promise.resolve();
  });
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe("AnimatedCounter", () => {
  beforeEach(() => {
    vi.useFakeTimers({
      toFake: ["requestAnimationFrame", "performance"],
    });
    _ioCallback = null;
    _observedElement = null;
    mockDisconnect.mockClear();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  // ── Rendering ─────────────────────────────────────────────────────────────

  it("renders a span element", () => {
    render(<AnimatedCounter value={100} />);
    const span = screen.getByText(DIGIT_RE);
    expect(span.tagName).toBe("SPAN");
  });

  it("displays 0 initially before the element enters the viewport", () => {
    render(<AnimatedCounter value={500} />);
    expect(screen.getByText("0")).toBeInTheDocument();
  });

  it("renders with a custom className on the span", () => {
    render(<AnimatedCounter className="my-class" value={10} />);
    const span = screen.getByText("0");
    expect(span).toHaveClass("my-class");
  });

  it("renders static prefix and suffix before animation starts", () => {
    const { container } = render(<AnimatedCounter prefix="$" suffix="+" value={100} />);
    const span = container.querySelector("span");
    expect(span?.textContent).toBe("$0+");
  });

  // ── IntersectionObserver lifecycle ────────────────────────────────────────

  it("sets up an IntersectionObserver with threshold 0.3 on mount", () => {
    render(<AnimatedCounter value={50} />);
    expect(IntersectionObserver).toHaveBeenCalledWith(
      expect.any(Function),
      expect.objectContaining({ threshold: 0.3 })
    );
  });

  it("disconnects the observer on unmount", async () => {
    const { unmount } = render(<AnimatedCounter value={50} />);
    await flushEffects();
    unmount();
    expect(mockDisconnect).toHaveBeenCalled();
  });

  it("does not animate before the element enters the viewport", async () => {
    render(<AnimatedCounter value={1000} />);
    await flushEffects();
    expect(screen.getByText("0")).toBeInTheDocument();
  });

  // ── Non-intersecting entry ────────────────────────────────────────────────

  it("does not start animation when entry is not intersecting", async () => {
    render(<AnimatedCounter duration={500} formatted={false} value={200} />);
    await flushEffects();

    await triggerIntersection(false);
    await completeAnimation(500);

    expect(screen.getByText("0")).toBeInTheDocument();
  });

  // ── Animation – integer, formatted ────────────────────────────────────────

  it("animates to the target integer value with locale formatting", async () => {
    render(<AnimatedCounter duration={500} formatted value={1000} />);
    await flushEffects();

    await triggerIntersection(true);
    await completeAnimation(500);

    const el = screen.getByText(ONE_THOUSAND_RE);
    expect(el).toBeInTheDocument();
  });

  // ── Animation – integer, NOT formatted ────────────────────────────────────

  it("animates to the target integer value without formatting", async () => {
    render(<AnimatedCounter duration={500} formatted={false} value={42} />);
    await flushEffects();

    await triggerIntersection(true);
    await completeAnimation(500);

    expect(screen.getByText("42")).toBeInTheDocument();
  });

  // ── Animation – fractional, formatted ─────────────────────────────────────

  it("animates to a fractional value with Intl formatting (1 decimal)", async () => {
    render(<AnimatedCounter duration={500} formatted value={3.7} />);
    await flushEffects();

    await triggerIntersection(true);
    await completeAnimation(500);

    const el = screen.getByText(THREE_SEVEN_RE);
    expect(el).toBeInTheDocument();
  });

  // ── Animation – fractional, NOT formatted ─────────────────────────────────

  it("animates to a fractional value without formatting", async () => {
    render(<AnimatedCounter duration={500} formatted={false} value={2.5} />);
    await flushEffects();

    await triggerIntersection(true);
    await completeAnimation(500);

    expect(screen.getByText("2.5")).toBeInTheDocument();
  });

  // ── Prefix & suffix after animation ──────────────────────────────────────

  it("renders prefix and suffix around the final animated value", async () => {
    render(<AnimatedCounter duration={500} formatted={false} prefix="$" suffix="+" value={5} />);
    await flushEffects();

    await triggerIntersection(true);
    await completeAnimation(500);

    const span = document.querySelector("span");
    expect(span?.textContent).toBe("$5+");
  });

  // ── easeOutExpo boundary: t = 1 ───────────────────────────────────────────

  it("reaches exactly the target value at animation completion (easeOutExpo t=1)", async () => {
    render(<AnimatedCounter duration={200} formatted={false} value={99} />);
    await flushEffects();

    await triggerIntersection(true);
    await completeAnimation(200);

    expect(screen.getByText("99")).toBeInTheDocument();
  });

  // ── No double-animation ───────────────────────────────────────────────────

  it("does not restart the animation when the element intersects a second time", async () => {
    render(<AnimatedCounter duration={500} formatted={false} value={10} />);
    await flushEffects();

    await triggerIntersection(true);
    await completeAnimation(500);

    expect(screen.getByText("10")).toBeInTheDocument();

    await triggerIntersection(true);
    await completeAnimation(500);

    expect(screen.getByText("10")).toBeInTheDocument();
  });
});
