/** Type definitions for CustomBadge. */

import type { LucideIcon } from "lucide-react";
import type * as React from "react";

import type { customBadgeClasses } from "./custom-badge.constants";

type ShadcnVariant = "default" | "secondary" | "destructive" | "outline" | "subtle" | "ghost";
export type CustomVariant = keyof typeof customBadgeClasses;

/** All supported badge types */
export type CustomBadgeType = ShadcnVariant | CustomVariant;

export interface CustomBadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** When `type==='ExpiresAt'`, renders `Expires in <n> day(s)` */
  expiresInDays?: number;
  icon?: LucideIcon | React.ReactNode | null;
  iconPosition?: "left" | "right";
  iconSrc?: string;
  matchPercentage?: number;
  ownerCount?: number;
  text?: React.ReactNode;
  type?: CustomBadgeType;
}
