"use client";

import { Button, Chip } from "@tfs-ucmp/ui";
import Image from "next/image";

import { XIcon } from "@/components/assets/icons";
import { resolveStateClass } from "./custom-chips.helpers";
import type { FilterChipProps } from "./custom-chips.types";

export type { CustomChipType, FilterChipProps } from "./custom-chips.types";

export const CustomChips = ({
  label,
  selected = false,
  type,
  onClick,
  className,
  prefix,
  onRemove,
  isRefineSearch = false,
  ...rest
}: FilterChipProps) => {
  const isSelected = type ? type === "selected" : selected;
  const isUnavailable = type === "unavailable";
  const isApplied = type === "applied";
  const chipOnClick = isUnavailable || isApplied ? undefined : onClick;

  return (
    <Chip
      aria-disabled={isUnavailable}
      className={[
        // ── base ─────────────────────────────────────────────────────────────
        "flex h-[var(--spacing-xl)] cursor-pointer items-center gap-[var(--spacing-xs)]",
        "rounded-full px-[var(--spacing-sm)] font-normal",
        "text-[length:var(--font-size-xs)] leading-normal transition-colors",
        // ── state ────────────────────────────────────────────────────────────
        resolveStateClass(isUnavailable, isSelected, isApplied, isRefineSearch),
        className ?? "",
      ]
        .filter(Boolean)
        .join(" ")}
      onClick={chipOnClick}
      tabIndex={isUnavailable ? -1 : undefined}
      variant="outline"
      {...rest}
    >
      {prefix}
      <span className="font-normal text-[length:var(--font-size-xs)] leading-normal">{label}</span>
      {isSelected && (
        <Image alt="Selected" height={12} src="/images/search/checkmark.svg" width={12} />
      )}
      {isApplied && onRemove && (
        <Button
          aria-label={`Remove ${label} filter`}
          className={
            isRefineSearch
              ? "relative -top-[-1px] flex h-4 w-4 items-center justify-center px-0 text-[var(--color-destructive-foreground)] transition-colors hover:opacity-70"
              : "relative -top-[-1px] flex h-4 w-4 items-center justify-center px-0 text-[var(--color-brand-text)] transition-colors hover:text-[var(--color-destructive)]"
          }
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          type="button"
          variant="search"
        >
          <XIcon className="h-3.5 w-3.5" />
        </Button>
      )}
    </Chip>
  );
};

CustomChips.displayName = "CustomChips";

// Backwards-compatible alias for existing imports
export const FilterChip = CustomChips;
