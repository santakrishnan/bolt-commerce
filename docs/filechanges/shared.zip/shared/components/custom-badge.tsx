/** CustomBadge — visual badge for price, status, and label types. */

import { Badge } from "@tfs-ucmp/ui";
import type * as React from "react";

import { cn } from "@/lib/utils";
import { customBadgeClasses } from "./custom-badge.constants";
import type { CustomBadgeProps } from "./custom-badge.types";
import { isCustomVariant, resolveIcon } from "./custom-badge-helpers";

export type { CustomBadgeProps, CustomBadgeType, CustomVariant } from "./custom-badge.types";

export function CustomBadge({
  icon,
  iconSrc,
  iconPosition = "left",
  type = "default",
  text,
  matchPercentage,
  ownerCount,
  expiresInDays,
  className,
  children,
  ref,
  ...props
}: CustomBadgeProps & { ref?: React.Ref<HTMLSpanElement> }) {
  const iconNode = resolveIcon(type, icon, iconSrc);

  const iconEl = iconNode ? <span className="inline-flex items-center">{iconNode}</span> : null;

  // Resolve label: expiresInDays (for ExpiresAt) > type-specific > text/children
  let resolvedLabel: React.ReactNode = text ?? children;
  if (type === "ExpiresAt" && expiresInDays !== undefined) {
    resolvedLabel = `Expires in ${expiresInDays} ${expiresInDays === 1 ? "day" : "days"}`;
  } else if (type === "matchingPercentage" && matchPercentage !== undefined) {
    resolvedLabel = `${matchPercentage}% Match`;
  } else if (type === "owner" && ownerCount !== undefined) {
    resolvedLabel = `${ownerCount} ${ownerCount === 1 ? "Owner" : "Owners"}`;
  }

  const content =
    iconPosition === "right" ? (
      <>
        {resolvedLabel}
        {iconEl}
      </>
    ) : (
      <>
        {iconEl}
        {resolvedLabel}
      </>
    );

  // Custom variants: plain <span> with the mapped class string
  if (isCustomVariant(type)) {
    return (
      <span
        className={cn(
          // Design spec: border-radius 4px, height 24px, padding 0 8px, gap 4px
          "inline-flex h-[var(--spacing-lg)] max-w-fit items-center gap-[var(--spacing-2xs)] rounded-[var(--spacing-2xs)] px-[var(--spacing-xs)] py-0",
          customBadgeClasses[type],
          className
        )}
        ref={ref}
        {...props}
      >
        {content}
      </span>
    );
  }

  // Shadcn variants: delegate to the shared <Badge> primitive
  return (
    <Badge className={cn(className)} ref={ref} variant={type} {...props}>
      {content}
    </Badge>
  );
}

export default CustomBadge;
