/** State class resolver for CustomChips. */

export function resolveStateClass(
  isUnavailable: boolean,
  isSelected: boolean,
  isApplied: boolean,
  isRefineSearch: boolean
): string {
  if (isUnavailable) {
    return "border-transparent bg-[var(--color-actions-tertiary-hover)] text-[var(--color-brand-text-disabled)] cursor-not-allowed pointer-events-none";
  }
  if (isApplied && isRefineSearch) {
    return "border border-[var(--color-destructive)] bg-[var(--color-destructive)] text-[var(--color-destructive-foreground)] cursor-default hover:bg-[var(--color-destructive)] hover:text-[var(--color-destructive-foreground)]";
  }
  if (isApplied) {
    return "border border-[var(--color-states-muted)] bg-transparent text-[var(--color-brand-text)] cursor-default hover:bg-transparent hover:opacity-100 hover:text-[var(--color-brand-text)]";
  }
  if (isSelected) {
    return "border border-[var(--color-actions-accent)] bg-inherit text-[var(--color-brand-text-primary)] hover:bg-inherit hover:text-[var(--color-brand-text-primary)]";
  }
  return "border-transparent bg-[var(--color-core-surfaces-background)] text-[var(--color-brand-text-primary)] hover:bg-[var(--color-core-surfaces-background)] hover:text-[var(--color-brand-text-primary)]";
}
