import { render } from "@testing-library/react";
import type React from "react";
import { describe, expect, it } from "vitest";
import { composeProviders } from "../compose-providers";

describe("composeProviders", () => {
  it("composes providers outermost-first (A > B > C) and renders children", () => {
    const A = ({ children }: { children: React.ReactNode }) => (
      <div data-testid="A">{children}</div>
    );
    const B = ({ children }: { children: React.ReactNode }) => (
      <div data-testid="B">{children}</div>
    );
    const C = ({ children }: { children: React.ReactNode }) => (
      <div data-testid="C">{children}</div>
    );

    A.displayName = "AProvider";
    B.displayName = "BProvider";
    C.displayName = "CProvider";

    const Providers = composeProviders(A, B, C);

    const { container, getByTestId } = render(
      <Providers>
        <span data-testid="child">hello</span>
      </Providers>
    );

    // Outer wrapper exists
    const a = getByTestId("A");
    const b = getByTestId("B");
    const c = getByTestId("C");

    // Ensure nesting A > B > C > child
    expect(a.contains(b)).toBe(true);
    expect(b.contains(c)).toBe(true);
    expect(c.querySelector('[data-testid="child"]')).not.toBeNull();
    expect(container.querySelector('[data-testid="child"]')?.textContent).toBe("hello");
  });

  it("returns a component that simply renders children when no providers given", () => {
    const Empty = composeProviders();
    const { getByTestId } = render(
      <Empty>
        <span data-testid="plain">ok</span>
      </Empty>
    );
    expect(getByTestId("plain").textContent).toBe("ok");
  });
});
