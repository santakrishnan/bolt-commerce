import { render } from "@testing-library/react";
import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { ThemeProvider, useTheme } from "../theme-provider";

function Consumer({ onReady }: { onReady: (ctx: any) => void }) {
  // call useTheme to exercise throwing and normal behavior
  const ctx = useTheme();
  React.useEffect(() => {
    onReady(ctx);
  }, [ctx, onReady]);
  return null;
}

describe("ThemeProvider", () => {
  let originalMatchMedia: any;
  let originalDocEl: any;

  beforeEach(() => {
    // reset/mocks
    originalMatchMedia = (window as any).matchMedia;
    originalDocEl = document.documentElement;

    // mock documentElement.classList
    const classList = {
      remove: vi.fn(),
      add: vi.fn(),
    } as any;

    Object.defineProperty(document, "documentElement", {
      configurable: true,
      value: { classList },
    });
  });

  afterEach(() => {
    // restore possible globals
    (window as any).matchMedia = originalMatchMedia;
    Object.defineProperty(document, "documentElement", {
      configurable: true,
      value: originalDocEl,
    });
  });

  it("useTheme throws when used outside ThemeProvider", () => {
    // render a component that calls useTheme without provider
    expect(() =>
      render(
        <Consumer
          onReady={() => {
            /* noop */
          }}
        />
      )
    ).toThrow("useTheme must be used within ThemeProvider");
  });

  it("setTheme applies dark class when asked", async () => {
    (window as any).matchMedia = vi.fn().mockReturnValue({ matches: false });

    await new Promise<void>((resolve, reject) => {
      render(
        <ThemeProvider>
          <Consumer
            onReady={(ctx: any) => {
              try {
                expect(ctx.state.theme).toBe("system");
                // call setTheme to dark
                ctx.actions.setTheme("dark");
                // documentElement.classList.remove should be called
                expect(document.documentElement.classList.remove).toHaveBeenCalledWith(
                  "light",
                  "dark"
                );
                expect(document.documentElement.classList.add).toHaveBeenCalledWith("dark");
                resolve();
              } catch (err) {
                reject(err);
              }
            }}
          />
        </ThemeProvider>
      );
    });
  });

  it("setTheme 'system' uses matchMedia result to choose class", async () => {
    // simulate system prefers dark
    (window as any).matchMedia = vi.fn().mockReturnValue({ matches: true });

    await new Promise<void>((resolve, reject) => {
      render(
        <ThemeProvider>
          <Consumer
            onReady={(ctx: any) => {
              try {
                ctx.actions.setTheme("system");
                expect(document.documentElement.classList.remove).toHaveBeenCalled();
                expect(document.documentElement.classList.add).toHaveBeenCalledWith("dark");
                resolve();
              } catch (err) {
                reject(err);
              }
            }}
          />
        </ThemeProvider>
      );
    });
  });
});
