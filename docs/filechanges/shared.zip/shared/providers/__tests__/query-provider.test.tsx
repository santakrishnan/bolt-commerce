import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

// capture object for mocked PersistQueryClientProvider
let captured: any = {};

vi.mock("@tanstack/react-query-persist-client", () => {
  return {
    PersistQueryClientProvider: ({ client, persistOptions, children }: any) => {
      captured.client = client;
      captured.persistOptions = persistOptions;
      return <div data-testid="children">{children}</div>;
    },
  };
});

vi.mock("@shared/lib/indexeddb", () => ({
  idbSet: vi.fn(),
  idbGet: vi.fn(),
  idbDel: vi.fn(),
}));

import { QueryProvider } from "../query-provider";

describe("QueryProvider (unit)", () => {
  beforeEach(async () => {
    captured = {};
    const idb = await import("@shared/lib/indexeddb");
    (idb.idbSet as any).mockReset();
    (idb.idbGet as any).mockReset();
    (idb.idbDel as any).mockReset();
  });

  it("renders children and injects PersistQueryClientProvider props", () => {
    render(
      <QueryProvider>
        <div>child</div>
      </QueryProvider>
    );

    expect(screen.getByTestId("children")).toBeTruthy();
    // persisted options should exist
    expect(captured.persistOptions).toBeDefined();
    expect(typeof captured.persistOptions.persister.persistClient).toBe("function");
  });

  it("shouldDehydrateQuery filter behaves correctly", () => {
    render(
      <QueryProvider>
        <div>child</div>
      </QueryProvider>
    );

    const shouldDehydrate = captured.persistOptions.dehydrateOptions.shouldDehydrateQuery;

    // not-success status -> false
    expect(shouldDehydrate({ state: { status: "error" }, queryKey: ["saved-vehicles"] })).toBe(
      false
    );

    // success but unknown prefix -> false
    expect(shouldDehydrate({ state: { status: "success" }, queryKey: ["other-key"] })).toBe(false);

    // success and known prefix -> true
    expect(shouldDehydrate({ state: { status: "success" }, queryKey: ["saved-vehicles"] })).toBe(
      true
    );
  });

  it("persister.persistClient calls idbSet and swallows errors", async () => {
    render(
      <QueryProvider>
        <div>child</div>
      </QueryProvider>
    );

    const persister = captured.persistOptions.persister;
    const idb = await import("@shared/lib/indexeddb");

    (idb.idbSet as any).mockResolvedValue(undefined);
    const client = { test: true } as any;
    await persister.persistClient(client);
    expect(idb.idbSet).toHaveBeenCalledWith("tanstack-query-cache", client);

    // throw inside idbSet should be swallowed
    (idb.idbSet as any).mockImplementationOnce(() => {
      throw new Error("fail");
    });
    await expect(persister.persistClient(client)).resolves.toBeUndefined();
  });

  it("persister.restoreClient returns stored value and returns undefined on error", async () => {
    render(
      <QueryProvider>
        <div>child</div>
      </QueryProvider>
    );

    const persister = captured.persistOptions.persister;
    const idb = await import("@shared/lib/indexeddb");

    (idb.idbGet as any).mockResolvedValueOnce({ a: 1 });
    await expect(persister.restoreClient()).resolves.toEqual({ a: 1 });

    (idb.idbGet as any).mockImplementationOnce(() => {
      throw new Error("nope");
    });
    await expect(persister.restoreClient()).resolves.toBeUndefined();
  });

  it("persister.removeClient calls idbDel and swallows errors", async () => {
    render(
      <QueryProvider>
        <div>child</div>
      </QueryProvider>
    );

    const persister = captured.persistOptions.persister;
    const idb = await import("@shared/lib/indexeddb");

    (idb.idbDel as any).mockResolvedValue(undefined);
    await persister.removeClient();
    expect(idb.idbDel).toHaveBeenCalledWith("tanstack-query-cache");

    (idb.idbDel as any).mockImplementationOnce(() => {
      throw new Error("nope");
    });
    await expect(persister.removeClient()).resolves.toBeUndefined();
  });
});
