import { describe, expect, it } from "vitest";
import { vehicleTypes } from "../vehicle-types";

describe("vehicleTypes data", () => {
  it("is an array with the expected vehicle type ids and shapes", () => {
    expect(Array.isArray(vehicleTypes)).toBe(true);
    expect(vehicleTypes.length).toBeGreaterThanOrEqual(8);

    const ids = vehicleTypes.map((v) => v.id);
    expect(ids).toEqual(
      expect.arrayContaining([
        "sedan",
        "suv",
        "coupe",
        "truck",
        "hatchback",
        "wagon",
        "van",
        "convertible",
      ])
    );

    for (const v of vehicleTypes) {
      expect(typeof v.id).toBe("string");
      expect(typeof v.name).toBe("string");
      expect(typeof v.description).toBe("string");
      expect(typeof v.image).toBe("string");
      expect(v.image.startsWith("/images/categories/")).toBe(true);
      // names are expected to be uppercase labels
      expect(v.name).toBe(v.name.toUpperCase());
    }
  });
});
