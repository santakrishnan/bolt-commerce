/**
 * Vehicle Type Data
 * Contains all vehicle types with their display information
 */

export interface VehicleType {
  description: string;
  id: string;
  image: string;
  name: string;
}

export const vehicleTypes: VehicleType[] = [
  {
    id: "sedan",
    name: "SEDAN",
    description: "Fuel-efficient daily driver",
    image: "/images/categories/Sedan.png",
  },
  {
    id: "suv",
    name: "SUV",
    description: "Space & versatility",
    image: "/images/categories/SUV.png",
  },
  {
    id: "truck",
    name: "TRUCK",
    description: "Power & capability",
    image: "/images/categories/Truck.png",
  },
  {
    id: "coupe",
    name: "COUPE",
    description: "Sleek, sporty, two-door",
    image: "/images/categories/Coupe.png",
  },
  {
    id: "hatchback",
    name: "HATCHBACK",
    description: "Fuel-efficient daily driver",
    image: "/images/categories/Hatchback.png",
  },
  {
    id: "wagon",
    name: "WAGON",
    description: "Space & versatility",
    image: "/images/categories/Wagon.png",
  },
  {
    id: "van",
    name: "VAN",
    description: "Power & capability",
    image: "/images/categories/Van.png",
  },
  {
    id: "convertible",
    name: "CONVERTIBLE",
    description: "Sleek, sporty, two-door",
    image: "/images/categories/Convertible.png",
  },
];
