const FINGERPRINT_REGEX = /fingerprint/i;

import { NextRequest } from "next/server";
import { describe, expect, it } from "vitest";
import { createGET } from "../session/route";

describe("/api/session", () => {
  it("GET returns initialized true if session exists", async () => {
    const GET = createGET({
      readSession: () => ({ sessionId: "abc", fingerprintId: "def" }),
    });
    const req = new NextRequest("https://test/api/session");
    const res = GET(req);
    expect(res.status).toBe(200);
    const json = await res.json();
    expect(json.initialized).toBe(true);
  });

  it("GET returns initialized false if no session", async () => {
    const GET = createGET({
      readSession: () => null,
    });
    const req = new NextRequest("https://test/api/session");
    const res = GET(req);
    expect(res.status).toBe(200);
    const json = await res.json();
    expect(json.initialized).toBe(false);
  });

  it("POST returns 400 if missing fingerprint", async () => {
    process.env.TEST_CASE = "missing-fingerprint";
    const { POST } = await import("../session/route");
    const req = new NextRequest("https://test/api/session", { method: "POST" });
    (req as any).json = () => Promise.resolve({});
    const res = await POST(req);
    expect(res.status).toBe(400);
    const json = await res.json();
    expect(json.error).toMatch(FINGERPRINT_REGEX);
  });
});
