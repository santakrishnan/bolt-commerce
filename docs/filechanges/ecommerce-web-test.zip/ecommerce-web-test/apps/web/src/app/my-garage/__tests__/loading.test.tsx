/**
 * @vitest-environment jsdom
 */

/**
 * Unit tests for MyGarageLoading component
 * @module app/my-garage/__tests__/loading
 */

import { render, screen } from "@arrow/vitest-config/test-utils";
import { describe, expect, it } from "vitest";
import MyGarageLoading from "../loading";

describe("MyGarageLoading", () => {
  it("renders the loading spinner and text correctly", () => {
    const { container } = render(<MyGarageLoading />);

    // Check for the loading text
    expect(screen.getByText("Loading your garage...")).toBeInTheDocument();

    // Check for the spinner element
    const spinner = container.querySelector(".animate-spin");
    expect(spinner).toBeInTheDocument();
    expect(spinner).toHaveClass(
      "h-12",
      "w-12",
      "rounded-full",
      "border-4",
      "border-gray-200",
      "border-t-red-600"
    );

    // Check for the outer container
    const outerDiv = container.firstChild;
    expect(outerDiv).toHaveClass("flex", "min-h-screen", "items-center", "justify-center");

    // Check for the inner container
    const innerDiv = outerDiv?.firstChild;
    expect(innerDiv).toHaveClass("flex", "flex-col", "items-center", "gap-4");
  });
});
