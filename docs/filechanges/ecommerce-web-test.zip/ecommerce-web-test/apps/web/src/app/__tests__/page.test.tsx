import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

const garageRegex = /Garage/;
vi.mock("@features/landing/components/vehicle-quick-links/vehicle-finder-quick-links", () => ({
  __esModule: true,
  default: () =>
    Promise.resolve(
      <section>
        <h1>Find your vehicle</h1>
      </section>
    ),
}));
vi.mock("@config/flags/flags", () => ({
  redirectToMyGarage: vi.fn(() => Promise.resolve(false)),
  getUserInfo: vi.fn(() => Promise.resolve({ isAuthenticated: false })),
  showPersonalizedHeroBanner: vi.fn(() => Promise.resolve(false)),
  customerPreQualified: vi.fn(() => Promise.resolve(false)),
}));
vi.mock("@features/my-garage", () => ({
  MyGarageWrapper: ({ showUserName }: any) => <div>Garage {showUserName ? "User" : ""}</div>,
}));
vi.mock("@features/landing", () => ({
  HomeHero: () => <div>HomeHero</div>,
  BuyingProcess: () => <div>BuyingProcess</div>,
  ArrowInspectedSectionWrapper: () => <div>ArrowInspectedSection</div>,
  ArrowInspectedSkeleton: () => <div>ArrowInspectedSkeleton</div>,
  CustomerJourneyCarouselSection: () => <div>CustomerJourneyCarouselSection</div>,
  CustomerJourneySkeleton: () => <div>CustomerJourneySkeleton</div>,
  VehicleFinderQuickLinks: () => <div>VehicleFinderQuickLinks</div>,
  VehicleFinderSkeleton: () => <div>VehicleFinderSkeleton</div>,
  VehicleTypeSelectorSkeleton: () => <div>VehicleTypeSelectorSkeleton</div>,
  VehicleTypeSelectorWrapper: () => <div>VehicleTypeSelectorWrapper</div>,
}));

describe("HomePage", () => {
  it("renders MyGarageWrapper when shouldShowGarage is true", async () => {
    // Set up the mock to return true for redirectToMyGarage and authenticated user
    const flags = await import("@config/flags/flags");
    (flags.redirectToMyGarage as any).mockImplementation(() => Promise.resolve(true));
    (flags.getUserInfo as any).mockImplementation(() => Promise.resolve({ isAuthenticated: true }));
    (flags.showPersonalizedHeroBanner as any).mockImplementation(() => Promise.resolve(true));
    const { HomePageContent } = await import("../page");
    const element = await HomePageContent();
    render(element);
    expect(await screen.findByText(garageRegex)).toBeInTheDocument();
    expect(screen.queryByText("HomeHero")).not.toBeInTheDocument();
  }, 15_000); // Increase timeout for SSR/dynamic import

  it("renders landing sections when shouldShowGarage is false", async () => {
    // Set up the mock to return false for redirectToMyGarage and unauthenticated user
    const flags = await import("@config/flags/flags");
    (flags.redirectToMyGarage as any).mockImplementation(() => Promise.resolve(false));
    (flags.getUserInfo as any).mockImplementation(() =>
      Promise.resolve({ isAuthenticated: false })
    );
    (flags.showPersonalizedHeroBanner as any).mockImplementation(() => Promise.resolve(false));
    (flags.customerPreQualified as any).mockImplementation(() => Promise.resolve(false));
    const { HomePageContent } = await import("../page");
    const element = await HomePageContent();
    render(element);
    // Use findByText for async assertion
    expect(await screen.findByText("HomeHero")).toBeInTheDocument();
  }, 15_000); // Increase timeout for SSR/dynamic import
});
