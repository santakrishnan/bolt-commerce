/**
 * @vitest-environment jsdom
 */
import { render, screen } from "@arrow/vitest-config/test-utils";
import { describe, expect, it, vi } from "vitest";
import DealerNotesPage from "../page";

vi.mock("@features/vdp/components/dealer-notes-section", () => ({
  DealerNotesSection: () => <div data-testid="dealer-notes-section" />,
}));

describe("DealerNotesPage", () => {
  it("renders DealerNotesSection", () => {
    render(<DealerNotesPage />);
    expect(screen.getByTestId("dealer-notes-section")).toBeInTheDocument();
  });
});
