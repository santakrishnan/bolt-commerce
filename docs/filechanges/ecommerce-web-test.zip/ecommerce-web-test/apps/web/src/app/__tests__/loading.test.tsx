import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import Loading from "../loading";

describe("Loading", () => {
  it("renders loading spinner and text", () => {
    render(<Loading />);
    expect(screen.getByText("Loading...")).toBeInTheDocument();
    expect(screen.getByRole("status", { hidden: true })).toBeInTheDocument();
  });
});
