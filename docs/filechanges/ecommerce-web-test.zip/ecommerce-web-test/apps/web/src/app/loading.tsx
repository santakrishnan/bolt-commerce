export default function Loading() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div
          aria-live="polite"
          className="h-12 w-12 animate-spin rounded-full border-4 border-muted border-t-primary"
          role="status"
        />
        <p className="text-muted-foreground">Loading...</p>
      </div>
    </div>
  );
}
