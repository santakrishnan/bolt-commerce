import { NextRequest } from "next/server";
import { describe, expect, it } from "vitest";
import { createGET } from "../session/route";

describe("/api/session GET initialized true (isolated)", () => {
  it("returns initialized true if session exists", async () => {
    const GET = createGET({
      readSession: () => ({ sessionId: "abc", fingerprintId: "def" }),
    });
    const req = new NextRequest("https://test/api/session");
    const res = GET(req);
    expect(res.status).toBe(200);
    const json = await res.json();
    expect(json.initialized).toBe(true);
  });
});
