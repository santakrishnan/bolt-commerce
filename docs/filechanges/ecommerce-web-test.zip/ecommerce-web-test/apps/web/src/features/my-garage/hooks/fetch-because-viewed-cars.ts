export { becauseViewedVehicles } from "@features/my-garage/services/mock-because-viewed";

import { becauseViewedVehicles } from "@features/my-garage/services/mock-because-viewed";
import type { Vehicle } from "@shared/types";

/** Fisher-Yates shuffle — returns a new randomly-ordered copy. */
function shuffle<T>(arr: readonly T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = copy[i];
    copy[i] = copy[j] as T;
    copy[j] = tmp as T;
  }
  return copy;
}

/** Returns a shuffled copy of the "because you viewed" mock vehicles. */
export function fetchBecauseYouViewedCars(): Vehicle[] {
  return shuffle(becauseViewedVehicles as Vehicle[]);
}
