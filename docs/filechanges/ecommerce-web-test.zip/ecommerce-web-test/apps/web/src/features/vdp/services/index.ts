export type {
  FeatureCategory,
  HistoryData,
  PriceHistoryEntry,
  PricingData,
  RatingData,
  RatingDistribution,
  VehicleData,
  VehicleDetail,
  VehicleSpecData,
  VehicleStatusData,
  VinData,
} from "./types";
// vdp.service uses cacheTag/cacheLife (server-only).
// Import directly: @features/vdp/services/vdp.service
