/** Constants for price range meter segment calculations. */

export const PRICE_LOW_MULTIPLIER = 0.7;
export const PRICE_HIGH_MULTIPLIER = 1.3;

/** Design pixel widths for bar segments: [excellent, good, fair, high]. */
export const SEGMENT_WIDTHS = [92, 92, 200, 200] as const;

/** Reads a CSS custom property value as a number, with a fallback. */
export function cssVarPx(name: string, fallback = "0px"): number {
  try {
    const v = getComputedStyle(document.documentElement).getPropertyValue(name) || fallback;
    return Number.parseFloat(v);
  } catch (_e) {
    return Number.parseFloat(fallback);
  }
}
