/** Shared formatting utilities for VDP pricing components. */

import Image from "next/image";

export function formatShortDate(isoDate: string): string {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(new Date(isoDate));
}

export function formatPrice(value: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(value);
}

export function formatChange(change: number): string {
  const abs = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(Math.abs(change));
  return change >= 0 ? `+${abs}` : `-${abs}`;
}

/** Returns true if the ISO date string falls in the current calendar month. */
export function isCurrentMonth(isoDate: string): boolean {
  const now = new Date();
  const d = new Date(isoDate);
  return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
}

export function UpGreenArrowImg() {
  return (
    <Image
      alt="Price up"
      className="inline-block"
      height={20}
      src="/images/vdp/Up-GreenArrow.svg"
      width={17}
    />
  );
}

export function DownGreenArrowImg() {
  return (
    <Image
      alt="Price down"
      className="inline-block"
      height={20}
      src="/images/vdp/Down-GreenArrow.svg"
      width={17}
    />
  );
}
