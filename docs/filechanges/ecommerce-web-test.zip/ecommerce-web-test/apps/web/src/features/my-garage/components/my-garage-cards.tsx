"use client";

// Scrollable cards for My Garage
/* eslint-disable */
/* biome:disable */

import { ROUTES } from "@config/routes/constants";
import { Button, ScrollArea } from "@tfs-ucmp/ui";
import Image from "next/image";
import Link from "next/link";
import type { FC, ReactNode } from "react";
import { Fragment } from "react";
import {
  FinancingCard,
  RecentSearchCard,
  SavedVehicleCard,
  TestDriveCard,
  TradeOfferCard,
} from "./my-garage-sub-cards";
import type { MyGarageCardsProps } from "./types";

export type { GarageInfoCardProps } from "@features/vehicle-card";

// ─── Shared panel wrapper ────────────────────────────────────────────────────

interface GarageCardPanelProps {
  action?: ReactNode;
  children: ReactNode;
  count?: number;
  iconAlt: string;
  iconSrc: string;
  scrollHeight: string;
  title: string;
}

const GarageCardPanel: FC<GarageCardPanelProps> = ({
  iconSrc,
  iconAlt,
  title,
  count,
  action,
  scrollHeight,
  children,
}) => (
  <div className="flex min-w-65 flex-1 flex-col rounded-lg bg-white py-4 shadow">
    <div className="mb-6 flex items-center justify-between px-4 pb-0">
      <div className="flex items-center gap-2 font-semibold text-sm">
        <Image alt={iconAlt} className="shrink-0" height={20} src={iconSrc} width={20} />
        <span className="font-semibold text-[length:var(--font-size-xl)] text-[var(--Core-surfaces-foreground,#0A0A0A)] leading-[115%] [font-family:var(--font-family)] [leading-trim:both] [text-edge:cap]">
          {title}
          {count != null && count > 0 ? ` (${count})` : ""}
        </span>
      </div>
      {action}
    </div>
    <div className="mx-4 h-px bg-black opacity-10" />
    <div className="py-2">
      <div className="relative">
        <ScrollArea className={`${scrollHeight} px-4 pr-3`}>{children}</ScrollArea>
        <div
          className="pointer-events-none absolute bottom-0 left-0 z-10 h-8 w-full"
          style={{ background: "linear-gradient(to bottom, #ffffff00 0%, #ffffff 100%)" }}
        />
      </div>
    </div>
  </div>
);

// ─── MyGarageCards ───────────────────────────────────────────────────────────

export const MyGarageCards: FC<
  MyGarageCardsProps & {
    onRemoveSavedVehicle?: (id: number | string) => void;
    onRemoveSearch?: (id: string) => void;
    onClearAllSearches?: () => void;
  }
> = ({
  savedVehicles,
  recentSearches,
  financing,
  tradeOffer,
  testDrive,
  onRemoveSavedVehicle,
  onRemoveSearch,
  onClearAllSearches,
  onSavedVehicleClick,
}) => (
  <div className="flex w-full flex-col gap-4 lg:flex-row">
    <GarageCardPanel
      action={
        savedVehicles.length > 0 ? (
          <Link
            className="h-auto p-0 font-normal text-[length:var(--font-size-sm,14px)] text-[var(--Core-surfaces-foreground,#0A0A0A)] leading-[125%] tracking-[-0.14px] underline [font-family:var(--font-family)]"
            href={ROUTES.FAVORITES}
          >
            View All
          </Link>
        ) : undefined
      }
      count={savedVehicles.length}
      iconAlt="Saved Vehicles"
      iconSrc="/images/garage/heart-filled.svg"
      scrollHeight="h-78"
      title="Saved Vehicles"
    >
      {savedVehicles.length === 0 ? (
        <p className="px-4 py-2 text-gray-500 text-sm">No saved vehicles yet</p>
      ) : (
        savedVehicles.map((props, idx) => (
          <Fragment key={props.id}>
            <SavedVehicleCard
              {...props}
              onClick={onSavedVehicleClick ? () => onSavedVehicleClick(props.id) : undefined}
              onRemove={onRemoveSavedVehicle ? () => onRemoveSavedVehicle(props.id) : undefined}
            />
            {idx !== savedVehicles.length - 1 && (
              <div className="h-px w-full bg-black opacity-10" />
            )}
          </Fragment>
        ))
      )}
    </GarageCardPanel>

    <GarageCardPanel
      action={
        recentSearches.length > 0 && onClearAllSearches ? (
          <Button
            className="h-auto p-0 font-normal text-[length:var(--font-size-sm,14px)] text-[var(--Core-surfaces-foreground,#0A0A0A)] leading-[125%] tracking-[-0.14px] underline [font-family:var(--font-family)]"
            onClick={onClearAllSearches}
            variant="link"
          >
            Clear All
          </Button>
        ) : undefined
      }
      count={recentSearches.length}
      iconAlt="Recent Searches"
      iconSrc="/images/garage/stars-icon.svg"
      scrollHeight="h-55"
      title="Recent Searches"
    >
      {recentSearches.length === 0 ? (
        <p className="px-4 py-2 text-gray-500 text-sm">No recent searches yet</p>
      ) : (
        recentSearches.map((props, idx) => (
          <Fragment key={props.id}>
            <RecentSearchCard
              {...props}
              onRemove={onRemoveSearch ? () => onRemoveSearch(props.id) : undefined}
            />
            {idx !== recentSearches.length - 1 && (
              <div className="h-px w-full bg-black opacity-10" />
            )}
          </Fragment>
        ))
      )}
    </GarageCardPanel>

    <div className="flex min-w-65 flex-1 flex-col gap-4">
      <FinancingCard {...financing} />
      <TradeOfferCard {...tradeOffer} />
      {testDrive && <TestDriveCard {...testDrive} />}
    </div>
  </div>
);
