import type { ReactNode } from "react";

interface SrpShellProps {
  children?: ReactNode;
  initialBodyType?: string;
}

/**
 * SrpShell — pure RSC that server-renders the SRP hero heading and filter chrome.
 *
 * No "use client" directive — this component renders entirely on the server so
 * the browser receives meaningful HTML on the first byte (fixes bug 1.2).
 *
 * Children (typically SearchWrapper wrapped in Suspense) are streamed in after
 * the static shell is delivered.
 */
export function SrpShell({ children, initialBodyType }: SrpShellProps) {
  return (
    <div className="flex min-h-screen flex-col bg-gray-50">
      {/* Hero section — server-rendered so FCP is not blank */}
      <section className="bg-[var(--color-core-surfaces-background)] py-[var(--spacing-10)] pt-8 pb-6 md:pb-[var(--spacing-lg)]">
        <div className="mx-auto max-w-[var(--container-2xl)] px-0 sm:px-[var(--spacing-lg)] lg:px-[var(--spacing-4xl)]">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
            {/* Heading — the key content that must be in the server HTML */}
            <div className="flex flex-col items-center justify-center text-center md:items-start md:justify-start md:text-left">
              <h1 className="mb-6 font-bold text-[color:var(--color-core-surfaces-foreground)] uppercase leading-[56px] tracking-[-0.449px] md:mb-0 md:text-[length:var(--text-2xl)] lg:text-[length:var(--text-2xl)]">
                FIND YOUR NEXT CAR
              </h1>
              {initialBodyType && (
                <p className="font-normal text-[15px] text-brand-text-primary capitalize leading-normal">
                  {initialBodyType}
                </p>
              )}
            </div>

            {/* Filter chrome placeholder — static shell, no data needed */}
            <div className="relative w-full min-w-0 max-w-[848px] flex-1 pt-4">
              <div aria-hidden="true" className="h-12 w-full rounded-md bg-gray-100" />
            </div>
          </div>
        </div>
      </section>

      {/* Dynamic content — SearchWrapper streams in via Suspense */}
      {children}
    </div>
  );
}
