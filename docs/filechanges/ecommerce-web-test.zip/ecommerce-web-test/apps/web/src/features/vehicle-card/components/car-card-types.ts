import type { ActiveFilter } from "@features/search";

export interface EstimationData {
  apr: string;
  creditScore: string;
  estimatedMonthlyPayment: string;
  termLength: string;
}

export interface CarCardProps {
  activeFilters?: ActiveFilter[];
  badge?: {
    type: "excellent" | "available" | "priceDrop";
    text: string;
  };
  carImage: string | string[];
  carName: string;
  dealerName: string;
  distance: string;
  enablePreviewModal?: boolean;
  estimatedPayment: string;
  estimation?: EstimationData;
  exteriorColor: string;
  exteriorColorGradient?: string;
  exteriorColorHex: string;
  features?: {
    warranty?: boolean;
    inspected?: boolean;
    oneOwner?: boolean;
  };
  interiorColor: string;
  interiorColorHex: string;
  // Optional VDP route segments — used to build the VDP URL and populate the preview modal
  make?: string;
  matchPercentage?: string;
  mileage: string;
  model?: string;
  onApplyRefineFilters?: (filters: { id: string; label: string }[]) => void;
  onSearch?: () => void;
  owners: number;
  price: string;
  variant?: string;
  vin?: string;
  wasPrice?: string;
  year?: number;
}
