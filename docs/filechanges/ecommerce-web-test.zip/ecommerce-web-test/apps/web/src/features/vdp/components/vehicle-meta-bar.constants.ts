/** Color swatch palettes and helper utilities for VehicleMetaBar. */

export const exteriorColorSwatches: Record<string, string> = {
  "Wind Chill Pearl": "#F4F4F2",
  "Midnight Black Metallic": "#171717",
  "Celestial Silver": "#BFC4C8",
  "Ruby Flare Pearl": "#7A0F1A",
  Blueprint: "#1D3C6A",
  "Magnetic Gray Metallic": "#5F646B",
  "Ice Cap": "#F7F8F8",
  "Classic Silver Metallic": "#A7ADB3",
  "Supersonic Red": "#A61C30",
  Underground: "#3E3E43",
  "Cavalry Blue": "#4A6F9E",
  "Lunar Rock": "#7D877A",
  "Army Green": "#59624D",
  "Solar Octane": "#E65B0B",
  Terra: "#8A5A44",
  "Smoked Mesquite": "#5C4A40",
  "Heavy Metal": "#676D77",
  "Bronze Oxide": "#8E634D",
  "Storm Cloud": "#4F5560",
  "White Pearl": "#F1F1EE",
};

export const interiorColorSwatches: Record<string, string> = {
  Black: "#1B1B1D",
  "Black SofTex": "#1C1C1E",
  Ash: "#C5C4C0",
  "Ash Fabric": "#C9C6BF",
  Boulder: "#8D8A83",
  Macadamia: "#B59878",
  "Cockpit Red": "#7B1E24",
  "Harvest Beige": "#B8A788",
  Moonstone: "#8F9398",
  "Light Gray": "#C8C9CB",
  "Dark Gray": "#54585F",
  "Saddle Tan": "#8A5A3B",
  "Rich Cream": "#D7C7AE",
  "Noble Brown": "#5C4237",
  "Red Rock": "#7E332C",
  "Gray/Black": "#676B71",
  "Black/Blue": "#28344D",
  "Black/Brown": "#3E322B",
  "Mineral Gray": "#7C8085",
};

import type { VehicleSpecData } from "@features/vdp/data";
import type { PillTone } from "@features/vdp/data/types";

export function getToneClass(tone: PillTone): string {
  if (tone === "success") {
    return "text-[#1F5F28]";
  }
  if (tone === "warning") {
    return "text-[#8A4B00]";
  }
  if (tone === "inactive") {
    return "text-[#888]";
  }
  return "text-[var(--color-core-surface-foreground)]";
}

export function toNumber(value: string): number | null {
  const digits = value.replace(/[^0-9]/g, "");
  if (!digits) {
    return null;
  }
  return Number.parseInt(digits, 10);
}

export function formatMileage(miles: string): string {
  const numericMiles = toNumber(miles);
  if (numericMiles === null) {
    return miles;
  }
  return `${new Intl.NumberFormat("en-US").format(numericMiles)} mi`;
}

export function getSpecValue(specs: VehicleSpecData[], key: string): string | null {
  const found = specs.find((spec) => spec.key === key)?.value;
  return found ?? null;
}

export function swatchColor(colorName: string, palette: Record<string, string>): string {
  return palette[colorName] ?? "#AAAAAA";
}
