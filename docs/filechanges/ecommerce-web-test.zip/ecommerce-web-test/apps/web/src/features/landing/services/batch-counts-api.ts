/**
 * Batch Counts API Client
 *
 * Client-side utility for fetching vehicle counts for multiple search queries
 * in a single API call. Used by the landing page vehicle finder section.
 */

import { API_ROUTES } from "@config/routes/constants";

export interface BatchCountQuery {
  id: string;
  searchQuery: string;
}

export interface BatchCountResponse {
  counts: Record<string, number>;
}

/**
 * Fetch vehicle counts for multiple search queries in one API call.
 *
 * @param queries - Array of query objects with id and searchQuery
 * @returns Promise resolving to a map of id -> count
 *
 * @example
 * ```ts
 * const counts = await fetchBatchCounts([
 *   { id: "under-20k", searchQuery: "cars-under-$20,000" },
 *   { id: "excellent-deals", searchQuery: "shop-excellent-deals" }
 * ]);
 * // { "under-20k": 1234, "excellent-deals": 567 }
 * ```
 */
export async function fetchBatchCounts(
  queries: BatchCountQuery[]
): Promise<Record<string, number>> {
  const response = await fetch(API_ROUTES.SEARCH_BATCH_COUNTS, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify({ queries }),
  });

  if (!response.ok) {
    throw new Error(`Batch counts API failed: ${response.status}`);
  }

  const data = (await response.json()) as BatchCountResponse;
  return data.counts;
}

/**
 * Predefined vehicle finder queries for the landing page.
 * These map to the quick-link cards shown in the vehicle finder section.
 */
export const VEHICLE_FINDER_QUERIES: BatchCountQuery[] = [
  { id: "under-20k", searchQuery: "cars-under-$20,000" },
  { id: "excellent-deals", searchQuery: "shop-excellent-deals" },
  { id: "price-drop", searchQuery: "price-drop" },
  { id: "low-miles", searchQuery: "low-miles" },
];

/**
 * Convenience function to fetch all vehicle finder counts at once.
 *
 * @example
 * ```ts
 * const counts = await fetchVehicleFinderBatchCounts();
 * // { "under-20k": 1234, "excellent-deals": 567, "price-drop": 89, "low-miles": 432 }
 * ```
 */
export function fetchVehicleFinderBatchCounts(): Promise<Record<string, number>> {
  return fetchBatchCounts(VEHICLE_FINDER_QUERIES);
}
