import "@testing-library/jest-dom";
import { fireEvent, render, screen } from "@testing-library/react";
import { act } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// Top-level regex constants (biome: lint/performance/useTopLevelRegex)
const RE_HEART_BUTTON = /heart-button/;
const RE_EXTRA_CLASS = /extra-class/;
const RE_ANIMATE = /animate/;
const RE_H9 = /h-9/;
const RE_W9 = /w-9/;

// Test-controlled mocks — updated per-test via the variables below.
let isVehicleSavedMock = (_vin: string) => false;
const toggleVehicleMock = vi.fn();

vi.mock("@features/favorites/context/favorites-provider", () => ({
  useFavorites: () => ({
    isVehicleSaved: (vin: string) => isVehicleSavedMock(vin),
    toggleVehicle: toggleVehicleMock,
  }),
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({ children, ...props }: any) => (
    <button data-testid="fav-button" {...props}>
      {children}
    </button>
  ),
}));

vi.mock("next/image", () => ({
  __esModule: true,
  default: ({ src, alt, ...rest }: any) => (
    // biome-ignore lint/performance/noImgElement: intentional test mock for next/image
    <img
      alt={alt as string}
      data-testid="fav-image"
      height={1}
      src={src as string}
      width={1}
      {...rest}
    />
  ),
}));

import { FavoriteButton } from "./favorite-button";

describe("FavoriteButton — functionality tests", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    // default to not-saved unless a test overrides it
    isVehicleSavedMock = () => false;
  });

  const cleanupTimers = () => {
    vi.useRealTimers();
  };

  afterEach(cleanupTimers);

  it("renders in unliked state with correct aria-label, classes and image", () => {
    render(<FavoriteButton className="extra-class" vin="VIN123" />);

    const btn = screen.getByTestId("fav-button");
    expect(btn).toBeInTheDocument();
    expect(btn).toHaveAttribute("aria-label", "Add to favorites");
    expect(btn.className).toMatch(RE_HEART_BUTTON);
    expect(btn.className).toMatch(RE_EXTRA_CLASS);

    const img = screen.getByTestId("fav-image");
    expect(img).toBeInTheDocument();
    expect(img).toHaveAttribute("alt", "Favorite");
    expect(img.getAttribute("src") ?? "").toContain("heart.svg");
    expect(img.getAttribute("src") ?? "").not.toContain("-filled");
  });

  it("renders in liked state (filled heart) and correct aria-label", () => {
    isVehicleSavedMock = () => true;
    render(<FavoriteButton vin="VIN123" />);

    const btn = screen.getByTestId("fav-button");
    expect(btn).toHaveAttribute("aria-label", "Remove from favorites");

    const img = screen.getByTestId("fav-image");
    expect(img.getAttribute("src") ?? "").toContain("heart-filled.svg");
  });

  it("calls toggleVehicle with vin, stops propagation and applies animation class for 500ms", () => {
    // use fake timers to test the 500ms animation lifecycle
    vi.useFakeTimers();

    const parentClick = vi.fn();

    const { unmount } = render(
      // biome-ignore lint/a11y/useSemanticElements: test wrapper — nesting <button> inside <button> is invalid HTML
      <div
        data-testid="parent"
        onClick={parentClick}
        onKeyUp={parentClick}
        role="button"
        tabIndex={0}
      >
        <FavoriteButton vin="VIN-CLICK" />
      </div>
    );

    const btn = screen.getByTestId("fav-button");

    act(() => {
      fireEvent.click(btn);
    });

    // toggleVehicle should be invoked with the provided VIN
    expect(toggleVehicleMock).toHaveBeenCalledWith("VIN-CLICK");

    // parent click should not have been invoked due to stopPropagation
    expect(parentClick).not.toHaveBeenCalled();

    // animation class should be applied immediately
    expect(btn.className).toMatch(RE_ANIMATE);

    // advance time by 500ms to let the effect clear animation
    act(() => {
      vi.advanceTimersByTime(500);
    });

    // after timeout, animation class should be removed
    expect(btn.className).not.toMatch(RE_ANIMATE);

    // ensure cleanup on unmount doesn't throw
    unmount();
  });

  it("cleans up the timeout when unmounted while animating", () => {
    vi.useFakeTimers();

    const { unmount } = render(<FavoriteButton vin="VIN-UNMOUNT" />);
    const btn = screen.getByTestId("fav-button");

    act(() => {
      fireEvent.click(btn);
    });

    // unmount immediately (before timeout) to trigger cleanup
    expect(() => unmount()).not.toThrow();

    // advance timers to ensure cleared timer doesn't attempt setState
    act(() => vi.advanceTimersByTime(1000));
  });

  it("click when already liked still toggles and animates (filled heart)", () => {
    vi.useFakeTimers();
    isVehicleSavedMock = () => true;

    render(<FavoriteButton vin="VIN-LIKED" />);

    const btn = screen.getByTestId("fav-button");
    const img = screen.getByTestId("fav-image");

    // initial should show filled heart
    expect(img.getAttribute("src") ?? "").toContain("heart-filled.svg");

    act(() => {
      fireEvent.click(btn);
    });

    expect(toggleVehicleMock).toHaveBeenCalledWith("VIN-LIKED");
    expect(btn.className).toMatch(RE_ANIMATE);

    act(() => {
      vi.advanceTimersByTime(500);
    });

    expect(btn.className).not.toMatch(RE_ANIMATE);
  });

  it("accepts an explicit empty className and forwards native button props", () => {
    // Render with empty string className to exercise the nullish coalescing branch
    render(<FavoriteButton className="" vin="VIN-EMPTY" />);

    const btn = screen.getByTestId("fav-button");

    // base class must always be present; empty className should not break merging
    expect(btn.className).toMatch(RE_HEART_BUTTON);

    // props from the component should be forwarded to the native button element
    expect(btn).toHaveAttribute("type", "button");
    // size/variant are passed to the UI Button API but may not appear as DOM
    // attributes in this environment; assert visible class pieces instead.
    expect(btn.className).toMatch(RE_H9);
    expect(btn.className).toMatch(RE_W9);
  });

  it("handles multiple quick clicks without throwing and toggles each time", () => {
    vi.useFakeTimers();

    const { unmount } = render(<FavoriteButton vin="VIN-DOUBLE" />);
    const btn = screen.getByTestId("fav-button");

    act(() => {
      fireEvent.click(btn);
      fireEvent.click(btn);
    });

    // toggle should be called for each click
    expect(toggleVehicleMock).toHaveBeenCalledWith("VIN-DOUBLE");
    expect(toggleVehicleMock).toHaveBeenCalledTimes(2);

    // animation class present and cleared after 500ms
    expect(btn.className).toMatch(RE_ANIMATE);
    act(() => vi.advanceTimersByTime(500));
    expect(btn.className).not.toMatch(RE_ANIMATE);

    unmount();
    vi.useRealTimers();
  });

  it("does not schedule a timer when not animating, schedules after click", () => {
    vi.useFakeTimers();

    render(<FavoriteButton vin="VIN-TIMER" />);

    // no timers scheduled on initial mount
    // vi.getTimerCount may be provided by the fake timer implementation
    // if unavailable this assertion is a no-op in environments without it
    try {
      expect(vi.getTimerCount()).toBe(0);
    } catch {
      // ignore if the runtime doesn't expose getTimerCount
    }

    const btn = screen.getByTestId("fav-button");

    act(() => {
      fireEvent.click(btn);
    });

    // clicking should schedule the 500ms timeout
    try {
      expect(vi.getTimerCount()).toBeGreaterThan(0);
    } catch {
      // ignore if unavailable
    }

    act(() => vi.advanceTimersByTime(500));
    expect(btn.className).not.toMatch(RE_ANIMATE);

    vi.useRealTimers();
  });

  it("preserves handleClick identity across re-renders when deps unchanged", () => {
    const { rerender } = render(<FavoriteButton vin="VIN-MEMO" />);

    const firstBtn = screen.getByTestId("fav-button") as HTMLButtonElement;
    const first = (firstBtn as any).onclick;

    // re-render with same props should keep the callback identity
    rerender(<FavoriteButton vin="VIN-MEMO" />);

    const secondBtn = screen.getByTestId("fav-button") as HTMLButtonElement;
    const second = (secondBtn as any).onclick;

    expect(first).toBe(second);
  });
});
