import "@testing-library/jest-dom";
import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

let savedVins: string[] = [];
let queryDataReturnUndefined = false;

vi.mock("@features/favorites/queries/saved-vehicles", () => ({
  savedVehicleQueries: {
    all: () => ({ queryKey: ["savedVins"] }),
  },
}));

const saveVehicleMock = vi.fn((vin: string) => Promise.resolve(vin));
const unsaveVehicleMock = vi.fn((vin: string) => Promise.resolve(vin));
const clearAllMock = vi.fn(() => Promise.resolve());

vi.mock("@features/favorites/services/saved-vehicles-api", () => ({
  saveVehicle: (vin: any) => saveVehicleMock(vin),
  unsaveVehicle: (vin: any) => unsaveVehicleMock(vin),
  clearAllSavedVehicles: () => clearAllMock(),
}));

vi.mock("@shared/hooks/use-optimistic-list-mutation", () => ({
  useOptimisticListMutation: ({ updater, mutationFn }: any) => ({
    mutate: (arg: any) => {
      savedVins = updater(savedVins, arg);
      return mutationFn(arg);
    },
  }),
}));

vi.mock("@tanstack/react-query", () => ({
  useQuery: () => ({ data: savedVins, isFetched: true }),
  useQueryClient: () => ({
    getQueryData: () => (queryDataReturnUndefined ? undefined : savedVins),
  }),
}));

import { FavoritesProvider, useFavorites } from "./favorites-provider";

function Consumer() {
  const {
    savedCount,
    savedVins,
    isLoaded,
    addVehicle,
    removeVehicle,
    toggleVehicle,
    clearAll,
    isVehicleSaved,
  } = useFavorites();

  return (
    <div>
      <div data-testid="count">{savedCount}</div>
      <div data-testid="loaded">{isLoaded ? "1" : "0"}</div>
      <div data-testid="list">{savedVins.join(",")}</div>

      <button data-testid="add" onClick={() => addVehicle("A")} type="button">
        add A
      </button>
      <button data-testid="remove" onClick={() => removeVehicle("A")} type="button">
        remove A
      </button>
      <button data-testid="toggle" onClick={() => toggleVehicle("B")} type="button">
        toggle B
      </button>
      <button data-testid="clear" onClick={() => clearAll()} type="button">
        clear
      </button>
      <div data-testid="isSavedA">{isVehicleSaved("A") ? "1" : "0"}</div>
    </div>
  );
}

describe("FavoritesProvider functionality", () => {
  beforeEach(() => {
    savedVins = [];
    queryDataReturnUndefined = false;
    vi.clearAllMocks();
  });

  it("exposes initial values and add/remove/toggle/clear work", () => {
    const { rerender } = render(
      <FavoritesProvider>
        <Consumer />
      </FavoritesProvider>
    );

    // initial
    expect(screen.getByTestId("count").textContent).toBe("0");
    expect(screen.getByTestId("loaded").textContent).toBe("1");
    expect(screen.getByTestId("isSavedA").textContent).toBe("0");

    // add A
    fireEvent.click(screen.getByTestId("add"));
    rerender(
      <FavoritesProvider>
        <Consumer />
      </FavoritesProvider>
    );
    // optimistic updater updates savedVins synchronously in our mock
    expect(saveVehicleMock).toHaveBeenCalledWith("A");
    expect(screen.getByTestId("count").textContent).toBe("1");
    expect(screen.getByTestId("list").textContent).toBe("A");
    expect(screen.getByTestId("isSavedA").textContent).toBe("1");

    // add A again should be no-op
    fireEvent.click(screen.getByTestId("add"));
    rerender(
      <FavoritesProvider>
        <Consumer />
      </FavoritesProvider>
    );
    expect(screen.getByTestId("count").textContent).toBe("1");

    // remove A
    fireEvent.click(screen.getByTestId("remove"));
    rerender(
      <FavoritesProvider>
        <Consumer />
      </FavoritesProvider>
    );
    expect(unsaveVehicleMock).toHaveBeenCalledWith("A");
    expect(screen.getByTestId("count").textContent).toBe("0");

    // toggle B: currently not present -> adds
    fireEvent.click(screen.getByTestId("toggle"));
    rerender(
      <FavoritesProvider>
        <Consumer />
      </FavoritesProvider>
    );
    expect(saveVehicleMock).toHaveBeenCalledWith("B");
    expect(screen.getByTestId("list").textContent).toBe("B");

    // toggle B again -> removes
    fireEvent.click(screen.getByTestId("toggle"));
    rerender(
      <FavoritesProvider>
        <Consumer />
      </FavoritesProvider>
    );
    expect(unsaveVehicleMock).toHaveBeenCalledWith("B");
    expect(screen.getByTestId("count").textContent).toBe("0");

    // add two, then clear
    fireEvent.click(screen.getByTestId("add")); // adds A
    rerender(
      <FavoritesProvider>
        <Consumer />
      </FavoritesProvider>
    );
    fireEvent.click(screen.getByTestId("toggle")); // toggles B -> adds B
    rerender(
      <FavoritesProvider>
        <Consumer />
      </FavoritesProvider>
    );
    expect(screen.getByTestId("count").textContent).toBe("2");
    fireEvent.click(screen.getByTestId("clear"));
    rerender(
      <FavoritesProvider>
        <Consumer />
      </FavoritesProvider>
    );
    expect(clearAllMock).toHaveBeenCalled();
    expect(screen.getByTestId("count").textContent).toBe("0");
  });

  it("toggleVehicle falls back to empty list when getQueryData returns undefined (??[] branch)", () => {
    queryDataReturnUndefined = true;

    render(
      <FavoritesProvider>
        <Consumer />
      </FavoritesProvider>
    );

    // cache returns undefined → falls back to [] → VIN not present → doSave is called
    fireEvent.click(screen.getByTestId("toggle"));
    expect(saveVehicleMock).toHaveBeenCalledWith("B");
  });

  it("useFavorites throws when used outside FavoritesProvider", () => {
    function Broken() {
      // calling the hook without a provider should throw
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const _ = (useFavorites as any)();
      return null;
    }

    expect(() => render(<Broken />)).toThrow(
      "useFavorites must be used within a <FavoritesProvider>"
    );
  });
});
