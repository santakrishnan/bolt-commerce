import type { FilterState } from "@features/search/components/filter-sidebar/types";
import { defaultFilterState } from "@features/search/components/filter-sidebar/types";
import { generateQuickFilterPills } from "@features/search/components/search-bar/services/nlp-autocomplete";
import { SearchClient } from "@features/search/context/search-client";
import { filterSections } from "@features/search/lib/filter-sections";
import { getInventoryPool } from "@features/search/lib/mock-faceted-search";
import { Suspense } from "react";
import { SearchProvider } from "./search-context";

interface SearchWrapperProps {
  initialBodyType?: string;
  initialSearchQuery?: string;
  initialUrlFilters?: Partial<FilterState>;
}

export function SearchWrapper({
  initialBodyType,
  initialSearchQuery,
  initialUrlFilters,
}: SearchWrapperProps = {}) {
  // Compute quick-filter pills server-side to avoid client-side promises.
  const pool = getInventoryPool();
  const suggestedPills = generateQuickFilterPills(pool);
  // Resolve path slug to canonical body style so initial filters match provider expectations.
  const initialBodyStyles: string[] = [];
  if (initialBodyType) {
    const match = filterSections.bodyStyle.find(
      (s) => s.toLowerCase() === initialBodyType.toLowerCase()
    );
    if (match) {
      initialBodyStyles.push(match);
    }
  }

  // Merge any URL-provided body styles with the resolved path-based type
  if (initialUrlFilters?.selectedBodyStyles) {
    for (const bodyStyle of initialUrlFilters.selectedBodyStyles) {
      if (!initialBodyStyles.includes(bodyStyle)) {
        initialBodyStyles.push(bodyStyle);
      }
    }
  }

  // Keep the raw search query from the URL; the search service normalizes semantics.
  const resolvedSearchQuery = initialSearchQuery ?? "";

  // Key forces full remount of `SearchClient` when URL-derived inputs change,
  // preventing stale state from previous navigations.
  const clientKey = `${initialBodyType ?? ""}|${initialSearchQuery ?? ""}|${JSON.stringify(initialUrlFilters ?? {})}`;

  return (
    <SearchProvider
      defaultFilterState={defaultFilterState}
      initialBodyStyles={initialBodyStyles}
      initialSearchQuery={resolvedSearchQuery}
      initialUrlFilters={initialUrlFilters}
      key={clientKey}
    >
      <Suspense fallback={null}>
        <SearchClient initialQuickFilters={suggestedPills} />
      </Suspense>
    </SearchProvider>
  );
}
