/** Filter-building helpers for RefineSearchModal. */

import { buildAllAvailableFilters } from "@features/search/lib/mock-search-service";
import type { Vehicle } from "@features/search/lib/mock-vehicles";
import { slugify } from "utils";

export interface FilterOption {
  id: string;
  label: string;
}

/** Number of filters shown per section (Your Filters / Suggested). */
export const FILTERS_PER_SECTION = 6;

/**
 * Build the "Your Filters" and "Suggested" lists from the mock search service.
 *
 * "Your Filters" = top comfort + tech features the user is most likely to care
 * about (first 6). "Suggested" = safety + exterior + performance features the
 * service reports as available (next 6). This replaces the old hardcoded arrays
 * so the refine modal always reflects the real vehicle inventory.
 */
export function buildFilterOptions(vehicles: Vehicle[]): {
  yourFilters: FilterOption[];
  suggestedFilters: FilterOption[];
  allFilters: FilterOption[];
} {
  const available = buildAllAvailableFilters(vehicles);

  const yourLabels = [...available.comfortFeatures, ...available.techFeatures];
  const yourFilters: FilterOption[] = yourLabels
    .slice(0, FILTERS_PER_SECTION)
    .map((label) => ({ id: slugify(label), label }));

  const suggestedLabels = [
    ...available.safetyFeatures,
    ...available.exteriorFeatures,
    ...available.performanceFeatures,
  ];
  const suggestedFilters: FilterOption[] = suggestedLabels
    .slice(0, FILTERS_PER_SECTION)
    .map((label) => ({ id: slugify(label), label }));

  return {
    yourFilters,
    suggestedFilters,
    allFilters: [...yourFilters, ...suggestedFilters],
  };
}
