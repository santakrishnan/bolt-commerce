import { getBadgeType, parseDealerInfo } from "@features/my-garage/lib/helpers";
import type { Vehicle } from "@features/search/lib/mock-vehicles";
import { getVehicleEstimation } from "@features/search/lib/mock-vehicles";
import { CarCard } from "@features/vehicle-card";

interface GarageCarCardProps {
  /** Override the badge derived from car.labels — e.g. force "priceDrop" */
  badgeOverride?: { type: "excellent" | "available" | "priceDrop"; text: string };
  car: Vehicle;
}

export function GarageCarCard({ car, badgeOverride }: GarageCarCardProps) {
  const { dealerName, distance } = parseDealerInfo(car.miles);
  const estimation = getVehicleEstimation(car);
  const firstLabel = car.labels[0];
  const badgeType = getBadgeType(firstLabel);
  const badge =
    badgeOverride ?? (badgeType && firstLabel ? { type: badgeType, text: firstLabel } : undefined);

  return (
    <CarCard
      badge={badge}
      carImage={car.image}
      carName={car.title}
      dealerName={dealerName}
      distance={distance}
      estimatedPayment={`Est. ${estimation.estimatedMonthlyPayment}/mo`}
      estimation={estimation}
      exteriorColor={car.extColorName}
      exteriorColorHex={car.extColorCode}
      features={{ warranty: true, inspected: true, oneOwner: car.owners === 1 }}
      interiorColor={car.intColorName}
      interiorColorHex={car.intColorCode}
      make={car.make}
      matchPercentage={car.match > 0 ? String(car.match) : undefined}
      mileage={car.odometer}
      model={car.model}
      owners={car.owners}
      price={`$${car.price.toLocaleString()}`}
      variant={car.variant}
      vin={car.vin}
      wasPrice={car.oldPrice ? `$${car.oldPrice.toLocaleString()}` : undefined}
      year={car.year}
    />
  );
}
