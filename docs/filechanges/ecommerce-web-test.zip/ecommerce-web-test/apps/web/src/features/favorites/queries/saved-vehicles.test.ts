import { SAVED_REGISTRY_STALE_TIME } from "@config/queries/constants";
import { getAllSavedVehicles } from "@features/favorites/services/saved-vehicles-api";
import { describe, expect, it } from "vitest";
import { savedVehicleQueries } from "./saved-vehicles";

describe("savedVehicleQueries — unit", () => {
  it("returns query options with correct key, fn, placeholder and staleTime", () => {
    const opts = savedVehicleQueries.all();

    // queryKey should be the centralised cache key
    expect(opts.queryKey).toEqual(["saved-vehicles"]);

    // queryFn should reference the service function (do not call it)
    expect(opts.queryFn).toBe(getAllSavedVehicles);

    // placeholder data must be an empty list (type: string[])
    expect(opts.placeholderData).toEqual([]);

    // staleTime must match the central constant
    expect(opts.staleTime).toBe(SAVED_REGISTRY_STALE_TIME);
  });
});
