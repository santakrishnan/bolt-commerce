import { render, screen } from "@arrow/vitest-config/test-utils";
import type { CSSProperties, ReactNode } from "react";
import { describe, expect, it, vi } from "vitest";

import { HeaderNav } from "../header-nav";

// ---------------------------------------------------------------------------
// Mock next/link as a plain <a> tag so tests stay framework-agnostic and
// we can make real DOM assertions (href, className, style).
// ---------------------------------------------------------------------------
vi.mock("next/link", () => ({
  default: ({
    href,
    className,
    style,
    children,
  }: {
    href: string;
    className?: string;
    style?: CSSProperties;
    children: ReactNode;
  }) => (
    <a className={className} href={href} style={style}>
      {children}
    </a>
  ),
}));

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const NAV_LINKS = ["Buy", "Finance", "Why Arrow"] as const;
const NAV_HREFS: Record<(typeof NAV_LINKS)[number], string> = {
  Buy: "/used-cars",
  Finance: "#",
  "Why Arrow": "#",
};

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("HeaderNav", () => {
  // ── Rendered structure ────────────────────────────────────────────────────

  describe("rendered structure", () => {
    it("renders a <nav> landmark", () => {
      render(<HeaderNav useSolidStyles={false} />);

      expect(screen.getByRole("navigation")).toBeInTheDocument();
    });

    it("renders exactly three navigation links", () => {
      render(<HeaderNav useSolidStyles={false} />);

      expect(screen.getAllByRole("link")).toHaveLength(3);
    });

    it.each(NAV_LINKS)('renders "%s" link', (name) => {
      render(<HeaderNav useSolidStyles={false} />);

      expect(screen.getByRole("link", { name })).toBeInTheDocument();
    });

    it.each(NAV_LINKS)('"%s" link points to the expected route', (name) => {
      render(<HeaderNav useSolidStyles={false} />);

      expect(screen.getByRole("link", { name })).toHaveAttribute("href", NAV_HREFS[name]);
    });
  });

  // ── Conditional styles: useSolidStyles=true ───────────────────────────────

  describe("when useSolidStyles is true (solid / dark header)", () => {
    it("applies text-text-dark to every link", () => {
      render(<HeaderNav useSolidStyles={true} />);

      for (const link of screen.getAllByRole("link")) {
        expect(link).toHaveClass("text-text-dark");
      }
    });

    it("does NOT apply text-white to any link", () => {
      render(<HeaderNav useSolidStyles={true} />);

      for (const link of screen.getAllByRole("link")) {
        expect(link).not.toHaveClass("text-white");
      }
    });
  });

  // ── Conditional styles: useSolidStyles=false ──────────────────────────────

  describe("when useSolidStyles is false (transparent / light header)", () => {
    it("applies text-white to every link", () => {
      render(<HeaderNav useSolidStyles={false} />);

      for (const link of screen.getAllByRole("link")) {
        expect(link).toHaveClass("text-white");
      }
    });

    it("does NOT apply text-text-dark to any link", () => {
      render(<HeaderNav useSolidStyles={false} />);

      for (const link of screen.getAllByRole("link")) {
        expect(link).not.toHaveClass("text-text-dark");
      }
    });
  });

  // ── Static classes (present in both modes) ────────────────────────────────

  describe("static Tailwind classes applied regardless of useSolidStyles", () => {
    it.each([
      true,
      false,
    ])("links carry base typography classes when useSolidStyles=%s", (useSolidStyles) => {
      render(<HeaderNav useSolidStyles={useSolidStyles} />);

      for (const link of screen.getAllByRole("link")) {
        expect(link).toHaveClass("font-normal");
        expect(link).toHaveClass("text-sm");
        expect(link).toHaveClass("leading-none");
      }
    });
  });

  // ── Inline style: Toyota Type font variable ───────────────────────────────

  describe("inline font-family style", () => {
    it.each([
      true,
      false,
    ])("links declare the toyota-type CSS variable when useSolidStyles=%s", (useSolidStyles) => {
      render(<HeaderNav useSolidStyles={useSolidStyles} />);

      for (const link of screen.getAllByRole("link")) {
        // Access the DOM CSSStyleDeclaration directly – CSS vars are not
        // resolved by jsdom, so toHaveStyle() is unreliable here.
        expect((link as HTMLElement).style.fontFamily).toBe("var(--font-toyota-type)");
      }
    });
  });
});
