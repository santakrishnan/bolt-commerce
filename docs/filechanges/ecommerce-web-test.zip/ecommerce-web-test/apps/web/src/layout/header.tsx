// No "use client" directive — this is an async React Server Component
import { DEFAULT_USER, FLAG_COOKIE_NAME, mockUsers } from "@config/flags/config";
import { cookies } from "next/headers";
import { HeaderClient } from "./header/header-client";

export async function Header() {
  const cookieStore = await cookies();
  const userCookie = cookieStore.get(FLAG_COOKIE_NAME);
  const user = (userCookie?.value ? mockUsers[userCookie.value] : undefined) ?? DEFAULT_USER;

  // Keep develop behavior: avatar visibility is driven by auth state.
  return (
    <HeaderClient
      initialFirstName={user.firstName}
      initialShowPersonalized={user.isAuthenticated === true}
    />
  );
}
