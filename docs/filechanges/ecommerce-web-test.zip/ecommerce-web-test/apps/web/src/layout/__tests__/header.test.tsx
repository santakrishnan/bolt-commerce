import { act, fireEvent, render, screen } from "@arrow/vitest-config/test-utils";
import type { ReactNode } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// Top-level regex constants (biome useTopLevelRegex)
const LOGO_LINK_RE = /ARROW/i;

import { HeaderClient } from "../header/header-client";

// ---------------------------------------------------------------------------
// Mocks
// ---------------------------------------------------------------------------

// next/navigation — usePathname is controlled per-test
const mockUsePathname = vi.fn(() => "/");
vi.mock("next/navigation", () => ({
  usePathname: () => mockUsePathname(),
}));

// @config/flags/client — auth state source used by renderHeader helper
const mockGetCurrentUserSync = vi.fn(() => ({ firstName: "Guest", isAuthenticated: false }));
vi.mock("@config/flags/client", () => ({
  getCurrentUserSync: () => mockGetCurrentUserSync(),
}));

// @config/routes/constants — stable route values
vi.mock("@config/routes/constants", () => ({
  ROUTES: { HOME: "/", MY_GARAGE: "/my-garage" },
}));

// @shared/lib/body-scroll-lock — verify lock/unlock lifecycle
const mockLockBodyScroll = vi.fn();
const mockUnlockBodyScroll = vi.fn();
vi.mock("@shared/lib/body-scroll-lock", () => ({
  lockBodyScroll: () => mockLockBodyScroll(),
  unlockBodyScroll: () => mockUnlockBodyScroll(),
}));

// @shared/providers/location-provider — controlled per-test
const mockUseLocation = vi.fn();
vi.mock("@shared/providers/location-provider", () => ({
  useLocation: () => mockUseLocation(),
}));

// @tfs-ucmp/ui — Button forwards aria-label + onClick; MenuIcon is a stub
vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({
    children,
    onClick,
    "aria-label": ariaLabel,
  }: {
    children: ReactNode;
    onClick?: () => void;
    "aria-label"?: string;
  }) => (
    <button aria-label={ariaLabel} onClick={onClick} type="button">
      {children}
    </button>
  ),
  MenuIcon: () => <svg aria-hidden="true" data-testid="menu-icon" />,
}));

// next/link — plain <a>
vi.mock("next/link", () => ({
  default: ({
    href,
    children,
    className,
  }: {
    href: string;
    children: ReactNode;
    className?: string;
  }) => (
    <a className={className} href={href}>
      {children}
    </a>
  ),
}));

// Child component stubs — expose useSolidStyles as data attribute so tests
// can assert the derived value without coupling to CSS class strings.
vi.mock("../header/header-nav", () => ({
  HeaderNav: ({ useSolidStyles }: { useSolidStyles: boolean }) => (
    <nav aria-label="main-nav" data-solid={String(useSolidStyles)} data-testid="header-nav" />
  ),
}));

vi.mock("../header/favorites-button", () => ({
  FavoritesButton: ({ useSolidStyles }: { useSolidStyles: boolean }) => (
    <div data-solid={String(useSolidStyles)} data-testid="favorites-button" />
  ),
}));

// Capture LocationBlock's onModalOpenChange so tests can trigger it
let triggerLocationModal: ((open: boolean) => void) | undefined;
vi.mock("../header/location-block", () => ({
  LocationBlock: ({
    useSolidStyles,
    onModalOpenChange,
  }: {
    useSolidStyles: boolean;
    onModalOpenChange?: (open: boolean) => void;
  }) => {
    triggerLocationModal = onModalOpenChange;
    return <div data-solid={String(useSolidStyles)} data-testid="location-block" />;
  },
}));

vi.mock("../header/auth-buttons", () => ({
  AvatarButton: ({ firstName, useSolidStyles }: { firstName: string; useSolidStyles: boolean }) => (
    <div
      data-first-name={firstName}
      data-solid={String(useSolidStyles)}
      data-testid="avatar-button"
    />
  ),
  SignInButton: ({ useSolidStyles }: { useSolidStyles: boolean }) => (
    <div data-solid={String(useSolidStyles)} data-testid="sign-in-button" />
  ),
  MobileUserButton: ({
    firstName,
    showAvatar,
    useSolidStyles,
  }: {
    firstName: string;
    showAvatar: boolean;
    useSolidStyles: boolean;
  }) => (
    <div
      data-first-name={firstName}
      data-show-avatar={String(showAvatar)}
      data-solid={String(useSolidStyles)}
      data-testid="mobile-user-button"
    />
  ),
}));

// Capture MobileMenu's onClose so tests can trigger close programmatically
let triggerMobileMenuClose: (() => void) | undefined;
vi.mock("../header/mobile-menu", () => ({
  MobileMenu: ({ onClose }: { onClose: () => void }) => {
    triggerMobileMenuClose = onClose;
    return <div data-testid="mobile-menu" />;
  },
}));

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function setupLocation(isResolved = true) {
  mockUseLocation.mockReturnValue({
    state: { isResolved },
    actions: {},
  });
}

/** Override window.scrollY (read-only in jsdom, requires defineProperty). */
function setScrollY(y: number) {
  Object.defineProperty(window, "scrollY", {
    get: () => y,
    configurable: true,
  });
}

/** Click the hamburger button (aria-label changes based on state). */
function clickHamburger() {
  const btn =
    screen.queryByRole("button", { name: "Open menu" }) ??
    screen.getByRole("button", { name: "Close menu" });
  fireEvent.click(btn);
}

/**
 * Render the client header with server-derived props.
 *
 * The Header component is now an async Server Component wrapper, so unit tests
 * that validate interactive behavior target HeaderClient directly and feed it
 * deterministic props from these test-local mocks.
 */
function renderHeader() {
  const user = mockGetCurrentUserSync();

  return render(
    <HeaderClient
      initialFirstName={user.firstName}
      initialShowPersonalized={user.isAuthenticated === true}
    />
  );
}

// ---------------------------------------------------------------------------
// Global test setup
// ---------------------------------------------------------------------------

beforeEach(() => {
  vi.clearAllMocks();
  triggerLocationModal = undefined;
  triggerMobileMenuClose = undefined;
  mockGetCurrentUserSync.mockReturnValue({ firstName: "Guest", isAuthenticated: false });
  mockUsePathname.mockReturnValue("/");
  setScrollY(0);
  document.documentElement.classList.remove("bg-white", "bg-black");
});

afterEach(() => {
  setScrollY(0);
  document.documentElement.classList.remove("bg-white", "bg-black");
});

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("Header", () => {
  // ── Invariant structure ────────────────────────────────────────────────────

  describe("invariant structure", () => {
    it("renders the ARROW logo link pointing to '/'", () => {
      setupLocation();
      renderHeader();

      const logo = screen.getByRole("link", { name: LOGO_LINK_RE });
      expect(logo).toBeInTheDocument();
      expect(logo).toHaveAttribute("href", "/");
    });

    it("renders HeaderNav", () => {
      setupLocation();
      renderHeader();

      expect(screen.getByTestId("header-nav")).toBeInTheDocument();
    });

    it("renders LocationBlock (desktop cluster)", () => {
      setupLocation();
      renderHeader();

      expect(screen.getByTestId("location-block")).toBeInTheDocument();
    });

    it("renders MobileUserButton", () => {
      setupLocation();
      renderHeader();

      expect(screen.getByTestId("mobile-user-button")).toBeInTheDocument();
    });

    it("renders the hamburger button with initial aria-label 'Open menu'", () => {
      setupLocation();
      renderHeader();

      expect(screen.getByRole("button", { name: "Open menu" })).toBeInTheDocument();
    });
  });

  // ── useSolidStyles computation ─────────────────────────────────────────────
  // useSolidStyles = !(isHomePage || isMyGaragePage) || isScrolled || locationModalOpen

  describe("useSolidStyles", () => {
    it("is false on the home page when not scrolled", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      renderHeader();

      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "false");
    });

    it("is false on the my-garage page when not scrolled", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/my-garage");
      renderHeader();

      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "false");
    });

    it("is true on any other page (e.g. /used-cars)", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/used-cars");
      renderHeader();

      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "true");
    });

    it("is true on the home page once the user scrolls past 150px", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      setScrollY(151);
      renderHeader();

      // The scroll effect calls update() immediately on mount, picking up scrollY=151
      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "true");
    });

    it("remains false on the home page when scrollY is exactly 150px", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      setScrollY(150);
      renderHeader();

      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "false");
    });

    it("becomes true on the home page after a scroll event pushes scrollY above 150", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      renderHeader();
      // Initially transparent
      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "false");

      setScrollY(200);
      fireEvent.scroll(window);

      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "true");
    });

    it("is true on the home page when the location modal is open", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      renderHeader();
      // Initially transparent
      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "false");

      // Trigger location modal open via the captured callback (direct state
      // setter call — must be wrapped in act())
      expect(triggerLocationModal).toBeDefined();
      act(() => {
        triggerLocationModal?.(true);
      });

      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "true");
    });

    it("reverts to false on the home page when location modal closes", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      renderHeader();

      act(() => {
        triggerLocationModal?.(true);
      });
      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "true");

      act(() => {
        triggerLocationModal?.(false);
      });
      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "false");
    });

    it("propagates useSolidStyles=true to LocationBlock", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/used-cars");
      renderHeader();

      expect(screen.getByTestId("location-block")).toHaveAttribute("data-solid", "true");
    });

    it("propagates useSolidStyles=false to HeaderNav on home page", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      renderHeader();

      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "false");
    });
  });

  // ── Spacer div (only rendered when solid) ─────────────────────────────────

  describe("spacer div (layout padding for fixed header)", () => {
    it("is rendered when useSolidStyles=true", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/used-cars");
      const { container } = renderHeader();

      // The spacer is the aria-hidden div that is a direct sibling of <header>.
      // The inner container div also carries h-16, so we target via adjacency.
      expect(container.querySelector('header + div[aria-hidden="true"]')).toBeInTheDocument();
    });

    it("is NOT rendered when useSolidStyles=false", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      const { container } = renderHeader();

      expect(container.querySelector('header + div[aria-hidden="true"]')).not.toBeInTheDocument();
    });
  });

  // ── document.documentElement class sync ───────────────────────────────────

  describe("html element class synchronisation", () => {
    it("adds bg-white to <html> when useSolidStyles=true", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/used-cars");
      renderHeader();

      expect(document.documentElement.classList.contains("bg-white")).toBe(true);
    });

    it("adds bg-black to <html> when useSolidStyles=false", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      renderHeader();

      expect(document.documentElement.classList.contains("bg-black")).toBe(true);
    });
  });

  // ── FavoritesButton visibility (locationReady gate) ───────────────────────

  describe("FavoritesButton conditional rendering", () => {
    it("renders FavoritesButton in both clusters when isResolved=true", () => {
      setupLocation(true);
      renderHeader();

      // One instance per cluster (mobile + desktop)
      expect(screen.getAllByTestId("favorites-button")).toHaveLength(2);
    });

    it("does NOT render FavoritesButton when isResolved=false", () => {
      setupLocation(false);
      renderHeader();

      expect(screen.queryAllByTestId("favorites-button")).toHaveLength(0);
    });
  });

  // ── Authentication state ───────────────────────────────────────────────────

  describe("auth state from isAuthenticated", () => {
    it("renders SignInButton when isAuthenticated=false", () => {
      setupLocation();
      mockGetCurrentUserSync.mockReturnValue({ firstName: "Guest", isAuthenticated: false });
      renderHeader();

      expect(screen.getByTestId("sign-in-button")).toBeInTheDocument();
      expect(screen.queryByTestId("avatar-button")).not.toBeInTheDocument();
    });

    it("renders AvatarButton when isAuthenticated=true", () => {
      setupLocation();
      mockGetCurrentUserSync.mockReturnValue({ firstName: "Sarah", isAuthenticated: true });
      renderHeader();

      expect(screen.getByTestId("avatar-button")).toBeInTheDocument();
      expect(screen.queryByTestId("sign-in-button")).not.toBeInTheDocument();
    });

    it("passes firstName from getCurrentUserSync to AvatarButton", () => {
      setupLocation();
      mockGetCurrentUserSync.mockReturnValue({ firstName: "Alice", isAuthenticated: true });
      renderHeader();

      expect(screen.getByTestId("avatar-button")).toHaveAttribute("data-first-name", "Alice");
    });

    it("passes firstName from getCurrentUserSync to MobileUserButton", () => {
      setupLocation();
      mockGetCurrentUserSync.mockReturnValue({ firstName: "Bob", isAuthenticated: false });
      renderHeader();

      expect(screen.getByTestId("mobile-user-button")).toHaveAttribute("data-first-name", "Bob");
    });

    it("passes showAvatar=false to MobileUserButton when not authenticated", () => {
      setupLocation();
      mockGetCurrentUserSync.mockReturnValue({ firstName: "Guest", isAuthenticated: false });
      renderHeader();

      expect(screen.getByTestId("mobile-user-button")).toHaveAttribute("data-show-avatar", "false");
    });

    it("passes showAvatar=true to MobileUserButton when authenticated", () => {
      setupLocation();
      mockGetCurrentUserSync.mockReturnValue({ firstName: "Sarah", isAuthenticated: true });
      renderHeader();

      expect(screen.getByTestId("mobile-user-button")).toHaveAttribute("data-show-avatar", "true");
    });
  });

  // ── Mobile menu toggle ─────────────────────────────────────────────────────

  describe("mobile menu toggle", () => {
    it("MobileMenu is NOT rendered initially", () => {
      setupLocation();
      renderHeader();

      expect(screen.queryByTestId("mobile-menu")).not.toBeInTheDocument();
    });

    it("MobileMenu is rendered after clicking the hamburger", () => {
      setupLocation();
      renderHeader();

      clickHamburger();

      expect(screen.getByTestId("mobile-menu")).toBeInTheDocument();
    });

    it("hamburger aria-label is 'Close menu' when menu is open", () => {
      setupLocation();
      renderHeader();

      clickHamburger();

      expect(screen.getByRole("button", { name: "Close menu" })).toBeInTheDocument();
    });

    it("hamburger aria-label returns to 'Open menu' after closing", () => {
      setupLocation();
      renderHeader();

      clickHamburger(); // open
      clickHamburger(); // close

      expect(screen.getByRole("button", { name: "Open menu" })).toBeInTheDocument();
      expect(screen.queryByTestId("mobile-menu")).not.toBeInTheDocument();
    });

    it("calls lockBodyScroll when the menu opens", () => {
      setupLocation();
      renderHeader();

      clickHamburger();

      expect(mockLockBodyScroll).toHaveBeenCalledTimes(1);
    });

    it("calls unlockBodyScroll when the menu closes", () => {
      setupLocation();
      renderHeader();

      clickHamburger(); // open
      clickHamburger(); // close

      expect(mockUnlockBodyScroll).toHaveBeenCalledTimes(1);
    });

    it("does NOT call lockBodyScroll on initial render", () => {
      setupLocation();
      renderHeader();

      expect(mockLockBodyScroll).not.toHaveBeenCalled();
    });
  });

  // ── MobileMenu onClose callback ────────────────────────────────────────────

  describe("MobileMenu onClose prop", () => {
    it("closes the mobile menu when onClose is invoked", () => {
      setupLocation();
      renderHeader();

      clickHamburger(); // open
      expect(screen.getByTestId("mobile-menu")).toBeInTheDocument();

      // Trigger the close via the captured callback (direct state setter call
      // — must be wrapped in act())
      expect(triggerMobileMenuClose).toBeDefined();
      act(() => {
        triggerMobileMenuClose?.();
      });

      expect(screen.queryByTestId("mobile-menu")).not.toBeInTheDocument();
    });
  });

  // ── Escape key closes mobile menu ─────────────────────────────────────────

  describe("Escape key behaviour", () => {
    it("closes the mobile menu when Escape is pressed while it is open", () => {
      setupLocation();
      renderHeader();

      clickHamburger(); // open
      expect(screen.getByTestId("mobile-menu")).toBeInTheDocument();

      fireEvent.keyDown(window, { key: "Escape" });

      expect(screen.queryByTestId("mobile-menu")).not.toBeInTheDocument();
    });

    it("has no effect when Escape is pressed while the menu is already closed", () => {
      setupLocation();
      renderHeader();

      expect(() => fireEvent.keyDown(window, { key: "Escape" })).not.toThrow();
      expect(screen.queryByTestId("mobile-menu")).not.toBeInTheDocument();
    });

    it("does not close the menu for non-Escape keys", () => {
      setupLocation();
      renderHeader();

      clickHamburger(); // open
      fireEvent.keyDown(window, { key: "Tab" });
      fireEvent.keyDown(window, { key: "Enter" });

      expect(screen.getByTestId("mobile-menu")).toBeInTheDocument();
    });
  });
});
