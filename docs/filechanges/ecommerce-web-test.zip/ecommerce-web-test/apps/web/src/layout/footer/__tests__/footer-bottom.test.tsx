/**
 * Unit tests for FooterBottom component.
 *
 * Covers:
 *  - section="contact": all 3 contact blocks (phone, email, location)
 *    - link href values
 *    - label text presence (rendered twice: mobile + desktop paragraph)
 *    - value text presence
 *    - icon image alt text
 *  - section="copyright": rendered text, absence of links/images
 *  - Edge cases: custom contactInfo data reflected at render time
 *
 * @module layout/footer/__tests__/footer-bottom
 */

import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { FooterBottom } from "../footer-bottom";

// ---------------------------------------------------------------------------
// Regex constants (must be at module scope per lint/performance/useTopLevelRegex)
// ---------------------------------------------------------------------------
const RE_CALL_US = /call us/i;
const RE_EMAIL_US = /email us/i;
const RE_FIND_A_LOCATION = /find a location/i;
const RE_2026 = /2026/;
const RE_TOYOTA_FINANCIAL_SERVICES = /toyota financial services/i;
const RE_ALL_RIGHTS_RESERVED = /all rights reserved/i;
const RE_RING_US = /ring us/i;
const RE_WRITE_US = /write us/i;
const RE_LOCATE_US = /locate us/i;
const RE_P_LABEL = /p label/i;
const RE_E_LABEL = /e label/i;
const RE_L_LABEL = /l label/i;

// ---------------------------------------------------------------------------
// Module mocks
// ---------------------------------------------------------------------------

/**
 * Mutable holder lets individual tests swap contactInfo without
 * vi.resetModules() or dynamic re-imports.
 */
const contactInfoRef = vi.hoisted(() => ({
  current: {
    phone: {
      label: "Call Us",
      value: "1-800-GO-Arrow",
      href: "tel:1-800-462-7769",
    },
    email: {
      label: "Email Us",
      value: "support@arrow.com",
      href: "mailto:support@arrow.com",
    },
    location: {
      label: "Find a Location",
      value: "Dealership Locator",
      href: "/locations",
    },
  },
}));

vi.mock("@shared/data/footer/footer-links", () => ({
  get contactInfo() {
    return contactInfoRef.current;
  },
}));

/**
 * Override the global next/image stub (which returns bare props) with one
 * that renders a real <img> element so we can assert on alt text.
 */
vi.mock("next/image", () => ({
  default: ({
    src,
    alt,
    width,
    height,
  }: {
    src: string;
    alt: string;
    width: number;
    height: number;
    // biome-ignore lint/performance/noImgElement: native <img> is required in this test mock to enable getByAltText queries
  }) => <img alt={alt} height={height} src={src} width={width} />,
}));

// ---------------------------------------------------------------------------
// Fixture
// ---------------------------------------------------------------------------

const DEFAULT_CONTACT = {
  phone: {
    label: "Call Us",
    value: "1-800-GO-Arrow",
    href: "tel:1-800-462-7769",
  },
  email: {
    label: "Email Us",
    value: "support@arrow.com",
    href: "mailto:support@arrow.com",
  },
  location: {
    label: "Find a Location",
    value: "Dealership Locator",
    href: "/locations",
  },
};

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("FooterBottom", () => {
  beforeEach(() => {
    contactInfoRef.current = structuredClone(DEFAULT_CONTACT);
  });

  // -------------------------------------------------------------------------
  // section="contact"
  // -------------------------------------------------------------------------
  describe('section="contact"', () => {
    describe("structure", () => {
      it("renders exactly 3 links", () => {
        render(<FooterBottom section="contact" />);

        expect(screen.getAllByRole("link")).toHaveLength(3);
      });

      it("renders exactly 3 icon images", () => {
        render(<FooterBottom section="contact" />);

        expect(screen.getAllByRole("img")).toHaveLength(3);
      });
    });

    // -----------------------------------------------------------------------
    // Phone block
    // -----------------------------------------------------------------------
    describe("phone contact", () => {
      it("renders a link pointing to the phone href", () => {
        render(<FooterBottom section="contact" />);

        // Accessible name is computed from all child text + img alt
        const link = screen.getByRole("link", { name: RE_CALL_US });
        expect(link).toHaveAttribute("href", DEFAULT_CONTACT.phone.href);
      });

      it("renders the phone label text (mobile + desktop paragraph)", () => {
        render(<FooterBottom section="contact" />);

        // The label paragraph is duplicated: once for mobile, once for desktop
        const labels = screen.getAllByText(DEFAULT_CONTACT.phone.label);
        expect(labels).toHaveLength(2);
        for (const el of labels) {
          expect(el).toBeInTheDocument();
        }
      });

      it("renders the phone value text", () => {
        render(<FooterBottom section="contact" />);

        expect(screen.getByText(DEFAULT_CONTACT.phone.value)).toBeInTheDocument();
      });

      it("renders the Phone icon image with alt='Phone'", () => {
        render(<FooterBottom section="contact" />);

        expect(screen.getByAltText("Phone")).toBeInTheDocument();
      });
    });

    // -----------------------------------------------------------------------
    // Email block
    // -----------------------------------------------------------------------
    describe("email contact", () => {
      it("renders a link pointing to the email href", () => {
        render(<FooterBottom section="contact" />);

        const link = screen.getByRole("link", { name: RE_EMAIL_US });
        expect(link).toHaveAttribute("href", DEFAULT_CONTACT.email.href);
      });

      it("renders the email label text (mobile + desktop paragraph)", () => {
        render(<FooterBottom section="contact" />);

        const labels = screen.getAllByText(DEFAULT_CONTACT.email.label);
        expect(labels).toHaveLength(2);
        for (const el of labels) {
          expect(el).toBeInTheDocument();
        }
      });

      it("renders the email value text", () => {
        render(<FooterBottom section="contact" />);

        expect(screen.getByText(DEFAULT_CONTACT.email.value)).toBeInTheDocument();
      });

      it("renders the Email icon image with alt='Email'", () => {
        render(<FooterBottom section="contact" />);

        expect(screen.getByAltText("Email")).toBeInTheDocument();
      });
    });

    // -----------------------------------------------------------------------
    // Location block
    // -----------------------------------------------------------------------
    describe("location contact", () => {
      it("renders a link pointing to the location href", () => {
        render(<FooterBottom section="contact" />);

        const link = screen.getByRole("link", { name: RE_FIND_A_LOCATION });
        expect(link).toHaveAttribute("href", DEFAULT_CONTACT.location.href);
      });

      it("renders the location label text (mobile + desktop paragraph)", () => {
        render(<FooterBottom section="contact" />);

        const labels = screen.getAllByText(DEFAULT_CONTACT.location.label);
        expect(labels).toHaveLength(2);
        for (const el of labels) {
          expect(el).toBeInTheDocument();
        }
      });

      it("renders the location value text", () => {
        render(<FooterBottom section="contact" />);

        expect(screen.getByText(DEFAULT_CONTACT.location.value)).toBeInTheDocument();
      });

      it("renders the Location icon image with alt='Location'", () => {
        render(<FooterBottom section="contact" />);

        expect(screen.getByAltText("Location")).toBeInTheDocument();
      });
    });
  });

  // -------------------------------------------------------------------------
  // section="copyright"
  // -------------------------------------------------------------------------
  describe('section="copyright"', () => {
    it("renders the copyright year 2026", () => {
      render(<FooterBottom section="copyright" />);

      expect(screen.getByText(RE_2026)).toBeInTheDocument();
    });

    it("renders 'Toyota Financial Services' in the copyright text", () => {
      render(<FooterBottom section="copyright" />);

      expect(screen.getByText(RE_TOYOTA_FINANCIAL_SERVICES)).toBeInTheDocument();
    });

    it("renders 'All rights reserved' in the copyright text", () => {
      render(<FooterBottom section="copyright" />);

      expect(screen.getByText(RE_ALL_RIGHTS_RESERVED)).toBeInTheDocument();
    });

    it("renders no links", () => {
      render(<FooterBottom section="copyright" />);

      expect(screen.queryAllByRole("link")).toHaveLength(0);
    });

    it("renders no images", () => {
      render(<FooterBottom section="copyright" />);

      expect(screen.queryAllByRole("img")).toHaveLength(0);
    });
  });

  // -------------------------------------------------------------------------
  // Edge cases — contactInfo data source is reflected at render time
  // -------------------------------------------------------------------------
  describe("data source integration", () => {
    it("reflects a custom phone href from contactInfo", () => {
      contactInfoRef.current = {
        ...DEFAULT_CONTACT,
        phone: { label: "Ring Us", value: "555-0100", href: "tel:555-0100" },
      };
      render(<FooterBottom section="contact" />);

      expect(screen.getByRole("link", { name: RE_RING_US })).toHaveAttribute(
        "href",
        "tel:555-0100"
      );
    });

    it("reflects a custom phone value from contactInfo", () => {
      contactInfoRef.current = {
        ...DEFAULT_CONTACT,
        phone: { label: "Call Us", value: "1-999-CUSTOM", href: "tel:1-999-CUSTOM" },
      };
      render(<FooterBottom section="contact" />);

      expect(screen.getByText("1-999-CUSTOM")).toBeInTheDocument();
    });

    it("reflects a custom email href from contactInfo", () => {
      contactInfoRef.current = {
        ...DEFAULT_CONTACT,
        email: {
          label: "Write Us",
          value: "custom@example.com",
          href: "mailto:custom@example.com",
        },
      };
      render(<FooterBottom section="contact" />);

      expect(screen.getByRole("link", { name: RE_WRITE_US })).toHaveAttribute(
        "href",
        "mailto:custom@example.com"
      );
    });

    it("reflects a custom email value from contactInfo", () => {
      contactInfoRef.current = {
        ...DEFAULT_CONTACT,
        email: {
          label: "Email Us",
          value: "custom@example.com",
          href: "mailto:custom@example.com",
        },
      };
      render(<FooterBottom section="contact" />);

      expect(screen.getByText("custom@example.com")).toBeInTheDocument();
    });

    it("reflects a custom location href from contactInfo", () => {
      contactInfoRef.current = {
        ...DEFAULT_CONTACT,
        location: { label: "Locate Us", value: "Store Finder", href: "/stores" },
      };
      render(<FooterBottom section="contact" />);

      expect(screen.getByRole("link", { name: RE_LOCATE_US })).toHaveAttribute("href", "/stores");
    });

    it("reflects a custom location value from contactInfo", () => {
      contactInfoRef.current = {
        ...DEFAULT_CONTACT,
        location: {
          label: "Find a Location",
          value: "Branch Locator",
          href: "/branches",
        },
      };
      render(<FooterBottom section="contact" />);

      expect(screen.getByText("Branch Locator")).toBeInTheDocument();
    });

    it("renders all 3 links even when all contactInfo values are customised", () => {
      contactInfoRef.current = {
        phone: { label: "P Label", value: "P Value", href: "/p" },
        email: { label: "E Label", value: "E Value", href: "/e" },
        location: { label: "L Label", value: "L Value", href: "/l" },
      };
      render(<FooterBottom section="contact" />);

      expect(screen.getAllByRole("link")).toHaveLength(3);
      expect(screen.getByRole("link", { name: RE_P_LABEL })).toHaveAttribute("href", "/p");
      expect(screen.getByRole("link", { name: RE_E_LABEL })).toHaveAttribute("href", "/e");
      expect(screen.getByRole("link", { name: RE_L_LABEL })).toHaveAttribute("href", "/l");
    });
  });
});
