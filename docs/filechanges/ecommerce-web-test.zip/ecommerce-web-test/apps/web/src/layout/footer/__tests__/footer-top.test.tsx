/**
 * Unit tests for FooterTop component.
 *
 * Covers:
 *  - Brand section: "Arrow" h2 heading, tagline paragraph
 *  - Social links: count, hrefs, aria-labels, target="_blank",
 *    rel="noopener noreferrer"
 *  - Social icons: alt text matches label, src resolved from iconMap
 *  - Edge cases: empty socialLinks, single link, large dataset,
 *    custom href/label, brand section always renders
 *
 * @module layout/footer/__tests__/footer-top
 */

import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { FooterTop } from "../footer-top";

// ---------------------------------------------------------------------------
// Module mocks
// ---------------------------------------------------------------------------

/**
 * Mutable holder lets individual tests swap socialLinks without
 * vi.resetModules() or dynamic re-imports.
 */
const socialLinksRef = vi.hoisted(() => ({
  current: [] as Array<{
    label: string;
    href: string;
    icon: "facebook" | "twitter" | "instagram" | "youtube";
  }>,
}));

vi.mock("@shared/data/footer/footer-links", () => ({
  get socialLinks() {
    return socialLinksRef.current;
  },
}));

/**
 * Override the global next/image stub (which returns bare props) with one
 * that renders a real <img> so alt and src assertions work.
 */
vi.mock("next/image", () => ({
  default: ({
    src,
    alt,
    width,
    height,
  }: {
    src: string;
    alt: string;
    width: number;
    height: number;
    // biome-ignore lint/performance/noImgElement: native <img> is required in this test mock to enable getByAltText queries
  }) => <img alt={alt} height={height} src={src} width={width} />,
}));

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

const DEFAULT_SOCIAL_LINKS = [
  { label: "Facebook", href: "https://facebook.com", icon: "facebook" as const },
  { label: "Twitter", href: "https://twitter.com", icon: "twitter" as const },
  { label: "Instagram", href: "https://instagram.com", icon: "instagram" as const },
  { label: "YouTube", href: "https://youtube.com", icon: "youtube" as const },
];

/**
 * The iconMap is internal to the component. These expected paths represent
 * the correct output for each known icon key — verifying them is a
 * functional assertion ("given icon X, the rendered image src is Y").
 */
const EXPECTED_ICON_SRC: Record<string, string> = {
  facebook: "/images/footer/icon-facebook.svg",
  twitter: "/images/footer/icon-twitter.svg",
  instagram: "/images/footer/icon-instagram.svg",
  youtube: "/images/footer/icon-youtube.svg",
};

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("FooterTop", () => {
  beforeEach(() => {
    socialLinksRef.current = DEFAULT_SOCIAL_LINKS;
  });

  // -------------------------------------------------------------------------
  // Brand section
  // -------------------------------------------------------------------------
  describe("brand section", () => {
    it("renders 'Arrow' as an h2 heading", () => {
      render(<FooterTop />);

      expect(screen.getByRole("heading", { level: 2, name: "Arrow" })).toBeInTheDocument();
    });

    it("renders the brand tagline text", () => {
      render(<FooterTop />);

      expect(
        screen.getByText("Your trusted partner for quality pre-owned vehicles")
      ).toBeInTheDocument();
    });

    it("renders the brand section even when socialLinks is empty", () => {
      socialLinksRef.current = [];
      render(<FooterTop />);

      expect(screen.getByRole("heading", { level: 2, name: "Arrow" })).toBeInTheDocument();
      expect(
        screen.getByText("Your trusted partner for quality pre-owned vehicles")
      ).toBeInTheDocument();
    });
  });

  // -------------------------------------------------------------------------
  // Social links — count and structure
  // -------------------------------------------------------------------------
  describe("social links — count and structure", () => {
    it("renders exactly one link per social entry", () => {
      render(<FooterTop />);

      expect(screen.getAllByRole("link")).toHaveLength(DEFAULT_SOCIAL_LINKS.length);
    });

    it("renders exactly one image per social entry", () => {
      render(<FooterTop />);

      expect(screen.getAllByRole("img")).toHaveLength(DEFAULT_SOCIAL_LINKS.length);
    });

    it("renders no links when socialLinks is empty", () => {
      socialLinksRef.current = [];
      render(<FooterTop />);

      expect(screen.queryAllByRole("link")).toHaveLength(0);
    });

    it("renders no images when socialLinks is empty", () => {
      socialLinksRef.current = [];
      render(<FooterTop />);

      expect(screen.queryAllByRole("img")).toHaveLength(0);
    });
  });

  // -------------------------------------------------------------------------
  // Social links — href values
  // -------------------------------------------------------------------------
  describe("social links — hrefs", () => {
    it("gives every social link the correct href", () => {
      render(<FooterTop />);

      for (const social of DEFAULT_SOCIAL_LINKS) {
        expect(screen.getByRole("link", { name: social.label })).toHaveAttribute(
          "href",
          social.href
        );
      }
    });
  });

  // -------------------------------------------------------------------------
  // Social links — accessible labels
  // -------------------------------------------------------------------------
  describe("social links — aria-labels", () => {
    it("gives every link an aria-label matching its social network name", () => {
      render(<FooterTop />);

      for (const social of DEFAULT_SOCIAL_LINKS) {
        // getByRole with name: queries aria-label
        expect(screen.getByRole("link", { name: social.label })).toBeInTheDocument();
      }
    });
  });

  // -------------------------------------------------------------------------
  // Social links — external link safety attributes
  // -------------------------------------------------------------------------
  describe("social links — external link attributes", () => {
    it("opens every social link in a new tab via target='_blank'", () => {
      render(<FooterTop />);

      for (const social of DEFAULT_SOCIAL_LINKS) {
        expect(screen.getByRole("link", { name: social.label })).toHaveAttribute(
          "target",
          "_blank"
        );
      }
    });

    it("adds rel='noopener noreferrer' to every social link", () => {
      render(<FooterTop />);

      for (const social of DEFAULT_SOCIAL_LINKS) {
        expect(screen.getByRole("link", { name: social.label })).toHaveAttribute(
          "rel",
          "noopener noreferrer"
        );
      }
    });
  });

  // -------------------------------------------------------------------------
  // Social icons — image alt text
  // -------------------------------------------------------------------------
  describe("social icons — alt text", () => {
    it("gives each icon image an alt attribute matching the link label", () => {
      render(<FooterTop />);

      for (const social of DEFAULT_SOCIAL_LINKS) {
        expect(screen.getByAltText(social.label)).toBeInTheDocument();
      }
    });
  });

  // -------------------------------------------------------------------------
  // Social icons — src paths from iconMap
  // -------------------------------------------------------------------------
  describe("social icons — src resolution", () => {
    it("resolves the correct icon src for each known social network", () => {
      render(<FooterTop />);

      for (const social of DEFAULT_SOCIAL_LINKS) {
        const img = screen.getByAltText(social.label);
        expect(img).toHaveAttribute("src", EXPECTED_ICON_SRC[social.icon]);
      }
    });

    it("facebook icon uses the facebook svg path", () => {
      socialLinksRef.current = [
        { label: "Facebook", href: "https://facebook.com", icon: "facebook" },
      ];
      render(<FooterTop />);

      expect(screen.getByAltText("Facebook")).toHaveAttribute(
        "src",
        "/images/footer/icon-facebook.svg"
      );
    });

    it("twitter icon uses the twitter svg path", () => {
      socialLinksRef.current = [{ label: "Twitter", href: "https://twitter.com", icon: "twitter" }];
      render(<FooterTop />);

      expect(screen.getByAltText("Twitter")).toHaveAttribute(
        "src",
        "/images/footer/icon-twitter.svg"
      );
    });

    it("instagram icon uses the instagram svg path", () => {
      socialLinksRef.current = [
        { label: "Instagram", href: "https://instagram.com", icon: "instagram" },
      ];
      render(<FooterTop />);

      expect(screen.getByAltText("Instagram")).toHaveAttribute(
        "src",
        "/images/footer/icon-instagram.svg"
      );
    });

    it("youtube icon uses the youtube svg path", () => {
      socialLinksRef.current = [{ label: "YouTube", href: "https://youtube.com", icon: "youtube" }];
      render(<FooterTop />);

      expect(screen.getByAltText("YouTube")).toHaveAttribute(
        "src",
        "/images/footer/icon-youtube.svg"
      );
    });
  });

  // -------------------------------------------------------------------------
  // Edge cases
  // -------------------------------------------------------------------------
  describe("edge cases", () => {
    it("renders a single social link correctly", () => {
      socialLinksRef.current = [
        { label: "Facebook", href: "https://facebook.com", icon: "facebook" },
      ];
      render(<FooterTop />);

      expect(screen.getAllByRole("link")).toHaveLength(1);
      expect(screen.getByRole("link", { name: "Facebook" })).toHaveAttribute(
        "href",
        "https://facebook.com"
      );
      expect(screen.getByRole("link", { name: "Facebook" })).toHaveAttribute("target", "_blank");
      expect(screen.getByRole("link", { name: "Facebook" })).toHaveAttribute(
        "rel",
        "noopener noreferrer"
      );
      expect(screen.getByAltText("Facebook")).toHaveAttribute(
        "src",
        "/images/footer/icon-facebook.svg"
      );
    });

    it("renders custom href and label from socialLinks data", () => {
      socialLinksRef.current = [
        { label: "Custom Network", href: "https://custom.example.com", icon: "twitter" },
      ];
      render(<FooterTop />);

      const link = screen.getByRole("link", { name: "Custom Network" });
      expect(link).toHaveAttribute("href", "https://custom.example.com");
      expect(screen.getByAltText("Custom Network")).toBeInTheDocument();
    });

    it("handles a large number of social links without errors", () => {
      const manyLinks = Array.from({ length: 20 }, (_, i) => ({
        label: `Network ${i + 1}`,
        href: `https://network${i + 1}.com`,
        icon: "facebook" as const,
      }));
      socialLinksRef.current = manyLinks;
      render(<FooterTop />);

      expect(screen.getAllByRole("link")).toHaveLength(20);
      expect(screen.getAllByRole("img")).toHaveLength(20);
    });

    it("preserves social link order from the data source", () => {
      const ordered = [
        { label: "First", href: "https://first.com", icon: "facebook" as const },
        { label: "Second", href: "https://second.com", icon: "twitter" as const },
        { label: "Third", href: "https://third.com", icon: "instagram" as const },
      ];
      socialLinksRef.current = ordered;
      render(<FooterTop />);

      const links = screen.getAllByRole("link");
      expect(links[0]).toHaveAttribute("aria-label", "First");
      expect(links[1]).toHaveAttribute("aria-label", "Second");
      expect(links[2]).toHaveAttribute("aria-label", "Third");
    });
  });
});
