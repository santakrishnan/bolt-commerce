import { render, screen } from "@arrow/vitest-config/test-utils";
import type { ReactNode } from "react";
import { describe, expect, it, vi } from "vitest";

import { AvatarButton, MobileUserButton, SignInButton } from "../auth-buttons";

// ---------------------------------------------------------------------------
// Mocks
// ---------------------------------------------------------------------------

// next/link → plain <a> that forwards all observable attributes
vi.mock("next/link", () => ({
  default: ({
    href,
    className,
    children,
    "aria-label": ariaLabel,
  }: {
    href: string;
    className?: string;
    children: ReactNode;
    "aria-label"?: string;
  }) => (
    <a aria-label={ariaLabel} className={className} href={href}>
      {children}
    </a>
  ),
}));

// @tfs-ucmp/ui – lightweight structural stand-ins so we never depend on
// shadcn internals.  Button renders a <button>, UserIcon an <svg>.
vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({
    children,
    className,
    size,
    variant,
  }: {
    children: ReactNode;
    className?: string;
    size?: string;
    variant?: string;
  }) => (
    <button
      className={className}
      data-size={size}
      data-testid="mock-button"
      data-variant={variant}
      type="button"
    >
      {children}
    </button>
  ),
  UserIcon: ({ className }: { className?: string }) => (
    <svg aria-hidden="true" className={className} data-testid="user-icon" />
  ),
}));

// @config/routes/constants – not aliased in vitest config, must be mocked
vi.mock("@config/routes/constants", () => ({
  ROUTES: {
    MY_GARAGE: "/my-garage",
    SIGN_IN: "/sign-in",
  },
}));

// ---------------------------------------------------------------------------
// SignInButton
// ---------------------------------------------------------------------------

describe("SignInButton", () => {
  describe("rendered content", () => {
    it("renders the 'Sign In' label", () => {
      render(<SignInButton useSolidStyles={false} />);

      expect(screen.getByText("Sign In")).toBeInTheDocument();
    });

    it("renders the UserIcon", () => {
      render(<SignInButton useSolidStyles={false} />);

      expect(screen.getByTestId("user-icon")).toBeInTheDocument();
    });
  });

  describe("navigation", () => {
    it("sign-in link href is '/'", () => {
      render(<SignInButton useSolidStyles={false} />);

      expect(screen.getByRole("link")).toHaveAttribute("href", "/");
    });
  });

  describe("style branches — coverage only", () => {
    it.each([true, false])("renders without throwing when useSolidStyles=%s", (useSolidStyles) => {
      expect(() => render(<SignInButton useSolidStyles={useSolidStyles} />)).not.toThrow();
    });
  });
});

// ---------------------------------------------------------------------------
// AvatarButton
// ---------------------------------------------------------------------------

describe("AvatarButton", () => {
  describe("initial letter derivation", () => {
    it("uppercases a lowercase first character", () => {
      render(<AvatarButton firstName="alice" useSolidStyles={true} />);

      // The initial div holds exactly one uppercase character
      expect(screen.getByText("A")).toBeInTheDocument();
    });

    it("preserves an already-uppercase first character", () => {
      render(<AvatarButton firstName="Bob" useSolidStyles={true} />);

      expect(screen.getByText("B")).toBeInTheDocument();
    });

    it("upper-cases a digit (edge: non-alpha start)", () => {
      render(<AvatarButton firstName="007Bond" useSolidStyles={true} />);

      // charAt(0).toUpperCase() of "0" is still "0"
      expect(screen.getByText("0")).toBeInTheDocument();
    });
  });

  describe("display-name truncation", () => {
    it("shows the full name when it is shorter than 6 characters", () => {
      render(<AvatarButton firstName="Sam" useSolidStyles={true} />);

      expect(screen.getByText("Sam")).toBeInTheDocument();
    });

    it("shows the full name at the 6-character boundary (no truncation)", () => {
      render(<AvatarButton firstName="Alexis" useSolidStyles={true} />);

      expect(screen.getByText("Alexis")).toBeInTheDocument();
    });

    it("truncates a 7-character name to 6 chars + '...'", () => {
      render(<AvatarButton firstName="Timothy" useSolidStyles={true} />);

      expect(screen.getByText("Timoth...")).toBeInTheDocument();
    });

    it("truncates names longer than 7 characters", () => {
      render(<AvatarButton firstName="Alexander" useSolidStyles={true} />);

      expect(screen.getByText("Alexan...")).toBeInTheDocument();
    });
  });

  describe("navigation", () => {
    it("links to /my-garage", () => {
      render(<AvatarButton firstName="Jane" useSolidStyles={true} />);

      expect(screen.getByRole("link")).toHaveAttribute("href", "/my-garage");
    });
  });

  describe("default prop for useSolidStyles", () => {
    it("defaults useSolidStyles to true and renders without error", () => {
      // No useSolidStyles prop supplied – should not throw
      expect(() => render(<AvatarButton firstName="Jane" />)).not.toThrow();
    });

    it("still shows correct content when relying on default useSolidStyles", () => {
      render(<AvatarButton firstName="Jane" />);

      expect(screen.getByText("J")).toBeInTheDocument();
      expect(screen.getByText("Jane")).toBeInTheDocument();
    });
  });

  describe("style branches — coverage only", () => {
    it("renders correctly when useSolidStyles=false", () => {
      render(<AvatarButton firstName="Jane" useSolidStyles={false} />);

      expect(screen.getByRole("link")).toBeInTheDocument();
      expect(screen.getByText("Jane")).toBeInTheDocument();
    });
  });
});

// ---------------------------------------------------------------------------
// MobileUserButton
// ---------------------------------------------------------------------------

describe("MobileUserButton", () => {
  describe("authenticated state (showAvatar=true)", () => {
    it("renders a link with aria-label 'User profile'", () => {
      render(<MobileUserButton firstName="Alice" showAvatar={true} useSolidStyles={true} />);

      expect(screen.getByRole("link", { name: "User profile" })).toBeInTheDocument();
    });

    it("links to /my-garage", () => {
      render(<MobileUserButton firstName="Alice" showAvatar={true} useSolidStyles={true} />);

      expect(screen.getByRole("link", { name: "User profile" })).toHaveAttribute(
        "href",
        "/my-garage"
      );
    });

    it("displays the uppercase initial of firstName", () => {
      render(<MobileUserButton firstName="charlie" showAvatar={true} useSolidStyles={false} />);

      expect(screen.getByRole("link", { name: "User profile" })).toHaveTextContent("C");
    });

    it("does not render the sign-in link", () => {
      render(<MobileUserButton firstName="Alice" showAvatar={true} useSolidStyles={true} />);

      expect(screen.queryByRole("link", { name: "Sign in" })).not.toBeInTheDocument();
    });

    it("does not render the UserIcon", () => {
      render(<MobileUserButton firstName="Alice" showAvatar={true} useSolidStyles={true} />);

      expect(screen.queryByTestId("user-icon")).not.toBeInTheDocument();
    });
  });

  describe("unauthenticated state (showAvatar=false)", () => {
    it("renders a link with aria-label 'Sign in'", () => {
      render(<MobileUserButton firstName="" showAvatar={false} useSolidStyles={true} />);

      expect(screen.getByRole("link", { name: "Sign in" })).toBeInTheDocument();
    });

    it("sign-in link points to /sign-in", () => {
      render(<MobileUserButton firstName="" showAvatar={false} useSolidStyles={true} />);

      expect(screen.getByRole("link", { name: "Sign in" })).toHaveAttribute("href", "/sign-in");
    });

    it("renders the UserIcon", () => {
      render(<MobileUserButton firstName="" showAvatar={false} useSolidStyles={true} />);

      expect(screen.getByTestId("user-icon")).toBeInTheDocument();
    });

    it("does not render the user-profile link", () => {
      render(<MobileUserButton firstName="" showAvatar={false} useSolidStyles={true} />);

      expect(screen.queryByRole("link", { name: "User profile" })).not.toBeInTheDocument();
    });

    it.each([true, false])("renders without throwing when useSolidStyles=%s", (useSolidStyles) => {
      expect(() =>
        render(<MobileUserButton firstName="" showAvatar={false} useSolidStyles={useSolidStyles} />)
      ).not.toThrow();
    });
  });
});
