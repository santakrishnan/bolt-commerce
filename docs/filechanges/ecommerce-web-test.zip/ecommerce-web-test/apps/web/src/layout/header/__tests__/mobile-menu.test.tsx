import { fireEvent, render, screen } from "@arrow/vitest-config/test-utils";
import type { ReactNode } from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { MobileMenu } from "../mobile-menu";

// ---------------------------------------------------------------------------
// Mocks
// ---------------------------------------------------------------------------

// next/link → plain <a> forwarding href, className, onClick, children
vi.mock("next/link", () => ({
  default: ({
    href,
    className,
    onClick,
    children,
  }: {
    href: string;
    className?: string;
    onClick?: () => void;
    children: ReactNode;
  }) => (
    <a className={className} href={href} onClick={onClick}>
      {children}
    </a>
  ),
}));

// @config/routes/constants – stable values for href assertions
vi.mock("@config/routes/constants", () => ({
  ROUTES: { HOME: "/" },
}));

// ./location-block – stub to isolate MobileMenu from LocationBlock's own deps
vi.mock("../location-block", () => ({
  LocationBlock: ({ useSolidStyles }: { useSolidStyles: boolean }) => (
    <div data-testid="location-block" data-use-solid-styles={String(useSolidStyles)} />
  ),
}));

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function renderMenu(onClose = vi.fn()) {
  render(<MobileMenu onClose={onClose} />);
  return { onClose };
}

/** The two "Close menu" buttons differ by position – return both. */
function getCloseMenuButtons() {
  return screen.getAllByRole("button", { name: "Close menu" });
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

beforeEach(() => {
  vi.clearAllMocks();
});

describe("MobileMenu", () => {
  // ── Rendered structure ────────────────────────────────────────────────────

  describe("rendered structure", () => {
    it("renders the navigation landmark", () => {
      renderMenu();
      expect(screen.getByRole("navigation")).toBeInTheDocument();
    });

    it("renders the ARROW logo link", () => {
      renderMenu();
      expect(screen.getByRole("link", { name: "ARROW" })).toBeInTheDocument();
    });

    it("header 'Close menu' button has visible 'Close' text", () => {
      renderMenu();
      const [, headerBtn] = getCloseMenuButtons();
      expect(headerBtn).toHaveTextContent("Close");
    });

    it("renders two 'Close menu' buttons (backdrop + header icon)", () => {
      renderMenu();
      expect(getCloseMenuButtons()).toHaveLength(2);
    });

    it("renders the 'Buy' nav link", () => {
      renderMenu();
      expect(screen.getByRole("link", { name: "Buy" })).toBeInTheDocument();
    });

    it("renders the 'Finance' nav link", () => {
      renderMenu();
      expect(screen.getByRole("link", { name: "Finance" })).toBeInTheDocument();
    });

    it("renders the 'Why Arrow' nav link", () => {
      renderMenu();
      expect(screen.getByRole("link", { name: "Why Arrow" })).toBeInTheDocument();
    });

    it("renders the LocationBlock stub", () => {
      renderMenu();
      expect(screen.getByTestId("location-block")).toBeInTheDocument();
    });

    it("passes useSolidStyles=true to LocationBlock", () => {
      renderMenu();
      expect(screen.getByTestId("location-block")).toHaveAttribute("data-use-solid-styles", "true");
    });
  });

  // ── Link hrefs ─────────────────────────────────────────────────────────────

  describe("link hrefs", () => {
    it("ARROW logo link points to ROUTES.HOME ('/')", () => {
      renderMenu();
      expect(screen.getByRole("link", { name: "ARROW" })).toHaveAttribute("href", "/");
    });

    it("'Buy' link points to '#'", () => {
      renderMenu();
      expect(screen.getByRole("link", { name: "Buy" })).toHaveAttribute("href", "#");
    });

    it("'Finance' link points to '#'", () => {
      renderMenu();
      expect(screen.getByRole("link", { name: "Finance" })).toHaveAttribute("href", "#");
    });

    it("'Why Arrow' link points to '#'", () => {
      renderMenu();
      expect(screen.getByRole("link", { name: "Why Arrow" })).toHaveAttribute("href", "#");
    });
  });

  // ── onClose invocations ────────────────────────────────────────────────────

  describe("onClose is called exactly once by each interactive element", () => {
    it("backdrop button click calls onClose", () => {
      const { onClose } = renderMenu();
      // The backdrop is the first of the two "Close menu" buttons
      const [backdrop, _] = getCloseMenuButtons() as [HTMLElement, HTMLElement];
      fireEvent.click(backdrop);
      expect(onClose).toHaveBeenCalledTimes(1);
    });

    it("header 'Close menu' button click calls onClose", () => {
      const { onClose } = renderMenu();
      // The second "Close menu" button is inside the nav header
      const [, headerBtn] = getCloseMenuButtons() as [HTMLElement, HTMLElement];
      fireEvent.click(headerBtn);
      expect(onClose).toHaveBeenCalledTimes(1);
    });

    it("ARROW logo link click calls onClose", () => {
      const { onClose } = renderMenu();
      fireEvent.click(screen.getByRole("link", { name: "ARROW" }));
      expect(onClose).toHaveBeenCalledTimes(1);
    });

    it("'Buy' link click calls onClose", () => {
      const { onClose } = renderMenu();
      fireEvent.click(screen.getByRole("link", { name: "Buy" }));
      expect(onClose).toHaveBeenCalledTimes(1);
    });

    it("'Finance' link click calls onClose", () => {
      const { onClose } = renderMenu();
      fireEvent.click(screen.getByRole("link", { name: "Finance" }));
      expect(onClose).toHaveBeenCalledTimes(1);
    });

    it("'Why Arrow' link click calls onClose", () => {
      const { onClose } = renderMenu();
      fireEvent.click(screen.getByRole("link", { name: "Why Arrow" }));
      expect(onClose).toHaveBeenCalledTimes(1);
    });
  });

  // ── Each element fires onClose independently (no cross-firing) ────────────

  describe("each element fires onClose independently", () => {
    it("clicking all elements accumulates the correct total call count", () => {
      const { onClose } = renderMenu();
      const [backdrop, headerCloseMenu] = getCloseMenuButtons() as [HTMLElement, HTMLElement];

      fireEvent.click(backdrop);
      fireEvent.click(headerCloseMenu);
      fireEvent.click(screen.getByRole("link", { name: "ARROW" }));
      fireEvent.click(screen.getByRole("link", { name: "Buy" }));
      fireEvent.click(screen.getByRole("link", { name: "Finance" }));
      fireEvent.click(screen.getByRole("link", { name: "Why Arrow" }));

      // 2 "Close menu" buttons + ARROW link + 3 nav links = 6
      expect(onClose).toHaveBeenCalledTimes(6);
    });
  });
});
