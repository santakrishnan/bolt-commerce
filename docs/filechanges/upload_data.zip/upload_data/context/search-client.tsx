"use client";

import {
  defaultFilterState,
  FilterSidebar,
  type FilterState,
} from "@features/search/components/filter-sidebar";
import { SearchHero } from "@features/search/components/search-hero";
import { VehicleResults } from "@features/search/components/vehicle-results";
import { useSearchContext } from "@features/search/context/search-context";
import {
  parseSearchUrlState,
  type SearchSortOption,
  serializeSearchUrlState,
} from "@features/search/lib/url-filters";
import { useDebouncedValue } from "@shared/hooks/use-debounced-value";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Suspense, useCallback, useDeferredValue, useEffect, useMemo, useRef } from "react";

// Animation timing for the top progress bar (kept as a helper for clarity)
function getProgressTransition(progress: number): string {
  if (progress === 100) {
    return "width 0.25s ease-in, opacity 0.4s ease 0.2s";
  }
  if (progress === 0) {
    return "none";
  }
  return "width 1.5s cubic-bezier(0.05, 0.6, 0.1, 1), opacity 0.15s ease";
}

// Helper functions for building active filters list
function addSingleFilter(
  filters: { label: string; type: string; value: string }[],
  value: string,
  type: string
) {
  if (value) {
    filters.push({ label: value, type, value });
  }
}

function addArrayFilters(
  filters: { label: string; type: string; value: string }[],
  arr: string[],
  type: string
) {
  for (const value of arr) {
    filters.push({ label: value, type, value });
  }
}

interface SearchClientProps {
  initialQuickFilters?: string[];
}

export function SearchClient({ initialQuickFilters }: SearchClientProps) {
  const {
    vehiclePool,
    filterState,
    searchQuery,
    setSearchQuery,
    searchQueryRef,
    labelFilter,
    setLabelFilter,
    refineSearchFilters,
    setRefineSearchFilters,
    currentPage,
    setCurrentPage,
    progress,
    isProgressVisible,
    isFilterOpen,
    setIsFilterOpen,
    availableFilters,
    totalCount,
    sortOption,
    setSortOption,
    loadingFacetSections,
    applyFiltersSearch,
    isFilterPending,
    isInitialLoading,
  } = useSearchContext();

  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const hydratedFromUrl = useRef(false);
  const lastSerializedUrlState = useRef("");
  const isInternalUpdate = useRef(false);
  const itemsPerPage = 20;
  // Track the previous page value to detect genuine page changes.
  // Using a ref avoids adding currentPage to a useEffect dependency list
  // (Biome flags it because the value isn't read inside the effect body —
  // it only acts as a trigger, which is a ref concern, not a dep concern).
  const prevPageRef = useRef(currentPage);

  // Scroll to top AFTER React has committed the new vehicle grid to the DOM.
  // No dependency array — runs every render, guarded by ref comparison so it
  // is effectively a no-op on every render except when the page changes.
  useEffect(() => {
    if (prevPageRef.current === currentPage) {
      return;
    }
    prevPageRef.current = currentPage;
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  // Sync URL -> state so back/forward navigation restores filters/search
  useEffect(() => {
    const parsed = parseSearchUrlState(searchParams);

    // Preserve provider defaults by removing explicit `undefined` entries
    const parsedFilterState = Object.fromEntries(
      Object.entries(parsed.filterState).filter(([_, value]) => value !== undefined)
    ) as Partial<FilterState>;

    const nextFilterState: FilterState = {
      ...defaultFilterState,
      ...parsedFilterState,
    };

    const nextSearchQuery = parsed.searchQuery ?? "";
    const nextPage = parsed.page ?? 1;
    const nextSort = (parsed.sortOption ?? "recommended") as SearchSortOption;
    const nextLabelFilter = parsed.labelFilter ?? "";

    const serialized = serializeSearchUrlState({
      filterState: nextFilterState,
      searchQuery: nextSearchQuery,
      page: nextPage,
      sortOption: nextSort,
      labelFilter: nextLabelFilter,
    });

    // On first hydration, prefer the provider's initial state to avoid clobbering
    if (!hydratedFromUrl.current) {
      hydratedFromUrl.current = true;
      lastSerializedUrlState.current = serialized;
      return;
    }

    if (serialized === lastSerializedUrlState.current) {
      return;
    }

    // Ignore URL updates that we triggered internally to avoid loops
    if (isInternalUpdate.current) {
      isInternalUpdate.current = false;
      lastSerializedUrlState.current = serialized;
      return;
    }

    lastSerializedUrlState.current = serialized;

    setCurrentPage(nextPage);
    setSortOption(nextSort);
    setLabelFilter(nextLabelFilter);
    setSearchQuery(nextSearchQuery);
    searchQueryRef.current = nextSearchQuery;

    applyFiltersSearch(nextFilterState, {
      searchQuery: nextSearchQuery,
      labelFilter: nextLabelFilter,
      refineFilters: refineSearchFilters,
      preservePage: true,
    });
  }, [
    searchParams,
    setCurrentPage,
    setSortOption,
    setLabelFilter,
    setSearchQuery,
    searchQueryRef,
    applyFiltersSearch,
    refineSearchFilters,
  ]);

  const debouncedUrlState = useDebouncedValue(
    {
      filterState,
      searchQuery,
      page: currentPage,
      sortOption,
      labelFilter,
    },
    250
  );

  // Debounced state -> URL sync (updates browser URL without immediate network calls)
  useEffect(() => {
    if (!hydratedFromUrl.current) {
      return;
    }

    const serialized = serializeSearchUrlState(debouncedUrlState);
    if (serialized === lastSerializedUrlState.current) {
      return;
    }

    lastSerializedUrlState.current = serialized;
    isInternalUpdate.current = true;
    const nextUrl = serialized ? `${pathname}?${serialized}` : pathname;
    router.replace(nextUrl, { scroll: false });
  }, [debouncedUrlState, pathname, router]);

  const handleApplyFilters = useCallback(
    (newState: FilterState) => {
      applyFiltersSearch(newState, {
        searchQuery,
        labelFilter,
        refineFilters: refineSearchFilters,
      });
    },
    [applyFiltersSearch, searchQuery, labelFilter, refineSearchFilters]
  );

  const activeFilters = useMemo(() => {
    const filters: { label: string; type: string; value: string; isRefineSearch?: boolean }[] = [];
    addSingleFilter(filters, filterState.selectedPriceQuick, "price");
    addSingleFilter(filters, filterState.selectedYearQuick, "year");
    addSingleFilter(filters, filterState.selectedMileage, "mileage");
    addArrayFilters(filters, filterState.selectedBodyStyles, "bodyStyle");
    addArrayFilters(filters, filterState.selectedExteriorColors, "exteriorColor");
    addArrayFilters(filters, filterState.selectedInteriorColors, "interiorColor");
    addArrayFilters(filters, filterState.selectedFuelTypes, "fuelType");
    addArrayFilters(filters, filterState.selectedModels, "model");
    addArrayFilters(filters, filterState.selectedSafetyFeatures, "safetyFeature");
    addArrayFilters(filters, filterState.selectedComfortFeatures, "comfortFeature");
    addArrayFilters(filters, filterState.selectedTechFeatures, "techFeature");
    addArrayFilters(filters, filterState.selectedExteriorFeatures, "exteriorFeature");
    addArrayFilters(filters, filterState.selectedPerformanceFeatures, "performanceFeature");
    addArrayFilters(filters, filterState.selectedSeatingCapacity, "seatingCapacity");
    addArrayFilters(filters, filterState.selectedDrivetrains, "drivetrain");
    addArrayFilters(filters, filterState.selectedTransmissions, "transmission");

    if (filterState.inspection160) {
      filters.push({ label: "160-Point Inspection", type: "inspection", value: "160" });
    }
    if (labelFilter) {
      filters.push({ label: labelFilter, type: "label", value: labelFilter });
    }
    for (const refineFilter of refineSearchFilters) {
      filters.push({ label: refineFilter.label, type: "refineSearch", value: refineFilter.id });
    }

    return filters;
  }, [filterState, labelFilter, refineSearchFilters]);

  // Display-friendly search query for the input: replace hyphens with spaces
  const displaySearchQuery = searchQuery?.includes("-")
    ? searchQuery.replace(/-/g, " ")
    : searchQuery;

  // Defer vehicle list rendering to reduce flashes during frequent updates
  const deferredVehicles = useDeferredValue(vehiclePool);
  const deferredTotalCount = useDeferredValue(totalCount);
  // isPending is true when deferred data hasn't caught up OR when a sort/filter
  // transition is in flight — both cases show the opacity indicator.
  const isPending = deferredVehicles !== vehiclePool || isFilterPending;

  const removeFilter = (type: string, value: string) => {
    let nextState: FilterState = filterState;
    let nextLabelFilter = labelFilter;
    let nextRefine = refineSearchFilters;

    switch (type) {
      case "price":
        nextState = { ...filterState, selectedPriceQuick: "" };
        break;
      case "year":
        nextState = { ...filterState, selectedYearQuick: "" };
        break;
      case "mileage":
        nextState = { ...filterState, selectedMileage: "" };
        break;
      case "bodyStyle":
        nextState = {
          ...filterState,
          selectedBodyStyles: filterState.selectedBodyStyles.filter((v) => v !== value),
        };
        break;
      case "exteriorColor":
        nextState = {
          ...filterState,
          selectedExteriorColors: filterState.selectedExteriorColors.filter((v) => v !== value),
        };
        break;
      case "interiorColor":
        nextState = {
          ...filterState,
          selectedInteriorColors: filterState.selectedInteriorColors.filter((v) => v !== value),
        };
        break;
      case "fuelType":
        nextState = {
          ...filterState,
          selectedFuelTypes: filterState.selectedFuelTypes.filter((v) => v !== value),
        };
        break;
      case "model":
        nextState = {
          ...filterState,
          selectedModels: filterState.selectedModels.filter((v) => v !== value),
        };
        break;
      case "safetyFeature":
        nextState = {
          ...filterState,
          selectedSafetyFeatures: filterState.selectedSafetyFeatures.filter((v) => v !== value),
        };
        break;
      case "comfortFeature":
        nextState = {
          ...filterState,
          selectedComfortFeatures: filterState.selectedComfortFeatures.filter((v) => v !== value),
        };
        break;
      case "techFeature":
        nextState = {
          ...filterState,
          selectedTechFeatures: filterState.selectedTechFeatures.filter((v) => v !== value),
        };
        break;
      case "exteriorFeature":
        nextState = {
          ...filterState,
          selectedExteriorFeatures: filterState.selectedExteriorFeatures.filter((v) => v !== value),
        };
        break;
      case "performanceFeature":
        nextState = {
          ...filterState,
          selectedPerformanceFeatures: filterState.selectedPerformanceFeatures.filter(
            (v) => v !== value
          ),
        };
        break;
      case "seatingCapacity":
        nextState = {
          ...filterState,
          selectedSeatingCapacity: filterState.selectedSeatingCapacity.filter((v) => v !== value),
        };
        break;
      case "drivetrain":
        nextState = {
          ...filterState,
          selectedDrivetrains: filterState.selectedDrivetrains.filter((v) => v !== value),
        };
        break;
      case "transmission":
        nextState = {
          ...filterState,
          selectedTransmissions: filterState.selectedTransmissions.filter((v) => v !== value),
        };
        break;
      case "inspection":
        nextState = { ...filterState, inspection160: false };
        break;
      case "label":
        nextLabelFilter = "";
        setLabelFilter("");
        break;
      case "refineSearch":
        nextRefine = refineSearchFilters.filter((f) => f.id !== value);
        setRefineSearchFilters(nextRefine);
        break;
      default:
        break;
    }

    applyFiltersSearch(nextState, {
      searchQuery,
      labelFilter: nextLabelFilter,
      refineFilters: nextRefine,
    });
  };

  const resetFilters = () => {
    // Let applyFiltersSearch handle all state updates in a single transition
    // to avoid duplicate payloads from separate state batches.
    searchQueryRef.current = "";
    applyFiltersSearch(defaultFilterState, {
      searchQuery: "",
      labelFilter: "",
      refineFilters: [],
    });
  };

  const applyRefineFilters = (filters: { id: string; label: string }[]) => {
    // Treat the array provided by the modal as the authoritative selection:
    // replace the current refine filters so removals are reflected.
    const unique: { id: string; label: string }[] = [];
    for (const f of filters) {
      if (!unique.some((u) => u.id === f.id)) {
        unique.push(f);
      }
    }
    setRefineSearchFilters(unique);
    applyFiltersSearch(filterState, {
      searchQuery,
      labelFilter,
      refineFilters: unique,
    });
  };

  return (
    <div className="flex min-h-screen flex-col bg-gray-50 lg:px-0">
      <FilterSidebar
        availableFilters={availableFilters}
        filterState={filterState}
        isOpen={isFilterOpen}
        labelFilter={labelFilter}
        loadingFacetSections={loadingFacetSections}
        onApply={handleApplyFilters}
        onClose={() => setIsFilterOpen(false)}
        onReset={resetFilters}
        refineFilters={refineSearchFilters}
        searchQuery={searchQuery}
        vehicleCount={totalCount}
      />

      <main className="relative flex-1 bg-gray-100">
        {/* Suspense boundary for SearchHero's use(quickFiltersPromise) —
            catches the brief suspension on first page load while quick-filter
            pills resolve. After that the promise is cached and renders instantly. */}
        <Suspense fallback={null}>
          <SearchHero
            activeFilters={activeFilters}
            onRemoveFilter={removeFilter}
            onReset={resetFilters}
            onSearch={() => {
              setCurrentPage(1);
            }}
            onSearchChange={(query) => {
              searchQueryRef.current = query;
              setSearchQuery(query);
            }}
            onToggleFilter={() => setIsFilterOpen(true)}
            searchQuery={displaySearchQuery}
            suggestedPills={initialQuickFilters}
            vehicleCount={totalCount}
            vehiclesAvailable={totalCount}
          />
        </Suspense>

        <div className="mx-6 md:mx-0">
          <div className="relative h-px overflow-hidden bg-(--color-structure-interaction-subtle-border)">
            <div
              aria-hidden
              // suppressHydrationWarning: the progress bar is a purely decorative
              // animation driven by client-only timers. Its style is intentionally
              // different between the server render (width 0, opacity 0) and the
              // first client frame (where a fetch may already be in-flight).
              // React should skip diffing this element's attributes during hydration
              // rather than leaving the mismatch unpatched.
              className="absolute top-0 left-0 h-full"
              style={{
                width: `${progress}%`,
                opacity: isProgressVisible ? 1 : 0,
                background: "var(--primary)",
                transition: getProgressTransition(progress),
              }}
              suppressHydrationWarning
            />
          </div>
        </div>

        <VehicleResults
          activeFilters={activeFilters}
          currentPage={currentPage}
          isInitialLoading={isInitialLoading}
          isPending={isPending}
          itemsPerPage={itemsPerPage}
          onApplyRefineFilters={applyRefineFilters}
          onPageChange={setCurrentPage}
          onRemoveFilter={removeFilter}
          onReset={resetFilters}
          onSearch={() => {
            setCurrentPage(1);
          }}
          onToggleFilter={() => setIsFilterOpen(true)}
          searchQuery={searchQuery}
          totalCount={deferredTotalCount}
          vehicles={deferredVehicles}
        />
      </main>
    </div>
  );
}
