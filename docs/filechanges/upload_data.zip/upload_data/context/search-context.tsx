"use client";

import { useDebouncedValue } from "@shared/hooks/use-debounced-value";
import { createContext, useCallback, useContext, useMemo, useTransition } from "react";
import { useSearchQueries } from "./search-context-queries";
import { useSearchState } from "./search-context-state";
import type { SearchContextValue, SearchProviderProps } from "./search-context-types";

const SearchContext = createContext<SearchContextValue | undefined>(undefined);

export function useSearchContext() {
  const ctx = useContext(SearchContext);
  if (!ctx) {
    throw new Error("useSearchContext must be used within SearchProvider");
  }
  return ctx;
}

export function SearchProvider({
  children,
  initialBodyStyles = [],
  initialSearchQuery = "",
  initialTotalCount = 0,
  initialUrlFilters,
  initialVehicles = [],
  defaultFilterState,
}: SearchProviderProps) {
  // For low-priority UI transitions
  const [isFilterPending, startFilterTransition] = useTransition();
  const state = useSearchState({
    defaultFilterState,
    initialBodyStyles,
    initialSearchQuery,
    initialTotalCount,
    initialUrlFilters,
    initialVehicles,
  });

  const {
    sortOption,
    setSortOption,
    vehiclePool,
    setVehiclePool,
    filterState,
    setFilterState,
    searchQuery,
    setSearchQuery,
    searchQueryRef,
    labelFilter,
    setLabelFilter,
    refineSearchFilters,
    setRefineSearchFilters,
    isFilterOpen,
    setIsFilterOpen,
    currentPage,
    setCurrentPage,
    progress,
    setProgress,
    isProgressVisible,
    setIsProgressVisible,
    availableFilters,
    setAvailableFilters,
    facetCounts,
    setFacetCounts,
    totalCount,
    setTotalCount,
    pendingFacetSections,
    setPendingFacetSections,
    loadingFacetSections,
    setLoadingFacetSections,
    setSearchId,
    setFilterId,
    handleSearch,
    applyFiltersSearch,
  } = state;

  const searchRequestPayload = useMemo<MockFacetedSearchRequest>(
    () => ({
      filterState,
      searchQuery,
      labelFilter,
      refineFilters: refineSearchFilters,
      sortOption,
      page: currentPage,
      pageSize: 20,
      includeFacets: false,
    }),
    [filterState, searchQuery, labelFilter, refineSearchFilters, sortOption, currentPage]
  );

  const filterRequestPayload = useMemo<MockFilterSearchRequest>(
    () => ({
      filterState,
      searchQuery,
      labelFilter,
      refineFilters: refineSearchFilters,
      updatedSections: pendingFacetSections,
    }),
    [filterState, searchQuery, labelFilter, refineSearchFilters, pendingFacetSections]
  );

  const debouncedSearchRequest = useDebouncedValue(searchRequestPayload, 300);
  const debouncedFilterRequest = useDebouncedValue(filterRequestPayload, 300);

  const { isSearching, isInitialLoading } = useSearchQueries(
    debouncedSearchRequest,
    debouncedFilterRequest,
    {
      setVehiclePool,
      setTotalCount,
      setSearchId,
      setAvailableFilters,
      setFacetCounts,
      setPendingFacetSections,
      setFilterId,
      setLoadingFacetSections,
      handleSearch,
    },
    initialVehicles.length > 0
  );

  // Wrapped setters that go through startFilterTransition so sort/label changes
  // are scheduled at low priority and keep the main thread free (Fix 1.4).
  const setSortOptionTransitioned = useCallback(
    (value) => {
      startFilterTransition(() => {
        state.setSortOption(value);
      });
    },
    [state.setSortOption]
  );

  const setLabelFilterTransitioned = useCallback(
    (value) => {
      startFilterTransition(() => {
        state.setLabelFilter(value);
      });
    },
    [state.setLabelFilter]
  );

  const contextValue = useMemo(
    () => ({
      vehiclePool: state.vehiclePool,
      setVehiclePool: state.setVehiclePool,
      filterState: state.filterState,
      setFilterState: state.setFilterState,
      searchQuery: state.searchQuery,
      setSearchQuery: state.setSearchQuery,
      searchQueryRef: state.searchQueryRef,
      labelFilter: state.labelFilter,
      setLabelFilter: setLabelFilterTransitioned,
      refineSearchFilters: state.refineSearchFilters,
      setRefineSearchFilters: state.setRefineSearchFilters,
      currentPage: state.currentPage,
      setCurrentPage: state.setCurrentPage,
      progress: state.progress,
      setProgress: state.setProgress,
      isProgressVisible: state.isProgressVisible,
      setIsProgressVisible: state.setIsProgressVisible,
      isFilterOpen: state.isFilterOpen,
      setIsFilterOpen: state.setIsFilterOpen,
      sortOption: state.sortOption,
      setSortOption: setSortOptionTransitioned,
      availableFilters: state.availableFilters,
      facetCounts: state.facetCounts,
      totalCount: state.totalCount,
      isInitialLoading,
      isSearching,
      isFilterPending,
      loadingFacetSections: state.loadingFacetSections,
      applyFiltersSearch: state.applyFiltersSearch,
      handleSearch: state.handleSearch,
    }),
    [
      state.vehiclePool,
      state.setVehiclePool,
      state.filterState,
      state.setFilterState,
      state.searchQuery,
      state.setSearchQuery,
      state.searchQueryRef,
      state.labelFilter,
      setLabelFilterTransitioned,
      state.refineSearchFilters,
      state.setRefineSearchFilters,
      state.currentPage,
      state.setCurrentPage,
      state.progress,
      state.setProgress,
      state.isProgressVisible,
      state.setIsProgressVisible,
      state.isFilterOpen,
      state.setIsFilterOpen,
      state.sortOption,
      setSortOptionTransitioned,
      state.availableFilters,
      state.facetCounts,
      state.totalCount,
      isInitialLoading,
      isSearching,
      isFilterPending,
      state.loadingFacetSections,
      state.applyFiltersSearch,
      state.handleSearch,
    ]
  );

  return <SearchContext.Provider value={contextValue}>{children}</SearchContext.Provider>;
}
