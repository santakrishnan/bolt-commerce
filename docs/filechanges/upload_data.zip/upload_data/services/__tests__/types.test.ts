import { describe, expect, it } from "vitest";
import type { SearchPagination, SearchQuery, SearchResult, SearchVehicle } from "../types";

// These tests are intentionally runtime checks of example objects that are
// typed with the exported interfaces. The TypeScript compiler will validate
// the shapes at build/compile time while the runtime assertions verify the
// example objects contain the expected keys and values.

describe("types: Search types smoke tests", () => {
  it("SearchVehicle sample conforms and has required runtime properties", () => {
    const vehicle: SearchVehicle = {
      id: 1,
      image: "/img.jpg",
      labels: ["one"],
      make: "Toyota",
      match: 90,
      miles: "10,000",
      model: "Camry",
      odometer: "10,000",
      owners: 1,
      price: 15_000,
      title: "2019 Toyota Camry",
      variant: "base",
      vin: "VIN123",
      year: 2019,
    };

    expect(vehicle).toBeDefined();
    expect(typeof vehicle.id).toBe("number");
    expect(typeof vehicle.make).toBe("string");
    expect(Array.isArray(vehicle.labels)).toBe(true);
    expect(vehicle.price).toBeGreaterThan(0);
  });

  it("SearchResult and SearchPagination sample preserve numeric metadata", () => {
    const pagination: SearchPagination = { page: 1, pageSize: 20, totalPages: 1, totalResults: 1 };

    const vehicle: SearchVehicle = {
      id: 2,
      image: ["/a.png"],
      labels: [],
      make: "Honda",
      match: 50,
      miles: "5,000",
      model: "Civic",
      odometer: "5,000",
      owners: 2,
      price: 12_000,
      title: "2020 Honda Civic",
      variant: "EX",
      vin: "VIN456",
      year: 2020,
    };

    const result: SearchResult = { vehicles: [vehicle], pagination };

    expect(result.vehicles.length).toBe(1);
    expect(result.pagination.page).toBe(1);
    expect(result.pagination.totalResults).toBeGreaterThanOrEqual(0);
  });

  it("SearchQuery accepts optional filters and preserves values at runtime", () => {
    const q: SearchQuery = {
      query: "test",
      page: 3,
      pageSize: 5,
      priceMin: 1000,
      priceMax: 5000,
      yearMin: 2015,
      yearMax: 2021,
      sortBy: "price",
      sortOrder: "asc",
    };

    expect(q.query).toBe("test");
    expect(q.page).toBe(3);
    expect(q.sortBy).toBe("price");
    expect(q.sortOrder).toBe("asc");
  });
});
