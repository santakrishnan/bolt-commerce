"use client";

import { useFavorites } from "@features/favorites/context/favorites-provider";
import { Button } from "@tfs-ucmp/ui";
import Image from "next/image";
import { useCallback, useEffect, useState } from "react";

interface FavoriteButtonProps {
  className?: string;
  vin: string;
}

/**
 * FavoriteButton
 * Displays a heart icon (filled when saved)
 * Toggles favorite state for the given VIN when clicked
 * Plays a short animation when toggled
 */
export function FavoriteButton({ vin, className }: FavoriteButtonProps) {
  const { isVehicleSaved, toggleVehicle } = useFavorites();
  const liked = isVehicleSaved(vin);
  const [animating, setAnimating] = useState(false);

  const handleClick = useCallback(
    (e: React.MouseEvent) => {
      e.stopPropagation();
      toggleVehicle(vin);
      setAnimating(true);
    },
    [toggleVehicle, vin]
  );

  useEffect(() => {
    if (!animating) {
      return undefined;
    }
    const timer = setTimeout(() => setAnimating(false), 500);
    return () => clearTimeout(timer);
  }, [animating]);

  return (
    <Button
      aria-label={liked ? "Remove from favorites" : "Add to favorites"}
      className={`heart-button h-9 w-9 rounded-full bg-white hover:bg-gray-50 ${animating ? "animate" : ""} ${className ?? ""}`}
      onClick={handleClick}
      size="icon"
      type="button"
      variant="ghost"
    >
      <Image
        alt="Favorite"
        height={36}
        src={`/images/garage/heart${liked ? "-filled" : ""}.svg`}
        width={36}
      />
    </Button>
  );
}
