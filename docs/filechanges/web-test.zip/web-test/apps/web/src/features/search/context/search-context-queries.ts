import type { AvailableFilters } from "@features/search/components/filter-sidebar/types";
import type {
  FacetSection,
  MockFacetedSearchRequest,
  MockFilterSearchRequest,
  SmartFilterGroup,
} from "@features/search/lib/mock-faceted-search";
import type { FacetCounts } from "@features/search/lib/mock-search-service";
import type { Vehicle } from "@features/search/lib/mock-vehicles";
import { useQuery } from "@tanstack/react-query";
import type { Dispatch, SetStateAction } from "react";
import { useEffect } from "react";
import { fetchFilters, fetchVehicleSearch } from "./search-context-utils";

interface Callbacks {
  handleSearch: () => void;
  setAvailableFilters: Dispatch<SetStateAction<AvailableFilters>>;
  setFacetCounts: Dispatch<SetStateAction<FacetCounts>>;
  setFilterId: (id: string) => void;
  setLoadingFacetSections: Dispatch<SetStateAction<FacetSection[]>>;
  setPendingFacetSections: Dispatch<SetStateAction<FacetSection[]>>;
  setSearchId: (id: string) => void;
  setSmartFilters?: Dispatch<SetStateAction<SmartFilterGroup[]>>;
  setTotalCount: (n: number) => void;
  setVehiclePool: Dispatch<SetStateAction<Vehicle[]>>;
}

export function useSearchQueries(
  debouncedSearchRequest: MockFacetedSearchRequest,
  debouncedFilterRequest: MockFilterSearchRequest,
  callbacks: Callbacks,
  hasServerData = false
) {
  const vehicleSearchQuery = useQuery({
    queryKey: ["vehicle-search", debouncedSearchRequest],
    queryFn: () => fetchVehicleSearch(debouncedSearchRequest),
    enabled: true,
    placeholderData: (prev) => prev,
    staleTime: hasServerData ? 30_000 : 20_000,
    refetchOnWindowFocus: false,
    retry: 1,
    structuralSharing: true,
  });

  const filtersQuery = useQuery({
    queryKey: ["search-filters", debouncedFilterRequest],
    queryFn: () => fetchFilters(debouncedFilterRequest),
    enabled: debouncedFilterRequest.updatedSections
      ? debouncedFilterRequest.updatedSections.length > 0
      : false,
    placeholderData: (prev) => prev,
    staleTime: 20_000,
    refetchOnWindowFocus: false,
    retry: 1,
    structuralSharing: true,
  });

  useEffect(() => {
    const data = vehicleSearchQuery.data;
    if (!data) {
      return;
    }

    const maxInventory = data.metadata.inventorySize;
    const boundedTotalCount = Math.max(0, Math.min(data.totalCount, maxInventory));

    callbacks.setVehiclePool(data.vehicles);
    callbacks.setTotalCount(boundedTotalCount);
    callbacks.setSmartFilters?.(data.smartFilters ?? []);

    if (data.metadata.searchId) {
      callbacks.setSearchId(data.metadata.searchId);
    }
  }, [
    vehicleSearchQuery.data,
    callbacks.setSearchId,
    callbacks.setTotalCount,
    callbacks.setVehiclePool,
    callbacks.setSmartFilters,
  ]);

  useEffect(() => {
    const data = filtersQuery.data;
    if (!data) {
      return;
    }

    if (data.facets.updatedSections.length > 0) {
      callbacks.setAvailableFilters((prev) => ({
        ...prev,
        ...data.facets.availableFiltersPatch,
      }));
      callbacks.setFacetCounts((prev) => ({
        ...prev,
        ...data.facets.facetCountsPatch,
      }));

      callbacks.setPendingFacetSections((prev: FacetSection[]) => {
        if (prev.length === 0) {
          return prev;
        }
        return [];
      });
    }

    if (data.filterId) {
      callbacks.setFilterId(data.filterId);
    }

    callbacks.setLoadingFacetSections((prev: FacetSection[]) =>
      prev.filter((section) => !data.facets.updatedSections.includes(section))
    );
  }, [
    filtersQuery.data,
    callbacks.setAvailableFilters,
    callbacks.setFacetCounts,
    callbacks.setPendingFacetSections,
    callbacks.setFilterId,
    callbacks.setLoadingFacetSections,
  ]);

  useEffect(() => {
    if (vehicleSearchQuery.isFetching) {
      callbacks.handleSearch();
    }
  }, [vehicleSearchQuery.isFetching, callbacks.handleSearch]);

  const isInitialLoading = vehicleSearchQuery.isLoading && !hasServerData;

  return {
    vehicleSearchQuery,
    filtersQuery,
    isSearching: vehicleSearchQuery.isFetching || filtersQuery.isFetching,
    isInitialLoading,
  };
}
