import type {
  AvailableFilters,
  FilterState,
} from "@features/search/components/filter-sidebar/types";
import { SEARCH_PAGE_SIZE } from "@features/search/lib/constants";
import { filterSections } from "@features/search/lib/filter-sections";
import { mockVehicles, type Vehicle } from "./mock-vehicles";

export type { AvailableFilters } from "@features/search/components/filter-sidebar/types";

export type SortOption = "recommended" | "low-high" | "high-low";

export interface RefineFilter {
  id: string;
  label: string;
}

export interface SearchFilterRequest {
  filterState: FilterState;
  labelFilter?: string;
  page?: number;
  pageSize?: number;
  refineFilters?: RefineFilter[];
  searchQuery?: string;
  sortOption?: SortOption;
  vehicles?: Vehicle[];
}

export interface SearchFilterResult {
  availableFilters: AvailableFilters;
  facetCounts: FacetCounts;
  page: number;
  pageSize: number;
  totalCount: number;
  vehicles: Vehicle[];
}

export interface FacetCounts {
  bodyType: Record<string, number>;
  drivetrain: Record<string, number>;
  exteriorColor: Record<string, number>;
  fuelType: Record<string, number>;
  interiorColor: Record<string, number>;
  mileageRange: Record<string, number>;
  priceRange: Record<string, number>;
  transmission: Record<string, number>;
  yearRange: Record<string, number>;
}

const PRICE_LIMITS: Record<string, number> = {
  "Cars Under $20,000": 19_999,
  "$10k or less": 10_000,
  "$20k or less": 20_000,
  "$30k or less": 30_000,
  "$40k or less": 40_000,
  "$50k or less": 50_000,
};

const MILEAGE_LIMITS: Record<string, number> = {
  "Low Miles": 19_999,
  "Under 15k mi": 15_000,
  "Under 30k mi": 30_000,
  "Under 50k mi": 50_000,
  "Under 75k mi": 75_000,
  "Under 100k mi": 100_000,
};

const YEAR_RANGES: Record<string, { min?: number; max?: number }> = {
  "2023 or newer": { min: 2023 },
  "2019-2021": { min: 2019, max: 2021 },
  "2015-2018": { min: 2015, max: 2018 },
  "pre-2015": { max: 2014 },
};

export const PRICE_BUCKET_LABELS: Record<string, string> = {
  "under-10k": "Under $10k",
  "10k-20k": "$10k–20k",
  "20k-30k": "$20k–30k",
  "30k-40k": "$30k–40k",
  "40k-50k": "$40k–50k",
  "50k-plus": "$50k+",
};

export const MILEAGE_BUCKET_LABELS: Record<string, string> = {
  "under-15k": "Under 15k mi",
  "15k-30k": "15k–30k mi",
  "30k-50k": "30k–50k mi",
  "50k-75k": "50k–75k mi",
  "75k-100k": "75k–100k mi",
  "100k-plus": "100k+ mi",
};

export const YEAR_BUCKET_LABELS: Record<string, string> = {
  "2023-or-newer": "2023 or newer",
  "2022": "2022",
  "2019-2021": "2019–2021",
  "2015-2018": "2015–2018",
  "pre-2015": "Pre-2015",
};

const TEXT_SEARCH_SHORTCUTS: Record<string, (v: Vehicle) => boolean> = {
  "cars under $20,000": (v) => v.price < 20_000,
  "cars-under-$20,000": (v) => v.price < 20_000,
  "shop excellent deals": (v) => v.labels.some((l) => l.toLowerCase().includes("excellent price")),
  "shop-excellent-deals": (v) => v.labels.some((l) => l.toLowerCase().includes("excellent price")),
  "low miles": (v) => v.mileage < 20_000,
  "low-miles": (v) => v.mileage < 20_000,
  "price drop": (v) => v.labels.some((l) => l.toLowerCase().includes("price drop")),
  "price-drop": (v) => v.labels.some((l) => l.toLowerCase().includes("price drop")),
};

/**
 * Convert a fuel label like "Gasoline (reg)" to its key "Gasoline".
 */
function fuelLabelToKey(label: string): string {
  return label.split("(")[0]?.trim() ?? label;
}

/**
 * Return true if all required items exist in available.
 */
function hasAll(available: string[], required: string[]): boolean {
  return required.every((r) => available.includes(r));
}

/**
 * Check if vehicle has a label matching the provided label filter.
 */
function matchesLabelFilter(vehicle: Vehicle, labelFilter: string): boolean {
  if (!labelFilter) {
    return true;
  }
  return vehicle.labels.some((l) => l.toLowerCase().includes(labelFilter.toLowerCase()));
}

/**
 * Check if vehicle matches any of the selected body styles.
 */
function matchesBodyStyle(vehicle: Vehicle, s: FilterState): boolean {
  if (s.selectedBodyStyles.length === 0) {
    return true;
  }
  return s.selectedBodyStyles.some((bs) => bs.toLowerCase() === vehicle.bodyType.toLowerCase());
}

/**
 * Check if vehicle price satisfies the selected quick price filter.
 */
function matchesPriceFilter(vehicle: Vehicle, s: FilterState): boolean {
  const max = PRICE_LIMITS[s.selectedPriceQuick];
  return max === undefined ? true : vehicle.price <= max;
}

/**
 * Check if vehicle mileage satisfies the selected quick mileage filter.
 */
function matchesMileageFilter(vehicle: Vehicle, s: FilterState): boolean {
  const max = MILEAGE_LIMITS[s.selectedMileage];
  return max === undefined ? true : vehicle.mileage <= max;
}

/**
 * Check if vehicle year falls within the selected quick year range.
 */
function matchesYearFilter(vehicle: Vehicle, s: FilterState): boolean {
  if (!s.selectedYearQuick) {
    return true;
  }
  const range = YEAR_RANGES[s.selectedYearQuick];
  if (!range) {
    return true;
  }
  if (range.min !== undefined && vehicle.year < range.min) {
    return false;
  }
  if (range.max !== undefined && vehicle.year > range.max) {
    return false;
  }
  return true;
}

/**
 * Check if vehicle matches selected exterior and interior colors.
 */
function matchesColors(vehicle: Vehicle, s: FilterState): boolean {
  if (
    s.selectedExteriorColors.length > 0 &&
    !s.selectedExteriorColors.includes(vehicle.extColorName)
  ) {
    return false;
  }
  if (
    s.selectedInteriorColors.length > 0 &&
    !s.selectedInteriorColors.includes(vehicle.intColorName)
  ) {
    return false;
  }
  return true;
}

/**
 * Check if vehicle title/model matches any selected models.
 */
function matchesModel(vehicle: Vehicle, s: FilterState): boolean {
  if (s.selectedModels.length === 0) {
    return true;
  }
  const titleLower = vehicle.title.toLowerCase();
  return s.selectedModels.some((m) => titleLower.includes(m.toLowerCase()));
}

/**
 * Apply enrichment filters (fuel, drivetrain, transmission, inspection, features).
 */
function matchesEnrichmentFilters(vehicle: Vehicle, s: FilterState): boolean {
  if (!matchesFuelType(vehicle, s)) {
    return false;
  }
  if (s.selectedDrivetrains.length > 0 && !s.selectedDrivetrains.includes(vehicle.drivetrain)) {
    return false;
  }
  if (
    s.selectedTransmissions.length > 0 &&
    !s.selectedTransmissions.includes(vehicle.transmission)
  ) {
    return false;
  }
  if (s.inspection160 && !vehicle.inspection160) {
    return false;
  }
  return matchesFeatureSets(vehicle, s);
}

/**
 * Check if vehicle fuel type matches any selected fuel types.
 */
function matchesFuelType(vehicle: Vehicle, s: FilterState): boolean {
  if (s.selectedFuelTypes.length === 0) {
    return true;
  }
  const keys = s.selectedFuelTypes.map(fuelLabelToKey);
  return keys.some((k) => vehicle.fuelType.toLowerCase() === k.toLowerCase());
}

/**
 * Check if vehicle contains all selected items across feature sets.
 */
function matchesFeatureSets(vehicle: Vehicle, s: FilterState): boolean {
  if (
    s.selectedSafetyFeatures.length > 0 &&
    !hasAll(vehicle.features.safety, s.selectedSafetyFeatures)
  ) {
    return false;
  }
  if (
    s.selectedComfortFeatures.length > 0 &&
    !hasAll(vehicle.features.comfort, s.selectedComfortFeatures)
  ) {
    return false;
  }
  if (s.selectedTechFeatures.length > 0 && !hasAll(vehicle.features.tech, s.selectedTechFeatures)) {
    return false;
  }
  if (
    s.selectedExteriorFeatures.length > 0 &&
    !hasAll(vehicle.features.exterior, s.selectedExteriorFeatures)
  ) {
    return false;
  }
  if (
    s.selectedPerformanceFeatures.length > 0 &&
    !hasAll(vehicle.features.performance, s.selectedPerformanceFeatures)
  ) {
    return false;
  }
  if (
    s.selectedSeatingCapacity.length > 0 &&
    !hasAll(vehicle.seatingCapacity, s.selectedSeatingCapacity)
  ) {
    return false;
  }
  return true;
}

/**
 * Check if vehicle features satisfy all provided refine filters.
 */
function matchesRefineFilters(vehicle: Vehicle, refineFilters: RefineFilter[]): boolean {
  if (!refineFilters || refineFilters.length === 0) {
    return true;
  }

  const checkOwnership = (val: string) => {
    const m = OWNERSHIP_REGEX.exec(val);
    if (m) {
      const owners = Number(m[1]);
      return vehicle.owners === owners;
    }
    return false;
  };

  const checkReliability = (val: string) => {
    return val === "excellent"
      ? (vehicle.labels?.some((l) => l.toLowerCase().includes("excellent")) ?? false)
      : false;
  };

  const allFeatures = [
    ...vehicle.features.safety,
    ...vehicle.features.comfort,
    ...vehicle.features.tech,
    ...vehicle.features.exterior,
    ...vehicle.features.performance,
  ].map((f) => f.toLowerCase());

  return refineFilters.every((r) => {
    const [group, val] = r.id.split(":");
    if (group === "ownership_history") {
      return checkOwnership(val);
    }
    if (group === "reliability_rating") {
      return checkReliability(val);
    }
    const label = (r.label || "").toLowerCase();
    if (
      vehicle.labels?.includes(r.id) ||
      vehicle.labels?.some((l) => l.toLowerCase().includes(label))
    ) {
      return true;
    }
    return allFeatures.some((f) => f.includes(label) || label.includes(f));
  });
}

const BODY_TYPE_SET: Set<string> = new Set(filterSections.bodyStyle.map((s) => s.toLowerCase()));

const PRICE_PATTERN = /(?:under|below|less than)\s*\$?([\d,]+)\s*(k)?/i;

const MILEAGE_PATTERN = /(?:under|below|less than)\s*\$?([\d,]+)\s*k?\s*(?:miles?|mi)/i;
const LOW_MILES_PATTERN = /\blow[\s-]?(?:miles?|mileage)\b/i;
const OWNERSHIP_REGEX = /(\d+)_owner/;

/**
 * Parse a compound textual query into an array of predicate functions.
 */
function parseCompoundQuery(query: string): ((v: Vehicle) => boolean)[] | null {
  const normalized = query.replace(/[-_]+/g, " ").replace(/\s+/g, " ").trim().toLowerCase();
  if (!normalized) {
    return null;
  }

  const predicates: ((v: Vehicle) => boolean)[] = [];
  let remaining = normalized;

  for (const bodyType of BODY_TYPE_SET) {
    const re = new RegExp(`\\b${bodyType}s?\\b`, "i");
    if (re.test(remaining)) {
      const bt = bodyType;
      predicates.push((v) => v.bodyType.toLowerCase() === bt);
      remaining = remaining.replace(re, " ").trim();
    }
  }

  if (LOW_MILES_PATTERN.test(remaining)) {
    predicates.push((v) => v.mileage < 20_000);
    remaining = remaining.replace(LOW_MILES_PATTERN, " ").trim();
  }

  const mileageMatch = remaining.match(MILEAGE_PATTERN);
  if (mileageMatch) {
    const rawNum = Number(mileageMatch[1]?.replace(/,/g, "") ?? "0");
    const multiplier = mileageMatch[2]?.toLowerCase() === "k" ? 1000 : 1;
    const maxMileage = rawNum * multiplier;
    predicates.push((v) => v.mileage <= maxMileage);
    remaining = remaining.replace(MILEAGE_PATTERN, " ").trim();
  }

  const priceMatch = remaining.match(PRICE_PATTERN);
  if (priceMatch) {
    const rawNum = Number(priceMatch[1]?.replace(/,/g, "") ?? "0");
    const multiplier = priceMatch[2]?.toLowerCase() === "k" ? 1000 : 1;
    const maxPrice = rawNum * multiplier;
    predicates.push((v) => v.price <= maxPrice);
    remaining = remaining.replace(PRICE_PATTERN, " ").trim();
  }

  remaining = remaining
    .replace(/\b(with|and|the|a|an|in|near|for|has|have)\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  if (remaining.length > 0) {
    const keywords = remaining.split(" ").filter((t) => t.length > 1);
    for (const kw of keywords) {
      const keyword = kw;
      predicates.push(
        (v) =>
          v.title.toLowerCase().includes(keyword) ||
          v.bodyType.toLowerCase().includes(keyword) ||
          v.labels.some((l) => l.toLowerCase().includes(keyword)) ||
          v.fuelType.toLowerCase().includes(keyword) ||
          v.miles.toLowerCase().includes(keyword)
      );
    }
  }

  return predicates.length ? predicates : null;
}

let _cachedQuery = "";
let _cachedPredicates: ((v: Vehicle) => boolean)[] | null = null;

/**
 * Return cached predicates for a query, parsing and caching when changed.
 */
function getCachedPredicates(q: string): ((v: Vehicle) => boolean)[] | null {
  if (q !== _cachedQuery) {
    _cachedQuery = q;
    _cachedPredicates = parseCompoundQuery(q);
  }
  return _cachedPredicates;
}

function scoreCompoundMatch(v: Vehicle, predicates: ((v: Vehicle) => boolean)[]): number {
  if (!predicates || predicates.length === 0) {
    return 0;
  }
  let hits = 0;
  for (const p of predicates) {
    try {
      if (p(v)) {
        hits++;
      }
    } catch {
      // ignore predicate errors
    }
  }
  return hits / predicates.length;
}

/**
 * Determine if a vehicle matches the provided textual search query.
 */
function matchesTextSearch(vehicle: Vehicle, searchQuery: string): boolean {
  const q = searchQuery.trim().toLowerCase();
  if (!q) {
    return true;
  }

  const shortcut = TEXT_SEARCH_SHORTCUTS[q];
  if (shortcut) {
    return shortcut(vehicle);
  }

  const predicates = getCachedPredicates(q);
  if (predicates) {
    return predicates.every((pred) => pred(vehicle));
  }

  return (
    vehicle.title.toLowerCase().includes(q) ||
    vehicle.bodyType.toLowerCase().includes(q) ||
    vehicle.miles.toLowerCase().includes(q) ||
    vehicle.labels.some((l) => l.toLowerCase().includes(q)) ||
    vehicle.fuelType.toLowerCase().includes(q)
  );
}

/**
 * Check whether a vehicle satisfies all filters, search, and refine filters.
 */
function matchesFilters(
  vehicle: Vehicle,
  s: FilterState,
  searchQuery: string,
  labelFilter: string,
  refineFilters: RefineFilter[]
): boolean {
  return (
    matchesLabelFilter(vehicle, labelFilter) &&
    matchesBodyStyle(vehicle, s) &&
    matchesPriceFilter(vehicle, s) &&
    matchesMileageFilter(vehicle, s) &&
    matchesYearFilter(vehicle, s) &&
    matchesColors(vehicle, s) &&
    matchesModel(vehicle, s) &&
    matchesEnrichmentFilters(vehicle, s) &&
    matchesRefineFilters(vehicle, refineFilters) &&
    matchesTextSearch(vehicle, searchQuery)
  );
}

/**
 * Map a price value to its price bucket key.
 */
function getVehiclePriceBucket(price: number): string {
  if (price < 10_000) {
    return "under-10k";
  }
  if (price < 20_000) {
    return "10k-20k";
  }
  if (price < 30_000) {
    return "20k-30k";
  }
  if (price < 40_000) {
    return "30k-40k";
  }
  if (price < 50_000) {
    return "40k-50k";
  }
  return "50k-plus";
}

/**
 * Map a mileage value to its mileage bucket key.
 */
function getVehicleMileageBucket(mileage: number): string {
  if (mileage < 15_000) {
    return "under-15k";
  }
  if (mileage < 30_000) {
    return "15k-30k";
  }
  if (mileage < 50_000) {
    return "30k-50k";
  }
  if (mileage < 75_000) {
    return "50k-75k";
  }
  if (mileage < 100_000) {
    return "75k-100k";
  }
  return "100k-plus";
}

/**
 *  Map a year value to its year bucket key.
 */
function getVehicleYearBucket(year: number): string {
  if (year >= 2023) {
    return "2023-or-newer";
  }
  if (year === 2022) {
    return "2022";
  }
  if (year >= 2019 && year <= 2021) {
    return "2019-2021";
  }
  if (year >= 2015 && year <= 2018) {
    return "2015-2018";
  }
  return "pre-2015";
}

/**
 * Increment facet counters based on a vehicle's attributes.
 */
function countFacets(
  v: Vehicle,
  facetAcc: {
    bodyType: Record<string, number>;
    fuelType: Record<string, number>;
    drivetrain: Record<string, number>;
    transmission: Record<string, number>;
    priceRange: Record<string, number>;
    mileageRange: Record<string, number>;
    yearRange: Record<string, number>;
    exteriorColor: Record<string, number>;
    interiorColor: Record<string, number>;
  }
) {
  const priceBucket = getVehiclePriceBucket(v.price);
  const mileageBucket = getVehicleMileageBucket(v.mileage);
  const yearBucket = getVehicleYearBucket(v.year);

  facetAcc.bodyType[v.bodyType] = (facetAcc.bodyType[v.bodyType] ?? 0) + 1;
  facetAcc.fuelType[v.fuelType] = (facetAcc.fuelType[v.fuelType] ?? 0) + 1;
  facetAcc.drivetrain[v.drivetrain] = (facetAcc.drivetrain[v.drivetrain] ?? 0) + 1;
  facetAcc.transmission[v.transmission] = (facetAcc.transmission[v.transmission] ?? 0) + 1;
  facetAcc.exteriorColor[v.extColorName] = (facetAcc.exteriorColor[v.extColorName] ?? 0) + 1;
  facetAcc.interiorColor[v.intColorName] = (facetAcc.interiorColor[v.intColorName] ?? 0) + 1;
  facetAcc.priceRange[priceBucket] = (facetAcc.priceRange[priceBucket] ?? 0) + 1;
  facetAcc.mileageRange[mileageBucket] = (facetAcc.mileageRange[mileageBucket] ?? 0) + 1;
  facetAcc.yearRange[yearBucket] = (facetAcc.yearRange[yearBucket] ?? 0) + 1;
}

interface FilterAccumulator {
  bodyStyles: Set<string>;
  comfortFeatures: Set<string>;
  drivetrains: Set<string>;
  exteriorColors: Set<string>;
  exteriorFeatures: Set<string>;
  fuelTypes: Set<string>;
  hasInspection160: boolean;
  interiorColors: Set<string>;
  models: Set<string>;
  performanceFeatures: Set<string>;
  safetyFeatures: Set<string>;
  seatingCapacity: Set<string>;
  techFeatures: Set<string>;
  transmissions: Set<string>;
}

/**
 * Add a vehicle's attributes into the available filters accumulator.
 */
function accumulateAvailableFilters(v: Vehicle, filterAcc: FilterAccumulator) {
  filterAcc.bodyStyles.add(v.bodyType);
  filterAcc.fuelTypes.add(v.fuelType);
  filterAcc.drivetrains.add(v.drivetrain);
  filterAcc.transmissions.add(v.transmission);
  filterAcc.exteriorColors.add(v.extColorName);
  filterAcc.interiorColors.add(v.intColorName);
  filterAcc.models.add(v.model);
  if (v.inspection160) {
    filterAcc.hasInspection160 = true;
  }
  for (const f of v.features.safety) {
    filterAcc.safetyFeatures.add(f);
  }
  for (const f of v.features.comfort) {
    filterAcc.comfortFeatures.add(f);
  }
  for (const f of v.features.tech) {
    filterAcc.techFeatures.add(f);
  }
  for (const f of v.features.exterior) {
    filterAcc.exteriorFeatures.add(f);
  }
  for (const f of v.features.performance) {
    filterAcc.performanceFeatures.add(f);
  }
  for (const s of v.seatingCapacity) {
    filterAcc.seatingCapacity.add(s);
  }
}

/**
 * Compute available filters and facet counts from a set of vehicles.
 */
function computeFiltersAndFacets(vehicles: Vehicle[]): {
  availableFilters: AvailableFilters;
  facetCounts: FacetCounts;
} {
  const facetAcc = {
    bodyType: {} as Record<string, number>,
    fuelType: {} as Record<string, number>,
    drivetrain: {} as Record<string, number>,
    transmission: {} as Record<string, number>,
    priceRange: {} as Record<string, number>,
    mileageRange: {} as Record<string, number>,
    yearRange: {} as Record<string, number>,
    exteriorColor: {} as Record<string, number>,
    interiorColor: {} as Record<string, number>,
  };

  const filterAcc = {
    bodyStyles: new Set<string>(),
    fuelTypes: new Set<string>(),
    drivetrains: new Set<string>(),
    transmissions: new Set<string>(),
    exteriorColors: new Set<string>(),
    interiorColors: new Set<string>(),
    models: new Set<string>(),
    safetyFeatures: new Set<string>(),
    comfortFeatures: new Set<string>(),
    techFeatures: new Set<string>(),
    exteriorFeatures: new Set<string>(),
    performanceFeatures: new Set<string>(),
    seatingCapacity: new Set<string>(),
    hasInspection160: false,
  };

  for (const v of vehicles) {
    countFacets(v, facetAcc);
    accumulateAvailableFilters(v, filterAcc);
  }

  return {
    availableFilters: {
      totalCount: vehicles.length,
      hasInspection160: filterAcc.hasInspection160,
      bodyStyles: [...filterAcc.bodyStyles],
      fuelTypes: [...filterAcc.fuelTypes],
      drivetrains: [...filterAcc.drivetrains],
      transmissions: [...filterAcc.transmissions],
      exteriorColors: [...filterAcc.exteriorColors],
      interiorColors: [...filterAcc.interiorColors],
      models: [...filterAcc.models],
      safetyFeatures: [...filterAcc.safetyFeatures],
      comfortFeatures: [...filterAcc.comfortFeatures],
      techFeatures: [...filterAcc.techFeatures],
      exteriorFeatures: [...filterAcc.exteriorFeatures],
      performanceFeatures: [...filterAcc.performanceFeatures],
      seatingCapacity: [...filterAcc.seatingCapacity],
    },
    facetCounts: {
      bodyType: facetAcc.bodyType,
      fuelType: facetAcc.fuelType,
      drivetrain: facetAcc.drivetrain,
      transmission: facetAcc.transmission,
      priceRange: facetAcc.priceRange,
      mileageRange: facetAcc.mileageRange,
      yearRange: facetAcc.yearRange,
      exteriorColor: facetAcc.exteriorColor,
      interiorColor: facetAcc.interiorColor,
    },
  };
}

/**
 * Sort vehicles according to the given sort option.
 */
function applySortOption(vehicles: Vehicle[], sortOption: SortOption): Vehicle[] {
  if (sortOption === "low-high") {
    return [...vehicles].sort((a, b) => a.price - b.price);
  }
  if (sortOption === "high-low") {
    return [...vehicles].sort((a, b) => b.price - a.price);
  }
  return vehicles;
}

/**
 * Return all available filters computed from the vehicles (exported).
 */
export function buildAllAvailableFilters(vehicles: Vehicle[]): AvailableFilters {
  return computeFiltersAndFacets(vehicles).availableFilters;
}

/**
 * Return all facet counts computed from the vehicles (exported).
 */
export function buildAllFacetCounts(vehicles: Vehicle[]): FacetCounts {
  return computeFiltersAndFacets(vehicles).facetCounts;
}

/**
 * Compute available filters and facet counts synchronously using the current filter state.
 */
export function computeAvailableFiltersSync(
  allVehicles: Vehicle[],
  filterState: FilterState,
  opts?: { searchQuery?: string; labelFilter?: string; refineFilters?: RefineFilter[] }
): { availableFilters: AvailableFilters; facetCounts: FacetCounts } {
  const sq = opts?.searchQuery ?? "";
  const lf = opts?.labelFilter ?? "";
  const rf = opts?.refineFilters ?? [];

  function filterWith(override: Partial<FilterState>): Vehicle[] {
    const s = { ...filterState, ...override };
    const result = allVehicles.filter((v) => matchesFilters(v, s, sq, lf, rf));

    return result.length > 0 ? result : allVehicles;
  }

  const fullyMatched = allVehicles.filter((v) => matchesFilters(v, filterState, sq, lf, rf));
  const countSource = fullyMatched.length > 0 ? fullyMatched : allVehicles;
  const { facetCounts } = computeFiltersAndFacets(countSource);

  const forBodyStyles = filterWith({ selectedBodyStyles: [] });
  const forFuelTypes = filterWith({ selectedFuelTypes: [] });
  const forExtColors = filterWith({ selectedExteriorColors: [] });
  const forIntColors = filterWith({ selectedInteriorColors: [] });
  const forModels = filterWith({ selectedModels: [] });
  const forDrivetrains = filterWith({ selectedDrivetrains: [] });
  const forTransmissions = filterWith({ selectedTransmissions: [] });
  const forSafety = filterWith({ selectedSafetyFeatures: [] });
  const forComfort = filterWith({ selectedComfortFeatures: [] });
  const forTech = filterWith({ selectedTechFeatures: [] });
  const forExterior = filterWith({ selectedExteriorFeatures: [] });
  const forPerf = filterWith({ selectedPerformanceFeatures: [] });
  const forSeating = filterWith({ selectedSeatingCapacity: [] });
  const forInspection = filterWith({ inspection160: false });

  const availableFilters: AvailableFilters = {
    totalCount: fullyMatched.length,
    hasInspection160: forInspection.some((v) => v.inspection160),
    bodyStyles: [...new Set(forBodyStyles.map((v) => v.bodyType))],
    fuelTypes: [...new Set(forFuelTypes.map((v) => v.fuelType))],
    exteriorColors: [...new Set(forExtColors.map((v) => v.extColorName))],
    interiorColors: [...new Set(forIntColors.map((v) => v.intColorName))],
    models: [...new Set(forModels.map((v) => v.model))],
    drivetrains: [...new Set(forDrivetrains.map((v) => v.drivetrain))],
    transmissions: [...new Set(forTransmissions.map((v) => v.transmission))],
    safetyFeatures: [...new Set(forSafety.flatMap((v) => v.features.safety))],
    comfortFeatures: [...new Set(forComfort.flatMap((v) => v.features.comfort))],
    techFeatures: [...new Set(forTech.flatMap((v) => v.features.tech))],
    exteriorFeatures: [...new Set(forExterior.flatMap((v) => v.features.exterior))],
    performanceFeatures: [...new Set(forPerf.flatMap((v) => v.features.performance))],
    seatingCapacity: [...new Set(forSeating.flatMap((v) => v.seatingCapacity))],
  };

  return { availableFilters, facetCounts };
}

/**
 * Mock search endpoint: filter, score, sort, paginate vehicles and return facets.
 */
export async function mockSearchVehicles(req: SearchFilterRequest): Promise<SearchFilterResult> {
  if (process.env.NODE_ENV === "development") {
    await new Promise<void>((resolve) => setTimeout(resolve, 150 + Math.random() * 100));
  }

  const {
    filterState,
    searchQuery = "",
    labelFilter = "",
    refineFilters = [],
    vehicles = mockVehicles,
    sortOption = "recommended",
    page = 1,
    pageSize = SEARCH_PAGE_SIZE,
  } = req;

  let matched = vehicles.filter((v) =>
    matchesFilters(v, filterState, searchQuery, labelFilter, refineFilters)
  );

  if (matched.length === 0 && searchQuery.trim()) {
    const predicates = getCachedPredicates(searchQuery.trim().toLowerCase());
    if (predicates && predicates.length > 1) {
      const candidates = vehicles.filter((v) =>
        matchesFilters(v, filterState, "", labelFilter, refineFilters)
      );

      const scored = candidates
        .map((v) => ({ vehicle: v, score: scoreCompoundMatch(v, predicates) }))
        .filter((entry) => entry.score > 0)
        .sort((a, b) => b.score - a.score);

      const minScore = 1 / predicates.length;
      matched = scored.filter((e) => e.score >= minScore).map((e) => e.vehicle);
    }
  }

  const facetSource = matched.length > 0 ? matched : vehicles;
  const { availableFilters, facetCounts } = computeFiltersAndFacets(facetSource);

  const sorted = applySortOption(matched, sortOption);

  const offset = (page - 1) * pageSize;
  const paginated = sorted.slice(offset, offset + pageSize);

  return {
    vehicles: paginated,
    totalCount: matched.length,
    page,
    pageSize,
    availableFilters,
    facetCounts,
  };
}
