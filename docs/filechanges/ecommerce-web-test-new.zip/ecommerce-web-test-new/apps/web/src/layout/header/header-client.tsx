"use client";

import { ROUTES } from "@config/routes/constants";
import { lockBodyScroll, unlockBodyScroll } from "@shared/lib/body-scroll-lock";
import { useLocation } from "@shared/providers/location-provider";
import { Button, MenuIcon } from "@tfs-ucmp/ui";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { AvatarButton, MobileUserButton, SignInButton } from "./auth-buttons";
import { FavoritesButton } from "./favorites-button";
import { HeaderNav } from "./header-nav";
import { LocationBlock } from "./location-block";
import { MobileMenu } from "./mobile-menu";

interface HeaderClientProps {
  initialFirstName: string;
  initialShowPersonalized: boolean;
}

/**
 * Client header managing nav, auth buttons, and mobile menu state.
 */
export function HeaderClient({ initialShowPersonalized, initialFirstName }: HeaderClientProps) {
  const {
    state: { isResolved: locationReady },
  } = useLocation();
  const pathname = usePathname();
  const isHomePage = pathname === ROUTES.HOME;
  const isMyGaragePage = pathname === ROUTES.MY_GARAGE;
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [locationModalOpen, setLocationModalOpen] = useState(false);

  const [showUserAvatar, setShowUserAvatar] = useState(initialShowPersonalized);
  const [userFirstName, setUserFirstName] = useState(initialFirstName);

  useEffect(() => {
    setShowUserAvatar(initialShowPersonalized);
    setUserFirstName(initialFirstName);
  }, [initialShowPersonalized, initialFirstName]);

  useEffect(() => {
    const update = () => setIsScrolled(window.scrollY > 150);
    update();

    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMobileMenuOpen(false);
      }
    };
    if (mobileMenuOpen) {
      lockBodyScroll();
    }
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      if (mobileMenuOpen) {
        unlockBodyScroll();
      }
    };
  }, [mobileMenuOpen]);

  const useSolidStyles = !(isHomePage || isMyGaragePage) || isScrolled || locationModalOpen;

  useEffect(() => {
    const { classList } = document.documentElement;
    classList.toggle("bg-white", useSolidStyles);
    classList.toggle("bg-black", !useSolidStyles);
  }, [useSolidStyles]);

  return (
    <>
      <header
        className={cn(
          "absolute top-0 right-0 left-0 z-[35] w-full",
          useSolidStyles ? "slide-down fixed bg-white" : "border-transparent bg-transparent"
        )}
      >
        <div className="mx-auto flex h-16 max-w-[var(--container-2xl)] items-center px-4 sm:h-20 sm:px-6 lg:px-20">
          <div className="flex items-center lg:flex-1 xl:flex-1">
            <Link className="flex items-center gap-2.5" href={ROUTES.HOME}>
              <div aria-hidden="true" className="h-10 w-10 bg-icon-primary" />
              <span
                className={cn(
                  "font-bold text-base uppercase leading-normal lg:text-[23px] lg:leading-none",
                  useSolidStyles ? "text-text-dark" : "text-white"
                )}
                style={{ fontFamily: "var(--font-toyota-type)" }}
              >
                ARROW
              </span>
            </Link>
          </div>

          <HeaderNav useSolidStyles={useSolidStyles} />

          <div className="flex flex-1 items-center justify-end">
            <div className="flex items-center gap-3 lg:hidden">
              {locationReady && <FavoritesButton useSolidStyles={useSolidStyles} />}

              <MobileUserButton
                firstName={userFirstName}
                showAvatar={showUserAvatar}
                useSolidStyles={useSolidStyles}
              />

              <Button
                aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
                className={cn(
                  "h-9 w-9 rounded-full border transition-colors",
                  useSolidStyles
                    ? "border-border-light hover:bg-muted"
                    : "border-overlay hover:bg-background-overlay-hover"
                )}
                onClick={() => setMobileMenuOpen((s) => !s)}
                size="icon"
                type="button"
                variant="ghost"
              >
                <MenuIcon
                  className={cn(
                    "h-5 w-5 transition-colors",
                    useSolidStyles ? "text-icon-primary" : "text-white"
                  )}
                />
              </Button>
            </div>

            <div className="hidden items-center gap-6 lg:flex lg:gap-4">
              <LocationBlock
                onModalOpenChange={setLocationModalOpen}
                useSolidStyles={useSolidStyles}
              />

              {locationReady && <FavoritesButton useSolidStyles={useSolidStyles} />}

              {showUserAvatar ? (
                <AvatarButton firstName={userFirstName} useSolidStyles={useSolidStyles} />
              ) : (
                <SignInButton useSolidStyles={useSolidStyles} />
              )}
            </div>
          </div>
        </div>

        {mobileMenuOpen && <MobileMenu onClose={() => setMobileMenuOpen(false)} />}
      </header>
      {useSolidStyles && <div aria-hidden="true" className="h-16 sm:h-20" />}
    </>
  );
}
