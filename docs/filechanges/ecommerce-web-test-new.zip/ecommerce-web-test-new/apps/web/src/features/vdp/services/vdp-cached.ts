/** Cache-optimized VDP data functions for direct page-level use. Composes VIN-only cached service functions, sharing entries across all users. */

import type { DealerNotes } from "@shared/data/dealer/dealer-data";
import { cacheLife, cacheTag } from "next/cache";
import { buildDealerNotes } from "./dealer-notes";
import { fetchVehicleDataCached, fetchVinDataCached } from "./vdp.service";
import type { VehicleBundle } from "./vdp-api";

/** Cached per VIN — fetches vinData then vehicleData (sequential dependency). */
export async function getVehicleBundleCached(vin: string): Promise<VehicleBundle> {
  "use cache";
  cacheLife("vdp");
  cacheTag("vdp", `bundle-${vin}`);

  const vinData = await fetchVinDataCached(vin);
  const vehicleData = await fetchVehicleDataCached(vinData.vehicle.id);
  return { vinData, vehicleData };
}

/** Cached per VIN — builds dealer notes from VIN data. */
export async function getDealerNotesCached(vin: string): Promise<DealerNotes> {
  "use cache";
  cacheLife("vdp");
  cacheTag("vdp", `dealer-${vin}`);

  const vinData = await fetchVinDataCached(vin);
  return buildDealerNotes(vinData);
}
