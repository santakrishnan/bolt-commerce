import type {
  HistoryData,
  PillTone,
  VehicleDetail,
  VehicleMetaBarChipComponents,
  VehicleMetaCheckedChipProps,
  VehicleMetaChipProps,
  VehicleMetaColorChipProps,
  VehicleSpecData,
  VehicleStatusData,
} from "@features/vdp/data";
import { cn } from "@tfs-ucmp/ui";
import {
  exteriorColorSwatches,
  formatMileage,
  getSpecValue,
  getToneClass,
  interiorColorSwatches,
  swatchColor,
} from "./vehicle-meta-bar.constants";

function DefaultMetaChip({
  value,
  tone = "neutral",
  className,
  chipClassName,
}: VehicleMetaChipProps) {
  return (
    <div
      className={cn(
        "inline-flex min-h-7 items-center rounded-full border px-3 py-1 text-[13px] leading-[1.2]",
        "border-[#D5D5D5] bg-[#F7F7F7]",
        getToneClass(tone),
        chipClassName,
        className
      )}
    >
      <span className="font-normal">{value}</span>
    </div>
  );
}

function DefaultColorChip({ label, colorName, swatchHex }: VehicleMetaColorChipProps) {
  return (
    <div className="inline-flex min-h-7 items-center gap-2 text-(--color-core-surface-foreground) text-[13px] leading-[1.2]">
      <span
        aria-hidden="true"
        className="h-4 w-4 rounded-full border border-[#CFCFCF]"
        style={{ backgroundColor: swatchHex }}
      />
      <span className="font-medium">{label}:</span>
      <span className="font-normal">{colorName}</span>
    </div>
  );
}

function DefaultCheckedChip({ label, active }: VehicleMetaCheckedChipProps) {
  return (
    <div
      className={cn(
        "inline-flex min-h-7 items-center gap-2 text-[13px] leading-[1.2]",
        active ? "text-[#1F5F28]" : "text-[#888]"
      )}
    >
      <span
        aria-hidden="true"
        className="inline-flex h-4 w-4 items-center justify-center rounded-full bg-[#4CAF50]"
      >
        <span className="text-2xs text-white leading-none">✓</span>
      </span>
      <span className="font-medium">{label}</span>
    </div>
  );
}

interface VehicleMetaBarProps {
  chipComponents?: VehicleMetaBarChipComponents;
  className?: string;
  historyData: HistoryData;
  specs: VehicleSpecData[];
  vehicle: VehicleDetail;
  vehicleStatus: VehicleStatusData;
}

export function VehicleMetaBar({
  vehicle,
  specs,
  historyData,
  vehicleStatus,
  className,
  chipComponents,
}: VehicleMetaBarProps) {
  const MetaChip = chipComponents?.MetaChipComponent ?? DefaultMetaChip;
  const ColorChip = chipComponents?.ColorChipComponent ?? DefaultColorChip;
  const CheckedChip = chipComponents?.CheckedChipComponent ?? DefaultCheckedChip;

  const fuelType = vehicle.fuelType ?? getSpecValue(specs, "fuel-type") ?? "Unknown";
  const transmission = vehicle.transmission ?? getSpecValue(specs, "transmission") ?? "Unknown";
  const mileage = formatMileage(vehicle.miles);

  const damageCount = Math.max(0, historyData.damageReported);
  const accidentHistory =
    damageCount > 0 ? `${damageCount} Accident${damageCount > 1 ? "s" : ""}` : "No Accidents";
  const accidentTone: PillTone = damageCount > 0 ? "warning" : "success";

  const ownerCount = Math.max(0, historyData.previousOwners);
  const ownerText = `${ownerCount} Owner${ownerCount === 1 ? "" : "s"}`;
  const titleStatus = historyData.titleStatus ?? "Title Status Unavailable";

  const certified = vehicle.certified ?? vehicle.warranty;
  const inspectionPassed = vehicle.inspectionPassed ?? vehicle.inspected;
  const inspectionActive = inspectionPassed && !vehicleStatus.inspectionInProgress;

  return (
    <div className={cn("mb-4 rounded-[10px] bg-white px-4 py-3 shadow-sm md:px-6", className)}>
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 md:gap-x-5">
        <MetaChip
          chipClassName="border-[#A8C7FF] bg-[#EAF2FF] text-[#1D4EA3]"
          value={vehicle.drivetrain}
        />
        <MetaChip chipClassName="border-[#9BD8B0] bg-[#EAF9EF] text-[#1F5F28]" value={fuelType} />
        <MetaChip
          chipClassName="border-[#F3C08A] bg-[#FFF3E6] text-[#8A4B00]"
          value={transmission}
        />
        <MetaChip value={mileage} />

        <ColorChip
          colorName={vehicle.exteriorColor}
          label="Ext"
          swatchHex={swatchColor(vehicle.exteriorColor, exteriorColorSwatches)}
        />
        <ColorChip
          colorName={vehicle.interiorColor}
          label="Int"
          swatchHex={swatchColor(vehicle.interiorColor, interiorColorSwatches)}
        />

        <MetaChip
          chipClassName="border-[#F1A8A8] bg-[#FDECEC] text-[#B42323]"
          tone={accidentTone}
          value={accidentHistory}
        />
        <MetaChip chipClassName="border-[#F1A8A8] bg-[#FDECEC] text-[#B42323]" value={ownerText} />
        <MetaChip
          chipClassName="border-[#F1A8A8] bg-[#FDECEC] text-[#B42323]"
          value={titleStatus}
        />

        <CheckedChip active={certified} label="Certified" />
        <CheckedChip active={inspectionActive} label="160-Point Inspection" />
      </div>
    </div>
  );
}
