"use client";

import { useCallback, useEffect, useRef } from "react";

const STICKY_HEIGHT = 72;

// Tracks scroll position and animates the sticky CTA banner via direct DOM updates.
export function useStickyScroll(
  keyHighlightsRef: React.RefObject<HTMLDivElement | null>,
  keyHighlightsMobileRef: React.RefObject<HTMLDivElement | null>
) {
  const stickyScrollOffsetRef = useRef(0);
  const showStickyCTARef = useRef(false);
  const scrollDirectionRef = useRef<"up" | "down">("down");
  const prevScrollY = useRef(0);
  const bannerRef = useRef<HTMLDivElement>(null);

  const updateBannerStyle = useCallback(
    (scrollOffset: number, show: boolean, dir: "up" | "down") => {
      if (!bannerRef.current) {
        return;
      }
      const el = bannerRef.current;
      el.style.opacity =
        dir === "down"
          ? String(Math.min(1, scrollOffset / STICKY_HEIGHT))
          : String(Math.max(0, scrollOffset / STICKY_HEIGHT));
      el.style.transform =
        dir === "down"
          ? `translateY(${Math.max(STICKY_HEIGHT - scrollOffset, 0)}px)`
          : "translateY(0px)";
      el.style.display = show ? "block" : "none";
    },
    []
  );

  useEffect(() => {
    function handleScroll() {
      const desktopEl = keyHighlightsRef.current;
      const mobileEl = keyHighlightsMobileRef.current;
      const target = desktopEl && desktopEl.offsetParent !== null ? desktopEl : mobileEl;
      if (!target) {
        return;
      }

      const rect = target.getBoundingClientRect();
      const header = document.querySelector("header");
      const headerHeight = header ? header.getBoundingClientRect().height : 80;

      const offset = Math.max(0, headerHeight - rect.top);
      stickyScrollOffsetRef.current = offset > 0 ? offset : 0;
      showStickyCTARef.current = rect.top < headerHeight;

      const currentY = window.scrollY;
      if (currentY > prevScrollY.current) {
        scrollDirectionRef.current = "down";
      } else if (currentY < prevScrollY.current) {
        scrollDirectionRef.current = "up";
      }
      prevScrollY.current = currentY;

      updateBannerStyle(
        stickyScrollOffsetRef.current,
        showStickyCTARef.current,
        scrollDirectionRef.current
      );
    }
    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, [keyHighlightsRef, keyHighlightsMobileRef, updateBannerStyle]);

  return { bannerRef };
}
