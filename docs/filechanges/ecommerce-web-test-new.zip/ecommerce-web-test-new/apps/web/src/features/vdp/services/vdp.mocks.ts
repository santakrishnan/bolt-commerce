import { mockVehicles } from "@features/search/lib/mock-vehicles";
import type { Vehicle as SearchVehicle } from "@shared/types";
import type {
  FeatureCategory,
  HistoryData,
  PriceHistoryEntry,
  PricingData,
  RatingData,
  VehicleData,
  VehicleDetail,
  VehicleSpecData,
  VehicleStatusData,
  VinData,
} from "./types";
import vehicleProfilesData from "./vdp-profiles.json";

const PRIORITY_VIN = "5TDFZRBH5RS100015";
const MOCK_NETWORK_DELAY_MS = 40;
const MILES_SUFFIX_REGEX = /mi$/i;

interface VehicleProfile {
  features: FeatureCategory[];
  meta: {
    Drivetrain: string;
    "Fuel Type": string;
    Transmission: string;
    Mileage: string;
    "Exterior Color": string;
    "Interior Color": string;
    "Vehicle History": string;
    Certification: string;
  };
  name: string;
}

const VEHICLE_PROFILES: VehicleProfile[] = vehicleProfilesData as VehicleProfile[];

const locationPool = [
  "Fort Worth, TX 76116",
  "Dallas, TX 75001",
  "Grapevine, TX 76051",
  "Irving, TX 75062",
];

const ratingTemplates: RatingData[] = [
  {
    rating: 4.8,
    reviewCount: 128,
    distribution: [
      { id: "5", stars: 5, count: 98 },
      { id: "4", stars: 4, count: 22 },
      { id: "3", stars: 3, count: 6 },
      { id: "2", stars: 2, count: 1 },
      { id: "1", stars: 1, count: 1 },
    ],
  },
  {
    rating: 4.6,
    reviewCount: 94,
    distribution: [
      { id: "5", stars: 5, count: 66 },
      { id: "4", stars: 4, count: 20 },
      { id: "3", stars: 3, count: 6 },
      { id: "2", stars: 2, count: 1 },
      { id: "1", stars: 1, count: 1 },
    ],
  },
  {
    rating: 4.9,
    reviewCount: 176,
    distribution: [
      { id: "5", stars: 5, count: 144 },
      { id: "4", stars: 4, count: 24 },
      { id: "3", stars: 3, count: 6 },
      { id: "2", stars: 2, count: 1 },
      { id: "1", stars: 1, count: 1 },
    ],
  },
];

const statusTemplates: VehicleStatusData[] = [
  {
    noLongerAvailable: false,
    historyReportPending: false,
    inspectionInProgress: false,
    limitedPhotos: false,
  },
  {
    noLongerAvailable: false,
    historyReportPending: true,
    inspectionInProgress: false,
    limitedPhotos: true,
  },
  {
    noLongerAvailable: false,
    historyReportPending: false,
    inspectionInProgress: true,
    limitedPhotos: false,
  },
];

const prioritizedVehicles = [...mockVehicles].sort((a, b) => {
  if (a.vin === PRIORITY_VIN) {
    return -1;
  }
  if (b.vin === PRIORITY_VIN) {
    return 1;
  }
  return 0;
});

function hashString(value: string): number {
  let hash = 0;
  for (let i = 0; i < value.length; i += 1) {
    hash = (hash * 31 + value.charCodeAt(i)) % 2_147_483_647;
  }
  return Math.abs(hash);
}

function pickByKey<T>(pool: T[], key: string): T {
  return pool[hashString(key) % pool.length] as T;
}

function normalizeImage(image: string | string[]): string[] {
  return Array.isArray(image) ? image : [image];
}

function parseDealerInfo(milesField: string): { name: string; distance: string } {
  const [nameRaw, distanceRaw] = milesField.split(" - ");
  return {
    name: nameRaw ?? "Toyota Dealer",
    distance: distanceRaw ?? "0.0mi",
  };
}

function resolveMpg(profile: VehicleProfile): string {
  const fuel = profile.meta["Fuel Type"].toLowerCase();
  const name = profile.name.toLowerCase();

  if (fuel.includes("hybrid")) {
    return "36-35";
  }
  if (name.includes("tundra")) {
    return "17-22";
  }
  return "28-39";
}

function resolveEngine(profile: VehicleProfile): string {
  const name = profile.name.toLowerCase();
  if (name.includes("i-force max")) {
    return "3.4L V6 Twin-Turbo Hybrid";
  }
  if (name.includes("hybrid")) {
    return "2.5L I4 Hybrid";
  }
  if (name.includes("corolla")) {
    return "2.0L I4";
  }
  return "2.5L I4";
}

function toVehicleDetail(vehicle: SearchVehicle, profile: VehicleProfile): VehicleDetail {
  const dealerInfo = parseDealerInfo(vehicle.miles);
  const id = String(vehicle.id);

  return {
    id,
    title: vehicle.title,
    year: vehicle.year,
    make: "Toyota",
    model: vehicle.model.replace(/-/g, " "),
    trim: vehicle.variant.replace(/-/g, " "),
    price: vehicle.price,
    originalPrice: vehicle.oldPrice ?? null,
    condition: vehicle.labels[0] ?? "Fair Price",
    warranty: vehicle.warranty,
    inspected: vehicle.inspection160,
    miles: vehicle.odometer.replace(MILES_SUFFIX_REGEX, "").trim(),
    drivetrain: vehicle.drivetrain,
    fuelType: vehicle.fuelType,
    transmission: vehicle.transmission,
    mpg: resolveMpg(profile),
    stock: `VDP${id.padStart(5, "0")}`,
    vin: vehicle.vin,
    exteriorColor: vehicle.extColorName,
    interiorColor: vehicle.intColorName,
    certified: vehicle.inspection160,
    inspectionPassed: vehicle.inspection160,
    dealer: {
      name: dealerInfo.name,
      location: pickByKey(locationPool, vehicle.vin),
      distance: dealerInfo.distance,
    },
    images: normalizeImage(vehicle.image),
    highlights: profile.features.flatMap((section) => section.features).slice(0, 6),
  };
}

function toHistoryData(vehicle: SearchVehicle): HistoryData {
  return {
    vin: vehicle.vin,
    vehicleDescription: vehicle.title,
    damageReported: 0,
    previousOwners: vehicle.owners,
    servicesOnRecord: 1 + (hashString(`${vehicle.vin}-service`) % 6),
    repairsReported: 0,
    ownerTypes: Array.from({ length: Math.max(1, vehicle.owners) }, () => "Personal"),
    lastOdometerReading: vehicle.mileage,
    titleStatus: "Clean Title",
  };
}

function toPricingData(vehicle: SearchVehicle): PricingData {
  const spread = 1200 + (hashString(vehicle.vin) % 2600);
  return {
    currentPrice: vehicle.price,
    avgPrice: vehicle.price + spread,
    daysOnSite: 3 + (hashString(`${vehicle.vin}-days`) % 28),
    views: 200 + (hashString(`${vehicle.vin}-views`) % 900),
    saves: 10 + (hashString(`${vehicle.vin}-saves`) % 220),
  };
}

function toPriceHistory(vehicle: SearchVehicle): PriceHistoryEntry[] {
  const currentPrice = vehicle.price;
  const oldPrice = vehicle.oldPrice ?? currentPrice + 1800;
  const step1 = Math.round((oldPrice - currentPrice) * 0.55);
  const step2 = Math.round((oldPrice - currentPrice) * 0.8);

  return [
    { date: "2026-03-01", price: currentPrice, change: 0 },
    { date: "2026-02-10", price: oldPrice - step1, change: -step1 },
    {
      date: "2026-01-15",
      price: oldPrice - Math.round(step2),
      change: -Math.round(step2 - step1),
    },
    {
      date: "2025-12-05",
      price: oldPrice,
      change: -Math.round(oldPrice - (oldPrice - step2)),
    },
  ];
}

function toVehicleData(vehicle: SearchVehicle, profile: VehicleProfile): VehicleData {
  const id = String(vehicle.id);
  const rating = pickByKey(ratingTemplates, `${id}-rating`);
  const status = pickByKey(statusTemplates, `${id}-status`);

  const specs: VehicleSpecData[] = [
    { key: "engine", label: "Engine", value: resolveEngine(profile) },
    { key: "fuel-type", label: "Fuel Type", value: vehicle.fuelType },
    { key: "transmission", label: "Transmission", value: vehicle.transmission },
    { key: "drivetrain", label: "Drivetrain", value: vehicle.drivetrain },
    { key: "mileage", label: "Mileage", value: vehicle.odometer },
    { key: "exterior-color", label: "Exterior Color", value: vehicle.extColorName },
    { key: "interior-color", label: "Interior Color", value: vehicle.intColorName },
  ];

  return {
    specs,
    features: profile.features.map((section) => ({
      name: section.name,
      features: [...section.features],
    })),
    featuresInitialCount: 4,
    rating: {
      rating: rating.rating,
      reviewCount: rating.reviewCount,
      distribution: rating.distribution.map((item) => ({ ...item })),
    },
    vehicleStatus: { ...status, featuresTableView: false },
  };
}

const mockInventoryByVin = Object.fromEntries(
  prioritizedVehicles.map((vehicle) => {
    const profile = pickByKey(VEHICLE_PROFILES, `${vehicle.vin}-profile`);

    return [
      vehicle.vin,
      {
        vinData: {
          vehicle: toVehicleDetail(vehicle, profile),
          pricing: toPricingData(vehicle),
          priceHistory: toPriceHistory(vehicle),
          history: toHistoryData(vehicle),
        } satisfies VinData,
        vehicleData: toVehicleData(vehicle, profile),
      },
    ];
  })
) as Record<string, { vinData: VinData; vehicleData: VehicleData }>;

const vinByVehicleId = Object.fromEntries(
  prioritizedVehicles.map((vehicle) => [String(vehicle.id), vehicle.vin])
) as Record<string, string>;

async function mockApiCall<T>(resolver: () => T): Promise<T> {
  await new Promise((resolve) => setTimeout(resolve, MOCK_NETWORK_DELAY_MS));
  return resolver();
}

export async function fetchMockVinData(vin: string): Promise<VinData> {
  return await mockApiCall(() => {
    const record = mockInventoryByVin[vin];
    if (!record) {
      throw new Error(`Mock API: vehicle with VIN ${vin} not found`);
    }
    return record.vinData;
  });
}

export async function fetchMockVehicleData(id: string): Promise<VehicleData> {
  return await mockApiCall(() => {
    const vin = vinByVehicleId[id];
    const record = vin ? mockInventoryByVin[vin] : undefined;

    if (!record) {
      throw new Error(`Mock API: vehicle details for id ${id} not found`);
    }

    return record.vehicleData;
  });
}
