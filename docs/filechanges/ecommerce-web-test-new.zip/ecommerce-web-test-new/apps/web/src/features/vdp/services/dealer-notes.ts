/** Builds dealer notes from VIN data. Reused across route and page-level service. */

import type { VehicleDetail } from "@features/vdp/data/types";
import { type DealerNotes, sampleDealerNotes } from "@shared/data/dealer/dealer-data";
import { vehicleTypes } from "@shared/data/vehicle-types";
import type { VinData } from "./types";

const SUV_RE = /rav4|highlander|sequoia|venza|cross|suv/;
const SEDAN_RE = /camry|corolla|prius|sedan/;
const TRUCK_RE = /tacoma|tundra|truck/;

function getBodyTypeById(id: string): string {
  return vehicleTypes.find((type) => type.id === id)?.id ?? "vehicle";
}

function buildVehicleTitle(vehicle: VehicleDetail): string {
  return (
    vehicle.title ||
    [vehicle.year, vehicle.make, vehicle.model, vehicle.trim].filter(Boolean).join(" ")
  );
}

function inferBodyType(vehicle: VehicleDetail): string {
  const haystack = `${vehicle.model} ${vehicle.trim} ${vehicle.title ?? ""}`.toLowerCase();

  if (SUV_RE.test(haystack)) {
    return getBodyTypeById("suv");
  }
  if (SEDAN_RE.test(haystack)) {
    return getBodyTypeById("sedan");
  }
  if (TRUCK_RE.test(haystack)) {
    return getBodyTypeById("truck");
  }

  return "vehicle";
}

export function buildDealerNotes(vinData: VinData): DealerNotes {
  const vehicleTitle = buildVehicleTitle(vinData.vehicle);
  const bodyType = inferBodyType(vinData.vehicle);
  const vehicleDealer = vinData.vehicle.dealer;

  return {
    vehicleDescription: `This well-maintained ${vehicleTitle} comes with low miles and is in excellent condition. It has been thoroughly inspected and certified by our team of expert technicians. The vehicle features all the latest safety technology and comfort features you'd expect from a premium ${bodyType}. Don't miss this opportunity to own a reliable and stylish vehicle at a great price.`,
    vehicleImage: vinData.vehicle.images[0] ?? sampleDealerNotes.vehicleImage,
    dealer: {
      ...sampleDealerNotes.dealer,
      id: `dealer-${vinData.vehicle.vin.toLowerCase()}`,
      name: vehicleDealer.name || sampleDealerNotes.dealer.name,
      address: vehicleDealer.location || sampleDealerNotes.dealer.address,
    },
  };
}
