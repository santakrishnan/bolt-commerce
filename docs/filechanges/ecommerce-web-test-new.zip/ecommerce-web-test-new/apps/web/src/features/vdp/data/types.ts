//Shared types for the VDP feature.

// Vehicle detail

export interface VehicleDetail {
  certified?: boolean;
  condition: string;
  dealer: {
    name: string;
    location: string;
    distance: string;
  };
  drivetrain: string;
  exteriorColor: string;
  fuelType?: string;
  highlights: string[];
  id: string;
  images: string[];
  inspected: boolean;
  inspectionPassed?: boolean;
  interiorColor: string;
  make: string;
  miles: string;
  model: string;
  mpg: string;
  originalPrice: number | null;
  price: number;
  stock: string;
  title?: string;
  transmission?: string;
  trim: string;
  vin: string;
  warranty: boolean;
  year: number;
}
// Overview tab

export interface VehicleSpecData {
  key: string;
  label: string;
  value: string;
}

// Features tab

export interface FeatureCategory {
  features: string[];
  name: string;
}

// Pricing tab

export interface PricingData {
  avgPrice: number;
  currentPrice: number;
  daysOnSite: number;
  saves: number;
  views: number;
}

// Price history tab

export interface PriceHistoryEntry {
  change: number;
  date: string;
  price: number;
}

// History tab

export interface HistoryData {
  damageReported: number;
  lastOdometerReading: number;
  ownerTypes: string[];
  previousOwners: number;
  repairsReported: number;
  servicesOnRecord: number;
  titleStatus?: string;
  vehicleDescription: string;
  vin: string;
}

// Rating data

export interface RatingDistribution {
  count: number;
  id: string;
  stars: number;
}

export interface RatingData {
  distribution: RatingDistribution[];
  rating: number;
  reviewCount: number;
}

// Vehicle status

export interface VehicleStatusData {
  featuresTableView?: boolean;
  historyReportPending: boolean;
  inspectionInProgress: boolean;
  limitedPhotos: boolean;
  noLongerAvailable: boolean;
}

// VehicleMetaBar

export type PillTone = "neutral" | "success" | "warning" | "inactive";

export interface VehicleMetaChipProps {
  ariaLabel?: string;
  chipClassName?: string;
  className?: string;
  tone?: PillTone;
  value: string;
}

export interface VehicleMetaColorChipProps {
  colorName: string;
  label: string;
  swatchHex: string;
}

export interface VehicleMetaCheckedChipProps {
  active: boolean;
  label: string;
}

export interface VehicleMetaBarChipComponents {
  CheckedChipComponent?: import("react").ComponentType<VehicleMetaCheckedChipProps>;
  ColorChipComponent?: import("react").ComponentType<VehicleMetaColorChipProps>;
  MetaChipComponent?: import("react").ComponentType<VehicleMetaChipProps>;
}

// PriceRangeMeter

export interface PriceRangeMeterProps {
  avgPrice: number;
  currentPrice: number;
}

// PriceHistoryTable

export interface PriceHistoryTableProps {
  entries: PriceHistoryEntry[];
}

// VehiclePDP

export interface VehiclePDPProps {
  slugParams: import("@config/routes").VdpParams;
  vehicle: VehicleDetail;
}

// VehicleStickyBanner

export interface VehicleStickyBannerProps {
  ref?: import("react").Ref<HTMLDivElement>;
  scrollDirection?: "up" | "down";
  showStickyCTA?: boolean;
  slugParams: import("@config/routes").VdpParams;
  stickyHeight?: number;
  stickyScrollOffset?: number;
  vehicle: VehicleDetail;
}

// VIN-based data (First API call)

export interface VinData {
  history: HistoryData;
  priceHistory: PriceHistoryEntry[];
  pricing: PricingData;
  vehicle: VehicleDetail;
}

// ID-based data (Second API call)

export interface VehicleData {
  features: FeatureCategory[];
  featuresInitialCount: number;
  rating: RatingData;
  specs: VehicleSpecData[];
  vehicleStatus: VehicleStatusData;
}
