"use client";

import { ImagePreviewModal } from "@features/vdp/components/image-preview-modal";
import { ImageCarousel } from "@features/vdp/components/image-thumbnail-carousal";
import { useState } from "react";

interface VehiclePdpMediaClientProps {
  images: string[];
  regionId: string;
  title?: string;
}

export function VehiclePdpMediaClient({ images, regionId, title }: VehiclePdpMediaClientProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [previewIndex, setPreviewIndex] = useState(0);

  const openPreview = () => {
    setPreviewIndex(currentImageIndex);
    setIsPreviewOpen(true);
  };

  return (
    <>
      <ImagePreviewModal
        alt={title ?? "Vehicle image"}
        currentIndex={previewIndex}
        images={images}
        isOpen={isPreviewOpen}
        onClose={() => setIsPreviewOpen(false)}
        onIndexChange={setPreviewIndex}
      />

      <ImageCarousel
        alt={title ?? "Vehicle image"}
        carouselClassName="h-full w-full overflow-hidden lg:rounded-md [&>div]:h-full"
        containerClassName="relative aspect-[4/3] w-full overflow-hidden rounded-none bg-background lg:aspect-auto lg:h-[518px] lg:rounded-md"
        getThumbnailButtonClassName={(isActive) =>
          `h-(--size-thumbnail) w-(--size-thumbnail) shrink-0 cursor-pointer rounded-md p-(--spacing-2xs) transition-all ${
            isActive
              ? "border-(length:--border-width-1) border-brand"
              : "border-(length:--border-width-1) border-divider hover:border-border"
          }`
        }
        id={regionId}
        images={images}
        onImageClick={openPreview}
        onImageIndexChange={setCurrentImageIndex}
        thumbnailContainerClassName="flex gap-(--spacing-xs) overflow-x-auto  pb-(--spacing-md) lg:gap-(--spacing-md) [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        thumbnailImageClassName="h-full w-full rounded-md object-contain"
        thumbnailSize={{ width: 97, height: 97 }}
      />
    </>
  );
}
