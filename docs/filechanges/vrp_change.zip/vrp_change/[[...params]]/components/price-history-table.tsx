import type { PriceHistoryEntry } from "@features/vdp/data";
import {
  DownGreenArrowImg,
  formatChange,
  formatPrice,
  formatShortDate,
  isCurrentMonth,
  UpGreenArrowImg,
} from "@features/vdp/lib/formatters";
import { ScrollArea } from "@tfs-ucmp/ui";
import { Fragment } from "react";

interface PriceHistoryTableProps {
  entries: PriceHistoryEntry[];
}

export function PriceHistoryTable({ entries }: PriceHistoryTableProps) {
  const rows = entries.slice(0, 4).reverse();

  return (
    <ScrollArea className="w-full">
      <table className="w-full border-separate font-normal text-[length:var(--font-size-sm)]">
        <colgroup>
          <col className="w-auto" />
          <col className="w-auto" />
          <col className="w-auto" />
          <col className="w-[var(--spacing-xl)]" />
        </colgroup>
        <tbody>
          {rows.map((entry, idx) => {
            const isCurrent = isCurrentMonth(entry.date);
            const isPriceUp = entry.change > 0;
            return (
              <Fragment key={entry.date}>
                {idx !== 0 && (
                  <tr>
                    <td aria-hidden="true" className="h-[var(--spacing-md)] p-0" colSpan={4} />
                  </tr>
                )}
                <tr>
                  <td
                    className={
                      "whitespace-nowrap pr-[var(--spacing-md)] pb-[var(--spacing-md)] align-middle font-normal text-heading"
                    }
                  >
                    {formatShortDate(entry.date)}
                  </td>
                  <td
                    className={
                      "whitespace-nowrap pr-[var(--spacing-md)] pb-[var(--spacing-md)] align-middle font-normal text-heading"
                    }
                  >
                    {formatPrice(entry.price)}
                  </td>
                  <td
                    className={
                      "whitespace-nowrap pr-[var(--spacing-md)] pb-[var(--spacing-md)] align-middle font-normal text-heading"
                    }
                  >
                    {!isCurrent && formatChange(entry.change)}
                  </td>
                  <td className={"pb-[var(--spacing-md)] align-middle"}>
                    <div className="flex justify-end">
                      {!isCurrent && (isPriceUp ? <UpGreenArrowImg /> : <DownGreenArrowImg />)}
                    </div>
                  </td>
                </tr>
                <tr>
                  <td className="p-0" colSpan={4}>
                    <div
                      aria-hidden="true"
                      className="h-px w-full bg-[var(--structure-interaction-subtle-border)]"
                    />
                  </td>
                </tr>
              </Fragment>
            );
          })}
        </tbody>
      </table>
    </ScrollArea>
  );
}
