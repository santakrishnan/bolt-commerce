"use client";

import { usePromotionFlags } from "@features/vdp/hooks/use-promotion-flags";
import { PrequalifyCard } from "./prequalify-card";
import type { PromotionCardId } from "./promotion-registry";
import { PROMOTION_CARDS } from "./promotion-registry";
import { TestDriveCard } from "./test-drive-card";
import { TradeInCard } from "./trade-in-card";

const CARD_COMPONENTS = {
  prequalify: PrequalifyCard,
  testDrive: TestDriveCard,
  tradeIn: TradeInCard,
} as const;

interface VdpPromotionCardsProps {
  showPrequal?: boolean;
  showTestDrive?: boolean;
  showTradeIn?: boolean;
  testDriveButtonText?: string;
}

function buildVisibilityMap(props: VdpPromotionCardsProps): Record<PromotionCardId, boolean> {
  return {
    prequalify: props.showPrequal ?? true,
    testDrive: props.showTestDrive ?? true,
    tradeIn: props.showTradeIn ?? true,
  };
}

export function VdpPromotionCards(props: VdpPromotionCardsProps) {
  const { context, isLoading } = usePromotionFlags();

  if (isLoading) {
    return null;
  }

  const visibility = buildVisibilityMap(props);

  const visibleCards = PROMOTION_CARDS.filter((entry) => visibility[entry.id])
    .filter((entry) => !entry.guard || entry.guard(context))
    .sort((a, b) => a.priority - b.priority);

  if (visibleCards.length === 0) {
    return null;
  }

  return (
    <>
      {visibleCards.map((entry) => {
        const Card = CARD_COMPONENTS[entry.id];
        const isDetailed = context.isCardTestEnabled;
        const overrides = isDetailed ? entry.cardTestOverrides : undefined;

        if (entry.id === "testDrive") {
          return (
            <Card
              buttonText={props.testDriveButtonText ?? entry.defaultButtonText}
              key={entry.id}
            />
          );
        }

        return (
          <Card
            buttonText={overrides?.buttonText ?? entry.defaultButtonText}
            description={overrides?.description}
            detailed={isDetailed}
            key={entry.id}
            title={overrides?.title}
          />
        );
      })}
    </>
  );
}
