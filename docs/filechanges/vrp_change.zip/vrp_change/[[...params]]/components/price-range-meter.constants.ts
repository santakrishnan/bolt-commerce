export const PRICE_LOW_MULTIPLIER = 0.7;
export const PRICE_HIGH_MULTIPLIER = 1.3;
export const SEGMENT_WIDTHS = [92, 92, 200, 200] as const;
export function cssVarPx(name: string, fallback = "0px"): number {
  try {
    const v = getComputedStyle(document.documentElement).getPropertyValue(name) || fallback;
    return Number.parseFloat(v);
  } catch (_e) {
    return Number.parseFloat(fallback);
  }
}
