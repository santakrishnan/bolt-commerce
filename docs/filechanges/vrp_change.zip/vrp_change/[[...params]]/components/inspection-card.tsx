import { Card } from "@tfs-ucmp/ui";
import Image from "next/image";

interface InspectionCardProps {
  description: string;
  iconSrc: string;
  photoAlt: string;
  photoSrc: string;
  title: React.ReactNode;
}

export function InspectionCard({
  photoSrc,
  photoAlt,
  iconSrc,
  title,
  description,
}: InspectionCardProps) {
  return (
    <Card className="overflow-hidden border-0 bg-surface shadow-sm">
      <div className="relative aspect-[4/3] w-full overflow-hidden">
        <Image
          alt={photoAlt}
          className="object-cover"
          fill
          sizes="(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 25vw"
          src={photoSrc}
        />
      </div>
      <div className="flex flex-col items-start p-6">
        <div className="mb-3 flex items-center gap-3">
          <Image
            alt=""
            aria-hidden="true"
            className="h-8 w-8"
            height={32}
            src={iconSrc}
            width={32}
          />
          <h4 className="font-semibold text-base text-foreground">{title}</h4>
        </div>
        <p className="text-muted-foreground text-sm leading-relaxed">{description}</p>
      </div>
    </Card>
  );
}
