function SkeletonBlock({ className }: { className?: string }) {
  return <div className={`animate-pulse rounded-lg bg-foreground/5 ${className}`} />;
}

export function PromotionCardsSkeleton() {
  return (
    <div className="flex flex-col gap-(--spacing-md)">
      <SkeletonBlock className="h-12 w-full" />
      <SkeletonBlock className="h-12 w-full" />
    </div>
  );
}

export function TestDriveCardSkeleton() {
  return <SkeletonBlock className="h-12 w-full" />;
}
