"use client";

import { buildVdpPath } from "@config/routes";
import { toPreviewData } from "@features/vdp/data/to-preview-data";
import type { VehicleStickyBannerProps } from "@features/vdp/data/types";
import { AppButton } from "@shared/components/button";
import { Heading } from "@tfs-ucmp/ui";
import type React from "react";

import { VehicleActionIcons } from "./vehicle-action-icons";

export const VehicleStickyBanner: React.FC<VehicleStickyBannerProps> = ({
  vehicle,
  slugParams,
  ref,
}) => {
  const shouldShowOriginalPrice =
    vehicle.originalPrice != null && vehicle.originalPrice > (vehicle.price ?? 0);

  return (
    <div
      className="fixed right-0 left-0 z-50 bg-surface py-(--spacing-lg) shadow-sm"
      ref={ref}
      style={{
        transition: "opacity 0.2s, transform 0.2s",
        display: "none",
        top: 0,
      }}
    >
      <div className="mx-auto h-full max-w-(--container-2xl) px-(--spacing-md) sm:px-(--spacing-lg) lg:px-(--spacing-4xl)">
        <div className="flex flex-col gap-(--spacing-xs) md:hidden">
          <Heading
            className="text-[length:var(--font-size-xl)] text-[var(--color-core-surfaces-foreground)] leading-normal"
            level={1}
            weight="bold"
          >
            {vehicle.title}
          </Heading>
          <div className="flex items-center justify-between gap-(--spacing-md)">
            <div className="flex items-baseline gap-(--spacing-xs)">
              <span className="text-(length:--font-size-lg) font-bold text-brand leading-normal">
                ${vehicle.price.toLocaleString()}
              </span>
              {shouldShowOriginalPrice && (
                <div className="flex items-baseline gap-(--spacing-2xs)">
                  <span className="font-normal text-[var(--color-core-surfaces-foreground)] text-xs leading-normal">
                    was
                  </span>
                  <span className="font-normal text-[var(--color-core-surfaces-foreground)] text-xs leading-normal line-through">
                    ${vehicle.originalPrice?.toLocaleString()}
                  </span>
                </div>
              )}
            </div>
            <VehicleActionIcons
              showFav={true}
              showPrint={true}
              showShare={true}
              vdpUrl={buildVdpPath(slugParams)}
              vehicle={toPreviewData(vehicle)}
              vin={vehicle.vin}
            />
          </div>
          <div className="flex flex-row items-center justify-between">
            <div className="flex flex-row gap-(--spacing-2xs)">
              <p className="font-semibold text-[var(--color-core-surfaces-foreground)] text-sm">
                Miles:
              </p>
              <p className="font-semibold text-[var(--color-core-surfaces-foreground)] text-sm">
                {vehicle.miles.toLocaleString()}
              </p>
            </div>
            <div className="flex flex-row gap-(--spacing-2xs)">
              <p className="font-semibold text-[var(--color-core-surfaces-foreground)] text-sm">
                VIN:
              </p>
              <p className="font-semibold text-[var(--color-core-surfaces-foreground)] text-sm">
                {vehicle.vin}
              </p>
            </div>
          </div>
          <AppButton className="w-full" size="md" variant="primary">
            Get Pre-Qualified
          </AppButton>
        </div>
        <div className="hidden md:flex md:items-center md:justify-between md:gap-(--spacing-lg)">
          <div className="flex min-w-0 flex-col gap-(--spacing-md)">
            <div className="flex flex-wrap items-baseline gap-x-(--spacing-md) gap-y-(--spacing-2xs)">
              <Heading
                className="text-[var(--color-core-surfaces-foreground)] leading-[115%] md:text-[length:var(--font-size-lg)] lg:text-[length:var(--font-size-lg)]"
                level={1}
                weight="bold"
              >
                {vehicle.title}
              </Heading>
              <div className="flex items-baseline gap-(--spacing-xs)">
                <span className="font-bold text-(--color-actions-accent) text-lg leading-[115%]">
                  ${vehicle.price.toLocaleString()}
                </span>
                {shouldShowOriginalPrice && (
                  <div className="flex items-baseline gap-(--spacing-2xs)">
                    <span className="font-normal text-[var(--color-states-muted-foreground)] text-xs leading-normal tracking-[-0.14px]">
                      was
                    </span>
                    <span className="text-[var(--color-states-muted-foreground)] text-sm leading-[125%] line-through">
                      ${vehicle.originalPrice?.toLocaleString()}
                    </span>
                  </div>
                )}
              </div>
            </div>
            <div className="flex flex-row items-center gap-(--spacing-xl)">
              <div className="flex flex-row gap-(--spacing-2xs)">
                <p className="text-(length:--font-size-md) font-semibold text-[var(--color-core-surfaces-foreground)] tracking-[-0.16px]">
                  Miles:
                </p>
                <p className="text-(length:--font-size-md) font-semibold text-[var(--color-core-surfaces-foreground)] tracking-[-0.16px]">
                  {vehicle.miles.toLocaleString()}
                </p>
              </div>
              <div className="flex flex-row gap-(--spacing-2xs)">
                <p className="text-(length:--font-size-md) font-semibold text-[var(--color-core-surfaces-foreground)] tracking-[-0.16px]">
                  VIN:
                </p>
                <p className="text-(length:--font-size-md) font-semibold text-[var(--color-core-surfaces-foreground)] tracking-[-0.16px]">
                  {vehicle.vin}
                </p>
              </div>
            </div>
          </div>

          <div className="flex shrink-0 items-center gap-(--spacing-2xl)">
            <VehicleActionIcons
              showFav={true}
              showPrint={true}
              showShare={true}
              vdpUrl={buildVdpPath(slugParams)}
              vehicle={toPreviewData(vehicle)}
              vin={vehicle.vin}
            />
            <div>
              <AppButton size="md" variant="primary">
                Get Pre-Qualified
              </AppButton>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
