import type { HistoryData } from "@features/vdp/data";
import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { HistoryTab } from "../history-tab";

const VIN_PATTERN = /VIN:/;
const REPORT_PATTERN = /View Full Report/;

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({ children, ...props }: any) => <button {...props}>{children}</button>,
  cn: (...args: any[]) => args.filter(Boolean).join(" "),
  DamageReportIcon: () => <div data-testid="damage-report-icon" />,
  Heading: ({ children, ...props }: any) => <h3 {...props}>{children}</h3>,
  NoDamageIcon: () => <div data-testid="no-damage-icon" />,
  OdometerIcon: () => <div data-testid="odometer-icon" />,
  PreviousOwnersIcon: () => <div data-testid="previous-owners-icon" />,
  ServiceHistoryIcon: () => <div data-testid="service-history-icon" />,
  TypeOwnersIcon: () => <div data-testid="type-owners-icon" />,
}));

vi.mock("../history-stat-card", () => ({
  HistoryStatCard: ({ label, value }: any) => (
    <div data-testid="history-stat-card">
      <span data-testid="stat-label">{label}</span>
      <span data-testid="stat-value">{value}</span>
    </div>
  ),
}));

describe("HistoryTab Component", () => {
  const mockHistoryData: HistoryData = {
    vin: "12345678901234567",
    vehicleDescription: "2023 Toyota Highlander XLE",
    damageReported: 0,
    previousOwners: 1,
    servicesOnRecord: 5,
    repairsReported: 0,
    ownerTypes: ["Personal"],
    lastOdometerReading: 15_000,
  };

  it("should render the component", () => {
    render(<HistoryTab historyData={mockHistoryData} />);

    expect(screen.getByText("Vehicle History")).toBeInTheDocument();
  });

  it("should display VIN information", () => {
    render(<HistoryTab historyData={mockHistoryData} />);

    expect(screen.getByText(VIN_PATTERN)).toBeInTheDocument();
    expect(screen.getByText("12345678901234567")).toBeInTheDocument();
  });

  it("should display vehicle description", () => {
    render(<HistoryTab historyData={mockHistoryData} />);

    expect(screen.getByText("2023 Toyota Highlander XLE")).toBeInTheDocument();
  });

  it("should render View Full Report button", () => {
    render(<HistoryTab historyData={mockHistoryData} />);

    const button = screen.getByRole("button", { name: REPORT_PATTERN });
    expect(button).toBeInTheDocument();
  });

  it("should render all history stat cards", () => {
    render(<HistoryTab historyData={mockHistoryData} />);

    const statCards = screen.getAllByTestId("history-stat-card");
    expect(statCards).toHaveLength(6);
  });

  it("should display No Damage stat card", () => {
    render(<HistoryTab historyData={mockHistoryData} />);

    expect(screen.getByText("No Damage")).toBeInTheDocument();
    expect(screen.getByText("0 Damage Reported")).toBeInTheDocument();
  });

  it("should display Previous Owners stat card", () => {
    render(<HistoryTab historyData={mockHistoryData} />);

    expect(screen.getByText("Previous Owners")).toBeInTheDocument();
    expect(screen.getByText("1 Owners")).toBeInTheDocument();
  });

  it("should display Service History stat card", () => {
    render(<HistoryTab historyData={mockHistoryData} />);

    expect(screen.getByText("Service History")).toBeInTheDocument();
    expect(screen.getByText("5 Services on Record")).toBeInTheDocument();
  });

  it("should display Damage Reports stat card", () => {
    render(<HistoryTab historyData={mockHistoryData} />);

    expect(screen.getByText("Damage Reports")).toBeInTheDocument();
    expect(screen.getByText("0 Repairs Reported")).toBeInTheDocument();
  });

  it("should display Type of Owner stat card", () => {
    render(<HistoryTab historyData={mockHistoryData} />);

    expect(screen.getByText("Type of Owner")).toBeInTheDocument();
    expect(screen.getByText("Personal")).toBeInTheDocument();
  });

  it("should display Last Odometer Reading stat card with formatted miles", () => {
    render(<HistoryTab historyData={mockHistoryData} />);

    expect(screen.getByText("Last Odometer Reading")).toBeInTheDocument();
    expect(screen.getByText("15,000 Miles")).toBeInTheDocument();
  });

  it("should handle multiple owner types", () => {
    const dataWithMultipleOwners: HistoryData = {
      ...mockHistoryData,
      ownerTypes: ["Personal", "Commercial"],
    };

    render(<HistoryTab historyData={dataWithMultipleOwners} />);

    expect(screen.getByText("Personal, Commercial")).toBeInTheDocument();
  });

  it("should display all required icons", () => {
    render(<HistoryTab historyData={mockHistoryData} />);

    const statCards = screen.getAllByTestId("history-stat-card");
    expect(statCards.length).toBeGreaterThan(0);
  });

  it("should handle large odometer reading", () => {
    const dataWithHighMileage: HistoryData = {
      ...mockHistoryData,
      lastOdometerReading: 125_000,
    };

    render(<HistoryTab historyData={dataWithHighMileage} />);

    expect(screen.getByText("125,000 Miles")).toBeInTheDocument();
  });

  it("should handle damage reported value", () => {
    const dataWithDamage: HistoryData = {
      ...mockHistoryData,
      damageReported: 1,
    };

    render(<HistoryTab historyData={dataWithDamage} />);

    expect(screen.getByText("1 Damage Reported")).toBeInTheDocument();
  });

  it("should handle high service record count", () => {
    const dataWithMoreServices: HistoryData = {
      ...mockHistoryData,
      servicesOnRecord: 12,
    };

    render(<HistoryTab historyData={dataWithMoreServices} />);

    expect(screen.getByText("12 Services on Record")).toBeInTheDocument();
  });

  it("should handle multiple repairs reported", () => {
    const dataWithRepairs: HistoryData = {
      ...mockHistoryData,
      repairsReported: 3,
    };

    render(<HistoryTab historyData={dataWithRepairs} />);

    expect(screen.getByText("3 Repairs Reported")).toBeInTheDocument();
  });

  it("should handle multiple previous owners", () => {
    const dataWithMoreOwners: HistoryData = {
      ...mockHistoryData,
      previousOwners: 4,
    };

    render(<HistoryTab historyData={dataWithMoreOwners} />);

    expect(screen.getByText("4 Owners")).toBeInTheDocument();
  });

  it("should render with accessibility attributes", () => {
    render(<HistoryTab historyData={mockHistoryData} />);

    const heading = screen.getByText("Vehicle History");
    expect(heading).toBeInTheDocument();
    expect(heading.tagName).toBe("H3");
  });
});
