import { render, screen } from "@testing-library/react";
import React from "react";
import { describe, expect, it, vi } from "vitest";

vi.mock("@features/favorites", () => ({
  FavoriteButton: (props: any) =>
    React.createElement("div", {
      "data-testid": "fav",
      "data-vin": props?.vin ?? "",
      "data-class": props?.className ?? "",
    }),
}));

vi.mock("@shared/components/print-button", () => ({
  PrintButton: (props: any) =>
    React.createElement("div", {
      "data-testid": "print",
      "data-has-vehicle": props?.vehicle ? "1" : "0",
    }),
}));

vi.mock("@shared/components/share-button", () => ({
  ShareButton: (props: any) =>
    React.createElement("div", {
      "data-testid": "share",
      "data-vehicle-url": props?.vehicleUrl ?? "",
      "data-src": props?.src ?? "",
    }),
}));

describe("VehicleActionIcons — behavior-only", () => {
  it("renders share, favorite and print when enabled and vin provided", async () => {
    vi.resetModules();
    const { VehicleActionIcons } = await import("../vehicle-action-icons");

    const { container } = render(
      React.createElement(VehicleActionIcons, {
        vin: "VIN123",
        vdpUrl: "/vehicle/1",
        vehicle: { id: "1" },
        showFav: true,
        showPrint: true,
        showShare: true,
        className: "extra-class",
      } as any)
    );

    expect(screen.queryByTestId("share")).toBeTruthy();
    expect(screen.queryByTestId("print")).toBeTruthy();
    const fav = screen.queryByTestId("fav");
    expect(fav).toBeTruthy();
    expect(fav?.getAttribute("data-vin")).toBe("VIN123");
    expect(container.firstChild && (container.firstChild as Element).className).toContain(
      "extra-class"
    );
  });

  it("does not render FavoriteButton when vin is not provided", async () => {
    vi.resetModules();
    const { VehicleActionIcons } = await import("../vehicle-action-icons");

    render(React.createElement(VehicleActionIcons, { showFav: true } as any));
    expect(screen.queryByTestId("fav")).toBeNull();
  });

  it("honors showShare=false and showPrint=false", async () => {
    vi.resetModules();
    const { VehicleActionIcons } = await import("../vehicle-action-icons");

    render(React.createElement(VehicleActionIcons, { showShare: false, showPrint: false } as any));
    expect(screen.queryByTestId("share")).toBeNull();
    expect(screen.queryByTestId("print")).toBeNull();
  });

  it("hides favorite when showFav is false even if vin provided", async () => {
    vi.resetModules();
    const { VehicleActionIcons } = await import("../vehicle-action-icons");

    render(React.createElement(VehicleActionIcons, { vin: "X", showFav: false } as any));
    expect(screen.queryByTestId("fav")).toBeNull();
  });
});
