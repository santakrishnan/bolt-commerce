import { fireEvent, render, screen } from "@testing-library/react";
import React from "react";
import { describe, expect, it, vi } from "vitest";

vi.mock("next/image", () => ({
  __esModule: true,
  default: ({ src, alt }: any) => React.createElement("img", { src, alt }),
}));

const PRICING_RX = /Pricing/i;
const DAYS_RX = /days/i;
const NUM12_RX = /12/i;
const VIEWS_RX = /Views/i;
const SAVES_RX = /saves/i;
const PRICE_HISTORY_RX = /Price History/i;

vi.mock("@tfs-ucmp/ui", () => ({
  __esModule: true,
  Button: ({ children, ...rest }: any) =>
    React.createElement(
      "button",
      { type: rest.type || "button", "data-button": "true", ...rest },
      children
    ),
  Heading: ({ children, level }: any) => React.createElement(`h${level || 3}`, null, children),
  cn: (...parts: any[]) => parts.filter(Boolean).join(" "),
}));

vi.mock("framer-motion", () => ({
  __esModule: true,
  AnimatePresence: ({ children }: any) => React.createElement("div", null, children),
  motion: { div: (props: any) => React.createElement("div", props, props.children) },
}));

vi.mock("@shared/components/custom-badge", () => ({
  __esModule: true,
  CustomBadge: ({ text }: any) => React.createElement("span", { "data-badge": "true" }, text),
}));

vi.mock("../price-history-table", () => ({
  __esModule: true,
  PriceHistoryTable: ({ entries }: any) =>
    React.createElement("div", { "data-price-history": entries?.length ?? 0 }, "history"),
}));

vi.mock("../price-range-meter", () => ({
  __esModule: true,
  PriceRangeMeter: ({ avgPrice, currentPrice }: any) =>
    React.createElement("div", { "data-range": `${avgPrice}-${currentPrice}` }),
}));

import { PricingTab } from "../pricing-tab";

describe("PricingTab", () => {
  it("renders header stats and toggles price history", () => {
    const pricingData = {
      daysOnSite: 12,
      views: 345,
      saves: 7,
      avgPrice: 20_000,
      currentPrice: 18_000,
    } as any;
    const priceHistory: any[] = [];

    render(React.createElement(PricingTab, { pricingData, priceHistory }));

    expect(screen.getByText(PRICING_RX)).toBeInTheDocument();
    expect(screen.getByText(NUM12_RX)).toBeInTheDocument();
    expect(screen.getByText(DAYS_RX)).toBeInTheDocument();
    expect(screen.getByText("345")).toBeInTheDocument();
    expect(screen.getByText(VIEWS_RX)).toBeInTheDocument();
    expect(screen.getByText("7")).toBeInTheDocument();
    expect(screen.getByText(SAVES_RX)).toBeInTheDocument();

    expect(document.querySelector('[data-badge="true"]')).toBeTruthy();
    expect(document.querySelector('[data-range="20000-18000"]')).toBeTruthy();

    const btn = screen.getByRole("button", { name: PRICE_HISTORY_RX });
    expect(btn).toBeInTheDocument();
    expect(btn.getAttribute("aria-expanded")).toBe("false");

    fireEvent.click(btn);
    expect(btn.getAttribute("aria-expanded")).toBe("true");
    expect(document.querySelector("[data-price-history]")).toBeTruthy();

    fireEvent.click(btn);
    expect(btn.getAttribute("aria-expanded")).toBe("false");
  });
});
