import { act } from "@testing-library/react";
import React from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";

describe("VehiclePdpStickyClient (behavior-only)", () => {
  beforeEach(() => {
    vi.resetModules();
    document.body.innerHTML = "";
    window.scrollTo = vi.fn();
  });

  it("passes computed props to VehicleStickyBanner and responds to scroll", async () => {
    vi.doMock("../sticky-banner", () => ({
      VehicleStickyBanner: (props: any) =>
        React.createElement("div", { "data-props": JSON.stringify(props) }),
    }));

    vi.doMock("next/navigation", () => ({ usePathname: () => "/vehicles/2021-toyota-corolla" }));

    const { render } = await import("@testing-library/react");
    const mod = await import("../vehicle-pdp-sticky-client");
    const { VehiclePdpStickyClient } = mod;

    const desktop = document.createElement("div");
    desktop.id = "desktop-target";
    (desktop as any).getBoundingClientRect = () => ({ top: 50 });
    Object.defineProperty(desktop as any, "offsetParent", { get: () => ({}) });
    document.body.appendChild(desktop);

    const header = document.createElement("header");
    header.getBoundingClientRect = () =>
      ({
        height: 80,
        width: 0,
        x: 0,
        y: 0,
        bottom: 80,
        left: 0,
        right: 0,
        top: 0,
        toJSON: () => ({}),
      }) as DOMRect;
    document.body.appendChild(header);

    (window as any).scrollY = 0;

    const { container } = render(
      React.createElement(VehiclePdpStickyClient, {
        vehicle: {} as any,
        slugParams: {} as any,
        desktopTargetId: "desktop-target",
        mobileTargetId: "mobile-target",
      })
    );

    const banner = container.querySelector("div[data-props]");
    if (!banner) {
      throw new Error("Banner not found");
    }
    const props = JSON.parse(banner.getAttribute("data-props") || "{}");

    expect(props.stickyScrollOffset).toBe(30);
    expect(props.showStickyCTA).toBe(true);
    expect(props.scrollDirection).toBe("down");

    await act(async () => {
      (window as any).scrollY = 200;
      window.dispatchEvent(new Event("scroll"));
      await Promise.resolve();
    });

    const bannerAfterDown = container.querySelector("div[data-props]");
    if (!bannerAfterDown) {
      throw new Error("Banner not found after scroll down");
    }
    const propsAfterDown = JSON.parse(bannerAfterDown.getAttribute("data-props") || "{}");
    expect(propsAfterDown.scrollDirection).toBe("down");

    await act(async () => {
      (window as any).scrollY = 50;
      window.dispatchEvent(new Event("scroll"));
      await Promise.resolve();
    });

    const bannerAfterUp = container.querySelector("div[data-props]");
    if (!bannerAfterUp) {
      throw new Error("Banner not found after scroll up");
    }
    const propsAfterUp = JSON.parse(bannerAfterUp.getAttribute("data-props") || "{}");
    expect(propsAfterUp.scrollDirection).toBe("up");
  });

  it("renders with defaults when no target is found", async () => {
    vi.doMock("../sticky-banner", () => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const ReactLocal = require("react");
      return {
        VehicleStickyBanner: (props: any) =>
          ReactLocal.createElement("div", { "data-props": JSON.stringify(props) }),
      };
    });
    vi.doMock("next/navigation", () => ({ usePathname: () => "/x" }));

    const { render } = await import("@testing-library/react");
    const mod = await import("../vehicle-pdp-sticky-client");
    const { VehiclePdpStickyClient } = mod;

    const { container } = render(
      React.createElement(VehiclePdpStickyClient, {
        vehicle: {} as any,
        slugParams: {} as any,
        desktopTargetId: "nope",
        mobileTargetId: "also-no",
      })
    );

    const banner = container.querySelector("div[data-props]");
    if (!banner) {
      throw new Error("Banner not found in defaults test");
    }
    const props = JSON.parse(banner.getAttribute("data-props") || "{}");

    expect(props.stickyScrollOffset).toBe(0);
    expect(props.showStickyCTA).toBe(false);
  });

  it("coverage: exercise alternate branches (no pathname, mobile target used, no header)", async () => {
    // ensure window.scrollTo isn't called when pathname is undefined
    const scrollToSpy = vi.fn();
    window.scrollTo = scrollToSpy;

    vi.doMock("../sticky-banner", () => ({
      VehicleStickyBanner: (props: any) =>
        React.createElement("div", { "data-props": JSON.stringify(props) }),
    }));
    vi.doMock("next/navigation", () => ({ usePathname: () => undefined }));

    const { render } = await import("@testing-library/react");
    const mod = await import("../vehicle-pdp-sticky-client");
    const { VehiclePdpStickyClient } = mod;

    const desktop = document.createElement("div");
    desktop.id = "desktop-target-2";
    Object.defineProperty(desktop as any, "offsetParent", { get: () => null });
    (desktop as any).getBoundingClientRect = () => ({ top: 0 });
    document.body.appendChild(desktop);

    const mobile = document.createElement("div");
    mobile.id = "mobile-target";
    (mobile as any).getBoundingClientRect = () => ({ top: 200 });
    Object.defineProperty(mobile as any, "offsetParent", { get: () => ({}) });
    document.body.appendChild(mobile);

    (window as any).scrollY = 0;

    const { container } = render(
      React.createElement(VehiclePdpStickyClient, {
        vehicle: {} as any,
        slugParams: {} as any,
        desktopTargetId: "desktop-target-2",
        mobileTargetId: "mobile-target",
      })
    );

    expect(scrollToSpy).not.toHaveBeenCalled();

    const banner = container.querySelector("div[data-props]");
    if (!banner) {
      throw new Error("Banner not found in coverage test");
    }
    const props = JSON.parse(banner.getAttribute("data-props") || "{}");
    expect(props.stickyScrollOffset).toBe(0);
    expect(props.showStickyCTA).toBe(false);
  });
});
