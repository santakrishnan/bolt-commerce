import { render, screen } from "@testing-library/react";
import React from "react";
import { describe, expect, it, vi } from "vitest";

vi.mock("next/image", () => ({
  __esModule: true,
  default: ({ src, alt }: any) => React.createElement("img", { src, alt }),
}));

vi.mock("@shared/components/action-card", () => ({
  __esModule: true,
  ActionCard: (props: any) => {
    const { title, description, buttonText, icon } = props;
    return React.createElement(
      "div",
      {
        "data-actioncard": "true",
        "data-title": title,
        "data-description": description,
        "data-buttontext": buttonText,
      },
      icon ? React.createElement("span", { "data-icon": "true" }, icon) : null
    );
  },
}));

vi.mock("@shared/components/button", () => ({
  __esModule: true,
  AppButton: ({ children, ...rest }: any) =>
    React.createElement(
      "button",
      { type: rest.type || "button", "data-appbutton": "true", ...rest },
      children
    ),
}));

import { PrequalifyCard } from "../prequalify-card";

const GET_STARTED_RX = /Get started/i;
const ARROW_INSPECTED_RX = /Arrow inspected icon/i;

describe("PrequalifyCard", () => {
  it("renders AppButton with default text when not detailed", () => {
    render(React.createElement(PrequalifyCard, null));

    const btn = screen.getByRole("button", { name: GET_STARTED_RX });
    expect(btn).toBeInTheDocument();
    expect(btn).toHaveAttribute("data-appbutton", "true");
  });

  it("renders ActionCard with provided props and icon when detailed", () => {
    render(
      React.createElement(PrequalifyCard, {
        detailed: true,
        buttonText: "Apply now",
        title: "Test Title",
        description: "Test Description",
      })
    );

    const actionImg = screen.getByRole("img", { name: ARROW_INSPECTED_RX });
    expect(actionImg).toBeInTheDocument();

    const actionCard = document.querySelector('[data-actioncard="true"]');
    expect(actionCard).toBeTruthy();
    expect(actionCard).toHaveAttribute("data-title", "Test Title");
    expect(actionCard).toHaveAttribute("data-description", "Test Description");
    expect(actionCard).toHaveAttribute("data-buttontext", "Apply now");
  });
});
