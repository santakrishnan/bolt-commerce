import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { VehicleBadges } from "../badges-vehicle";

describe("VehicleBadges", () => {
  it("always renders excellent price badge", () => {
    render(<VehicleBadges inspected={false} warranty={false} />);
    expect(screen.getByText("Excellent Price")).toBeInTheDocument();
  });

  it("renders warranty badge when warranty is true", () => {
    render(<VehicleBadges inspected={false} warranty={true} />);
    expect(screen.getByText("Warranty")).toBeInTheDocument();
  });

  it("renders inspected badge when inspected is true", () => {
    render(<VehicleBadges inspected={true} warranty={false} />);
    expect(screen.getByText("Inspected")).toBeInTheDocument();
  });

  it("renders all three badges when both warranty and inspected are true", () => {
    render(<VehicleBadges inspected={true} warranty={true} />);
    expect(screen.getByText("Excellent Price")).toBeInTheDocument();
    expect(screen.getByText("Warranty")).toBeInTheDocument();
    expect(screen.getByText("Inspected")).toBeInTheDocument();
  });

  it("does not render warranty badge when warranty is false", () => {
    render(<VehicleBadges inspected={false} warranty={false} />);
    expect(screen.queryByText("Warranty")).not.toBeInTheDocument();
  });

  it("does not render inspected badge when inspected is false", () => {
    render(<VehicleBadges inspected={false} warranty={false} />);
    expect(screen.queryByText("Inspected")).not.toBeInTheDocument();
  });

  it("applies custom className", () => {
    const { container } = render(
      <VehicleBadges className="custom-badge-class" inspected={false} warranty={false} />
    );
    const wrapper = container.firstChild as HTMLElement;
    expect(wrapper).toHaveAttribute("class");
  });

  it("renders Excellent Price and Warranty when only warranty is true", () => {
    render(<VehicleBadges inspected={false} warranty={true} />);
    expect(screen.getByText("Excellent Price")).toBeInTheDocument();
    expect(screen.getByText("Warranty")).toBeInTheDocument();
  });

  it("renders Excellent Price and Inspected when only inspected is true", () => {
    render(<VehicleBadges inspected={true} warranty={false} />);
    expect(screen.getByText("Excellent Price")).toBeInTheDocument();
    expect(screen.getByText("Inspected")).toBeInTheDocument();
  });
});
