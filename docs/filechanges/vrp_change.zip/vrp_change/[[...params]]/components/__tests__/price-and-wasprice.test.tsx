import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { VehiclePrice } from "../price-and-wasprice";

describe("VehiclePrice", () => {
  it("renders current price", () => {
    render(<VehiclePrice price={25_000} />);
    expect(screen.getByText("$25,000")).toBeInTheDocument();
  });

  it("renders price with thousands separator", () => {
    render(<VehiclePrice price={45_500} />);
    expect(screen.getByText("$45,500")).toBeInTheDocument();
  });

  it("renders large price", () => {
    render(<VehiclePrice price={125_999} />);
    expect(screen.getByText("$125,999")).toBeInTheDocument();
  });

  it("does not render was price when originalPrice is undefined", () => {
    render(<VehiclePrice price={30_000} />);
    expect(screen.queryByText("was")).not.toBeInTheDocument();
  });

  it("does not render was price when originalPrice is null", () => {
    render(<VehiclePrice originalPrice={null} price={30_000} />);
    expect(screen.queryByText("was")).not.toBeInTheDocument();
  });

  it("does not render was price when originalPrice is equal to current price", () => {
    render(<VehiclePrice originalPrice={30_000} price={30_000} />);
    expect(screen.queryByText("was")).not.toBeInTheDocument();
  });

  it("does not render was price when originalPrice is lower than current price", () => {
    render(<VehiclePrice originalPrice={25_000} price={30_000} />);
    expect(screen.queryByText("was")).not.toBeInTheDocument();
  });

  it("renders was price when originalPrice is higher than current price", () => {
    render(<VehiclePrice originalPrice={35_000} price={30_000} />);
    expect(screen.getByText("was")).toBeInTheDocument();
    expect(screen.getByText("$35,000")).toBeInTheDocument();
  });

  it("renders was price with proper formatting", () => {
    render(<VehiclePrice originalPrice={40_000} price={32_000} />);
    const wastPriceElement = screen.getAllByText("$40,000")[0];
    expect(wastPriceElement).toBeInTheDocument();
    expect(wastPriceElement?.textContent).toBe("$40,000");
  });

  it("applies custom className", () => {
    render(<VehiclePrice className="custom-wrapper" price={25_000} />);
    expect(screen.getByText("$25,000")).toBeInTheDocument();
  });

  it("applies custom priceClassName", () => {
    render(<VehiclePrice price={25_000} priceClassName="custom-price-class text-xl" />);
    expect(screen.getByText("$25,000")).toBeInTheDocument();
  });

  it("handles zero price", () => {
    render(<VehiclePrice price={0} />);
    expect(screen.getByText("$0")).toBeInTheDocument();
  });

  it("handles null price by rendering 0", () => {
    render(<VehiclePrice price={null as any} />);
    expect(screen.getByText("$0")).toBeInTheDocument();
  });

  it("renders multiple prices in was price scenario", () => {
    render(<VehiclePrice originalPrice={50_000} price={40_000} />);
    expect(screen.getByText("$40,000")).toBeInTheDocument();
    expect(screen.getByText("$50,000")).toBeInTheDocument();
  });
});
