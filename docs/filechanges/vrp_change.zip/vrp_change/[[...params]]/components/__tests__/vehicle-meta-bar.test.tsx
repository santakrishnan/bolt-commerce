import { render } from "@testing-library/react";
import React from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";

describe("VehicleMetaBar — behavior-only", () => {
  beforeEach(() => {
    vi.resetModules();
    document.body.innerHTML = "";
    vi.doMock("@tfs-ucmp/ui", () => ({ cn: (...parts: any[]) => parts.filter(Boolean).join(" ") }));
  });

  it("renders expected chips and formats numeric mileage, no accidents path", async () => {
    const mod = await import("../vehicle-meta-bar");
    const { VehicleMetaBar } = mod;

    const vehicle = {
      drivetrain: "FWD",
      fuelType: undefined,
      transmission: undefined,
      miles: "12345",
      exteriorColor: "Wind Chill Pearl",
      interiorColor: "Black",
      certified: true,
      warranty: false,
      inspectionPassed: true,
      inspected: undefined,
    } as any;

    const specs: any[] = [
      { key: "fuel-type", value: "Gasoline" },
      { key: "transmission", value: "Automatic" },
    ];

    const historyData = { damageReported: 0, previousOwners: 1, titleStatus: undefined } as any;
    const vehicleStatus = { inspectionInProgress: false } as any;

    const { container } = render(
      React.createElement(VehicleMetaBar, { vehicle, specs, historyData, vehicleStatus })
    );

    const text = container.textContent || "";
    expect(text).toContain("FWD");
    expect(text).toContain("Gasoline");
    expect(text).toContain("Automatic");
    expect(text).toContain("12,345 mi");
    expect(text).toContain("Ext");
    expect(text).toContain("Int");
    expect(text).toContain("No Accidents");
    expect(text).toContain("1 Owner");
    expect(text).toContain("Certified");
    expect(text).toContain("160-Point Inspection");
  });

  it("renders alternate branches (plural accidents, non-numeric miles, missing swatch)", async () => {
    const mod = await import("../vehicle-meta-bar");
    const { VehicleMetaBar } = mod;

    const vehicle = {
      drivetrain: "AWD",
      miles: "unknown",
      exteriorColor: "Some Unknown Color",
      interiorColor: "Some Unknown Int",
      certified: false,
      warranty: false,
      inspectionPassed: false,
    } as any;

    const specs: any[] = [];
    const historyData = { damageReported: 2, previousOwners: 2, titleStatus: "Salvage" } as any;
    const vehicleStatus = { inspectionInProgress: true } as any;

    const { container } = render(
      React.createElement(VehicleMetaBar, { vehicle, specs, historyData, vehicleStatus })
    );

    const text = container.textContent || "";
    expect(text).toContain("AWD");
    expect(text).toContain("unknown");
    expect(text).toContain("2 Accidents");
    expect(text).toContain("2 Owners");
    expect(text).toContain("Salvage");
    expect(text).toContain("Some Unknown Color");
  });

  // Note: avoid importing internal helpers from the module to respect SUT immutability.
});
