import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { TestDriveCard } from "../test-drive-card";

describe("TestDriveCard", () => {
  it("renders with default button text", () => {
    render(<TestDriveCard />);
    expect(screen.getByRole("button")).toHaveTextContent("Book an Appointment");
  });

  it("renders with custom button text", () => {
    render(<TestDriveCard buttonText="Schedule Now" />);
    expect(screen.getByRole("button")).toHaveTextContent("Schedule Now");
  });

  it("renders button with full width class", () => {
    render(<TestDriveCard />);
    const button = screen.getByRole("button");
    expect(button).toBeInTheDocument();
    expect(button.tagName).toBe("BUTTON");
  });

  it("renders button with rounded-full class", () => {
    render(<TestDriveCard />);
    const button = screen.getByRole("button");
    button.focus();
    expect(document.activeElement).toBe(button);
  });

  it("renders button with tertiary variant", () => {
    render(<TestDriveCard />);
    expect(screen.getByRole("button")).toBeInTheDocument();
  });

  it("renders button with md size", () => {
    render(<TestDriveCard />);
    const button = screen.getByRole("button");
    expect(button).toBeInTheDocument();
  });

  it("renders button with empty text when provided", () => {
    render(<TestDriveCard buttonText="" />);
    const button = screen.getByRole("button");
    expect(button.textContent).toBe("");
  });

  it("renders button with special characters in text", () => {
    render(<TestDriveCard buttonText="Book & Schedule Appointment!" />);
    expect(screen.getByRole("button")).toHaveTextContent("Book & Schedule Appointment!");
  });
});
