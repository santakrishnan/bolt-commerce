import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

vi.mock("@tfs-ucmp/ui", () => {
  const React = require("react");
  return {
    Heading: ({ children, level }: any) => React.createElement(`h${level || 3}`, {}, children),
  };
});

vi.mock("@shared/components/button", () => {
  const React = require("react");
  return {
    AppButton: ({ children, onClick, ...props }: any) =>
      React.createElement("button", { onClick, ...props }, children),
  };
});

vi.mock("../vehicle-action-icons", () => {
  const React = require("react");
  return {
    VehicleActionIcons: (props: any) =>
      React.createElement(
        "div",
        { "data-testid": "vehicle-action-icons", "data-vdp": props.vdpUrl },
        null
      ),
  };
});

vi.mock("@config/routes", () => ({ buildVdpPath: () => "/mock-vdp" }));

import { VehicleStickyBanner } from "../sticky-banner";

const VEHICLE_TITLE_REGEX = /2020 Test Vehicle/;
const PRICE_REGEX = /20,000/;
const MILES_REGEX = /12,345/;
const WAS_REGEX = /was/;
const ORIGINAL_PRICE_REGEX = /25,000/;

const BASE_VEHICLE = {
  title: "2020 Test Vehicle",
  price: 20_000,
  originalPrice: undefined,
  miles: 12_345,
  vin: "VIN123",
  year: 2020,
  make: "Make",
  model: "Model",
  condition: "used",
  warranty: null,
  inspected: false,
  drivetrain: "FWD",
  mpg: 25,
  stock: "STK",
  dealer: { name: "Dealer", location: "City", distance: 10 },
  images: [],
  highlights: [],
} as any;

describe("VehicleStickyBanner — behavior-only", () => {
  it("renders title, price, miles, VIN and action icons (calls buildVdpPath)", () => {
    render(
      <VehicleStickyBanner slugParams={{ vin: BASE_VEHICLE.vin } as any} vehicle={BASE_VEHICLE} />
    );

    const [title] = screen.getAllByText(VEHICLE_TITLE_REGEX);
    expect(title).toBeTruthy();

    const [price] = screen.getAllByText(PRICE_REGEX);
    expect(price).toBeTruthy();

    const [miles] = screen.getAllByText(MILES_REGEX);
    expect(miles).toBeTruthy();
    const [vin] = screen.getAllByText("VIN123");
    expect(vin).toBeTruthy();

    const icons = screen.getAllByTestId("vehicle-action-icons")[0];
    expect(icons?.getAttribute("data-vdp")).toBe("/mock-vdp");

    expect(screen.getAllByText("Get Pre-Qualified").length).toBeGreaterThan(0);

    const [btnText] = screen.getAllByText("Get Pre-Qualified");
    const btn = btnText?.closest("button");
    expect(btn).toBeTruthy();
    fireEvent.click(btn as Element);
  });

  it("shows original price when it's greater than price", () => {
    const v = { ...BASE_VEHICLE, originalPrice: 25_000 } as any;
    render(<VehicleStickyBanner slugParams={{ vin: v.vin } as any} vehicle={v} />);

    expect(screen.getAllByText(WAS_REGEX).length).toBeGreaterThan(0);
    expect(screen.getAllByText(ORIGINAL_PRICE_REGEX)[0]).toBeTruthy();
  });
});
