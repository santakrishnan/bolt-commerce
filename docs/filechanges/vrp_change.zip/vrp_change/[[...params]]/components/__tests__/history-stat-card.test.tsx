import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { HistoryStatCard } from "../history-stat-card";

describe("HistoryStatCard", () => {
  it("renders label", () => {
    render(<HistoryStatCard icon={<span>📋</span>} label="Previous Owners" value="2" />);
    expect(screen.getByText("Previous Owners")).toBeInTheDocument();
  });

  it("renders value", () => {
    render(<HistoryStatCard icon={<span>🚗</span>} label="Total Miles" value="45,000" />);
    expect(screen.getByText("45,000")).toBeInTheDocument();
  });

  it("renders icon", () => {
    render(
      <HistoryStatCard
        icon={<span data-testid="test-icon">⚠️</span>}
        label="Damage History"
        value="None"
      />
    );
    expect(screen.getByTestId("test-icon")).toBeInTheDocument();
  });

  it("renders with custom labels", () => {
    render(<HistoryStatCard icon={<span>✅</span>} label="Service Records" value="Complete" />);
    expect(screen.getByText("Service Records")).toBeInTheDocument();
    expect(screen.getByText("Complete")).toBeInTheDocument();
  });

  it("renders with numeric values", () => {
    render(<HistoryStatCard icon={<span>📊</span>} label="Accidents" value="0" />);
    expect(screen.getByText("0")).toBeInTheDocument();
  });

  it("renders with empty icon", () => {
    render(<HistoryStatCard icon={<span />} label="Test Label" value="Test Value" />);
    expect(screen.getByText("Test Label")).toBeInTheDocument();
  });

  it("renders JSX icon component", () => {
    const IconComponent = () => <div data-testid="jsx-icon">Icon</div>;
    render(<HistoryStatCard icon={<IconComponent />} label="Custom Icon" value="Present" />);
    expect(screen.getByTestId("jsx-icon")).toBeInTheDocument();
  });

  it("renders with very long label", () => {
    const longLabel = "Very Long Label That Describes A Complex History Metric";
    render(<HistoryStatCard icon={<span>📈</span>} label={longLabel} value="Yes" />);
    expect(screen.getByText(longLabel)).toBeInTheDocument();
  });

  it("renders with special characters in value", () => {
    render(<HistoryStatCard icon={<span>💰</span>} label="Price" value="$25,500.00" />);
    expect(screen.getByText("$25,500.00")).toBeInTheDocument();
  });

  it("renders with icon border styling", () => {
    const { container } = render(
      <HistoryStatCard icon={<span>🔧</span>} label="Maintenance" value="Up-to-date" />
    );
    const icon = container.querySelector("span");
    expect(icon).toBeInTheDocument();
  });
});
