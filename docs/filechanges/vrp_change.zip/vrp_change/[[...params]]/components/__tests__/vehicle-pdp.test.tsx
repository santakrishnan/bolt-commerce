import { describe, expect, it, vi } from "vitest";

describe("VehiclePDP — simple behavior tests", () => {
  it("VehiclePDP component is defined", async () => {
    vi.resetModules();
    vi.doMock("next/image", () => ({
      default: (props: any) => ({ $$typeof: Symbol.for("react.element"), type: "img", props }),
    }));
    vi.doMock("next/navigation", () => ({ usePathname: () => "/" }));
    vi.doMock("@config/routes", () => ({ buildVdpPath: () => "/test" }));

    const stubComponent = () => ({ $$typeof: Symbol.for("react.element"), type: "div" });
    vi.doMock("@features/vdp/components/back-to-search", () => ({ BackToSearch: stubComponent }));
    vi.doMock("@features/vdp/components/badges-vehicle", () => ({ VehicleBadges: stubComponent }));
    vi.doMock("@features/vdp/components/colors-vehicle", () => ({ VehicleColors: stubComponent }));
    vi.doMock("@features/vdp/components/dealer-info", () => ({ VehicleDealerInfo: stubComponent }));
    vi.doMock("@features/vdp/components/image-preview-modal", () => ({
      ImagePreviewModal: stubComponent,
    }));
    vi.doMock("@features/vdp/components/image-thumbnail-carousal", () => ({
      ImageCarousel: stubComponent,
    }));
    vi.doMock("@features/vdp/components/key-features", () => ({
      VehicleKeyFeatures: stubComponent,
    }));
    vi.doMock("@features/vdp/components/price-and-wasprice", () => ({
      VehiclePrice: stubComponent,
    }));
    vi.doMock("@features/vdp/components/specs", () => ({ VehicleSpecsGrid: stubComponent }));
    vi.doMock("@features/vdp/components/title", () => ({ VehicleTitle: stubComponent }));
    vi.doMock("@features/vdp/components/vehicle-action-icons", () => ({
      VehicleActionIcons: stubComponent,
    }));
    vi.doMock("@features/vdp/components/vehicle-breadcrumb", () => ({
      VehicleBreadcrumbList: stubComponent,
    }));
    vi.doMock("@features/vdp/components/sticky-banner", () => ({
      VehicleStickyBanner: stubComponent,
    }));
    vi.doMock("../vdp-promotion-cards", () => ({ VdpPromotionCards: stubComponent }));

    const { VehiclePDP } = await import("../vehicle-pdp");
    expect(VehiclePDP).toBeDefined();
    expect(typeof VehiclePDP).toBe("function");
  });

  it("VehiclePDP accepts vehicle and slugParams props", async () => {
    vi.resetModules();

    vi.doMock("next/image", () => ({ default: () => null }));
    vi.doMock("next/navigation", () => ({ usePathname: () => "/" }));
    vi.doMock("@config/routes", () => ({ buildVdpPath: () => "/test" }));

    const stubComponent = () => null;
    vi.doMock("@features/vdp/components/back-to-search", () => ({ BackToSearch: stubComponent }));
    vi.doMock("@features/vdp/components/badges-vehicle", () => ({ VehicleBadges: stubComponent }));
    vi.doMock("@features/vdp/components/colors-vehicle", () => ({ VehicleColors: stubComponent }));
    vi.doMock("@features/vdp/components/dealer-info", () => ({ VehicleDealerInfo: stubComponent }));
    vi.doMock("@features/vdp/components/image-preview-modal", () => ({
      ImagePreviewModal: stubComponent,
    }));
    vi.doMock("@features/vdp/components/image-thumbnail-carousal", () => ({
      ImageCarousel: stubComponent,
    }));
    vi.doMock("@features/vdp/components/key-features", () => ({
      VehicleKeyFeatures: stubComponent,
    }));
    vi.doMock("@features/vdp/components/price-and-wasprice", () => ({
      VehiclePrice: stubComponent,
    }));
    vi.doMock("@features/vdp/components/specs", () => ({ VehicleSpecsGrid: stubComponent }));
    vi.doMock("@features/vdp/components/title", () => ({ VehicleTitle: stubComponent }));
    vi.doMock("@features/vdp/components/vehicle-action-icons", () => ({
      VehicleActionIcons: stubComponent,
    }));
    vi.doMock("@features/vdp/components/vehicle-breadcrumb", () => ({
      VehicleBreadcrumbList: stubComponent,
    }));
    vi.doMock("@features/vdp/components/sticky-banner", () => ({
      VehicleStickyBanner: stubComponent,
    }));
    vi.doMock("../vdp-promotion-cards", () => ({ VdpPromotionCards: stubComponent }));

    const { VehiclePDP } = await import("../vehicle-pdp");
    expect(VehiclePDP).toBeDefined();
  });

  it("VehiclePDP is a React FC", async () => {
    vi.resetModules();

    vi.doMock("next/image", () => ({ default: () => null }));
    vi.doMock("next/navigation", () => ({ usePathname: () => "/" }));
    vi.doMock("@config/routes", () => ({ buildVdpPath: () => "/test" }));

    const stubComponent = () => null;
    vi.doMock("@features/vdp/components/back-to-search", () => ({ BackToSearch: stubComponent }));
    vi.doMock("@features/vdp/components/badges-vehicle", () => ({ VehicleBadges: stubComponent }));
    vi.doMock("@features/vdp/components/colors-vehicle", () => ({ VehicleColors: stubComponent }));
    vi.doMock("@features/vdp/components/dealer-info", () => ({ VehicleDealerInfo: stubComponent }));
    vi.doMock("@features/vdp/components/image-preview-modal", () => ({
      ImagePreviewModal: stubComponent,
    }));
    vi.doMock("@features/vdp/components/image-thumbnail-carousal", () => ({
      ImageCarousel: stubComponent,
    }));
    vi.doMock("@features/vdp/components/key-features", () => ({
      VehicleKeyFeatures: stubComponent,
    }));
    vi.doMock("@features/vdp/components/price-and-wasprice", () => ({
      VehiclePrice: stubComponent,
    }));
    vi.doMock("@features/vdp/components/specs", () => ({ VehicleSpecsGrid: stubComponent }));
    vi.doMock("@features/vdp/components/title", () => ({ VehicleTitle: stubComponent }));
    vi.doMock("@features/vdp/components/vehicle-action-icons", () => ({
      VehicleActionIcons: stubComponent,
    }));
    vi.doMock("@features/vdp/components/vehicle-breadcrumb", () => ({
      VehicleBreadcrumbList: stubComponent,
    }));
    vi.doMock("@features/vdp/components/sticky-banner", () => ({
      VehicleStickyBanner: stubComponent,
    }));
    vi.doMock("../vdp-promotion-cards", () => ({ VdpPromotionCards: stubComponent }));

    const mod = await import("../vehicle-pdp");
    expect(mod.VehiclePDP).toBeTruthy();
  });
});
