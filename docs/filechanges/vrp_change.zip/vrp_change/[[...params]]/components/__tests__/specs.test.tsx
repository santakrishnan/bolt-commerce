import { render } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { VehicleSpecsGrid } from "../specs";

vi.mock("@/components/heading", () => ({
  Heading: ({ children, className }: any) => <h3 className={className}>{children}</h3>,
}));

const RE_DRIVETRAIN = /Front-Wheel|FWD/;
const RE_MILES = /50,000|miles/;
const RE_MPG = /28|35|mpg/;
const RE_STOCK = /STOCK12345|Stock/;
const RE_VIN = /12345ABCDE|VIN/;

describe("VehicleSpecsGrid Component", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  const defaultProps = {
    drivetrain: "Front-Wheel Drive",
    miles: "50,000",
    mpg: "28/35",
    stock: "STOCK12345",
    vin: "12345ABCDE",
  };

  it("should render specifications grid", () => {
    const { container } = render(<VehicleSpecsGrid {...defaultProps} />);
    expect(container).toBeInTheDocument();
  });

  it("should display drivetrain spec", () => {
    const { container } = render(<VehicleSpecsGrid {...defaultProps} />);
    expect(container.textContent).toMatch(RE_DRIVETRAIN);
  });

  it("should display miles spec", () => {
    const { container } = render(<VehicleSpecsGrid {...defaultProps} />);
    expect(container.textContent).toMatch(RE_MILES);
  });

  it("should display MPG information", () => {
    const { container } = render(<VehicleSpecsGrid {...defaultProps} />);
    expect(container.textContent).toMatch(RE_MPG);
  });

  it("should display stock number", () => {
    const { container } = render(<VehicleSpecsGrid {...defaultProps} />);
    expect(container.textContent).toMatch(RE_STOCK);
  });

  it("should display VIN", () => {
    const { container } = render(<VehicleSpecsGrid {...defaultProps} />);
    expect(container.textContent).toMatch(RE_VIN);
  });

  it("should apply custom className", () => {
    const { container } = render(<VehicleSpecsGrid {...defaultProps} className="custom-class" />);
    const text = container.textContent;
    expect(text).toMatch(RE_MILES);
  });

  it("should format all specs correctly", () => {
    const { container } = render(<VehicleSpecsGrid {...defaultProps} />);
    expect(container.textContent).toBeDefined();
  });

  it("should be accessible", () => {
    const { container } = render(<VehicleSpecsGrid {...defaultProps} />);
    expect(container.textContent).toBeDefined();
  });
});
