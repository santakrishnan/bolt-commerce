import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { VehicleTitle } from "../title";

vi.mock("@/components/heading", () => ({
  Heading: ({ children, className }: any) => <h1 className={className}>{children}</h1>,
}));

describe("VehicleTitle Component", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should render vehicle title with year make model", () => {
    render(
      <VehicleTitle className="test-class" make="Toyota" model="Camry" trim="LE" year={2023} />
    );
    const heading = screen.getByRole("heading", { level: 1 });
    expect(heading).toBeInTheDocument();
  });

  it("should display year make model in correct order", () => {
    render(<VehicleTitle make="Honda" model="Accord" year={2023} />);
    const text = document.body.textContent;
    expect(text).toContain("2023");
    expect(text).toContain("Honda");
    expect(text).toContain("Accord");
  });

  it("should include trim when provided", () => {
    render(<VehicleTitle make="Toyota" model="Camry" trim="Premium" year={2023} />);
    const text = document.body.textContent;
    expect(text).toContain("Premium");
  });

  it("should handle missing trim gracefully", () => {
    render(<VehicleTitle make="Toyota" model="Camry" year={2023} />);
    expect(screen.getByRole("heading")).toBeInTheDocument();
  });

  it("should apply custom className", () => {
    render(<VehicleTitle className="custom-class" make="Toyota" model="Camry" year={2023} />);
    const heading = screen.getByRole("heading");
    expect(heading).toBeInTheDocument();
  });

  it("should render as proper heading element", () => {
    render(<VehicleTitle make="Toyota" model="Camry" year={2023} />);
    const heading = screen.getByRole("heading", { level: 1 });
    expect(heading).toBeInTheDocument();
  });

  it("should handle numeric and string year values", () => {
    render(<VehicleTitle make="Toyota" model="Camry" year={2023} />);
    render(<VehicleTitle make="Toyota" model="Camry" year={"2023"} />);
    expect(screen.getAllByRole("heading").length).toBeGreaterThanOrEqual(2);
  });
});
