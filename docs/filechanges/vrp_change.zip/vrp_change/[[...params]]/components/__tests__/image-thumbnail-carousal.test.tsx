import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import React from "react";
import { afterEach, expect, test, vi } from "vitest";
import { ImageCarousel } from "../image-thumbnail-carousal";

const VIEW_REGEX = /View image (\d+)/;
vi.mock("@tfs-ucmp/ui", async () => {
  const React = await import("react");
  let lastApi: any = null;
  let lastSetApi: any = null;
  let lastCarouselContentProps: any = null;

  function createApi() {
    const listeners: Record<string, (...args: unknown[]) => unknown> = {};
    const api: any = {
      _selected: 0,
      scrollTo: vi.fn((i: number) => {
        api._selected = i;
      }),
      scrollPrev: vi.fn(() => {
        api._selected = Math.max(0, (api._selected ?? 0) - 1);
      }),
      scrollNext: vi.fn(() => {
        api._selected = Math.min(10, (api._selected ?? 0) + 1);
      }),
      on: (e: string, cb: (...args: unknown[]) => unknown) => {
        listeners[e] = cb;
      },
      off: (e: string) => {
        delete listeners[e];
      },
      selectedScrollSnap: vi.fn(() => api._selected ?? 0),
      _listeners: listeners,
      trigger: (e: string) => {
        listeners[e]?.();
      },
    };
    return api;
  }

  const Button = (props: any) => {
    const aria = props["aria-label"] || props["aria-hidden"];
    const handleClick = (e: any) => {
      if (typeof props.onClick === "function") {
        props.onClick(e);
      }
      try {
        if (typeof aria === "string" && aria.includes("Previous")) {
          lastApi?.scrollPrev();
        } else if (typeof aria === "string" && aria.includes("Next")) {
          lastApi?.scrollNext();
        } else if (typeof aria === "string" && aria.startsWith("View image")) {
          const match = aria.match(VIEW_REGEX);
          const idx = match ? Number(match[1]) - 1 : undefined;
          if (typeof idx === "number") {
            lastApi?.scrollTo(idx);
          }
        }
      } catch (_err) {
        // intentional: suppress carousel API errors in test
      }
    };
    return React.createElement("button", { ...props, onClick: handleClick }, props.children);
  };

  const Carousel = ({ setApi, children }: any) => {
    const api = createApi();
    lastApi = api;
    lastSetApi = setApi;
    React.useLayoutEffect(() => setApi(api), [setApi]);
    return React.createElement("div", { "data-testid": "carousel" }, children);
  };

  const CarouselContent = (props: any) => {
    lastCarouselContentProps = props;
    return React.createElement(
      "div",
      { "data-testid": "carousel-content", ...props },
      props.children
    );
  };
  const CarouselItem = (props: any) => React.createElement("div", props, props.children);

  return {
    __esModule: true,
    Button,
    Carousel,
    CarouselContent,
    CarouselItem,
    getLastCarouselContentProps: () => lastCarouselContentProps,
    getLastApi: () => lastApi,
    getLastSetApi: () => lastSetApi,
  };
});

vi.mock("next/image", () => ({
  __esModule: true,
  default: (props: any) => React.createElement("span", { "data-src": props.src }, props.alt),
}));

if (!HTMLElement.prototype.scrollIntoView) {
  HTMLElement.prototype.scrollIntoView = (() => undefined) as any;
}

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
});

const IMAGES = ["/1.jpg", "/2.jpg", "/3.jpg"];

test("renders images and thumbnails", () => {
  const { container } = render(<ImageCarousel alt="alt" images={IMAGES} />);
  expect(screen.getByText("3 Images")).toBeTruthy();
  const imgs = container.querySelectorAll("span[data-src]");
  expect(imgs.length).toBeGreaterThanOrEqual(IMAGES.length);
  expect(container.querySelector('button[aria-label="View image 1 of 3"]')).toBeTruthy();
});

test("prev/next buttons and thumbnail click call carousel api", async () => {
  const onImageIndexChange = vi.fn();
  render(<ImageCarousel alt="alt" images={IMAGES} onImageIndexChange={onImageIndexChange} />);

  await screen.findByTestId("carousel");
  const ui: any = await import("@tfs-ucmp/ui");
  let api = ui.getLastApi();
  for (let i = 0; i < 10 && !api; i++) {
    await new Promise((r) => setTimeout(r, 0));
    api = ui.getLastApi();
  }
  expect(api).toBeTruthy();

  const prev = screen.queryByLabelText("Previous image");
  const next = screen.queryByLabelText("Next image");
  if (prev) {
    fireEvent.click(prev);
  }
  if (next) {
    fireEvent.click(next);
  }

  const thumb2 = screen.getByLabelText("View image 2 of 3");
  fireEvent.click(thumb2);

  expect(api.scrollPrev).toBeDefined();
  expect(api.scrollNext).toBeDefined();
  expect(api.scrollTo).toBeDefined();
});

test("onImageClick fires when pointer down and click are within threshold", async () => {
  const onImageClick = vi.fn();
  render(<ImageCarousel alt="alt" images={IMAGES} onImageClick={onImageClick} />);

  await screen.findByTestId("carousel");
  const ui: any = await import("@tfs-ucmp/ui");
  const lastProps = ui.getLastCarouselContentProps?.();
  lastProps?.onPointerDown?.({ clientX: 10, clientY: 10 });
  lastProps?.onClick?.({ clientX: 10, clientY: 10 });

  expect(onImageClick).toHaveBeenCalled();
});

test("select event updates index and scrolls thumbnail into view", async () => {
  const onImageIndexChange = vi.fn();

  render(<ImageCarousel alt="alt" images={IMAGES} onImageIndexChange={onImageIndexChange} />);
  await screen.findByTestId("carousel");

  const ui: any = await import("@tfs-ucmp/ui");
  let api = ui.getLastApi();
  for (let i = 0; i < 10 && !api; i++) {
    await new Promise((r) => setTimeout(r, 0));
    api = ui.getLastApi();
  }
  expect(api).toBeTruthy();

  (onImageIndexChange as any).mockClear?.();

  const setApi = ui.getLastSetApi?.();
  if (setApi) {
    setApi(api);
  }

  for (let i = 0; i < 10 && !api._listeners?.select; i++) {
    // eslint-disable-next-line no-await-in-loop
    await new Promise((r) => setTimeout(r, 0));
  }

  if (api?.scrollTo) {
    api.scrollTo(2);
  }
  if (typeof api.trigger === "function") {
    api.trigger("select");
  }
  await new Promise((r) => setTimeout(r, 0));

  expect(onImageIndexChange).toHaveBeenCalled();
  expect(onImageIndexChange).toHaveBeenLastCalledWith(2);
});
