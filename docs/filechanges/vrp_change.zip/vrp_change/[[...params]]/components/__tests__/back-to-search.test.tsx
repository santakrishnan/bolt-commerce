import { ROUTES } from "@config/routes/constants";
import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { BackToSearch } from "../back-to-search";

const mockBack = vi.fn();
const mockPush = vi.fn();

vi.mock("next/navigation", () => ({
  useRouter: () => ({ back: mockBack, push: mockPush }),
}));

// Mock next/image to a lightweight element to avoid React child errors in tests
vi.mock("next/image", () => ({ __esModule: true, default: (props: any) => <span {...props} /> }));

let isMobileValue = true;
vi.mock("@shared/hooks/use-is-mobile", () => ({ useIsMobile: () => isMobileValue }));

describe("BackToSearch", () => {
  beforeEach(() => {
    mockBack.mockClear();
    mockPush.mockClear();
  });

  // no global teardown needed; individual tests set history explicitly

  it("shows mobile text when on mobile", () => {
    isMobileValue = true;
    render(<BackToSearch />);
    expect(screen.getByText("Back to Search")).toBeInTheDocument();
  });

  it("shows desktop text when not mobile", () => {
    isMobileValue = false;
    render(<BackToSearch />);
    expect(screen.getByText("Back to Search Result")).toBeInTheDocument();
  });

  it("calls router.back when history length > 1 on left click", () => {
    // simulate a session with previous entries
    Object.defineProperty(window.history, "length", { value: 3, configurable: true });
    isMobileValue = true;
    render(<BackToSearch />);
    const anchor = screen.getByLabelText("Back to search");
    fireEvent.click(anchor);

    expect(mockBack).toHaveBeenCalled();
    expect(mockPush).not.toHaveBeenCalled();
  });

  it("calls router.push when history length <= 1 on left click", () => {
    Object.defineProperty(window.history, "length", { value: 1, configurable: true });
    isMobileValue = true;
    render(<BackToSearch />);
    const anchor = screen.getByLabelText("Back to search");
    fireEvent.click(anchor);

    expect(mockPush).toHaveBeenCalledWith(ROUTES.USED_CARS);
    expect(mockBack).not.toHaveBeenCalled();
  });

  it("does not navigate on non-left clicks or when modifier keys are used", () => {
    Object.defineProperty(window.history, "length", { value: 3, configurable: true });
    isMobileValue = true;
    render(<BackToSearch />);
    const anchor = screen.getByLabelText("Back to search");

    // non-left click (button=1)
    anchor.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, button: 1 }));
    // modifier key (metaKey)
    anchor.dispatchEvent(
      new MouseEvent("click", { bubbles: true, cancelable: true, metaKey: true } as any)
    );

    expect(mockBack).not.toHaveBeenCalled();
    expect(mockPush).not.toHaveBeenCalled();
  });

  it("does nothing when the event's default is already prevented", () => {
    isMobileValue = true;
    render(<BackToSearch />);
    const anchor = screen.getByLabelText("Back to search");

    const ev = new MouseEvent("click", { bubbles: true, cancelable: true });
    ev.preventDefault();
    anchor.dispatchEvent(ev);

    expect(mockBack).not.toHaveBeenCalled();
    expect(mockPush).not.toHaveBeenCalled();
  });
});
