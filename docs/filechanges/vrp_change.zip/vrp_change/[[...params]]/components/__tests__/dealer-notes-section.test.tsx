import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { DealerNotesSection } from "../dealer-notes-section";

vi.mock("next/image", () => ({
  default: ({ alt, src }: any) => <span aria-label={alt} data-src={src} role="img" />,
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Card: ({ children, className }: any) => <div className={className}>{children}</div>,
  Heading: ({ children, level, weight, className }: any) => (
    <div className={className} data-level={level} data-weight={weight}>
      {children}
    </div>
  ),
  cn: (...args: any[]) => args.filter(Boolean).join(" "),
}));

describe("DealerNotesSection", () => {
  const mockDealer = {
    id: "dealer-1",
    name: "Test Dealer",
    address: "123 Test St",
    phone: "555-1234",
    hours: "9AM - 6PM",
    dealershipImage: "https://example.com/dealer.jpg",
    rating: 4.5,
  };

  const mockDealerNotes = {
    dealer: mockDealer,
    vehicleDescription: "This vehicle is in excellent condition with full service history.",
    vehicleImage: "https://example.com/vehicle.jpg",
  };

  it("renders dealer notes heading", () => {
    render(<DealerNotesSection data={mockDealerNotes} />);

    expect(screen.getByText("Dealer Notes")).toBeInTheDocument();
  });

  it("renders vehicle description", () => {
    render(<DealerNotesSection data={mockDealerNotes} />);

    expect(
      screen.getByText("This vehicle is in excellent condition with full service history.")
    ).toBeInTheDocument();
  });

  it("renders vehicle image", () => {
    render(<DealerNotesSection data={mockDealerNotes} />);

    const image = screen.getByRole("img", { name: "Vehicle" });
    expect(image).toBeInTheDocument();
    expect(image).toHaveAttribute("data-src", "https://example.com/vehicle.jpg");
  });

  it("renders section as section element", () => {
    const { container } = render(<DealerNotesSection data={mockDealerNotes} />);

    const section = container.querySelector("section");
    expect(section).toBeInTheDocument();
  });

  it("uses default data when no data prop provided", () => {
    render(<DealerNotesSection />);

    expect(screen.getByText("Dealer Notes")).toBeInTheDocument();
  });

  it("renders card component", () => {
    const { container } = render(<DealerNotesSection data={mockDealerNotes} />);

    const card = container.querySelector("div");
    expect(card).toBeInTheDocument();
  });

  it("renders with custom description text", () => {
    const customNotes = {
      dealer: mockDealer,
      vehicleDescription: "Custom dealer notes about this specific vehicle.",
      vehicleImage: "https://example.com/vehicle.jpg",
    };
    render(<DealerNotesSection data={customNotes} />);

    expect(
      screen.getByText("Custom dealer notes about this specific vehicle.")
    ).toBeInTheDocument();
  });

  it("renders heading with correct level", () => {
    const { container } = render(<DealerNotesSection data={mockDealerNotes} />);

    const heading = container.querySelector("[data-level='2']");
    expect(heading).toBeInTheDocument();
  });

  it("renders image with correct alt text", () => {
    render(<DealerNotesSection data={mockDealerNotes} />);

    const image = screen.getByRole("img", { name: "Vehicle" });
    expect(image).toBeInTheDocument();
  });
});
