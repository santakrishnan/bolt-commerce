import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { VehicleRating } from "../vehicle-rating";

vi.mock("@shared/components/button", () => ({
  AppButton: ({ children, size, variant }: any) => (
    <button data-size={size} data-variant={variant} type="button">
      {children}
    </button>
  ),
}));

vi.mock("@tfs-ucmp/ui", () => ({
  StarIcon: ({ fill, className }: any) => (
    <span className={className} data-fill={fill}>
      ★
    </span>
  ),
}));

const REVIEWS_REGEX = /1100 Reviews/;

describe("VehicleRating", () => {
  const mockDistribution = [
    { id: "five", stars: 5, count: 450 },
    { id: "four", stars: 4, count: 300 },
    { id: "three", stars: 3, count: 200 },
    { id: "two", stars: 2, count: 100 },
    { id: "one", stars: 1, count: 50 },
  ];

  it("renders title", () => {
    render(
      <VehicleRating
        distribution={mockDistribution}
        rating={4.5}
        reviewCount={1100}
        title="Customer Reviews"
      />
    );

    expect(screen.getByText("Customer Reviews")).toBeInTheDocument();
  });

  it("renders rating with one decimal place", () => {
    render(
      <VehicleRating
        distribution={mockDistribution}
        rating={4.5}
        reviewCount={1100}
        title="Customer Reviews"
      />
    );

    expect(screen.getByText("4.5")).toBeInTheDocument();
  });

  it("renders review count in button", () => {
    render(
      <VehicleRating
        distribution={mockDistribution}
        rating={4.5}
        reviewCount={1100}
        title="Customer Reviews"
      />
    );

    expect(screen.getByText(REVIEWS_REGEX)).toBeInTheDocument();
  });

  it("renders all distribution star levels", () => {
    render(
      <VehicleRating
        distribution={mockDistribution}
        rating={4.5}
        reviewCount={1100}
        title="Customer Reviews"
      />
    );

    expect(screen.getByText("5 stars")).toBeInTheDocument();
    expect(screen.getByText("4 stars")).toBeInTheDocument();
    expect(screen.getByText("3 stars")).toBeInTheDocument();
    expect(screen.getByText("2 stars")).toBeInTheDocument();
    expect(screen.getByText("1 stars")).toBeInTheDocument();
  });

  it("renders distribution counts", () => {
    render(
      <VehicleRating
        distribution={mockDistribution}
        rating={4.5}
        reviewCount={1100}
        title="Customer Reviews"
      />
    );

    expect(screen.getByText("450")).toBeInTheDocument();
    expect(screen.getByText("300")).toBeInTheDocument();
    expect(screen.getByText("200")).toBeInTheDocument();
    expect(screen.getByText("100")).toBeInTheDocument();
    expect(screen.getByText("50")).toBeInTheDocument();
  });

  it("renders 5 star icons", () => {
    const { container } = render(
      <VehicleRating
        distribution={mockDistribution}
        rating={4.5}
        reviewCount={1100}
        title="Customer Reviews"
      />
    );

    const stars = container.querySelectorAll('[role="img"] span');
    expect(stars.length).toBe(5);
  });

  it("fills correct number of stars based on rating", () => {
    const { container } = render(
      <VehicleRating
        distribution={mockDistribution}
        rating={4.5}
        reviewCount={1100}
        title="Customer Reviews"
      />
    );

    const stars = Array.from(container.querySelectorAll('[role="img"] span'));
    const filledStars = stars.filter((star) => star.getAttribute("data-fill") === "currentColor");
    expect(filledStars.length).toBe(5); // 4.5 rounds up to 5
  });

  it("renders view more button", () => {
    render(
      <VehicleRating
        distribution={mockDistribution}
        rating={4.5}
        reviewCount={1100}
        title="Customer Reviews"
      />
    );

    const button = screen.getByRole("button");
    expect(button).toBeInTheDocument();
    expect(button).toHaveTextContent("View More");
  });

  it("renders rating bars for all distribution items", () => {
    const { container } = render(
      <VehicleRating
        distribution={mockDistribution}
        rating={4.5}
        reviewCount={1100}
        title="Customer Reviews"
      />
    );

    const bars = container.querySelectorAll("[role*='meter']");
    expect(bars.length).toBeGreaterThanOrEqual(5);
  });

  it("handles single decimal rating", () => {
    render(
      <VehicleRating
        distribution={mockDistribution}
        rating={4.0}
        reviewCount={100}
        title="Customer Reviews"
      />
    );

    expect(screen.getByText("4.0")).toBeInTheDocument();
  });

  it("handles high ratings", () => {
    render(
      <VehicleRating
        distribution={mockDistribution}
        rating={5.0}
        reviewCount={500}
        title="Customer Reviews"
      />
    );

    expect(screen.getByText("5.0")).toBeInTheDocument();
  });

  it("handles low ratings", () => {
    render(
      <VehicleRating
        distribution={mockDistribution}
        rating={1.0}
        reviewCount={50}
        title="Customer Reviews"
      />
    );

    expect(screen.getByText("1.0")).toBeInTheDocument();
  });

  it("renders bars with correct width percentages", () => {
    const { container } = render(
      <VehicleRating
        distribution={mockDistribution}
        rating={4.5}
        reviewCount={1100}
        title="Customer Reviews"
      />
    );

    const barFills = container.querySelectorAll("div[style*='width']");
    expect(barFills.length).toBeGreaterThan(0);
  });

  it("handles empty distribution", () => {
    render(<VehicleRating distribution={[]} rating={0} reviewCount={0} title="Customer Reviews" />);

    expect(screen.getByText("0.0")).toBeInTheDocument();
  });

  it("handles distribution items with zero count (covers zero-width branch)", () => {
    const zeroDist = [{ id: "zero", stars: 5, count: 0 }];
    render(<VehicleRating distribution={zeroDist} rating={0} reviewCount={0} title="Zero" />);

    // assert the count text exists (avoid asserting inline styles)
    expect(screen.getByText("0")).toBeInTheDocument();
  });

  it("displays all star ratings in order", () => {
    render(
      <VehicleRating
        distribution={mockDistribution}
        rating={4.5}
        reviewCount={1100}
        title="Customer Reviews"
      />
    );

    const starTexts = ["5 stars", "4 stars", "3 stars", "2 stars", "1 stars"];
    for (const text of starTexts) {
      expect(screen.getByText(text)).toBeInTheDocument();
    }
  });
});
