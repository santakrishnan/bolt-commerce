import { describe, expect, it } from "vitest";
import * as vehicleData from "../vehicle-data";

describe("vehicle-data module", () => {
  it('exports specsById and contains expected engine spec for id "1"', () => {
    const specs = vehicleData.specsById["1"];
    expect(Array.isArray(specs)).toBe(true);
    const engine = specs?.find((s) => s.key === "engine");
    expect(engine).toBeDefined();
    expect(engine?.value).toBeTruthy();
  });

  it("returns undefined for missing specs id", () => {
    expect(vehicleData.specsById.zzz).toBeUndefined();
  });

  it('exports featuresById and includes Safety category for id "1"', () => {
    const categories = vehicleData.featuresById["1"];
    expect(Array.isArray(categories)).toBe(true);
    const safety = categories?.find((c) => c.name === "Safety");
    expect(safety).toBeDefined();
    expect(safety?.features.length).toBeGreaterThan(0);
  });

  it("exports ratingById and vehicleStatusById and they have expected shapes", () => {
    const rating = vehicleData.ratingById["1"];
    expect(rating).toBeDefined();
    expect(typeof rating?.rating).toBe("number");
    expect(Array.isArray(rating?.distribution)).toBe(true);

    const status = vehicleData.vehicleStatusById["1"];
    expect(status).toBeDefined();
    expect(typeof status?.historyReportPending).toBe("boolean");
  });
});
