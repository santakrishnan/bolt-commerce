import { describe, expect, it, vi } from "vitest";

describe("vin-data branching behavior", () => {
  const HIGHLANDER_VIN = "5TDFZRBH5RS100015";

  it("handles highlander with single image string and hyphenated values", async () => {
    vi.resetModules();
    vi.doMock("@features/search/lib/mock-vehicles", () => ({
      mockVehicles: [
        {
          id: 999,
          vin: HIGHLANDER_VIN,
          year: 2024,
          make: "toy-ota",
          model: "high-lander",
          variant: "x-se",
          price: 12_345,
          oldPrice: undefined,
          labels: [],
          odometer: "1,234mi",
          extColorName: "Blueprint",
          intColorName: "Black",
          image: "/images/single.png",
        },
      ],
    }));

    const mod = await import("../vin-data");
    const vehicle = mod.vehiclesByVin[HIGHLANDER_VIN];
    expect(vehicle).toBeDefined();
    expect(vehicle?.make).toBe("Toy Ota");
    expect(vehicle?.model).toBe("High Lander");
    expect(vehicle?.trim).toBe("X Se");
    expect(Array.isArray(vehicle?.images)).toBe(true);
    expect(vehicle?.images[0]).toBe("/images/single.png");
  });

  it("throws when highlander search vehicle is missing", async () => {
    vi.resetModules();
    vi.doMock("@features/search/lib/mock-vehicles", () => ({ mockVehicles: [] }));

    await expect(import("../vin-data")).rejects.toThrow(
      "Expected Highlander search mock vehicle to exist"
    );
  });
});
