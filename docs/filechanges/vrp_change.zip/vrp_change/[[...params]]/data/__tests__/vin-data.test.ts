import { describe, expect, it } from "vitest";
import * as vinData from "../vin-data";

describe("vin-data module", () => {
  const sampleVin = "JTDEPMAE5PJ100001";

  it("exports vehiclesByVin and contains expected vehicle for sample VIN", () => {
    const vehicle = vinData.vehiclesByVin[sampleVin];
    expect(vehicle).toBeDefined();
    expect(vehicle?.id).toBe("1");
    expect(typeof vehicle?.make).toBe("string");
    expect(typeof vehicle?.model).toBe("string");
  });

  it("exports pricingByVin and has numeric fields for sample VIN", () => {
    const pricing = vinData.pricingByVin[sampleVin];
    expect(pricing).toBeDefined();
    expect(typeof pricing?.avgPrice).toBe("number");
    expect(typeof pricing?.currentPrice).toBe("number");
  });

  it("exports priceHistoryByVin and historyDataByVin and they contain expected shapes", () => {
    const history = vinData.priceHistoryByVin[sampleVin];
    expect(Array.isArray(history)).toBe(true);
    if (history && history.length > 0) {
      const first = history[0];
      if (!first) {
        throw new Error("First history entry not found");
      }
      expect(typeof first.date).toBe("string");
      expect(typeof first.price).toBe("number");
    }

    const histData = vinData.historyDataByVin[sampleVin];
    expect(histData).toBeDefined();
    if (histData) {
      expect(typeof histData.previousOwners).toBe("number");
    }
  });
});
