import type { VehicleDetail } from "./types";

/** Maps a VehicleDetail into the shape expected by VehicleActionIcons. */
export function toPreviewData(vehicle: VehicleDetail) {
  return {
    title: vehicle.title,
    year: vehicle.year,
    make: vehicle.make,
    model: vehicle.model,
    price: vehicle.price,
    originalPrice: vehicle.originalPrice ?? undefined,
    condition: vehicle.condition,
    warranty: vehicle.warranty,
    inspected: vehicle.inspected,
    miles: vehicle.miles,
    drivetrain: vehicle.drivetrain,
    mpg: vehicle.mpg,
    stock: vehicle.stock,
    vin: vehicle.vin,
    exterior: vehicle.exteriorColor,
    interior: vehicle.interiorColor,
    dealer: vehicle.dealer.name,
    location: vehicle.dealer.location,
    distance: vehicle.dealer.distance,
    images: vehicle.images,
    features: vehicle.highlights,
  } as const;
}
