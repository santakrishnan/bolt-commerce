import type { DealerNotes } from "@shared/data/dealer/dealer-data";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { getDealerDetailsFromApi, getVehicleBundleFromApi, type VehicleBundle } from "../vdp-api";

global.fetch = vi.fn();

describe("VDP API Service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("getVehicleBundleFromApi", () => {
    it("should fetch vehicle bundle successfully", async () => {
      const mockBundle: VehicleBundle = {
        dealerInfo: {
          id: "dealer-001",
          name: "Toyota Dealership",
          address: "New York, NY",
        } as any,
        vehicleData: {
          id: "vehicle123",
          title: "2023 Toyota Camry",
          price: 25_000,
          year: 2023,
          make: "Toyota",
          model: "Camry",
          trim: "LE",
          vin: "12345ABCDE",
          stock: "STK123",
          condition: "Used",
          miles: "50,000",
          exteriorColor: "Blue",
          interiorColor: "Black",
          drivetrain: "FWD",
          mpg: "28/38",
          images: ["https://example.com/image1.jpg"],
          highlights: ["Clean title", "One owner"],
          dealer: {
            dealerId: "dealer-001",
            name: "Toyota Dealership",
            location: "New York, NY",
            distance: "5 miles",
          },
          originalPrice: 28_000,
          inspected: true,
          warranty: true,
        } as any,
        vinData: {
          vin: "12345ABCDE",
          year: 2023,
          make: "Toyota",
          model: "Camry",
          body: "Sedan",
          transmission: "Automatic",
          fuelType: "Gasoline",
          engine: "2.5L I4",
        } as any,
      };

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockBundle }),
      } as Response);

      const result = await getVehicleBundleFromApi("vehicle123");

      expect((result as any).vehicleData?.id).toBe("vehicle123");
      expect((result as any).vehicleData?.title).toBe("2023 Toyota Camry");
      expect((result as any).vinData?.vin).toBe("12345ABCDE");
      expect(global.fetch).toHaveBeenCalled();
    });

    it("should include credentials in request", async () => {
      const mockBundle: VehicleBundle = {
        dealerInfo: {} as any,
        vehicleData: {} as any,
        vinData: {} as any,
      };

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockBundle }),
      } as Response);

      await getVehicleBundleFromApi("vehicle123");

      const call = vi.mocked(global.fetch).mock.calls[0];
      expect(call?.[1]).toMatchObject({
        credentials: "include",
        method: "GET",
      });
    });

    it("should set correct content-type header", async () => {
      const mockBundle: VehicleBundle = {
        dealerInfo: {} as any,
        vehicleData: {} as any,
        vinData: {} as any,
      };

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockBundle }),
      } as Response);

      await getVehicleBundleFromApi("vehicle123");

      const call = vi.mocked(global.fetch).mock.calls[0];
      expect(call?.[1]?.headers).toMatchObject({
        "Content-Type": "application/json",
      });
    });

    it("should accept custom headers", async () => {
      const mockBundle: VehicleBundle = {
        dealerInfo: {} as any,
        vehicleData: {} as any,
        vinData: {} as any,
      };

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockBundle }),
      } as Response);

      const customHeaders = { "X-Custom-Header": "custom-value" };

      await getVehicleBundleFromApi("vehicle123", { headers: customHeaders });

      const call = vi.mocked(global.fetch).mock.calls[0];
      expect(call?.[1]?.headers).toMatchObject(customHeaders);
    });

    it("should use custom base URL when provided", async () => {
      const mockBundle: VehicleBundle = {
        dealerInfo: {} as any,
        vehicleData: {} as any,
        vinData: {} as any,
      };

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockBundle }),
      } as Response);

      const baseUrl = "https://custom-api.com";

      await getVehicleBundleFromApi("vehicle123", { baseUrl });

      const call = vi.mocked(global.fetch).mock.calls[0];
      expect((call?.[0] as string) ?? "").toContain(baseUrl);
    });

    it("should throw error on unsuccessful response", async () => {
      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: false,
        status: 404,
        json: async () => ({ error: "Vehicle not found" }),
      } as Response);

      await expect(getVehicleBundleFromApi("invalid-id")).rejects.toThrow("Vehicle not found");
    });

    it("should handle response without error property", async () => {
      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: false,
        status: 500,
        json: async () => ({}),
      } as Response);

      await expect(getVehicleBundleFromApi("vehicle123")).rejects.toThrow("Request failed: 500");
    });

    it("should handle JSON parse errors gracefully", async () => {
      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: false,
        status: 500,
        json: () => Promise.reject(new Error("Invalid JSON")),
      } as unknown as Response);

      await expect(getVehicleBundleFromApi("vehicle123")).rejects.toThrow("Request failed: 500");
    });

    it("should handle empty vehicle ID", async () => {
      const mockBundle: VehicleBundle = {
        dealerInfo: {} as any,
        vehicleData: {} as any,
        vinData: {} as any,
      };

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockBundle }),
      } as Response);

      const result = await getVehicleBundleFromApi("");

      expect(result).toBeDefined();
    });
  });

  describe("getDealerDetailsFromApi", () => {
    it("should fetch dealer details successfully", async () => {
      const mockDealerNotes: DealerNotes = {
        vin: "12345ABCDE",
        dealerName: "Smith Motors",
        notes: "Well maintained, single owner",
        certified: true,
        certified_preowned: true,
      } as any;

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockDealerNotes }),
      } as Response);

      const result = await getDealerDetailsFromApi("12345ABCDE");

      expect((result as any)?.vin).toBe("12345ABCDE");
      expect((result as any)?.dealerName).toBe("Smith Motors");
      expect((result as any)?.notes).toBe("Well maintained, single owner");
      expect(global.fetch).toHaveBeenCalled();
    });

    it("should include credentials in dealer details request", async () => {
      const mockDealerNotes: DealerNotes = {} as any;

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockDealerNotes }),
      } as Response);

      await getDealerDetailsFromApi("12345ABCDE");

      const call = vi.mocked(global.fetch).mock.calls[0];
      expect(call?.[1]).toMatchObject({
        credentials: "include",
        method: "GET",
      });
    });

    it("should accept custom headers for dealer details", async () => {
      const mockDealerNotes: DealerNotes = {} as any;

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockDealerNotes }),
      } as Response);

      const customHeaders = { Authorization: "Bearer token123" };

      await getDealerDetailsFromApi("12345ABCDE", { headers: customHeaders });

      const call = vi.mocked(global.fetch).mock.calls[0];
      expect(call?.[1]?.headers).toMatchObject(customHeaders);
    });

    it("should use custom base URL for dealer details", async () => {
      const mockDealerNotes: DealerNotes = {} as any;

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockDealerNotes }),
      } as Response);

      const baseUrl = "https://dealer-api.com";

      await getDealerDetailsFromApi("12345ABCDE", { baseUrl });

      const call = vi.mocked(global.fetch).mock.calls[0];
      expect((call?.[0] as string) ?? "").toContain(baseUrl);
    });

    it("should throw error when dealer details not found", async () => {
      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: false,
        status: 404,
        json: async () => ({ error: "Dealer not found" }),
      } as Response);

      await expect(getDealerDetailsFromApi("invalid-vin")).rejects.toThrow("Dealer not found");
    });

    it("should handle multiple dealer detail requests", async () => {
      const vins = ["VIN001", "VIN002", "VIN003"];
      const mockDealerNotes: DealerNotes = {} as any;

      vi.mocked(global.fetch).mockResolvedValue({
        ok: true,
        json: async () => ({ data: mockDealerNotes }),
      } as Response);

      for (const vin of vins) {
        await getDealerDetailsFromApi(vin);
      }

      expect(global.fetch).toHaveBeenCalledTimes(3);
    });

    it("should handle empty VIN", async () => {
      const mockDealerNotes: DealerNotes = {} as any;

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockDealerNotes }),
      } as Response);

      const result = await getDealerDetailsFromApi("");

      expect(result).toBeDefined();
    });
  });

  describe("Error handling", () => {
    it("should handle network errors", async () => {
      vi.mocked(global.fetch).mockRejectedValueOnce(new Error("Network error"));

      await expect(getVehicleBundleFromApi("vehicle123")).rejects.toThrow("Network error");
    });

    it("should handle timeout errors", async () => {
      vi.mocked(global.fetch).mockRejectedValueOnce(new Error("Request timeout"));

      await expect(getDealerDetailsFromApi("12345ABCDE")).rejects.toThrow("Request timeout");
    });

    it("should handle malformed response data", async () => {
      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: null }),
      } as Response);

      const result = await getVehicleBundleFromApi("vehicle123");

      expect(result).toBeNull();
    });
  });

  describe("URL building", () => {
    it("should build URL without base URL", async () => {
      const mockBundle: VehicleBundle = {
        dealerInfo: {} as any,
        vehicleData: {} as any,
        vinData: {} as any,
      };

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockBundle }),
      } as Response);

      await getVehicleBundleFromApi("vehicle123");

      const call = vi.mocked(global.fetch).mock.calls[0];
      expect(typeof call?.[0]).toBe("string");
    });

    it("should build URL with base URL", async () => {
      const mockBundle: VehicleBundle = {
        dealerInfo: {} as any,
        vehicleData: {} as any,
        vinData: {} as any,
      };

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockBundle }),
      } as Response);

      const baseUrl = "https://api.example.com";
      await getVehicleBundleFromApi("vehicle123", { baseUrl });

      const call = vi.mocked(global.fetch).mock.calls[0];
      expect((call?.[0] as string) ?? "").toContain(baseUrl);
    });

    it("should handle base URL with trailing slash", async () => {
      const mockBundle: VehicleBundle = {
        dealerInfo: {} as any,
        vehicleData: {} as any,
        vinData: {} as any,
      };

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockBundle }),
      } as Response);

      const baseUrl = "https://api.example.com/";
      await getVehicleBundleFromApi("vehicle123", { baseUrl });

      expect(global.fetch).toHaveBeenCalled();
    });
  });

  describe("Request options", () => {
    it("should merge headers correctly", async () => {
      const mockBundle: VehicleBundle = {
        dealerInfo: {} as any,
        vehicleData: {} as any,
        vinData: {} as any,
      };

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockBundle }),
      } as Response);

      const customHeaders = {
        "X-Custom": "value",
        "X-Another": "header",
      };

      await getVehicleBundleFromApi("vehicle123", { headers: customHeaders });

      const call = vi.mocked(global.fetch).mock.calls[0];
      expect(call?.[1]?.headers).toMatchObject({
        "Content-Type": "application/json",
        ...customHeaders,
      });
    });

    it("should preserve method as GET", async () => {
      const mockBundle: VehicleBundle = {
        dealerInfo: {} as any,
        vehicleData: {} as any,
        vinData: {} as any,
      };

      vi.mocked(global.fetch).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: mockBundle }),
      } as Response);

      await getVehicleBundleFromApi("vehicle123");

      const call = vi.mocked(global.fetch).mock.calls[0];
      expect(call?.[1]?.method).toBe("GET");
    });
  });
});
