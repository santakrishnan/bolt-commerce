/**
 * Dealer service — fetches dealer details by dealer ID or VIN.
 *
 * Supports dual lookup for flexibility: the VDP page uses byId (from
 * vinData.vehicle.dealer.dealerId), while the dealer API route can
 * use byVin when only the VIN is available.
 *
 * Currently backed by mock data; will call a separate backend dealer
 * API when available.
 */

import {
  ArrowServerError,
  type ArrowServerIds,
  createArrowServerClient,
} from "@features/tracking/lib/server-api";
import type { DealerInfo } from "@shared/data/dealer/dealer-data";
import { cacheLife, cacheTag } from "next/cache";
import { fetchMockDealerById, fetchMockDealerByVin } from "./vdp.mocks";

export interface DealerFetchOptions {
  forwardHeaders?: Record<string, string>;
  ids?: ArrowServerIds;
}

let _client: ReturnType<typeof createArrowServerClient> | null = null;

function getDealerClient() {
  if (!_client) {
    _client = createArrowServerClient({
      baseUrl: process.env.VDP_SERVICE_URL ?? "",
      authToken: process.env.VDP_API_KEY,
      serviceName: "DealerService",
      timeout: 10_000,
      retries: 1,
    });
  }
  return _client;
}

function isMockMode(): boolean {
  return !process.env.VDP_SERVICE_URL || process.env.USE_MOCK_VDP === "true";
}

// ---------------------------------------------------------------------------
// Cached — page-level (no per-user headers)
// ---------------------------------------------------------------------------

/** Fetch dealer by dealer ID — primary lookup. */
export async function fetchDealerByIdCached(dealerId: string): Promise<DealerInfo> {
  "use cache";
  cacheLife("vdp");
  cacheTag("vdp", `dealer-${dealerId}`);

  if (isMockMode()) {
    return await fetchMockDealerById(dealerId);
  }

  try {
    return await getDealerClient().get<DealerInfo>(`/vdp/dealers/${dealerId}`);
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[DealerService] Upstream error (dealer-by-id):", error.message);
    } else {
      console.error("[DealerService] Unexpected error (dealer-by-id):", error);
    }
    return await fetchMockDealerById(dealerId);
  }
}

/** Fetch dealer by VIN — convenience when only VIN is available. */
export async function fetchDealerByVinCached(vin: string): Promise<DealerInfo> {
  "use cache";
  cacheLife("vdp");
  cacheTag("vdp", `dealer-vin-${vin}`);

  if (isMockMode()) {
    return await fetchMockDealerByVin(vin);
  }

  try {
    return await getDealerClient().get<DealerInfo>(`/vdp/dealers?vin=${encodeURIComponent(vin)}`);
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[DealerService] Upstream error (dealer-by-vin):", error.message);
    } else {
      console.error("[DealerService] Unexpected error (dealer-by-vin):", error);
    }
    return await fetchMockDealerByVin(vin);
  }
}

// ---------------------------------------------------------------------------
// Uncached — API route handlers (forward per-user tracking headers)
// ---------------------------------------------------------------------------

/** Uncached dealer fetch by ID — for API route handlers. */
export async function fetchDealerById(
  dealerId: string,
  options: DealerFetchOptions = {}
): Promise<DealerInfo> {
  if (isMockMode()) {
    return await fetchMockDealerById(dealerId);
  }

  try {
    return await getDealerClient().get<DealerInfo>(`/vdp/dealers/${dealerId}`, {
      ids: options.ids,
      headers: options.forwardHeaders,
    });
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[DealerService] Upstream error (dealer-by-id):", error.message);
    } else {
      console.error("[DealerService] Unexpected error (dealer-by-id):", error);
    }
    return await fetchMockDealerById(dealerId);
  }
}

/** Uncached dealer fetch by VIN — for API route handlers. */
export async function fetchDealerByVin(
  vin: string,
  options: DealerFetchOptions = {}
): Promise<DealerInfo> {
  if (isMockMode()) {
    return await fetchMockDealerByVin(vin);
  }

  try {
    return await getDealerClient().get<DealerInfo>(`/vdp/dealers?vin=${encodeURIComponent(vin)}`, {
      ids: options.ids,
      headers: options.forwardHeaders,
    });
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[DealerService] Upstream error (dealer-by-vin):", error.message);
    } else {
      console.error("[DealerService] Unexpected error (dealer-by-vin):", error);
    }
    return await fetchMockDealerByVin(vin);
  }
}
