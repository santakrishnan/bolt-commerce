/** Cache-optimized VDP data functions for direct page-level use. Composes VIN-only cached service functions, sharing entries across all users. */

import { cacheLife, cacheTag } from "next/cache";
import { fetchDealerByIdCached } from "./dealer.service";
import { fetchVehicleDataCached, fetchVinDataCached } from "./vdp.service";
import type { VehicleBundle } from "./vdp-api";

/** Cached per VIN — fetches vinData, then vehicleData + dealerInfo in parallel. */
export async function getVehicleBundleCached(vin: string): Promise<VehicleBundle> {
  "use cache";
  cacheLife("vdp");
  cacheTag("vdp", `bundle-${vin}`);

  const vinData = await fetchVinDataCached(vin);
  const [vehicleData, dealerInfo] = await Promise.all([
    fetchVehicleDataCached(vinData.vehicle.id),
    fetchDealerByIdCached(vinData.vehicle.dealer.dealerId),
  ]);
  return { vinData, vehicleData, dealerInfo };
}
