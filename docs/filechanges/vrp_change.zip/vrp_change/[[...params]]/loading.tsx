import { VdpSkeleton } from "@features/vdp/components/vdp-skeleton";

export default function UsedCarsLoading() {
  return <VdpSkeleton />;
}
