/**
 * Search feature constants — single source of truth.
 * Import from here instead of hard-coding values across files.
 */

/** Number of vehicle cards per page on the search results page. */
export const SEARCH_PAGE_SIZE = 12;
