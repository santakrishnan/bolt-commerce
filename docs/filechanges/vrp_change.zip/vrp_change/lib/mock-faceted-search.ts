import type {
  AvailableFilters,
  FilterState,
} from "@features/search/components/filter-sidebar/types";
import { SEARCH_PAGE_SIZE } from "@features/search/lib/constants";
import { filterSections } from "@features/search/lib/filter-sections";
import {
  computeAvailableFiltersSync,
  type FacetCounts,
  mockSearchVehicles,
  type RefineFilter,
  type SortOption,
} from "@features/search/lib/mock-search-service";
import { mockVehicles, type Vehicle } from "@features/search/lib/mock-vehicles";

export type FacetSection =
  | "Price"
  | "Year"
  | "Mileage"
  | "Body Style"
  | "Exterior Color"
  | "Interior Color"
  | "Make & Model"
  | "Fuel Type"
  | "Features & Technology"
  | "Inspection"
  | "Drivetrain"
  | "Transmission";

export const ALL_FACET_SECTIONS: FacetSection[] = [
  "Price",
  "Year",
  "Mileage",
  "Body Style",
  "Exterior Color",
  "Interior Color",
  "Make & Model",
  "Fuel Type",
  "Features & Technology",
  "Inspection",
  "Drivetrain",
  "Transmission",
];

const FACET_VERSION = "mock-faceted-search-v1";
const INVENTORY_MIN = 50;
const INVENTORY_MAX = 100;

const COLOR_HEX_MAP: Record<string, string> = {
  White: "#f4f4f4",
  Black: "#151515",
  "Midnight Gray": "#5a5f66",
  "Midnight Grey": "#5a5f66",
  "Metallic Green": "#2d7b5a",
  "Deep Red": "#8b1f2a",
  Graphite: "#50555b",
  "Luminous Yellow": "#d7c33e",
  "Ocean Blue": "#2568a8",
  "Electric Blue": "#2e74ff",
};

const DEALER_NAMES = [
  "Toyota of Frisco",
  "Northside Toyota",
  "Toyota Downtown",
  "Sunrise Toyota",
  "Heritage Toyota",
  "West End Toyota",
];

export interface FacetPatch {
  availableFiltersPatch: Partial<AvailableFilters>;
  facetCountsPatch: Partial<FacetCounts>;
  updatedSections: FacetSection[];
}

export interface MockFacetedSearchRequest {
  filterState: FilterState;
  /** Set false for pagination/sort-only updates where facets do not need refreshing. */
  includeFacets?: boolean;
  labelFilter?: string;
  page?: number;
  pageSize?: number;
  refineFilters?: RefineFilter[];
  /** Correlation ID for this search session. Reused across pagination/sort/filter changes. */
  searchId?: string;
  searchQuery?: string;
  sortOption?: SortOption;
  /** Sections that changed in the UI; used to return partial facet patches. */
  updatedSections?: FacetSection[];
}

export interface MockFacetedSearchResponse {
  facets: FacetPatch;
  metadata: {
    queryTimeMs: number;
    version: string;
    latencyMs: number;
    inventorySize: number;
    searchId: string;
  };
  pagination: {
    page: number;
    pageSize: number;
    totalResults: number;
    totalPages: number;
  };
  totalCount: number;
  vehicles: Vehicle[];
}

// ── Filter-only API types ─────────────────────────────────────────────

export interface MockFilterSearchRequest {
  filterId?: string;
  filterState: FilterState;
  labelFilter?: string;
  refineFilters?: RefineFilter[];
  searchId?: string;
  searchQuery?: string;
  updatedSections?: FacetSection[];
}

export interface MockFilterSearchResponse {
  facets: FacetPatch;
  filterId: string;
  metadata: {
    queryTimeMs: number;
    inventorySize: number;
  };
  searchId: string;
}

function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n));
}

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomPick<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)] as T;
}

/** Fisher-Yates shuffle — returns a new randomly-ordered copy. */
function shuffle<T>(arr: readonly T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = copy[i];
    copy[i] = copy[j] as T;
    copy[j] = tmp as T;
  }
  return copy;
}

function toModelLabel(modelSlug: string): string {
  return modelSlug
    .split("-")
    .map((chunk) =>
      chunk.length <= 3 ? chunk.toUpperCase() : chunk[0]?.toUpperCase() + chunk.slice(1)
    )
    .join(" ");
}

function toFuelKey(label: string): string {
  return label.split("(")[0]?.trim() ?? label;
}

function createInventoryVariant(seed: Vehicle, index: number): Vehicle {
  const extColors = filterSections.exteriorColors;
  const intColors = filterSections.interiorColors;

  const year = clamp(seed.year + randomInt(-2, 2), 2015, 2025);
  const priceDelta = randomInt(-4500, 6000) + (year - seed.year) * 850;
  const price = clamp(seed.price + priceDelta, 5000, 70_000);

  const mileage = clamp(
    seed.mileage + randomInt(-25_000, 32_000) - (year - seed.year) * 5500,
    0,
    140_000
  );

  const extColorName = Math.random() < 0.65 ? seed.extColorName : randomPick(extColors);
  const intColorName = Math.random() < 0.65 ? seed.intColorName : randomPick(intColors);

  const dealer = randomPick(DEALER_NAMES);
  const distance = randomInt(3, 125);

  const labels = [...seed.labels];
  if (price <= 22_000 && !labels.includes("Excellent Price")) {
    labels.push("Excellent Price");
  }
  if (Math.random() < 0.2 && !labels.includes("Price Drop")) {
    labels.push("Price Drop");
  }

  return {
    ...seed,
    id: index + 1,
    year,
    price,
    mileage,
    odometer: `${mileage.toLocaleString()} mi`,
    miles: `${dealer} - ${distance} miles`,
    // Keep original VIN so VDP mock service can resolve details by VIN.
    vin: seed.vin,
    title: `${year} Toyota ${toModelLabel(seed.model)} ${toModelLabel(seed.variant)}`,
    match: clamp(seed.match + randomInt(-8, 9), 70, 99),
    labels,
    extColorName,
    intColorName,
    extColorCode: COLOR_HEX_MAP[extColorName] ?? seed.extColorCode,
    intColorCode: COLOR_HEX_MAP[intColorName] ?? seed.intColorCode,
  };
}

function ensureMinimumCoverage(
  pool: Vehicle[],
  seeds: Vehicle[],
  selector: (v: Vehicle) => string,
  values: string[],
  minPerValue: number,
  maxPoolSize: number,
  /** Property key to override when creating a synthetic seed for a missing value. */
  overrideKey?: keyof Vehicle
): Vehicle[] {
  const next = [...pool];
  const countByValue = new Map<string, number>();
  for (const vehicle of next) {
    const key = selector(vehicle);
    countByValue.set(key, (countByValue.get(key) ?? 0) + 1);
  }

  for (const value of values) {
    let eligible = seeds.filter((vehicle) => selector(vehicle) === value);

    // No seed exists for this value — create a synthetic seed by cloning a
    // random existing seed and overriding the target property.  This ensures
    // every value in the canonical filter list produces inventory.
    if (eligible.length === 0 && overrideKey && seeds.length > 0) {
      const synthetic = { ...randomPick(seeds), [overrideKey]: value } as Vehicle;
      eligible = [synthetic];
    }

    if (eligible.length === 0) {
      continue;
    }

    while ((countByValue.get(value) ?? 0) < minPerValue && next.length < maxPoolSize) {
      const seed = randomPick(eligible);
      const appended = createInventoryVariant(seed, next.length);
      next.push(appended);
      countByValue.set(value, (countByValue.get(value) ?? 0) + 1);
    }
  }

  return next;
}

function buildInventoryPool(): Vehicle[] {
  const minPool = INVENTORY_MIN;
  const maxPool = INVENTORY_MAX;
  const target = randomInt(minPool, maxPool);

  const shuffledSeeds = shuffle(mockVehicles);
  const pool: Vehicle[] = [];

  // Seed from the whole catalog first to improve baseline facet diversity.
  for (let idx = 0; idx < shuffledSeeds.length && pool.length < target; idx++) {
    pool.push(createInventoryVariant(shuffledSeeds[idx] as Vehicle, pool.length));
  }

  while (pool.length < target) {
    pool.push(createInventoryVariant(randomPick(shuffledSeeds), pool.length));
  }

  let covered = ensureMinimumCoverage(
    pool,
    shuffledSeeds,
    (v) => v.bodyType,
    filterSections.bodyStyle,
    2,
    maxPool,
    "bodyType"
  );

  covered = ensureMinimumCoverage(
    covered,
    shuffledSeeds,
    (v) => v.drivetrain,
    filterSections.drivetrains,
    2,
    maxPool,
    "drivetrain"
  );

  covered = ensureMinimumCoverage(
    covered,
    shuffledSeeds,
    (v) => v.transmission,
    filterSections.transmissions,
    2,
    maxPool,
    "transmission"
  );

  covered = ensureMinimumCoverage(
    covered,
    shuffledSeeds,
    (v) => v.fuelType,
    filterSections.fuelTypes.map(toFuelKey),
    2,
    maxPool,
    "fuelType"
  );

  if (covered.length > maxPool) {
    covered = covered.slice(0, maxPool);
  }

  if (covered.length < minPool) {
    while (covered.length < minPool) {
      covered.push(createInventoryVariant(randomPick(shuffledSeeds), covered.length));
    }
  }

  return covered;
}

const inventoryPool = buildInventoryPool();
const inventorySize = inventoryPool.length;

/** Expose the generated inventory pool for use by other services (e.g. autosuggest). */
export function getInventoryPool(): Vehicle[] {
  return inventoryPool;
}

function sectionSet(sections?: FacetSection[]): Set<FacetSection> {
  if (!sections || sections.length === 0) {
    return new Set(ALL_FACET_SECTIONS);
  }
  return new Set(sections);
}

export function buildFacetPatch(
  availableFilters: AvailableFilters,
  facetCounts: FacetCounts,
  updatedSections: FacetSection[]
): FacetPatch {
  const selected = sectionSet(updatedSections);
  const availableFiltersPatch: Partial<AvailableFilters> = {};
  const facetCountsPatch: Partial<FacetCounts> = {};

  if (selected.has("Body Style")) {
    availableFiltersPatch.bodyStyles = availableFilters.bodyStyles;
    facetCountsPatch.bodyType = facetCounts.bodyType;
  }
  if (selected.has("Exterior Color")) {
    availableFiltersPatch.exteriorColors = availableFilters.exteriorColors;
    facetCountsPatch.exteriorColor = facetCounts.exteriorColor;
  }
  if (selected.has("Interior Color")) {
    availableFiltersPatch.interiorColors = availableFilters.interiorColors;
    facetCountsPatch.interiorColor = facetCounts.interiorColor;
  }
  if (selected.has("Fuel Type")) {
    availableFiltersPatch.fuelTypes = availableFilters.fuelTypes;
    facetCountsPatch.fuelType = facetCounts.fuelType;
  }
  if (selected.has("Make & Model")) {
    availableFiltersPatch.models = availableFilters.models;
  }
  if (selected.has("Features & Technology")) {
    availableFiltersPatch.safetyFeatures = availableFilters.safetyFeatures;
    availableFiltersPatch.comfortFeatures = availableFilters.comfortFeatures;
    availableFiltersPatch.techFeatures = availableFilters.techFeatures;
    availableFiltersPatch.exteriorFeatures = availableFilters.exteriorFeatures;
    availableFiltersPatch.performanceFeatures = availableFilters.performanceFeatures;
    availableFiltersPatch.seatingCapacity = availableFilters.seatingCapacity;
  }
  if (selected.has("Inspection")) {
    availableFiltersPatch.hasInspection160 = availableFilters.hasInspection160;
  }
  if (selected.has("Drivetrain")) {
    availableFiltersPatch.drivetrains = availableFilters.drivetrains;
    facetCountsPatch.drivetrain = facetCounts.drivetrain;
  }
  if (selected.has("Transmission")) {
    availableFiltersPatch.transmissions = availableFilters.transmissions;
    facetCountsPatch.transmission = facetCounts.transmission;
  }
  if (selected.has("Price")) {
    facetCountsPatch.priceRange = facetCounts.priceRange;
  }
  if (selected.has("Year")) {
    facetCountsPatch.yearRange = facetCounts.yearRange;
  }
  if (selected.has("Mileage")) {
    facetCountsPatch.mileageRange = facetCounts.mileageRange;
  }

  availableFiltersPatch.totalCount = Math.min(availableFilters.totalCount, inventorySize);

  return {
    availableFiltersPatch,
    facetCountsPatch,
    updatedSections,
  };
}

export async function runMockFacetedSearch(
  req: MockFacetedSearchRequest
): Promise<MockFacetedSearchResponse> {
  const startedAt = Date.now();
  const searchId = req.searchId || crypto.randomUUID();

  const page = req.page ?? 1;
  const pageSize = req.pageSize ?? SEARCH_PAGE_SIZE;

  const searchResult = await mockSearchVehicles({
    filterState: req.filterState,
    searchQuery: req.searchQuery ?? "",
    labelFilter: req.labelFilter ?? "",
    refineFilters: req.refineFilters,
    vehicles: inventoryPool,
    sortOption: req.sortOption ?? "recommended",
    page,
    pageSize,
  });

  const includeFacets = req.includeFacets ?? true;
  const updatedSections = includeFacets ? (req.updatedSections ?? ALL_FACET_SECTIONS) : [];

  let facets: FacetPatch = {
    availableFiltersPatch: {},
    facetCountsPatch: {},
    updatedSections: [],
  };

  if (includeFacets) {
    const disjunctive = computeAvailableFiltersSync(inventoryPool, req.filterState, {
      searchQuery: req.searchQuery ?? "",
      labelFilter: req.labelFilter ?? "",
      refineFilters: req.refineFilters,
    });

    facets = buildFacetPatch(
      disjunctive.availableFilters,
      disjunctive.facetCounts,
      updatedSections
    );
  }

  const queryTimeMs = Date.now() - startedAt;
  const boundedTotalCount = Math.min(searchResult.totalCount, inventorySize);
  facets.availableFiltersPatch.totalCount = Math.min(
    facets.availableFiltersPatch.totalCount ?? boundedTotalCount,
    boundedTotalCount
  );

  return {
    vehicles: searchResult.vehicles,
    totalCount: boundedTotalCount,
    pagination: {
      page,
      pageSize,
      totalResults: boundedTotalCount,
      totalPages: Math.ceil(boundedTotalCount / pageSize),
    },
    facets,
    metadata: {
      queryTimeMs,
      version: FACET_VERSION,
      latencyMs: 0,
      inventorySize,
      searchId,
    },
  };
}

// ── Filter-only search (separate from vehicle search) ─────────────────

export function runMockFilterSearch(req: MockFilterSearchRequest): MockFilterSearchResponse {
  const startedAt = Date.now();
  const searchId = req.searchId || crypto.randomUUID();
  const filterId = req.filterId || crypto.randomUUID();

  const updatedSections = req.updatedSections ?? ALL_FACET_SECTIONS;

  const disjunctive = computeAvailableFiltersSync(inventoryPool, req.filterState, {
    searchQuery: req.searchQuery ?? "",
    labelFilter: req.labelFilter ?? "",
    refineFilters: req.refineFilters,
  });

  const facets = buildFacetPatch(
    disjunctive.availableFilters,
    disjunctive.facetCounts,
    updatedSections
  );

  facets.availableFiltersPatch.totalCount = Math.min(
    facets.availableFiltersPatch.totalCount ?? inventorySize,
    inventorySize
  );

  return {
    filterId,
    searchId,
    facets,
    metadata: {
      queryTimeMs: Date.now() - startedAt,
      inventorySize,
    },
  };
}
