/** Maps a Vehicle object to CarCard component props. */

import { getVehicleFinancing } from "@features/search/lib/mock-financing-service";
import type { Vehicle } from "@features/search/lib/mock-vehicles";

/** Flatten the structured VehicleFeatures object into a single string array. */
function flattenFeatures(features: Vehicle["features"]): string[] {
  return [
    ...features.safety,
    ...features.tech,
    ...features.comfort,
    ...features.exterior,
    ...features.performance,
  ];
}

export function vehicleToCarCardProps(vehicle: Vehicle) {
  const parts = vehicle.miles.split(" - ");
  const distance = parts[1] ?? "";

  let badge: { type: "excellent" | "priceDrop"; text: string } | undefined;
  if (vehicle.labels.includes("Excellent Price")) {
    badge = { type: "excellent", text: "Excellent Price" };
  } else if (vehicle.labels.includes("Price Drop")) {
    badge = { type: "priceDrop", text: "Price Drop" };
  }

  const condition = vehicle.labels[0] ?? "Fair Price";

  const financing = getVehicleFinancing(vehicle);
  const estimation = {
    creditScore: financing.creditScore,
    apr: financing.apr,
    termLength: `${financing.termMonths} months`,
    estimatedMonthlyPayment: financing.estimatedMonthlyPayment,
  };

  return {
    carImage: vehicle.image,
    carName: vehicle.title,
    condition,
    dealerLocation: vehicle.dealerLocation,
    dealerName: vehicle.dealerName,
    distance,
    drivetrain: vehicle.drivetrain,
    make: vehicle.make,
    model: vehicle.model,
    mpg: vehicle.mpg,
    stock: vehicle.stock,
    variant: vehicle.variant,
    vehicleFeatures: flattenFeatures(vehicle.features),
    year: vehicle.year,
    vin: vehicle.vin,
    price: `$${vehicle.price.toLocaleString()}`,
    wasPrice: vehicle.oldPrice ? `$${vehicle.oldPrice.toLocaleString()}` : undefined,
    mileage: vehicle.odometer,
    estimatedPayment: `Est. ${financing.estimatedMonthlyPayment}/mo`,
    exteriorColor: vehicle.extColorName,
    exteriorColorHex: vehicle.extColorCode,
    interiorColor: vehicle.intColorName,
    interiorColorHex: vehicle.intColorCode,
    matchPercentage: vehicle.match > 0 ? String(vehicle.match) : undefined,
    badge,
    owners: vehicle.owners,
    estimation,
  };
}
