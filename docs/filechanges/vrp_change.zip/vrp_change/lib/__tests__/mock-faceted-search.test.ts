import { defaultFilterState } from "@features/search/components/filter-sidebar/types";
import { beforeEach, describe, expect, it, vi } from "vitest";

// Mock dependencies before importing the module under test to keep inventory
// generation deterministic and lightweight.
const seedVehicles = [
  {
    id: 101,
    vin: "VIN101",
    title: "2019 Toyota Camry L",
    year: 2019,
    price: 15_000,
    mileage: 30_000,
    odometer: "30,000 mi",
    miles: "Dealer - 10 miles",
    match: 90,
    labels: [] as string[],
    extColorName: "White",
    intColorName: "Black",
    extColorCode: "#fff",
    intColorCode: "#000",
    model: "camry",
    variant: "l",
    bodyType: "Sedan",
    drivetrain: "FWD",
    transmission: "Automatic",
    fuelType: "Gasoline (Gas)",
  },
  {
    id: 102,
    vin: "VIN102",
    title: "2020 Honda Civic LX",
    year: 2020,
    price: 14_000,
    mileage: 25_000,
    odometer: "25,000 mi",
    miles: "Dealer - 20 miles",
    match: 85,
    labels: [] as string[],
    extColorName: "Black",
    intColorName: "White",
    extColorCode: "#000",
    intColorCode: "#fff",
    model: "civic",
    variant: "lx",
    bodyType: "Sedan",
    drivetrain: "FWD",
    transmission: "CVT",
    fuelType: "Gasoline (Gas)",
  },
];

vi.mock("@features/search/lib/mock-vehicles", () => ({
  mockVehicles: seedVehicles,
}));

// Provide deterministic implementations for computeAvailableFiltersSync and mockSearchVehicles
vi.mock("@features/search/lib/mock-search-service", () => ({
  computeAvailableFiltersSync: (vehicles: any[], _filterState: any) => {
    return {
      availableFilters: {
        bodyStyles: ["Sedan"],
        exteriorColors: ["White", "Black"],
        interiorColors: ["Black", "White"],
        fuelTypes: ["Gasoline (Gas)"],
        models: ["camry", "civic"],
        safetyFeatures: [],
        comfortFeatures: [],
        techFeatures: [],
        exteriorFeatures: [],
        performanceFeatures: [],
        seatingCapacity: [],
        drivetrains: ["FWD"],
        transmissions: ["Automatic", "CVT"],
        hasInspection160: false,
        totalCount: vehicles.length,
      },
      facetCounts: {
        bodyType: { Sedan: vehicles.length },
        exteriorColor: { White: 1, Black: 1 },
        interiorColor: { Black: 1, White: 1 },
        fuelType: { "Gasoline (Gas)": vehicles.length },
        drivetrain: { FWD: vehicles.length },
        transmission: { Automatic: 1, CVT: 1 },
        priceRange: { "<20k": vehicles.length },
        yearRange: { "2019": 1, "2020": 1 },
        mileageRange: { "<50k": vehicles.length },
      },
    };
  },
  mockSearchVehicles: (_opts: any) => {
    return {
      vehicles: seedVehicles,
      totalCount: seedVehicles.length,
    };
  },
}));

beforeEach(() => {
  vi.resetModules();
  vi.restoreAllMocks();
  // deterministic crypto UUID
  vi.stubGlobal("crypto", { randomUUID: () => "uuid-123" } as any);
  // make random deterministic
  vi.spyOn(Math, "random").mockImplementation(() => 0.1);
});

describe("mock-faceted-search exports", () => {
  it("getInventoryPool returns an array of vehicles", async () => {
    const mod = await import("../mock-faceted-search");
    const pool = mod.getInventoryPool();
    expect(Array.isArray(pool)).toBe(true);
    expect(pool.length).toBeGreaterThan(0);
    expect(pool[0]).toHaveProperty("vin");
  });

  it("buildFacetPatch returns patches for requested sections and caps totalCount", async () => {
    const mod = await import("../mock-faceted-search");
    const { buildFacetPatch, getInventoryPool } = mod;

    const inventory = getInventoryPool();
    const availableFilters: any = {
      bodyStyles: ["Sedan"],
      exteriorColors: ["White"],
      interiorColors: ["Black"],
      fuelTypes: ["Gasoline (Gas)"],
      models: ["camry"],
      safetyFeatures: [],
      comfortFeatures: [],
      techFeatures: [],
      exteriorFeatures: [],
      performanceFeatures: [],
      seatingCapacity: [],
      drivetrains: ["FWD"],
      transmissions: ["Automatic"],
      hasInspection160: false,
      totalCount: inventory.length + 10, // intentionally larger
    };

    const facetCounts: any = {
      bodyType: { Sedan: inventory.length },
      exteriorColor: { White: inventory.length },
      interiorColor: { Black: inventory.length },
      fuelType: { "Gasoline (Gas)": inventory.length },
      drivetrain: { FWD: inventory.length },
      transmission: { Automatic: inventory.length },
      priceRange: { "<20k": inventory.length },
      yearRange: { "2019": 1 },
      mileageRange: { "<50k": inventory.length },
    };

    const updatedSections = ["Body Style", "Price"] as any;
    const patch = buildFacetPatch(availableFilters, facetCounts, updatedSections);

    expect(patch.updatedSections).toEqual(updatedSections);
    expect(patch.availableFiltersPatch.bodyStyles).toEqual(availableFilters.bodyStyles);
    expect(patch.facetCountsPatch.priceRange).toEqual(facetCounts.priceRange);
    // totalCount should be capped to inventory size
    expect(typeof patch.availableFiltersPatch.totalCount).toBe("number");
    expect(patch.availableFiltersPatch.totalCount).toBeLessThanOrEqual(inventory.length);
  });

  it("runMockFacetedSearch returns expected shape and respects includeFacets flag", async () => {
    const { runMockFacetedSearch } = await import("../mock-faceted-search");

    const res = await runMockFacetedSearch({
      filterState: defaultFilterState,
      includeFacets: true,
      page: 1,
      pageSize: 10,
    });
    expect(res).toHaveProperty("vehicles");
    expect(Array.isArray(res.vehicles)).toBe(true);
    expect(res).toHaveProperty("facets");
    expect(res.metadata.version).toBe("mock-faceted-search-v1");

    const resNoFacets = await runMockFacetedSearch({
      filterState: defaultFilterState,
      includeFacets: false,
    });
    expect(Array.isArray(resNoFacets.vehicles)).toBe(true);
    expect(Array.isArray(resNoFacets.facets.updatedSections)).toBe(true);
    expect(resNoFacets.facets.updatedSections.length).toBe(0);
  });

  it("runMockFilterSearch returns filterId and facets and sets metadata.inventorySize", async () => {
    const { runMockFilterSearch } = await import("../mock-faceted-search");

    const out = runMockFilterSearch({ filterState: defaultFilterState });
    expect(typeof out.filterId).toBe("string");
    expect(typeof out.searchId).toBe("string");
    expect(out.facets).toBeDefined();
    expect(typeof out.metadata.inventorySize).toBe("number");
  });
});
