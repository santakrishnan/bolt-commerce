import { beforeEach, describe, expect, it, vi } from "vitest";

import {
  getFinancingInfo,
  getFinancingInfoSync,
  getVehicleFinancing,
} from "../mock-financing-service";

const DOWN_PAYMENT_REGEX = /\$\d{1,3}(,\d{3})*/;

describe("mock-financing-service", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it("getFinancingInfoSync returns expected shape and defaults", () => {
    const res = getFinancingInfoSync({ vehiclePrice: 25_000 });
    expect(res).toHaveProperty("apr");
    expect(res).toHaveProperty("aprNumeric");
    expect(res).toHaveProperty("creditScore");
    expect(res).toHaveProperty("downPaymentFormatted");
    expect(res).toHaveProperty("estimatedMonthlyPayment");
    expect(res).toHaveProperty("monthlyPaymentNumeric");
    expect(res).toHaveProperty("termMonths");

    // Defaults should be applied
    expect(res.termMonths).toBeGreaterThan(0);
    expect(res.downPaymentFormatted).toMatch(DOWN_PAYMENT_REGEX);
    expect(typeof res.aprNumeric).toBe("number");
    expect(res.apr).toContain(res.aprNumeric.toFixed(2));
  });

  it("getVehicleFinancing uses vehicle.price and options", () => {
    const vehicle = { price: 18_000 };
    const out = getVehicleFinancing(vehicle, {
      downPayment: 0,
      termMonths: 36,
      creditTier: "good",
    });
    expect(out.termMonths).toBe(36);
    expect(out.downPaymentFormatted).toBe("$0");
    expect(out.monthlyPaymentNumeric).toBeGreaterThan(0);
    expect(out.aprNumeric).toBeGreaterThanOrEqual(0);
  });

  it("getFinancingInfo simulates latency in development (uses fake timers)", async () => {
    const original = process.env.NODE_ENV;
    (process.env as any).NODE_ENV = "development";

    vi.useFakeTimers();

    const promise = getFinancingInfo({ vehiclePrice: 15_000, downPayment: 1500 });

    // fast-forward any pending timers used to simulate latency
    vi.runAllTimers();

    const res = await promise;
    expect(res).toEqual(getFinancingInfoSync({ vehiclePrice: 15_000, downPayment: 1500 }));

    vi.useRealTimers();
    (process.env as any).NODE_ENV = original;
  });

  it("handles negative downPayment by treating it as additional principal", () => {
    const a = getFinancingInfoSync({ vehiclePrice: 10_000, downPayment: -1000 });
    const b = getFinancingInfoSync({ vehiclePrice: 10_000, downPayment: 0 });
    expect(a.monthlyPaymentNumeric).toBeGreaterThan(b.monthlyPaymentNumeric);
  });
});
