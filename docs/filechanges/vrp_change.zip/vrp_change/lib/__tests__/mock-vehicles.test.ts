import { describe, expect, it } from "vitest";
import { getVehicleEstimation, mockVehicles } from "../mock-vehicles";

const ESTIMATED_PAYMENT_REGEX = /^\$-?\d+$/;

describe("mock-vehicles exports", () => {
  it("exports an array of vehicles with required fields", () => {
    expect(Array.isArray(mockVehicles)).toBe(true);
    expect(mockVehicles.length).toBeGreaterThan(0);

    for (const v of mockVehicles) {
      expect(typeof v.id).toBe("number");
      expect(typeof v.vin).toBe("string");
      expect(typeof v.title).toBe("string");
      expect(typeof v.price).toBe("number");
      expect(v.price).toBeGreaterThanOrEqual(0);
      expect(v.bodyType).toBeTruthy();
      expect(v.make).toBeTruthy();
      expect(v.model).toBeTruthy();
    }
  });

  it("has unique VINs", () => {
    const vins = mockVehicles.map((v) => v.vin);
    const set = new Set(vins);
    expect(set.size).toBe(vins.length);
  });

  it("contains at least one vehicle with multiple images and one with single image", () => {
    const hasArray = mockVehicles.some((v) => Array.isArray(v.image));
    const hasString = mockVehicles.some((v) => typeof v.image === "string");
    expect(hasArray).toBe(true);
    expect(hasString).toBe(true);
  });

  it("contains vehicles with oldPrice and each oldPrice is higher than current price", () => {
    const withOld = mockVehicles.filter((v) => typeof v.oldPrice === "number");
    expect(withOld.length).toBeGreaterThan(0);
    for (const v of withOld) {
      expect(v.oldPrice).toBeGreaterThan(v.price);
    }
  });

  it("uses valid fuel/drivetrain/transmission values", () => {
    const allowedFuel = new Set([
      "Gasoline",
      "Hybrid",
      "Plug-in Hybrid",
      "Electric",
      "Hydrogen",
      "Diesel",
      "Flex Fuel",
    ]);
    const allowedDrivetrain = new Set(["AWD", "FWD", "RWD", "4WD"]);
    const allowedTransmission = new Set(["Automatic", "CVT", "Manual"]);

    for (const v of mockVehicles) {
      expect(allowedFuel.has(v.fuelType)).toBe(true);
      expect(allowedDrivetrain.has(v.drivetrain)).toBe(true);
      expect(allowedTransmission.has(v.transmission)).toBe(true);
    }
  });
});

describe("getVehicleEstimation() behavior", () => {
  it("returns provided estimation unmodified if present", () => {
    const customEst = {
      apr: "3%",
      creditScore: "Good",
      estimatedMonthlyPayment: "$100",
      termLength: "36",
    };
    const sample = { ...mockVehicles[0], estimation: customEst } as any;
    const out = getVehicleEstimation(sample);
    expect(out).toBe(customEst);
  });

  it("computes a default estimation for a typical vehicle and matches calculation exactly", () => {
    // pick a vehicle with a positive price
    const vehicle = mockVehicles.find((v) => v.price >= 1000);
    if (!vehicle) {
      throw new Error("No vehicle with price >= 1000");
    }

    const apr = 5.49;
    const termMonths = 60;
    const downPayment = 2500;
    const principal = vehicle.price - downPayment;
    const monthlyRate = apr / 100 / 12;
    const expectedMonthly = Math.round(
      (principal * monthlyRate) / (1 - (1 + monthlyRate) ** -termMonths)
    );

    const result = getVehicleEstimation(vehicle as any);
    expect(result.creditScore).toBe("Excellent (800+) FICO® Score");
    expect(result.apr).toBe(`${apr}%`);
    expect(result.termLength).toBe(`$${downPayment.toLocaleString()}`);
    expect(result.estimatedMonthlyPayment).toBe(`$${expectedMonthly}`);
  });

  it("handles price equal to down payment (principal=0) returning $0 monthly", () => {
    const special = { ...mockVehicles[0], price: 2500 } as any;
    const res = getVehicleEstimation(special);
    expect(res.estimatedMonthlyPayment).toBe("$0");
  });

  it("handles price less than down payment (negative principal) and returns a formatted value", () => {
    const special = { ...mockVehicles[0], price: 1000 } as any;
    const res = getVehicleEstimation(special);
    // Should still be a dollar string and contain a number (may be negative)
    expect(typeof res.estimatedMonthlyPayment).toBe("string");
    expect(res.estimatedMonthlyPayment).toMatch(ESTIMATED_PAYMENT_REGEX);
  });
});

// Extra assertion: every vehicle safety features includes a basic safety item
describe("features consistency", () => {
  it("includes common safety features across vehicles", () => {
    const found = mockVehicles.some(
      (v) => Array.isArray(v.features?.safety) && v.features.safety.includes("PCS")
    );
    expect(found).toBe(true);
  });
});
