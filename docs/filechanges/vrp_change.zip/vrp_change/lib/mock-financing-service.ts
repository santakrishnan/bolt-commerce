/**
 * Mock Financing Service
 *
 * Simulates a future BED Financing API that returns APR, monthly payment,
 * credit-tier information and term details for a given vehicle price.
 *
 * When a real Financing API is integrated, replace `getFinancingInfo` with a
 * real fetch. The `FinancingRequest` / `FinancingResult` contract stays.
 */

// ─── Public types ─────────────────────────────────────────────────────────────

/** Credit tier used to determine the APR offered. */
export type CreditTier = "excellent" | "good" | "fair" | "poor";

export interface FinancingRequest {
  /** Buyer credit tier. Defaults to "excellent". */
  creditTier?: CreditTier;
  /** Optional down-payment amount. Defaults to $2,500. */
  downPayment?: number;
  /** Loan term in months. Defaults to 60. */
  termMonths?: number;
  /** Vehicle sale price in dollars. */
  vehiclePrice: number;
}

export interface FinancingResult {
  /** Annual Percentage Rate as a display string, e.g. "5.49%". */
  apr: string;
  /** APR as a numeric value for calculations. */
  aprNumeric: number;
  /** Human-readable credit score description. */
  creditScore: string;
  /** Down-payment formatted as a dollar string used as `termLength` in the UI. */
  downPaymentFormatted: string;
  /** Estimated monthly payment, e.g. "$583". */
  estimatedMonthlyPayment: string;
  /** Estimated monthly payment as a numeric value. */
  monthlyPaymentNumeric: number;
  /** Loan term in months. */
  termMonths: number;
}

// ─── Credit tier configuration ────────────────────────────────────────────────

interface CreditTierConfig {
  apr: number;
  label: string;
}

const CREDIT_TIERS: Record<CreditTier, CreditTierConfig> = {
  excellent: { apr: 5.49, label: "Excellent (800+) FICO® Score" },
  good: { apr: 6.99, label: "Good (670–799) FICO® Score" },
  fair: { apr: 9.49, label: "Fair (580–669) FICO® Score" },
  poor: { apr: 13.99, label: "Below Average (<580) FICO® Score" },
};

// ─── Defaults ─────────────────────────────────────────────────────────────────

const DEFAULT_DOWN_PAYMENT = 2500;
const DEFAULT_TERM_MONTHS = 60;
const DEFAULT_CREDIT_TIER: CreditTier = "excellent";

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Standard amortization formula:
 *   M = P × [ r(1+r)^n ] / [ (1+r)^n – 1 ]
 * where P = principal, r = monthly rate, n = term in months.
 */
function calculateMonthlyPayment(
  principal: number,
  annualRate: number,
  termMonths: number
): number {
  if (principal <= 0) {
    return 0;
  }
  if (termMonths <= 0) {
    return 0;
  }
  if (annualRate === 0) {
    return Math.round(principal / termMonths);
  }
  const monthlyRate = annualRate / 100 / 12;
  return Math.round((principal * monthlyRate) / (1 - (1 + monthlyRate) ** -termMonths));
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Synchronously compute financing details for a vehicle.
 * Use for instant UI rendering without waiting for an async call.
 */
export function getFinancingInfoSync(req: FinancingRequest): FinancingResult {
  const {
    vehiclePrice,
    downPayment = DEFAULT_DOWN_PAYMENT,
    termMonths = DEFAULT_TERM_MONTHS,
    creditTier = DEFAULT_CREDIT_TIER,
  } = req;

  const tierConfig = CREDIT_TIERS[creditTier];
  const principal = Math.max(0, vehiclePrice - downPayment);
  const monthly = calculateMonthlyPayment(principal, tierConfig.apr, termMonths);

  return {
    apr: `${tierConfig.apr.toFixed(2)}%`,
    aprNumeric: tierConfig.apr,
    creditScore: tierConfig.label,
    downPaymentFormatted: `$${downPayment.toLocaleString()}`,
    estimatedMonthlyPayment: `$${monthly.toLocaleString()}`,
    monthlyPaymentNumeric: monthly,
    termMonths,
  };
}

/**
 * Async version that simulates network latency in development.
 * Swap with a real `fetch("/api/financing", …)` when the BED is ready —
 * the FinancingRequest → FinancingResult contract stays.
 */
export async function getFinancingInfo(req: FinancingRequest): Promise<FinancingResult> {
  if (process.env.NODE_ENV === "development") {
    await new Promise<void>((resolve) => setTimeout(resolve, 80 + Math.random() * 70));
  }
  return getFinancingInfoSync(req);
}

/**
 * Convenience: compute financing for a Vehicle-like object that has a `price`.
 * Mirrors the old `getVehicleEstimation` helper but uses the financing service.
 */
export function getVehicleFinancing(
  vehicle: { price: number },
  opts?: Omit<FinancingRequest, "vehiclePrice">
): FinancingResult {
  return getFinancingInfoSync({ vehiclePrice: vehicle.price, ...opts });
}
