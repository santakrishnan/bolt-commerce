/** Facet comparison and merging utilities for SearchContext. */

import type { FilterState } from "@features/search/components/filter-sidebar/types";
import { ALL_FACET_SECTIONS, type FacetSection } from "@features/search/lib/mock-faceted-search";

export function listEqual(a: string[], b: string[]): boolean {
  if (a.length !== b.length) {
    return false;
  }
  const aa = [...a].sort();
  const bb = [...b].sort();
  return aa.every((item, idx) => item === bb[idx]);
}

export function mergeUniqueSections(current: FacetSection[], next: FacetSection[]): FacetSection[] {
  return [...new Set([...current, ...next])];
}

export function changedFacetSections(
  prev: FilterState,
  next: FilterState,
  opts?: { queryChanged?: boolean; labelChanged?: boolean; refineChanged?: boolean }
): FacetSection[] {
  const changed: FacetSection[] = [];

  if (prev.selectedPriceQuick !== next.selectedPriceQuick) {
    changed.push("Price");
  }
  if (prev.selectedYearQuick !== next.selectedYearQuick) {
    changed.push("Year");
  }
  if (prev.selectedMileage !== next.selectedMileage) {
    changed.push("Mileage");
  }
  if (!listEqual(prev.selectedBodyStyles, next.selectedBodyStyles)) {
    changed.push("Body Style");
  }
  if (!listEqual(prev.selectedExteriorColors, next.selectedExteriorColors)) {
    changed.push("Exterior Color");
  }
  if (!listEqual(prev.selectedInteriorColors, next.selectedInteriorColors)) {
    changed.push("Interior Color");
  }
  if (!listEqual(prev.selectedModels, next.selectedModels)) {
    changed.push("Make & Model");
  }
  if (!listEqual(prev.selectedFuelTypes, next.selectedFuelTypes)) {
    changed.push("Fuel Type");
  }
  if (
    !(
      listEqual(prev.selectedSafetyFeatures, next.selectedSafetyFeatures) &&
      listEqual(prev.selectedComfortFeatures, next.selectedComfortFeatures) &&
      listEqual(prev.selectedTechFeatures, next.selectedTechFeatures) &&
      listEqual(prev.selectedExteriorFeatures, next.selectedExteriorFeatures) &&
      listEqual(prev.selectedPerformanceFeatures, next.selectedPerformanceFeatures) &&
      listEqual(prev.selectedSeatingCapacity, next.selectedSeatingCapacity)
    )
  ) {
    changed.push("Features & Technology");
  }
  if (prev.inspection160 !== next.inspection160) {
    changed.push("Inspection");
  }
  if (!listEqual(prev.selectedDrivetrains, next.selectedDrivetrains)) {
    changed.push("Drivetrain");
  }
  if (!listEqual(prev.selectedTransmissions, next.selectedTransmissions)) {
    changed.push("Transmission");
  }

  if (opts?.queryChanged || opts?.labelChanged || opts?.refineChanged) {
    return ALL_FACET_SECTIONS;
  }

  return [...new Set(changed)];
}
