import { describe, expect, it } from "vitest";
import * as data from "../index";

describe("shared/data index", () => {
  it("exports async getters and re-exported data", async () => {
    expect(typeof data.getVehicleTypes).toBe("function");
    expect(typeof data.getInspectionFeatures).toBe("function");

    expect(Array.isArray(data.inspectionFeatures)).toBe(true);
    const features = await data.getInspectionFeatures();
    expect(features).toEqual(data.inspectionFeatures);

    const hasVehicleTypes = Object.hasOwn(data, "vehicleTypes");
    expect(hasVehicleTypes).toBe(true);
    const vehicleTypes = (data as any).vehicleTypes;
    const vt = await data.getVehicleTypes();
    expect(Array.isArray(vt)).toBe(true);
    expect(vt).toEqual(vehicleTypes);
  });

  it("getters are stable across multiple calls", async () => {
    const a = await data.getVehicleTypes();
    const b = await data.getVehicleTypes();
    expect(a).toEqual(b);

    const f1 = await data.getInspectionFeatures();
    const f2 = await data.getInspectionFeatures();
    expect(f1).toEqual(f2);
  });
});
