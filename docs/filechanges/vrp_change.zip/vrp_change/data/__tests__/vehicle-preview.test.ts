import { describe, expect, it } from "vitest";
import { demoVehiclePreview, vehiclePreviewImages } from "../vehicle-preview";

describe("vehicle-preview data", () => {
  it("vehiclePreviewImages is a non-empty array with expected paths and preserved spaces", () => {
    expect(Array.isArray(vehiclePreviewImages)).toBe(true);
    expect(vehiclePreviewImages.length).toBeGreaterThan(0);
    for (const p of vehiclePreviewImages) {
      expect(typeof p).toBe("string");
      expect(p.startsWith("/images/vdp-images/")).toBe(true);
    }
    expect(vehiclePreviewImages.some((p) => p.includes(" "))).toBe(true);
  });

  it("demoVehiclePreview has expected fields and matches vehiclePreviewImages", () => {
    expect(demoVehiclePreview.images).toEqual(vehiclePreviewImages);

    expect(typeof demoVehiclePreview.make).toBe("string");
    expect(typeof demoVehiclePreview.model).toBe("string");
    expect(typeof demoVehiclePreview.vin).toBe("string");
    expect(typeof demoVehiclePreview.stock).toBe("string");

    expect(typeof demoVehiclePreview.year).toBe("number");
    expect(demoVehiclePreview.year).toBeGreaterThan(1900);

    expect(typeof demoVehiclePreview.price).toBe("number");
    expect(demoVehiclePreview.price).toBeGreaterThanOrEqual(0);
    expect(demoVehiclePreview.originalPrice).toBeGreaterThanOrEqual(0);

    expect(Array.isArray(demoVehiclePreview.features)).toBe(true);
    expect(demoVehiclePreview.features.length).toBeGreaterThan(0);
    for (const f of demoVehiclePreview.features) {
      expect(typeof f).toBe("string");
      expect(f.length).toBeGreaterThan(0);
    }

    expect(demoVehiclePreview.title).toBeUndefined();
  });
});
