import { describe, expect, it } from "vitest";
import { contactInfo, footerSections, socialLinks } from "../footer-links";

describe("footer-links data", () => {
  it("exports footerSections with expected sections and link shapes", () => {
    expect(Array.isArray(footerSections)).toBe(true);
    expect(footerSections.length).toBeGreaterThan(0);

    const titles = footerSections.map((s) => s.title);
    expect(titles).toEqual(expect.arrayContaining(["Shop", "Support", "Company", "Legal"]));

    for (const section of footerSections) {
      expect(typeof section.title).toBe("string");
      expect(Array.isArray(section.links)).toBe(true);
      expect(section.links.length).toBeGreaterThan(0);

      for (const link of section.links) {
        expect(typeof link.label).toBe("string");
        expect(typeof link.href).toBe("string");
        if (Object.hasOwn(link, "external")) {
          expect(typeof link.external).toBe("boolean");
        }
      }
    }
  });

  it("exports socialLinks with expected shape and external hrefs", () => {
    expect(Array.isArray(socialLinks)).toBe(true);
    expect(socialLinks.length).toBeGreaterThanOrEqual(4);

    for (const s of socialLinks) {
      expect(typeof s.label).toBe("string");
      expect(typeof s.href).toBe("string");
      expect(typeof s.icon).toBe("string");
      expect(s.href.startsWith("http")).toBe(true);
    }
  });

  it("exports contactInfo with phone, email and location entries", () => {
    expect(contactInfo).toBeTruthy();
    expect(contactInfo.phone).toBeTruthy();
    expect(contactInfo.email).toBeTruthy();
    expect(contactInfo.location).toBeTruthy();

    expect(typeof contactInfo.phone.label).toBe("string");
    expect(typeof contactInfo.phone.value).toBe("string");
    expect(typeof contactInfo.phone.href).toBe("string");
    expect(contactInfo.phone.href.startsWith("tel:")).toBe(true);

    expect(contactInfo.email.href.startsWith("mailto:")).toBe(true);

    expect(typeof contactInfo.location.label).toBe("string");
    expect(typeof contactInfo.location.value).toBe("string");
    expect(typeof contactInfo.location.href).toBe("string");
  });
});
