export { type InspectionFeature, inspectionFeatures } from "./inspection/features";
export { type VehicleType, vehicleTypes } from "./vehicle-types";

export async function getVehicleTypes() {
  const { vehicleTypes } = await import("./vehicle-types");
  return vehicleTypes;
}

export async function getInspectionFeatures() {
  const { inspectionFeatures } = await import("./inspection/features");
  return inspectionFeatures;
}
