import { describe, expect, it } from "vitest";
import { getDealerDataByZip, sampleDealerNotes } from "../dealer-data";
import dealersByZip from "../mock-dealers-by-zip.json";

describe("dealer-data", () => {
  it("returns sampleDealerNotes when zip is not found", () => {
    const { dealerInfo, dealerNotes } = getDealerDataByZip("00000");
    expect(dealerInfo).toEqual(sampleDealerNotes.dealer);
    expect(dealerNotes).toEqual(sampleDealerNotes);
  });

  it("returns dealer info and notes for a known zip from mock file", () => {
    const zips = Object.keys(dealersByZip);
    expect(zips.length).toBeGreaterThan(0);
    const zip = zips[0];
    expect(zip).toBeTruthy();
    if (!zip) {
      throw new Error("No zip found");
    }

    const entry: any = (dealersByZip as any)[zip];

    const { dealerInfo, dealerNotes } = getDealerDataByZip(zip);

    expect(dealerInfo).toEqual(entry.dealerInfo);
    expect(dealerNotes.dealer).toEqual(entry.dealerInfo);
    expect(dealerNotes.vehicleDescription).toBe(entry.dealerNotes.vehicleDescription);
    expect(dealerNotes.vehicleImage).toBe(entry.dealerNotes.vehicleImage);
  });
});
