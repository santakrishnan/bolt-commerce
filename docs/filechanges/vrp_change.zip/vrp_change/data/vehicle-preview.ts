export interface VehiclePreviewData {
  condition: string;
  dealer: string;
  distance: string;
  drivetrain: string;
  exterior: string;
  exteriorColorCode: string;
  features: string[];
  images: string[];
  inspected: boolean;
  interior: string;
  interiorColorCode: string;
  location: string;
  make: string;
  miles: string;
  model: string;
  mpg: string;
  originalPrice: number;
  price: number;
  stock: string;
  title?: string;
  trim?: string;
  vin: string;
  warranty: boolean;
  year: number;
}

export const vehiclePreviewImages: string[] = [
  "/images/vdp-images/image 904.png",
  "/images/vdp-images/image 905.png",
  "/images/vdp-images/image 907.png",
  "/images/vdp-images/image 908.png",
  "/images/vdp-images/image 909.png",
  "/images/vdp-images/image 910.png",
];

export const demoVehiclePreview: VehiclePreviewData = {
  year: 2023,
  make: "Toyota",
  model: "Highlander XLE",
  trim: "XLE",
  price: 43_098,
  originalPrice: 35_900,
  condition: "Excellent Price",
  warranty: true,
  inspected: true,
  miles: "18,450",
  drivetrain: "AWD",
  mpg: "18-24",
  stock: "990167H",
  vin: "2T3P1RF5VNW123456",
  exterior: "Graphite Fabric",
  exteriorColorCode: "#474B50",
  interior: "Charcoal Gray",
  interiorColorCode: "#36454F",
  dealer: "Toyota of Plano",
  location: "Plano, TX 75001",
  distance: "3.2mi",
  images: vehiclePreviewImages,
  features: [
    "Apple CarPlay/Android Auto",
    "Around View Camera",
    "Pedestrian Detection",
    "Bluetooth Hands-Free/ Streaming Audio",
    "Forward Collision Warning",
    "Voice Command",
    "Rear Sunshade",
    "Power Trunk/ Liftgate",
    "LED Highlights",
    "Folding Mirrors",
    "Blind Spot Monitor",
    "Lane Departure Warning",
    "Adaptive Cruise Control",
    "Heated Seats",
    "Ventilated Seats",
    "Panoramic Sunroof",
    "Navigation System",
    "Premium Sound System",
  ],
};
