import { describe, expect, it } from "vitest";
import { inspectionFeatures } from "../features";

describe("inspectionFeatures data", () => {
  it("is an array with expected features and shapes", () => {
    expect(Array.isArray(inspectionFeatures)).toBe(true);
    expect(inspectionFeatures.length).toBeGreaterThanOrEqual(4);

    const allowedIcons = ["arrow-circle", "certified-document", "verified-badge", "guarantee"];

    for (const f of inspectionFeatures) {
      expect(typeof f.id).toBe("string");
      expect(typeof f.title).toBe("string");
      expect(typeof f.description).toBe("string");
      expect(typeof f.image).toBe("string");
      expect(allowedIcons).toContain(f.icon);
      expect(f.image.startsWith("/images/")).toBe(true);
    }
  });

  it("contains the canonical feature ids", () => {
    const ids = inspectionFeatures.map((f) => f.id);
    expect(ids).toEqual(
      expect.arrayContaining([
        "160-point-inspection",
        "verified-vin",
        "no-hidden-damage",
        "7-day-return",
      ])
    );
  });

  it("first feature has expected title fragment", () => {
    const f = inspectionFeatures.find((x) => x.id === "160-point-inspection");
    expect(f).toBeDefined();
    expect(f?.title).toContain("160-Point");
  });
});
