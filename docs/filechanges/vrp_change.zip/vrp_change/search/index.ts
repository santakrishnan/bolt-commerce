// ── Public API for the search feature ────────────────────────────────
// Only exports consumed through the barrel by external features.
// All other imports use deep paths (e.g., @features/search/services).

export type { ActiveFilter } from "./components/vehicle-results";
export { SearchHistoryProvider, useSearchHistory } from "./context/search-history-provider";
