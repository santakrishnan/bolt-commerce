import { act, render } from "@testing-library/react";
import React from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";

// Test-scoped mocks so their instances can be controlled per-test
const routerMock = { push: vi.fn(), replace: vi.fn() };
const addSearchMock = vi.fn();
const toSearchUrlMock = vi.fn();

vi.mock("next/navigation", () => ({
  useRouter: () => routerMock,
}));

vi.mock("@features/search/context/search-history-provider", () => ({
  useSearchHistory: () => ({ addSearch: addSearchMock }),
}));

vi.mock("utils", () => ({
  toSearchUrl: (query: string, basePath: string) => toSearchUrlMock(query, basePath),
}));

vi.mock("@config/routes/constants", () => ({
  ROUTES: { USED_CARS: "/used-cars" },
}));

import { useSearchNavigation } from "../use-search-navigation";

function HookHost({ options, onReady }: { options?: any; onReady: (api: any) => void }) {
  const api = useSearchNavigation(options);
  React.useEffect(() => {
    onReady(api);
  }, [api, onReady]);
  return null;
}

beforeEach(() => {
  routerMock.push.mockClear();
  routerMock.replace.mockClear();
  addSearchMock.mockClear();
  toSearchUrlMock.mockClear();
});

describe("useSearchNavigation", () => {
  it("buildUrl calls toSearchUrl with default basePath", () => {
    toSearchUrlMock.mockReturnValue("/used-cars?q=SUV");

    let api: any;
    render(React.createElement(HookHost, { onReady: (a: any) => (api = a) }));

    const url = api.buildUrl("SUV");

    expect(url).toBe("/used-cars?q=SUV");
    expect(toSearchUrlMock).toHaveBeenCalledWith("SUV", "/used-cars");
  });

  it("navigate in push mode calls router.push and does not record history by default", () => {
    toSearchUrlMock.mockReturnValue("/used-cars?q=sedan");

    let api: any;
    render(React.createElement(HookHost, { onReady: (a: any) => (api = a) }));

    act(() => {
      api.navigate("sedan");
    });

    expect(routerMock.push).toHaveBeenCalledTimes(1);
    expect(routerMock.push).toHaveBeenCalledWith("/used-cars?q=sedan");
    expect(routerMock.replace).not.toHaveBeenCalled();
    expect(addSearchMock).not.toHaveBeenCalled();
  });

  it("navigate with recordHistory=true records searches when trimmed length > 1 and forwards source", () => {
    toSearchUrlMock.mockReturnValue("/used-cars?q=compact+car");

    let api: any;
    render(
      React.createElement(HookHost, {
        options: { recordHistory: true },
        onReady: (a: any) => (api = a),
      })
    );

    act(() => {
      api.navigate("  compact car  ", { source: "filter" });
    });

    expect(addSearchMock).toHaveBeenCalledTimes(1);
    expect(addSearchMock).toHaveBeenCalledWith("compact car", "/used-cars?q=compact+car", "filter");
    expect(routerMock.push).toHaveBeenCalledWith("/used-cars?q=compact+car");
  });

  it("does not record history when trimmed query length <= 1", () => {
    toSearchUrlMock.mockReturnValue("/used-cars?q=A");

    let api: any;
    render(
      React.createElement(HookHost, {
        options: { recordHistory: true },
        onReady: (a: any) => (api = a),
      })
    );

    act(() => {
      api.navigate(" A ");
    });

    expect(addSearchMock).not.toHaveBeenCalled();
    expect(routerMock.push).toHaveBeenCalledWith("/used-cars?q=A");
  });

  it("replace mode uses router.replace and respects scroll option", () => {
    toSearchUrlMock.mockReturnValue("/used-cars?q=truck");

    let api: any;
    render(
      React.createElement(HookHost, {
        options: { mode: "replace", scroll: false },
        onReady: (a: any) => (api = a),
      })
    );

    act(() => {
      api.navigate("truck");
    });

    expect(routerMock.replace).toHaveBeenCalledTimes(1);
    expect(routerMock.replace).toHaveBeenCalledWith("/used-cars?q=truck", { scroll: false });
    expect(routerMock.push).not.toHaveBeenCalled();
  });

  it("buildUrl respects custom basePath option", () => {
    toSearchUrlMock.mockReturnValue("/dealer/42?q=mini");

    let api: any;
    render(
      React.createElement(HookHost, {
        options: { basePath: "/dealer/42" },
        onReady: (a: any) => (api = a),
      })
    );

    const url = api.buildUrl("mini");

    expect(url).toBe("/dealer/42?q=mini");
    expect(toSearchUrlMock).toHaveBeenCalledWith("mini", "/dealer/42");
  });

  it("empty or whitespace-only query navigates to base path (no history recorded)", () => {
    toSearchUrlMock.mockReturnValue("/used-cars");

    let api: any;
    render(
      React.createElement(HookHost, {
        options: { recordHistory: true },
        onReady: (a: any) => (api = a),
      })
    );

    act(() => {
      api.navigate("   ");
    });

    expect(routerMock.push).toHaveBeenCalledWith("/used-cars");
    expect(addSearchMock).not.toHaveBeenCalled();
  });
});
