import { API_ROUTES } from "@config/routes/constants";
import type {
  MockFacetedSearchRequest,
  MockFacetedSearchResponse,
  MockFilterSearchRequest,
  MockFilterSearchResponse,
} from "@features/search/lib/mock-faceted-search";

export async function fetchVehicleSearch(
  request: MockFacetedSearchRequest
): Promise<MockFacetedSearchResponse> {
  const res = await fetch(API_ROUTES.SEARCH, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify({ ...request, includeFacets: false }),
  });

  if (!res.ok) {
    throw new Error(`Vehicle search failed: ${res.status}`);
  }

  return (await res.json()) as MockFacetedSearchResponse;
}

export async function fetchFilters(
  request: MockFilterSearchRequest
): Promise<MockFilterSearchResponse> {
  const res = await fetch(API_ROUTES.SEARCH_FILTERS, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify(request),
  });

  if (!res.ok) {
    throw new Error(`Filters search failed: ${res.status}`);
  }

  return (await res.json()) as MockFilterSearchResponse;
}
