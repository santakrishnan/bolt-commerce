import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

// Mocks for modules used by the provider
vi.mock("@features/search/queries/search-history", () => ({
  searchHistoryQueries: {
    all: () => ({ queryKey: ["search-history"] }),
  },
}));

vi.mock("@features/search/services/search-history-api", () => ({
  addSearchEntry: vi.fn(async () => ({})),
  removeSearchEntry: vi.fn(async () => ({})),
  clearSearchHistory: vi.fn(async () => ({})),
}));

// Mock useQuery to return a controllable searches array and fetched flag
vi.mock("@tanstack/react-query", () => ({
  useQuery: vi.fn(() => ({ data: [], isFetched: true })),
}));

// Mock for optimistic hook — provide internal accessors via the mocked module
vi.mock("@shared/hooks/use-optimistic-list-mutation", () => {
  const state: { last?: any; captured: any[] } = { last: undefined, captured: [] };

  function useOptimisticListMutation(opts: any) {
    state.captured.push(opts);
    return {
      mutate: async (vars?: any) => {
        await (opts.mutationFn ? opts.mutationFn(vars) : Promise.resolve());
        const prev: any[] = [
          { id: "1", query: "foo", url: "/old", timestamp: "t1", type: "nlp" },
          { id: "2", query: "bar", url: "/b", timestamp: "t2", type: "filter" },
        ];
        const updated = opts.updater ? opts.updater(prev, vars) : prev;
        state.last = updated;
        return updated;
      },
    };
  }

  (useOptimisticListMutation as any).__getState = () => state;

  return { useOptimisticListMutation };
});

// Now import the provider and hook under test
import {
  SEARCH_HISTORY_KEY,
  SearchHistoryProvider,
  useSearchHistory,
} from "../search-history-provider";

function Consumer() {
  const { addSearch, removeSearch, clearAll, searches, isLoaded } = useSearchHistory();

  return (
    <div>
      <div data-testid="loaded">{String(isLoaded)}</div>
      <div data-testid="count">{searches.length}</div>
      <button data-testid="add" onClick={() => addSearch("foo", "/new", "nlp")} type="button" />
      <button data-testid="add-short" onClick={() => addSearch("a", "/x", "nlp")} type="button" />
      <button data-testid="remove" onClick={() => removeSearch("1")} type="button" />
      <button data-testid="clear" onClick={() => clearAll()} type="button" />
    </div>
  );
}

describe("SearchHistoryProvider", () => {
  beforeEach(async () => {
    vi.clearAllMocks();
    // clear captured mutations and last state in the optimistic hook mock
    const mockOpt = (await vi.importMock("@shared/hooks/use-optimistic-list-mutation")) as any;
    const s = mockOpt.useOptimisticListMutation.__getState();
    s.captured.length = 0;
    s.last = undefined;
  });

  it("exposes SEARCH_HISTORY_KEY from query factory", () => {
    expect(SEARCH_HISTORY_KEY).toEqual(["search-history"]);
  });

  it("provides lazy data through useSearchHistory and mutation actions", async () => {
    render(
      <SearchHistoryProvider>
        <Consumer />
      </SearchHistoryProvider>
    );

    // initial useQuery mock returns [] and isFetched true
    expect(screen.getByTestId("loaded").textContent).toBe("true");
    expect(screen.getByTestId("count").textContent).toBe("0");

    // There should be three captured mutation configs (add, remove, clear)
    const mockOpt = (await vi.importMock("@shared/hooks/use-optimistic-list-mutation")) as any;
    expect(mockOpt.useOptimisticListMutation.__getState().captured.length).toBe(3);

    // Trigger add with a normal query
    fireEvent.click(screen.getByTestId("add"));
    // The mocked mutate stores result in last
    const lastAdd = (await vi.importMock("@shared/hooks/use-optimistic-list-mutation")) as any;
    const lastAddState = lastAdd.useOptimisticListMutation.__getState().last;
    expect(Array.isArray(lastAddState)).toBe(true);
    // dedupe behavior: first entry should be the added/updated query trimmed to "foo"
    expect(lastAddState[0].query.toLowerCase()).toBe("foo");

    // Trigger add with a short query (should be ignored by updater)
    fireEvent.click(screen.getByTestId("add-short"));
    const lastShort = (await vi.importMock("@shared/hooks/use-optimistic-list-mutation")) as any;
    const lastShortState = lastShort.useOptimisticListMutation.__getState().last;
    // Updater returns prev unchanged for 1-char queries (length <=1)
    expect(lastShortState).toBeDefined();
    expect(lastShortState.length).toBeGreaterThanOrEqual(0);

    // Trigger remove
    fireEvent.click(screen.getByTestId("remove"));
    const lastRemove = (await vi.importMock("@shared/hooks/use-optimistic-list-mutation")) as any;
    const lastRemoveState = lastRemove.useOptimisticListMutation.__getState().last;
    // remove updater should filter out id '1'
    expect(lastRemoveState.find((s: any) => s.id === "1")).toBeUndefined();

    // Trigger clear
    fireEvent.click(screen.getByTestId("clear"));
    const lastClear = (await vi.importMock("@shared/hooks/use-optimistic-list-mutation")) as any;
    const lastClearState = lastClear.useOptimisticListMutation.__getState().last;
    expect(Array.isArray(lastClearState)).toBe(true);
    expect(lastClearState.length).toBe(0);
  });
});
