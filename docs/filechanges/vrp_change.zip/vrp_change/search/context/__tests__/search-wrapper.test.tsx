import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

// Mock filterSections to a predictable set. Provide the full shape so other
// modules (mock-faceted-search) won't receive undefined arrays during the
// full test run.
vi.mock("@features/search/services/srp-initial-data", () => ({
  fetchInitialSrpResults: vi.fn().mockResolvedValue({ vehicles: [], totalCount: 0 }),
}));

vi.mock("@features/search/lib/filter-sections", () => ({
  filterSections: {
    bodyStyle: ["Sedan", "SUV", "Coupe"],
    exteriorColors: ["White", "Black", "Ocean Blue"],
    interiorColors: ["Black", "Beige"],
    drivetrains: ["FWD", "AWD", "RWD"],
    transmissions: ["Automatic", "Manual"],
    fuelTypes: ["Gasoline", "Hybrid", "Electric"],
    models: ["corolla", "camry"],
    // Feature fields required by nlp-autocomplete
    comfortFeatures: ["Heated Seats", "Leather Seats", "Climate Control"],
    techFeatures: ["Bluetooth", "Apple CarPlay"],
    safetyFeatures: ["Airbags", "Lane Assist"],
    exteriorFeatures: ["Sunroof", "Tow Package"],
    // keep other fields the mock-faceted-search expects available
    hasInspection160: [true],
  },
}));

// Mock SearchClient to render a visible marker
vi.mock("@features/search/context/search-client", () => ({
  SearchClient: () => <div data-testid="mock-client">client</div>,
}));

// Mock SearchProvider to capture props passed and render children
vi.mock("@features/search/context/search-context", () => {
  let lastProps: any = null;

  function SearchProvider(props: any) {
    // store props (excluding children) so tests can assert
    const { children, ...rest } = props;
    lastProps = rest;
    return <div data-testid="mock-provider">{children}</div>;
  }

  return {
    SearchProvider,
    __getLastProps: () => lastProps,
  };
});

import { SearchWrapper } from "../search-wrapper";

// helper to import the mocked provider accessor at runtime
const getLastProps = async () => {
  const mod = await vi.importMock("@features/search/context/search-context");
  return (mod as any).__getLastProps();
};

describe("SearchWrapper", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("resolves path body type case-insensitively and passes it to SearchProvider", async () => {
    render(await SearchWrapper({ initialBodyType: "sedan" }));

    // SearchClient should render inside mocked provider
    expect(screen.getByTestId("mock-client")).toBeDefined();

    const props = await getLastProps();
    expect(props).toBeTruthy();
    expect(Array.isArray(props.initialBodyStyles)).toBe(true);
    expect(props.initialBodyStyles).toEqual(["Sedan"]);
  });

  it("merges initialUrlFilters.selectedBodyStyles without duplicates and preserves order", async () => {
    render(
      await SearchWrapper({
        initialBodyType: "sedan",
        initialUrlFilters: { selectedBodyStyles: ["Coupe", "Sedan"] },
      })
    );

    const props = await getLastProps();
    expect(props.initialBodyStyles).toEqual(["Sedan", "Coupe"]);
  });

  it("uses provided initialSearchQuery as resolvedSearchQuery", async () => {
    render(await SearchWrapper({ initialSearchQuery: "find me" }));
    const props = await getLastProps();
    expect(props.initialSearchQuery).toBe("find me");
  });

  it("falls back to url filters when no path body type is provided", async () => {
    render(await SearchWrapper({ initialUrlFilters: { selectedBodyStyles: ["Coupe"] } }));
    const props = await getLastProps();
    expect(props.initialBodyStyles).toEqual(["Coupe"]);
  });
});
