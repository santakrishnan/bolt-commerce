import { fireEvent, render, screen } from "@testing-library/react";
import { expect, test, vi } from "vitest";

// Mutable context used by the mock factory so tests can mutate between renders
const mockContext: any = {
  vehiclePool: [],
  filterState: {
    selectedPriceQuick: "",
    selectedYearQuick: "",
    selectedMileage: "",
    selectedBodyStyles: [],
    selectedExteriorColors: [],
    selectedInteriorColors: [],
    selectedFuelTypes: [],
    selectedModels: [],
    selectedSafetyFeatures: [],
    selectedComfortFeatures: [],
    selectedTechFeatures: [],
    selectedExteriorFeatures: [],
    selectedPerformanceFeatures: [],
    selectedSeatingCapacity: [],
    selectedDrivetrains: [],
    selectedTransmissions: [],
    inspection160: false,
  },
  searchQuery: "",
  setSearchQuery: vi.fn(),
  searchQueryRef: { current: "" },
  labelFilter: "",
  setLabelFilter: vi.fn(),
  refineSearchFilters: [],
  setRefineSearchFilters: vi.fn(),
  currentPage: 1,
  setCurrentPage: vi.fn(),
  progress: 0,
  isProgressVisible: true,
  isFilterOpen: false,
  setIsFilterOpen: vi.fn(),
  availableFilters: [],
  totalCount: 0,
  sortOption: "recommended",
  setSortOption: vi.fn(),
  loadingFacetSections: false,
  applyFiltersSearch: vi.fn(),
};

// Provide a minimal defaultFilterState used by reset path
const fakeDefaultFilterState = {
  selectedPriceQuick: "",
  selectedYearQuick: "",
  selectedMileage: "",
  selectedBodyStyles: [],
  selectedExteriorColors: [],
  selectedInteriorColors: [],
  selectedFuelTypes: [],
  selectedModels: [],
  selectedSafetyFeatures: [],
  selectedComfortFeatures: [],
  selectedTechFeatures: [],
  selectedExteriorFeatures: [],
  selectedPerformanceFeatures: [],
  selectedSeatingCapacity: [],
  selectedDrivetrains: [],
  selectedTransmissions: [],
  inspection160: false,
};

vi.mock("@features/search/context/search-context", () => ({
  useSearchContext: () => mockContext,
}));

// Mock URL helpers so SearchClient effects are deterministic
vi.mock("@features/search/lib/url-filters", () => ({
  parseSearchUrlState: () => ({
    filterState: {},
    searchQuery: "",
    page: 1,
    sortOption: "recommended",
    labelFilter: "",
  }),
  serializeSearchUrlState: () => "",
}));

// Mock Next navigation hooks
vi.mock("next/navigation", () => ({
  useRouter: () => ({ replace: vi.fn() }),
  usePathname: () => "/search",
  useSearchParams: () => null,
}));

vi.mock("@features/search/components/filter-sidebar", () => {
  const _default = {
    selectedPriceQuick: "",
    selectedYearQuick: "",
    selectedMileage: "",
    selectedBodyStyles: [],
    selectedExteriorColors: [],
    selectedInteriorColors: [],
    selectedFuelTypes: [],
    selectedModels: [],
    selectedSafetyFeatures: [],
    selectedComfortFeatures: [],
    selectedTechFeatures: [],
    selectedExteriorFeatures: [],
    selectedPerformanceFeatures: [],
    selectedSeatingCapacity: [],
    selectedDrivetrains: [],
    selectedTransmissions: [],
    inspection160: false,
  };
  return {
    defaultFilterState: _default,
    FilterSidebar: (props: any) => (
      <div data-testid="filter-sidebar">
        <button
          data-testid="filters-apply"
          onClick={() => props.onApply?.(_default)}
          type="button"
        />
        <button data-testid="filters-reset" onClick={() => props.onReset?.()} type="button" />
      </div>
    ),
  };
});

vi.mock("@features/search/components/search-hero", () => ({
  SearchHero: (props: any) => (
    <div data-testid="search-hero">
      <button
        data-testid="remove-label"
        onClick={() => props.onRemoveFilter?.("label", props.searchQuery || "")}
        type="button"
      />
      <button
        data-testid="remove-price"
        onClick={() => props.onRemoveFilter?.("price", "")}
        type="button"
      />
      <button data-testid="reset" onClick={() => props.onReset?.()} type="button" />
      <button
        data-testid="search-change"
        onClick={() => props.onSearchChange?.("new-query")}
        type="button"
      />
      <button data-testid="open-filter" onClick={() => props.onToggleFilter?.()} type="button" />
    </div>
  ),
}));

vi.mock("@features/search/components/vehicle-results", () => ({
  VehicleResults: (props: any) => (
    <div>
      <button
        data-testid="apply-refine"
        onClick={() =>
          props.onApplyRefineFilters?.([
            { id: "a", label: "A" },
            { id: "a", label: "A" },
            { id: "b", label: "B" },
          ])
        }
        type="button"
      />
    </div>
  ),
}));

import { SearchClient } from "@features/search/context/search-client";

test("progress transition reflects progress values (0, mid, 100)", () => {
  mockContext.progress = 0;
  mockContext.isProgressVisible = true;
  const { rerender } = render(<SearchClient />);

  // the progress bar element is the div with the `aria-hidden` attribute
  let bar = document.querySelector("div[aria-hidden]") as HTMLElement | null;
  expect(bar).toBeTruthy();
  expect(bar?.style.transition).toBe("none");

  mockContext.progress = 50;
  rerender(<SearchClient />);
  bar = document.querySelector("div[aria-hidden]") as HTMLElement | null;
  expect(bar?.style.transition).toContain("width 1.5s");

  mockContext.progress = 100;
  rerender(<SearchClient />);
  bar = document.querySelector("div[aria-hidden]") as HTMLElement | null;
  expect(bar?.style.transition).toContain("width 0.25s");
});

test("removeFilter 'label' clears label and calls applyFiltersSearch", () => {
  mockContext.labelFilter = "LABEL";
  mockContext.applyFiltersSearch = vi.fn();
  mockContext.setLabelFilter = vi.fn();

  render(<SearchClient />);
  const btn = screen.getByTestId("remove-label");
  fireEvent.click(btn);

  expect(mockContext.setLabelFilter).toHaveBeenCalledWith("");
  expect(mockContext.applyFiltersSearch).toHaveBeenCalled();
});

test("removeFilter 'bodyStyle' removes item from array and calls applyFiltersSearch", () => {
  mockContext.filterState = { ...mockContext.filterState, selectedBodyStyles: ["A", "B"] };
  mockContext.applyFiltersSearch = vi.fn();

  render(<SearchClient />);

  // call the internal remove by invoking the exposed onRemoveFilter via the SearchHero mock
  const removePrice = screen.getByTestId("remove-price");
  fireEvent.click(removePrice);

  // price path will call applyFiltersSearch
  expect(mockContext.applyFiltersSearch).toHaveBeenCalled();
});

test("applyRefineFilters deduplicates, sets refine filters and applies search", () => {
  mockContext.setRefineSearchFilters = vi.fn();
  mockContext.applyFiltersSearch = vi.fn();

  render(<SearchClient />);
  const btn = screen.getByTestId("apply-refine");
  fireEvent.click(btn);

  // deduped should be two items: a and b
  expect(mockContext.setRefineSearchFilters).toHaveBeenCalled();
  expect(mockContext.applyFiltersSearch).toHaveBeenCalled();
});

test("resetFilters clears searchQueryRef and applies defaultFilterState", () => {
  mockContext.searchQueryRef = { current: "something" };
  mockContext.applyFiltersSearch = vi.fn();

  render(<SearchClient />);
  const reset = screen.getByTestId("reset");
  fireEvent.click(reset);

  expect(mockContext.searchQueryRef.current).toBe("");
  expect(mockContext.applyFiltersSearch).toHaveBeenCalledWith(
    fakeDefaultFilterState,
    expect.any(Object)
  );
});
