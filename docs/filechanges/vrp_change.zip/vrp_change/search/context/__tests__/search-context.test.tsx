import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { act, fireEvent, render, screen } from "@testing-library/react";
import type React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { SearchProvider, useSearchContext } from "../search-context";

// Minimal FilterState matching the keys used by the provider internals
const defaultFilterState = {
  selectedPriceQuick: "",
  selectedYearQuick: "",
  selectedMileage: "",
  selectedBodyStyles: [],
  selectedExteriorColors: [],
  selectedInteriorColors: [],
  selectedModels: [],
  selectedFuelTypes: [],
  selectedSafetyFeatures: [],
  selectedComfortFeatures: [],
  selectedTechFeatures: [],
  selectedExteriorFeatures: [],
  selectedPerformanceFeatures: [],
  selectedSeatingCapacity: [],
  inspection160: false,
  selectedDrivetrains: [],
  selectedTransmissions: [],
} as unknown as any;

function Wrapper({ children }: { children: React.ReactNode }) {
  const qc = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return <QueryClientProvider client={qc}>{children}</QueryClientProvider>;
}

function TestConsumer() {
  const ctx = useSearchContext();

  return (
    <div>
      <div data-testid="vehicle-count">{ctx.vehiclePool.length}</div>
      <div data-testid="total-count">{ctx.totalCount}</div>
      <div data-testid="search-query">{ctx.searchQuery}</div>
      <div data-testid="refine-count">{ctx.refineSearchFilters.length}</div>
      <div data-testid="loading-sections">{ctx.loadingFacetSections.join(",")}</div>
      <div data-testid="progress">{ctx.progress}</div>
      <div data-testid="is-progress-visible">{String(ctx.isProgressVisible)}</div>
      <div data-testid="current-page">{ctx.currentPage}</div>

      <button
        data-testid="apply-btn"
        onClick={() =>
          ctx.applyFiltersSearch(
            { ...ctx.filterState, selectedBodyStyles: ["SUV"] },
            {
              searchQuery: "new-query",
              refineFilters: [
                { id: "r1", label: "Refinement 1" },
                { id: "r1", label: "Refinement 1" },
              ],
            }
          )
        }
        type="button"
      >
        apply
      </button>

      <button data-testid="search-btn" onClick={() => ctx.handleSearch()} type="button">
        search
      </button>
    </div>
  );
}

describe("SearchProvider integration", () => {
  let fetchMock: any;

  beforeEach(() => {
    // Fake timers for progress bar assertions
    vi.useFakeTimers();
    // do not call vi.setTimeout here; use per-waitFor timeouts below

    // Mock global fetch to return different payloads depending on request body
    fetchMock = vi.spyOn(global, "fetch").mockImplementation((_input: any, init?: any) => {
      const body = init?.body ? JSON.parse(init.body as string) : {};

      if (body.includeFacets === false) {
        // Vehicle search response
        return Promise.resolve({
          ok: true,
          status: 200,
          json: async () => ({
            metadata: { inventorySize: 100, searchId: "s1" },
            vehicles: [{ id: "v1" }],
            totalCount: 1,
          }),
        } as unknown as Response);
      }

      // Filters response
      return Promise.resolve({
        ok: true,
        status: 200,
        json: async () => ({
          facets: {
            updatedSections: ["Price"],
            availableFiltersPatch: { bodyStyles: ["SUV"] },
            facetCountsPatch: { bodyType: { SUV: 1 } },
          },
          filterId: "f1",
        }),
      } as unknown as Response);
    });
  });

  afterEach(() => {
    vi.useRealTimers();
    fetchMock.mockRestore();
  });

  it("applies initial search and filters from fetch responses", async () => {
    render(
      <Wrapper>
        <SearchProvider defaultFilterState={defaultFilterState}>
          <TestConsumer />
        </SearchProvider>
      </Wrapper>
    );

    // advance debounce timers used by the provider (300ms) and flush all timers
    await act(async () => {
      await vi.runAllTimersAsync();
    });

    // Check that queries finished and context updated
    expect(screen.getByTestId("vehicle-count").textContent).toBe("1");
    expect(screen.getByTestId("total-count").textContent).toBe("1");

    // Filters fetch removed the "Price" section from loadingFacetSections
    expect(screen.getByTestId("loading-sections").textContent).not.toContain("Price");
  });

  it("applyFiltersSearch updates searchQuery, deduplicates refine filters and resets page", async () => {
    render(
      <Wrapper>
        <SearchProvider defaultFilterState={defaultFilterState}>
          <TestConsumer />
        </SearchProvider>
      </Wrapper>
    );

    // advance debounce timers and flush all timers
    await act(async () => {
      await vi.runAllTimersAsync();
    });

    // Check initial queries loaded
    expect(screen.getByTestId("vehicle-count").textContent).toBe("1");

    // Click apply button to trigger filter change
    await act(async () => {
      fireEvent.click(screen.getByTestId("apply-btn"));
      await vi.runAllTimersAsync();
    });

    // Verify filter update results
    expect(screen.getByTestId("search-query").textContent).toBe("new-query");
    expect(screen.getByTestId("refine-count").textContent).toBe("1");
    expect(screen.getByTestId("current-page").textContent).toBe("1");
  });

  it("handleSearch toggles progress according to timers", async () => {
    render(
      <Wrapper>
        <SearchProvider defaultFilterState={defaultFilterState}>
          <TestConsumer />
        </SearchProvider>
      </Wrapper>
    );

    // advance debounce timers
    await act(async () => {
      await vi.runAllTimersAsync();
    });

    // Click search to trigger the progress sequence
    await act(() => {
      fireEvent.click(screen.getByTestId("search-btn"));
      vi.advanceTimersByTime(30);
    });

    // After ~20ms progress should be visible and set to 78
    expect(screen.getByTestId("is-progress-visible").textContent).toBe("true");
    expect(Number(screen.getByTestId("progress").textContent)).toBeGreaterThanOrEqual(0);

    // Advance to the end of the sequence; visibility should hide afterwards
    act(() => vi.advanceTimersByTime(1200));
    expect(screen.getByTestId("is-progress-visible").textContent).toBe("false");
  });
});
