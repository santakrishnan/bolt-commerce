import { API_ROUTES } from "@config/routes/constants";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import * as api from "../search-history-api";

interface MockResponse {
  json: () => Promise<any>;
  ok: boolean;
  status?: number;
}

function makeRes(ok: boolean, jsonData: any, status = 200, jsonReject = false): MockResponse {
  return {
    ok,
    status,
    json: () => {
      if (jsonReject) {
        return Promise.reject(new Error("invalid json"));
      }
      return Promise.resolve(jsonData);
    },
  };
}

let __originalFetch: typeof globalThis.fetch | undefined;

beforeEach(() => {
  vi.restoreAllMocks();
  // Save the original global fetch so we can restore it after the test.
  __originalFetch = globalThis.fetch;
  globalThis.fetch = vi.fn();
});

afterEach(() => {
  // Restore the original fetch implementation to avoid leaking into other tests
  if (typeof __originalFetch !== "undefined") {
    globalThis.fetch = __originalFetch;
    __originalFetch = undefined;
  }
});

describe("search-history-api client", () => {
  it("getAllSearchHistory: calls correct URL and returns data on success", async () => {
    const entries = [{ id: "1", query: "x", url: "/", type: "nlp" }];
    // @ts-expect-error
    globalThis.fetch.mockResolvedValue(makeRes(true, { data: entries }));

    const res = await api.getAllSearchHistory();
    expect(res).toEqual(entries);

    expect(globalThis.fetch).toHaveBeenCalledTimes(1);
    expect(globalThis.fetch).toHaveBeenCalledWith(
      API_ROUTES.SEARCH_HISTORY,
      expect.objectContaining({
        credentials: "include",
        headers: expect.objectContaining({ "Content-Type": "application/json" }),
      })
    );
  });

  it("addSearchEntry: posts JSON body with default type and returns updated list", async () => {
    const entries = [{ id: "2", query: "q", url: "/u", type: "nlp" }];
    // @ts-expect-error
    globalThis.fetch.mockResolvedValue(makeRes(true, { data: entries }));

    const res = await api.addSearchEntry("q", "/u");
    expect(res).toEqual(entries);

    expect(globalThis.fetch).toHaveBeenCalledWith(
      API_ROUTES.SEARCH_HISTORY,
      expect.objectContaining({
        credentials: "include",
        method: "POST",
        body: JSON.stringify({ query: "q", url: "/u", type: "nlp" }),
        headers: expect.objectContaining({ "Content-Type": "application/json" }),
      })
    );
  });

  it("addSearchEntry: accepts explicit type and sends it in the payload", async () => {
    const entries = [{ id: "3", query: "f", url: "/v", type: "filter" }];
    // @ts-expect-error
    globalThis.fetch.mockResolvedValue(makeRes(true, { data: entries }));

    const res = await api.addSearchEntry("f", "/v", "filter");
    expect(res).toEqual(entries);

    expect(globalThis.fetch).toHaveBeenCalledWith(
      API_ROUTES.SEARCH_HISTORY,
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({ query: "f", url: "/v", type: "filter" }),
      })
    );
  });

  it("removeSearchEntry: encodes id and issues DELETE", async () => {
    const id = "a b/c?d";
    const entries: any[] = [];
    // @ts-expect-error
    globalThis.fetch.mockResolvedValue(makeRes(true, { data: entries }));

    const res = await api.removeSearchEntry(id);
    expect(res).toEqual(entries);

    expect(globalThis.fetch).toHaveBeenCalledWith(
      `${API_ROUTES.SEARCH_HISTORY}/${encodeURIComponent(id)}`,
      expect.objectContaining({ method: "DELETE" })
    );
  });

  it("clearSearchHistory: calls DELETE on base route and returns empty array", async () => {
    const entries: any[] = [];
    // @ts-expect-error
    globalThis.fetch.mockResolvedValue(makeRes(true, { data: entries }));

    const res = await api.clearSearchHistory();
    expect(res).toEqual(entries);

    expect(globalThis.fetch).toHaveBeenCalledWith(
      API_ROUTES.SEARCH_HISTORY,
      expect.objectContaining({ method: "DELETE" })
    );
  });

  it("fetchJson: throws Error with message from body.error when response not ok", async () => {
    // @ts-expect-error
    globalThis.fetch.mockResolvedValue(makeRes(false, { error: "boom" }, 400));

    await expect(api.getAllSearchHistory()).rejects.toThrow("boom");
  });

  it("fetchJson: throws generic status message when body parsing fails", async () => {
    // @ts-expect-error
    globalThis.fetch.mockResolvedValue(makeRes(false, null, 500, true));

    await expect(api.getAllSearchHistory()).rejects.toThrow("Request failed: 500");
  });

  it("handles successful responses missing data property (returns undefined)", async () => {
    // @ts-expect-error
    globalThis.fetch.mockResolvedValue(makeRes(true, {}));

    const res = await api.getAllSearchHistory();
    expect(res).toBeUndefined();
  });
});
