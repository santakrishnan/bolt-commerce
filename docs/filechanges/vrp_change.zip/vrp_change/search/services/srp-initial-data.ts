import { defaultFilterState } from "@features/search/components/filter-sidebar/types";
import {
  type MockFacetedSearchResponse,
  runMockFacetedSearch,
} from "@features/search/lib/mock-faceted-search";
import { cacheLife, cacheTag } from "next/cache";

/**
 * Server-side initial SRP data fetch with per-bodyType caching.
 *
 * Called from SearchWrapper (server component) to provide initial vehicles
 * so the client renders cards immediately — no empty-state flash.
 *
 * When a real NLS API replaces the mock, swap `runMockFacetedSearch` for
 * an `ArrowServerClient` call with server-to-server auth. The cache key
 * stays bodyType + searchQuery (no per-user headers), so caching is preserved.
 * Per-user personalized results come via the client-side React Query path.
 */
export async function fetchInitialSrpResults(
  bodyType?: string,
  searchQuery?: string
): Promise<MockFacetedSearchResponse> {
  "use cache";
  cacheLife("srp");
  cacheTag("srp", bodyType ? `srp-${bodyType}` : "srp-all");

  const filterState = {
    ...defaultFilterState,
    ...(bodyType ? { selectedBodyStyles: [bodyType] } : {}),
  };

  // await needed: function must be async for "use cache" directive
  return await runMockFacetedSearch({
    filterState,
    searchQuery: searchQuery ?? "",
    page: 1,
    pageSize: 20,
    includeFacets: false,
    sortOption: "recommended",
  });
}
