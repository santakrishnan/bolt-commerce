import { SAVED_REGISTRY_STALE_TIME } from "@config/queries/constants";
import {
  getAllSearchHistory,
  type SearchEntry,
} from "@features/search/services/search-history-api";
import { queryOptions } from "@tanstack/react-query";

/**
 * Query key factory for search history.
 *
 * Centralises the query key and options so every consumer
 * (SearchHistoryProvider, search-bar hook, my-garage) reads from the
 * same cache entry.
 *
 * `queryFn` calls the saved-registry proxy (`/api/saved-registry/search-history`)
 * which forwards to the BED Recent Search Service (currently mocked).
 */
export const searchHistoryQueries = {
  all: () =>
    queryOptions({
      queryKey: ["search-history"] as const,
      queryFn: getAllSearchHistory,
      // Show empty list while the first fetch runs
      placeholderData: [] as SearchEntry[],
      staleTime: SAVED_REGISTRY_STALE_TIME,
    }),
} as const;
