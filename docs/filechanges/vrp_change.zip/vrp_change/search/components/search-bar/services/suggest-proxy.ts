/**
 * Proxy autocomplete service
 *
 * Fetches suggestions from `/api/search/suggest` — the same proxy pattern
 * used by the main search API.  In production this endpoint would forward
 * to a backend NLP/autosuggest service; the contract stays the same.
 *
 * @module search-bar/services/suggest-proxy
 */

import type { SuggestResponse } from "~/app/api/search/suggest/route";
import type { AutocompleteService, Suggestion } from "../types";

export class SuggestProxyService implements AutocompleteService {
  private readonly baseUrl: string;
  private quickFiltersCache: string[] | null = null;

  constructor(baseUrl = "/api/search/suggest") {
    this.baseUrl = baseUrl;
  }

  async getSuggestions(query: string, maxResults: number): Promise<Suggestion[]> {
    const trimmed = query.trim();
    if (trimmed.length === 0) {
      return [];
    }

    try {
      const url = `${this.baseUrl}?q=${encodeURIComponent(trimmed)}&max=${maxResults}`;
      const res = await fetch(url);

      if (!res.ok) {
        console.error(`[SuggestProxy] ${res.status} ${res.statusText}`);
        return [];
      }

      const data: SuggestResponse = await res.json();

      // Cache quick filters from the response for getQuickFilters()
      if (data.quickFilters) {
        this.quickFiltersCache = data.quickFilters;
      }

      return data.suggestions;
    } catch (err) {
      console.error("[SuggestProxy] fetch failed:", err);
      return [];
    }
  }

  /**
   * Fetch quick-filter pills from the suggest endpoint.
   * Makes a single request with empty query to get pills from the API.
   */
  async getQuickFilters(): Promise<string[]> {
    if (this.quickFiltersCache) {
      return this.quickFiltersCache;
    }

    try {
      const res = await fetch(`${this.baseUrl}?q=&max=0`);
      if (!res.ok) {
        return [];
      }

      const data: SuggestResponse = await res.json();
      this.quickFiltersCache = data.quickFilters;
      return data.quickFilters;
    } catch {
      return [];
    }
  }
}
