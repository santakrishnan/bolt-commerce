/**
 * Autocomplete service interface and exports
 * @module search-bar/services/autocomplete-service
 */

export type { AutocompleteService, Suggestion } from "../types";
export { MockAutocompleteService } from "./mock-autocomplete";
export { generateQuickFilterPills, NlpAutocompleteService } from "./nlp-autocomplete";
export { SuggestProxyService } from "./suggest-proxy";
export { VehicleAutocompleteService } from "./vehicle-autocomplete";
