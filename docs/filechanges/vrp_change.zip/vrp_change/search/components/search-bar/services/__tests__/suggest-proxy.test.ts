import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { SuggestProxyService } from "../suggest-proxy";

describe("SuggestProxyService", () => {
  let fetchMock: any;

  beforeEach(() => {
    fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("returns empty array for empty or whitespace-only query without calling fetch", async () => {
    const svc = new SuggestProxyService();
    const out = await svc.getSuggestions("   ", 5);
    expect(out).toEqual([]);
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("fetches suggestions, returns them, and caches quickFilters", async () => {
    const data = { suggestions: [{ text: "a", highlight: "b", id: "1" }], quickFilters: ["x"] };
    fetchMock.mockResolvedValue({ ok: true, json: async () => data });

    const svc = new SuggestProxyService("/custom/suggest");

    const res = await svc.getSuggestions("suv", 3);
    expect(res).toEqual(data.suggestions);
    expect(fetchMock).toHaveBeenCalledTimes(1);

    // Calling getQuickFilters should return cached value and not trigger a second fetch
    fetchMock.mockClear();
    const pills = await svc.getQuickFilters();
    expect(pills).toEqual(["x"]);
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("returns empty array on non-OK response and logs an error", async () => {
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => {
      // Suppress console.error for this test
    });
    fetchMock.mockResolvedValue({ ok: false, status: 500, statusText: "Server Error" });

    const svc = new SuggestProxyService();
    const out = await svc.getSuggestions("query", 2);

    expect(out).toEqual([]);
    expect(consoleSpy).toHaveBeenCalled();
    consoleSpy.mockRestore();
  });

  it("returns empty array when fetch throws and logs the error", async () => {
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => {
      // Suppress console.error for this test
    });
    fetchMock.mockRejectedValue(new Error("network"));

    const svc = new SuggestProxyService();
    const out = await svc.getSuggestions("x", 1);

    expect(out).toEqual([]);
    expect(consoleSpy).toHaveBeenCalled();
    consoleSpy.mockRestore();
  });

  it("getQuickFilters makes a single request when not cached and handles non-OK gracefully", async () => {
    // non-ok for quick filters
    fetchMock.mockResolvedValue({ ok: false, status: 400, statusText: "Bad" });
    const svc = new SuggestProxyService();
    const out = await svc.getQuickFilters();
    expect(Array.isArray(out)).toBe(true);
    expect(out.length).toBe(0);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it("encodes query parameters correctly when calling fetch", async () => {
    const data = { suggestions: [], quickFilters: [] };
    fetchMock.mockResolvedValue({ ok: true, json: async () => data });

    const svc = new SuggestProxyService("/api/suggest");
    const query = "special & chars/?#";
    await svc.getSuggestions(query, 7);

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const calledUrl = fetchMock.mock.calls[0][0] as string;
    expect(calledUrl).toContain("/api/suggest");
    expect(calledUrl).toContain("max=7");
    // encoded query should appear in URL
    expect(calledUrl).toContain(encodeURIComponent(query.trim()));
  });
});
