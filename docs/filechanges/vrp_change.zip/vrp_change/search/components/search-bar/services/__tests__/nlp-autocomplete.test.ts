import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// Test constants
const UNDER_REGEX = /under/i;
const MILES_REGEX = /miles?/i;
const HEATED_REGEX = /heated/i;
const TOYOTA_REGEX = /toyota/i;
const CAMRY_REGEX = /camry/i;
const SUV_UNDER_35K_REGEX = /SUV under 35K/i;
const LOW_MILES_REGEX = /Low Miles/i;
const CARS_UNDER_REGEX = /Cars under/i;
const UNDER_PRICE_REGEX = /under \$20,000/i;

// Mock filterSections before importing the module under test so module-level
// constants in `nlp-autocomplete` are derived from predictable data.
vi.mock("@features/search/lib/filter-sections", () => ({
  filterSections: {
    bodyStyle: ["SUV", "Sedan", "Truck", "Coupe"],
    comfortFeatures: ["Heated Seats", "Leather Seats", "Climate Control"],
    techFeatures: ["Bluetooth", "Apple CarPlay"],
    safetyFeatures: ["Airbags", "Lane Assist"],
    exteriorFeatures: ["Sunroof", "Tow Package"],
  },
}));

import { generateQuickFilterPills, NlpAutocompleteService } from "../nlp-autocomplete";

describe("NlpAutocompleteService (integration-like unit tests)", () => {
  let svc: NlpAutocompleteService;
  const vehicles = [
    { id: "v1", make: "Toyota", model: "camry", bodyType: "SUV" },
    { id: "v2", make: "Toyota", model: "camry-le", bodyType: "Sedan" },
    { id: "v3", make: "Honda", model: "civic", bodyType: "Sedan" },
  ];

  beforeEach(() => {
    vi.useFakeTimers();
    svc = new NlpAutocompleteService(vehicles as any);
  });

  afterEach(() => {
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  it("returns suggestions for a body-type query (case-insensitive)", async () => {
    const p = svc.getSuggestions("sUv", 4);
    // Simulated latency inside service is 50ms
    vi.advanceTimersByTime(50);
    const out = await p;

    expect(Array.isArray(out)).toBe(true);
    expect(out.length).toBeGreaterThan(0);
    // Suggestions should reference the body type in text (not coupled to exact format)
    expect(out.some((s) => s.text.toLowerCase().includes("suv"))).toBe(true);
    // Each suggestion must include required fields
    for (const s of out) {
      expect(typeof s.text).toBe("string");
      expect(typeof s.highlight).toBe("string");
      expect(typeof s.id).toBe("string");
    }
  });

  it("returns price-based suggestions when query contains 'under' and respects maxResults", async () => {
    const p = svc.getSuggestions("truck under", 2);
    vi.advanceTimersByTime(50);
    const out = await p;

    expect(out.length).toBeLessThanOrEqual(2);
    // Text should contain 'under' and either the body type or a generic prefix
    expect(out.every((s) => UNDER_REGEX.test(s.text))).toBe(true);
  });

  it("returns mileage suggestions for mileage intent", async () => {
    const p = svc.getSuggestions("low miles", 5);
    vi.advanceTimersByTime(50);
    const out = await p;

    expect(out.length).toBeGreaterThan(0);
    // Highlights should correspond to mileage descriptors (contain 'Miles' / 'Under')
    expect(out.some((s) => MILES_REGEX.test(s.highlight) || UNDER_REGEX.test(s.highlight))).toBe(
      true
    );
  });

  it("returns feature-based suggestions when a popular feature is typed", async () => {
    const p = svc.getSuggestions("heated", 3);
    vi.advanceTimersByTime(50);
    const out = await p;

    expect(out.length).toBeGreaterThan(0);
    // Highlights should include the matched feature text (case-insensitive)
    expect(out.some((s) => HEATED_REGEX.test(s.highlight))).toBe(true);
  });

  it("matches models/makes from inventory (fallback template) without depending on internal ids", async () => {
    const p = svc.getSuggestions("cam", 5);
    vi.advanceTimersByTime(50);
    const out = await p;

    // We expect at least one suggestion where make is present and highlight contains model fragment
    expect(out.some((s) => TOYOTA_REGEX.test(s.text))).toBe(true);
    expect(out.some((s) => CAMRY_REGEX.test(s.highlight))).toBe(true);
  });

  it("normalizes hyphens/underscores and trims whitespace before matching", async () => {
    const p = svc.getSuggestions("  camry-le  ", 3);
    vi.advanceTimersByTime(50);
    const out = await p;

    expect(out.length).toBeGreaterThan(0);
    // Ensure at least one suggestion refers to Camry
    expect(out.some((s) => CAMRY_REGEX.test(s.highlight))).toBe(true);
  });

  it("returns empty array for empty or whitespace-only queries", async () => {
    const p = svc.getSuggestions("   ", 5);
    vi.advanceTimersByTime(50);
    const out = await p;
    expect(Array.isArray(out)).toBe(true);
    expect(out.length).toBe(0);
  });
});

describe("generateQuickFilterPills", () => {
  it("produces pills reflecting top body types and common filters", () => {
    const vehicles = [
      { id: "1", make: "A", model: "x", bodyType: "SUV" },
      { id: "2", make: "B", model: "y", bodyType: "SUV" },
      { id: "3", make: "C", model: "z", bodyType: "Sedan" },
    ];

    const pills = generateQuickFilterPills(vehicles as any);

    // Should be an array of strings
    expect(Array.isArray(pills)).toBe(true);
    expect(pills.length).toBeGreaterThanOrEqual(3);

    // Top body type should be present as a '<Body> under 35K' pill
    expect(pills.some((p) => SUV_UNDER_35K_REGEX.test(p))).toBe(true);

    // Must include the 'Low Miles' and a price-based pill
    expect(pills.some((p) => LOW_MILES_REGEX.test(p))).toBe(true);
    expect(pills.some((p) => CARS_UNDER_REGEX.test(p) || UNDER_PRICE_REGEX.test(p))).toBe(true);
  });
});
