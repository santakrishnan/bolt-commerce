/**
 * Unit tests for PillsSuggestions component
 * @module search-bar/__tests__/pills-suggestions
 *
 * This test suite ensures the PillsSuggestions component:
 * - Renders suggestions as pills correctly
 * - Handles user interactions (click, keyboard)
 * - Manages animation states
 * - Supports above/below placement
 * - Shows quick filters when appropriate
 * - Implements proper accessibility
 * - Handles edge cases
 */

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { PillsSuggestions } from "../pills-suggestions";
import type { Suggestion } from "../types";

// Mock @tfs-ucmp/ui Button component
vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({
    children,
    onClick,
    onKeyDown,
    onMouseEnter,
    className,
    id,
    role,
    tabIndex,
    type,
    variant,
    "aria-selected": ariaSelected,
  }: {
    children: React.ReactNode;
    onClick?: () => void;
    onKeyDown?: (e: React.KeyboardEvent) => void;
    onMouseEnter?: () => void;
    className?: string;
    id?: string;
    role?: string;
    tabIndex?: number;
    type?: string;
    variant?: string;
    "aria-selected"?: boolean;
  }) => (
    // biome-ignore lint/a11y/useAriaPropsSupportedByRole: role is dynamically set to "option" when aria-selected is used
    <button
      aria-selected={ariaSelected}
      className={className}
      data-variant={variant}
      id={id}
      onClick={onClick}
      onKeyDown={onKeyDown}
      onMouseEnter={onMouseEnter}
      role={role || (ariaSelected === undefined ? undefined : "option")}
      tabIndex={tabIndex}
      type={type as "button" | "submit" | "reset" | undefined}
    >
      {children}
    </button>
  ),
}));

// Mock cn utility
vi.mock("@/lib/utils", () => ({
  cn: (...classes: (string | boolean | undefined)[]) => classes.filter(Boolean).join(" "),
}));

describe("PillsSuggestions", () => {
  const mockOnSelect = vi.fn();
  const mockOnSuggestionFocus = vi.fn();
  const mockOnQuickFilterSelect = vi.fn();

  const mockSuggestions: Suggestion[] = [
    { id: "1", text: "Search for", highlight: "SUV" },
    { id: "2", text: "Looking for", highlight: "Hybrid Sedan" },
    { id: "3", text: "", highlight: "Truck under 30k" },
  ];

  const defaultProps = {
    suggestions: mockSuggestions,
    isAnimating: false,
    onSelect: mockOnSelect,
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Rendering", () => {
    it("renders suggestion pills correctly", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const listbox = screen.getByRole("listbox");
      expect(listbox).toBeInTheDocument();
      expect(listbox).toHaveAttribute("aria-label", "Search suggestions");
      expect(listbox).toHaveAttribute("id", "search-suggestions");
    });

    it("renders all suggestions as pills", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const pills = screen.getAllByRole("option");
      expect(pills).toHaveLength(3);
    });

    it("renders suggestion with text and highlight", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const firstPill = screen.getAllByRole("option")[0] as HTMLElement;
      expect(firstPill).toHaveTextContent("Search for");
      expect(firstPill).toHaveTextContent("SUV");
    });

    it("renders suggestion with only highlight when text is empty", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const thirdPill = screen.getAllByRole("option")[2] as HTMLElement;
      expect(thirdPill).toHaveTextContent("Truck under 30k");
      expect(thirdPill.querySelector(".font-semibold")).toBeInTheDocument();
    });

    it("returns null when no suggestions and no quick filters", () => {
      const { container } = render(<PillsSuggestions {...defaultProps} suggestions={[]} />);

      expect(container.firstChild).toBeNull();
    });

    it("returns null when suggestions empty and quickFilters empty", () => {
      const { container } = render(
        <PillsSuggestions {...defaultProps} quickFilters={[]} suggestions={[]} />
      );

      expect(container.firstChild).toBeNull();
    });

    it("renders with correct button type", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const pills = screen.getAllByRole("option");
      for (const pill of pills) {
        expect(pill).toHaveAttribute("type", "button");
      }
    });

    it("renders with search variant", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const pills = screen.getAllByRole("option");
      for (const pill of pills) {
        expect(pill).toHaveAttribute("data-variant", "search");
      }
    });

    it("renders with correct tabIndex", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const pills = screen.getAllByRole("option");
      for (const pill of pills) {
        expect(pill).toHaveAttribute("tabIndex", "-1");
      }
    });

    it("uses suggestion id when available", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const firstPill = screen.getAllByRole("option")[0] as HTMLElement;
      expect(firstPill).toHaveAttribute("id", "suggestion-0");
    });

    it("generates key from text and index when id is missing", () => {
      const suggestionsWithoutId: Suggestion[] = [{ text: "Test", highlight: "Query" }];

      render(<PillsSuggestions {...defaultProps} suggestions={suggestionsWithoutId} />);

      const pill = screen.getByRole("option");
      expect(pill).toBeInTheDocument();
    });
  });

  describe("Placement", () => {
    it("applies below placement by default", () => {
      const { container } = render(<PillsSuggestions {...defaultProps} />);

      const wrapper = container.querySelector('[aria-label="Search suggestions"]');
      expect(wrapper?.className).toContain("mt-sm");
      expect(wrapper?.className).not.toContain("mb-sm");
    });

    it("applies above placement when specified", () => {
      const { container } = render(<PillsSuggestions {...defaultProps} pillsPlacement="above" />);

      const wrapper = container.querySelector('[aria-label="Search suggestions"]');
      expect(wrapper?.className).toContain("mb-sm");
      expect(wrapper?.className).not.toContain("mt-sm");
    });

    it("applies correct inner margin for below placement", () => {
      const { container } = render(<PillsSuggestions {...defaultProps} pillsPlacement="below" />);

      const innerDiv = container.querySelector(".scrollbar-hide");
      expect(innerDiv?.className).toContain("mt-6");
      expect(innerDiv?.className).toContain("md:mt-4");
    });

    it("applies correct inner margin for above placement", () => {
      const { container } = render(<PillsSuggestions {...defaultProps} pillsPlacement="above" />);

      const innerDiv = container.querySelector(".scrollbar-hide");
      expect(innerDiv?.className).toContain("mb-4");
    });
  });

  describe("Animation States", () => {
    it("applies animation classes when isAnimating is true with below placement", () => {
      const { container } = render(
        <PillsSuggestions {...defaultProps} isAnimating={true} pillsPlacement="below" />
      );

      const wrapper = container.querySelector('[aria-label="Search suggestions"]');
      expect(wrapper?.className).toContain("-translate-y-1");
      expect(wrapper?.className).toContain("opacity-0");
    });

    it("applies animation classes when isAnimating is true with above placement", () => {
      const { container } = render(
        <PillsSuggestions {...defaultProps} isAnimating={true} pillsPlacement="above" />
      );

      const wrapper = container.querySelector('[aria-label="Search suggestions"]');
      expect(wrapper?.className).toContain("translate-y-1");
      expect(wrapper?.className).toContain("opacity-0");
    });

    it("applies visible classes when isAnimating is false", () => {
      const { container } = render(<PillsSuggestions {...defaultProps} isAnimating={false} />);

      const wrapper = container.querySelector('[aria-label="Search suggestions"]');
      expect(wrapper?.className).toContain("translate-y-0");
      expect(wrapper?.className).toContain("opacity-100");
    });

    it("includes transition classes", () => {
      const { container } = render(<PillsSuggestions {...defaultProps} />);

      const wrapper = container.querySelector('[aria-label="Search suggestions"]');
      expect(wrapper?.className).toContain("transition-all");
      expect(wrapper?.className).toContain("duration-200");
      expect(wrapper?.className).toContain("ease-out");
    });
  });

  describe("User Interactions - Click", () => {
    it("calls onSelect when a pill is clicked", async () => {
      const user = userEvent.setup();
      render(<PillsSuggestions {...defaultProps} />);

      const firstPill = screen.getAllByRole("option")[0] as HTMLElement;
      await user.click(firstPill);

      expect(mockOnSelect).toHaveBeenCalledTimes(1);
      expect(mockOnSelect).toHaveBeenCalledWith(mockSuggestions[0]);
    });

    it("calls onSelect with correct suggestion for each pill", async () => {
      const user = userEvent.setup();
      render(<PillsSuggestions {...defaultProps} />);

      const pills = screen.getAllByRole("option");

      await user.click(pills[1] as HTMLElement);
      expect(mockOnSelect).toHaveBeenCalledWith(mockSuggestions[1]);

      await user.click(pills[2] as HTMLElement);
      expect(mockOnSelect).toHaveBeenCalledWith(mockSuggestions[2]);
    });

    it("handles multiple clicks correctly", async () => {
      const user = userEvent.setup();
      render(<PillsSuggestions {...defaultProps} />);

      const firstPill = screen.getAllByRole("option")[0] as HTMLElement;

      await user.click(firstPill);
      await user.click(firstPill);

      expect(mockOnSelect).toHaveBeenCalledTimes(2);
    });
  });

  describe("User Interactions - Keyboard", () => {
    it("calls onSelect when Enter key is pressed", async () => {
      const user = userEvent.setup();
      render(<PillsSuggestions {...defaultProps} />);

      const firstPill = screen.getAllByRole("option")[0] as HTMLElement;
      firstPill.focus();
      await user.keyboard("{Enter}");

      expect(mockOnSelect).toHaveBeenCalledTimes(1);
      expect(mockOnSelect).toHaveBeenCalledWith(mockSuggestions[0]);
    });

    it("calls onSelect when Space key is pressed", async () => {
      const user = userEvent.setup();
      render(<PillsSuggestions {...defaultProps} />);

      const firstPill = screen.getAllByRole("option")[0] as HTMLElement;
      firstPill.focus();
      await user.keyboard(" ");

      expect(mockOnSelect).toHaveBeenCalledTimes(1);
      expect(mockOnSelect).toHaveBeenCalledWith(mockSuggestions[0]);
    });

    it("prevents default behavior on Enter key", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const firstPill = screen.getAllByRole("option")[0] as HTMLElement;
      firstPill.focus();

      const enterEvent = new KeyboardEvent("keydown", {
        key: "Enter",
        bubbles: true,
        cancelable: true,
      });

      const preventDefaultSpy = vi.spyOn(enterEvent, "preventDefault");
      firstPill.dispatchEvent(enterEvent);

      expect(preventDefaultSpy).toHaveBeenCalled();
    });

    it("prevents default behavior on Space key", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const firstPill = screen.getAllByRole("option")[0] as HTMLElement;
      firstPill.focus();

      const spaceEvent = new KeyboardEvent("keydown", {
        key: " ",
        bubbles: true,
        cancelable: true,
      });

      const preventDefaultSpy = vi.spyOn(spaceEvent, "preventDefault");
      firstPill.dispatchEvent(spaceEvent);

      expect(preventDefaultSpy).toHaveBeenCalled();
    });

    it("does not call onSelect for other keys", async () => {
      const user = userEvent.setup();
      render(<PillsSuggestions {...defaultProps} />);

      const firstPill = screen.getAllByRole("option")[0] as HTMLElement;
      firstPill.focus();
      await user.keyboard("{ArrowDown}");
      await user.keyboard("{Tab}");

      expect(mockOnSelect).not.toHaveBeenCalled();
    });
  });

  describe("User Interactions - Mouse", () => {
    it("calls onSuggestionFocus when mouse enters a pill", async () => {
      const user = userEvent.setup();
      render(<PillsSuggestions {...defaultProps} onSuggestionFocus={mockOnSuggestionFocus} />);

      const firstPill = screen.getAllByRole("option")[0] as HTMLElement;
      await user.hover(firstPill);

      expect(mockOnSuggestionFocus).toHaveBeenCalledTimes(1);
      expect(mockOnSuggestionFocus).toHaveBeenCalledWith(0);
    });

    it("calls onSuggestionFocus with correct index for each pill", async () => {
      const user = userEvent.setup();
      render(<PillsSuggestions {...defaultProps} onSuggestionFocus={mockOnSuggestionFocus} />);

      const pills = screen.getAllByRole("option");

      await user.hover(pills[1] as HTMLElement);
      expect(mockOnSuggestionFocus).toHaveBeenCalledWith(1);

      await user.hover(pills[2] as HTMLElement);
      expect(mockOnSuggestionFocus).toHaveBeenCalledWith(2);
    });

    it("does not crash when onSuggestionFocus is not provided", () => {
      const user = userEvent.setup();
      render(<PillsSuggestions {...defaultProps} />);

      const firstPill = screen.getAllByRole("option")[0] as HTMLElement;

      expect(async () => {
        await user.hover(firstPill);
      }).not.toThrow();
    });
  });

  describe("Active State", () => {
    it("applies active styling when activeDescendantId matches", () => {
      render(<PillsSuggestions {...defaultProps} activeDescendantId="suggestion-1" />);

      const pills = screen.getAllByRole("option");
      expect(pills[1]).toHaveAttribute("aria-selected", "true");
      expect((pills[1] as HTMLElement).className).toContain("opacity-80");
    });

    it("does not apply active styling to non-active pills", () => {
      render(<PillsSuggestions {...defaultProps} activeDescendantId="suggestion-1" />);

      const pills = screen.getAllByRole("option");
      expect(pills[0]).toHaveAttribute("aria-selected", "false");
      expect((pills[0] as HTMLElement).className).not.toContain("opacity-80");
    });

    it("handles no active descendant", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const pills = screen.getAllByRole("option");
      for (const pill of pills) {
        expect(pill).toHaveAttribute("aria-selected", "false");
      }
    });
  });

  describe("Quick Filters", () => {
    it("renders quick filters when suggestions are empty", () => {
      const quickFilters = ["Hybrid", "SUV", "Under $30k"];

      render(<PillsSuggestions {...defaultProps} quickFilters={quickFilters} suggestions={[]} />);

      const pills = screen.getAllByRole("option");
      expect(pills).toHaveLength(3);
      expect(pills[0]).toHaveTextContent("Hybrid");
      expect(pills[1]).toHaveTextContent("SUV");
      expect(pills[2]).toHaveTextContent("Under $30k");
    });

    it("does not render quick filters when suggestions exist", () => {
      const quickFilters = ["Hybrid", "SUV"];

      render(
        <PillsSuggestions
          {...defaultProps}
          quickFilters={quickFilters}
          suggestions={mockSuggestions}
        />
      );

      const pills = screen.getAllByRole("option");
      expect(pills).toHaveLength(mockSuggestions.length);
      expect(screen.queryByText("Hybrid")).not.toBeInTheDocument();
    });

    it("calls onQuickFilterSelect when quick filter is clicked", async () => {
      const user = userEvent.setup();
      const quickFilters = ["Hybrid", "SUV"];

      render(
        <PillsSuggestions
          {...defaultProps}
          onQuickFilterSelect={mockOnQuickFilterSelect}
          quickFilters={quickFilters}
          suggestions={[]}
        />
      );

      const firstFilter = screen.getAllByRole("option")[0] as HTMLElement;
      await user.click(firstFilter);

      expect(mockOnQuickFilterSelect).toHaveBeenCalledTimes(1);
      expect(mockOnQuickFilterSelect).toHaveBeenCalledWith("Hybrid");
    });

    it("does not crash when onQuickFilterSelect is not provided", () => {
      const user = userEvent.setup();
      const quickFilters = ["Hybrid"];

      render(<PillsSuggestions {...defaultProps} quickFilters={quickFilters} suggestions={[]} />);

      const filter = screen.getByRole("option");

      expect(async () => {
        await user.click(filter);
      }).not.toThrow();
    });

    it("renders quick filters with correct styling", () => {
      const quickFilters = ["Test Filter"];

      render(<PillsSuggestions {...defaultProps} quickFilters={quickFilters} suggestions={[]} />);

      const filter = screen.getByRole("option");
      expect(filter.className).toContain("rounded-full");
      expect(filter.className).toContain("bg-white");
      expect(filter.className).toContain("cursor-pointer");
    });
  });

  describe("Accessibility", () => {
    it("has correct ARIA role for container", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const listbox = screen.getByRole("listbox");
      expect(listbox).toBeInTheDocument();
    });

    it("has correct ARIA role for pills", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const pills = screen.getAllByRole("option");
      expect(pills).toHaveLength(mockSuggestions.length);
    });

    it("has aria-label on container", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const listbox = screen.getByRole("listbox");
      expect(listbox).toHaveAttribute("aria-label", "Search suggestions");
    });

    it("sets aria-selected correctly", () => {
      render(<PillsSuggestions {...defaultProps} activeDescendantId="suggestion-0" />);

      const pills = screen.getAllByRole("option");
      expect(pills[0]).toHaveAttribute("aria-selected", "true");
      expect(pills[1]).toHaveAttribute("aria-selected", "false");
    });

    it("has unique ids for each pill", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const pills = screen.getAllByRole("option");
      const ids = pills.map((pill) => pill.id);
      const uniqueIds = new Set(ids);

      expect(uniqueIds.size).toBe(pills.length);
    });
  });

  describe("Styling and Layout", () => {
    it("applies scrollbar-hide class", () => {
      const { container } = render(<PillsSuggestions {...defaultProps} />);

      const scrollContainer = container.querySelector(".scrollbar-hide");
      expect(scrollContainer).toBeInTheDocument();
    });

    it("applies overflow-x-auto for horizontal scrolling", () => {
      const { container } = render(<PillsSuggestions {...defaultProps} />);

      const scrollContainer = container.querySelector(".overflow-x-auto");
      expect(scrollContainer).toBeInTheDocument();
    });

    it("applies correct inline styles for scrolling", () => {
      const { container } = render(<PillsSuggestions {...defaultProps} />);

      const innerDiv = container.querySelector(".scrollbar-hide") as HTMLElement;
      const style = innerDiv.style as unknown as Record<string, string>;
      expect(style.WebkitOverflowScrolling).toBe("touch");
      expect(style.scrollbarWidth).toBe("none");
      expect(style.msOverflowStyle).toBe("none");
    });

    it("applies whitespace-nowrap class", () => {
      const { container } = render(<PillsSuggestions {...defaultProps} />);

      const scrollContainer = container.querySelector(".whitespace-nowrap");
      expect(scrollContainer).toBeInTheDocument();
    });

    it("applies responsive classes", () => {
      const { container } = render(<PillsSuggestions {...defaultProps} />);

      const innerDiv = container.querySelector(".scrollbar-hide");
      expect(innerDiv?.className).toContain("md:flex-wrap");
      expect(innerDiv?.className).toContain("md:justify-end");
      expect(innerDiv?.className).toContain("md:overflow-x-visible");
    });

    it("applies pill styling classes", () => {
      render(<PillsSuggestions {...defaultProps} />);

      const firstPill = screen.getAllByRole("option")[0] as HTMLElement;
      expect(firstPill.className).toContain("rounded-full");
      expect(firstPill.className).toContain("bg-white");
      expect(firstPill.className).toContain("items-center");
    });
  });

  describe("Edge Cases", () => {
    it("handles empty suggestions array", () => {
      const { container } = render(<PillsSuggestions {...defaultProps} suggestions={[]} />);

      expect(container.firstChild).toBeNull();
    });

    it("handles single suggestion", () => {
      const singleSuggestion: Suggestion[] = mockSuggestions.slice(0, 1);

      render(<PillsSuggestions {...defaultProps} suggestions={singleSuggestion} />);

      const pills = screen.getAllByRole("option");
      expect(pills).toHaveLength(1);
    });

    it("handles large number of suggestions", () => {
      const manySuggestions: Suggestion[] = Array.from({ length: 50 }, (_, i) => ({
        id: `${i}`,
        text: `Suggestion ${i}`,
        highlight: `Query ${i}`,
      }));

      render(<PillsSuggestions {...defaultProps} suggestions={manySuggestions} />);

      const pills = screen.getAllByRole("option");
      expect(pills).toHaveLength(50);
    });

    it("handles suggestions with very long text", () => {
      const longTextSuggestion: Suggestion[] = [
        {
          id: "long",
          text: "This is a very long suggestion text that might wrap or overflow",
          highlight: "with an equally long highlighted portion that needs to be displayed",
        },
      ];

      render(<PillsSuggestions {...defaultProps} suggestions={longTextSuggestion} />);

      const pill = screen.getByRole("option");
      expect(pill).toBeInTheDocument();
      expect(pill.className).toContain("whitespace-nowrap");
    });

    it("handles suggestions with special characters", () => {
      const specialCharSuggestions: Suggestion[] = [
        { id: "1", text: "Search for", highlight: "<SUV & Truck>" },
        { id: "2", text: "Price:", highlight: "$25,000" },
      ];

      render(<PillsSuggestions {...defaultProps} suggestions={specialCharSuggestions} />);

      expect(screen.getByText("<SUV & Truck>")).toBeInTheDocument();
      expect(screen.getByText("$25,000")).toBeInTheDocument();
    });

    it("handles missing id gracefully", () => {
      const noIdSuggestions: Suggestion[] = [{ text: "Test", highlight: "Query" }];

      render(<PillsSuggestions {...defaultProps} suggestions={noIdSuggestions} />);

      const pill = screen.getByRole("option");
      expect(pill).toBeInTheDocument();
    });

    it("handles undefined callbacks gracefully", () => {
      render(
        <PillsSuggestions
          isAnimating={false}
          onSelect={mockOnSelect}
          suggestions={mockSuggestions}
        />
      );

      const pill = screen.getAllByRole("option")[0];
      expect(pill).toBeInTheDocument();
    });

    it("handles rapid clicks", async () => {
      const user = userEvent.setup();
      render(<PillsSuggestions {...defaultProps} />);

      const firstPill = screen.getAllByRole("option")[0] as HTMLElement;

      await user.click(firstPill);
      await user.click(firstPill);
      await user.click(firstPill);

      expect(mockOnSelect).toHaveBeenCalledTimes(3);
    });

    it("handles switching between suggestions and quick filters", () => {
      const quickFilters = ["Filter1", "Filter2"];
      const { rerender } = render(
        <PillsSuggestions
          {...defaultProps}
          quickFilters={quickFilters}
          suggestions={mockSuggestions}
        />
      );

      let pills = screen.getAllByRole("option");
      expect(pills).toHaveLength(mockSuggestions.length);

      rerender(<PillsSuggestions {...defaultProps} quickFilters={quickFilters} suggestions={[]} />);

      pills = screen.getAllByRole("option");
      expect(pills).toHaveLength(quickFilters.length);
    });
  });

  describe("Component Props", () => {
    it("accepts all required props", () => {
      expect(() => {
        render(<PillsSuggestions {...defaultProps} />);
      }).not.toThrow();
    });

    it("accepts all optional props", () => {
      expect(() => {
        render(
          <PillsSuggestions
            {...defaultProps}
            activeDescendantId="suggestion-0"
            onQuickFilterSelect={mockOnQuickFilterSelect}
            onSuggestionFocus={mockOnSuggestionFocus}
            pillsPlacement="above"
            quickFilters={["Test"]}
          />
        );
      }).not.toThrow();
    });

    it("handles prop changes correctly", () => {
      const { rerender } = render(<PillsSuggestions {...defaultProps} />);

      rerender(<PillsSuggestions {...defaultProps} isAnimating={true} />);

      const listbox = screen.getByRole("listbox");
      expect(listbox).toBeInTheDocument();
    });
  });

  describe("Integration", () => {
    it("handles complete user interaction flow", async () => {
      const user = userEvent.setup();
      render(<PillsSuggestions {...defaultProps} onSuggestionFocus={mockOnSuggestionFocus} />);

      const firstPill = screen.getAllByRole("option")[0] as HTMLElement;

      // Hover
      await user.hover(firstPill);
      expect(mockOnSuggestionFocus).toHaveBeenCalledWith(0);

      // Click
      await user.click(firstPill);
      expect(mockOnSelect).toHaveBeenCalledWith(mockSuggestions[0]);
    });

    it("handles animation state changes during interaction", async () => {
      const user = userEvent.setup();
      const { rerender } = render(<PillsSuggestions {...defaultProps} isAnimating={true} />);

      rerender(<PillsSuggestions {...defaultProps} isAnimating={false} />);

      const firstPill = screen.getAllByRole("option")[0] as HTMLElement;
      await user.click(firstPill);

      expect(mockOnSelect).toHaveBeenCalled();
    });
  });
});
