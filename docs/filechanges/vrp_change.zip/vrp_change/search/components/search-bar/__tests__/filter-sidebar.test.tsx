import { describe, expect, it, vi } from "vitest";

// Mock the implementation module before importing the re-exporting barrel.
vi.mock("../../filter-sidebar", () => ({
  defaultFilterState: { someKey: "someValue" },
  FilterSidebar: () => "MOCK_COMPONENT",
}));

import * as reexport from "../../filter-sidebar";

describe("filter-sidebar barrel exports", () => {
  it("forwards runtime exports from ./filter-sidebar/index", () => {
    expect(reexport.defaultFilterState).toEqual({ someKey: "someValue" });
    // verify the forwarded component returns the mocked marker value when invoked
    expect(typeof reexport.FilterSidebar).toBe("function");
    expect((reexport.FilterSidebar as any)()).toBe("MOCK_COMPONENT");
  });

  it("runtime exports have expected shapes (no implementation coupling)", () => {
    expect(typeof reexport.defaultFilterState).toBe("object");
    expect(typeof reexport.FilterSidebar).toBe("function");
  });
});
