import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

// Mock filterSections used by the SidebarFilters component
vi.mock("@features/search/lib/filter-sections", () => ({
  filterSections: {
    price: {
      quickRanges: ["$0 - $10k", "$10k - $20k", "$20k - $30k"],
      minDropdown: ["$0", "$5,000"],
      maxDropdown: ["$15,000", "$30,000"],
    },
    bodyStyle: ["Sedan", "SUV", "Truck"],
    exteriorColors: ["Red", "Blue", "White"],
    interiorColors: ["Black", "Beige"],
    fuelTypes: ["Hybrid (Hybrid)", "Gasoline (Gasoline)", "Electric (Electric)"],
    popularModels: ["Corolla", "Camry", "RAV4", "Highlander"],
    makeModelSearchPlaceholder: "Search models",
    drivetrains: ["FWD", "AWD", "RWD"],
    transmissions: ["Automatic", "Manual"],
    mileage: {
      quickFilters: ["Under 30k", "Under 60k"],
      minDropdown: ["0", "10,000"],
      maxDropdown: ["50,000", "100,000"],
    },
    year: {
      fromOptions: ["2020", "2021"],
      toOptions: ["2024", "2025"],
      popularRanges: ["2020-2024"],
    },
    safetyFeatures: ["Blind Spot Monitor", "Lane Departure"],
    comfortFeatures: ["Heated Seats", "Ventilated Seats"],
    techFeatures: ["Apple CarPlay", "Android Auto"],
    exteriorFeatures: ["Sunroof", "LED Headlights"],
    performanceFeatures: ["Sport Mode", "Paddle Shifters"],
    seatingCapacity: ["5 Seats", "7 Seats"],
  },
}));

// Simple production-like mock for CustomChips that exposes props as attributes
vi.mock("@shared/components/custom-chips", () => ({
  CustomChips: ({ label, onClick, type, className, prefix }: any) => (
    <button
      data-class={className}
      data-prefix={prefix ? "true" : "false"}
      data-testid={`chip-${label}`}
      data-type={type}
      onClick={onClick}
      type="button"
    >
      {label}
    </button>
  ),
}));

// Mock the color map used for color swatches
vi.mock("@shared/components/color-swatch", () => ({
  colorMap: {
    Red: "bg-red-500",
    Black: "bg-black",
    Blue: "bg-blue-500",
    White: "bg-white",
    Beige: "bg-beige-500",
  },
}));

// Mock FilterSection so tests can observe isLoading/title and render children
vi.mock("../filter-section", () => ({
  FilterSection: ({ title, isLoading, children }: any) => (
    <section data-isloading={isLoading ? "true" : "false"} data-testid={`section-${title}`}>
      {children}
    </section>
  ),
}));

import { SidebarFilters } from "../sidebar-filters";

describe("SidebarFilters", () => {
  const baseDraftState = {
    selectedPriceQuick: "",
    selectedYearQuick: "",
    selectedMileage: "",
    selectedBodyStyles: [] as string[],
    selectedExteriorColors: [] as string[],
    selectedInteriorColors: [] as string[],
    selectedFuelTypes: [] as string[],
    selectedModels: [] as string[],
    selectedSafetyFeatures: [] as string[],
    selectedComfortFeatures: [] as string[],
    selectedTechFeatures: [] as string[],
    selectedExteriorFeatures: [] as string[],
    selectedPerformanceFeatures: [] as string[],
    selectedSeatingCapacity: [] as string[],
    selectedDrivetrains: [] as string[],
    selectedTransmissions: [] as string[],
    inspection160: false,
  };

  const mockAvailableFilters = {
    bodyStyles: ["Sedan", "SUV"],
    comfortFeatures: ["Heated Seats"],
    drivetrains: ["FWD", "AWD"],
    exteriorColors: ["Red", "Blue"],
    exteriorFeatures: ["Sunroof"],
    fuelTypes: ["Hybrid", "Gasoline"],
    interiorColors: ["Black"],
    models: ["Corolla", "Camry"],
    performanceFeatures: ["Sport Mode"],
    safetyFeatures: ["Blind Spot Monitor"],
    seatingCapacity: ["5 Seats"],
    techFeatures: ["Apple CarPlay"],
    transmissions: ["Automatic"],
    hasInspection160: true,
    totalCount: 100,
  };

  it("renders all filter sections with proper structure", () => {
    render(
      <SidebarFilters
        draftState={baseDraftState}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={null}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    expect(screen.getByTestId("section-Price")).toBeInTheDocument();
    expect(screen.getByTestId("section-Year")).toBeInTheDocument();
    expect(screen.getByTestId("section-Mileage")).toBeInTheDocument();
    expect(screen.getByTestId("section-Body Style")).toBeInTheDocument();
    expect(screen.getByTestId("section-Exterior Color")).toBeInTheDocument();
    expect(screen.getByTestId("section-Interior Color")).toBeInTheDocument();
    expect(screen.getByTestId("section-Make & Model")).toBeInTheDocument();
    expect(screen.getByTestId("section-Fuel Type")).toBeInTheDocument();
    expect(screen.getByTestId("section-Features & Technology")).toBeInTheDocument();
    expect(screen.getByTestId("section-Inspection")).toBeInTheDocument();
    expect(screen.getByTestId("section-Drivetrain")).toBeInTheDocument();
    expect(screen.getByTestId("section-Transmission")).toBeInTheDocument();
  });

  it("toggles quick price range via handleDraftChange and toggles back", async () => {
    const user = userEvent.setup();
    const handleDraftChange = vi.fn();

    const { rerender } = render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={handleDraftChange}
        handleScroll={vi.fn()}
        openSection={null}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    const chip = screen.getByTestId("chip-$0 - $10k");
    await user.click(chip);
    expect(handleDraftChange).toHaveBeenCalledTimes(1);
    expect(handleDraftChange).toHaveBeenCalledWith("selectedPriceQuick", "$0 - $10k");

    // Re-render with the same selection to assert toggling back to empty string
    handleDraftChange.mockClear();
    rerender(
      <SidebarFilters
        draftState={{ ...baseDraftState, selectedPriceQuick: "$0 - $10k" }}
        handleDraftChange={handleDraftChange}
        handleScroll={vi.fn()}
        openSection={null}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    const chipSelected = screen.getByTestId("chip-$0 - $10k");
    await user.click(chipSelected);
    expect(handleDraftChange).toHaveBeenCalledWith("selectedPriceQuick", "");
  });

  it("toggles year range via handleDraftChange", async () => {
    const user = userEvent.setup();
    const handleDraftChange = vi.fn();

    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={handleDraftChange}
        handleScroll={vi.fn()}
        openSection={"Year"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    const chip = screen.getByTestId("chip-2020-2024");
    await user.click(chip);
    expect(handleDraftChange).toHaveBeenCalledWith("selectedYearQuick", "2020-2024");
  });

  it("toggles mileage filter via handleDraftChange", async () => {
    const user = userEvent.setup();
    const handleDraftChange = vi.fn();

    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={handleDraftChange}
        handleScroll={vi.fn()}
        openSection={"Mileage"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    const chip = screen.getByTestId("chip-Under 30k");
    await user.click(chip);
    expect(handleDraftChange).toHaveBeenCalledWith("selectedMileage", "Under 30k");
  });

  it("passes unavailable type when availableFilters lacks a body style and calls toggleArrayFilter", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();

    render(
      <SidebarFilters
        availableFilters={mockAvailableFilters}
        draftState={{ ...baseDraftState, selectedBodyStyles: [] }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Body Style"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={toggleArrayFilter}
        toggleSection={vi.fn()}
      />
    );

    const truckChip = screen.getByTestId("chip-Truck");
    // unavailable because availableFilters.bodyStyles does not include "Truck"
    expect(truckChip.dataset.type).toBe("unavailable");

    await user.click(truckChip);
    expect(toggleArrayFilter).toHaveBeenCalledTimes(1);
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedBodyStyles", [], "Truck");
  });

  it("marks body style chip as selected when included in selectedBodyStyles", () => {
    render(
      <SidebarFilters
        availableFilters={mockAvailableFilters}
        draftState={{ ...baseDraftState, selectedBodyStyles: ["Sedan"] }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Body Style"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    const sedanChip = screen.getByTestId("chip-Sedan");
    expect(sedanChip.dataset.type).toBe("selected");
  });

  it("renders exterior color chips with color swatches", () => {
    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Exterior Color"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    const redChip = screen.getByTestId("chip-Red");
    expect(redChip.dataset.prefix).toBe("true");
  });

  it("toggles exterior color via toggleArrayFilter", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();

    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Exterior Color"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={toggleArrayFilter}
        toggleSection={vi.fn()}
      />
    );

    const blueChip = screen.getByTestId("chip-Blue");
    await user.click(blueChip);
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedExteriorColors", [], "Blue");
  });

  it("renders interior color chips with color swatches", () => {
    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Interior Color"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    const blackChip = screen.getByTestId("chip-Black");
    expect(blackChip.dataset.prefix).toBe("true");
  });

  it("renders model search input with placeholder", () => {
    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Make & Model"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    const searchInput = screen.getByPlaceholderText("Search models");
    expect(searchInput).toBeInTheDocument();
  });

  it("toggles model selection via toggleArrayFilter", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();

    render(
      <SidebarFilters
        availableFilters={mockAvailableFilters}
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Make & Model"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={toggleArrayFilter}
        toggleSection={vi.fn()}
      />
    );

    const corollaChip = screen.getByTestId("chip-Corolla");
    await user.click(corollaChip);
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedModels", [], "Corolla");
  });

  it("resolves fuel labels with parentheses correctly and marks available", () => {
    const toggleArrayFilter = vi.fn();

    render(
      <SidebarFilters
        availableFilters={mockAvailableFilters}
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Fuel Type"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={toggleArrayFilter}
        toggleSection={vi.fn()}
      />
    );

    const hybridChip = screen.getByTestId("chip-Hybrid (Hybrid)");
    // fuelChipAvailable should consider the part before " (" and find "Hybrid"
    expect(hybridChip.dataset.type).toBe("unselected");
  });

  it("marks fuel type as unavailable when not in availableFilters", () => {
    render(
      <SidebarFilters
        availableFilters={mockAvailableFilters}
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Fuel Type"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    const electricChip = screen.getByTestId("chip-Electric (Electric)");
    expect(electricChip.dataset.type).toBe("unavailable");
  });

  it("renders all feature subsections in Features & Technology", () => {
    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Features & Technology"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    expect(screen.getByText("Safety & Drive Assist")).toBeInTheDocument();
    expect(screen.getByText("Comfort & Convenience")).toBeInTheDocument();
    expect(screen.getByText("Technology & Entertainment")).toBeInTheDocument();
    expect(screen.getByText("Exterior & Lighting")).toBeInTheDocument();
    expect(screen.getByText("Performance & Capability")).toBeInTheDocument();
    expect(screen.getByText("Seating & Capacity")).toBeInTheDocument();
  });

  it("toggles safety features via toggleArrayFilter", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();

    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Features & Technology"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={toggleArrayFilter}
        toggleSection={vi.fn()}
      />
    );

    const blindSpotChip = screen.getByTestId("chip-Blind Spot Monitor");
    await user.click(blindSpotChip);
    expect(toggleArrayFilter).toHaveBeenCalledWith(
      "selectedSafetyFeatures",
      [],
      "Blind Spot Monitor"
    );
  });

  it("toggles comfort features via toggleArrayFilter", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();

    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Features & Technology"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={toggleArrayFilter}
        toggleSection={vi.fn()}
      />
    );

    const heatedSeatsChip = screen.getByTestId("chip-Heated Seats");
    await user.click(heatedSeatsChip);
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedComfortFeatures", [], "Heated Seats");
  });

  it("toggles tech features via toggleArrayFilter", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();

    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Features & Technology"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={toggleArrayFilter}
        toggleSection={vi.fn()}
      />
    );

    const carPlayChip = screen.getByTestId("chip-Apple CarPlay");
    await user.click(carPlayChip);
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedTechFeatures", [], "Apple CarPlay");
  });

  it("toggles exterior features via toggleArrayFilter", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();

    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Features & Technology"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={toggleArrayFilter}
        toggleSection={vi.fn()}
      />
    );

    const sunroofChip = screen.getByTestId("chip-Sunroof");
    await user.click(sunroofChip);
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedExteriorFeatures", [], "Sunroof");
  });

  it("toggles performance features via toggleArrayFilter", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();

    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Features & Technology"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={toggleArrayFilter}
        toggleSection={vi.fn()}
      />
    );

    const sportModeChip = screen.getByTestId("chip-Sport Mode");
    await user.click(sportModeChip);
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedPerformanceFeatures", [], "Sport Mode");
  });

  it("toggles seating capacity via toggleArrayFilter", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();

    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Features & Technology"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={toggleArrayFilter}
        toggleSection={vi.fn()}
      />
    );

    const fiveSeatsChip = screen.getByTestId("chip-5 Seats");
    await user.click(fiveSeatsChip);
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedSeatingCapacity", [], "5 Seats");
  });

  it("toggles inspection160 via handleDraftChange", async () => {
    const user = userEvent.setup();
    const handleDraftChange = vi.fn();

    render(
      <SidebarFilters
        draftState={{ ...baseDraftState, inspection160: false }}
        handleDraftChange={handleDraftChange}
        handleScroll={vi.fn()}
        openSection={"Inspection"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 10, thumbHeight: 50 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    const inspectionSection = screen.getByTestId("section-Inspection");
    const toggleBtn = inspectionSection.querySelector("button[type='button']");
    expect(toggleBtn).toBeTruthy();

    if (toggleBtn) {
      await user.click(toggleBtn);
      expect(handleDraftChange).toHaveBeenCalledWith("inspection160", true);
    }
  });

  it("renders inspection section with correct text and toggle button state", () => {
    render(
      <SidebarFilters
        draftState={{ ...baseDraftState, inspection160: true }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Inspection"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    expect(screen.getByText("160-Point Inspection")).toBeInTheDocument();
    expect(screen.getByText("Factory-trained technician verified")).toBeInTheDocument();
  });

  it("toggles drivetrain via toggleArrayFilter", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();

    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Drivetrain"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={toggleArrayFilter}
        toggleSection={vi.fn()}
      />
    );

    const awdChip = screen.getByTestId("chip-AWD");
    await user.click(awdChip);
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedDrivetrains", [], "AWD");
  });

  it("toggles transmission via toggleArrayFilter", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();

    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Transmission"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={toggleArrayFilter}
        toggleSection={vi.fn()}
      />
    );

    const manualChip = screen.getByTestId("chip-Manual");
    await user.click(manualChip);
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedTransmissions", [], "Manual");
  });

  it("renders custom scrollbar with correct position and height", () => {
    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={null}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 20, thumbHeight: 100 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    const thumb = document.querySelector(".bg-red-500") as HTMLElement;
    expect(thumb).not.toBeNull();
    expect(thumb.style.top).toBe("20px");
    expect(thumb.style.height).toBe("100px");
  });

  it("calls handleScroll when scroll container is scrolled", () => {
    const handleScroll = vi.fn();
    const scrollContainerRef = { current: document.createElement("div") };

    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={handleScroll}
        openSection={null}
        scrollContainerRef={scrollContainerRef}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    scrollContainerRef.current.dispatchEvent(new Event("scroll"));
    expect(handleScroll).toHaveBeenCalled();
  });

  it("marks price section as loading when included in loadingFacetSections", () => {
    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        loadingFacetSections={["Price"]}
        openSection={"Price"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    const priceSection = screen.getByTestId("section-Price");
    expect(priceSection.dataset.isloading).toBe("true");
  });

  it("marks multiple sections as loading when included in loadingFacetSections", () => {
    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        loadingFacetSections={["Price", "Year", "Body Style"]}
        openSection={null}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    expect(screen.getByTestId("section-Price").dataset.isloading).toBe("true");
    expect(screen.getByTestId("section-Year").dataset.isloading).toBe("true");
    expect(screen.getByTestId("section-Body Style").dataset.isloading).toBe("true");
    expect(screen.getByTestId("section-Mileage").dataset.isloading).toBe("false");
  });

  it("does not mark sections as loading when loadingFacetSections is undefined", () => {
    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={null}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    expect(screen.getByTestId("section-Price").dataset.isloading).toBe("false");
    expect(screen.getByTestId("section-Year").dataset.isloading).toBe("false");
  });

  it("properly resolves chip type when no availableFilters provided", () => {
    render(
      <SidebarFilters
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Body Style"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    // When no availableFilters, chips should use static availability (true by default for body styles)
    const sedanChip = screen.getByTestId("chip-Sedan");
    expect(sedanChip.dataset.type).toBe("unselected");
  });

  it("handles model partial matching in availableFilters", () => {
    render(
      <SidebarFilters
        availableFilters={{ ...mockAvailableFilters, models: ["Toyota Camry"] }}
        draftState={{ ...baseDraftState }}
        handleDraftChange={vi.fn()}
        handleScroll={vi.fn()}
        openSection={"Make & Model"}
        scrollContainerRef={{ current: null }}
        scrollInfo={{ thumbTop: 0, thumbHeight: 0 }}
        sectionRefs={{ current: {} }}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
      />
    );

    // Should match "Camry" with "Toyota Camry"
    const camryChip = screen.getByTestId("chip-Camry");
    expect(camryChip.dataset.type).toBe("unselected");
  });
});
