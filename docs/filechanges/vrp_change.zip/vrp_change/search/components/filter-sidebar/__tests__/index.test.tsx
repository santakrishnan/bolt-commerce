/**
 * Unit tests for FilterSidebar component
 * @module filter-sidebar/__tests__/index
 *
 * This test suite ensures the FilterSidebar component:
 * - Renders with correct structure and accessibility
 * - Manages draft state independently from parent
 * - Handles user interactions (apply, reset, close)
 * - Computes live available filters correctly
 * - Manages section expansion and scrolling
 * - Handles edge cases and error conditions
 */

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { act } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { FilterSidebar } from "../index";
import type { AvailableFilters, FilterState } from "../types";
import { defaultFilterState } from "../types";

// Mock next/image
vi.mock("next/image", () => ({
  default: ({
    src,
    alt,
    ...props
  }: {
    src: string;
    alt: string;
    width?: number;
    height?: number;
    // biome-ignore lint/performance/noImgElement: test mock for next/image
  }) => <img alt={alt || "mock"} height={1} src={src} width={1} {...props} />,
}));

// Mock computeAvailableFiltersSync
const mockComputeAvailableFiltersSync = vi.fn();
vi.mock("@features/search/lib/mock-search-service", () => ({
  computeAvailableFiltersSync: (...args: unknown[]) => mockComputeAvailableFiltersSync(...args),
}));

// Mock AppButton component
vi.mock("@shared/components/button", () => ({
  AppButton: ({
    children,
    onClick,
    size,
    variant,
  }: {
    children: React.ReactNode;
    onClick?: () => void;
    size?: string;
    variant?: string;
  }) => (
    <button
      data-size={size}
      data-testid={`app-button-${children}`}
      data-variant={variant}
      onClick={onClick}
      type="button"
    >
      {children}
    </button>
  ),
}));

// Mock Button component from @tfs-ucmp/ui
vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({
    children,
    onClick,
    className,
    type,
    variant,
  }: {
    children: React.ReactNode;
    onClick?: () => void;
    className?: string;
    type?: string;
    variant?: string;
  }) => (
    <button
      className={className}
      data-testid="close-button"
      data-variant={variant}
      onClick={onClick}
      type={type as "button" | "submit" | "reset" | undefined}
    >
      {children}
    </button>
  ),
}));

// Mock SidebarNav component
vi.mock("../sidebar-nav", () => ({
  SidebarNav: ({
    onToggleSection,
    openSection,
  }: {
    onToggleSection: (section: string) => void;
    openSection: string | null;
  }) => (
    <div data-open-section={openSection} data-testid="sidebar-nav">
      <button onClick={() => onToggleSection("Price")} type="button">
        Toggle Price
      </button>
      <button onClick={() => onToggleSection("Year")} type="button">
        Toggle Year
      </button>
    </div>
  ),
}));

// Mock SidebarFilters component
vi.mock("../sidebar-filters", () => ({
  SidebarFilters: ({
    availableFilters,
    draftState,
    openSection,
    toggleSection,
    handleDraftChange,
    toggleArrayFilter,
  }: {
    availableFilters?: AvailableFilters;
    draftState: FilterState;
    openSection: string | null;
    toggleSection: (section: string) => void;
    handleDraftChange: (key: keyof FilterState, value: FilterState[keyof FilterState]) => void;
    toggleArrayFilter: (key: keyof FilterState, arr: string[], value: string) => void;
  }) => (
    <div
      data-body-styles={(draftState.selectedBodyStyles || []).join(",")}
      data-draft-inspection={draftState.inspection160}
      data-open-section={openSection}
      data-testid="sidebar-filters"
    >
      <div>Available Filters Count: {availableFilters?.totalCount ?? 0}</div>
      <button onClick={() => handleDraftChange("inspection160", true)} type="button">
        Set Inspection
      </button>
      <button onClick={() => toggleSection("Mileage")} type="button">
        Toggle Mileage
      </button>
      <button
        onClick={() =>
          toggleArrayFilter("selectedBodyStyles", draftState.selectedBodyStyles || [], "SUV")
        }
        type="button"
      >
        Toggle SUV
      </button>
    </div>
  ),
}));

describe("FilterSidebar", () => {
  const mockOnClose = vi.fn();
  const mockOnApply = vi.fn();
  const mockOnReset = vi.fn();

  const mockAvailableFilters: AvailableFilters = {
    bodyStyles: ["SUV", "Sedan"],
    comfortFeatures: ["Heated Seats"],
    drivetrains: ["AWD"],
    exteriorColors: ["White", "Black"],
    exteriorFeatures: ["LED Headlights"],
    fuelTypes: ["Gasoline", "Hybrid"],
    hasInspection160: true,
    interiorColors: ["Black"],
    models: ["Camry", "RAV4"],
    performanceFeatures: ["Turbo"],
    safetyFeatures: ["PCS"],
    seatingCapacity: ["7 Passenger"],
    techFeatures: ["Navigation"],
    totalCount: 50,
    transmissions: ["Automatic"],
  };

  const defaultProps = {
    isOpen: true,
    onClose: mockOnClose,
    filterState: defaultFilterState,
    onApply: mockOnApply,
    onReset: mockOnReset,
    availableFilters: mockAvailableFilters,
    vehicleCount: 50,
  };

  beforeEach(() => {
    vi.clearAllMocks();
    mockComputeAvailableFiltersSync.mockReturnValue({
      availableFilters: mockAvailableFilters,
    });
  });

  afterEach(() => {
    vi.clearAllTimers();
  });

  describe("Rendering", () => {
    it("renders the sidebar when isOpen is true", () => {
      render(<FilterSidebar {...defaultProps} />);

      const aside = screen.getByRole("complementary");
      expect(aside).toBeInTheDocument();
      expect(aside).toHaveClass("translate-x-0");
    });

    it("hides the sidebar when isOpen is false", () => {
      render(<FilterSidebar {...defaultProps} isOpen={false} />);

      const aside = screen.getByRole("complementary");
      expect(aside).toHaveClass("-translate-x-full");
    });

    it("renders overlay when isOpen is true", () => {
      render(<FilterSidebar {...defaultProps} />);

      const overlay = screen.getByLabelText("Close filter sidebar");
      expect(overlay).toBeInTheDocument();
      expect(overlay).toHaveClass("bg-black/40");
    });

    it("does not render overlay when isOpen is false", () => {
      render(<FilterSidebar {...defaultProps} isOpen={false} />);

      const overlay = screen.queryByLabelText("Close filter sidebar");
      expect(overlay).not.toBeInTheDocument();
    });

    it("renders header with filter icon and title", () => {
      render(<FilterSidebar {...defaultProps} />);

      const filterImage = screen.getByAltText("Filter");
      expect(filterImage).toBeInTheDocument();
      expect(filterImage).toHaveAttribute("src", "/images/filter-lines.svg");

      expect(screen.getByText("Filter")).toBeInTheDocument();
    });

    it("renders Apply button", () => {
      render(<FilterSidebar {...defaultProps} />);

      const applyButton = screen.getByTestId("app-button-Apply");
      expect(applyButton).toBeInTheDocument();
      expect(applyButton).toHaveAttribute("data-variant", "primary");
      expect(applyButton).toHaveAttribute("data-size", "sm");
    });

    it("renders Reset button", () => {
      render(<FilterSidebar {...defaultProps} />);

      const resetButton = screen.getByTestId("app-button-Reset");
      expect(resetButton).toBeInTheDocument();
      expect(resetButton).toHaveAttribute("data-variant", "secondary");
      expect(resetButton).toHaveAttribute("data-size", "sm");
    });

    it("renders close button with cross icon", () => {
      render(<FilterSidebar {...defaultProps} />);

      const closeButton = screen.getByTestId("close-button");
      expect(closeButton).toBeInTheDocument();

      const closeImage = screen.getByAltText("Close");
      expect(closeImage).toBeInTheDocument();
      expect(closeImage).toHaveAttribute("src", "/images/cross.svg");
    });

    it("renders SidebarNav component", () => {
      render(<FilterSidebar {...defaultProps} />);

      const sidebarNav = screen.getByTestId("sidebar-nav");
      expect(sidebarNav).toBeInTheDocument();
    });

    it("renders SidebarFilters component", () => {
      render(<FilterSidebar {...defaultProps} />);

      const sidebarFilters = screen.getByTestId("sidebar-filters");
      expect(sidebarFilters).toBeInTheDocument();
    });
  });

  describe("State Management", () => {
    it("initializes draft state with filterState prop", () => {
      const customFilterState: FilterState = {
        ...defaultFilterState,
        inspection160: true,
        selectedBodyStyles: ["SUV"],
      };

      render(<FilterSidebar {...defaultProps} filterState={customFilterState} />);

      const sidebarFilters = screen.getByTestId("sidebar-filters");
      expect(sidebarFilters).toHaveAttribute("data-draft-inspection", "true");
    });

    it("syncs draft state when sidebar opens", () => {
      const customFilterState: FilterState = {
        ...defaultFilterState,
        inspection160: true,
      };

      const { rerender } = render(
        <FilterSidebar {...defaultProps} filterState={customFilterState} isOpen={false} />
      );

      // Reopen with new state
      const newFilterState: FilterState = {
        ...defaultFilterState,
        inspection160: false,
      };

      rerender(<FilterSidebar {...defaultProps} filterState={newFilterState} isOpen={true} />);

      const sidebarFilters = screen.getByTestId("sidebar-filters");
      expect(sidebarFilters).toHaveAttribute("data-draft-inspection", "false");
    });

    it("maintains draft state independently from parent", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      // Modify draft state
      const setInspectionButton = screen.getByText("Set Inspection");
      await user.click(setInspectionButton);

      const sidebarFilters = screen.getByTestId("sidebar-filters");
      expect(sidebarFilters).toHaveAttribute("data-draft-inspection", "true");

      // Parent callbacks should not be called yet
      expect(mockOnApply).not.toHaveBeenCalled();
    });

    it("syncs draft state when sidebar remains open and props change", () => {
      const customFilterState: FilterState = {
        ...defaultFilterState,
        inspection160: true,
      };

      const { rerender } = render(
        <FilterSidebar {...defaultProps} filterState={customFilterState} isOpen={true} />
      );

      // Verify initial state
      let sidebarFilters = screen.getByTestId("sidebar-filters");
      expect(sidebarFilters).toHaveAttribute("data-draft-inspection", "true");

      // Update prop while open (component syncs on isOpen change)
      const newFilterState: FilterState = {
        ...defaultFilterState,
        inspection160: false,
      };

      rerender(<FilterSidebar {...defaultProps} filterState={newFilterState} isOpen={true} />);

      // Draft state syncs because the effect depends on [isOpen, filterState]
      sidebarFilters = screen.getByTestId("sidebar-filters");
      expect(sidebarFilters).toHaveAttribute("data-draft-inspection", "false");
    });

    it("handles toggleArrayFilter for adding values", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      const sidebarFilters = screen.getByTestId("sidebar-filters");
      expect(sidebarFilters).toHaveAttribute("data-body-styles", "");

      // Toggle SUV on
      const toggleSUVButton = screen.getByText("Toggle SUV");
      await user.click(toggleSUVButton);

      const updatedSidebarFilters = screen.getByTestId("sidebar-filters");
      expect(updatedSidebarFilters).toHaveAttribute("data-body-styles", "SUV");
    });

    it("handles toggleArrayFilter for removing values", async () => {
      const user = userEvent.setup();
      const customFilterState: FilterState = {
        ...defaultFilterState,
        selectedBodyStyles: ["SUV"],
      };

      render(<FilterSidebar {...defaultProps} filterState={customFilterState} />);

      const sidebarFilters = screen.getByTestId("sidebar-filters");
      expect(sidebarFilters).toHaveAttribute("data-body-styles", "SUV");

      // Toggle SUV off
      const toggleSUVButton = screen.getByText("Toggle SUV");
      await user.click(toggleSUVButton);

      const updatedSidebarFilters = screen.getByTestId("sidebar-filters");
      expect(updatedSidebarFilters).toHaveAttribute("data-body-styles", "");
    });
  });

  describe("User Interactions - Apply", () => {
    it("calls onApply with draft state when Apply button is clicked", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      // Modify draft state
      const setInspectionButton = screen.getByText("Set Inspection");
      await user.click(setInspectionButton);

      // Click Apply
      const applyButton = screen.getByTestId("app-button-Apply");
      await user.click(applyButton);

      expect(mockOnApply).toHaveBeenCalledTimes(1);
      expect(mockOnApply).toHaveBeenCalledWith(
        expect.objectContaining({
          inspection160: true,
        })
      );
    });

    it("closes sidebar after applying filters", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      const applyButton = screen.getByTestId("app-button-Apply");
      await user.click(applyButton);

      expect(mockOnClose).toHaveBeenCalledTimes(1);
    });

    it("applies default state when no changes are made", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      const applyButton = screen.getByTestId("app-button-Apply");
      await user.click(applyButton);

      expect(mockOnApply).toHaveBeenCalledWith(defaultFilterState);
    });
  });

  describe("User Interactions - Reset", () => {
    it("resets draft state to default when Reset button is clicked", async () => {
      const user = userEvent.setup();
      const customFilterState: FilterState = {
        ...defaultFilterState,
        inspection160: true,
        selectedBodyStyles: ["SUV", "Sedan"],
      };

      render(<FilterSidebar {...defaultProps} filterState={customFilterState} />);

      const resetButton = screen.getByTestId("app-button-Reset");
      await user.click(resetButton);

      expect(mockOnReset).toHaveBeenCalledTimes(1);
    });

    it("updates draft state to default after reset", async () => {
      const user = userEvent.setup();
      const customFilterState: FilterState = {
        ...defaultFilterState,
        inspection160: true,
      };

      render(<FilterSidebar {...defaultProps} filterState={customFilterState} />);

      const resetButton = screen.getByTestId("app-button-Reset");
      await user.click(resetButton);

      // After reset, applying should use default state
      const applyButton = screen.getByTestId("app-button-Apply");
      await user.click(applyButton);

      expect(mockOnApply).toHaveBeenCalledWith(defaultFilterState);
    });

    it("does not close sidebar after reset", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      const resetButton = screen.getByTestId("app-button-Reset");
      await user.click(resetButton);

      expect(mockOnClose).not.toHaveBeenCalled();
    });
  });

  describe("User Interactions - Close", () => {
    it("calls onClose when close button is clicked", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      const closeButton = screen.getByTestId("close-button");
      await user.click(closeButton);

      expect(mockOnClose).toHaveBeenCalledTimes(1);
    });

    it("calls onClose when overlay is clicked", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      const overlay = screen.getByLabelText("Close filter sidebar");
      await user.click(overlay);

      expect(mockOnClose).toHaveBeenCalledTimes(1);
    });

    it("calls onClose when Escape key is pressed on overlay", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      const overlay = screen.getByLabelText("Close filter sidebar");
      overlay.focus();
      await user.keyboard("{Escape}");

      expect(mockOnClose).toHaveBeenCalledTimes(1);
    });

    it("does not call onApply when closing without applying", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      // Modify draft state
      const setInspectionButton = screen.getByText("Set Inspection");
      await user.click(setInspectionButton);

      // Close without applying
      const closeButton = screen.getByTestId("close-button");
      await user.click(closeButton);

      expect(mockOnApply).not.toHaveBeenCalled();
      expect(mockOnClose).toHaveBeenCalledTimes(1);
    });
  });

  describe("Section Management", () => {
    it("initializes with no section open", () => {
      render(<FilterSidebar {...defaultProps} />);

      const sidebarNav = screen.getByTestId("sidebar-nav");
      const openSection = sidebarNav.getAttribute("data-open-section");
      expect(openSection === null || openSection === "").toBe(true);

      const sidebarFilters = screen.getByTestId("sidebar-filters");
      const filtersOpenSection = sidebarFilters.getAttribute("data-open-section");
      expect(filtersOpenSection === null || filtersOpenSection === "").toBe(true);
    });

    it("opens a section when toggled from SidebarNav", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      const toggleButton = screen.getByText("Toggle Price");
      await user.click(toggleButton);

      const sidebarNav = screen.getByTestId("sidebar-nav");
      expect(sidebarNav).toHaveAttribute("data-open-section", "Price");

      const sidebarFilters = screen.getByTestId("sidebar-filters");
      expect(sidebarFilters).toHaveAttribute("data-open-section", "Price");
    });

    it("closes an open section when toggled again", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      const toggleButton = screen.getByText("Toggle Price");

      // Open section
      await user.click(toggleButton);
      let sidebarNav = screen.getByTestId("sidebar-nav");
      expect(sidebarNav).toHaveAttribute("data-open-section", "Price");

      // Close section
      await user.click(toggleButton);
      sidebarNav = screen.getByTestId("sidebar-nav");
      const openSection = sidebarNav.getAttribute("data-open-section");
      expect(openSection === null || openSection === "").toBe(true);
    });

    it("switches between different sections", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      const priceButton = screen.getByText("Toggle Price");
      const yearButton = screen.getByText("Toggle Year");

      // Open Price section
      await user.click(priceButton);
      let sidebarNav = screen.getByTestId("sidebar-nav");
      expect(sidebarNav).toHaveAttribute("data-open-section", "Price");

      // Switch to Year section
      await user.click(yearButton);
      sidebarNav = screen.getByTestId("sidebar-nav");
      expect(sidebarNav).toHaveAttribute("data-open-section", "Year");
    });

    it("handles toggle from SidebarFilters component", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      const toggleMileageButton = screen.getByText("Toggle Mileage");
      await user.click(toggleMileageButton);

      const sidebarFilters = screen.getByTestId("sidebar-filters");
      expect(sidebarFilters).toHaveAttribute("data-open-section", "Mileage");
    });
  });

  describe("Live Available Filters", () => {
    it("uses availableFilters prop when no vehicles are provided", () => {
      render(<FilterSidebar {...defaultProps} vehicles={undefined} />);

      const sidebarFilters = screen.getByTestId("sidebar-filters");
      expect(sidebarFilters).toHaveTextContent("Available Filters Count: 50");
      expect(mockComputeAvailableFiltersSync).not.toHaveBeenCalled();
    });

    it("uses availableFilters prop when vehicles array is empty", () => {
      render(<FilterSidebar {...defaultProps} vehicles={[]} />);

      const sidebarFilters = screen.getByTestId("sidebar-filters");
      expect(sidebarFilters).toHaveTextContent("Available Filters Count: 50");
      expect(mockComputeAvailableFiltersSync).not.toHaveBeenCalled();
    });

    it("computes live filters when vehicles are provided", () => {
      const mockVehicles = [
        {
          id: "1",
          make: "Toyota",
          model: "Camry",
          year: 2023,
          bodyStyle: "Sedan",
        },
      ] as any[];

      render(<FilterSidebar {...defaultProps} vehicles={mockVehicles} />);

      expect(mockComputeAvailableFiltersSync).toHaveBeenCalledWith(
        mockVehicles,
        defaultFilterState,
        {
          searchQuery: undefined,
          labelFilter: undefined,
          refineFilters: undefined,
        }
      );
    });

    it("recomputes live filters when draft state changes", async () => {
      const user = userEvent.setup();
      const mockVehicles = [
        {
          id: "1",
          make: "Toyota",
          model: "Camry",
        },
      ] as any[];

      render(<FilterSidebar {...defaultProps} vehicles={mockVehicles} />);

      mockComputeAvailableFiltersSync.mockClear();

      // Change draft state
      const setInspectionButton = screen.getByText("Set Inspection");
      await user.click(setInspectionButton);

      expect(mockComputeAvailableFiltersSync).toHaveBeenCalledWith(
        mockVehicles,
        expect.objectContaining({ inspection160: true }),
        expect.any(Object)
      );
    });

    it("passes searchQuery to computeAvailableFiltersSync", () => {
      const mockVehicles = [{ id: "1" }] as any[];
      const searchQuery = "hybrid suv";

      render(<FilterSidebar {...defaultProps} searchQuery={searchQuery} vehicles={mockVehicles} />);

      expect(mockComputeAvailableFiltersSync).toHaveBeenCalledWith(
        mockVehicles,
        defaultFilterState,
        expect.objectContaining({ searchQuery })
      );
    });

    it("passes labelFilter to computeAvailableFiltersSync", () => {
      const mockVehicles = [{ id: "1" }] as any[];
      const labelFilter = "new-arrival";

      render(<FilterSidebar {...defaultProps} labelFilter={labelFilter} vehicles={mockVehicles} />);

      expect(mockComputeAvailableFiltersSync).toHaveBeenCalledWith(
        mockVehicles,
        defaultFilterState,
        expect.objectContaining({ labelFilter })
      );
    });

    it("passes refineFilters to computeAvailableFiltersSync", () => {
      const mockVehicles = [{ id: "1" }] as any[];
      const refineFilters = [
        { id: "fuel-hybrid", label: "Hybrid" },
        { id: "body-suv", label: "SUV" },
      ];

      render(
        <FilterSidebar {...defaultProps} refineFilters={refineFilters} vehicles={mockVehicles} />
      );

      expect(mockComputeAvailableFiltersSync).toHaveBeenCalledWith(
        mockVehicles,
        defaultFilterState,
        expect.objectContaining({ refineFilters })
      );
    });
  });

  describe("Props Propagation", () => {
    it("passes facetCounts to SidebarFilters", () => {
      const facetCounts = {
        bodyStyle: { SUV: 10, Sedan: 5 },
      } as any;

      render(<FilterSidebar {...defaultProps} facetCounts={facetCounts} />);

      // SidebarFilters receives the prop (verified through mock)
      expect(screen.getByTestId("sidebar-filters")).toBeInTheDocument();
    });

    it("passes loadingFacetSections to SidebarFilters", () => {
      const loadingFacetSections = ["bodyStyle", "fuelType"] as any[];

      render(<FilterSidebar {...defaultProps} loadingFacetSections={loadingFacetSections} />);

      expect(screen.getByTestId("sidebar-filters")).toBeInTheDocument();
    });

    it("handles undefined availableFilters", () => {
      render(<FilterSidebar {...defaultProps} availableFilters={undefined} />);

      const sidebarFilters = screen.getByTestId("sidebar-filters");
      expect(sidebarFilters).toHaveTextContent("Available Filters Count: 0");
    });
  });

  describe("Edge Cases", () => {
    it("handles rapid Apply and Reset clicks", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      const applyButton = screen.getByTestId("app-button-Apply");
      const resetButton = screen.getByTestId("app-button-Reset");

      await user.click(resetButton);
      await user.click(applyButton);
      await user.click(resetButton);
      await user.click(applyButton);

      expect(mockOnReset).toHaveBeenCalledTimes(2);
      expect(mockOnApply).toHaveBeenCalledTimes(2);
    });

    it("handles section toggle during filter changes", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      const setInspectionButton = screen.getByText("Set Inspection");
      const togglePriceButton = screen.getByText("Toggle Price");

      await user.click(setInspectionButton);
      await user.click(togglePriceButton);

      const sidebarNav = screen.getByTestId("sidebar-nav");
      expect(sidebarNav).toHaveAttribute("data-open-section", "Price");
    });

    it("handles non-existent section toggle gracefully", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      // Mock component handles any section name
      const toggleButton = screen.getByText("Toggle Mileage");
      await user.click(toggleButton);

      expect(screen.getByTestId("sidebar-filters")).toHaveAttribute("data-open-section", "Mileage");
    });

    it("maintains state after multiple open/close cycles", async () => {
      const user = userEvent.setup();
      const { rerender } = render(<FilterSidebar {...defaultProps} isOpen={true} />);

      // Make changes
      const setInspectionButton = screen.getByText("Set Inspection");
      await user.click(setInspectionButton);

      // Close
      rerender(<FilterSidebar {...defaultProps} isOpen={false} />);

      // Reopen
      rerender(<FilterSidebar {...defaultProps} isOpen={true} />);

      // State should reset on reopen
      const sidebarFilters = screen.getByTestId("sidebar-filters");
      expect(sidebarFilters).toHaveAttribute("data-draft-inspection", "false");
    });

    it("handles empty filterState", () => {
      const emptyState = {} as FilterState;

      render(<FilterSidebar {...defaultProps} filterState={emptyState} />);

      expect(screen.getByTestId("sidebar-filters")).toBeInTheDocument();
    });

    it("handles computeAvailableFiltersSync throwing error", () => {
      mockComputeAvailableFiltersSync.mockImplementation(() => {
        throw new Error("Computation error");
      });

      const mockVehicles = [{ id: "1" }] as any[];

      // Should not crash
      expect(() => {
        render(<FilterSidebar {...defaultProps} vehicles={mockVehicles} />);
      }).toThrow();
    });

    it("handles null onClose callback", () => {
      const user = userEvent.setup();
      const propsWithNullClose = {
        ...defaultProps,
        onClose: undefined as any,
      };

      render(<FilterSidebar {...propsWithNullClose} />);

      const closeButton = screen.getByTestId("close-button");

      // Should not crash
      expect(() => user.click(closeButton)).not.toThrow();
    });
  });

  describe("Accessibility", () => {
    it("renders semantic aside element for sidebar", () => {
      render(<FilterSidebar {...defaultProps} />);

      const aside = screen.getByRole("complementary");
      expect(aside).toBeInTheDocument();
    });

    it("provides accessible label for overlay close button", () => {
      render(<FilterSidebar {...defaultProps} />);

      const overlay = screen.getByLabelText("Close filter sidebar");
      expect(overlay).toBeInTheDocument();
      expect(overlay.tagName).toBe("BUTTON");
    });

    it("close button has proper type attribute", () => {
      render(<FilterSidebar {...defaultProps} />);

      const closeButton = screen.getByTestId("close-button");
      expect(closeButton).toHaveAttribute("type", "button");
    });

    it("overlay supports keyboard interaction", () => {
      render(<FilterSidebar {...defaultProps} />);

      const overlay = screen.getByLabelText("Close filter sidebar");

      // Should be keyboard accessible
      overlay.focus();
      expect(overlay).toHaveFocus();
    });

    it("maintains focus management for interactive elements", () => {
      render(<FilterSidebar {...defaultProps} />);

      const applyButton = screen.getByTestId("app-button-Apply");
      const resetButton = screen.getByTestId("app-button-Reset");
      const closeButton = screen.getByTestId("close-button");

      expect(applyButton).toBeInTheDocument();
      expect(resetButton).toBeInTheDocument();
      expect(closeButton).toBeInTheDocument();
    });
  });

  describe("Performance", () => {
    it("does not recompute filters unnecessarily", () => {
      const mockVehicles = [{ id: "1" }] as any[];

      const { rerender } = render(<FilterSidebar {...defaultProps} vehicles={mockVehicles} />);

      const initialCallCount = mockComputeAvailableFiltersSync.mock.calls.length;

      // Rerender with same props
      rerender(<FilterSidebar {...defaultProps} vehicles={mockVehicles} />);

      // Should not call again with same inputs
      expect(mockComputeAvailableFiltersSync.mock.calls.length).toBe(initialCallCount);
    });

    it("memoizes live filters correctly", async () => {
      const mockVehicles = [{ id: "1" }] as any[];

      render(<FilterSidebar {...defaultProps} vehicles={mockVehicles} />);

      const initialCallCount = mockComputeAvailableFiltersSync.mock.calls.length;

      // Toggle section (should not trigger recomputation)
      const user = userEvent.setup();
      const toggleButton = screen.getByText("Toggle Price");
      await user.click(toggleButton);

      // Call count should remain the same
      expect(mockComputeAvailableFiltersSync.mock.calls.length).toBe(initialCallCount);
    });

    it("handles large vehicle arrays efficiently", () => {
      const largeVehicleArray = Array.from({ length: 1000 }, (_, i) => ({
        id: `vehicle-${i}`,
        make: "Toyota",
        model: "Camry",
      })) as any[];

      const startTime = performance.now();
      render(<FilterSidebar {...defaultProps} vehicles={largeVehicleArray} />);
      const endTime = performance.now();

      // Should render in reasonable time (< 100ms)
      expect(endTime - startTime).toBeLessThan(100);
    });
  });

  describe("Scroll Management", () => {
    it("initializes scroll container ref", () => {
      render(<FilterSidebar {...defaultProps} />);

      expect(screen.getByTestId("sidebar-filters")).toBeInTheDocument();
      // Scroll functionality is passed to SidebarFilters
    });

    it("provides scroll handler to SidebarFilters", () => {
      render(<FilterSidebar {...defaultProps} />);

      // Handler is passed to child component (verified through mock)
      expect(screen.getByTestId("sidebar-filters")).toBeInTheDocument();
    });
  });

  describe("Integration", () => {
    it("integrates Apply flow with all components", async () => {
      const user = userEvent.setup();
      render(<FilterSidebar {...defaultProps} />);

      // 1. Open a section
      const togglePriceButton = screen.getByText("Toggle Price");
      await user.click(togglePriceButton);

      // 2. Change filter
      const setInspectionButton = screen.getByText("Set Inspection");
      await user.click(setInspectionButton);

      // 3. Apply changes
      const applyButton = screen.getByTestId("app-button-Apply");
      await user.click(applyButton);

      // 4. Verify callbacks
      expect(mockOnApply).toHaveBeenCalledWith(expect.objectContaining({ inspection160: true }));
      expect(mockOnClose).toHaveBeenCalledTimes(1);
    });

    it("integrates Reset flow with all components", async () => {
      const user = userEvent.setup();
      const customFilterState: FilterState = {
        ...defaultFilterState,
        inspection160: true,
        selectedBodyStyles: ["SUV"],
      };

      render(<FilterSidebar {...defaultProps} filterState={customFilterState} />);

      // 1. Reset
      const resetButton = screen.getByTestId("app-button-Reset");
      await user.click(resetButton);

      expect(mockOnReset).toHaveBeenCalledTimes(1);

      // 2. Apply after reset
      const applyButton = screen.getByTestId("app-button-Apply");
      await user.click(applyButton);

      expect(mockOnApply).toHaveBeenCalledWith(defaultFilterState);
    });

    it("handles complete user journey", async () => {
      const user = userEvent.setup();
      const { rerender } = render(<FilterSidebar {...defaultProps} isOpen={false} />);

      // 1. Open sidebar
      rerender(<FilterSidebar {...defaultProps} isOpen={true} />);

      // 2. Navigate sections
      const toggleYearButton = screen.getByText("Toggle Year");
      await user.click(toggleYearButton);

      // 3. Make changes
      const setInspectionButton = screen.getByText("Set Inspection");
      await user.click(setInspectionButton);

      // 4. Apply
      const applyButton = screen.getByTestId("app-button-Apply");
      await user.click(applyButton);

      // 5. Close
      expect(mockOnClose).toHaveBeenCalled();
      expect(mockOnApply).toHaveBeenCalled();
    });

    it("triggers scroll effect when section opens", () => {
      vi.useFakeTimers();

      render(<FilterSidebar {...defaultProps} />);

      const togglePriceButton = screen.getByText("Toggle Price");
      togglePriceButton.click();

      // Wait for the setTimeout to execute
      act(() => {
        vi.advanceTimersByTime(50);
      });

      vi.useRealTimers();
    });

    it("cleans up timer when section changes", () => {
      vi.useFakeTimers();

      render(<FilterSidebar {...defaultProps} />);

      const togglePriceButton = screen.getByText("Toggle Price");
      const toggleYearButton = screen.getByText("Toggle Year");

      // Open Price section
      togglePriceButton.click();

      // Switch to Year section before timer fires (should cleanup previous timer)
      toggleYearButton.click();

      // Advance timers - should not cause issues
      act(() => {
        vi.advanceTimersByTime(100);
      });

      vi.useRealTimers();
    });
  });
});
