/**
 * VehicleGridSkeleton — static skeleton shown while SearchWrapper streams in.
 *
 * No "use client" directive — this is a pure RSC / static component used as
 * the Suspense fallback for the vehicle grid.
 */
export function VehicleGridSkeleton() {
  return (
    <div className="mx-auto max-w-[var(--container-2xl)] px-4 py-8 sm:px-6 lg:px-20">
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          // biome-ignore lint/suspicious/noArrayIndexKey: static skeleton items have no meaningful key
          <div className="animate-pulse overflow-hidden rounded-lg bg-white shadow-sm" key={i}>
            {/* Image placeholder */}
            <div className="h-48 w-full bg-gray-200" />
            {/* Content placeholder */}
            <div className="space-y-3 p-4">
              <div className="h-4 w-3/4 rounded bg-gray-200" />
              <div className="h-4 w-1/2 rounded bg-gray-200" />
              <div className="h-6 w-1/3 rounded bg-gray-200" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
