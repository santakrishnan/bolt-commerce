"use client";

import { buildUsedCarsPath } from "@config/routes";
import { useFavorites } from "@features/favorites";
import { GarageCarCard } from "@features/my-garage/components/garage-car-card";
import { MyGarageCards } from "@features/my-garage/components/my-garage-cards";
import { TestDriveBanner } from "@features/my-garage/components/test-drive-banner";
import { parseDealerInfo } from "@features/my-garage/lib/helpers";
import { useSearchHistory } from "@features/search";
import type { Vehicle } from "@features/search/lib/mock-vehicles";
import { VehiclePreviewModal } from "@features/vehicle-preview";
import { Heading } from "@tfs-ucmp/ui";
import { useCallback, useEffect, useMemo, useState } from "react";

import type { MyGarageClientProps } from "./types";

export function MyGarageClient({
  cars,
  becauseViewedCars,
  becauseYouViewedLabel = "Toyota Camry",
  priceDropCars: priceDropCarsProp,
  children,
  isPreQualified = false,
  hasTradeInSubmitted = false,
  daysRemaining = 27,
}: MyGarageClientProps) {
  const [previewVin, setPreviewVin] = useState<string | null>(null);
  const [mounted, setMounted] = useState(false);
  const { savedVins, removeVehicle } = useFavorites();
  const { searches, removeSearch, clearAll: clearAllSearches } = useSearchHistory();

  useEffect(() => {
    setPreviewVin(null);
    setMounted(true);
  }, []);

  const recentSearchCards = useMemo(
    () =>
      mounted
        ? searches.map((entry) => ({
            id: entry.id,
            search: entry.query,
            url: entry.url,
          }))
        : [],
    [mounted, searches]
  );

  const priceDropCars = useMemo(
    () => priceDropCarsProp ?? cars.filter((car) => car.oldPrice),
    [priceDropCarsProp, cars]
  );

  const displayedCars = cars;
  const displayedBecauseViewed = becauseViewedCars ?? cars;
  const displayedPriceDrops = priceDropCars;

  const savedVehicles = useMemo(
    () =>
      mounted
        ? savedVins
            .map((vin) => displayedCars.find((c) => c.vin === vin))
            .filter((car): car is Vehicle => car !== undefined)
            .map((car) => ({
              id: car.vin,
              imageUrl: Array.isArray(car.image) ? (car.image[0] ?? "") : car.image,
              title: car.title,
              price: `$${car.price.toLocaleString()}`,
              miles: car.odometer,
            }))
        : [],
    [mounted, savedVins, displayedCars]
  );

  const handleRemoveSavedVehicle = useCallback(
    (id: number | string) => {
      removeVehicle(String(id));
    },
    [removeVehicle]
  );

  const selectedVehicle = previewVin ? displayedCars.find((c) => c.vin === previewVin) : undefined;

  return (
    <div className="relative min-h-screen">
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: "url('/images/garage/background.svg')",
          backgroundSize: "cover",
          backgroundPosition: "center top",
          backgroundRepeat: "no-repeat",
        }}
      />

      <div
        className="pointer-events-none absolute inset-0 z-0"
        style={{
          background:
            "linear-gradient(to bottom, #F5F5F5 0%, #F5F5F5 350px, rgba(245,245,245,0) 600px, rgba(245,245,245,0) 100%)",
        }}
      />
      <div className="relative z-0">
        <Heading
          className="mx-auto mb-8 w-full max-w-(--container-2xl) px-4 pt-8 text-left text-lg sm:px-6 md:text-lg lg:px-20"
          level={2}
          weight="semibold"
        >
          My Garage
        </Heading>
        <div className="mx-auto mb-10 w-full max-w-(--container-2xl) px-4 sm:px-6 lg:px-20">
          <MyGarageCards
            financing={{
              prequalified: isPreQualified,
              daysRemaining,
            }}
            onClearAllSearches={clearAllSearches}
            onRemoveSavedVehicle={handleRemoveSavedVehicle}
            onRemoveSearch={removeSearch}
            onSavedVehicleClick={(id) => setPreviewVin(String(id))}
            recentSearches={recentSearchCards}
            savedVehicles={savedVehicles}
            tradeOffer={{
              imageUrl: hasTradeInSubmitted ? "/images/vehicles/offer.png" : undefined,
              title: hasTradeInSubmitted ? "2019 Audi A7" : undefined,
              price: hasTradeInSubmitted ? "$15,500" : undefined,
              miles: hasTradeInSubmitted ? "68,150 miles" : undefined,
              expiresIn: hasTradeInSubmitted ? "2 days" : undefined,
              hasSubmittedTradeIn: hasTradeInSubmitted,
            }}
          />
          {selectedVehicle &&
            (() => {
              const dealerInfo = parseDealerInfo(selectedVehicle.miles);
              const vdpUrl =
                selectedVehicle.make &&
                selectedVehicle.model &&
                selectedVehicle.variant &&
                selectedVehicle.year &&
                selectedVehicle.vin
                  ? buildUsedCarsPath({
                      type: "details",
                      make: selectedVehicle.make,
                      model: selectedVehicle.model,
                      trim: selectedVehicle.variant,
                      year: selectedVehicle.year,
                      vin: selectedVehicle.vin,
                    })
                  : "#";

              return (
                <VehiclePreviewModal
                  isOpen={!!previewVin}
                  onClose={() => setPreviewVin(null)}
                  vdpUrl={vdpUrl}
                  vehicle={{
                    year: selectedVehicle.year,
                    make: selectedVehicle.make,
                    model: selectedVehicle.model,
                    price: selectedVehicle.price,
                    originalPrice: selectedVehicle.oldPrice ?? 0,
                    condition: selectedVehicle.labels[0] ?? "",
                    warranty: false,
                    inspected: false,
                    miles: selectedVehicle.odometer,
                    drivetrain: "",
                    mpg: "",
                    stock: "",
                    vin: selectedVehicle.vin,
                    exterior: selectedVehicle.extColorName,
                    exteriorColorCode: selectedVehicle.extColorCode,
                    interior: selectedVehicle.intColorName,
                    interiorColorCode: selectedVehicle.intColorCode,
                    dealer: dealerInfo.dealerName,
                    location: dealerInfo.dealerName,
                    distance: dealerInfo.distance,
                    images: Array.isArray(selectedVehicle.image)
                      ? selectedVehicle.image
                      : [selectedVehicle.image],
                    features: [],
                  }}
                  vin={selectedVehicle.vin}
                />
              );
            })()}
        </div>

        <Heading
          className="mx-auto mb-6 w-full max-w-(--container-2xl) px-4 text-left text-xl sm:px-6 md:text-xl lg:px-20"
          level={2}
          weight="semibold"
        >
          Best Matches for you
        </Heading>
        <div className="mx-auto grid max-w-(--container-2xl) grid-cols-1 gap-4 px-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-3 lg:px-20 xl:grid-cols-4">
          {displayedCars.slice(0, 8).map((car, index) => (
            <div className={index >= 6 ? "lg:hidden xl:block" : undefined} key={car.id}>
              <GarageCarCard car={car} />
            </div>
          ))}
        </div>

        {children}

        <div className="mx-auto mt-20 mb-10 w-full">
          <TestDriveBanner />
        </div>
        <Heading
          className="mx-auto mb-8 w-full max-w-(--container-2xl) px-4 text-left text-xl sm:px-6 md:text-xl lg:px-20"
          level={2}
          weight="semibold"
        >
          Because You Viewed {becauseYouViewedLabel}
        </Heading>
        <div className="mx-auto mb-16 grid max-w-(--container-2xl) grid-cols-1 gap-4 px-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-3 lg:px-20 xl:grid-cols-4">
          {displayedBecauseViewed.slice(0, 4).map((car, index) => (
            <div className={index >= 3 ? "lg:hidden xl:block" : undefined} key={car.id}>
              <GarageCarCard car={car} />
            </div>
          ))}
        </div>

        <Heading
          className="mx-auto mb-8 w-full max-w-(--container-2xl) px-4 text-left text-xl sm:px-6 md:text-xl lg:px-20"
          level={2}
          weight="semibold"
        >
          Recent Price Drop
        </Heading>
        <div className="mx-auto grid max-w-(--container-2xl) grid-cols-1 gap-4 px-4 pb-16 sm:grid-cols-2 sm:px-6 lg:grid-cols-3 lg:px-20 xl:grid-cols-4">
          {displayedPriceDrops.slice(0, 4).map((car, index) => (
            <div className={index >= 3 ? "lg:hidden xl:block" : undefined} key={car.id}>
              <GarageCarCard badgeOverride={{ type: "priceDrop", text: "Price Drop" }} car={car} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
