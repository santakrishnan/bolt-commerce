import { fireEvent, render, screen } from "@arrow/vitest-config/test-utils";
import { describe, expect, it, vi } from "vitest";
import {
  VehicleStatCard,
  type VehicleStatCardProps,
  VehicleStatsGrid,
} from "../vehicle-stats-grid";

const FIND_VEHICLE_HEADING_REGEX = /find your vehicle/i;

vi.mock("@tfs-ucmp/ui", () => ({
  Heading: ({ children, level, weight, className }: any) => {
    const Tag = `h${level}` as "h1" | "h2" | "h3" | "h4" | "h5" | "h6";
    return (
      <Tag className={className} data-weight={weight}>
        {children}
      </Tag>
    );
  },
}));

const mockIcon = <svg data-testid="mock-icon" />;

const baseCardProps: VehicleStatCardProps = {
  icon: mockIcon,
  title: "Saved Vehicles",
  count: "5",
};

describe("VehicleStatCard", () => {
  describe("rendering", () => {
    it("renders the title", () => {
      render(<VehicleStatCard {...baseCardProps} />);
      expect(screen.getByText("Saved Vehicles")).toBeInTheDocument();
    });

    it("renders the count", () => {
      render(<VehicleStatCard {...baseCardProps} />);
      expect(screen.getByText("5")).toBeInTheDocument();
    });

    it("renders the icon", () => {
      render(<VehicleStatCard {...baseCardProps} />);
      expect(screen.getByTestId("mock-icon")).toBeInTheDocument();
    });

    it("renders default subtitle 'vehicles'", () => {
      render(<VehicleStatCard {...baseCardProps} />);
      expect(screen.getByText("vehicles")).toBeInTheDocument();
    });

    it("renders custom subtitle when provided", () => {
      render(<VehicleStatCard {...baseCardProps} subtitle="listings" />);
      expect(screen.getByText("listings")).toBeInTheDocument();
    });

    it("renders as a button element", () => {
      render(<VehicleStatCard {...baseCardProps} />);
      expect(screen.getByRole("button")).toBeInTheDocument();
    });
  });

  describe("onClick", () => {
    it("calls onClick handler when clicked", () => {
      const handleClick = vi.fn();
      render(<VehicleStatCard {...baseCardProps} onClick={handleClick} />);
      fireEvent.click(screen.getByRole("button"));
      expect(handleClick).toHaveBeenCalledOnce();
    });

    it("does not throw when onClick is not provided", () => {
      render(<VehicleStatCard {...baseCardProps} />);
      expect(() => fireEvent.click(screen.getByRole("button"))).not.toThrow();
    });
  });

  describe("countColor prop", () => {
    it("applies default countColor class to count wrapper", () => {
      const { container } = render(<VehicleStatCard {...baseCardProps} />);
      const countDiv = container.querySelector(".text-\\[\\#E53935\\]");
      expect(countDiv).toBeInTheDocument();
    });

    it("applies custom countColor class when provided", () => {
      const { container } = render(
        <VehicleStatCard {...baseCardProps} countColor="text-blue-500" />
      );
      const countDiv = container.querySelector(".text-blue-500");
      expect(countDiv).toBeInTheDocument();
    });
  });
});

describe("VehicleStatsGrid", () => {
  const cards: VehicleStatCardProps[] = [
    { icon: <svg data-testid="icon-1" />, title: "Card One", count: "3" },
    { icon: <svg data-testid="icon-2" />, title: "Card Two", count: "7" },
  ];

  describe("rendering", () => {
    it("renders default title 'Find your vehicle' when title is omitted", () => {
      render(<VehicleStatsGrid cards={[]} />);
      expect(screen.getByRole("heading", { name: FIND_VEHICLE_HEADING_REGEX })).toBeInTheDocument();
    });

    it("renders a custom title when provided", () => {
      render(<VehicleStatsGrid cards={[]} title="My Custom Title" />);
      expect(screen.getByRole("heading", { name: "My Custom Title" })).toBeInTheDocument();
    });

    it("renders all provided cards", () => {
      render(<VehicleStatsGrid cards={cards} />);
      expect(screen.getByText("Card One")).toBeInTheDocument();
      expect(screen.getByText("Card Two")).toBeInTheDocument();
    });

    it("renders the correct number of card buttons", () => {
      render(<VehicleStatsGrid cards={cards} />);
      expect(screen.getAllByRole("button")).toHaveLength(2);
    });

    it("renders icons for each card", () => {
      render(<VehicleStatsGrid cards={cards} />);
      expect(screen.getByTestId("icon-1")).toBeInTheDocument();
      expect(screen.getByTestId("icon-2")).toBeInTheDocument();
    });

    it("renders count values for each card", () => {
      render(<VehicleStatsGrid cards={cards} />);
      expect(screen.getByText("3")).toBeInTheDocument();
      expect(screen.getByText("7")).toBeInTheDocument();
    });

    it("renders an empty grid when cards array is empty", () => {
      render(<VehicleStatsGrid cards={[]} />);
      expect(screen.queryAllByRole("button")).toHaveLength(0);
    });
  });

  describe("card click propagation", () => {
    it("fires onClick for the correct card", () => {
      const onClickOne = vi.fn();
      const onClickTwo = vi.fn();
      const clickableCards: VehicleStatCardProps[] = [
        { ...(cards[0] as VehicleStatCardProps), onClick: onClickOne },
        { ...(cards[1] as VehicleStatCardProps), onClick: onClickTwo },
      ];
      render(<VehicleStatsGrid cards={clickableCards} />);
      const buttons = screen.getAllByRole("button");
      fireEvent.click(buttons[1] as HTMLElement);
      expect(onClickTwo).toHaveBeenCalledOnce();
      expect(onClickOne).not.toHaveBeenCalled();
    });
  });
});
