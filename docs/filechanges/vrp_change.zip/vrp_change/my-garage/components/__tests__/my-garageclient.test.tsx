import { fireEvent, render, screen } from "@arrow/vitest-config/test-utils";
import type { Vehicle } from "@shared/types";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { MyGarageClient } from "../my-garageclient";

const REGEX = {
  MY_GARAGE: /my garage/i,
  BEST_MATCHES: /best matches for you/i,
  BECAUSE_VIEWED: /because you viewed toyota camry/i,
  RECENT_PRICE_DROP: /recent price drop/i,
  TEST_DRIVE: /schedule a test drive/i,
} as const;

function buildVehicle(overrides: Partial<Vehicle> = {}): Vehicle {
  return {
    id: 1,
    vin: "VIN001",
    title: "2024 Toyota Camry",
    make: "Toyota",
    model: "Camry",
    variant: "XSE",
    year: 2024,
    price: 32_000,
    oldPrice: undefined,
    odometer: "12,345 mi",
    miles: "Toyota of Fort Worth - 6.1mi",
    image: "/images/camry.jpg",
    labels: [],
    match: 0,
    owners: 1,
    bodyType: "Sedan",
    drivetrain: "FWD",
    fuelType: "Gasoline",
    transmission: "Automatic",
    extColorCode: "#FFFFFF",
    extColorName: "White",
    intColorCode: "#000000",
    intColorName: "Black",
    mileage: 12_345,
    inspection160: true,
    seatingCapacity: ["5"],
    features: {
      comfort: [],
      exterior: [],
      performance: [],
      safety: [],
      tech: [],
    },
    warranty: false,
    dealerId: "toyota-plano",
    dealerLocation: "Plano, TX 75001",
    dealerName: "Toyota of Plano",
    mpg: "28-39",
    stock: "STK00001",
    ...overrides,
  };
}

const mockRemoveVehicle = vi.fn();
const mockRemoveSearch = vi.fn();
const mockClearAll = vi.fn();

const favoritesState: { savedVins: string[] } = { savedVins: [] };

const searchHistoryState: { searches: Array<{ id: string; query: string; url: string }> } = {
  searches: [],
};

vi.mock("@features/favorites", () => ({
  useFavorites: () => ({
    savedVins: favoritesState.savedVins,
    removeVehicle: mockRemoveVehicle,
  }),
}));

vi.mock("@features/search", () => ({
  useSearchHistory: () => ({
    searches: searchHistoryState.searches,
    removeSearch: mockRemoveSearch,
    clearAll: mockClearAll,
  }),
}));

vi.mock("@features/search/lib/mock-vehicles", () => ({
  getVehicleEstimation: () => ({
    estimatedMonthlyPayment: "$520/mo",
    apr: "5.9%",
    creditScore: "700",
    termLength: "60 months",
  }),
}));

vi.mock("@config/routes", () => ({
  buildUsedCarsPath: vi.fn(
    ({ make, model, trim, year, vin }) => `/used-cars/${make}/${model}/${trim}/${year}/${vin}`
  ),
}));

vi.mock("@features/my-garage/components/my-garage-cards", () => ({
  MyGarageCards: ({
    financing,
    savedVehicles,
    recentSearches,
    tradeOffer,
    onSavedVehicleClick,
    onRemoveSavedVehicle,
    onClearAllSearches,
  }: any) => (
    <div data-testid="my-garage-cards">
      <div data-testid="financing-prequalified">{String(financing.prequalified)}</div>
      <div data-testid="financing-days">{financing.daysRemaining}</div>
      <div data-testid="saved-count">{savedVehicles.length}</div>
      <div data-testid="search-count">{recentSearches.length}</div>
      <div data-testid="trade-submitted">{String(tradeOffer.hasSubmittedTradeIn)}</div>
      {savedVehicles.map((v: any) => (
        <button
          data-testid={`remove-saved-${v.id}`}
          key={v.id}
          onClick={() => onRemoveSavedVehicle(v.id)}
          type="button"
        >
          Remove {v.title}
        </button>
      ))}
      <button data-testid="clear-searches" onClick={onClearAllSearches} type="button">
        Clear all
      </button>
      {savedVehicles.map((v: any) => (
        <button
          data-testid={`view-saved-${v.id}`}
          key={`view-${v.id}`}
          onClick={() => onSavedVehicleClick(v.id)}
          type="button"
        >
          View {v.title}
        </button>
      ))}
    </div>
  ),
}));

vi.mock("@features/my-garage/components/test-drive-banner", () => ({
  TestDriveBanner: () => <div data-testid="test-drive-banner">Test Drive Banner</div>,
}));

vi.mock("@features/vehicle-card", () => ({
  CarCard: ({ carName, vin, badge, wasPrice, matchPercentage }: any) => (
    <div
      data-badge={badge?.type}
      data-match={matchPercentage}
      data-testid={`car-card-${vin}`}
      data-was-price={wasPrice}
    >
      {carName}
    </div>
  ),
}));

vi.mock("@features/vehicle-preview", () => ({
  VehiclePreviewModal: ({ isOpen, onClose, vdpUrl, vin }: any) =>
    isOpen ? (
      <div data-testid="vehicle-preview-modal" data-vdp-url={vdpUrl}>
        <button data-testid="close-modal" onClick={onClose} type="button">
          Close
        </button>
        <span data-testid="modal-vin">{vin}</span>
      </div>
    ) : null,
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Heading: ({ children, level, className, weight }: any) => {
    const Tag = `h${level}` as "h1" | "h2" | "h3" | "h4" | "h5" | "h6";
    return (
      <Tag className={className} data-weight={weight}>
        {children}
      </Tag>
    );
  },
}));

describe("MyGarageClient", () => {
  const baseCars = [buildVehicle()];

  beforeEach(() => {
    vi.clearAllMocks();
    favoritesState.savedVins = [];
    searchHistoryState.searches = [];
  });

  describe("section headings", () => {
    it("renders 'My Garage' heading", () => {
      render(<MyGarageClient cars={baseCars} />);
      expect(screen.getByText(REGEX.MY_GARAGE)).toBeInTheDocument();
    });

    it("renders 'Best Matches for you' heading", () => {
      render(<MyGarageClient cars={baseCars} />);
      expect(screen.getByText(REGEX.BEST_MATCHES)).toBeInTheDocument();
    });

    it("renders 'Because You Viewed Toyota Camry' heading", () => {
      render(<MyGarageClient cars={baseCars} />);
      expect(screen.getByText(REGEX.BECAUSE_VIEWED)).toBeInTheDocument();
    });

    it("renders 'Recent Price Drop' heading", () => {
      render(<MyGarageClient cars={baseCars} />);
      expect(screen.getByText(REGEX.RECENT_PRICE_DROP)).toBeInTheDocument();
    });
  });

  describe("sub-component mounting", () => {
    it("renders MyGarageCards", () => {
      render(<MyGarageClient cars={baseCars} />);
      expect(screen.getByTestId("my-garage-cards")).toBeInTheDocument();
    });

    it("renders TestDriveBanner", () => {
      render(<MyGarageClient cars={baseCars} />);
      expect(screen.getByTestId("test-drive-banner")).toBeInTheDocument();
    });

    it("does NOT render VehiclePreviewModal by default (no previewVin)", () => {
      render(<MyGarageClient cars={baseCars} />);
      expect(screen.queryByTestId("vehicle-preview-modal")).not.toBeInTheDocument();
    });
  });

  describe("default props", () => {
    it("passes isPreQualified=false to MyGarageCards by default", () => {
      render(<MyGarageClient cars={baseCars} />);
      expect(screen.getByTestId("financing-prequalified").textContent).toBe("false");
    });

    it("passes daysRemaining=27 to MyGarageCards by default", () => {
      render(<MyGarageClient cars={baseCars} />);
      expect(screen.getByTestId("financing-days").textContent).toBe("27");
    });

    it("passes hasTradeInSubmitted=false to MyGarageCards by default", () => {
      render(<MyGarageClient cars={baseCars} />);
      expect(screen.getByTestId("trade-submitted").textContent).toBe("false");
    });
  });

  describe("prop forwarding", () => {
    it("forwards isPreQualified=true correctly", () => {
      render(<MyGarageClient cars={baseCars} isPreQualified />);
      expect(screen.getByTestId("financing-prequalified").textContent).toBe("true");
    });

    it("forwards custom daysRemaining", () => {
      render(<MyGarageClient cars={baseCars} daysRemaining={10} />);
      expect(screen.getByTestId("financing-days").textContent).toBe("10");
    });

    it("forwards hasTradeInSubmitted=true", () => {
      render(<MyGarageClient cars={baseCars} hasTradeInSubmitted />);
      expect(screen.getByTestId("trade-submitted").textContent).toBe("true");
    });

    it("renders children when provided", () => {
      render(
        <MyGarageClient cars={baseCars}>
          <div data-testid="custom-child">Child Content</div>
        </MyGarageClient>
      );
      expect(screen.getByTestId("custom-child")).toBeInTheDocument();
    });
  });

  describe("best matches grid", () => {
    it("renders a CarCard for each car (up to 12)", () => {
      const cars = Array.from({ length: 3 }, (_, i) =>
        buildVehicle({ id: i + 1, vin: `VIN00${i + 1}`, title: `Car ${i + 1}` })
      );
      render(<MyGarageClient becauseViewedCars={[]} cars={cars} />);
      expect(screen.getByTestId("car-card-VIN001")).toBeInTheDocument();
      expect(screen.getByTestId("car-card-VIN002")).toBeInTheDocument();
      expect(screen.getByTestId("car-card-VIN003")).toBeInTheDocument();
    });

    it("caps best matches grid at 8 cars", () => {
      const cars = Array.from({ length: 15 }, (_, i) =>
        buildVehicle({ id: i + 1, vin: `VIN${String(i + 1).padStart(3, "0")}` })
      );
      render(<MyGarageClient becauseViewedCars={[]} cars={cars} />);
      expect(screen.getByTestId("car-card-VIN001")).toBeInTheDocument();
      expect(screen.getByTestId("car-card-VIN008")).toBeInTheDocument();
      expect(screen.queryByTestId("car-card-VIN009")).not.toBeInTheDocument();
    });

    it("wraps cards at index 6 and 7 with lg:hidden xl:block (hidden at 3-col, shown at 4-col)", () => {
      const cars = Array.from({ length: 8 }, (_, i) =>
        buildVehicle({ id: i + 1, vin: `BMVIS${String(i + 1).padStart(3, "0")}` })
      );
      render(<MyGarageClient becauseViewedCars={[]} cars={cars} />);
      expect(screen.getByTestId("car-card-BMVIS001").parentElement?.className ?? "").not.toContain(
        "lg:hidden"
      );
      expect(screen.getByTestId("car-card-BMVIS006").parentElement?.className ?? "").not.toContain(
        "lg:hidden"
      );
      expect(screen.getByTestId("car-card-BMVIS007").parentElement?.className).toContain(
        "lg:hidden xl:block"
      );
      expect(screen.getByTestId("car-card-BMVIS008").parentElement?.className).toContain(
        "lg:hidden xl:block"
      );
    });

    it("passes badge 'excellent' for 'Excellent Price' label", () => {
      const car = buildVehicle({ vin: "VINBADGE", labels: ["Excellent Price"] });
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      expect(screen.getByTestId("car-card-VINBADGE")).toHaveAttribute("data-badge", "excellent");
    });

    it("passes badge 'priceDrop' for 'Price Drop' label", () => {
      const car = buildVehicle({ vin: "VINPRICE", labels: ["Price Drop"] });
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      expect(screen.getAllByTestId("car-card-VINPRICE")[0]).toHaveAttribute(
        "data-badge",
        "priceDrop"
      );
    });

    it("passes badge 'available' for other non-empty labels", () => {
      const car = buildVehicle({ vin: "VINAVAIL", labels: ["Good Deal"] });
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      expect(screen.getByTestId("car-card-VINAVAIL")).toHaveAttribute("data-badge", "available");
    });

    it("omits badge when car has no labels", () => {
      const car = buildVehicle({ vin: "VINNOLAB", labels: [] });
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      expect(screen.getByTestId("car-card-VINNOLAB")).not.toHaveAttribute("data-badge");
    });

    it("passes wasPrice when car has oldPrice", () => {
      const car = buildVehicle({ vin: "VINWAS", oldPrice: 35_000 });
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      expect(screen.getAllByTestId("car-card-VINWAS")[0]).toHaveAttribute(
        "data-was-price",
        "$35,000"
      );
    });

    it("omits wasPrice when car has no oldPrice", () => {
      const car = buildVehicle({ vin: "VINNO", oldPrice: undefined });
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      expect(screen.getByTestId("car-card-VINNO")).not.toHaveAttribute("data-was-price");
    });

    it("passes matchPercentage when match > 0", () => {
      const car = buildVehicle({ vin: "VINMATCH", match: 85 });
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      expect(screen.getByTestId("car-card-VINMATCH")).toHaveAttribute("data-match", "85");
    });

    it("omits matchPercentage when match is 0", () => {
      const car = buildVehicle({ vin: "VINZERO", match: 0 });
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      expect(screen.getByTestId("car-card-VINZERO")).not.toHaveAttribute("data-match");
    });
  });

  describe("because you viewed section", () => {
    it("uses cars when becauseViewedCars is not provided", () => {
      const cars = [buildVehicle({ vin: "VINFALLBACK" })];
      render(<MyGarageClient cars={cars} />);
      expect(screen.getAllByTestId("car-card-VINFALLBACK").length).toBeGreaterThanOrEqual(1);
    });

    it("uses becauseViewedCars when provided", () => {
      const car = buildVehicle({ vin: "VINBECAUSE", title: "Because Viewed Car" });
      render(<MyGarageClient becauseViewedCars={[car]} cars={baseCars} />);
      expect(screen.getByTestId("car-card-VINBECAUSE")).toBeInTheDocument();
    });

    it("caps 'because you viewed' section at 4 cars", () => {
      const cars = Array.from({ length: 6 }, (_, i) =>
        buildVehicle({ id: i + 100, vin: `BEC${String(i + 1).padStart(3, "0")}` })
      );
      render(<MyGarageClient becauseViewedCars={cars} cars={[]} />);
      expect(screen.getByTestId("car-card-BEC001")).toBeInTheDocument();
      expect(screen.getByTestId("car-card-BEC004")).toBeInTheDocument();
      expect(screen.queryByTestId("car-card-BEC005")).not.toBeInTheDocument();
    });

    it("wraps card at index 3 with lg:hidden xl:block (1 row: 3 at lg, 4 at xl)", () => {
      const cars = Array.from({ length: 4 }, (_, i) =>
        buildVehicle({ id: i + 100, vin: `BECVIS${String(i + 1).padStart(3, "0")}` })
      );
      render(<MyGarageClient becauseViewedCars={cars} cars={[]} />);
      expect(screen.getByTestId("car-card-BECVIS001").parentElement?.className ?? "").not.toContain(
        "lg:hidden"
      );
      expect(screen.getByTestId("car-card-BECVIS003").parentElement?.className ?? "").not.toContain(
        "lg:hidden"
      );
      expect(screen.getByTestId("car-card-BECVIS004").parentElement?.className).toContain(
        "lg:hidden xl:block"
      );
    });

    it("passes badge 'priceDrop' in because-you-viewed for 'Price Drop' label", () => {
      const car = buildVehicle({ vin: "BECPRICEDROP", labels: ["Price Drop"] });
      render(<MyGarageClient becauseViewedCars={[car]} cars={[]} />);
      expect(screen.getByTestId("car-card-BECPRICEDROP")).toHaveAttribute(
        "data-badge",
        "priceDrop"
      );
    });

    it("passes matchPercentage in because-you-viewed section when match > 0", () => {
      const car = buildVehicle({ vin: "BECMATCH", match: 72 });
      render(<MyGarageClient becauseViewedCars={[car]} cars={[]} />);
      expect(screen.getByTestId("car-card-BECMATCH")).toHaveAttribute("data-match", "72");
    });

    it("omits matchPercentage in because-you-viewed section when match is 0", () => {
      const car = buildVehicle({ vin: "BECNOMATCH", match: 0 });
      render(<MyGarageClient becauseViewedCars={[car]} cars={[]} />);
      expect(screen.getByTestId("car-card-BECNOMATCH")).not.toHaveAttribute("data-match");
    });
  });

  describe("recent price drop section", () => {
    it("only shows cars with oldPrice in price drop section", () => {
      const withOldPrice = buildVehicle({ vin: "VINOLD", oldPrice: 30_000 });
      const withoutOldPrice = buildVehicle({ id: 2, vin: "VINNEW", oldPrice: undefined });
      render(<MyGarageClient cars={[withoutOldPrice, withOldPrice]} />);

      const cards = screen.getAllByTestId("car-card-VINOLD");
      expect(cards.length).toBeGreaterThanOrEqual(1);
    });

    it("caps price drop section at 4 cars", () => {
      const cars = Array.from({ length: 6 }, (_, i) =>
        buildVehicle({
          id: i + 200,
          vin: `PD${String(i + 1).padStart(3, "0")}`,
          oldPrice: 20_000 + i * 1000,
        })
      );
      render(<MyGarageClient cars={cars} />);

      expect(screen.getAllByTestId("car-card-PD001").length).toBeGreaterThanOrEqual(1);
      expect(screen.getAllByTestId("car-card-PD004").length).toBeGreaterThanOrEqual(1);
    });

    it("wraps card at index 3 with lg:hidden xl:block (1 row: 3 at lg, 4 at xl)", () => {
      const cars = Array.from({ length: 4 }, (_, i) =>
        buildVehicle({
          id: i + 200,
          vin: `PDVIS${String(i + 1).padStart(3, "0")}`,
          oldPrice: 20_000 + i * 1000,
        })
      );
      render(<MyGarageClient becauseViewedCars={[]} cars={cars} />);
      const pdCards = screen.getAllByTestId("car-card-PDVIS001");
      expect(pdCards.at(-1)?.parentElement?.className ?? "").not.toContain("lg:hidden");
      const pd3Cards = screen.getAllByTestId("car-card-PDVIS003");
      expect(pd3Cards.at(-1)?.parentElement?.className ?? "").not.toContain("lg:hidden");
      const pd4Cards = screen.getAllByTestId("car-card-PDVIS004");
      expect(pd4Cards.at(-1)?.parentElement?.className).toContain("lg:hidden xl:block");
    });

    it("passes matchPercentage in price-drop section when match > 0", () => {
      const car = buildVehicle({ vin: "PDMATCH", oldPrice: 25_000, match: 60 });
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);

      const cards = screen.getAllByTestId("car-card-PDMATCH");
      expect(cards.at(-1)).toHaveAttribute("data-match", "60");
    });

    it("renders no price-drop CarCards when no car has oldPrice", () => {
      const cars = [
        buildVehicle({ vin: "VIN_A", oldPrice: undefined }),
        buildVehicle({ id: 2, vin: "VIN_B", oldPrice: undefined }),
      ];
      render(<MyGarageClient cars={cars} />);
    });
  });

  describe("saved vehicle interactions", () => {
    it("calls clearAll when onClearAllSearches is triggered", () => {
      render(<MyGarageClient cars={baseCars} />);
      fireEvent.click(screen.getByTestId("clear-searches"));
      expect(mockClearAll).toHaveBeenCalledTimes(1);
    });

    it("calls removeVehicle with correct string id when saved vehicle is removed", () => {
      const car = buildVehicle({ vin: "VIN_REMOVE" });
      favoritesState.savedVins = ["VIN_REMOVE"];
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      fireEvent.click(screen.getByTestId("remove-saved-VIN_REMOVE"));
      expect(mockRemoveVehicle).toHaveBeenCalledWith("VIN_REMOVE");
    });

    it("maps search history entries into recentSearchCards", () => {
      searchHistoryState.searches = [
        { id: "s1", query: "Toyota Camry", url: "/search?q=camry" },
        { id: "s2", query: "Honda Accord", url: "/search?q=accord" },
      ];
      render(<MyGarageClient cars={baseCars} />);
      expect(screen.getByTestId("search-count").textContent).toBe("2");
    });
  });

  describe("vehicle preview modal", () => {
    it("does not render modal initially", () => {
      render(<MyGarageClient cars={baseCars} />);
      expect(screen.queryByTestId("vehicle-preview-modal")).not.toBeInTheDocument();
    });

    it("opens modal and shows correct VIN when saved vehicle is clicked", () => {
      const car = buildVehicle({ vin: "VIN_MODAL" });
      favoritesState.savedVins = ["VIN_MODAL"];
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      fireEvent.click(screen.getByTestId("view-saved-VIN_MODAL"));
      expect(screen.getByTestId("vehicle-preview-modal")).toBeInTheDocument();
      expect(screen.getByTestId("modal-vin").textContent).toBe("VIN_MODAL");
    });

    it("closes modal when onClose is called", () => {
      const car = buildVehicle({ vin: "VIN_CLOSE" });
      favoritesState.savedVins = ["VIN_CLOSE"];
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      fireEvent.click(screen.getByTestId("view-saved-VIN_CLOSE"));
      expect(screen.getByTestId("vehicle-preview-modal")).toBeInTheDocument();
      fireEvent.click(screen.getByTestId("close-modal"));
      expect(screen.queryByTestId("vehicle-preview-modal")).not.toBeInTheDocument();
    });

    it("builds vdpUrl using buildUsedCarsPath when all vehicle fields are present", async () => {
      const { buildUsedCarsPath } = await import("@config/routes");
      const car = buildVehicle({
        vin: "VIN_VDP",
        make: "Toyota",
        model: "Camry",
        variant: "XSE",
        year: 2024,
      });
      favoritesState.savedVins = ["VIN_VDP"];
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      fireEvent.click(screen.getByTestId("view-saved-VIN_VDP"));
      const modal = screen.getByTestId("vehicle-preview-modal");
      expect(modal.getAttribute("data-vdp-url")).not.toBe("#");
      expect(buildUsedCarsPath).toHaveBeenCalled();
    });

    it("falls back to '#' vdpUrl when make is empty string", () => {
      const car = buildVehicle({ vin: "VIN_NOVDP", make: "" });
      favoritesState.savedVins = ["VIN_NOVDP"];
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      fireEvent.click(screen.getByTestId("view-saved-VIN_NOVDP"));
      expect(screen.getByTestId("vehicle-preview-modal").getAttribute("data-vdp-url")).toBe("#");
    });

    it("handles array image correctly in modal (uses array.isArray branch)", () => {
      const car = buildVehicle({ vin: "VIN_ARRIMG", image: ["/img1.jpg", "/img2.jpg"] });
      favoritesState.savedVins = ["VIN_ARRIMG"];
      expect(() => {
        render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
        fireEvent.click(screen.getByTestId("view-saved-VIN_ARRIMG"));
      }).not.toThrow();
      expect(screen.getByTestId("vehicle-preview-modal")).toBeInTheDocument();
    });

    it("handles string image correctly in modal (uses string branch)", () => {
      const car = buildVehicle({ vin: "VIN_STRIMG", image: "/single.jpg" });
      favoritesState.savedVins = ["VIN_STRIMG"];
      expect(() => {
        render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
        fireEvent.click(screen.getByTestId("view-saved-VIN_STRIMG"));
      }).not.toThrow();
      expect(screen.getByTestId("vehicle-preview-modal")).toBeInTheDocument();
    });

    it("uses first label as condition in modal, falls back to empty string when no labels", () => {
      const car = buildVehicle({ vin: "VIN_NOLABEL", labels: [] });
      favoritesState.savedVins = ["VIN_NOLABEL"];
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      fireEvent.click(screen.getByTestId("view-saved-VIN_NOLABEL"));
      expect(screen.getByTestId("vehicle-preview-modal")).toBeInTheDocument();
    });

    it("uses oldPrice as originalPrice in modal when present", () => {
      const car = buildVehicle({ vin: "VIN_OLDPRICE", oldPrice: 38_000 });
      favoritesState.savedVins = ["VIN_OLDPRICE"];
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      fireEvent.click(screen.getByTestId("view-saved-VIN_OLDPRICE"));
      expect(screen.getByTestId("vehicle-preview-modal")).toBeInTheDocument();
    });

    it("sets originalPrice to 0 in modal when oldPrice is undefined", () => {
      const car = buildVehicle({ vin: "VIN_NOOLDPRICE", oldPrice: undefined });
      favoritesState.savedVins = ["VIN_NOOLDPRICE"];
      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      fireEvent.click(screen.getByTestId("view-saved-VIN_NOOLDPRICE"));
      expect(screen.getByTestId("vehicle-preview-modal")).toBeInTheDocument();
    });
  });

  describe("layout structure", () => {
    it("renders the root container with min-h-screen class", () => {
      const { container } = render(<MyGarageClient cars={baseCars} />);
      expect(container.firstChild).toHaveClass("min-h-screen");
    });

    it("renders background image layer", () => {
      const { container } = render(<MyGarageClient cars={baseCars} />);
      const bg = container.querySelector('[style*="background-image"]');
      expect(bg).toBeInTheDocument();
    });

    it("renders gradient overlay layer", () => {
      const { container } = render(<MyGarageClient cars={baseCars} />);
      const gradients = container.querySelectorAll('[style*="linear-gradient"]');
      expect(gradients.length).toBeGreaterThanOrEqual(1);
    });
  });

  describe("empty cars", () => {
    it("renders without errors when cars is empty", () => {
      expect(() => render(<MyGarageClient cars={[]} />)).not.toThrow();
    });

    it("still renders headings with no cars", () => {
      render(<MyGarageClient cars={[]} />);
      expect(screen.getByText(REGEX.MY_GARAGE)).toBeInTheDocument();
      expect(screen.getByText(REGEX.BEST_MATCHES)).toBeInTheDocument();
    });
  });

  describe("dealer info parsing via car miles", () => {
    it("handles miles without a dash separator gracefully", () => {
      const car = buildVehicle({ vin: "VINDASH", miles: "NoDash Dealer" });
      expect(() => render(<MyGarageClient cars={[car]} />)).not.toThrow();
    });

    it("handles miles with a dash separator (e.g. 'Toyota of FW - 6.1mi')", () => {
      const car = buildVehicle({ vin: "VINPARSED", miles: "Toyota of FW - 6.1mi" });
      expect(() => render(<MyGarageClient cars={[car]} />)).not.toThrow();
    });
  });

  describe("image field handling", () => {
    it("handles array images for saved vehicles lookup", () => {
      const car = buildVehicle({ vin: "VIN_ARR", image: ["/img1.jpg", "/img2.jpg"] });
      expect(() => render(<MyGarageClient cars={[car]} />)).not.toThrow();
    });

    it("handles string image for saved vehicles lookup", () => {
      const car = buildVehicle({ vin: "VIN_STR", image: "/img.jpg" });
      expect(() => render(<MyGarageClient cars={[car]} />)).not.toThrow();
    });

    it("handles empty array image (car.image[0] ?? '' fallback) in saved vehicles lookup", () => {
      const car = buildVehicle({ vin: "VIN_EMPTYARR", image: [] as unknown as string[] });
      favoritesState.savedVins = ["VIN_EMPTYARR"];
      expect(() => render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />)).not.toThrow();
      expect(screen.getByTestId("saved-count").textContent).toBe("1");
    });
  });
});

describe("parseDealerInfo logic (via rendered output)", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("splits 'Toyota of Fort Worth - 6.1mi' into name and distance", () => {
    const car: Vehicle = {
      id: 99,
      vin: "VINPARSE",
      title: "2022 Toyota Highlander",
      make: "Toyota",
      model: "Highlander",
      variant: "XLE",
      year: 2022,
      price: 40_000,
      oldPrice: undefined,
      odometer: "20,000 mi",
      miles: "Toyota of Fort Worth - 6.1mi",
      image: "/img.jpg",
      labels: [],
      match: 0,
      owners: 1,
      bodyType: "SUV",
      drivetrain: "AWD",
      fuelType: "Hybrid",
      transmission: "CVT",
      extColorCode: "#000",
      extColorName: "Black",
      intColorCode: "#FFF",
      intColorName: "White",
      mileage: 20_000,
      inspection160: false,
      seatingCapacity: ["7"],
      features: { comfort: [], exterior: [], performance: [], safety: [], tech: [] },
      warranty: false,
      dealerId: "toyota-plano",
      dealerLocation: "Plano, TX 75001",
      dealerName: "Toyota of Plano",
      mpg: "36-35",
      stock: "STK00099",
    };
    expect(() => render(<MyGarageClient cars={[car]} />)).not.toThrow();
  });
});

describe("getBadgeType branch coverage (via car labels)", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  const cases: Array<{ label: string | undefined; expectedBadge: string | null }> = [
    { label: undefined, expectedBadge: null },
    { label: "", expectedBadge: null },
    { label: "Excellent Price", expectedBadge: "excellent" },
    { label: "Price Drop", expectedBadge: "priceDrop" },
    { label: "Fair Price", expectedBadge: "available" },
    { label: "Good Deal", expectedBadge: "available" },
  ];

  for (const { label, expectedBadge } of cases) {
    it(`label="${label}" → badge="${expectedBadge}"`, () => {
      const car = buildVehicle({
        vin: `VIN_BADGE_${label ?? "UNDEF"}`,
        labels: label ? [label] : [],
      });

      render(<MyGarageClient becauseViewedCars={[]} cars={[car]} />);
      const cards = screen.getAllByTestId(`car-card-VIN_BADGE_${label ?? "UNDEF"}`);
      const card = cards[0];
      if (expectedBadge) {
        expect(card).toHaveAttribute("data-badge", expectedBadge);
      } else {
        expect(card).not.toHaveAttribute("data-badge");
      }
    });
  }
});
