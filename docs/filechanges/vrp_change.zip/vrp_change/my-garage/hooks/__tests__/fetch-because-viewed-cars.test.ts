import { describe, expect, it, vi } from "vitest";
import { becauseViewedVehicles, fetchBecauseYouViewedCars } from "../fetch-because-viewed-cars";

describe("fetchBecauseYouViewedCars", () => {
  it("returns an array of vehicles", () => {
    const result = fetchBecauseYouViewedCars();
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBe(becauseViewedVehicles.length);
  });

  it("returns vehicles with correct structure", () => {
    const result = fetchBecauseYouViewedCars();
    for (const vehicle of result) {
      expect(vehicle).toHaveProperty("id");
      expect(vehicle).toHaveProperty("title");
      expect(vehicle).toHaveProperty("make");
      expect(vehicle).toHaveProperty("model");
      expect(vehicle).toHaveProperty("year");
      expect(vehicle).toHaveProperty("price");
      expect(vehicle).toHaveProperty("vin");
      expect(vehicle).toHaveProperty("image");
      expect(vehicle).toHaveProperty("miles");
      expect(vehicle).toHaveProperty("odometer");
      expect(vehicle).toHaveProperty("mileage");
      expect(vehicle).toHaveProperty("bodyType");
      expect(vehicle).toHaveProperty("match");
      expect(vehicle).toHaveProperty("labels");
      expect(vehicle).toHaveProperty("owners");
      expect(vehicle).toHaveProperty("extColorName");
      expect(vehicle).toHaveProperty("extColorCode");
      expect(vehicle).toHaveProperty("intColorName");
      expect(vehicle).toHaveProperty("intColorCode");
    }
  });

  it("returns the same vehicles as becauseViewedVehicles (shuffled)", () => {
    const result = fetchBecauseYouViewedCars();
    expect(result).toHaveLength(becauseViewedVehicles.length);
    const resultIds = result.map((v) => v.id).sort();
    const originalIds = becauseViewedVehicles.map((v) => v.id).sort();
    expect(resultIds).toEqual(originalIds);
  });

  it("shuffles the array (order changes)", () => {
    const originalRandom = Math.random;
    let callCount = 0;
    Math.random = vi.fn(() => {
      callCount++;
      return callCount % 2 === 0 ? 0.1 : 0.9;
    });

    const result = fetchBecauseYouViewedCars();

    expect(result).toHaveLength(becauseViewedVehicles.length);

    Math.random = originalRandom;
  });

  it("does not modify the original becauseViewedVehicles array", () => {
    const original = [...becauseViewedVehicles];
    fetchBecauseYouViewedCars();
    expect(becauseViewedVehicles).toEqual(original);
  });
});

describe("becauseViewedVehicles", () => {
  it("is an array of 20 vehicles", () => {
    expect(Array.isArray(becauseViewedVehicles)).toBe(true);
    expect(becauseViewedVehicles).toHaveLength(20);
  });

  it("contains vehicles with unique IDs from 1 to 20", () => {
    const ids = becauseViewedVehicles.map((v) => v.id);
    expect(ids).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]);
  });

  it("all vehicles have toyota make", () => {
    for (const vehicle of becauseViewedVehicles) {
      expect(vehicle.make).toBe("toyota");
    }
  });

  it("all vehicles have valid prices (positive numbers)", () => {
    for (const vehicle of becauseViewedVehicles) {
      expect(typeof vehicle.price).toBe("number");
      expect(vehicle.price).toBeGreaterThan(0);
    }
  });

  it("all vehicles have valid mileage (positive numbers)", () => {
    for (const vehicle of becauseViewedVehicles) {
      expect(typeof vehicle.mileage).toBe("number");
      expect(vehicle.mileage).toBeGreaterThanOrEqual(0);
    }
  });

  it("all vehicles have match percentage between 0 and 100", () => {
    for (const vehicle of becauseViewedVehicles) {
      expect(vehicle.match).toBeGreaterThanOrEqual(0);
      expect(vehicle.match).toBeLessThanOrEqual(100);
    }
  });

  it("all vehicles have owners count of 1, 2, or 3", () => {
    for (const vehicle of becauseViewedVehicles) {
      expect([1, 2, 3]).toContain(vehicle.owners);
    }
  });

  it("some vehicles have labels array with 'Price Drop'", () => {
    const vehiclesWithPriceDrop = becauseViewedVehicles.filter((v) =>
      v.labels.includes("Price Drop")
    );
    expect(vehiclesWithPriceDrop.length).toBeGreaterThan(0);
  });

  it("some vehicles have empty labels array", () => {
    const vehiclesWithEmptyLabels = becauseViewedVehicles.filter((v) => v.labels.length === 0);
    expect(vehiclesWithEmptyLabels.length).toBeGreaterThan(0);
  });
});
