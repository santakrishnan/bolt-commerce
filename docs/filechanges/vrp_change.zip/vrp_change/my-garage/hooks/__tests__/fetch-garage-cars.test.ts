/**
 * @vitest-environment jsdom
 */

vi.resetModules();

const mockVehiclesData: Vehicle[] = [
  {
    id: 1,
    vin: "VIN001",
    title: "2024 Toyota Camry",
    make: "Toyota",
    model: "Camry",
    variant: "XSE",
    year: 2024,
    price: 32_000,
    odometer: "12,345 mi",
    miles: "Toyota of Fort Worth - 6.1mi",
    image: "/images/camry.jpg",
    labels: [],
    match: 0,
    owners: 1,
    bodyType: "Sedan",
    drivetrain: "FWD",
    fuelType: "Gasoline",
    transmission: "Automatic",
    extColorCode: "#FFFFFF",
    extColorName: "White",
    intColorCode: "#000000",
    intColorName: "Black",
    mileage: 12_345,
    inspection160: true,
    seatingCapacity: ["5"],
    features: { comfort: [], exterior: [], performance: [], safety: [], tech: [] },
    warranty: false,
    dealerId: "toyota-plano",
    dealerLocation: "Plano, TX 75001",
    dealerName: "Toyota of Plano",
    mpg: "28-39",
    stock: "STK00001",
  },
  {
    id: 2,
    vin: "VIN002",
    title: "2023 Toyota RAV4",
    make: "Toyota",
    model: "RAV4",
    variant: "LE",
    year: 2023,
    price: 28_000,
    odometer: "15,000 mi",
    miles: "Toyota of Dallas - 8.2mi",
    image: "/images/rav4.jpg",
    labels: ["Price Drop"],
    match: 85,
    owners: 1,
    bodyType: "SUV",
    drivetrain: "FWD",
    fuelType: "Gasoline",
    transmission: "Automatic",
    extColorCode: "#000000",
    extColorName: "Black",
    intColorCode: "#FFFFFF",
    intColorName: "Gray",
    mileage: 15_000,
    inspection160: true,
    seatingCapacity: ["5"],
    features: { comfort: [], exterior: [], performance: [], safety: [], tech: [] },
    warranty: false,
    dealerId: "toyota-plano",
    dealerLocation: "Plano, TX 75001",
    dealerName: "Toyota of Plano",
    mpg: "28-39",
    stock: "STK00002",
  },
];

vi.mock("@features/search/lib/mock-vehicles", () => {
  const mockVehiclesData: Vehicle[] = [
    {
      id: 1,
      vin: "VIN001",
      title: "2024 Toyota Camry",
      make: "Toyota",
      model: "Camry",
      variant: "XSE",
      year: 2024,
      price: 32_000,
      odometer: "12,345 mi",
      miles: "Toyota of Fort Worth - 6.1mi",
      image: "/images/camry.jpg",
      labels: [],
      match: 0,
      owners: 1,
      bodyType: "Sedan",
      drivetrain: "FWD",
      fuelType: "Gasoline",
      transmission: "Automatic",
      extColorCode: "#FFFFFF",
      extColorName: "White",
      intColorCode: "#000000",
      intColorName: "Black",
      mileage: 12_345,
      inspection160: true,
      seatingCapacity: ["5"],
      features: { comfort: [], exterior: [], performance: [], safety: [], tech: [] },
      warranty: false,
      dealerId: "toyota-plano",
      dealerLocation: "Plano, TX 75001",
      dealerName: "Toyota of Plano",
      mpg: "28-39",
      stock: "STK00001",
    },
    {
      id: 2,
      vin: "VIN002",
      title: "2023 Toyota RAV4",
      make: "Toyota",
      model: "RAV4",
      variant: "LE",
      year: 2023,
      price: 28_000,
      odometer: "15,000 mi",
      miles: "Toyota of Dallas - 8.2mi",
      image: "/images/rav4.jpg",
      labels: ["Price Drop"],
      match: 85,
      owners: 1,
      bodyType: "SUV",
      drivetrain: "FWD",
      fuelType: "Gasoline",
      transmission: "Automatic",
      extColorCode: "#000000",
      extColorName: "Black",
      intColorCode: "#FFFFFF",
      intColorName: "Gray",
      mileage: 15_000,
      inspection160: true,
      seatingCapacity: ["5"],
      features: { comfort: [], exterior: [], performance: [], safety: [], tech: [] },
      warranty: false,
      dealerId: "toyota-plano",
      dealerLocation: "Plano, TX 75001",
      dealerName: "Toyota of Plano",
      mpg: "28-39",
      stock: "STK00002",
    },
  ];

  return {
    mockVehicles: mockVehiclesData,
  };
});

import type { Vehicle } from "@shared/types";
import { describe, expect, it, vi } from "vitest";
import { fetchGarageCars } from "../fetch-garage-cars";

// =============================================================================
// TESTS
// =============================================================================

describe("fetchGarageCars", () => {
  it("returns an array of vehicles", () => {
    const result = fetchGarageCars();
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBe(mockVehiclesData.length);
  });

  it("returns vehicles with correct structure", () => {
    const result = fetchGarageCars();
    for (const vehicle of result) {
      expect(vehicle).toHaveProperty("id");
      expect(vehicle).toHaveProperty("vin");
      expect(vehicle).toHaveProperty("title");
      expect(vehicle).toHaveProperty("make");
      expect(vehicle).toHaveProperty("model");
      expect(vehicle).toHaveProperty("year");
      expect(vehicle).toHaveProperty("price");
      expect(vehicle).toHaveProperty("odometer");
      expect(vehicle).toHaveProperty("miles");
      expect(vehicle).toHaveProperty("image");
      expect(vehicle).toHaveProperty("labels");
      expect(vehicle).toHaveProperty("match");
      expect(vehicle).toHaveProperty("owners");
      expect(vehicle).toHaveProperty("bodyType");
      expect(vehicle).toHaveProperty("drivetrain");
      expect(vehicle).toHaveProperty("fuelType");
      expect(vehicle).toHaveProperty("transmission");
      expect(vehicle).toHaveProperty("extColorCode");
      expect(vehicle).toHaveProperty("extColorName");
      expect(vehicle).toHaveProperty("intColorCode");
      expect(vehicle).toHaveProperty("intColorName");
      expect(vehicle).toHaveProperty("mileage");
      expect(vehicle).toHaveProperty("inspection160");
      expect(vehicle).toHaveProperty("seatingCapacity");
      expect(vehicle).toHaveProperty("features");
    }
  });

  it("returns the same vehicles as mockVehicles (shuffled)", () => {
    const result = fetchGarageCars();
    expect(result).toHaveLength(mockVehiclesData.length);
    // Check that all vehicles are present (order may differ)
    const resultVins = result.map((v) => v.vin).sort();
    const originalVins = mockVehiclesData.map((v) => v.vin).sort();
    expect(resultVins).toEqual(originalVins);
  });

  it("shuffles the array (order changes)", () => {
    // Mock Math.random to return predictable values for testing shuffle
    const originalRandom = Math.random;
    let callCount = 0;
    Math.random = vi.fn(() => {
      callCount++;
      // Return values that will cause swaps
      return callCount % 2 === 0 ? 0.1 : 0.9;
    });

    const result = fetchGarageCars();
    // Since we mocked random, the shuffle should produce a different order
    // But to be deterministic, just check that it's an array and has the right length
    expect(result).toHaveLength(mockVehiclesData.length);

    // Restore original Math.random
    Math.random = originalRandom;
  });

  it("does not modify the original mockVehicles array", () => {
    const original = [...mockVehiclesData];
    fetchGarageCars();
    expect(mockVehiclesData).toEqual(original);
  });

  it("returns different order on multiple calls (due to shuffle)", () => {
    const result1 = fetchGarageCars();
    const result2 = fetchGarageCars();
    // Since shuffle is random, results should usually be different, but to avoid flakiness,
    // just check they are arrays of same length
    expect(result1).toHaveLength(mockVehiclesData.length);
    expect(result2).toHaveLength(mockVehiclesData.length);
  });
});
