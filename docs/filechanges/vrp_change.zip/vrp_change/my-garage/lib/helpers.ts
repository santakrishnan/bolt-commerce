/** Utility functions for My Garage feature. */

/** Parse dealer name and distance from the miles field (e.g. "Toyota of Fort Worth - 6.1mi") */
export function parseDealerInfo(miles: string) {
  const parts = miles.split(" - ");
  return {
    dealerName: parts[0] ?? miles,
    distance: parts[1] ?? "",
  };
}

/** Compute badge type from label string */
export function getBadgeType(
  label: string | undefined
): "excellent" | "priceDrop" | "available" | undefined {
  if (!label) {
    return undefined;
  }
  if (label === "Excellent Price") {
    return "excellent";
  }
  if (label === "Price Drop") {
    return "priceDrop";
  }
  return "available";
}
