// ── Public API for the my-garage feature ─────────────────────────────

export { MyGarageWrapper } from "./components/my-garagewrapper";
