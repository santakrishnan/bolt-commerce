import type { Vehicle } from "@shared/types";

export interface MyGarageData {
  becauseYouViewed: Vehicle[];
  becauseYouViewedLabel: string;
  bestMatches: Vehicle[];
  recentPriceDrop: Vehicle[];
}

export interface MyGarageApiResponse {
  data: MyGarageData;
}
