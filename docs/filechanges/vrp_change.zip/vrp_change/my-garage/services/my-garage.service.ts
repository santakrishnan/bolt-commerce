/**
 * My Garage Service
 *
 * Fetches personalized vehicle data for the My Garage page:
 * - bestMatches       — vehicles matched to the user's profile
 * - becauseYouViewed  — recommendations based on viewed vehicles
 * - becauseYouViewedLabel — display name for the "Because You Viewed" heading
 * - recentPriceDrop   — vehicles with recent price reductions
 *
 * ─── MOCK MODE (current) ────────────────────────────────────────────────────
 * Active when PROFILE_SERVICE_URL is not set or USE_MOCK_PROFILE=true.
 *
 * Mock data sources:
 *   bestMatches        → @features/search/lib/mock-vehicles (shared dataset, shuffled per request)
 *   becauseYouViewed   → ./mock-because-viewed.ts (10 dedicated vehicles, shuffled per request)
 *   recentPriceDrop    → filtered from bestMatches where vehicle.oldPrice is set
 *   becauseYouViewedLabel → randomly selected from BECAUSE_YOU_VIEWED_LABELS on each request
 *
 * To swap in real data: set PROFILE_SERVICE_URL env var. The service will call
 * GET {PROFILE_SERVICE_URL}/profile/garage and fall back to mock on failure.
 *
 * ─── PRODUCTION MODE (future) ───────────────────────────────────────────────
 * Endpoint: GET {PROFILE_SERVICE_URL}/profile/garage
 * Auth:     Bearer {PROFILE_API_KEY} (optional)
 * Expected response shape: { data: MyGarageData }
 */

import type { Vehicle } from "@shared/types";
import type { MyGarageData } from "./my-garage-types";

function isMockMode(): boolean {
  return !process.env.PROFILE_SERVICE_URL || process.env.USE_MOCK_PROFILE === "true";
}

// ─── Mock data ───────────────────────────────────────────────────────────────

const BECAUSE_YOU_VIEWED_LABELS = ["Toyota Camry", "Toyota Tundra", "Toyota RAV4"];

async function getMockGarageData(): Promise<MyGarageData> {
  // Lazy import so mock data is never bundled in production
  const [{ mockVehicles }, { becauseViewedVehicles }] = await Promise.all([
    import("@features/search/lib/mock-vehicles"),
    import("@features/my-garage/services/mock-because-viewed"),
  ]);

  const shuffled = shuffle(mockVehicles as Vehicle[]);
  const label =
    BECAUSE_YOU_VIEWED_LABELS[Math.floor(Math.random() * BECAUSE_YOU_VIEWED_LABELS.length)] ??
    "Toyota Camry";

  return {
    bestMatches: shuffled,
    becauseYouViewed: shuffle(becauseViewedVehicles as Vehicle[]),
    becauseYouViewedLabel: label,
    recentPriceDrop: shuffled.filter((v) => v.oldPrice != null),
  };
}

/** Fisher-Yates shuffle — returns a new randomly-ordered copy. */
function shuffle<T>(arr: readonly T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = copy[i];
    copy[i] = copy[j] as T;
    copy[j] = tmp as T;
  }
  return copy;
}

//  Real service

async function fetchFromProfileService(): Promise<MyGarageData> {
  const baseUrl = process.env.PROFILE_SERVICE_URL;
  if (!baseUrl) {
    throw new Error("[MyGarageService] PROFILE_SERVICE_URL is not configured");
  }
  const res = await fetch(`${baseUrl}/profile/garage`, {
    headers: {
      ...(process.env.PROFILE_API_KEY && {
        Authorization: `Bearer ${process.env.PROFILE_API_KEY}`,
      }),
    },
    next: { revalidate: 60 },
  });

  if (!res.ok) {
    throw new Error(`[MyGarageService] Profile service error: ${res.status} ${res.statusText}`);
  }

  const json = (await res.json()) as { data: MyGarageData };
  return json.data;
}

// ─── Public API

// Fetch My Garage data; fall back to mock data if the profile service is unavailable.
export async function getMyGarageData(): Promise<MyGarageData> {
  if (isMockMode()) {
    console.log("[MyGarageService] Using mock data");
    return getMockGarageData();
  }

  try {
    return await fetchFromProfileService();
  } catch (error) {
    console.error("[MyGarageService] Falling back to mock data due to error:", error);
    return getMockGarageData();
  }
}
