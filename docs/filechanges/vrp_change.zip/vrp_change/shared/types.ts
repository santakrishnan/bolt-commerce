/** Backwards-compatible re-exports from the canonical vehicle entity. */

export type {
  Drivetrain,
  FuelType,
  Transmission,
  Vehicle,
  VehicleEstimation,
  VehicleFeatures,
} from "@shared/vehicle";
