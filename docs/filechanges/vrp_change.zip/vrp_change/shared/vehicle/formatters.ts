/** Shared vehicle formatting utilities. */

const priceFormatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});

const numberFormatter = new Intl.NumberFormat("en-US");

/** Format a numeric price as "$12,345". */
export function formatPrice(value: number): string {
  return priceFormatter.format(value);
}

/** Format a mileage string (e.g. "25000") as "25,000 mi". Returns input unchanged if non-numeric. */
export function formatMileage(miles: string): string {
  const cleaned = miles.replace(/[^0-9.]/g, "");
  const num = Number(cleaned);
  if (!cleaned || Number.isNaN(num)) {
    return miles;
  }
  return `${numberFormatter.format(num)} mi`;
}
