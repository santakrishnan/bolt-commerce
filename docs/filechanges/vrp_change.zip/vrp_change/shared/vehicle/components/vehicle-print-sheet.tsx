import {
  PrintColors,
  PrintDealer,
  PrintFeatures,
  PrintHeader,
  PrintImages,
  PrintSpecs,
} from "./vehicle-print-sheet-sections";

export interface VehiclePrintData {
  condition?: string;
  dealer?: string;
  distance?: string;
  drivetrain?: string;
  exterior?: string;
  exteriorColorCode?: string;
  features?: string[];
  images?: string[];
  inspected?: boolean;
  interior?: string;
  interiorColorCode?: string;
  location?: string;
  make?: string;
  miles?: string;
  model?: string;
  mpg?: string;
  originalPrice?: number;
  price?: number;
  stock?: string;
  title?: string;
  vin?: string;
  warranty?: boolean;
  year?: number;
}

const PRINT_CSS = `
  @media print {
    body > *:not([data-print-portal]) { display: none !important; }
    [data-print-portal] {
      display: block !important;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
      color-adjust: exact !important;
    }
    [data-print-portal] * {
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
      color-adjust: exact !important;
    }
  }
`;

export function VehiclePrintSheet({ vehicle }: { vehicle: VehiclePrintData }) {
  const title = vehicle.title ?? "";

  return (
    <>
      <style precedence="print">{PRINT_CSS}</style>
      <div
        style={{
          fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
          color: "#1a1a1a",
          padding: 40,
        }}
      >
        <PrintHeader title={title} vehicle={vehicle} />
        <PrintImages images={vehicle.images ?? []} />
        <PrintSpecs vehicle={vehicle} />
        <PrintColors vehicle={vehicle} />
        <PrintFeatures features={vehicle.features ?? []} />
        <PrintDealer vehicle={vehicle} />
        <div
          style={{
            textAlign: "center",
            marginTop: 30,
            fontSize: 12,
            color: "#9ca3af",
          }}
        >
          Printed on {new Date().toLocaleDateString()}
        </div>
      </div>
    </>
  );
}
