/** Sub-components for VehiclePrintSheet. */

import type { VehiclePrintData } from "./vehicle-print-sheet";
import {
  badgeStyle,
  sectionStyle,
  sectionTitleStyle,
  specLabelStyle,
  specValueStyle,
} from "./vehicle-print-sheet.constants";

export function PrintHeader({ title, vehicle }: { title: string; vehicle: VehiclePrintData }) {
  return (
    <div
      style={{
        textAlign: "center",
        marginBottom: 30,
        paddingBottom: 20,
        borderBottom: "2px solid #e5e7eb",
      }}
    >
      <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 8, margin: 0 }}>{title}</h1>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "baseline",
          gap: 12,
        }}
      >
        <span style={{ fontSize: 26, fontWeight: 700, color: "#1d4ed8" }}>
          ${(vehicle.price ?? 0).toLocaleString()}
        </span>
        {vehicle.originalPrice ? (
          <>
            <span>was</span>
            <span
              style={{
                fontSize: 16,
                color: "#6b7280",
                textDecoration: "line-through",
              }}
            >
              ${vehicle.originalPrice.toLocaleString()}
            </span>
          </>
        ) : null}
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          gap: 12,
          marginTop: 12,
          flexWrap: "wrap",
        }}
      >
        {vehicle.condition ? <span style={badgeStyle}>{vehicle.condition}</span> : null}
        {vehicle.warranty ? <span style={badgeStyle}>Warranty</span> : null}
        {vehicle.inspected ? <span style={badgeStyle}>Inspected</span> : null}
      </div>
    </div>
  );
}

export function PrintImages({ images }: { images: string[] }) {
  if (images.length === 0) {
    return null;
  }
  return (
    <div style={sectionStyle}>
      <div style={sectionTitleStyle}>Vehicle Photo</div>
      {/* biome-ignore lint/performance/noImgElement: Renders in a standalone print window without Next.js */}
      <img
        alt="Vehicle"
        height={400}
        src={images[0]}
        style={{
          width: "100%",
          borderRadius: 8,
          objectFit: "cover",
          maxHeight: 400,
        }}
        width={800}
      />
    </div>
  );
}

export function PrintSpecs({ vehicle }: { vehicle: VehiclePrintData }) {
  return (
    <div style={sectionStyle}>
      <div style={sectionTitleStyle}>Specifications</div>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: 16,
        }}
      >
        <div>
          <div style={specLabelStyle}>Miles</div>
          <p style={specValueStyle}>{vehicle.miles ?? "—"}</p>
        </div>
        <div>
          <div style={specLabelStyle}>Drivetrain</div>
          <p style={specValueStyle}>{vehicle.drivetrain ?? "—"}</p>
        </div>
        <div>
          <div style={specLabelStyle}>MPG</div>
          <p style={specValueStyle}>{vehicle.mpg ?? "—"}</p>
        </div>
        <div>
          <div style={specLabelStyle}>Stock #</div>
          <p style={specValueStyle}>{vehicle.stock ?? "—"}</p>
        </div>
        <div>
          <div style={specLabelStyle}>VIN</div>
          <p style={specValueStyle}>{vehicle.vin ?? "—"}</p>
        </div>
      </div>
    </div>
  );
}

export function PrintColors({ vehicle }: { vehicle: VehiclePrintData }) {
  return (
    <div style={sectionStyle}>
      <div style={sectionTitleStyle}>Colors</div>
      <div style={{ display: "flex", gap: 40 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div
            style={{
              width: 28,
              height: 28,
              borderRadius: "50%",
              border: "1px solid #d1d5db",
              backgroundColor: vehicle.exteriorColorCode ?? "#ccc",
              WebkitPrintColorAdjust: "exact",
              printColorAdjust: "exact",
            }}
          />
          <div>
            <div style={{ fontSize: 12, color: "#6b7280" }}>Exterior</div>
            <div style={{ fontSize: 14, fontWeight: 600 }}>{vehicle.exterior ?? "—"}</div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div
            style={{
              width: 28,
              height: 28,
              borderRadius: "50%",
              border: "1px solid #d1d5db",
              backgroundColor: vehicle.interiorColorCode ?? "#ccc",
              WebkitPrintColorAdjust: "exact",
              printColorAdjust: "exact",
            }}
          />
          <div>
            <div style={{ fontSize: 12, color: "#6b7280" }}>Interior</div>
            <div style={{ fontSize: 14, fontWeight: 600 }}>{vehicle.interior ?? "—"}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function PrintFeatures({ features }: { features: string[] }) {
  if (features.length === 0) {
    return null;
  }
  return (
    <div style={sectionStyle}>
      <div style={sectionTitleStyle}>Key Features</div>
      <ul
        style={{
          columns: 2,
          columnGap: 24,
          listStyle: "none",
          padding: 0,
          margin: 0,
        }}
      >
        {features.map((f) => (
          <li key={f} style={{ padding: "4px 0", fontSize: 14 }}>
            <span style={{ color: "#16a34a", fontWeight: 700, marginRight: 4 }}>✓</span>
            {f}
          </li>
        ))}
      </ul>
    </div>
  );
}

export function PrintDealer({ vehicle }: { vehicle: VehiclePrintData }) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "16px 0",
        borderTop: "1px solid #e5e7eb",
        borderBottom: "1px solid #e5e7eb",
      }}
    >
      <div>
        <div style={{ fontSize: 15, fontWeight: 600 }}>{vehicle.dealer ?? "—"}</div>
        <div style={{ fontSize: 13, color: "#6b7280" }}>{vehicle.location ?? ""}</div>
      </div>
      <div style={{ fontSize: 13, color: "#6b7280" }}>{vehicle.distance ?? ""}</div>
    </div>
  );
}
