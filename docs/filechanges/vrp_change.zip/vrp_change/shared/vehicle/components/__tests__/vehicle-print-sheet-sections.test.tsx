import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import type { VehiclePrintData } from "../vehicle-print-sheet";
import {
  PrintColors,
  PrintDealer,
  PrintFeatures,
  PrintHeader,
  PrintImages,
  PrintSpecs,
} from "../vehicle-print-sheet-sections";

// Top-level regex constants
const FORMATTED_PRICE_28500_REGEX = /28,500/;
const FORMATTED_PRICE_32000_REGEX = /32,000/;
const FORMATTED_PRICE_25000_REGEX = /25,000/;
const PRICE_ZERO_REGEX = /\$\s*0/;
const PRICE_299M_REGEX = /299,999,999/;
const PRICE_1B_REGEX = /1,000,000,000/;
const ANY_CHAR_REGEX = /./;

/** Minimal fixture — only the fields required by PrintHeader. */
const VEHICLE_BASE: VehiclePrintData = {
  title: "2023 Toyota Camry",
  price: 28_500,
};

/** Fully-populated fixture used for integration and completeness tests. */
const VEHICLE_FULL: VehiclePrintData = {
  title: "2023 Honda Civic EX",
  price: 24_999,
  originalPrice: 32_000,
  condition: "Used",
  warranty: true,
  inspected: true,
  miles: "32,000",
  drivetrain: "FWD",
  mpg: "33/42",
  stock: "H2023001",
  vin: "2HGFC2F59LH123456",
  exterior: "Sonic Gray Pearl",
  exteriorColorCode: "#6e7477",
  interior: "Black Fabric",
  interiorColorCode: "#1a1a1a",
  features: ["Backup Camera", "Bluetooth", "Apple CarPlay", "Cruise Control"],
  dealer: "Civic Motors",
  location: "Portland, OR",
  distance: "12 miles",
  images: ["/images/car1.jpg", "/images/car2.jpg"],
};

describe("VehiclePrintSheet Sections", () => {
  describe("PrintHeader", () => {
    it("renders title correctly", () => {
      render(<PrintHeader title="Vehicle Details" vehicle={VEHICLE_BASE} />);
      expect(screen.getByText("Vehicle Details")).toBeInTheDocument();
    });

    it("formats price with locale string", () => {
      render(<PrintHeader title="Details" vehicle={{ title: "Test", price: 28_500 }} />);
      expect(screen.getByText(FORMATTED_PRICE_28500_REGEX)).toBeInTheDocument();
    });

    it("renders zero price when price is undefined", () => {
      render(<PrintHeader title="Details" vehicle={{ title: "Test" }} />);
      expect(screen.getByText(PRICE_ZERO_REGEX)).toBeInTheDocument();
    });

    it("displays original price with strikethrough when provided", () => {
      render(
        <PrintHeader
          title="Details"
          vehicle={{ title: "Test", price: 24_999, originalPrice: 32_000 }}
        />
      );
      expect(screen.getByText("was")).toBeInTheDocument();
      expect(screen.getByText(FORMATTED_PRICE_32000_REGEX)).toBeInTheDocument();
    });

    it("does not render original price when undefined", () => {
      render(<PrintHeader title="Details" vehicle={VEHICLE_BASE} />);
      expect(screen.queryByText("was")).not.toBeInTheDocument();
    });

    it("renders condition badge when provided", () => {
      render(<PrintHeader title="Details" vehicle={{ title: "Test", condition: "Used" }} />);
      expect(screen.getByText("Used")).toBeInTheDocument();
    });

    it("does not render condition badge when undefined", () => {
      render(<PrintHeader title="Details" vehicle={VEHICLE_BASE} />);
      expect(screen.queryByText("Used")).not.toBeInTheDocument();
    });

    it("renders warranty badge when warranty is true", () => {
      render(<PrintHeader title="Details" vehicle={{ title: "Test", warranty: true }} />);
      expect(screen.getByText("Warranty")).toBeInTheDocument();
    });

    it("does not render warranty badge when warranty is false or undefined", () => {
      render(<PrintHeader title="Details" vehicle={{ title: "Test", warranty: false }} />);
      expect(screen.queryByText("Warranty")).not.toBeInTheDocument();
    });

    it("renders inspected badge when inspected is true", () => {
      render(<PrintHeader title="Details" vehicle={{ title: "Test", inspected: true }} />);
      expect(screen.getByText("Inspected")).toBeInTheDocument();
    });

    it("does not render inspected badge when inspected is false or undefined", () => {
      render(<PrintHeader title="Details" vehicle={{ title: "Test", inspected: false }} />);
      expect(screen.queryByText("Inspected")).not.toBeInTheDocument();
    });

    it("renders all three badges together", () => {
      render(
        <PrintHeader
          title="Details"
          vehicle={{
            title: "Test",
            condition: "Used",
            warranty: true,
            inspected: true,
          }}
        />
      );
      expect(screen.getByText("Used")).toBeInTheDocument();
      expect(screen.getByText("Warranty")).toBeInTheDocument();
      expect(screen.getByText("Inspected")).toBeInTheDocument();
    });

    it("renders with large price when price is very high", () => {
      render(<PrintHeader title="Luxury" vehicle={{ title: "Test", price: 299_999_999 }} />);
      expect(screen.getByText(PRICE_299M_REGEX)).toBeInTheDocument();
    });
  });

  describe("PrintImages", () => {
    it("returns null when images array is empty", () => {
      const { container } = render(<PrintImages images={[]} />);
      expect(container.firstChild).toBeNull();
    });

    it("renders image with first image from array", () => {
      render(<PrintImages images={["/images/car1.jpg", "/images/car2.jpg"]} />);
      const img = screen.getByAltText("Vehicle") as HTMLImageElement;
      expect(img).toBeInTheDocument();
      expect(img.src).toContain("/images/car1.jpg");
    });

    it("renders section title", () => {
      render(<PrintImages images={["/images/car1.jpg"]} />);
      expect(screen.getByText("Vehicle Photo")).toBeInTheDocument();
    });

    it("sets correct image dimensions", () => {
      render(<PrintImages images={["/images/car.jpg"]} />);
      const img = screen.getByAltText("Vehicle") as HTMLImageElement;
      expect(img.width).toBe(800);
      expect(img.height).toBe(400);
    });

    it("only renders first image even with multiple images", () => {
      render(<PrintImages images={["/images/car1.jpg", "/images/car2.jpg", "/images/car3.jpg"]} />);
      const img = screen.getByAltText("Vehicle") as HTMLImageElement;
      expect(img.src).toContain("/images/car1.jpg");
      expect(img.src).not.toContain("/images/car2.jpg");
    });

    it("handles single image in array", () => {
      render(<PrintImages images={["/images/single.jpg"]} />);
      expect(screen.getByAltText("Vehicle")).toBeInTheDocument();
    });
  });

  describe("PrintSpecs", () => {
    it("renders specifications section title", () => {
      render(<PrintSpecs vehicle={VEHICLE_BASE} />);
      expect(screen.getByText("Specifications")).toBeInTheDocument();
    });

    it("displays miles when provided", () => {
      render(<PrintSpecs vehicle={{ miles: "32,000" }} />);
      expect(screen.getByText("32,000")).toBeInTheDocument();
    });

    it("displays dash when miles is undefined", () => {
      render(<PrintSpecs vehicle={{}} />);
      const elements = screen.getAllByText(ANY_CHAR_REGEX);
      expect(elements.length).toBeGreaterThan(0);
    });

    it("displays drivetrain when provided", () => {
      render(<PrintSpecs vehicle={{ drivetrain: "FWD" }} />);
      expect(screen.getByText("FWD")).toBeInTheDocument();
    });

    it("displays MPG when provided", () => {
      render(<PrintSpecs vehicle={{ mpg: "33/42" }} />);
      expect(screen.getByText("33/42")).toBeInTheDocument();
    });

    it("displays stock number when provided", () => {
      render(<PrintSpecs vehicle={{ stock: "H2023001" }} />);
      expect(screen.getByText("H2023001")).toBeInTheDocument();
    });

    it("displays VIN when provided", () => {
      render(<PrintSpecs vehicle={{ vin: "2HGFC2F59LH123456" }} />);
      expect(screen.getByText("2HGFC2F59LH123456")).toBeInTheDocument();
    });

    it("renders all spec labels", () => {
      render(<PrintSpecs vehicle={VEHICLE_FULL} />);
      expect(screen.getByText("Miles")).toBeInTheDocument();
      expect(screen.getByText("Drivetrain")).toBeInTheDocument();
      expect(screen.getByText("MPG")).toBeInTheDocument();
      expect(screen.getByText("Stock #")).toBeInTheDocument();
      expect(screen.getByText("VIN")).toBeInTheDocument();
    });

    it("renders all dashes when all specs are undefined", () => {
      render(<PrintSpecs vehicle={{}} />);
      const elements = screen.getByText("Specifications").parentElement;
      expect(elements).toBeInTheDocument();
    });

    it("handles partial specs data", () => {
      render(
        <PrintSpecs
          vehicle={{
            miles: "50,000",
            drivetrain: "AWD",
            // mpg, stock, vin undefined
          }}
        />
      );
      expect(screen.getByText("50,000")).toBeInTheDocument();
      expect(screen.getByText("AWD")).toBeInTheDocument();
      expect(screen.getByText("Specifications")).toBeInTheDocument();
    });
  });

  describe("PrintColors", () => {
    it("renders colors section title", () => {
      render(<PrintColors vehicle={VEHICLE_BASE} />);
      expect(screen.getByText("Colors")).toBeInTheDocument();
    });

    it("displays exterior label", () => {
      render(<PrintColors vehicle={VEHICLE_BASE} />);
      expect(screen.getByText("Exterior")).toBeInTheDocument();
    });

    it("displays interior label", () => {
      render(<PrintColors vehicle={VEHICLE_BASE} />);
      expect(screen.getByText("Interior")).toBeInTheDocument();
    });

    it("displays exterior color name when provided", () => {
      render(<PrintColors vehicle={{ exterior: "Sonic Gray Pearl" }} />);
      expect(screen.getByText("Sonic Gray Pearl")).toBeInTheDocument();
    });

    it("displays interior color name when provided", () => {
      render(<PrintColors vehicle={{ interior: "Black Fabric" }} />);
      expect(screen.getByText("Black Fabric")).toBeInTheDocument();
    });

    it("displays dash for exterior when undefined", () => {
      render(<PrintColors vehicle={{ interior: "Black" }} />);
      expect(screen.getByText("Colors")).toBeInTheDocument();
    });

    it("displays dash for interior when undefined", () => {
      render(<PrintColors vehicle={{ exterior: "White" }} />);
      expect(screen.getByText("Colors")).toBeInTheDocument();
    });

    it("renders color swatches with provided color codes", () => {
      const { container } = render(
        <PrintColors
          vehicle={{
            exteriorColorCode: "#6e7477",
            interiorColorCode: "#1a1a1a",
          }}
        />
      );
      expect(container.querySelector("div")).toBeInTheDocument();
      expect(screen.getByText("Colors")).toBeInTheDocument();
    });

    it("uses default color code when not provided", () => {
      const { container } = render(<PrintColors vehicle={{}} />);
      expect(container.querySelector("div")).toBeInTheDocument();
      expect(screen.getByText("Colors")).toBeInTheDocument();
    });

    it("renders both exterior and interior color information", () => {
      render(
        <PrintColors
          vehicle={{
            exterior: "Pearl White",
            exteriorColorCode: "#ffffff",
            interior: "Tan Leather",
            interiorColorCode: "#d4a574",
          }}
        />
      );
      expect(screen.getByText("Pearl White")).toBeInTheDocument();
      expect(screen.getByText("Tan Leather")).toBeInTheDocument();
    });
  });

  describe("PrintFeatures", () => {
    it("returns null when features array is empty", () => {
      const { container } = render(<PrintFeatures features={[]} />);
      expect(container.firstChild).toBeNull();
    });

    it("renders features section title when features provided", () => {
      render(<PrintFeatures features={["Backup Camera"]} />);
      expect(screen.getByText("Key Features")).toBeInTheDocument();
    });

    it("renders all features in list", () => {
      render(
        <PrintFeatures
          features={["Backup Camera", "Bluetooth", "Apple CarPlay", "Cruise Control"]}
        />
      );
      expect(screen.getByText("Backup Camera")).toBeInTheDocument();
      expect(screen.getByText("Bluetooth")).toBeInTheDocument();
      expect(screen.getByText("Apple CarPlay")).toBeInTheDocument();
      expect(screen.getByText("Cruise Control")).toBeInTheDocument();
    });

    it("renders single feature", () => {
      render(<PrintFeatures features={["Backup Camera"]} />);
      expect(screen.getByText("Backup Camera")).toBeInTheDocument();
      expect(screen.getByText("Key Features")).toBeInTheDocument();
    });

    it("renders many features without overflow", () => {
      const features = Array.from({ length: 20 }, (_, i) => `Feature ${i + 1}`);
      render(<PrintFeatures features={features} />);
      expect(screen.getByText("Feature 1")).toBeInTheDocument();
      expect(screen.getByText("Feature 20")).toBeInTheDocument();
    });

    it("uses checkmark symbol for each feature", () => {
      const { container } = render(<PrintFeatures features={["Feature 1", "Feature 2"]} />);
      const checkmarks = container.querySelectorAll("span");
      const hasCheckmark = Array.from(checkmarks).some((span) => span.textContent?.includes("✓"));
      expect(hasCheckmark).toBe(true);
    });

    it("handles features with special characters", () => {
      render(
        <PrintFeatures features={["Apple CarPlay®", "Android™ Auto", "Lane-Keeping Assist"]} />
      );
      expect(screen.getByText("Apple CarPlay®")).toBeInTheDocument();
      expect(screen.getByText("Android™ Auto")).toBeInTheDocument();
      expect(screen.getByText("Lane-Keeping Assist")).toBeInTheDocument();
    });

    it("renders each feature as list item", () => {
      const { container } = render(<PrintFeatures features={["Feature 1", "Feature 2"]} />);
      const listItems = container.querySelectorAll("li");
      expect(listItems.length).toBe(2);
    });
  });

  describe("PrintDealer", () => {
    it("renders dealer name when provided", () => {
      render(<PrintDealer vehicle={{ dealer: "Civic Motors" }} />);
      expect(screen.getByText("Civic Motors")).toBeInTheDocument();
    });

    it("displays dash when dealer is undefined", () => {
      const { container } = render(<PrintDealer vehicle={{}} />);
      expect(container.querySelector("div")).toBeInTheDocument();
    });

    it("renders location when provided", () => {
      render(<PrintDealer vehicle={{ location: "Portland, OR" }} />);
      expect(screen.getByText("Portland, OR")).toBeInTheDocument();
    });

    it("renders empty string when location is undefined", () => {
      render(<PrintDealer vehicle={{ dealer: "Test Dealer" }} />);
      expect(screen.getByText("Test Dealer")).toBeInTheDocument();
    });

    it("renders distance when provided", () => {
      render(<PrintDealer vehicle={{ distance: "12 miles" }} />);
      expect(screen.getByText("12 miles")).toBeInTheDocument();
    });

    it("renders empty string when distance is undefined", () => {
      render(<PrintDealer vehicle={{ dealer: "Test" }} />);
      expect(screen.getByText("Test")).toBeInTheDocument();
    });

    it("renders all dealer information together", () => {
      render(
        <PrintDealer
          vehicle={{
            dealer: "Civic Motors",
            location: "Portland, OR",
            distance: "12 miles",
          }}
        />
      );
      expect(screen.getByText("Civic Motors")).toBeInTheDocument();
      expect(screen.getByText("Portland, OR")).toBeInTheDocument();
      expect(screen.getByText("12 miles")).toBeInTheDocument();
    });

    it("handles dealer with long name", () => {
      render(
        <PrintDealer
          vehicle={{
            dealer: "Very Long Dealer Name That Goes On And On And On And On",
          }}
        />
      );
      expect(
        screen.getByText("Very Long Dealer Name That Goes On And On And On And On")
      ).toBeInTheDocument();
    });

    it("handles dealer with special characters", () => {
      render(
        <PrintDealer
          vehicle={{
            dealer: "Smith & Associates, Inc.",
            location: "New York, NY 10001",
          }}
        />
      );
      expect(screen.getByText("Smith & Associates, Inc.")).toBeInTheDocument();
      expect(screen.getByText("New York, NY 10001")).toBeInTheDocument();
    });

    it("handles multiple dealers by rendering dealer on left", () => {
      const { container } = render(
        <PrintDealer
          vehicle={{
            dealer: "Primary Dealer",
            distance: "5 miles",
          }}
        />
      );
      const text = container.textContent;
      expect(text).toContain("Primary Dealer");
      expect(text).toContain("5 miles");
    });
  });

  /** Renders each section with VEHICLE_FULL to confirm they all mount without errors when given a complete data set. */
  describe("Integration scenarios", () => {
    it("handles complete vehicle data across all sections", () => {
      const { container: headerContainer } = render(
        <PrintHeader title="Complete Vehicle" vehicle={VEHICLE_FULL} />
      );
      expect(headerContainer).toBeInTheDocument();

      const { container: specsContainer } = render(<PrintSpecs vehicle={VEHICLE_FULL} />);
      expect(specsContainer).toBeInTheDocument();

      const { container: colorsContainer } = render(<PrintColors vehicle={VEHICLE_FULL} />);
      expect(colorsContainer).toBeInTheDocument();

      const { container: dealerContainer } = render(<PrintDealer vehicle={VEHICLE_FULL} />);
      expect(dealerContainer).toBeInTheDocument();
    });

    it("handles minimal vehicle data gracefully", () => {
      const minimalVehicle: VehiclePrintData = {};
      render(<PrintHeader title="Minimal" vehicle={minimalVehicle} />);
      render(<PrintSpecs vehicle={minimalVehicle} />);
      render(<PrintColors vehicle={minimalVehicle} />);
      render(<PrintDealer vehicle={minimalVehicle} />);
      expect(screen.getByText("Minimal")).toBeInTheDocument();
    });

    it("renders without features when features array is empty", () => {
      const { container } = render(<PrintFeatures features={[]} />);
      expect(container.firstChild).toBeNull();
    });

    it("renders without images when images array is empty", () => {
      const { container } = render(<PrintImages images={[]} />);
      expect(container.firstChild).toBeNull();
    });
  });

  /** Boundary inputs: zero/large prices, equal/inverted original prices, undefined fields, and special characters in strings. */
  describe("Edge cases", () => {
    it("handles zero price correctly", () => {
      render(<PrintHeader title="Free" vehicle={{ title: "Test", price: 0 }} />);
      expect(screen.getByText(PRICE_ZERO_REGEX)).toBeInTheDocument();
    });

    it("handles very large price numbers", () => {
      render(<PrintHeader title="Luxury" vehicle={{ title: "Test", price: 1_000_000_000 }} />);
      expect(screen.getByText(PRICE_1B_REGEX)).toBeInTheDocument();
    });

    it("handles original price equal to current price", () => {
      render(
        <PrintHeader
          title="Equal"
          vehicle={{ title: "Test", price: 50_000, originalPrice: 50_000 }}
        />
      );
      expect(screen.getByText("was")).toBeInTheDocument();
      expect(screen.getByText("Equal")).toBeInTheDocument();
    });

    it("handles original price less than current price", () => {
      render(
        <PrintHeader
          title="Price Up"
          vehicle={{ title: "Test", price: 30_000, originalPrice: 25_000 }}
        />
      );
      expect(screen.getByText("was")).toBeInTheDocument();
      expect(screen.getByText(FORMATTED_PRICE_25000_REGEX)).toBeInTheDocument();
    });

    it("handles empty string values for text fields", () => {
      render(
        <PrintDealer
          vehicle={{
            dealer: undefined,
            location: "",
            distance: "",
          }}
        />
      );
      expect(screen.getByText(ANY_CHAR_REGEX)).toBeInTheDocument();
    });

    it("handles features with commas and special punctuation", () => {
      render(<PrintFeatures features={["All-wheel, climate controlled", "Power, heated seats"]} />);
      expect(screen.getByText("All-wheel, climate controlled")).toBeInTheDocument();
      expect(screen.getByText("Power, heated seats")).toBeInTheDocument();
    });

    it("handles color codes with various hex formats", () => {
      const { container } = render(
        <PrintColors
          vehicle={{
            exteriorColorCode: "#ffffff",
            interiorColorCode: "#000000",
          }}
        />
      );
      expect(container).toBeInTheDocument();
    });

    it("handles image URLs with query parameters", () => {
      render(<PrintImages images={["/images/car.jpg?width=800&height=600"]} />);
      const img = screen.getByAltText("Vehicle") as HTMLImageElement;
      expect(img.src).toContain("/images/car.jpg");
    });

    it("handles missing specs by showing dashes", () => {
      render(
        <PrintSpecs
          vehicle={{
            miles: undefined,
            drivetrain: undefined,
            mpg: undefined,
            stock: undefined,
            vin: undefined,
          }}
        />
      );
      expect(screen.getByText("Specifications")).toBeInTheDocument();
    });
  });
});
