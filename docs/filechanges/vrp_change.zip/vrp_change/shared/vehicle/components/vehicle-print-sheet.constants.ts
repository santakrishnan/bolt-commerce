/** Shared inline styles for VehiclePrintSheet (needed because it renders in a standalone print window). */

import type { CSSProperties } from "react";

export const badgeStyle: CSSProperties = {
  padding: "4px 14px",
  borderRadius: 20,
  fontSize: 13,
  fontWeight: 600,
  border: "1px solid #d1d5db",
};

export const sectionStyle: CSSProperties = {
  margin: "24px 0",
};

export const sectionTitleStyle: CSSProperties = {
  fontSize: 18,
  fontWeight: 600,
  marginBottom: 12,
  paddingBottom: 8,
  borderBottom: "1px solid #e5e7eb",
};

export const specLabelStyle: CSSProperties = {
  fontSize: 12,
  color: "#6b7280",
  fontWeight: 600,
  textTransform: "uppercase",
  margin: 0,
};

export const specValueStyle: CSSProperties = {
  fontSize: 15,
  fontWeight: 600,
  marginTop: 2,
  margin: 0,
};
