/** Vehicle domain — public API. */

export type { VehiclePrintData } from "./components/vehicle-print-sheet";
export { VehiclePrintSheet } from "./components/vehicle-print-sheet";
export { formatMileage, formatPrice } from "./formatters";
export { vehicleToCarCardProps } from "./mappers";
export type {
  Drivetrain,
  FuelType,
  Transmission,
  Vehicle,
  VehicleEstimation,
  VehicleFeatures,
} from "./types";
