/** Vehicle mappers — re-exported from feature implementations. */

export { vehicleToCarCardProps } from "@features/search/lib/vehicle-to-card-props";
