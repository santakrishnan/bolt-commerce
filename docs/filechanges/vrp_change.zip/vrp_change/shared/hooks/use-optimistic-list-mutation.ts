"use client";

import { useMutation, useQueryClient } from "@tanstack/react-query";

// Optimistic mutation hook for list-based caches (favorites, search history).
export function useOptimisticListMutation<TItem, TVariables>({
  queryKey,
  mutationFn,
  updater,
}: {
  queryKey: readonly unknown[];
  mutationFn: (vars: TVariables) => Promise<unknown>;
  updater: (current: TItem[], vars: TVariables) => TItem[];
}) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn,
    onMutate: async (vars: TVariables) => {
      await queryClient.cancelQueries({ queryKey });
      const previous = queryClient.getQueryData<TItem[]>(queryKey) ?? [];
      queryClient.setQueryData<TItem[]>(queryKey, updater(previous, vars));
      return { previous };
    },
    onSuccess: (data: unknown) => {
      if (Array.isArray(data)) {
        queryClient.setQueryData<TItem[]>(queryKey, data);
      }
    },
    onError: (_err: unknown, _vars: TVariables, context?: { previous: TItem[] }) => {
      if (context?.previous) {
        queryClient.setQueryData(queryKey, context.previous);
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey, refetchType: "none" });
    },
  });
}
