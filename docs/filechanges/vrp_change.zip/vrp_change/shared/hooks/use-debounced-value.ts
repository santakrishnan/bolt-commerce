import { useEffect, useRef, useState } from "react";

export function useDebouncedValue<T>(value: T, delayMs = 300): T {
  const [debounced, setDebounced] = useState(value);
  const timer = useRef<number | null>(null);

  useEffect(() => {
    if (timer.current) {
      window.clearTimeout(timer.current);
    }
    timer.current = window.setTimeout(() => setDebounced(value), delayMs) as unknown as number;
    return () => {
      if (timer.current) {
        window.clearTimeout(timer.current);
      }
    };
  }, [value, delayMs]);

  return debounced;
}
