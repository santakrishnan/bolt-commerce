/**
 * Unit tests for useEscapeKey hook
 * @module shared/hooks/__tests__/use-escape-key
 */

import { renderHook } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { useEscapeKey } from "../use-escape-key";

describe("useEscapeKey", () => {
  let handler: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    handler = vi.fn();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  it("calls handler when Escape key is pressed", () => {
    renderHook(() => useEscapeKey(handler));

    const event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(1);
    expect(handler).toHaveBeenCalledWith(event);
  });

  it("calls handler when Esc key is pressed (legacy key name)", () => {
    renderHook(() => useEscapeKey(handler));

    const event = new KeyboardEvent("keydown", { key: "Esc" });
    window.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(1);
    expect(handler).toHaveBeenCalledWith(event);
  });

  it("does not call handler for other keys", () => {
    renderHook(() => useEscapeKey(handler));

    const keys = ["Enter", "Space", "Tab", "a", "1", "ArrowUp", "Backspace"];

    for (const key of keys) {
      const event = new KeyboardEvent("keydown", { key });
      window.dispatchEvent(event);
    }

    expect(handler).not.toHaveBeenCalled();
  });

  it("does not call handler when enabled is false", () => {
    renderHook(() => useEscapeKey(handler, false));

    const event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler).not.toHaveBeenCalled();
  });

  it("calls handler when enabled is true (explicit)", () => {
    renderHook(() => useEscapeKey(handler, true));

    const event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(1);
  });

  it("defaults to enabled when no enabled parameter is provided", () => {
    renderHook(() => useEscapeKey(handler));

    const event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(1);
  });

  it("removes event listener on unmount", () => {
    const removeEventListenerSpy = vi.spyOn(window, "removeEventListener");

    const { unmount } = renderHook(() => useEscapeKey(handler));

    unmount();

    expect(removeEventListenerSpy).toHaveBeenCalledWith("keydown", expect.any(Function));
    removeEventListenerSpy.mockRestore();
  });

  it("adds event listener on mount", () => {
    const addEventListenerSpy = vi.spyOn(window, "addEventListener");

    renderHook(() => useEscapeKey(handler));

    expect(addEventListenerSpy).toHaveBeenCalledWith("keydown", expect.any(Function));
    addEventListenerSpy.mockRestore();
  });

  it("does not add event listener when enabled is false", () => {
    const addEventListenerSpy = vi.spyOn(window, "addEventListener");

    renderHook(() => useEscapeKey(handler, false));

    expect(addEventListenerSpy).not.toHaveBeenCalled();
    addEventListenerSpy.mockRestore();
  });

  it("handles multiple Escape key presses", () => {
    renderHook(() => useEscapeKey(handler));

    let event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(3);
  });

  it("updates handler when handler function changes", () => {
    const newHandler = vi.fn();

    const { rerender } = renderHook(({ handlerFn }) => useEscapeKey(handlerFn), {
      initialProps: { handlerFn: handler },
    });

    let event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(1);
    expect(newHandler).not.toHaveBeenCalled();

    rerender({ handlerFn: newHandler });

    event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(1);
    expect(newHandler).toHaveBeenCalledTimes(1);
  });

  it("handles enabled changing from false to true", () => {
    const { rerender } = renderHook(({ enabled }) => useEscapeKey(handler, enabled), {
      initialProps: { enabled: false },
    });

    let event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler).not.toHaveBeenCalled();

    rerender({ enabled: true });

    event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(1);
  });

  it("handles enabled changing from true to false", () => {
    const { rerender } = renderHook(({ enabled }) => useEscapeKey(handler, enabled), {
      initialProps: { enabled: true },
    });

    let event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(1);

    rerender({ enabled: false });

    event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(1);
  });

  it("does not remove event listener on unmount if never added", () => {
    const removeEventListenerSpy = vi.spyOn(window, "removeEventListener");

    const { unmount } = renderHook(() => useEscapeKey(handler, false));

    unmount();

    expect(removeEventListenerSpy).not.toHaveBeenCalled();
    removeEventListenerSpy.mockRestore();
  });

  it("handles both Escape and Esc in the same session", () => {
    renderHook(() => useEscapeKey(handler));

    // Press Escape
    let event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    // Press Esc
    event = new KeyboardEvent("keydown", { key: "Esc" });
    window.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(2);
  });

  it("preserves event properties when calling handler", () => {
    renderHook(() => useEscapeKey(handler));

    const event = new KeyboardEvent("keydown", {
      key: "Escape",
      bubbles: true,
      cancelable: true,
      ctrlKey: true,
      shiftKey: false,
      altKey: false,
      metaKey: false,
    });
    window.dispatchEvent(event);

    expect(handler).toHaveBeenCalledTimes(1);
    const calledEvent = handler.mock.calls[0]?.[0];
    expect(calledEvent?.key).toBe("Escape");
    expect(calledEvent?.ctrlKey).toBe(true);
    expect(calledEvent?.shiftKey).toBe(false);
  });

  it("works with multiple instances of the hook", () => {
    const handler1 = vi.fn();
    const handler2 = vi.fn();

    renderHook(() => useEscapeKey(handler1));
    renderHook(() => useEscapeKey(handler2));

    const event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler1).toHaveBeenCalledTimes(1);
    expect(handler2).toHaveBeenCalledTimes(1);
  });

  it("only the enabled instance responds when one is disabled", () => {
    const handler1 = vi.fn();
    const handler2 = vi.fn();

    renderHook(() => useEscapeKey(handler1, true));
    renderHook(() => useEscapeKey(handler2, false));

    const event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler1).toHaveBeenCalledTimes(1);
    expect(handler2).not.toHaveBeenCalled();
  });

  it("cleans up properly when multiple instances unmount", () => {
    const handler1 = vi.fn();
    const handler2 = vi.fn();

    const { unmount: unmount1 } = renderHook(() => useEscapeKey(handler1));
    const { unmount: unmount2 } = renderHook(() => useEscapeKey(handler2));

    let event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler1).toHaveBeenCalledTimes(1);
    expect(handler2).toHaveBeenCalledTimes(1);

    unmount1();

    event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler1).toHaveBeenCalledTimes(1);
    expect(handler2).toHaveBeenCalledTimes(2);

    unmount2();

    event = new KeyboardEvent("keydown", { key: "Escape" });
    window.dispatchEvent(event);

    expect(handler1).toHaveBeenCalledTimes(1);
    expect(handler2).toHaveBeenCalledTimes(2);
  });
});
