import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { useIsFullyVisible } from "../use-is-fully-visible";

let ioCallback: ((entries: IntersectionObserverEntry[]) => void) | undefined;

class MockIntersectionObserver {
  constructor(cb: any) {
    ioCallback = cb;
  }
  observe() {
    // no-op
  }
  disconnect() {
    // no-op
  }
}

// @ts-expect-error
global.IntersectionObserver = MockIntersectionObserver;

function TestComp() {
  const { ref, isFullyVisible } = useIsFullyVisible<HTMLDivElement>();
  return (
    <div>
      <div data-testid="target" ref={ref} />
      <span data-testid="flag">{String(isFullyVisible)}</span>
    </div>
  );
}

describe("useIsFullyVisible", () => {
  it("sets flag to true when bottom is visible and intersection >= 0.85 and latches", async () => {
    render(<TestComp />);

    expect(screen.getByTestId("flag").textContent).toBe("false");

    ioCallback?.([
      {
        boundingClientRect: { bottom: window.innerHeight },
        intersectionRatio: 0.9,
        isIntersecting: true,
      } as unknown as IntersectionObserverEntry,
    ]);

    expect(await screen.findByText("true")).toBeDefined();

    ioCallback?.([
      {
        boundingClientRect: { bottom: window.innerHeight + 200 },
        intersectionRatio: 0.0,
        isIntersecting: false,
      } as unknown as IntersectionObserverEntry,
    ]);

    expect(screen.getByTestId("flag").textContent).toBe("true");
  });
});
