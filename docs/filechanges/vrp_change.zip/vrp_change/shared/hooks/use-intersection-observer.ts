import { useEffect } from "react";

type Options = IntersectionObserverInit & { enabled?: boolean };

export function useIntersectionObserver(
  ref: { current: Element | null } | null,
  callback: IntersectionObserverCallback,
  options: Options = {}
) {
  useEffect(() => {
    if (!ref?.current) {
      return;
    }
    if (options.enabled === false) {
      return;
    }

    const observer = new IntersectionObserver(callback, options);
    observer.observe(ref.current as Element);
    return () => observer.disconnect();
  }, [ref, callback, options]);
}
