"use client";

import { useEffect, useState } from "react";

// Custom hook to calculate viewport height minus header height
export function useViewportHeight() {
  const [viewportHeight, setViewportHeight] = useState<string>("100vh");

  useEffect(() => {
    const calculateHeight = () => {
      const headerHeight = window.innerWidth >= 640 ? 80 : 64;
      const vh = window.innerHeight - headerHeight;
      setViewportHeight(`${vh}px`);
    };

    calculateHeight();
    window.addEventListener("resize", calculateHeight);
    return () => window.removeEventListener("resize", calculateHeight);
  }, []);

  return viewportHeight;
}

export function useViewportHeightVar() {
  const vh = useViewportHeight();
  return { "--vh-minus-header": vh } as React.CSSProperties;
}
