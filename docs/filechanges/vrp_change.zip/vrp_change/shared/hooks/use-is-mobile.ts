"use client";

import { useEffect, useState } from "react";

/**
 * Returns `true` if viewport width is below Tailwind's `lg` breakpoint (< 1024px), `false` otherwise or during SSR.
 *
 * @example
 * const isMobile = useIsMobile();
 * return isMobile ? <MobileView /> : <DesktopView />;
 *
 * @returns {boolean} True if viewport width is less than 1024px
 */
export function useIsMobile(): boolean {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") {
      return;
    }

    const MOBILE_BREAKPOINT = 1024;
    const checkIsMobile = (): void => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    };
    checkIsMobile();
    window.addEventListener("resize", checkIsMobile);

    return () => {
      window.removeEventListener("resize", checkIsMobile);
    };
  }, []);

  return isMobile;
}
