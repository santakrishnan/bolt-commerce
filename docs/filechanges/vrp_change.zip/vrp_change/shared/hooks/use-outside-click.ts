import { useEffect } from "react";

export function useOutsideClick(
  ref: { current: HTMLElement | null } | null,
  handler: (e: MouseEvent) => void
) {
  useEffect(() => {
    if (!ref?.current) {
      return;
    }
    const onClick = (e: MouseEvent) => {
      const el = ref.current as HTMLElement | null;
      if (!el) {
        return;
      }
      if (!el.contains(e.target as Node)) {
        handler(e);
      }
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [ref, handler]);
}
