"use client";

import { idbDel, idbGet, idbSet } from "@shared/lib/indexeddb";
import { QueryClient } from "@tanstack/react-query";
import {
  type PersistedClient,
  type Persister,
  PersistQueryClientProvider,
} from "@tanstack/react-query-persist-client";
import { useState } from "react";

/** IndexedDB key for the persisted TanStack Query cache. */
const PERSIST_KEY = "tanstack-query-cache";

/** Cache buster — bump this when the persisted data shape changes. */
const PERSIST_BUSTER = "v2";

/** Only persist queries whose keys start with one of these prefixes. */
const PERSISTED_PREFIXES = ["saved-vehicles", "search-history"];

/** IndexedDB-backed persister for TanStack Query's `Persister` interface. */
const idbPersister: Persister = {
  persistClient: async (client: PersistedClient) => {
    try {
      await idbSet(PERSIST_KEY, client);
    } catch {
      // best-effort — IndexedDB may be unavailable in incognito
    }
  },
  restoreClient: async (): Promise<PersistedClient | undefined> => {
    try {
      const stored = await idbGet<PersistedClient>(PERSIST_KEY);
      return stored ?? undefined;
    } catch {
      return undefined;
    }
  },
  removeClient: async () => {
    try {
      await idbDel(PERSIST_KEY);
    } catch {
      // best-effort
    }
  },
};

/**
 * App-wide TanStack Query provider with IndexedDB cache persistence.
 * Restores the IDB cache before children render, then refetches stale entries in the background.
 * Only `saved-vehicles` and `search-history` queries are persisted; all others are transient.
 */
export function QueryProvider({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            // Keep server data fresh for 30 s before refetching in background
            staleTime: 30 * 1000,
            // Keep unused query data for 24 h so persisted cache survives GC
            gcTime: 24 * 60 * 60 * 1000,
            // Retry once on failure then surface the error
            retry: 1,
          },
        },
      })
  );

  return (
    <PersistQueryClientProvider
      client={queryClient}
      persistOptions={{
        persister: idbPersister,
        buster: PERSIST_BUSTER,
        dehydrateOptions: {
          shouldDehydrateQuery: (query) => {
            // Only persist successful queries whose key starts with a known prefix
            if (query.state.status !== "success") {
              return false;
            }
            const firstKey = query.queryKey[0];
            return typeof firstKey === "string" && PERSISTED_PREFIXES.includes(firstKey);
          },
        },
      }}
    >
      {children}
    </PersistQueryClientProvider>
  );
}
