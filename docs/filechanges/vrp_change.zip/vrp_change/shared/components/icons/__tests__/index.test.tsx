import { render } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import * as Icons from "../index";

describe("icons/index.ts exports", () => {
  it("re-exports footer icons and social icons as functions", () => {
    expect(typeof Icons.EmailIcon).toBe("function");
    expect(typeof Icons.PhoneIcon).toBe("function");
    expect(typeof Icons.LocationIcon).toBe("function");

    expect(typeof Icons.FacebookIcon).toBe("function");
    expect(typeof Icons.InstagramIcon).toBe("function");
    expect(typeof Icons.TwitterIcon).toBe("function");
    expect(typeof Icons.YouTubeIcon).toBe("function");
  });

  it("renders exported footer icons as SVG elements", () => {
    const { container: e } = render(<Icons.EmailIcon />);
    expect(e.querySelector("svg")).not.toBeNull();

    const { container: p } = render(<Icons.PhoneIcon />);
    expect(p.querySelector("svg")).not.toBeNull();

    const { container: l } = render(<Icons.LocationIcon />);
    expect(l.querySelector("svg")).not.toBeNull();
  });

  it("renders exported social icons as SVG elements", () => {
    const { container: f } = render(<Icons.FacebookIcon />);
    expect(f.querySelector("svg")).not.toBeNull();

    const { container: i } = render(<Icons.InstagramIcon />);
    expect(i.querySelector("svg")).not.toBeNull();

    const { container: t } = render(<Icons.TwitterIcon />);
    expect(t.querySelector("svg")).not.toBeNull();

    const { container: y } = render(<Icons.YouTubeIcon />);
    expect(y.querySelector("svg")).not.toBeNull();
  });
});
