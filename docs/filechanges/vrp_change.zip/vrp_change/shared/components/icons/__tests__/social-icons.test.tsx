import { render } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { FacebookIcon, InstagramIcon, TwitterIcon, YouTubeIcon } from "../social-icons";

describe("social-icons", () => {
  it("FacebookIcon renders svg with default size and supports custom size", () => {
    const { container: c1 } = render(<FacebookIcon />);
    const svg1 = c1.querySelector("svg");
    expect(svg1).not.toBeNull();
    expect(svg1?.getAttribute("width")).toBe("24");
    expect(svg1?.getAttribute("height")).toBe("24");
    expect(svg1?.getAttribute("fill")).toBe("currentColor");

    const { container: c2 } = render(<FacebookIcon size={48} />);
    const svg2 = c2.querySelector("svg");
    expect(svg2?.getAttribute("width")).toBe("48");
    expect(svg2?.getAttribute("height")).toBe("48");
    expect(c2.querySelector("path")).not.toBeNull();
  });

  it("TwitterIcon renders and contains expected path d fragment", () => {
    const { container } = render(<TwitterIcon />);
    const svg = container.querySelector("svg");
    expect(svg).not.toBeNull();
    expect(svg?.getAttribute("fill")).toBe("currentColor");
    const path = container.querySelector("path");
    expect(path).not.toBeNull();
    const d = path?.getAttribute("d") || "";
    expect(d).toContain("M23.953");
  });

  it("InstagramIcon renders rect, path and circle and respects size prop", () => {
    const { container } = render(<InstagramIcon size={36} />);
    const svg = container.querySelector("svg");
    expect(svg).not.toBeNull();
    expect(svg?.getAttribute("width")).toBe("36");
    expect(svg?.getAttribute("height")).toBe("36");

    const rect = container.querySelector("rect");
    expect(rect).not.toBeNull();
    expect(rect?.getAttribute("width")).toBe("20");
    expect(rect?.getAttribute("height")).toBe("20");

    const circle = container.querySelector("circle");
    expect(circle).not.toBeNull();
    expect(circle?.getAttribute("cx")).toBe("17.5");
    expect(circle?.getAttribute("r")).toBe("1.5");
  });

  it("YouTubeIcon renders and contains expected path fragments", () => {
    const { container } = render(<YouTubeIcon />);
    const svg = container.querySelector("svg");
    expect(svg).not.toBeNull();
    const path = container.querySelector("path");
    expect(path).not.toBeNull();
    const d = path?.getAttribute("d") || "";
    expect(d).toContain("23.498");
    expect(d).toContain("V8.432");
  });
});
