import { render } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { EmailIcon, LocationIcon, PhoneIcon } from "../footer-icons";

describe("footer-icons", () => {
  it("EmailIcon renders svg with default size and expected children", () => {
    const { container } = render(<EmailIcon />);
    const svg = container.querySelector("svg");
    expect(svg).not.toBeNull();
    expect(svg?.getAttribute("width")).toBe("24");
    expect(svg?.getAttribute("height")).toBe("24");
    expect(svg?.getAttribute("fill")).toBe("none");
    expect(container.querySelector("rect")).not.toBeNull();
    expect(container.querySelectorAll("path").length).toBeGreaterThan(0);
  });

  it("EmailIcon accepts size prop", () => {
    const { container } = render(<EmailIcon size={32} />);
    const svg = container.querySelector("svg");
    expect(svg?.getAttribute("width")).toBe("32");
    expect(svg?.getAttribute("height")).toBe("32");
  });

  it("PhoneIcon renders path with expected d and supports custom size", () => {
    const { container } = render(<PhoneIcon size={40} />);
    const svg = container.querySelector("svg");
    expect(svg).not.toBeNull();
    expect(svg?.getAttribute("width")).toBe("40");
    const path = container.querySelector("path");
    expect(path).not.toBeNull();
    const d = path?.getAttribute("d") || "";
    expect(d).toContain("M22 16.92");
  });

  it("LocationIcon contains pin path and a circle element", () => {
    const { container } = render(<LocationIcon />);
    expect(container.querySelector("path")).not.toBeNull();
    const circle = container.querySelector("circle");
    expect(circle).not.toBeNull();
    expect(circle?.getAttribute("cx")).toBe("12");
    expect(circle?.getAttribute("cy")).toBe("10");
    expect(circle?.getAttribute("r")).toBe("3");
  });
});
