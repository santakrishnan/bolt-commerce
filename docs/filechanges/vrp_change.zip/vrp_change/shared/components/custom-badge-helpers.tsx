/** Helper functions and sub-components for CustomBadge. */

import Image from "next/image";
import * as React from "react";

import { BADGE_ICON_BASE, customBadgeClasses, defaultBadgeIcons } from "./custom-badge.constants";
import type { CustomBadgeProps, CustomBadgeType, CustomVariant } from "./custom-badge.types";

export function MaskedIcon({ src }: { src: string }) {
  return (
    <span
      aria-hidden
      className="inline-block h-[16px] w-[12px] shrink-0"
      style={{
        backgroundColor: "currentColor",
        WebkitMaskImage: `url(${src})`,
        maskImage: `url(${src})`,
        WebkitMaskRepeat: "no-repeat",
        maskRepeat: "no-repeat",
        WebkitMaskSize: "contain",
        maskSize: "contain",
        WebkitMaskPosition: "center",
        maskPosition: "center",
      }}
    />
  );
}

export function isCustomVariant(type: CustomBadgeType): type is CustomVariant {
  return type in customBadgeClasses;
}

export function resolveIcon(
  type: CustomBadgeType,
  icon: CustomBadgeProps["icon"],
  iconSrc?: string
): React.ReactNode {
  if (iconSrc) {
    return (
      <Image
        alt=""
        aria-hidden
        className="inline-block shrink-0"
        height={16}
        src={`${BADGE_ICON_BASE}${iconSrc}`}
        style={{ width: "12px", height: "16px" }}
        width={12}
      />
    );
  }

  if (icon === null) {
    return null;
  }

  if (typeof icon === "function") {
    return React.createElement(icon as React.ElementType, {
      className: "inline-block w-3 h-4 shrink-0",
    });
  }

  if (icon !== undefined) {
    return icon;
  }

  if (isCustomVariant(type)) {
    const src = defaultBadgeIcons[type];
    if (src) {
      return <MaskedIcon src={src} />;
    }
  }

  return null;
}
