import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

vi.mock("framer-motion", () => {
  const React = require("react");
  return {
    useInView: () => true,
    motion: {
      div: (props: any) => {
        const { children, className, initial, transition, viewport, whileInView, ...rest } = props;
        return React.createElement(
          "div",
          {
            "data-testid": "motion-div",
            className,
            "data-initial": initial ? JSON.stringify(initial) : undefined,
            "data-transition": transition ? JSON.stringify(transition) : undefined,
            "data-viewport": viewport ? JSON.stringify(viewport) : undefined,
            "data-whileinview": whileInView ? JSON.stringify(whileInView) : undefined,
            ...rest,
          },
          children
        );
      },
    },
  };
});

import { AnimatedSection } from "../animated-section";

describe("AnimatedSection", () => {
  it("renders children", () => {
    render(
      <AnimatedSection>
        <span>hello</span>
      </AnimatedSection>
    );

    expect(screen.getByText("hello")).toBeInTheDocument();
  });

  it("applies default transition values", () => {
    render(<AnimatedSection>child</AnimatedSection>);
    const el = screen.getByTestId("motion-div");
    const transition = JSON.parse(el.getAttribute("data-transition") || "{}");

    expect(transition.duration).toBe(1.2);
    expect(transition.delay).toBe(0);
    expect(transition.staggerChildren).toBe(0);
    expect(transition.delayChildren).toBe(0);
  });

  it("passes className and custom delay/duration", () => {
    render(
      <AnimatedSection className="foo" delay={0.5} duration={2}>
        x
      </AnimatedSection>
    );

    const el = screen.getByTestId("motion-div");
    expect(el).toHaveClass("foo");
    const transition = JSON.parse(el.getAttribute("data-transition") || "{}");
    expect(transition.duration).toBe(2);
    expect(transition.delay).toBe(0.5);
  });

  it("enables staggerChildren behavior", () => {
    render(
      <AnimatedSection duration={1.5} staggerChildren>
        x
      </AnimatedSection>
    );

    const el = screen.getByTestId("motion-div");
    const transition = JSON.parse(el.getAttribute("data-transition") || "{}");

    expect(transition.staggerChildren).toBe(0.2);
    expect(transition.delayChildren).toBe(1.5);
  });
});
