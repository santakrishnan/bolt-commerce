import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { CircularProgress } from "../circular-progress";

const DAYS_REGEX = /DAYS/i;

describe("CircularProgress", () => {
  it("renders the numeric value and default label", () => {
    render(<CircularProgress value={10} />);

    expect(screen.getByText("10")).toBeTruthy();
    expect(screen.getByText(DAYS_REGEX)).toBeTruthy();
  });

  it("computes stroke dasharray and strokeDashoffset correctly for a 50% value", () => {
    const { container } = render(<CircularProgress value={15} />);

    const circles = container.querySelectorAll("svg circle");
    // second circle is the progress arc
    const progress = circles[1] as SVGCircleElement;
    const dashArray = progress.getAttribute("stroke-dasharray") || "";
    const dashOffset = Number.parseFloat(progress.getAttribute("stroke-dashoffset") || "0");

    // replicate the math used in the component.
    const RADIUS = 18;
    const circumference = 2 * Math.PI * RADIUS;
    const clamped = Math.min(Math.max(15 / 30, 0), 1);
    const arc = clamped * circumference;
    const gap = circumference - arc;

    const [arcStr, gapStr] = dashArray.split(" ");
    expect(Number.parseFloat(arcStr ?? "0")).toBeCloseTo(arc, 3);
    expect(Number.parseFloat(gapStr ?? "0")).toBeCloseTo(gap, 3);
    expect(dashOffset).toBeCloseTo(arc, 3);
  });

  it("uses the green colour for >=90% (clamped) and handles overflow values", () => {
    const { container } = render(<CircularProgress total={30} value={100} />);
    const circles = container.querySelectorAll("svg circle");
    const progress = circles[1] as SVGCircleElement;

    // colour string expected from implementation for >= 0.9
    expect(progress.getAttribute("stroke")).toBe("var(--color-badge-success-bg, #078843)");

    // arc should be effectively the full circumference (clamped to 1)
    const RADIUS = 18;
    const circumference = 2 * Math.PI * RADIUS;
    const [arcStr, gapStr] = (progress.getAttribute("stroke-dasharray") || "").split(" ");
    expect(Number.parseFloat(arcStr ?? "0")).toBeCloseTo(circumference, 3);
    expect(Number.parseFloat(gapStr ?? "0")).toBeCloseTo(0, 3);
  });

  it("uses amber and red colours at the proper thresholds", () => {
    // amber at >= 0.5
    const { container: c1 } = render(<CircularProgress total={30} value={15} />);
    const p1 = c1.querySelectorAll("svg circle")[1] as SVGCircleElement;
    expect(p1.getAttribute("stroke")).toBe("#F59E0B");

    // red when below 0.5
    const { container: c2 } = render(<CircularProgress total={30} value={14} />);
    const p2 = c2.querySelectorAll("svg circle")[1] as SVGCircleElement;
    expect(p2.getAttribute("stroke")).toBe("var(--color-accent-primary, #EB0D1C)");
  });

  it("applies the provided size to the SVG element", () => {
    const { container } = render(<CircularProgress size={64} value={5} />);
    const svg = container.querySelector("svg") as SVGElement;
    expect(svg.getAttribute("width")).toBe("64");
    expect(svg.getAttribute("height")).toBe("64");
  });
});
