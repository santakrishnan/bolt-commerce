import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import React from "react";
import { describe, expect, test, vi } from "vitest";

// Mock the UI primitives so tests focus on our component logic, not shadcn/css.
vi.mock("@tfs-ucmp/ui", () => {
  const React = require("react");
  return {
    Chip: ({
      children,
      className,
      onClick,
      tabIndex,
      "aria-disabled": ariaDisabled,
      ...props
    }: any) =>
      React.createElement(
        "div",
        {
          "data-testid": "chip",
          className,
          onClick: onClick as any,
          tabIndex,
          "aria-disabled": ariaDisabled,
          ...props,
        },
        children
      ),
    Button: ({ children, className, onClick, ...props }: any) =>
      React.createElement(
        "button",
        { "data-testid": "button", className, onClick: onClick as any, ...props },
        children
      ),
  };
});

// Mock next/image to render a plain img for tests
vi.mock("next/image", () => ({
  default: (props: any) => {
    return <span aria-label={props.alt} data-testid="next-image" role="img" {...props} />;
  },
}));

// Mock the XIcon used inside the remove button
vi.mock("@/components/assets/icons", () => ({
  XIcon: (props: any) => React.createElement("svg", { "data-testid": "xicon", ...props }),
}));

import { CustomChips } from "../custom-chips";

// Top-level regex constants to avoid recreating regex literals repeatedly.
const REMOVE_SUNROOF_FILTER = /Remove Sunroof filter/i;
const REMOVE_ACCIDENT_FILTER = /Remove Accident filter/i;

describe("CustomChips - functionality", () => {
  test("renders label and optional prefix", () => {
    render(<CustomChips label="Sedan" prefix={<span data-testid="prefix">P</span>} />);
    expect(screen.getByText("Sedan")).toBeInTheDocument();
    expect(screen.getByTestId("prefix")).toBeInTheDocument();
  });

  test("selected prop shows the Selected image", () => {
    render(<CustomChips label="Hybrid" selected />);
    expect(screen.getByRole("img", { name: "Selected" })).toBeInTheDocument();
  });

  test("clicking interactive chip triggers onClick", async () => {
    const user = userEvent.setup();
    const handle = vi.fn();
    render(<CustomChips label="ClickMe" onClick={handle} />);
    await user.click(screen.getByTestId("chip"));
    expect(handle).toHaveBeenCalled();
  });

  test("applied with onRemove renders remove button and stops propagation to chip onClick", async () => {
    const user = userEvent.setup();
    const onRemove = vi.fn();
    const onClick = vi.fn();
    render(<CustomChips label="Sunroof" onClick={onClick} onRemove={onRemove} type="applied" />);

    const remove = screen.getByRole("button", { name: REMOVE_SUNROOF_FILTER });
    await user.click(remove);

    expect(onRemove).toHaveBeenCalled();
    expect(onClick).not.toHaveBeenCalled();
  });

  test("applied refine-search remove button uses destructive class fragment", () => {
    render(
      <CustomChips
        isRefineSearch
        label="Accident"
        onRemove={() => {
          // intentional no-op for test
        }}
        type="applied"
      />
    );
    const button = screen.getByRole("button", { name: REMOVE_ACCIDENT_FILTER });
    expect(button.className).toEqual(
      expect.stringContaining("text-[var(--color-destructive-foreground)]")
    );
  });

  test("unavailable chips are aria-disabled, not focusable and not clickable", async () => {
    const user = userEvent.setup();
    const onClick = vi.fn();
    render(<CustomChips label="Limited" onClick={onClick} type="unavailable" />);
    const chip = screen.getByTestId("chip");
    expect(chip).toHaveAttribute("aria-disabled", "true");
    expect(chip).toHaveAttribute("tabindex", "-1");
    await user.click(chip);
    expect(onClick).not.toHaveBeenCalled();
  });

  test("applied without onRemove is non-interactive (chip onClick not called)", async () => {
    const user = userEvent.setup();
    const onClick = vi.fn();
    render(<CustomChips label="A" onClick={onClick} type="applied" />);
    await user.click(screen.getByTestId("chip"));
    expect(onClick).not.toHaveBeenCalled();
  });

  test("selected state includes selected-state class fragments and applied/unavailable have their fragments", () => {
    const { rerender } = render(<CustomChips label="S1" selected />);
    const chip = screen.getByTestId("chip");
    expect(chip.className).toEqual(expect.stringContaining("actions-accent"));

    rerender(<CustomChips label="S2" type="applied" />);
    expect(screen.getByTestId("chip").className).toEqual(expect.stringContaining("states-muted"));

    rerender(<CustomChips label="S3" type="unavailable" />);
    expect(screen.getByTestId("chip").className).toEqual(
      expect.stringContaining("cursor-not-allowed")
    );
  });
});
