import { act, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ShareButton } from "../share-button";

vi.mock("next/image", () => {
  return {
    __esModule: true,
    default: ({ alt, src, ...props }: any) => (
      <span
        aria-label={alt}
        data-testid="next-image"
        role="img"
        src={typeof src === "string" ? src : src?.src}
        {...props}
      />
    ),
  };
});

const SHARE_RE = /share/i;

vi.mock("@tfs-ucmp/ui", () => {
  return {
    __esModule: true,
    Button: ({ children, ...props }: any) => <button {...props}>{children}</button>,
  };
});

describe("ShareButton", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    Object.defineProperty(navigator, "clipboard", {
      value: { writeText: vi.fn().mockResolvedValue(undefined) },
      writable: true,
    });
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("copies full vehicle URL to clipboard and shows temporary copied message", async () => {
    Object.defineProperty(window, "location", {
      value: { origin: "https://example.com" },
      writable: true,
    });

    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, "clipboard", {
      value: { writeText },
      writable: true,
    });

    const setTimeoutSpy = vi.spyOn(global, "setTimeout");

    render(<ShareButton vehicleUrl="/vehicle/123" />);

    const btn = screen.getByRole("button", { name: SHARE_RE });

    fireEvent.click(btn);

    await act(async () => {
      await Promise.resolve();
    });

    await waitFor(() => expect(writeText).toHaveBeenCalledWith("https://example.com/vehicle/123"));
    await waitFor(() => expect(screen.getByText("Copied to Clipboard!")).toBeInTheDocument());

    expect(setTimeoutSpy).toHaveBeenCalled();
    const firstCall = setTimeoutSpy.mock.calls?.[0];
    const delay = firstCall ? (firstCall[1] as number | undefined) : undefined;
    expect(delay).toBe(2000);
    setTimeoutSpy.mockRestore();
  });

  it("does not call clipboard when vehicleUrl is not provided", () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, "clipboard", {
      value: { writeText },
      writable: true,
    });

    render(<ShareButton />);

    const candidates = screen.getAllByRole("button", { name: SHARE_RE });
    const btn = candidates.find((el) => el.tagName === "BUTTON");
    expect(btn).toBeTruthy();
    fireEvent.click(btn as HTMLElement);

    expect(writeText).not.toHaveBeenCalled();
  });

  it("calls provided onClick and respects stopPropagation (default true)", () => {
    const onClick = vi.fn();

    const stopSpy = vi.spyOn(Event.prototype, "stopPropagation");

    render(<ShareButton onClick={onClick} vehicleUrl="/v/1" />);

    const candidates = screen.getAllByRole("button", { name: SHARE_RE });
    const btn = candidates.find((el) => el.tagName === "BUTTON");
    expect(btn).toBeTruthy();
    fireEvent.click(btn as HTMLElement);

    expect(onClick).toHaveBeenCalled();
    expect(stopSpy).toHaveBeenCalled();

    stopSpy.mockRestore();
  });

  it("allows event propagation when stopPropagation is false", () => {
    const stopSpy = vi.spyOn(Event.prototype, "stopPropagation");

    render(<ShareButton stopPropagation={false} vehicleUrl="/v/1" />);

    const candidates = screen.getAllByRole("button", { name: SHARE_RE });
    const btn = candidates.find((el) => el.tagName === "BUTTON");
    expect(btn).toBeTruthy();
    fireEvent.click(btn as HTMLElement);

    expect(stopSpy).not.toHaveBeenCalled();

    stopSpy.mockRestore();
  });

  it("renders provided alt and src for the image and uses defaults when not provided", () => {
    render(<ShareButton alt="Custom" src="/foo.png" />);
    expect(screen.getByRole("img", { name: "Custom" })).toHaveAttribute("src", "/foo.png");

    render(<ShareButton />);
    expect(screen.getByRole("img", { name: "Share" })).toHaveAttribute(
      "src",
      "/images/garage/share.svg"
    );
  });
});
