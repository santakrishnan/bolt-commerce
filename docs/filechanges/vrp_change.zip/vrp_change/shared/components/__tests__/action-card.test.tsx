import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { ActionCard } from "../action-card";

vi.mock("@shared/components/button", () => {
  const React = require("react");
  return {
    AppButton: ({ children, onClick, size, variant, className }: any) =>
      React.createElement(
        "button",
        {
          "data-testid": "app-button",
          onClick,
          "data-size": size,
          "data-variant": variant,
          className,
        },
        children
      ),
  };
});

vi.mock("@tfs-ucmp/ui", () => {
  const React = require("react");
  return {
    Card: ({ children, className }: any) =>
      React.createElement("div", { "data-testid": "card", "data-class": className }, children),
    CardHeader: ({ children, className }: any) =>
      React.createElement(
        "div",
        { "data-testid": "card-header", "data-class": className },
        children
      ),
    CardDescription: ({ children, className }: any) =>
      React.createElement(
        "div",
        { "data-testid": "card-description", "data-class": className },
        children
      ),
    CardFooter: ({ children, className }: any) =>
      React.createElement(
        "div",
        { "data-testid": "card-footer", "data-class": className },
        children
      ),
    CardTitle: ({ children, className }: any) =>
      React.createElement(
        "div",
        { "data-testid": "card-title", "data-class": className },
        children
      ),
    cn: (...args: any[]) => args.filter(Boolean).join(" "),
  };
});

describe("ActionCard", () => {
  it("renders content and handles click with defaults", () => {
    const handle = vi.fn();

    render(
      <ActionCard
        buttonText="Click"
        description="Desc"
        descriptionTrailing={<span data-testid="trailing">TR</span>}
        icon={<span data-testid="icon">ICON</span>}
        onButtonClick={handle}
        title="Hello"
      />
    );

    expect(screen.getByTestId("icon")).toHaveTextContent("ICON");
    expect(screen.getByTestId("card-title")).toHaveTextContent("Hello");
    expect(screen.getByTestId("card-description")).toHaveTextContent("Desc");
    expect(screen.getByTestId("trailing")).toHaveTextContent("TR");

    const btn = screen.getByTestId("app-button");
    expect(btn).toHaveTextContent("Click");
    expect(btn).toHaveAttribute("data-size", "md");
    expect(btn).toHaveAttribute("data-variant", "primary");

    fireEvent.click(btn);
    expect(handle).toHaveBeenCalledTimes(1);
  });

  it("forwards button props and className", () => {
    render(
      <ActionCard
        buttonClassName="my-class"
        buttonSize="lg"
        buttonText="Btn"
        buttonVariant={"ghost" as any}
        className="card-class"
        description="D"
        icon={<span>i</span>}
        title="T"
      />
    );

    const btn = screen.getByTestId("app-button");
    expect(btn).toHaveAttribute("data-size", "lg");
    expect(btn).toHaveAttribute("data-variant", "ghost");
    expect(btn.className).toContain("my-class");

    const card = screen.getByTestId("card");
    expect(card.getAttribute("data-class")).toContain("card-class");
  });

  it("works without onButtonClick", () => {
    const { getByTestId } = render(
      <ActionCard buttonText="Btn" description="D" icon={<span>i</span>} title="T" />
    );

    const btn = getByTestId("app-button");
    // should not throw when clicked without handler
    fireEvent.click(btn);
  });
});
//End of file
