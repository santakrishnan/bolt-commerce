import { describe, expect, it } from "vitest";
import { colorMap } from "../color-swatch";

const expected = {
  White: "bg-white border border-gray-300",
  Black: "bg-black",
  "Midnight Gray": "bg-gray-600",
  "Metallic Green": "bg-green-600",
  "Deep Red": "bg-red-700",
  Graphite: "bg-gray-800",
  "Luminous Yellow": "bg-yellow-400",
  "Ocean Blue": "bg-blue-600",
  "Electric Blue": "bg-blue-400",
};

describe("colorMap", () => {
  it("matches the expected mapping exactly", () => {
    expect(colorMap).toEqual(expected);
  });

  it("all values are non-empty strings", () => {
    const keys = Object.keys(colorMap);
    expect(keys.length).toBe(Object.keys(expected).length);
    for (const k of keys) {
      const v = (colorMap as Record<string, unknown>)[k];
      expect(typeof v).toBe("string");
      expect((v as string).length).toBeGreaterThan(0);
    }
  });

  it("returns undefined for unknown keys", () => {
    expect((colorMap as any).NOT_A_COLOR).toBeUndefined();
  });
});
