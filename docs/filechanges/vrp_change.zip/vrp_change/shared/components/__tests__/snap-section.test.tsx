import { render } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { SnapSection } from "../snap-section";

const MIN_H_RE = /min-h/;

describe("SnapSection", () => {
  it("renders children and applies className and style when useViewportHeight is false (default)", () => {
    const { container, getByText } = render(
      <SnapSection className="extra" style={{ backgroundColor: "red" }}>
        <div>child content</div>
      </SnapSection>
    );

    expect(getByText("child content")).toBeTruthy();

    const el = container.firstChild as HTMLElement;
    expect(el).toBeTruthy();
    expect(el.className).toContain("snap-section");
    expect(el.className).toContain("extra");
    expect(el.getAttribute("style")).toContain("background-color: red");
    expect(el.className).not.toMatch(MIN_H_RE);
  });

  it("adds viewport height classes when useViewportHeight is true", () => {
    const { container, getByText } = render(
      <SnapSection useViewportHeight>
        <span>vh child</span>
      </SnapSection>
    );

    expect(getByText("vh child")).toBeTruthy();
    const el = container.firstChild as HTMLElement;
    expect(el).toBeTruthy();
    expect(el.className).toContain("snap-section");
    expect(el.className).toMatch(MIN_H_RE);
  });
});
