// Type definitions for CustomChips.

import type { Chip } from "@tfs-ucmp/ui";
import type React from "react";
import type { ComponentProps } from "react";

type ChipProps = ComponentProps<typeof Chip>;

export type CustomChipType = "selected" | "unselected" | "unavailable" | "applied";

export interface FilterChipProps extends Omit<ChipProps, "removable" | "onRemove" | "prefix"> {
  isRefineSearch?: boolean;
  label: string;
  onClick?: () => void;
  onRemove?: () => void;
  prefix?: React.ReactNode;
  selected?: boolean;
  type?: CustomChipType;
}
