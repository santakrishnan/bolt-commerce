import type { FC } from "react";

export interface CircularProgressProps {
  label?: string;
  size?: number;
  total?: number;
  value: number;
}

function getStrokeColor(value: number, total: number): string {
  const ratio = value / total;
  if (ratio >= 0.9) {
    return "var(--color-badge-success-bg, #078843)";
  }
  if (ratio >= 0.5) {
    return "#F59E0B";
  }
  return "var(--color-accent-primary, #EB0D1C)";
}

export const CircularProgress: FC<CircularProgressProps> = ({
  value,
  total = 30,
  label = "DAYS",
  size = 48,
}) => {
  const RADIUS = 18;
  const VIEW_SIZE = 40;
  const circumference = 2 * Math.PI * RADIUS;
  const clamped = Math.min(Math.max(value / total, 0), 1);
  const arc = clamped * circumference;
  const gap = circumference - arc;
  const strokeColor = getStrokeColor(value, total);

  return (
    <div
      className="relative inline-flex items-center justify-center"
      style={{ width: size, height: size }}
    >
      <svg
        aria-hidden="true"
        className="-rotate-90"
        height={size}
        viewBox={`0 0 ${VIEW_SIZE} ${VIEW_SIZE}`}
        width={size}
      >
        <circle cx="20" cy="20" fill="transparent" r={RADIUS} stroke="#ECECEC" strokeWidth="3" />

        <circle
          cx="20"
          cy="20"
          fill="transparent"
          r={RADIUS}
          stroke={strokeColor}
          strokeDasharray={`${arc} ${gap}`}
          strokeDashoffset={arc}
          strokeLinecap="round"
          strokeWidth="3"
          style={{ transition: "stroke-dashoffset 0.3s ease, stroke 0.3s ease" }}
        />
      </svg>

      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span
          className="text-center font-semibold leading-[130%]"
          style={{
            fontFamily: "var(--font-family)",
            fontSize: "var(--font-size-sm, 14px)",
            color: "var(--color-text-primary, #000)",
          }}
        >
          {value}
        </span>
        <span
          className="text-center font-semibold uppercase leading-normal"
          style={{ fontFamily: "var(--font-family)", fontSize: "8px", color: "#8A8A8A" }}
        >
          {label}
        </span>
      </div>
    </div>
  );
};
