// Style constants and icon map for CustomBadge.

export const priceBadgeBase =
  "border-transparent text-white shadow-none ring-0 whitespace-nowrap" +
  " font-[var(--font-family)] text-[length:var(--text-2xs)] font-semibold leading-[125%] tracking-[-0.1px]";

// Custom badge variant → class map
export const customBadgeClasses = {
  excellentPrice: `${priceBadgeBase} bg-[var(--color-brand-success)]`,
  lowPrice: `${priceBadgeBase} bg-[var(--color-brand-success)]`,
  preQualifies: `${priceBadgeBase} bg-[var(--color-brand-success)]`,
  goodPrice: `${priceBadgeBase} bg-[var(--color-badge-good-price)]`,
  fairPrice: `${priceBadgeBase} bg-[var(--color-badge-fair-price)]`,
  matchingPercentage: `${priceBadgeBase} bg-[var(--color-badge-matching-percentage)]`,
  ExpiresAt: `${priceBadgeBase} bg-[var(--color-badge-matching-percentage)]`,
  priceDrop: `${priceBadgeBase} bg-[var(--color-badge-price-drop-listed)]`,
  justListed: `${priceBadgeBase} bg-[var(--color-badge-price-drop-listed)]`,
  newArrival: `${priceBadgeBase} bg-[var(--color-badge-price-drop-listed)]`,
  warranty: `${priceBadgeBase} bg-inherit text-[var(--color-brand-text-secondary)]`,
  Inspected: `${priceBadgeBase} bg-inherit text-[var(--color-brand-text-secondary)]`,
  lowMiles: `${priceBadgeBase} bg-inherit text-[var(--color-brand-text-secondary)]`,
  noAccidents: `${priceBadgeBase} bg-inherit text-[var(--color-brand-text-secondary)]`,
  owner: `${priceBadgeBase} bg-inherit text-[var(--color-brand-text-secondary)]`,
} as const;

// Default icons per badge type (public/images/badges/)
export const defaultBadgeIcons: Partial<Record<keyof typeof customBadgeClasses, string>> = {
  excellentPrice: "/images/badges/excellent_price.svg",
  lowPrice: "/images/badges/low_price.svg",
  goodPrice: "/images/badges/good_price.svg",
  fairPrice: "/images/badges/fair_price.svg",
  priceDrop: "/images/badges/price_drop.svg",
  justListed: "/images/badges/just_listed.svg",
  warranty: "/images/badges/warranty.svg",
  Inspected: "/images/badges/inspected.svg",
  lowMiles: "/images/badges/low_miles.svg",
  noAccidents: "/images/badges/no_accidents.svg",
  owner: "/images/badges/one_owner.svg",
  matchingPercentage: "/images/badges/low_price.svg",
};

export const BADGE_ICON_BASE = "/images/badges/";
