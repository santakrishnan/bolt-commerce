import { describe, expect, it } from "vitest";
import * as registry from "../index";
import * as directVehicles from "../vehicles.service";

describe("saved-registry index exports", () => {
  it("re-exports vehiclesService and searchHistoryService", () => {
    expect(typeof registry.vehiclesService).toBe("object");
    expect(typeof registry.searchHistoryService).toBe("object");
  });

  it("vehiclesService export matches direct module exports", () => {
    const regKeys = Object.keys(registry.vehiclesService).sort();
    const directKeys = Object.keys(directVehicles).sort();
    expect(regKeys).toEqual(directKeys);
  });

  it("vehiclesService functions are usable via registry", async () => {
    const id = "index-test-visitor";
    await registry.vehiclesService.clearAll(id);
    await registry.vehiclesService.save(id, "IDX-VIN");
    const all = await registry.vehiclesService.getAll(id);
    expect(all).toEqual(["IDX-VIN"]);
    await registry.vehiclesService.remove(id, "IDX-VIN");
    expect(await registry.vehiclesService.getAll(id)).toEqual([]);
  });
});
