import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import * as svc from "../search-history.service";

describe("search-history.service (mock store)", () => {
  beforeEach(async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2020, 0, 1).getTime());
    await svc.clearAll("visitor-test");
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("starts empty", async () => {
    const all = await svc.getAll("visitor-test");
    expect(all).toEqual([]);
  });

  it("ignores empty or single-character queries", async () => {
    await svc.clearAll("v-short");
    const r1 = await svc.add("v-short", " ", "/url");
    expect(r1).toEqual([]);
    const r2 = await svc.add("v-short", "a", "/url");
    expect(r2).toEqual([]);
  });

  it("adds an entry and returns it with trimmed query and default type", async () => {
    const res = await svc.add("visitor-test", "  Hello World  ", "/search");
    expect(res.length).toBe(1);
    const e = res[0];
    expect(e?.query).toBe("Hello World");
    expect(e?.url).toBe("/search");
    expect(e?.type).toBe("nlp");
    expect(typeof e?.id).toBe("string");
    if (e?.timestamp) {
      expect(new Date(e.timestamp).toISOString()).toBe(e.timestamp);
    }
  });

  it("moves duplicate queries (case-insensitive) to top and updates url/timestamp", async () => {
    // create three entries: c, b, a (most recent first)
    await svc.clearAll("v-dup");
    vi.setSystemTime(new Date(2020, 0, 1, 0, 0, 0).getTime());
    await svc.add("v-dup", "a1", "/a");
    vi.setSystemTime(new Date(2020, 0, 1, 0, 0, 1).getTime());
    await svc.add("v-dup", "b1", "/b");
    vi.setSystemTime(new Date(2020, 0, 1, 0, 0, 2).getTime());
    await svc.add("v-dup", "c1", "/c");

    const before = await svc.getAll("v-dup");
    expect(before.map((x) => x.query)).toEqual(["c1", "b1", "a1"]);

    // advance time and add duplicate 'B' (different case) with new URL
    vi.setSystemTime(new Date(2020, 0, 1, 0, 0, 10).getTime());
    const updated = await svc.add("v-dup", "B1", "/b-new");
    expect(updated[0]?.query).toBe("b1");
    expect(updated[0]?.url).toBe("/b-new");
    expect(updated[0]?.timestamp).not.toBe(before[1]?.timestamp);
    // ensure ordering moved 'b1' to top
    expect(updated.map((x) => x.query)).toEqual(["b1", "c1", "a1"]);
  });

  it("prunes oldest entries when exceeding MAX_SEARCHES (10)", async () => {
    await svc.clearAll("v-prune");
    // add 11 unique queries q0..q10
    for (let i = 0; i <= 10; i++) {
      vi.setSystemTime(new Date(2020, 0, 1, 0, 0, i).getTime());
      // use different visitor to avoid interference
      await svc.add("v-prune", `q${i}`, `/q${i}`);
    }
    const all = await svc.getAll("v-prune");
    // should be pruned to 10 entries (q10..q1), q0 removed
    expect(all.length).toBe(10);
    expect(all.some((e) => e.query === "q0")).toBe(false);
    expect(all[0]?.query).toBe("q10");
    expect(all.at(-1)?.query).toBe("q1");
  });

  it("remove by id deletes the entry and returns updated list", async () => {
    await svc.clearAll("v-rem");
    const added = await svc.add("v-rem", "to-remove", "/rm");
    expect(added.length).toBe(1);
    const id = added[0]?.id as string;
    const after = await svc.remove("v-rem", id);
    expect(after).toEqual([]);
  });

  it("clearAll empties the store and returns []", async () => {
    await svc.add("v-clear", "x", "/x");
    const cleared = await svc.clearAll("v-clear");
    expect(cleared).toEqual([]);
    const now = await svc.getAll("v-clear");
    expect(now).toEqual([]);
  });

  it("stores provided type when type is 'filter'", async () => {
    await svc.clearAll("v-type");
    const res = await svc.add("v-type", "filter-me", "/f", "filter");
    expect(res[0]?.type).toBe("filter");
  });
});
