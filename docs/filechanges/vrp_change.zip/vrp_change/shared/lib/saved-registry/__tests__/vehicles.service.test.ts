import { describe, expect, it } from "vitest";
import { clearAll, getAll, remove, save } from "../vehicles.service";

describe("vehicles.service (mock in-memory)", () => {
  it("getAll returns empty array for new visitor", async () => {
    const id = "visitor-empty";
    const list = await getAll(id);
    expect(list).toEqual([]);
  });

  it("save adds a VIN and getAll reflects it", async () => {
    const id = "visitor-save";
    const vin = "VIN-123";
    const res = await save(id, vin);
    expect(res).toEqual([vin]);
    expect(await getAll(id)).toEqual([vin]);
  });

  it("save is idempotent for duplicate VINs", async () => {
    const id = "visitor-duplicate";
    const vin = "VIN-dup";
    await save(id, vin);
    const again = await save(id, vin);
    expect(again).toEqual([vin]);
    const all = await getAll(id);
    expect(all).toHaveLength(1);
  });

  it("remove deletes a saved VIN and returns updated list", async () => {
    const id = "visitor-remove";
    const a = "VIN-A";
    const b = "VIN-B";
    await save(id, a);
    await save(id, b);
    const after = await remove(id, a);
    expect(after).toEqual([b]);
    expect(await getAll(id)).toEqual([b]);
  });

  it("remove of non-existent VIN is a no-op", async () => {
    const id = "visitor-noop-remove";
    const vin = "VIN-only";
    await save(id, vin);
    const after = await remove(id, "NO-SUCH-VIN");
    expect(after).toEqual([vin]);
    expect(await getAll(id)).toEqual([vin]);
  });

  it("clearAll clears the store and returns empty array", async () => {
    const id = "visitor-clear";
    await save(id, "VIN-1");
    const cleared = await clearAll(id);
    expect(cleared).toEqual([]);
    expect(await getAll(id)).toEqual([]);
  });

  it("getAll returns a shallow copy (mutating returned array does not affect store)", async () => {
    const id = "visitor-copy";
    await save(id, "VIN-copy");
    const list = await getAll(id);
    list.push("MUTATED");
    const fresh = await getAll(id);
    expect(fresh).toEqual(["VIN-copy"]);
    expect(list).toContain("MUTATED");
  });

  it("save rejects when exceeding MAX_SAVED capacity", async () => {
    const id = "visitor-full";
    const base = "VIN-FULL-";
    for (let i = 0; i < 30; i++) {
      // eslint-disable-next-line no-await-in-loop
      const res = await save(id, `${base}${i}`);
      expect(res.length).toBeGreaterThanOrEqual(i + 1);
    }

    await expect(save(id, `${base}OVER`)).rejects.toThrow();
  });
});
