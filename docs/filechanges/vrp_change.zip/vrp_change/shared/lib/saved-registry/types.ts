/** Shared types for the Saved Registry service layer (used by both server-side service and client-side proxy calls). */

export interface SearchEntry {
  id: string;
  query: string;
  timestamp: string;
  type: "nlp" | "filter";
  url: string;
}

/**
 * Standard envelope returned by all saved-registry proxy routes.
 * `data` carries the payload; `error` is populated on failure.
 */
export interface SavedRegistryResponse<T> {
  data: T;
  error?: string;
}
