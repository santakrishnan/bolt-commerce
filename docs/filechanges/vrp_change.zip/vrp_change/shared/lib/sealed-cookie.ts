/**
 * Arrow session cookies — one httpOnly cookie per identifier, each with its own TTL.
 * Values are Base64url-encoded. The `__Host-` prefix is applied in production
 * to prevent subdomain leaks (enforces Secure=true, Path=/, no Domain).
 *
 * | Cookie name           | Value         | TTL     |
 * |-----------------------|---------------|---------|
 * | `_arrow_session_id`   | sessionId     | 90 days |
 * | `_arrow_fp_id`        | fingerprintId | 24 hrs  |
 * | `_arrow_profile_id`   | profileId     | 24 hrs  |
 * | `_arrow_fp_eid`       | eventId       | 24 hrs  |
 */

import { ARROW_COOKIE, ARROW_TTL } from "@features/tracking/constants";

export interface SessionPayload {
  /** Fingerprint event ID for server-side detail lookups */
  eventId?: string;
  /** Fingerprint visitor ID */
  fingerprintId: string;
  /** Resolved profile ID (nullable) */
  profileId: string | null;
  /** Server-generated session ID (UUID v4) */
  sessionId: string;
}

/** Encodes a string to Base64url for opaque, transport-safe cookie storage. */
export function encodeCookieValue(value: string): string {
  return Buffer.from(value, "utf-8").toString("base64url");
}

/** Decodes a Base64url cookie value. Returns `null` if decoding fails or the value is empty. */
export function decodeCookieValue(token: string): string | null {
  try {
    const value = Buffer.from(token, "base64url").toString("utf-8");
    return value || null;
  } catch {
    return null;
  }
}

export interface CookieConfig {
  httpOnly: boolean;
  /** Browser-enforced TTL in seconds */
  maxAge: number;
  /** Final cookie name (includes `__Host-` prefix in production) */
  name: string;
  path: string;
  sameSite: "lax";
  secure: boolean;
}

/**
 * Builds cookie options for a single Arrow cookie.
 * In production the `__Host-` prefix enforces Secure=true, Path=/, and no Domain attribute.
 */
function buildCookieConfig(baseName: string, ttl: number): CookieConfig {
  const isProduction = process.env.NODE_ENV === "production";
  return {
    name: isProduction ? `__Host-${baseName}` : baseName,
    maxAge: ttl,
    httpOnly: true,
    secure: isProduction,
    sameSite: "lax",
    path: "/",
  };
}

/** Returns the cookie configuration for every Arrow cookie, keyed by purpose. */
export function getCookieConfigs() {
  return {
    session: buildCookieConfig(ARROW_COOKIE.SESSION_ID, ARROW_TTL.SESSION),
    fingerprint: buildCookieConfig(ARROW_COOKIE.FP_ID, ARROW_TTL.FINGERPRINT),
    profile: buildCookieConfig(ARROW_COOKIE.PROFILE_ID, ARROW_TTL.PROFILE),
    event: buildCookieConfig(ARROW_COOKIE.FP_EID, ARROW_TTL.EVENT),
  };
}
