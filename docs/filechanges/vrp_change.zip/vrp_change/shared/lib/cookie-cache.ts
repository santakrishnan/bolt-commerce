/**
 * Client-side cookie utility with in-memory caching.
 * Cache is lazily populated on first access and invalidated on tab visibility change.
 */

/** In-memory cache for cookie values. Populated lazily, invalidated on visibility change. */
let cookieCache: Record<string, string> | null = null;

/** Parses `document.cookie` into a key-value map. Called only on cache miss. */
function parseCookies(): Record<string, string> {
  if (typeof document === "undefined") {
    return {};
  }

  try {
    const cookies: Record<string, string> = {};
    const cookieString = document.cookie;

    if (!cookieString) {
      return cookies;
    }

    for (const cookie of cookieString.split("; ")) {
      const [name, ...rest] = cookie.split("=");
      if (name) {
        cookies[name] = rest.join("=") || "";
      }
    }

    return cookies;
  } catch {
    return {};
  }
}

function clearCache(): void {
  cookieCache = null;
}

if (typeof document !== "undefined") {
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      clearCache();
    }
  });
}

export interface CookieOptions {
  expires?: Date;
  maxAge?: number;
  /** Cookie path (default: "/") */
  path?: string;
  /** SameSite attribute (default: "Lax") */
  sameSite?: "Strict" | "Lax" | "None";
  /** Use Secure flag (default: auto-detected from protocol) */
  secure?: boolean;
}

/**
 * Returns a cookie value from cache, or `null` if it doesn't exist.
 * Parses `document.cookie` on first call; subsequent calls read from memory.
 */
export function getCookie(name: string): string | null {
  if (cookieCache === null) {
    cookieCache = parseCookies();
  }

  return cookieCache[name] ?? null;
}

/**
 * Sets a cookie and updates the cache.
 * Uses the Cookie Store API when available, falls back to `document.cookie`.
 */
export function setCookie(name: string, value: string, options: CookieOptions = {}): void {
  if (typeof window === "undefined") {
    return;
  }

  const {
    maxAge,
    expires,
    path = "/",
    secure = window.location.protocol === "https:",
    sameSite = "Lax",
  } = options;

  if ("cookieStore" in window) {
    try {
      // Prefer maxAge over expires when calculating expiration timestamp
      let expiresTimestamp: number | undefined;
      if (maxAge !== undefined) {
        expiresTimestamp = Date.now() + maxAge * 1000;
      } else if (expires !== undefined) {
        expiresTimestamp = expires.getTime();
      }

      const cookieStoreOptions: {
        name: string;
        value: string;
        path: string;
        expires?: number;
        sameSite?: "strict" | "lax" | "none";
      } = {
        name,
        value,
        path,
      };

      if (expiresTimestamp !== undefined) {
        cookieStoreOptions.expires = expiresTimestamp;
      }

      if (sameSite !== undefined) {
        cookieStoreOptions.sameSite = sameSite.toLowerCase() as "strict" | "lax" | "none";
      }

      // Cookie Store API applies Secure automatically on HTTPS contexts
      (window as Window & { cookieStore: { set: (opts: object) => Promise<void> } }).cookieStore
        .set(cookieStoreOptions)
        .catch(() => {
          setViaDom(name, value, { maxAge, expires, path, secure, sameSite });
        });

      if (cookieCache === null) {
        cookieCache = parseCookies();
      }
      cookieCache[name] = value;

      return;
    } catch {
      // Fall through to document.cookie
    }
  }

  setViaDom(name, value, { maxAge, expires, path, secure, sameSite });

  if (cookieCache === null) {
    cookieCache = parseCookies();
  }
  cookieCache[name] = value;
}

/** Removes a cookie by expiring it and deletes it from the cache. */
export function removeCookie(name: string, options: Pick<CookieOptions, "path"> = {}): void {
  const { path = "/" } = options;

  if ("cookieStore" in window) {
    try {
      (
        window as Window & {
          cookieStore: { delete: (opts: { name: string; path: string }) => Promise<void> };
        }
      ).cookieStore
        .delete({ name, path })
        .catch(() => {
          setViaDom(name, "", { maxAge: -1, path });
        });

      if (cookieCache !== null) {
        delete cookieCache[name];
      }

      return;
    } catch {
      // Fall through to document.cookie
    }
  }

  setViaDom(name, "", { maxAge: -1, path });

  if (cookieCache !== null) {
    delete cookieCache[name];
  }
}

/** Returns all cookies as a shallow copy of the cache. */
export function getAllCookies(): Record<string, string> {
  if (cookieCache === null) {
    cookieCache = parseCookies();
  }

  return { ...cookieCache };
}

/** Returns `true` if the named cookie exists. */
export function hasCookie(name: string): boolean {
  return getCookie(name) !== null;
}

/** Manually invalidates the cookie cache. Useful when cookies are modified outside this module. */
export function clearCookieCache(): void {
  clearCache();
}

/** Writes a cookie via `document.cookie`. Used as fallback when Cookie Store API is unavailable. */
function setViaDom(name: string, value: string, options: CookieOptions): void {
  if (typeof document === "undefined") {
    return;
  }

  const { maxAge, expires, path = "/", secure = false, sameSite = "Lax" } = options;

  let cookieString = `${encodeURIComponent(name)}=${encodeURIComponent(value)}`;

  if (maxAge !== undefined) {
    cookieString += `; max-age=${maxAge}`;
  } else if (expires !== undefined) {
    cookieString += `; expires=${expires.toUTCString()}`;
  }

  cookieString += `; path=${path}`;

  if (secure) {
    cookieString += "; Secure";
  }

  cookieString += `; SameSite=${sameSite}`;

  // biome-ignore lint/suspicious/noDocumentCookie: Required for cookie manipulation
  document.cookie = cookieString;
}
