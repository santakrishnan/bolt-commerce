import { describe, expect, it } from "vitest";
import { capitalize, formatSlugLabel, getPriceCategory } from "../formatters";

describe("formatters", () => {
  it("capitalize: capitalizes first letter and preserves rest", () => {
    expect(capitalize("hello")).toBe("Hello");
    expect(capitalize("Hello")).toBe("Hello");
  });

  it("capitalize: returns empty string unchanged", () => {
    expect(capitalize("")).toBe("");
  });

  it("formatSlugLabel: converts slug to uppercase label", () => {
    expect(formatSlugLabel("xle-awd")).toBe("XLE AWD");
    expect(formatSlugLabel("premium")).toBe("PREMIUM");
    expect(formatSlugLabel("a-b-c-d")).toBe("A B C D");
  });

  it("getPriceCategory: returns High for >75", () => {
    const res = getPriceCategory(90);
    expect(res.category).toBe("High");
    expect(res.color).toBe("bg-orange-500");
  });

  it("getPriceCategory: returns Fair for >50", () => {
    const res = getPriceCategory(60);
    expect(res.category).toBe("Fair");
    expect(res.color).toBe("bg-gray-700");
  });

  it("getPriceCategory: returns Good for >25", () => {
    const res = getPriceCategory(30);
    expect(res.category).toBe("Good");
    expect(res.color).toBe("bg-success");
  });

  it("getPriceCategory: returns Excellent for <=25", () => {
    expect(getPriceCategory(25).category).toBe("Excellent");
    expect(getPriceCategory(0).category).toBe("Excellent");
    expect(getPriceCategory(-5).category).toBe("Excellent");
    expect(getPriceCategory(25).color).toBe("bg-success");
  });
});
