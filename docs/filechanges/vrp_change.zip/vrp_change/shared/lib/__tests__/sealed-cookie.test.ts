import { afterEach, describe, expect, it, vi } from "vitest";
import { ARROW_COOKIE, ARROW_TTL } from "../../../features/tracking/constants";
import { decodeCookieValue, encodeCookieValue, getCookieConfigs } from "../sealed-cookie";

describe("encodeCookieValue", () => {
  it("encodes a plain string to Base64url", () => {
    const encoded = encodeCookieValue("hello");
    expect(encoded).toBe(Buffer.from("hello", "utf-8").toString("base64url"));
  });

  it("encodes a UUID-like string", () => {
    const uuid = "123e4567-e89b-12d3-a456-426614174000";
    expect(encodeCookieValue(uuid)).toBe(Buffer.from(uuid, "utf-8").toString("base64url"));
  });

  it("encodes an empty string to Base64url empty", () => {
    expect(encodeCookieValue("")).toBe("");
  });

  it("round-trips with decodeCookieValue", () => {
    const original = "session-data-xyz";
    expect(decodeCookieValue(encodeCookieValue(original))).toBe(original);
  });
});

describe("decodeCookieValue", () => {
  it("decodes a valid Base64url token", () => {
    const token = Buffer.from("my-value", "utf-8").toString("base64url");
    expect(decodeCookieValue(token)).toBe("my-value");
  });

  it("returns null for an empty string", () => {
    expect(decodeCookieValue("")).toBeNull();
  });

  it("returns null when Buffer.from throws", () => {
    const fromSpy = vi.spyOn(Buffer, "from").mockImplementationOnce(() => {
      throw new Error("decode error");
    });
    expect(decodeCookieValue("anything")).toBeNull();
    fromSpy.mockRestore();
  });
});

describe("getCookieConfigs — development", () => {
  it("returns configs with plain names (no __Host- prefix)", () => {
    // NODE_ENV defaults to 'test' in vitest, treated as non-production
    const configs = getCookieConfigs();

    expect(configs.session.name).toBe(ARROW_COOKIE.SESSION_ID);
    expect(configs.fingerprint.name).toBe(ARROW_COOKIE.FP_ID);
    expect(configs.profile.name).toBe(ARROW_COOKIE.PROFILE_ID);
    expect(configs.event.name).toBe(ARROW_COOKIE.FP_EID);
  });

  it("returns correct TTLs for each cookie", () => {
    const configs = getCookieConfigs();

    expect(configs.session.maxAge).toBe(ARROW_TTL.SESSION);
    expect(configs.fingerprint.maxAge).toBe(ARROW_TTL.FINGERPRINT);
    expect(configs.profile.maxAge).toBe(ARROW_TTL.PROFILE);
    expect(configs.event.maxAge).toBe(ARROW_TTL.EVENT);
  });

  it("sets httpOnly, sameSite=lax, path=/ for all configs", () => {
    const configs = getCookieConfigs();
    for (const config of Object.values(configs)) {
      expect(config.httpOnly).toBe(true);
      expect(config.sameSite).toBe("lax");
      expect(config.path).toBe("/");
    }
  });

  it("sets secure=false in non-production", () => {
    const configs = getCookieConfigs();
    for (const config of Object.values(configs)) {
      expect(config.secure).toBe(false);
    }
  });
});

describe("getCookieConfigs — production", () => {
  afterEach(() => {
    vi.unstubAllEnvs();
  });

  it("prefixes cookie names with __Host- in production", () => {
    vi.stubEnv("NODE_ENV", "production");
    const configs = getCookieConfigs();

    expect(configs.session.name).toBe(`__Host-${ARROW_COOKIE.SESSION_ID}`);
    expect(configs.fingerprint.name).toBe(`__Host-${ARROW_COOKIE.FP_ID}`);
    expect(configs.profile.name).toBe(`__Host-${ARROW_COOKIE.PROFILE_ID}`);
    expect(configs.event.name).toBe(`__Host-${ARROW_COOKIE.FP_EID}`);
  });

  it("sets secure=true in production", () => {
    vi.stubEnv("NODE_ENV", "production");
    const configs = getCookieConfigs();

    for (const config of Object.values(configs)) {
      expect(config.secure).toBe(true);
    }
  });
});
