import { beforeEach, describe, expect, it, vi } from "vitest";

beforeEach(() => {
  vi.resetModules();
  document.body.style.overflow = "";
  document.body.style.paddingRight = "";
});

describe("body-scroll-lock", () => {
  it("locks and unlocks body scroll and compensates for scrollbar width", async () => {
    // fresh import to reset module-level state
    const mod = await import("../body-scroll-lock");
    const { lockBodyScroll, unlockBodyScroll } = mod;

    // Simulate a scrollbar width of 20px
    Object.defineProperty(document.documentElement, "clientWidth", {
      value: 1000,
      configurable: true,
    });
    window.innerWidth = 1020;

    document.body.style.overflow = "auto";
    document.body.style.paddingRight = "5px";

    lockBodyScroll();
    expect(document.body.style.overflow).toBe("hidden");
    expect(document.body.style.paddingRight).toBe("25px");

    // second lock: count increments, styles unchanged
    lockBodyScroll();
    expect(document.body.style.overflow).toBe("hidden");
    expect(document.body.style.paddingRight).toBe("25px");

    // first unlock: count drops to 1, still locked
    unlockBodyScroll();
    expect(document.body.style.overflow).toBe("hidden");
    expect(document.body.style.paddingRight).toBe("25px");

    // final unlock: styles restored to original values
    unlockBodyScroll();
    expect(document.body.style.overflow).toBe("auto");
    expect(document.body.style.paddingRight).toBe("5px");
  });

  it("does not adjust padding when scrollbar width is zero", async () => {
    const mod = await import("../body-scroll-lock");
    const { lockBodyScroll, unlockBodyScroll } = mod;

    // Simulate no scrollbar (innerWidth == clientWidth)
    Object.defineProperty(document.documentElement, "clientWidth", {
      value: 1000,
      configurable: true,
    });
    window.innerWidth = 1000;

    document.body.style.overflow = "visible";
    document.body.style.paddingRight = "3px";

    lockBodyScroll();
    expect(document.body.style.overflow).toBe("hidden");
    expect(document.body.style.paddingRight).toBe("3px");

    unlockBodyScroll();
    expect(document.body.style.overflow).toBe("visible");
    expect(document.body.style.paddingRight).toBe("3px");
  });

  it("unlock when no locks is a no-op", async () => {
    const mod = await import("../body-scroll-lock");
    const { unlockBodyScroll } = mod;

    document.body.style.overflow = "orig";
    document.body.style.paddingRight = "7px";

    unlockBodyScroll();
    expect(document.body.style.overflow).toBe("orig");
    expect(document.body.style.paddingRight).toBe("7px");
  });

  it("is a no-op when window is undefined", async () => {
    const mod = await import("../body-scroll-lock");
    const { lockBodyScroll, unlockBodyScroll } = mod;

    const savedWindow = (global as any).window;
    try {
      (global as any).window = undefined;

      document.body.style.overflow = "keep";
      document.body.style.paddingRight = "9px";

      expect(() => lockBodyScroll()).not.toThrow();
      expect(document.body.style.overflow).toBe("keep");
      expect(document.body.style.paddingRight).toBe("9px");

      expect(() => unlockBodyScroll()).not.toThrow();
      expect(document.body.style.overflow).toBe("keep");
      expect(document.body.style.paddingRight).toBe("9px");
    } finally {
      (global as any).window = savedWindow;
    }
  });

  it("handles non-numeric computed paddingRight gracefully", async () => {
    const mod = await import("../body-scroll-lock");
    const { lockBodyScroll, unlockBodyScroll } = mod;

    Object.defineProperty(document.documentElement, "clientWidth", {
      value: 1000,
      configurable: true,
    });
    window.innerWidth = 1020;

    document.body.style.paddingRight = "";
    // Mock getComputedStyle to return a non-numeric paddingRight (treated as 0)
    const originalGetComputedStyle = window.getComputedStyle;
    window.getComputedStyle = () => ({ paddingRight: "invalid" }) as CSSStyleDeclaration;

    try {
      lockBodyScroll();
      expect(document.body.style.paddingRight).toBe("20px");
    } finally {
      window.getComputedStyle = originalGetComputedStyle;
      unlockBodyScroll();
    }
  });
});
