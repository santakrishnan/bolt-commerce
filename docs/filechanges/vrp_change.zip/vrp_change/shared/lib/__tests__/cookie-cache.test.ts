import { beforeEach, describe, expect, it, vi } from "vitest";
import * as cookieCache from "../cookie-cache";

/**
 * Controls `document.cookie` in tests by installing a getter/setter pair.
 * `cookieGetterValue` simulates what the browser reports; `lastCookieSet` captures writes.
 */
let cookieGetterValue = "";
let lastCookieSet = "";
function installCookieMock(initial = "") {
  cookieGetterValue = initial;
  lastCookieSet = "";
  Object.defineProperty(document, "cookie", {
    configurable: true,
    get() {
      return cookieGetterValue;
    },
    set(v: string) {
      lastCookieSet = v;
    },
  });
}

describe("cookie-cache utilities", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    try {
      Object.defineProperty((global as any).window, "cookieStore", {
        configurable: true,
        value: undefined,
      });
    } catch {
      // ignore: some environments expose readonly window properties
    }
    installCookieMock("");
    cookieCache.clearCookieCache();
  });

  it("parses cookies and returns values via getCookie/getAllCookies/hasCookie", () => {
    installCookieMock("a=1; b=two=2; empty=; encoded=%20");

    expect(cookieCache.getCookie("a")).toBe("1");
    expect(cookieCache.getCookie("b")).toBe("two=2");
    expect(cookieCache.getCookie("empty")).toBe("");
    expect(cookieCache.getCookie("missing")).toBeNull();

    const all = cookieCache.getAllCookies();
    expect(all).toMatchObject({ a: "1", b: "two=2", empty: "", encoded: "%20" });
    expect(cookieCache.hasCookie("a")).toBe(true);
    expect(cookieCache.hasCookie("missing")).toBe(false);
  });

  it("uses cookieStore.set when available and updates cache", () => {
    const mockSet = vi.fn().mockResolvedValue(undefined);
    try {
      Object.defineProperty(window, "cookieStore", { configurable: true, value: { set: mockSet } });
    } catch {
      // ignore: fallback if defineProperty isn't allowed in this environment
    }

    cookieCache.setCookie("x", "y", { maxAge: 5, path: "/p", sameSite: "Strict" });

    expect(mockSet).toHaveBeenCalled();
    const arg = (mockSet as any).mock.calls[0][0];
    expect(arg.name).toBe("x");
    expect(arg.value).toBe("y");
    expect(arg.path).toBe("/p");
    expect(arg.sameSite).toBe("strict");

    expect(cookieCache.getCookie("x")).toBe("y");
  });

  it("falls back to document.cookie when cookieStore.set rejects and encodes attributes", async () => {
    const mockSet = vi.fn().mockRejectedValue(new Error("nope"));
    try {
      Object.defineProperty(window, "cookieStore", { configurable: true, value: { set: mockSet } });
    } catch {
      // ignore: fallback if defineProperty isn't allowed in this environment
    }

    installCookieMock("");

    const expires = new Date(Date.UTC(2030, 0, 1, 0, 0, 0));
    cookieCache.setCookie("z name", "v;val", {
      expires,
      path: "/q",
      sameSite: "None",
      secure: true,
    });

    expect(mockSet).toHaveBeenCalled();

    // Wait a tick for the cookieStore rejection handler to run
    await new Promise((r) => setTimeout(r, 0));

    expect(lastCookieSet).toContain(`${encodeURIComponent("z name")}=`);
    expect(lastCookieSet).toContain("path=/q");
    expect(lastCookieSet).toContain("SameSite=None");

    expect(cookieCache.getCookie("z name")).toBe("v;val");
  });

  it("removes cookie via cookieStore.delete and updates cache", () => {
    const mockDelete = vi.fn().mockResolvedValue(undefined);
    try {
      Object.defineProperty(window, "cookieStore", {
        configurable: true,
        value: { delete: mockDelete },
      });
    } catch {
      // ignore: fallback if defineProperty isn't allowed in this environment
    }

    // Prime the cache
    cookieCache.setCookie("todelete", "1");
    expect(cookieCache.getCookie("todelete")).toBe("1");

    cookieCache.removeCookie("todelete", { path: "/" });
    expect(mockDelete).toHaveBeenCalledWith({ name: "todelete", path: "/" });
    expect(cookieCache.getCookie("todelete")).toBeNull();
  });

  it("falls back to document.cookie when delete rejects and expires cookie", async () => {
    const mockDelete = vi.fn().mockRejectedValue(new Error("nope"));
    try {
      Object.defineProperty(window, "cookieStore", {
        configurable: true,
        value: { delete: mockDelete },
      });
    } catch {
      // ignore: fallback if defineProperty isn't allowed in this environment
    }

    // Prime the cache
    cookieCache.setCookie("old", "v");
    expect(cookieCache.getCookie("old")).toBe("v");

    cookieCache.removeCookie("old", { path: "/p" });

    // Wait a tick for the cookieStore rejection handler to run
    await new Promise((r) => setTimeout(r, 0));

    expect(lastCookieSet).toContain("max-age=-1");
    expect(lastCookieSet).toContain("path=/p");
    expect(cookieCache.getCookie("old")).toBeNull();
  });

  it("clearCookieCache invalidates cache", () => {
    installCookieMock("A=1");
    expect(cookieCache.getCookie("A")).toBe("1");

    installCookieMock("A=2");

    // Cache still holds the old value until explicitly invalidated
    expect(cookieCache.getCookie("A")).toBe("1");

    cookieCache.clearCookieCache();
    expect(cookieCache.getCookie("A")).toBe("2");
  });

  it("visibilitychange invalidates cache when page becomes visible", () => {
    installCookieMock("B=1");
    expect(cookieCache.getCookie("B")).toBe("1");

    // Update underlying cookie value then trigger a visibility change
    installCookieMock("B=9");
    Object.defineProperty(document, "visibilityState", {
      configurable: true,
      get: () => "visible",
    });
    document.dispatchEvent(new Event("visibilitychange"));

    expect(cookieCache.getCookie("B")).toBe("9");
  });

  it("setCookie falls back to document.cookie when cookieStore is absent", () => {
    try {
      Object.defineProperty(window, "cookieStore", { configurable: true, value: undefined });
    } catch {
      // ignore: fallback if defineProperty isn't allowed in this environment
    }
    installCookieMock("");

    cookieCache.setCookie("noapi", "val", {
      maxAge: 10,
      path: "/x",
      secure: true,
      sameSite: "Lax",
    });

    expect(lastCookieSet).toContain("max-age=10");
    expect(lastCookieSet).toContain("path=/x");
    expect(cookieCache.getCookie("noapi")).toBe("val");
  });

  it("removeCookie falls back to document.cookie when cookieStore is absent", () => {
    try {
      Object.defineProperty(window, "cookieStore", { configurable: true, value: undefined });
    } catch {
      // ignore: fallback if defineProperty isn't allowed in this environment
    }

    // prime cache
    installCookieMock("");
    cookieCache.setCookie("noapi-delete", "v");
    expect(cookieCache.getCookie("noapi-delete")).toBe("v");

    cookieCache.removeCookie("noapi-delete", { path: "/del" });
    expect(lastCookieSet).toContain("max-age=-1");
    expect(lastCookieSet).toContain("path=/del");
    expect(cookieCache.getCookie("noapi-delete")).toBeNull();
  });

  it("parseCookies handles errors gracefully", () => {
    // Make document.cookie getter throw to exercise the try/catch in parseCookies
    Object.defineProperty(document, "cookie", {
      configurable: true,
      get() {
        throw new Error("boom");
      },
    });

    cookieCache.clearCookieCache();
    expect(cookieCache.getCookie("anything")).toBeNull();
  });

  it("setCookie returns early when window is undefined", () => {
    const orig = global.window;
    global.window = undefined as any;

    expect(() => cookieCache.setCookie("a", "b")).not.toThrow();

    global.window = orig;
  });

  it("setCookie catches synchronous cookieStore access errors and falls back", () => {
    // cookieStore getter throws synchronously to exercise the outer try/catch in setCookie
    Object.defineProperty(window, "cookieStore", {
      configurable: true,
      get() {
        throw new Error("access error");
      },
    });

    installCookieMock("");
    cookieCache.setCookie("syncthrow", "v", { path: "/throw" });

    expect(lastCookieSet).toContain("path=/throw");
    expect(cookieCache.getCookie("syncthrow")).toBe("v");
  });

  it("removeCookie catches synchronous cookieStore access errors and falls back", () => {
    Object.defineProperty(window, "cookieStore", {
      configurable: true,
      get() {
        throw new Error("access error");
      },
    });

    installCookieMock("");
    cookieCache.setCookie("syncdel", "v");
    cookieCache.removeCookie("syncdel", { path: "/pd" });

    expect(lastCookieSet).toContain("path=/pd");
    expect(cookieCache.getCookie("syncdel")).toBeNull();
  });

  it("parseCookies returns empty when document is undefined", () => {
    const origDoc = global.document;
    global.document = undefined as any;

    cookieCache.clearCookieCache();
    expect(cookieCache.getCookie("no-doc")).toBeNull();

    global.document = origDoc;
  });

  it("getAllCookies populates cache when empty", () => {
    cookieCache.clearCookieCache();
    installCookieMock("k=1");
    const all = cookieCache.getAllCookies();
    expect(all.k).toBe("1");
  });

  it("setCookie fallback with missing document returns early from setViaDom but still updates cache", () => {
    try {
      Object.defineProperty(window, "cookieStore", { configurable: true, value: undefined });
    } catch {
      // ignore: fallback if defineProperty isn't allowed in this environment
    }

    // Remove document so setViaDom returns early without writing to document.cookie
    const origDoc2 = global.document;
    global.document = undefined as any;

    lastCookieSet = "";
    cookieCache.clearCookieCache();

    cookieCache.setCookie("nodoc", "val", { maxAge: 5, path: "/x" });

    expect(lastCookieSet).toBe("");
    expect(cookieCache.getCookie("nodoc")).toBe("val");

    global.document = origDoc2;
  });
});
