import { AppButton } from "@shared/components/button";
import { Card, CardContent, CardHeader } from "@tfs-ucmp/ui";
import type React from "react";

export interface GarageInfoCardProps {
  badge?: React.ReactNode;
  children: React.ReactNode;
  ctaLabel: string;
  ctaVariant?: "primary" | "secondary" | "tertiary";
  heading: React.ReactNode;
  onCtaClick?: () => void;
}

export const GarageInfoCard: React.FC<GarageInfoCardProps> = ({
  heading,
  badge,
  children,
  ctaLabel,
  onCtaClick,
  ctaVariant = "primary",
}) => {
  return (
    <Card className="border-0 shadow">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 px-[var(--spacing-lg,24px)] pt-[var(--spacing-md,16px)] pb-[var(--spacing-md,16px)]">
        <div className="flex items-center gap-[var(--spacing-sm,8px)] font-semibold text-[color:var(--color-text-primary,#111)] text-[length:var(--text-body-lg,18px)] leading-[130%] [leading-trim:both] [text-edge:cap]">
          {heading}
        </div>
        {badge}
      </CardHeader>
      <div
        className="mx-[var(--spacing-lg,24px)] h-[1px] bg-black opacity-10"
        style={{ background: "#000" }}
      />
      <CardContent className="flex flex-col gap-[var(--spacing-md,16px)] px-[var(--spacing-lg,24px)] pt-[var(--spacing-md,16px)] pb-[var(--spacing-md,16px)] font-normal text-[color:var(--color-text-secondary,#58595B)] text-[length:var(--font-size-sm,14px)] leading-normal [font-family:var(--font-family,'Toyota_Type')] [leading-trim:both] [text-edge:cap]">
        {children}
        <AppButton onClick={onCtaClick} size="md" variant={ctaVariant}>
          {ctaLabel}
        </AppButton>
      </CardContent>
    </Card>
  );
};
