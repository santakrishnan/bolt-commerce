import { FavoriteButton } from "@features/favorites";
import { CustomBadge } from "@shared/components/custom-badge";
import { ShareButton } from "@shared/components/share-button";
import Image from "next/image";
import { Carousel } from "./car-card-carousel";
import type { CarCardProps } from "./car-card-types";

function resolveBadgeNode(badge: CarCardProps["badge"]) {
  if (!badge) {
    return <div className="h-6" />;
  }
  if (badge.type === "excellent") {
    return <CustomBadge text={badge.text} type="excellentPrice" />;
  }
  if (badge.type === "priceDrop") {
    return <CustomBadge text={badge.text} type="priceDrop" />;
  }
  return <CustomBadge icon={null} text={badge.text} type="preQualifies" />;
}

export function CarCardImageSection({
  carImage,
  carName,
  badge,
  vdpUrl,
  vin,
}: {
  carImage: CarCardProps["carImage"];
  carName: string;
  badge: CarCardProps["badge"];
  vdpUrl: string;
  vin: string;
}) {
  return (
    <div className="relative h-78 overflow-hidden">
      {Array.isArray(carImage) && carImage.length > 1 ? (
        <Carousel carName={carName} images={carImage} />
      ) : (
        <Image
          alt={carName}
          className="absolute inset-0 h-full max-h-78 w-full max-w-104 object-contain p-4"
          height={312}
          src={typeof carImage === "string" ? carImage : (carImage[0] ?? "")}
          width={416}
        />
      )}
      <div className="absolute top-0 right-0 left-0 flex items-start justify-between p-4 pt-2 pr-2">
        <div>{resolveBadgeNode(badge)}</div>
        <div className="-mt-0.75 flex gap-0">
          <ShareButton vehicleUrl={vdpUrl} />
          {vin && <FavoriteButton vin={vin} />}
        </div>
      </div>
    </div>
  );
}
