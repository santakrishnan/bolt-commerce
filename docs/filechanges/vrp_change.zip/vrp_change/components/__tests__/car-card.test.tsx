import { fireEvent, render, screen } from "@arrow/vitest-config/test-utils";
import * as matchers from "@testing-library/jest-dom/matchers";
import { cleanup } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

expect.extend(matchers);
afterEach(cleanup);

import CarCard from "../car-card";
import type { CarCardProps } from "../car-card-types";

vi.mock("next/image", async () => {
  const actual = await vi.importActual("next/image");
  return {
    __esModule: true,
    default: actual.default,
  };
});

vi.mock("@config/routes", () => ({
  buildUsedCarsPath: vi.fn(
    ({ make, model, trim, year, vin }) => `/used-cars/${year}-${make}-${model}-${trim}-${vin}`
  ),
}));

vi.mock("@features/favorites", () => ({
  FavoriteButton: ({ vin }: { vin: string }) => (
    <button data-testid="favorite-btn" data-vin={vin} type="button">
      Favorite
    </button>
  ),
}));

vi.mock("@features/search/lib/mock-financing-service", () => ({
  getVehicleFinancing: vi.fn(() => ({
    apr: "5.9%",
    creditScore: "750",
    estimatedMonthlyPayment: "$450/mo",
    termMonths: 72,
  })),
}));

vi.mock("@features/search/lib/mock-vehicles", () => ({
  mockVehicles: [
    {
      id: "1",
      title: "2023 Toyota Camry SE",
      make: "Toyota",
      model: "Camry",
      variant: "SE",
      year: 2023,
      vin: "1HGBH41JX1",
      price: 28_500,
      oldPrice: 30_000,
      image: "/images/car1.jpg",
      odometer: "15,234 mi",
      miles: "6.1 mi",
      owners: 1,
      match: 92,
      labels: ["Excellent Price"],
    },
    {
      id: "2",
      title: "2022 Honda Accord EX",
      make: "Honda",
      model: "Accord",
      variant: "EX",
      year: 2022,
      vin: "2HGFB21K2",
      price: 25_000,
      oldPrice: null,
      image: ["/img/a.jpg", "/img/b.jpg"],
      odometer: "20,000 mi",
      miles: "8.2 mi",
      owners: 2,
      match: 85,
      labels: ["Price Drop"],
    },
    {
      id: "3",
      title: "2021 Ford F-150 XLT",
      make: "Ford",
      model: "F-150",
      variant: "XLT",
      year: 2021,
      vin: "1FTFW1ET5MFA12345",
      price: 35_000,
      oldPrice: null,
      image: "/images/car3.jpg",
      odometer: "30,000 mi",
      miles: "12.0 mi",
      owners: 1,
      match: 78,
      labels: ["Special Deal"],
    },
    {
      id: "4",
      title: "2020 Nissan Altima S",
      make: "Nissan",
      model: "Altima",
      variant: "S",
      year: 2020,
      vin: "1N4AL3AP5LC123456",
      price: 19_000,
      oldPrice: null,
      image: "/images/car4.jpg",
      odometer: "45,000 mi",
      miles: "5.0 mi",
      owners: 2,
      match: 70,
      labels: [],
    },
  ],
}));

vi.mock("@features/vehicle-preview", () => ({
  VehiclePreviewModal: ({
    isOpen,
    onClose,
    vdpUrl,
    vin,
  }: {
    isOpen: boolean;
    onClose: () => void;
    vdpUrl?: string;
    vin?: string;
    vehicle?: unknown;
  }) =>
    isOpen ? (
      <div data-testid="vehicle-preview-modal" data-vdp-url={vdpUrl} data-vin={vin}>
        <button onClick={onClose} type="button">
          Close Preview
        </button>
      </div>
    ) : null,
}));

vi.mock("@shared/components/custom-badge", () => ({
  CustomBadge: ({
    text,
    type,
    matchPercentage,
  }: {
    text?: string;
    type: string;
    matchPercentage?: number;
  }) => (
    <span data-testid={`badge-${type}`}>
      {text}
      {matchPercentage === undefined ? null : `${matchPercentage}%`}
    </span>
  ),
}));

vi.mock("@shared/components/share-button", () => ({
  ShareButton: ({ vehicleUrl }: { vehicleUrl: string }) => (
    <button data-testid="share-btn" data-url={vehicleUrl} type="button">
      Share
    </button>
  ),
}));

vi.mock("../car-card-carousel", () => ({
  Carousel: ({ images, carName }: { images: string[]; carName: string }) => (
    <div data-car-name={carName} data-images={images.join(",")} data-testid="carousel">
      Carousel
    </div>
  ),
}));

vi.mock("../car-card-content", () => ({
  CarCardContent: ({
    onShowEstimation,
    onShowRefineSearch,
    carName,
  }: {
    onShowEstimation: () => void;
    onShowRefineSearch: () => void;
    carName: string;
  }) => (
    <div data-testid="car-card-content">
      <span>{carName}</span>
      <button
        data-testid="show-estimation-btn"
        onClick={(e) => {
          e.stopPropagation();
          onShowEstimation();
        }}
        type="button"
      >
        Show Estimation
      </button>
      <button
        data-testid="show-refine-btn"
        onClick={(e) => {
          e.stopPropagation();
          onShowRefineSearch?.();
        }}
        type="button"
      >
        Refine
      </button>
    </div>
  ),
}));

vi.mock("../estimation-modal", () => ({
  default: ({
    isOpen,
    onClose,
  }: {
    isOpen: boolean;
    onClose: () => void;
    apr?: string;
    creditScore?: string;
    estimatedMonthlyPayment?: string;
    termLength?: string;
  }) =>
    isOpen ? (
      <div data-testid="estimation-modal">
        <button onClick={onClose} type="button">
          Close Estimation
        </button>
      </div>
    ) : null,
}));

vi.mock("../refine-search-modal", () => ({
  RefineSearchModal: ({
    isOpen,
    onClose,
    onSearch,
  }: {
    isOpen: boolean;
    onClose: () => void;
    activeFilters?: unknown[];
    onApplyFilters?: (f: unknown[]) => void;
    onSearch?: () => void;
  }) =>
    isOpen ? (
      <div data-testid="refine-search-modal">
        <button onClick={onClose} type="button">
          Close Refine
        </button>
        <button onClick={onSearch} type="button">
          Trigger Search
        </button>
      </div>
    ) : null,
}));

const VDP_URL_REGEX = /toyota.*camry/i;

const defaultProps: CarCardProps = {
  activeFilters: [],
  carImage: "/images/car.jpg",
  carName: "2023 Toyota Camry SE",
  make: "Toyota",
  model: "Camry",
  variant: "SE",
  year: 2023,
  vin: "1HGBH41JXMN109186",
  price: "$28,500",
  wasPrice: "$30,000",
  mileage: "15,234 mi",
  estimatedPayment: "Est. $450/mo",
  exteriorColor: "Pearl White",
  exteriorColorHex: "#FFFFFF",
  interiorColor: "Black",
  interiorColorHex: "#000000",
  matchPercentage: "92",
  dealerName: "Toyota of Fort Worth",
  distance: "6.1 mi",
  owners: 1,
  features: { warranty: true, inspected: true, oneOwner: true },
  onSearch: vi.fn(),
};

describe("CarCard", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Rendering", () => {
    it("renders the card component", () => {
      const { container } = render(<CarCard {...defaultProps} />);
      expect(container.firstChild).toBeInTheDocument();
    });

    it("renders CarCardContent", () => {
      render(<CarCard {...defaultProps} />);
      expect(screen.getByTestId("car-card-content")).toBeInTheDocument();
    });

    it("renders FavoriteButton when vin is provided", () => {
      render(<CarCard {...defaultProps} vin="TEST123" />);
      expect(screen.getByTestId("favorite-btn")).toBeInTheDocument();
    });

    it("does not render FavoriteButton when vin is not provided", () => {
      render(<CarCard {...defaultProps} vin={undefined} />);
      expect(screen.queryByTestId("favorite-btn")).not.toBeInTheDocument();
    });

    it("renders ShareButton", () => {
      render(<CarCard {...defaultProps} />);
      expect(screen.getByTestId("share-btn")).toBeInTheDocument();
    });

    it("renders single image when carImage is a string", () => {
      render(<CarCard {...defaultProps} carImage="/images/car.jpg" />);
      expect(screen.getByAltText("2023 Toyota Camry SE")).toBeInTheDocument();
    });

    it("renders Carousel when carImage is an array with multiple images", () => {
      render(<CarCard {...defaultProps} carImage={["/images/car1.jpg", "/images/car2.jpg"]} />);
      expect(screen.getByTestId("carousel")).toBeInTheDocument();
    });

    it("renders single image when carImage is a single-element array", () => {
      render(<CarCard {...defaultProps} carImage={["/images/car.jpg"]} />);
      expect(screen.queryByTestId("carousel")).not.toBeInTheDocument();
    });

    it("renders empty string src when carImage is empty array (covers carImage[0] ?? '' branch)", () => {
      const { container } = render(<CarCard {...defaultProps} carImage={[]} />);
      expect(container.firstChild).toBeInTheDocument();
    });

    it("handles non-numeric price (covers parseInt || 0 branch in vehiclePreviewData)", () => {
      const { container } = render(<CarCard {...defaultProps} price="N/A" />);
      expect(container.firstChild).toBeInTheDocument();
    });

    it("handles undefined features (covers features?.warranty ?? false and features?.inspected ?? false branches)", () => {
      const { container } = render(<CarCard {...defaultProps} features={{ oneOwner: true }} />);
      expect(container.firstChild).toBeInTheDocument();
    });

    it("shows estimation modal with non-numeric price (covers || 0 branch in estimation IIFE)", () => {
      render(<CarCard {...defaultProps} price="N/A" />);
      fireEvent.click(screen.getByTestId("show-estimation-btn"));

      expect(screen.getByTestId("estimation-modal")).toBeInTheDocument();
    });
  });

  describe("Badge rendering", () => {
    it("renders spacer div when no badge is provided", () => {
      const { container } = render(<CarCard {...defaultProps} badge={undefined} />);

      const spacer = container.querySelector(".h-6");
      expect(spacer).toBeInTheDocument();
    });

    it("renders excellent price badge", () => {
      render(<CarCard {...defaultProps} badge={{ type: "excellent", text: "Excellent Price" }} />);
      expect(screen.getByTestId("badge-excellentPrice")).toBeInTheDocument();
    });

    it("renders price drop badge", () => {
      render(<CarCard {...defaultProps} badge={{ type: "priceDrop", text: "Price Drop" }} />);
      expect(screen.getByTestId("badge-priceDrop")).toBeInTheDocument();
    });

    it("renders available/preQualifies badge for other types", () => {
      render(<CarCard {...defaultProps} badge={{ type: "available", text: "Pre-Qualifies" }} />);
      expect(screen.getByTestId("badge-preQualifies")).toBeInTheDocument();
    });
  });

  describe("Preview modal", () => {
    it("does not show VehiclePreviewModal by default", () => {
      render(<CarCard {...defaultProps} />);
      expect(screen.queryByTestId("vehicle-preview-modal")).not.toBeInTheDocument();
    });

    it("opens VehiclePreviewModal on card click when enablePreviewModal is true", () => {
      const { container } = render(<CarCard {...defaultProps} enablePreviewModal={true} />);
      const card = container.querySelector('[role="button"][tabindex="0"]') as HTMLElement;
      fireEvent.click(card);
      expect(screen.getByTestId("vehicle-preview-modal")).toBeInTheDocument();
    });

    it("does not open VehiclePreviewModal when enablePreviewModal is false", () => {
      const { container } = render(<CarCard {...defaultProps} enablePreviewModal={false} />);
      const card = container.querySelector('[role="button"][tabindex="0"]') as HTMLElement;
      fireEvent.click(card);
      expect(screen.queryByTestId("vehicle-preview-modal")).not.toBeInTheDocument();
    });

    it("closes VehiclePreviewModal when close button is clicked", () => {
      const { container } = render(<CarCard {...defaultProps} />);
      const card = container.querySelector('[role="button"][tabindex="0"]') as HTMLElement;
      fireEvent.click(card);
      expect(screen.getByTestId("vehicle-preview-modal")).toBeInTheDocument();
      fireEvent.click(screen.getByText("Close Preview"));
      expect(screen.queryByTestId("vehicle-preview-modal")).not.toBeInTheDocument();
    });

    it("opens preview modal on Enter key press", () => {
      const { container } = render(<CarCard {...defaultProps} enablePreviewModal={true} />);
      const card = container.querySelector('[role="button"][tabindex="0"]') as HTMLElement;
      fireEvent.keyDown(card, { key: "Enter" });
      expect(screen.getByTestId("vehicle-preview-modal")).toBeInTheDocument();
    });

    it("opens preview modal on Space key press", () => {
      const { container } = render(<CarCard {...defaultProps} enablePreviewModal={true} />);
      const card = container.querySelector('[role="button"][tabindex="0"]') as HTMLElement;
      fireEvent.keyDown(card, { key: " " });
      expect(screen.getByTestId("vehicle-preview-modal")).toBeInTheDocument();
    });

    it("does not open preview on other key press", () => {
      const { container } = render(<CarCard {...defaultProps} enablePreviewModal={true} />);
      const card = container.querySelector('[role="button"][tabindex="0"]') as HTMLElement;
      fireEvent.keyDown(card, { key: "Tab" });
      expect(screen.queryByTestId("vehicle-preview-modal")).not.toBeInTheDocument();
    });
  });

  describe("Estimation modal", () => {
    it("opens EstimationModal when show-estimation-btn is clicked", () => {
      render(<CarCard {...defaultProps} />);
      fireEvent.click(screen.getByTestId("show-estimation-btn"));
      expect(screen.getByTestId("estimation-modal")).toBeInTheDocument();
    });

    it("closes EstimationModal when its close button is clicked", () => {
      render(<CarCard {...defaultProps} />);
      fireEvent.click(screen.getByTestId("show-estimation-btn"));
      expect(screen.getByTestId("estimation-modal")).toBeInTheDocument();
      fireEvent.click(screen.getByText("Close Estimation"));
      expect(screen.queryByTestId("estimation-modal")).not.toBeInTheDocument();
    });

    it("uses provided estimation data when available", () => {
      render(
        <CarCard
          {...defaultProps}
          estimation={{
            apr: "3.9%",
            creditScore: "800",
            estimatedMonthlyPayment: "$399/mo",
            termLength: "60 months",
          }}
        />
      );
      fireEvent.click(screen.getByTestId("show-estimation-btn"));
      expect(screen.getByTestId("estimation-modal")).toBeInTheDocument();
    });
  });

  describe("Refine search modal", () => {
    it("opens RefineSearchModal when show-refine-btn is clicked", () => {
      render(<CarCard {...defaultProps} />);
      fireEvent.click(screen.getByTestId("show-refine-btn"));
      expect(screen.getByTestId("refine-search-modal")).toBeInTheDocument();
    });

    it("closes RefineSearchModal when its close button is clicked", () => {
      render(<CarCard {...defaultProps} />);
      fireEvent.click(screen.getByTestId("show-refine-btn"));
      expect(screen.getByTestId("refine-search-modal")).toBeInTheDocument();
      fireEvent.click(screen.getByText("Close Refine"));
      expect(screen.queryByTestId("refine-search-modal")).not.toBeInTheDocument();
    });
  });

  describe("VDP URL computation", () => {
    it("builds VDP URL when all required fields are provided", () => {
      render(<CarCard {...defaultProps} />);
      const shareBtn = screen.getByTestId("share-btn");
      expect(shareBtn.getAttribute("data-url")).toMatch(VDP_URL_REGEX);
    });

    it("uses '#' as vdpUrl when required fields are missing", () => {
      render(<CarCard {...defaultProps} make={undefined} model={undefined} />);
      const shareBtn = screen.getByTestId("share-btn");
      expect(shareBtn.getAttribute("data-url")).toBe("#");
    });
  });

  describe("Overlay stopPropagation", () => {
    it("estimation modal does not trigger card click when closed", () => {
      render(<CarCard {...defaultProps} enablePreviewModal={true} />);
      fireEvent.click(screen.getByTestId("show-estimation-btn"));
      expect(screen.getByTestId("estimation-modal")).toBeInTheDocument();
      fireEvent.click(screen.getByText("Close Estimation"));
      expect(screen.queryByTestId("estimation-modal")).not.toBeInTheDocument();
      expect(screen.queryByTestId("vehicle-preview-modal")).not.toBeInTheDocument();
    });

    it("estimation overlay keyDown does not throw", () => {
      render(<CarCard {...defaultProps} />);
      fireEvent.click(screen.getByTestId("show-estimation-btn"));
      expect(screen.getByTestId("estimation-modal")).toBeInTheDocument();
      expect(() =>
        fireEvent.keyDown(screen.getByTestId("estimation-modal"), { key: "Enter" })
      ).not.toThrow();
    });

    it("refine search modal does not trigger card click when closed", () => {
      render(<CarCard {...defaultProps} enablePreviewModal={true} />);
      fireEvent.click(screen.getByTestId("show-refine-btn"));
      expect(screen.getByTestId("refine-search-modal")).toBeInTheDocument();
      fireEvent.click(screen.getByText("Close Refine"));
      expect(screen.queryByTestId("refine-search-modal")).not.toBeInTheDocument();
      expect(screen.queryByTestId("vehicle-preview-modal")).not.toBeInTheDocument();
    });

    it("refine search overlay keyDown does not throw", () => {
      render(<CarCard {...defaultProps} />);
      fireEvent.click(screen.getByTestId("show-refine-btn"));
      expect(screen.getByTestId("refine-search-modal")).toBeInTheDocument();
      expect(() =>
        fireEvent.keyDown(screen.getByTestId("refine-search-modal"), { key: "Enter" })
      ).not.toThrow();
    });
  });

  describe("Accessibility", () => {
    it("card has role=button", () => {
      const { container } = render(<CarCard {...defaultProps} />);
      const card = container.querySelector('[role="button"]');
      expect(card).toBeInTheDocument();
    });

    it("card has tabIndex=0", () => {
      const { container } = render(<CarCard {...defaultProps} />);
      const card = container.querySelector('[role="button"][tabindex="0"]');
      expect(card).toBeInTheDocument();
    });
  });
});
