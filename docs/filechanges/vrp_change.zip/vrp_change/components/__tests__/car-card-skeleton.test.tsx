import { render } from "@arrow/vitest-config/test-utils";
import * as matchers from "@testing-library/jest-dom/matchers";
import { cleanup } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";

expect.extend(matchers);
afterEach(cleanup);

import CarCardSkeleton from "../car-card-skeleton";

describe("CarCardSkeleton", () => {
  it("renders without crashing", () => {
    const { container } = render(<CarCardSkeleton />);
    expect(container.firstChild).toBeInTheDocument();
  });

  it("renders a root container element", () => {
    const { container } = render(<CarCardSkeleton />);
    const root = container.firstChild as HTMLElement;
    expect(root.tagName).toBe("DIV");
  });

  it("renders the image placeholder shimmer block", () => {
    const { container } = render(<CarCardSkeleton />);
    const shimmers = container.querySelectorAll(".shimmer");
    expect(shimmers.length).toBeGreaterThan(0);
  });

  it("renders multiple shimmer blocks for skeleton content", () => {
    const { container } = render(<CarCardSkeleton />);
    const shimmers = container.querySelectorAll(".shimmer");

    expect(shimmers.length).toBeGreaterThanOrEqual(5);
  });

  it("is structured with an image area and a content area", () => {
    const { container } = render(<CarCardSkeleton />);

    const imageArea = container.querySelector(".h-78");
    expect(imageArea).toBeInTheDocument();

    const contentArea = container.querySelector(".flex.flex-col.gap-3");
    expect(contentArea).toBeInTheDocument();
  });
});
