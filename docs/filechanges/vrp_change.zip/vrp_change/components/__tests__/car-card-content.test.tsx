import { fireEvent, render, screen } from "@arrow/vitest-config/test-utils";
import * as matchers from "@testing-library/jest-dom/matchers";
import { cleanup } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

expect.extend(matchers);
afterEach(cleanup);

import { CarCardContent } from "../car-card-content";

vi.mock("next/image", async () => {
  const actual = await vi.importActual("next/image");
  return {
    __esModule: true,
    default: actual.default,
  };
});

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({
    children,
    onClick,
    className,
  }: {
    children: React.ReactNode;
    onClick?: (e: React.MouseEvent) => void;
    className?: string;
    type?: string;
    variant?: string;
  }) => (
    <button className={className} onClick={onClick} type="button">
      {children}
    </button>
  ),
  Heading: ({
    children,
    level: _level,
    weight: _weight,
    className,
  }: {
    children: React.ReactNode;
    level?: number;
    weight?: string;
    className?: string;
  }) => <h3 className={className}>{children}</h3>,
}));

vi.mock("@shared/components/custom-badge", () => ({
  CustomBadge: ({
    text,
    type,
    matchPercentage,
    ownerCount,
  }: {
    text?: string;
    type: string;
    matchPercentage?: number;
    ownerCount?: number;
  }) => (
    <span data-testid={`badge-${type}`}>
      {text ?? (matchPercentage === undefined ? null : `${matchPercentage}%`)}
      {ownerCount === undefined ? null : `${ownerCount} owner`}
    </span>
  ),
}));

const defaultProps = {
  carName: "2023 Toyota Camry SE",
  price: "$28,500",
  wasPrice: "$30,000",
  mileage: "15,234 mi",
  estimatedPayment: "Est. $450/mo",
  exteriorColor: "Pearl White",
  exteriorColorHex: "#FFFFFF",
  exteriorColorGradient: undefined as string | undefined,
  interiorColor: "Black",
  interiorColorHex: "#000000",
  matchPercentage: "92",
  dealerName: "Toyota of Fort Worth",
  distance: "6.1 mi",
  owners: 1,
  features: { warranty: true, inspected: true, oneOwner: true },
  onShowEstimation: vi.fn(),
  onShowRefineSearch: vi.fn(),
};

describe("CarCardContent", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Car name display", () => {
    it("renders full car name when ≤ 39 characters", () => {
      render(<CarCardContent {...defaultProps} />);
      expect(screen.getByText("2023 Toyota Camry SE")).toBeInTheDocument();
    });

    it("truncates car name when > 39 characters", () => {
      const longName = "2023 Toyota Camry SE Extra Long Trim Edition Pro";
      render(<CarCardContent {...defaultProps} carName={longName} />);
      const expectedTruncated = `${longName.slice(0, 39)}…`;
      expect(screen.getByText(expectedTruncated)).toBeInTheDocument();
    });
  });

  describe("Pricing", () => {
    it("renders current price", () => {
      render(<CarCardContent {...defaultProps} />);
      expect(screen.getByText("$28,500")).toBeInTheDocument();
    });

    it("renders wasPrice when provided", () => {
      render(<CarCardContent {...defaultProps} />);
      expect(screen.getByText("$30,000")).toBeInTheDocument();
    });

    it("renders placeholder dash when wasPrice is not provided", () => {
      render(<CarCardContent {...defaultProps} wasPrice={undefined} />);

      expect(screen.getByText("-")).toBeInTheDocument();
    });

    it("renders estimated payment", () => {
      render(<CarCardContent {...defaultProps} />);
      expect(screen.getByText("Est. $450/mo")).toBeInTheDocument();
    });
  });

  describe("Mileage", () => {
    it("renders mileage value", () => {
      render(<CarCardContent {...defaultProps} />);
      expect(screen.getByText("15,234 mi")).toBeInTheDocument();
    });
  });

  describe("Colors", () => {
    it("renders exterior color label", () => {
      render(<CarCardContent {...defaultProps} />);
      expect(screen.getByText("Pearl White")).toBeInTheDocument();
    });

    it("renders interior color label", () => {
      render(<CarCardContent {...defaultProps} />);
      expect(screen.getByText("Black")).toBeInTheDocument();
    });

    it("renders exterior color swatch using hex when no gradient", () => {
      const { container } = render(
        <CarCardContent {...defaultProps} exteriorColorGradient={undefined} />
      );

      const swatches = container.querySelectorAll("div[style]");
      expect(swatches.length).toBeGreaterThan(0);
    });

    it("renders exterior color swatch using gradient when gradient provided", () => {
      const { container } = render(
        <CarCardContent {...defaultProps} exteriorColorGradient="linear-gradient(red, blue)" />
      );
      const gradientSwatch = container.querySelector('[style*="linear-gradient"]');
      expect(gradientSwatch).toBeInTheDocument();
    });
  });

  describe("Match percentage badge", () => {
    it("renders match badge when matchPercentage is provided", () => {
      render(<CarCardContent {...defaultProps} matchPercentage="92" />);
      expect(screen.getByTestId("badge-matchingPercentage")).toBeInTheDocument();
    });

    it("does not render match badge when matchPercentage is undefined", () => {
      render(<CarCardContent {...defaultProps} matchPercentage={undefined} />);
      expect(screen.queryByTestId("badge-matchingPercentage")).not.toBeInTheDocument();
    });
  });

  describe("Dealer info", () => {
    it("renders dealer name", () => {
      render(<CarCardContent {...defaultProps} />);
      expect(screen.getByText("Toyota of Fort Worth")).toBeInTheDocument();
    });

    it("renders distance", () => {
      render(<CarCardContent {...defaultProps} />);
      expect(screen.getByText("6.1 mi")).toBeInTheDocument();
    });
  });

  describe("Features", () => {
    it("renders warranty badge when features.warranty is true", () => {
      render(<CarCardContent {...defaultProps} features={{ warranty: true }} />);
      expect(screen.getByTestId("badge-warranty")).toBeInTheDocument();
    });

    it("does not render warranty badge when features.warranty is false", () => {
      render(<CarCardContent {...defaultProps} features={{ warranty: false }} />);
      expect(screen.queryByTestId("badge-warranty")).not.toBeInTheDocument();
    });

    it("renders inspected badge when features.inspected is true", () => {
      render(<CarCardContent {...defaultProps} features={{ inspected: true }} />);
      expect(screen.getByTestId("badge-Inspected")).toBeInTheDocument();
    });

    it("does not render inspected badge when features.inspected is false", () => {
      render(<CarCardContent {...defaultProps} features={{ inspected: false }} />);
      expect(screen.queryByTestId("badge-Inspected")).not.toBeInTheDocument();
    });

    it("renders owner badge when owners === 1", () => {
      render(<CarCardContent {...defaultProps} owners={1} />);
      expect(screen.getByTestId("badge-owner")).toBeInTheDocument();
    });

    it("does not render owner badge when owners > 1", () => {
      render(<CarCardContent {...defaultProps} owners={2} />);
      expect(screen.queryByTestId("badge-owner")).not.toBeInTheDocument();
    });

    it("does not render owner badge when owners is 0", () => {
      render(<CarCardContent {...defaultProps} owners={0} />);
      expect(screen.queryByTestId("badge-owner")).not.toBeInTheDocument();
    });

    it("features row uses a 3-column grid to keep layout stable", () => {
      const { container } = render(<CarCardContent {...defaultProps} />);
      const featuresRow = container.querySelector(".grid.grid-cols-3");
      expect(featuresRow).toBeInTheDocument();
    });

    it("warranty is in the left slot, inspected in the center slot, owner in the right slot", () => {
      const { container } = render(
        <CarCardContent
          {...defaultProps}
          features={{ warranty: true, inspected: true }}
          owners={1}
        />
      );
      const slots = container.querySelectorAll(".grid.grid-cols-3 > div");
      expect(slots).toHaveLength(3);
      expect(slots[0]).toContainElement(screen.getByTestId("badge-warranty"));
      expect(slots[1]).toContainElement(screen.getByTestId("badge-Inspected"));
      expect(slots[2]).toContainElement(screen.getByTestId("badge-owner"));
    });

    it("owner slot is empty (not removed) when owners > 1, keeping layout stable", () => {
      const { container } = render(
        <CarCardContent
          {...defaultProps}
          features={{ warranty: true, inspected: true }}
          owners={2}
        />
      );
      const slots = container.querySelectorAll(".grid.grid-cols-3 > div");
      expect(slots).toHaveLength(3);
      expect(slots[2]).toBeEmptyDOMElement();
    });
  });

  describe("Interactions", () => {
    it("calls onShowEstimation when info icon is clicked", () => {
      const onShowEstimation = vi.fn();
      const { container } = render(
        <CarCardContent {...defaultProps} onShowEstimation={onShowEstimation} />
      );

      const infoImg = container.querySelector('img[alt="Info"]') as HTMLElement;
      fireEvent.click(infoImg);
      expect(onShowEstimation).toHaveBeenCalledTimes(1);
    });

    it("info icon click stops propagation", () => {
      const parentHandler = vi.fn();
      const { container } = render(
        // biome-ignore lint/a11y/noStaticElementInteractions lint/a11y/useKeyWithClickEvents lint/a11y/noNoninteractiveElementInteractions: test only
        <div onClick={parentHandler}>
          <CarCardContent {...defaultProps} />
        </div>
      );
      const infoImg = container.querySelector('img[alt="Info"]') as HTMLElement;
      fireEvent.click(infoImg);
      expect(parentHandler).not.toHaveBeenCalled();
    });

    it("calls onShowRefineSearch when 'Refine your search' button is clicked", () => {
      const onShowRefineSearch = vi.fn();
      render(<CarCardContent {...defaultProps} onShowRefineSearch={onShowRefineSearch} />);
      fireEvent.click(screen.getByText("Refine your search"));
      expect(onShowRefineSearch).toHaveBeenCalledTimes(1);
    });

    it("refine search button click stops propagation", () => {
      const parentHandler = vi.fn();
      render(
        // biome-ignore lint/a11y/noStaticElementInteractions lint/a11y/useKeyWithClickEvents lint/a11y/noNoninteractiveElementInteractions: test only
        <div onClick={parentHandler}>
          <CarCardContent {...defaultProps} />
        </div>
      );
      fireEvent.click(screen.getByText("Refine your search"));
      expect(parentHandler).not.toHaveBeenCalled();
    });

    it("dealer name button click stops propagation", () => {
      const parentHandler = vi.fn();
      render(
        // biome-ignore lint/a11y/noStaticElementInteractions lint/a11y/useKeyWithClickEvents lint/a11y/noNoninteractiveElementInteractions: test only
        <div onClick={parentHandler}>
          <CarCardContent {...defaultProps} />
        </div>
      );
      fireEvent.click(screen.getByText("Toyota of Fort Worth"));
      expect(parentHandler).not.toHaveBeenCalled();
    });
  });
});
