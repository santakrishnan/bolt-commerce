import { fireEvent, render, screen } from "@arrow/vitest-config/test-utils";
import * as matchers from "@testing-library/jest-dom/matchers";
import { cleanup } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

expect.extend(matchers);
afterEach(cleanup);

import { Carousel } from "../car-card-carousel";

vi.mock("next/image", async () => {
  const actual = await vi.importActual("next/image");
  return {
    __esModule: true,
    default: actual.default,
  };
});

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({
    children,
    onClick,
    "aria-label": ariaLabel,
  }: {
    children: React.ReactNode;
    onClick?: (e: React.MouseEvent) => void;
    "aria-label"?: string;
  }) => (
    <button aria-label={ariaLabel} onClick={onClick} type="button">
      {children}
    </button>
  ),
}));

// ─── Test Data ────────────────────────────────────────────────────────────────

const IMAGES = ["/img/car1.jpg", "/img/car2.jpg", "/img/car3.jpg"];
const CAR_NAME = "2023 Toyota Camry";

describe("Carousel", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Empty / edge cases", () => {
    it("returns null when images array is empty", () => {
      const { container } = render(<Carousel carName={CAR_NAME} images={[]} />);
      expect(container.firstChild).toBeNull();
    });

    it("renders a single image without navigation buttons hidden", () => {
      render(<Carousel carName={CAR_NAME} images={["/img/car1.jpg"]} />);
      expect(screen.getByAltText(`${CAR_NAME} — image 1`)).toBeInTheDocument();
    });
  });

  describe("Rendering", () => {
    it("renders all images from the array", () => {
      render(<Carousel carName={CAR_NAME} images={IMAGES} />);
      IMAGES.forEach((_, idx) => {
        expect(screen.getAllByAltText(`${CAR_NAME} — image ${idx + 1}`)[0]).toBeInTheDocument();
      });
    });

    it("first image starts as visible (opacity-100)", () => {
      const { container } = render(<Carousel carName={CAR_NAME} images={IMAGES} />);
      const imgs = container.querySelectorAll("img");
      expect(imgs[0]).toHaveClass("opacity-100");
    });

    it("subsequent images start as hidden (opacity-0)", () => {
      const { container } = render(<Carousel carName={CAR_NAME} images={IMAGES} />);
      const imgs = container.querySelectorAll("img");
      expect(imgs[1]).toHaveClass("opacity-0");
      expect(imgs[2]).toHaveClass("opacity-0");
    });

    it("renders prev and next navigation buttons", () => {
      render(<Carousel carName={CAR_NAME} images={IMAGES} />);
      expect(screen.getByLabelText("Previous image")).toBeInTheDocument();
      expect(screen.getByLabelText("Next image")).toBeInTheDocument();
    });

    it("renders correct number of dot indicators", () => {
      const { container } = render(<Carousel carName={CAR_NAME} images={IMAGES} />);
      const dots = container.querySelectorAll(".flex-1.justify-center span");
      expect(dots.length).toBeGreaterThan(0);
    });
  });

  describe("Navigation — Next", () => {
    it("advances to the next image on next button click", () => {
      const { container } = render(<Carousel carName={CAR_NAME} images={IMAGES} />);
      const nextBtn = screen.getByLabelText("Next image");

      fireEvent.click(nextBtn);

      const imgs = container.querySelectorAll("img");
      expect(imgs[0]).toHaveClass("opacity-0");
      expect(imgs[1]).toHaveClass("opacity-100");
    });

    it("wraps from last to first image on next click", () => {
      const { container } = render(<Carousel carName={CAR_NAME} images={IMAGES} />);
      const nextBtn = screen.getByLabelText("Next image");

      fireEvent.click(nextBtn);
      fireEvent.click(nextBtn);
      fireEvent.click(nextBtn);

      const imgs = container.querySelectorAll("img");
      expect(imgs[0]).toHaveClass("opacity-100");
    });
  });

  describe("Navigation — Prev", () => {
    it("goes back to the previous image on prev button click", () => {
      const { container } = render(<Carousel carName={CAR_NAME} images={IMAGES} />);
      const nextBtn = screen.getByLabelText("Next image");
      const prevBtn = screen.getByLabelText("Previous image");

      fireEvent.click(nextBtn);
      fireEvent.click(prevBtn);

      const imgs = container.querySelectorAll("img");
      expect(imgs[0]).toHaveClass("opacity-100");
    });

    it("wraps from first to last image on 0prev click", () => {
      const { container } = render(<Carousel carName={CAR_NAME} images={IMAGES} />);
      const prevBtn = screen.getByLabelText("Previous image");

      fireEvent.click(prevBtn);

      const imgs = container.querySelectorAll("img");
      expect(imgs[2]).toHaveClass("opacity-100");
    });
  });

  describe("Event propagation", () => {
    it("next button click stops propagation", () => {
      const parentHandler = vi.fn();
      const { container } = render(
        // biome-ignore lint/a11y/noStaticElementInteractions lint/a11y/useKeyWithClickEvents lint/a11y/noNoninteractiveElementInteractions: test only
        <div onClick={parentHandler}>
          <Carousel carName={CAR_NAME} images={IMAGES} />
        </div>
      );
      const nextBtn = container.querySelector("[aria-label='Next image']") as HTMLElement;
      fireEvent.click(nextBtn);
      expect(parentHandler).not.toHaveBeenCalled();
    });

    it("prev button click stops propagation", () => {
      const parentHandler = vi.fn();
      const { container } = render(
        // biome-ignore lint/a11y/noStaticElementInteractions lint/a11y/useKeyWithClickEvents lint/a11y/noNoninteractiveElementInteractions: test only
        <div onClick={parentHandler}>
          <Carousel carName={CAR_NAME} images={IMAGES} />
        </div>
      );
      const prevBtn = container.querySelector("[aria-label='Previous image']") as HTMLElement;
      fireEvent.click(prevBtn);
      expect(parentHandler).not.toHaveBeenCalled();
    });
  });
});
