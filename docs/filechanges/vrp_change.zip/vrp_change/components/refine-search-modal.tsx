"use client";

import type { ActiveFilter } from "@features/search";
import { mockVehicles } from "@features/search/lib/mock-vehicles";
import { AppButton } from "@shared/components/button";
import { CustomChips } from "@shared/components/custom-chips";
import { useSingletonModal } from "@shared/hooks/use-single-modal";
import { Button, Heading } from "@tfs-ucmp/ui";
import Image from "next/image";
import { useMemo, useState } from "react";

import { buildFilterOptions } from "./refine-search-modal.helpers";

interface RefineSearchModalProps {
  activeFilters?: ActiveFilter[];
  isOpen: boolean;
  onApplyFilters?: (filters: { id: string; label: string }[]) => void;
  onClose: () => void;
  onSearch: () => void;
}

export function RefineSearchModal({
  activeFilters: initialActiveFilters = [],
  isOpen,
  onClose,
  onApplyFilters,
  onSearch,
}: RefineSearchModalProps) {
  // Derive filter options from the mock search service (real inventory data)
  const { yourFilters, suggestedFilters, allFilters } = useMemo(
    () => buildFilterOptions(mockVehicles),
    []
  );

  const [activeFilters, setActiveFilters] = useState<ActiveFilter[]>(() => {
    // Start with initialActiveFilters (may be undefined) and add any matching filters
    const matchedFilters: ActiveFilter[] = [...initialActiveFilters];

    for (const initialFilter of initialActiveFilters) {
      const matchingFilter = allFilters.find(
        (f) => f.label.toLowerCase() === initialFilter.label.toLowerCase()
      );

      if (matchingFilter && !matchedFilters.some((mf) => mf.value === matchingFilter.id)) {
        matchedFilters.push({
          label: matchingFilter.label,
          type: "feature",
          value: matchingFilter.id,
          isRefineSearch: true,
        });
      }
    }
    return matchedFilters;
  });
  const [isCloseHovered, setIsCloseHovered] = useState(false);
  useSingletonModal("refine-search-open", isOpen, onClose);

  if (!isOpen) {
    return null;
  }

  const toggleFilter = (filterId: string) => {
    setActiveFilters((prev) => {
      const existingIndex = prev.findIndex((f) => f.value === filterId);
      if (existingIndex !== -1) {
        return prev.filter((_, i) => i !== existingIndex);
      }
      const filterOption = allFilters.find((f) => f.id === filterId);
      if (filterOption) {
        return [
          ...prev,
          {
            label: filterOption.label,
            type: "feature",
            value: filterId,
            isRefineSearch: true,
          },
        ];
      }
      return prev;
    });
  };

  const handleApplyFilters = () => {
    const selected = activeFilters
      .map((f) => ({ id: f.value, label: f.label }))
      .filter((f, idx, arr) => arr.findIndex((a) => a.id === f.id) === idx);
    onApplyFilters?.(selected);

    try {
      onSearch();
    } catch {
      // noop if parent didn't provide a handler
    }
    onClose();
  };

  const handleReset = () => {
    setActiveFilters([]);
    // Inform parent that refine filters are cleared and trigger a search
    onApplyFilters?.([]);
    try {
      onSearch();
    } catch {
      // noop
    }
  };

  return (
    // biome-ignore lint/a11y/noNoninteractiveElementInteractions: Modal backdrop needs click handler to close modal
    <div
      aria-label="Close modal"
      aria-modal="true"
      className="pointer-events-auto absolute inset-0 z-30 flex h-full w-full flex-col overflow-y-auto overflow-x-hidden rounded-lg bg-white shadow-xl"
      onClick={(e) => {
        e.stopPropagation();
      }}
      onKeyDown={(e) => {
        if (e.key === "Escape") {
          onClose();
        }
      }}
      onMouseDown={(e) => {
        e.stopPropagation();
      }}
      role="dialog"
      tabIndex={-1}
    >
      <div className="flex justify-end px-4 pt-1">
        <Button
          className="flex items-center gap-2 underline hover:bg-transparent"
          onClick={onClose}
          onMouseEnter={() => setIsCloseHovered(true)}
          onMouseLeave={() => setIsCloseHovered(false)}
          type="button"
          variant="ghost"
        >
          <span
            className={`text-sm ${
              isCloseHovered ? "text-muted-foreground" : "text-(--color-brand-text)"
            }`}
          >
            Close
          </span>
          <Image
            alt="Close"
            className={`mt-1 ml-1 ${isCloseHovered ? "opacity-60" : "opacity-100"}`}
            height={7.15}
            src="/images/cross.svg"
            width={7.15}
          />
        </Button>
      </div>

      <div className="mt-3 h-px bg-black opacity-10" />

      <div className="flex min-w-0 flex-1 flex-col justify-between overflow-y-auto p-3">
        <div className="flex min-w-0 flex-col gap-4">
          <Heading
            className="text-(--color-brand-text) text-sm md:text-sm"
            level={3}
            weight="semibold"
          >
            Your Filters
          </Heading>
          <div className="flex flex-wrap gap-1.5">
            {yourFilters.map((filter) => (
              <CustomChips
                key={filter.id}
                label={filter.label}
                onClick={() => toggleFilter(filter.id)}
                type={activeFilters.some((f) => f.value === filter.id) ? "selected" : "unselected"}
              />
            ))}
          </div>
        </div>

        <div className="flex min-w-0 flex-col gap-4">
          <Heading
            className="font-semibold text-(--color-brand-text) text-sm md:text-sm"
            level={3}
            weight="semibold"
          >
            Suggested
          </Heading>
          <div className="flex flex-wrap gap-1.5">
            {suggestedFilters.map((filter) => (
              <CustomChips
                key={filter.id}
                label={filter.label}
                onClick={() => toggleFilter(filter.id)}
                type={activeFilters.some((f) => f.value === filter.id) ? "selected" : "unselected"}
              />
            ))}
          </div>
        </div>
      </div>

      <div className="flex gap-4 px-4 pt-2 pb-3.5">
        <AppButton className="flex-1" onClick={handleApplyFilters} variant="primary">
          Apply Filter
        </AppButton>
        <AppButton className="flex-1" onClick={handleReset} variant="tertiary">
          Reset
        </AppButton>
      </div>
    </div>
  );
}
