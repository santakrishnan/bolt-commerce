import type { ActiveFilter } from "@features/search";

export interface EstimationData {
  apr: string;
  creditScore: string;
  estimatedMonthlyPayment: string;
  termLength: string;
}

export interface CarCardProps {
  activeFilters?: ActiveFilter[];
  badge?: {
    type: "excellent" | "available" | "priceDrop";
    text: string;
  };
  carImage: string | string[];
  carName: string;
  condition?: string;
  dealerLocation?: string;
  dealerName: string;
  distance: string;
  drivetrain?: string;
  enablePreviewModal?: boolean;
  estimatedPayment: string;
  estimation?: EstimationData;
  exteriorColor: string;
  exteriorColorGradient?: string;
  exteriorColorHex: string;
  features?: {
    warranty?: boolean;
    inspected?: boolean;
    oneOwner?: boolean;
  };
  interiorColor: string;
  interiorColorHex: string;
  make?: string;
  matchPercentage?: string;
  mileage: string;
  model?: string;
  mpg?: string;
  onApplyRefineFilters?: (filters: { id: string; label: string }[]) => void;
  onSearch?: () => void;
  owners: number;
  price: string;
  stock?: string;
  variant?: string;
  vehicleFeatures?: string[];
  vin?: string;
  wasPrice?: string;
  year?: number;
}
