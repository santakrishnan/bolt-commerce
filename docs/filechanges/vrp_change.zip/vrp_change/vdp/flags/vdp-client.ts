// Client-side VDP feature flag helpers for use in Client Components (reads from localStorage, synced from cookie).

import {
  VDP_DEFAULT_FLAGS,
  VDP_DEFAULT_SCENARIO_ID,
  VDP_FLAG_COOKIE_NAME,
  type VdpStatusFlags,
  vdpFlagsToVehicleStatus,
  vdpScenarios,
} from "./vdp-config";

// Get current VDP status flags from localStorage (client-side, synced with cookie).
export function getVdpFlagsSync(): VdpStatusFlags {
  if (typeof window !== "undefined") {
    const scenarioId = localStorage.getItem(VDP_FLAG_COOKIE_NAME);
    if (scenarioId && vdpScenarios[scenarioId]) {
      const scenario = vdpScenarios[scenarioId];
      if (scenario) {
        return scenario.flags;
      }
    }
  }

  const scenario = vdpScenarios[VDP_DEFAULT_SCENARIO_ID];
  return scenario?.flags ?? VDP_DEFAULT_FLAGS;
}

// Get a specific VDP flag value from localStorage (client-side, synced with cookie).
export function getVdpFlagSync<K extends keyof VdpStatusFlags>(flagName: K): VdpStatusFlags[K] {
  const flags = getVdpFlagsSync();
  return flags[flagName];
}

// Get VehicleStatusData from current VDP flags for initializing activeVehicleStatus in client components.
export function getVehicleStatusFromFlagsSync() {
  const flags = getVdpFlagsSync();
  return vdpFlagsToVehicleStatus(flags);
}
