import { cookies } from "next/headers";
import {
  VDP_DEFAULT_FLAGS,
  VDP_DEFAULT_SCENARIO_ID,
  VDP_FLAG_COOKIE_NAME,
  type VdpStatusFlags,
  vdpFlagsToVehicleStatus,
  vdpScenarios,
} from "./vdp-config";

export async function getVdpFlags(): Promise<VdpStatusFlags> {
  try {
    const cookieStore = await cookies();
    const scenarioCookie = cookieStore.get(VDP_FLAG_COOKIE_NAME);

    if (scenarioCookie?.value && vdpScenarios[scenarioCookie.value]) {
      console.log(`🚩 VDP Flags: Using scenario from cookie: ${scenarioCookie.value}`);
      const scenario = vdpScenarios[scenarioCookie.value];
      if (scenario) {
        return scenario.flags;
      }
    }
  } catch {
    // cookies() may fail in some contexts, fall back to default
  }

  const scenario = vdpScenarios[VDP_DEFAULT_SCENARIO_ID];
  return scenario?.flags ?? VDP_DEFAULT_FLAGS;
}

export async function getVdpFlag<K extends keyof VdpStatusFlags>(
  flagName: K
): Promise<VdpStatusFlags[K]> {
  const flags = await getVdpFlags();
  return flags[flagName];
}

export async function getVehicleStatusFromFlags() {
  const flags = await getVdpFlags();
  return vdpFlagsToVehicleStatus(flags);
}
