// VDP feature flag config/types for Vehicle Detail Page. Test via the debug panel or vdp-status-flag cookie.

export const VDP_FLAG_COOKIE_NAME = "vdp-status-flag";

export interface VdpStatusFlags {
  /** Toggle for new Features Table View */
  "features-table-view"?: boolean;
  /** Banner: "Vehicle History Report Pending" → CTA: View History Report */
  "vdp-history-report-pending": boolean;
  /** Banner: "160-Point Inspection In Progress" → no CTA */
  "vdp-inspection-in-progress": boolean;
  /** Banner: "Limited Photos Available" → CTA: Request More Photos */
  "vdp-limited-photos": boolean;
  /** Banner: "This Vehicle Is No Longer Available" → CTA: Browse Similar Vehicles */
  "vdp-no-longer-available": boolean;
}

export interface VdpScenario {
  description: string;
  flags: VdpStatusFlags;
  id: string;
  label: string;
}

export const vdpScenarios: Record<string, VdpScenario> = {
  none: {
    id: "none",
    label: "No Status Banner",
    description: "Vehicle is available with full details. No status banner shown.",
    flags: {
      "vdp-no-longer-available": false,
      "vdp-history-report-pending": false,
      "vdp-inspection-in-progress": false,
      "vdp-limited-photos": false,
      "features-table-view": true,
    },
  },

  browseSimilar: {
    id: "browseSimilar",
    label: "Browse Similar Vehicles",
    description:
      "Vehicle is no longer available. Shows 'This Vehicle Is No Longer Available' banner.",
    flags: {
      "vdp-no-longer-available": true,
      "vdp-history-report-pending": false,
      "vdp-inspection-in-progress": false,
      "vdp-limited-photos": false,
      "features-table-view": false,
    },
  },

  viewHistory: {
    id: "viewHistory",
    label: "View History Report",
    description: "History report is pending. Shows 'Vehicle History Report Pending' banner.",
    flags: {
      "vdp-no-longer-available": false,
      "vdp-history-report-pending": true,
      "vdp-inspection-in-progress": false,
      "vdp-limited-photos": false,
      "features-table-view": false,
    },
  },

  inspectionInProgress: {
    id: "inspectionInProgress",
    label: "Our 160-point inspection is in progress",
    description: "Inspection is underway. Shows '160-Point Inspection In Progress' banner.",
    flags: {
      "vdp-no-longer-available": false,
      "vdp-history-report-pending": false,
      "vdp-inspection-in-progress": true,
      "vdp-limited-photos": false,
      "features-table-view": false,
    },
  },

  requestPhotos: {
    id: "requestPhotos",
    label: "Request More Photos",
    description: "Limited photos available. Shows 'Limited Photos Available' banner.",
    flags: {
      "vdp-no-longer-available": false,
      "vdp-history-report-pending": false,
      "vdp-inspection-in-progress": false,
      "vdp-limited-photos": true,
      "features-table-view": false,
    },
  },
};

export const VDP_DEFAULT_SCENARIO_ID: keyof typeof vdpScenarios = "none";

export const VDP_DEFAULT_FLAGS: VdpStatusFlags = vdpScenarios[VDP_DEFAULT_SCENARIO_ID]?.flags ?? {
  "vdp-no-longer-available": false,
  "vdp-history-report-pending": false,
  "vdp-inspection-in-progress": false,
  "vdp-limited-photos": false,
  "features-table-view": false,
};

// Convert VdpStatusFlags to VehicleStatusData shape for VehiclePDP (1:1 flag mapping).
export function vdpFlagsToVehicleStatus(flags: VdpStatusFlags) {
  return {
    noLongerAvailable: flags["vdp-no-longer-available"],
    historyReportPending: flags["vdp-history-report-pending"],
    inspectionInProgress: flags["vdp-inspection-in-progress"],
    limitedPhotos: flags["vdp-limited-photos"],
    featuresTableView: flags["features-table-view"] ?? false,
  };
}
