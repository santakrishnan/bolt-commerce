import { beforeEach, describe, expect, it, vi } from "vitest";

describe("vdp-flags SDK wrappers", () => {
  beforeEach(() => {
    vi.resetModules();
  });

  it("returns scenario flags when cookie matches a known scenario", async () => {
    vi.doMock("../vdp-config", () => ({
      VDP_DEFAULT_FLAGS: {
        "vdp-no-longer-available": false,
        "vdp-history-report-pending": false,
        "vdp-inspection-in-progress": false,
        "vdp-limited-photos": false,
      },
      VDP_FLAG_COOKIE_NAME: "vdp-flag-cookie",
      vdpScenarios: {
        sale: {
          label: "Sale scenario",
          flags: {
            "vdp-no-longer-available": true,
            "vdp-history-report-pending": true,
            "vdp-inspection-in-progress": false,
            "vdp-limited-photos": false,
          },
        },
      },
    }));

    vi.doMock("flags/next", () => ({ flag: (opts: any) => opts }));

    vi.doMock("next/headers", () => ({
      cookies: () => ({
        get: (name: string) => (name === "vdp-flag-cookie" ? { value: "sale" } : undefined),
      }),
    }));

    const mod = await import("../vdp-flags");

    const params = { headers: {} as any, cookies: {} as any };
    await expect(mod.vdpNoLongerAvailable.decide?.(params)).resolves.toBe(true);
    await expect(mod.vdpHistoryReportPending.decide?.(params)).resolves.toBe(true);
    await expect(mod.vdpInspectionInProgress.decide?.(params)).resolves.toBe(false);
    await expect(mod.vdpLimitedPhotos.decide?.(params)).resolves.toBe(false);
  });

  it("falls back to default flags when cookies() throws", async () => {
    vi.doMock("../vdp-config", () => ({
      VDP_DEFAULT_FLAGS: {
        "vdp-no-longer-available": false,
        "vdp-history-report-pending": false,
        "vdp-inspection-in-progress": false,
        "vdp-limited-photos": false,
      },
      VDP_FLAG_COOKIE_NAME: "vdp-flag-cookie",
      vdpScenarios: {},
    }));

    vi.doMock("flags/next", () => ({ flag: (opts: any) => opts }));

    vi.doMock("next/headers", () => ({
      cookies: () => {
        throw new Error("no cookies here");
      },
    }));

    const mod = await import("../vdp-flags");

    const params = { headers: {} as any, cookies: {} as any };
    await expect(mod.vdpNoLongerAvailable.decide?.(params)).resolves.toBe(false);
    await expect(mod.vdpHistoryReportPending.decide?.(params)).resolves.toBe(false);
  });

  it("uses default when cookie value does not match any scenario", async () => {
    vi.doMock("../vdp-config", () => ({
      VDP_DEFAULT_FLAGS: {
        "vdp-no-longer-available": false,
        "vdp-history-report-pending": false,
        "vdp-inspection-in-progress": false,
        "vdp-limited-photos": false,
      },
      VDP_FLAG_COOKIE_NAME: "vdp-flag-cookie",
      vdpScenarios: {
        other: { label: "Other", flags: { "vdp-no-longer-available": true } },
      },
    }));

    vi.doMock("flags/next", () => ({ flag: (opts: any) => opts }));

    vi.doMock("next/headers", () => ({ cookies: () => ({ get: () => ({ value: "unknown" }) }) }));

    const mod = await import("../vdp-flags");

    const params = { headers: {} as any, cookies: {} as any };
    await expect(mod.vdpNoLongerAvailable.decide?.(params)).resolves.toBe(false);
  });
});
