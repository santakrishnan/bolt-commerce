import { describe, expect, it } from "vitest";
import {
  VDP_DEFAULT_FLAGS,
  VDP_DEFAULT_SCENARIO_ID,
  vdpFlagsToVehicleStatus,
  vdpScenarios,
} from "../vdp-config";

describe("vdp-config utilities", () => {
  it("exports scenarios and default flags", () => {
    expect(vdpScenarios).toBeDefined();
    expect(vdpScenarios.none).toBeDefined();
    expect(VDP_DEFAULT_FLAGS).toEqual(vdpScenarios[VDP_DEFAULT_SCENARIO_ID]?.flags);
  });

  it("maps flags to vehicle status shape correctly", () => {
    const flags = {
      "vdp-no-longer-available": true,
      "vdp-history-report-pending": false,
      "vdp-inspection-in-progress": true,
      "vdp-limited-photos": false,
      "features-table-view": true,
    } as const;

    const status = vdpFlagsToVehicleStatus(flags as any);
    expect(status.noLongerAvailable).toBe(true);
    expect(status.historyReportPending).toBe(false);
    expect(status.inspectionInProgress).toBe(true);
    expect(status.limitedPhotos).toBe(false);
    expect(status.featuresTableView).toBe(true);
  });
});
