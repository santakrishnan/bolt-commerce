import { beforeEach, describe, expect, it, vi } from "vitest";

describe("vdp-client sync helpers", () => {
  beforeEach(() => {
    vi.resetModules();

    const _store: Record<string, string> = {};
    (global as any).localStorage = {
      getItem: (k: string) => (Object.hasOwn(_store, k) ? _store[k] : null),
      setItem: (k: string, v: string) => {
        _store[k] = String(v);
      },
      removeItem: (k: string) => {
        delete _store[k];
      },
      clear: () => {
        for (const k in _store) {
          if (Object.hasOwn(_store, k)) {
            delete _store[k];
          }
        }
      },
    } as any;
    if (typeof (global as any).window === "undefined") {
      (global as any).window = {};
    }
    (global as any).window.localStorage = (global as any).localStorage;
  });

  it("reads flags from localStorage when scenario present", async () => {
    vi.doMock("../vdp-config", () => ({
      VDP_DEFAULT_FLAGS: {
        "vdp-no-longer-available": false,
        "vdp-history-report-pending": false,
        "vdp-inspection-in-progress": false,
        "vdp-limited-photos": false,
      },
      VDP_DEFAULT_SCENARIO_ID: "none",
      VDP_FLAG_COOKIE_NAME: "vdp-flag-key",
      vdpScenarios: {
        sale: {
          label: "Sale",
          flags: {
            "vdp-no-longer-available": true,
            "vdp-history-report-pending": false,
            "vdp-inspection-in-progress": false,
            "vdp-limited-photos": false,
          },
        },
        none: {
          label: "None",
          flags: {
            "vdp-no-longer-available": false,
            "vdp-history-report-pending": false,
            "vdp-inspection-in-progress": false,
            "vdp-limited-photos": false,
          },
        },
      },
      vdpFlagsToVehicleStatus: (flags: any) => ({
        noLongerAvailable: !!flags["vdp-no-longer-available"],
      }),
    }));

    localStorage.setItem("vdp-flag-key", "sale");
    console.log("DEBUG: localStorage vdp-flag-key =", localStorage.getItem("vdp-flag-key"));

    const mod = await import("../vdp-client");

    const flags = mod.getVdpFlagsSync();
    expect(flags["vdp-no-longer-available"]).toBe(true);

    const single = mod.getVdpFlagSync("vdp-no-longer-available");
    expect(single).toBe(true);

    const vs = mod.getVehicleStatusFromFlagsSync();
    expect(vs.noLongerAvailable).toBe(true);
  });

  it("falls back to default scenario when localStorage missing or unknown", async () => {
    vi.doMock("../vdp-config", () => ({
      VDP_DEFAULT_FLAGS: {
        "vdp-no-longer-available": false,
        "vdp-history-report-pending": false,
        "vdp-inspection-in-progress": false,
        "vdp-limited-photos": false,
      },
      VDP_DEFAULT_SCENARIO_ID: "none",
      VDP_FLAG_COOKIE_NAME: "vdp-flag-key",
      vdpScenarios: {
        none: {
          label: "None",
          flags: {
            "vdp-no-longer-available": false,
            "vdp-history-report-pending": false,
            "vdp-inspection-in-progress": false,
            "vdp-limited-photos": false,
          },
        },
      },
      vdpFlagsToVehicleStatus: (flags: any) => ({
        noLongerAvailable: !!flags["vdp-no-longer-available"],
      }),
    }));

    localStorage.removeItem("vdp-flag-key");

    const mod = await import("../vdp-client");

    const flags = mod.getVdpFlagsSync();
    expect(flags["vdp-no-longer-available"]).toBe(false);
  });

  it("falls back to default scenario when localStorage contains unknown id", async () => {
    vi.doMock("../vdp-config", () => ({
      VDP_DEFAULT_FLAGS: {
        "vdp-no-longer-available": false,
        "vdp-history-report-pending": false,
        "vdp-inspection-in-progress": false,
        "vdp-limited-photos": false,
      },
      VDP_DEFAULT_SCENARIO_ID: "none",
      VDP_FLAG_COOKIE_NAME: "vdp-flag-key",
      vdpScenarios: {
        none: {
          label: "None",
          flags: {
            "vdp-no-longer-available": false,
            "vdp-history-report-pending": false,
            "vdp-inspection-in-progress": false,
            "vdp-limited-photos": false,
          },
        },
      },
      vdpFlagsToVehicleStatus: (flags: any) => ({
        noLongerAvailable: !!flags["vdp-no-longer-available"],
      }),
    }));

    localStorage.setItem("vdp-flag-key", "unknown-scenario");

    const mod = await import("../vdp-client");

    const flags = mod.getVdpFlagsSync();
    expect(flags["vdp-no-longer-available"]).toBe(false);
  });

  it("returns defaults when window is undefined", async () => {
    vi.doMock("../vdp-config", () => ({
      VDP_DEFAULT_FLAGS: {
        "vdp-no-longer-available": false,
        "vdp-history-report-pending": false,
        "vdp-inspection-in-progress": false,
        "vdp-limited-photos": false,
      },
      VDP_DEFAULT_SCENARIO_ID: "none",
      VDP_FLAG_COOKIE_NAME: "vdp-flag-key",
      vdpScenarios: {
        none: {
          label: "None",
          flags: {
            "vdp-no-longer-available": false,
            "vdp-history-report-pending": false,
            "vdp-inspection-in-progress": false,
            "vdp-limited-photos": false,
          },
        },
      },
      vdpFlagsToVehicleStatus: (flags: any) => ({
        noLongerAvailable: !!flags["vdp-no-longer-available"],
      }),
    }));

    const origWindow = (global as any).window;
    try {
      (global as any).window = undefined;

      const mod = await import("../vdp-client");

      const flags = mod.getVdpFlagsSync();
      expect(flags["vdp-no-longer-available"]).toBe(false);
    } finally {
      (global as any).window = origWindow;
    }
  });
});
