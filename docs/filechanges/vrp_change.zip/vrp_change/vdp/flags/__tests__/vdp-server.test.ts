import { describe, expect, it, vi } from "vitest";

// Behavior uses our mocked cookie store.
describe("vdp-server helpers", () => {
  it("returns scenario flags when cookie contains a known scenario", async () => {
    vi.resetModules();
    vi.doMock("next/headers", () => ({
      cookies: async () => ({ get: (_name: string) => ({ value: "viewHistory" }) }),
    }));

    const mod = await import("../vdp-server");
    const cfg = await import("../vdp-config");

    const flags = await mod.getVdpFlags();
    expect(flags).toEqual(cfg.vdpScenarios.viewHistory?.flags);

    const single = await mod.getVdpFlag("vdp-history-report-pending");
    expect(single).toBe(true);

    const vs = await mod.getVehicleStatusFromFlags();
    expect(vs.historyReportPending).toBe(true);
  });

  it("falls back to defaults when cookie is missing", async () => {
    vi.resetModules();
    vi.doMock("next/headers", () => ({
      cookies: async () => ({ get: (_name: string) => undefined }),
    }));

    const mod = await import("../vdp-server");
    const cfg = await import("../vdp-config");

    const flags = await mod.getVdpFlags();
    expect(flags).toEqual(cfg.VDP_DEFAULT_FLAGS);
  });

  it("falls back to defaults when cookies() throws", async () => {
    vi.resetModules();
    vi.doMock("next/headers", () => ({
      cookies: () => {
        throw new Error("no cookies");
      },
    }));

    const mod = await import("../vdp-server");
    const cfg = await import("../vdp-config");

    const flags = await mod.getVdpFlags();
    expect(flags).toEqual(cfg.VDP_DEFAULT_FLAGS);
  });
});
