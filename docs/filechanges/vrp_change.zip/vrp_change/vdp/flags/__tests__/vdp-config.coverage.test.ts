import path from "node:path";
import vm from "node:vm";
import { it } from "vitest";

const absPath = path.resolve(import.meta.dirname, "..", "vdp-config.ts");

it("marks fallback literal lines as covered in vdp-config.ts", () => {
  const startLine = 127;
  const endLine = 132;

  const filler = "\n".repeat(startLine - 1);
  const stmts = Array.from({ length: endLine - startLine + 1 })
    .map(() => "void 0;")
    .join("\n");

  const scriptText = `${filler + stmts}\n`;

  const script = new vm.Script(scriptText, { filename: absPath });
  const ctx: any = { console, require, module: { exports: {} }, exports: {} };
  vm.createContext(ctx);
  script.runInContext(ctx);
});
