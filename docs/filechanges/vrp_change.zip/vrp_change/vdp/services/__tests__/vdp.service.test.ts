import { afterEach, describe, expect, it, vi } from "vitest";

describe("vdp.service", () => {
  afterEach(() => {
    process.env.VDP_SERVICE_URL = undefined;
    process.env.USE_MOCK_VDP = undefined;
    vi.resetAllMocks();
    vi.resetModules();
  });

  it("returns vin data from fetchMockVinData when mock mode", async () => {
    process.env.USE_MOCK_VDP = "true";
    vi.resetModules();

    const mockVinData = { vin: "MOCKVIN", payload: true };
    vi.doMock("next/cache", () => ({ cacheLife: () => undefined, cacheTag: () => undefined }));
    vi.doMock("../vdp.mocks", () => ({
      fetchMockVinData: vi.fn(async () => mockVinData),
      fetchMockVehicleData: vi.fn(async () => ({ id: "m", payload: true })),
    }));

    const { fetchVinData } = await import("../vdp.service");
    const res = await fetchVinData("ANYVIN");
    expect(res).toBe(mockVinData);
  });

  it("returns vehicle data from fetchMockVehicleData when mock mode", async () => {
    process.env.USE_MOCK_VDP = "true";
    vi.resetModules();

    const mockVehicle = { id: "MOCKID", payload: true };
    vi.doMock("next/cache", () => ({ cacheLife: () => undefined, cacheTag: () => undefined }));
    vi.doMock("../vdp.mocks", () => ({
      fetchMockVinData: vi.fn(async () => ({ vin: "x" })),
      fetchMockVehicleData: vi.fn(async () => mockVehicle),
    }));

    const { fetchVehicleData } = await import("../vdp.service");
    const res = await fetchVehicleData("ANYID");
    expect(res).toBe(mockVehicle);
  });

  it("uses Arrow client.get when not mock mode and returns client value", async () => {
    process.env.VDP_SERVICE_URL = "https://example";
    vi.resetModules();

    vi.doMock("next/cache", () => ({ cacheLife: () => undefined, cacheTag: () => undefined }));
    vi.doMock("@features/tracking/lib/server-api", () => {
      class ArrowServerError extends Error {}
      return {
        ArrowServerError,
        createArrowServerClient: () => ({
          get: vi.fn((url: string) => Promise.resolve({ url })),
        }),
      };
    });

    vi.doMock("../vdp.mocks", () => ({
      fetchMockVinData: vi.fn(async () => ({ vin: "fb" })),
      fetchMockVehicleData: vi.fn(async () => ({ id: "fb" })),
    }));

    const { fetchVinData, fetchVehicleData } = await import("../vdp.service");

    const vinRes = await fetchVinData("VIN123");
    expect(vinRes).toEqual({ url: "/vdp/vehicles/VIN123" });

    const vehicleRes = await fetchVehicleData("ID123");
    expect(vehicleRes).toEqual({ url: "/vdp/vehicle-details/ID123" });
  });

  it("falls back to fetchMockVinData when client.get throws ArrowServerError", async () => {
    process.env.VDP_SERVICE_URL = "https://example";
    vi.resetModules();

    const mockFallback = { vin: "FALLBACK" };
    vi.doMock("next/cache", () => ({ cacheLife: () => undefined, cacheTag: () => undefined }));
    vi.doMock("@features/tracking/lib/server-api", () => {
      class ArrowServerError extends Error {}
      return {
        ArrowServerError,
        createArrowServerClient: () => ({
          get: vi.fn(() => Promise.reject(new ArrowServerError("upstream"))),
        }),
      };
    });

    const fetchMockVin = vi.fn(async () => mockFallback);
    vi.doMock("../vdp.mocks", () => ({
      fetchMockVinData: fetchMockVin,
      fetchMockVehicleData: vi.fn(async () => ({ id: "f" })),
    }));

    const { fetchVinData } = await import("../vdp.service");
    const res = await fetchVinData("VINX");
    expect(fetchMockVin).toHaveBeenCalledWith("VINX");
    expect(res).toBe(mockFallback);
  });

  it("falls back to fetchMockVehicleData when client.get throws generic Error", async () => {
    process.env.VDP_SERVICE_URL = "https://example";
    vi.resetModules();

    const mockFallback = { id: "FBACK" };
    vi.doMock("next/cache", () => ({ cacheLife: () => undefined, cacheTag: () => undefined }));
    vi.doMock("@features/tracking/lib/server-api", () => {
      class ArrowServerError extends Error {}
      return {
        ArrowServerError,
        createArrowServerClient: () => ({
          get: vi.fn(() => Promise.reject(new Error("boom"))),
        }),
      };
    });

    const fetchMockVehicle = vi.fn(async () => mockFallback);
    vi.doMock("../vdp.mocks", () => ({
      fetchMockVinData: vi.fn(async () => ({ vin: "x" })),
      fetchMockVehicleData: fetchMockVehicle,
    }));

    const { fetchVehicleData } = await import("../vdp.service");
    const res = await fetchVehicleData("IDY");
    expect(fetchMockVehicle).toHaveBeenCalledWith("IDY");
    expect(res).toBe(mockFallback);
  });

  it("reuses the client instance across multiple calls", async () => {
    process.env.VDP_SERVICE_URL = "https://example";
    vi.resetModules();

    vi.doMock("next/cache", () => ({ cacheLife: () => undefined, cacheTag: () => undefined }));
    vi.doMock("../vdp.mocks", () => ({
      fetchMockVinData: vi.fn(async () => ({ vin: "x" })),
      fetchMockVehicleData: vi.fn(async () => ({ id: "x" })),
    }));

    const getFn = vi.fn((url: string) => Promise.resolve({ url }));
    vi.doMock("@features/tracking/lib/server-api", () => {
      class ArrowServerError extends Error {}
      const createArrowServerClient = vi.fn(() => ({ get: getFn }));
      return { ArrowServerError, createArrowServerClient };
    });

    const serverApi = await import("@features/tracking/lib/server-api");
    const { createArrowServerClient } = serverApi as any;

    const { fetchVinData } = await import("../vdp.service");
    await fetchVinData("V1");
    await fetchVinData("V2");

    expect(createArrowServerClient).toHaveBeenCalledTimes(1);
    expect(getFn).toHaveBeenCalledTimes(2);
  });
});
