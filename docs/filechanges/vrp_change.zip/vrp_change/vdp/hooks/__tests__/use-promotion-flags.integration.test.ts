import { renderHook, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { type UsePromotionFlagsResult, usePromotionFlags } from "../use-promotion-flags";

vi.mock("@config/flags/config", () => ({
  FLAG_COOKIE_NAME: "vdp-mock-user",
  mockUsers: {
    authenticated: { isAuthenticated: true },
    unauthenticated: { isAuthenticated: false },
    cardTest: { isAuthenticated: true },
  },
}));

vi.mock("@features/tracking/context/arrow-provider", () => ({
  useArrow: vi.fn(() => ({
    visitorProfile: {
      isKnown: false,
    },
    isProfileLoading: false,
  })),
}));

vi.mock("@features/vdp/components/promotion-registry", () => ({
  CARD_TEST_FLAG_VALUE: "cardTest",
  ENABLE_FLAG_OVERRIDES: true,
}));

vi.mock("@shared/lib/cookie-cache", () => ({
  getCookie: vi.fn(() => null),
}));

describe("usePromotionFlags Hook Implementation", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should return default context structure", () => {
    const { result } = renderHook(() => usePromotionFlags());

    expect(result.current).toBeDefined();
    expect(result.current).toHaveProperty("context");
    expect(result.current).toHaveProperty("isLoading");
  });

  it("should return UsePromotionFlagsResult type", () => {
    const { result } = renderHook(() => usePromotionFlags());

    const typedResult: UsePromotionFlagsResult = result.current;
    expect(typedResult.context).toBeDefined();
    expect(typeof typedResult.isLoading).toBe("boolean");
  });

  it("should handle default values when no visitor profile", async () => {
    const { result } = renderHook(() => usePromotionFlags());

    await waitFor(() => {
      expect(result.current.context).toBeDefined();
    });
  });

  it("should include isAuthenticated flag in context", async () => {
    const { result } = renderHook(() => usePromotionFlags());

    await waitFor(() => {
      expect(result.current.context).toHaveProperty("isAuthenticated");
    });
  });

  it("should include isCardTestEnabled flag in context", async () => {
    const { result } = renderHook(() => usePromotionFlags());

    await waitFor(() => {
      expect(result.current.context).toHaveProperty("isCardTestEnabled");
    });
  });

  it("should return proper loading state", () => {
    const { result } = renderHook(() => usePromotionFlags());

    expect(typeof result.current.isLoading).toBe("boolean");
  });

  it("should memoize results appropriately", () => {
    const { result, rerender } = renderHook(() => usePromotionFlags());

    const firstContext = result.current.context;

    rerender();

    const secondContext = result.current.context;

    expect(firstContext).toBeDefined();
    expect(secondContext).toBeDefined();
  });

  it("should use effect to sync cookie state", async () => {
    const { getCookie } = await vi.importMock<typeof import("@shared/lib/cookie-cache")>(
      "@shared/lib/cookie-cache"
    );

    vi.mocked(getCookie).mockReturnValueOnce("authenticated");

    const { result } = renderHook(() => usePromotionFlags());

    await waitFor(() => {
      expect(result.current).toBeDefined();
    });
  });

  it("should handle flag overrides when enabled", async () => {
    const { useArrow } = await vi.importMock<
      typeof import("@features/tracking/context/arrow-provider")
    >("@features/tracking/context/arrow-provider");

    vi.mocked(useArrow).mockReturnValueOnce({
      visitorProfile: {
        isKnown: false,
      },
      isProfileLoading: false,
    } as any);

    const { result } = renderHook(() => usePromotionFlags());

    expect(result.current.context).toBeDefined();
  });
});
