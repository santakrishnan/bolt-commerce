import { renderHook, waitFor } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

describe("usePromotionFlags — branch coverage extras", () => {
  it("applies cookie override when mock user exists and equals CARD_TEST_FLAG_VALUE", async () => {
    vi.resetModules();

    vi.doMock("@config/flags/config", () => ({
      FLAG_COOKIE_NAME: "vdp-mock-user",
      mockUsers: { cardTest: { isAuthenticated: true } },
    }));

    vi.doMock("@features/tracking/context/arrow-provider", () => ({
      useArrow: () => ({ visitorProfile: { isKnown: false }, isProfileLoading: false }),
    }));

    vi.doMock("@features/vdp/components/promotion-registry", () => ({
      CARD_TEST_FLAG_VALUE: "cardTest",
      ENABLE_FLAG_OVERRIDES: true,
    }));

    vi.doMock("@shared/lib/cookie-cache", () => ({
      getCookie: () => "cardTest",
    }));

    const { usePromotionFlags } = await import("../use-promotion-flags");

    const { result } = renderHook(() => usePromotionFlags());

    await waitFor(() => {
      expect(result.current.context.isCardTestEnabled).toBe(true);
      expect(result.current.context.isAuthenticated).toBe(true);
    });
  });

  it("does not apply cookie override when ENABLE_FLAG_OVERRIDES is false", async () => {
    vi.resetModules();

    vi.doMock("@config/flags/config", () => ({
      FLAG_COOKIE_NAME: "vdp-mock-user",
      mockUsers: { cardTest: { isAuthenticated: false } },
    }));

    vi.doMock("@features/tracking/context/arrow-provider", () => ({
      useArrow: () => ({ visitorProfile: { isKnown: true }, isProfileLoading: false }),
    }));

    vi.doMock("@features/vdp/components/promotion-registry", () => ({
      CARD_TEST_FLAG_VALUE: "cardTest",
      ENABLE_FLAG_OVERRIDES: false,
    }));

    vi.doMock("@shared/lib/cookie-cache", () => ({
      getCookie: () => "cardTest",
    }));

    const { usePromotionFlags } = await import("../use-promotion-flags");

    const { result } = renderHook(() => usePromotionFlags());

    await waitFor(() => {
      expect(result.current.context.isCardTestEnabled).toBe(false);

      expect(result.current.context.isAuthenticated).toBe(true);
    });
  });

  it("handles ENABLE_FLAG_OVERRIDES true but no mockUserKey present (cookie missing)", async () => {
    vi.resetModules();

    vi.doMock("@config/flags/config", () => ({
      FLAG_COOKIE_NAME: "vdp-mock-user",
      mockUsers: {},
    }));

    vi.doMock("@features/tracking/context/arrow-provider", () => ({
      useArrow: () => ({ visitorProfile: { isKnown: false }, isProfileLoading: false }),
    }));

    vi.doMock("@features/vdp/components/promotion-registry", () => ({
      CARD_TEST_FLAG_VALUE: "cardTest",
      ENABLE_FLAG_OVERRIDES: true,
    }));

    vi.doMock("@shared/lib/cookie-cache", () => ({
      getCookie: () => null,
    }));

    const { usePromotionFlags } = await import("../use-promotion-flags");

    const { result } = renderHook(() => usePromotionFlags());

    await waitFor(() => {
      expect(result.current.context.isCardTestEnabled).toBe(false);
      expect(result.current.context.isAuthenticated).toBe(false);
    });
  });

  it("handles mockUserKey present but mockUser missing (no matching mockUsers entry)", async () => {
    vi.resetModules();

    vi.doMock("@config/flags/config", () => ({
      FLAG_COOKIE_NAME: "vdp-mock-user",
      mockUsers: {
        /* no matching entry for 'unknown' */
      },
    }));

    vi.doMock("@features/tracking/context/arrow-provider", () => ({
      useArrow: () => ({ visitorProfile: { isKnown: false }, isProfileLoading: false }),
    }));

    vi.doMock("@features/vdp/components/promotion-registry", () => ({
      CARD_TEST_FLAG_VALUE: "cardTest",
      ENABLE_FLAG_OVERRIDES: true,
    }));

    vi.doMock("@shared/lib/cookie-cache", () => ({
      getCookie: () => "unknown",
    }));

    const { usePromotionFlags } = await import("../use-promotion-flags");

    const { result } = renderHook(() => usePromotionFlags());

    await waitFor(() => {
      expect(result.current.context.isCardTestEnabled).toBe(false);
      expect(result.current.context.isAuthenticated).toBe(false);
    });
  });

  it("respects visitorProfile when overrides enabled but cookie absent", async () => {
    vi.resetModules();

    vi.doMock("@config/flags/config", () => ({
      FLAG_COOKIE_NAME: "vdp-mock-user",
      mockUsers: {},
    }));

    vi.doMock("@features/tracking/context/arrow-provider", () => ({
      useArrow: () => ({ visitorProfile: { isKnown: true }, isProfileLoading: false }),
    }));

    vi.doMock("@features/vdp/components/promotion-registry", () => ({
      CARD_TEST_FLAG_VALUE: "cardTest",
      ENABLE_FLAG_OVERRIDES: true,
    }));

    vi.doMock("@shared/lib/cookie-cache", () => ({
      getCookie: () => null,
    }));

    const { usePromotionFlags } = await import("../use-promotion-flags");

    const { result } = renderHook(() => usePromotionFlags());

    await waitFor(() => {
      expect(result.current.context.isCardTestEnabled).toBe(false);
      expect(result.current.context.isAuthenticated).toBe(true);
    });
  });

  it("defaults mockUser.isAuthenticated to false when missing (nullish coalescing)", async () => {
    vi.resetModules();

    vi.doMock("@config/flags/config", () => ({
      FLAG_COOKIE_NAME: "vdp-mock-user",
      mockUsers: { cardTest: {} },
    }));

    vi.doMock("@features/tracking/context/arrow-provider", () => ({
      useArrow: () => ({ visitorProfile: { isKnown: false }, isProfileLoading: false }),
    }));

    vi.doMock("@features/vdp/components/promotion-registry", () => ({
      CARD_TEST_FLAG_VALUE: "cardTest",
      ENABLE_FLAG_OVERRIDES: true,
    }));

    vi.doMock("@shared/lib/cookie-cache", () => ({
      getCookie: () => "cardTest",
    }));

    const { usePromotionFlags } = await import("../use-promotion-flags");

    const { result } = renderHook(() => usePromotionFlags());

    await waitFor(() => {
      expect(result.current.context.isCardTestEnabled).toBe(true);
      expect(result.current.context.isAuthenticated).toBe(false);
    });
  });
});
