import { act, renderHook, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { useStickyScroll } from "../use-sticky-scroll";

describe("useStickyScroll", () => {
  beforeEach(() => {
    document.body.innerHTML = "";
    (window as any).scrollY = 0;
    vi.restoreAllMocks();
  });

  function makeTarget(top: number, offsetParentNotNull = true) {
    const el = document.createElement("div");
    Object.defineProperty(el, "offsetParent", {
      get: () => (offsetParentNotNull ? document.body : null),
    });
    (el as any).getBoundingClientRect = () => ({
      top,
      left: 0,
      right: 0,
      bottom: 0,
      width: 0,
      height: 0,
      x: 0,
      y: 0,
    });
    document.body.appendChild(el);
    return el;
  }

  function makeHeader(height: number) {
    const header = document.createElement("header");
    (header as any).getBoundingClientRect = () => ({ height });
    document.body.appendChild(header);
    return header;
  }

  it("toggles banner display and updates style on scroll down and up", async () => {
    const desktop = makeTarget(200, true);
    const mobile = makeTarget(200, false);
    makeHeader(80);

    const { result } = renderHook(() => useStickyScroll({ current: desktop }, { current: mobile }));

    const bannerEl = document.createElement("div");
    bannerEl.style.opacity = "";
    bannerEl.style.transform = "";
    bannerEl.style.display = "";

    act(() => {
      result.current.bannerRef.current = bannerEl;
    });

    (window as any).scrollY = 0;
    act(() => window.dispatchEvent(new Event("scroll")));

    await waitFor(() => {
      expect(bannerEl.style.display === "" || bannerEl.style.display === "none").toBe(true);
    });

    (desktop as any).getBoundingClientRect = () => ({ top: 10 });
    (window as any).scrollY = 100;
    act(() => window.dispatchEvent(new Event("scroll")));

    await waitFor(() => {
      expect(bannerEl.style.display).toBe("block");
      const opacity = Number.parseFloat(bannerEl.style.opacity || "0");
      expect(opacity).toBeGreaterThan(0);
      expect(bannerEl.style.transform).toContain("translateY(");
    });

    (window as any).scrollY = 50;
    act(() => window.dispatchEvent(new Event("scroll")));

    await waitFor(() => {
      expect(bannerEl.style.transform).toBe("translateY(0px)");
    });
  });

  it("uses mobile target when desktop offsetParent is null and header missing", async () => {
    document.body.innerHTML = "";
    const desktop = makeTarget(200, false);
    const mobile = makeTarget(10, true);

    const { result } = renderHook(() => useStickyScroll({ current: desktop }, { current: mobile }));

    const bannerEl = document.createElement("div");
    bannerEl.style.opacity = "";
    bannerEl.style.transform = "";
    bannerEl.style.display = "";

    act(() => {
      result.current.bannerRef.current = bannerEl;
    });

    (window as any).scrollY = 0;
    act(() => window.dispatchEvent(new Event("scroll")));

    (window as any).scrollY = 60;
    act(() => window.dispatchEvent(new Event("scroll")));

    (window as any).scrollY = 20;
    act(() => window.dispatchEvent(new Event("scroll")));

    await waitFor(() => {
      expect(bannerEl.style.display).toBe("block");
      expect(Number.parseFloat(bannerEl.style.opacity || "0")).toBeGreaterThanOrEqual(0);
    });
  });

  it("handles missing bannerRef gracefully (no throw)", async () => {
    document.body.innerHTML = "";
    const desktop = makeTarget(10, true);
    const mobile = makeTarget(200, false);

    const { result } = renderHook(() => useStickyScroll({ current: desktop }, { current: mobile }));

    act(() => {
      result.current.bannerRef.current = null as any;
    });

    (window as any).scrollY = 10;
    // should not throw
    act(() => window.dispatchEvent(new Event("scroll")));

    await waitFor(() => {
      expect(true).toBe(true);
    });
  });

  it("returns early when no target elements are provided", async () => {
    document.body.innerHTML = "";

    renderHook(() => useStickyScroll({ current: null }, { current: null }));

    act(() => window.dispatchEvent(new Event("scroll")));

    await waitFor(() => {
      expect(true).toBe(true);
    });
  });
});
