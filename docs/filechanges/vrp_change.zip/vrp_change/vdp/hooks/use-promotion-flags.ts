"use client";

import { FLAG_COOKIE_NAME, mockUsers } from "@config/flags/config";
import { useArrow } from "@features/tracking/context/arrow-provider";
import {
  CARD_TEST_FLAG_VALUE,
  ENABLE_FLAG_OVERRIDES,
  type PromotionContext,
} from "@features/vdp/components/promotion-registry";
import { getCookie } from "@shared/lib/cookie-cache";
import { useEffect, useMemo, useState } from "react";

export interface UsePromotionFlagsResult {
  /** Context for guard evaluation and card variant selection. */
  context: PromotionContext;
  /** True while the visitor profile is still loading. */
  isLoading: boolean;
}

// Resolves promotion card context from visitor profile, with optional mock-user cookie overrides (client-only, uses useEffect for hydration).
export function usePromotionFlags(): UsePromotionFlagsResult {
  const { visitorProfile, isProfileLoading } = useArrow();

  // Sync the mock-user cookie into React state so it survives hydration.
  const [mockUserKey, setMockUserKey] = useState<string | null>(null);

  useEffect(() => {
    if (ENABLE_FLAG_OVERRIDES) {
      setMockUserKey(getCookie(FLAG_COOKIE_NAME));
    }
  }, []);

  return useMemo(() => {
    let isAuthenticated = visitorProfile?.isKnown ?? false;
    let isCardTestEnabled = false;

    // Cookie-based overrides (dev/QA, controlled by toggle)
    if (ENABLE_FLAG_OVERRIDES && mockUserKey) {
      const mockUser = mockUsers[mockUserKey];
      if (mockUser) {
        isAuthenticated = mockUser.isAuthenticated ?? false;
      }
      isCardTestEnabled = mockUserKey === CARD_TEST_FLAG_VALUE;
    }

    return {
      context: { isAuthenticated, isCardTestEnabled },
      isLoading: isProfileLoading,
    };
  }, [visitorProfile, isProfileLoading, mockUserKey]);
}
