import { describe, expect, it } from "vitest";
import { filterSections } from "../filter-sections";

function parseCurrency(value: string): number {
  return Number(value.replace(/[^0-9.-]+/g, ""));
}

describe("filterSections constant", () => {
  it("exports the expected top-level sections and placeholders", () => {
    expect(filterSections).toBeDefined();
    expect(typeof filterSections.makeModelSearchPlaceholder).toBe("string");
    expect(Array.isArray(filterSections.navItems)).toBe(true);
    expect(filterSections.navItems.length).toBeGreaterThan(0);
  });

  it("price: min <= max and dropdown values are parseable and within range", () => {
    const p = filterSections.price;
    expect(typeof p.min).toBe("number");
    expect(typeof p.max).toBe("number");
    expect(p.min).toBeLessThanOrEqual(p.max);

    const mins = p.minDropdown.map(parseCurrency);
    const maxs = p.maxDropdown.map(parseCurrency);
    expect(mins.every((n) => !Number.isNaN(n))).toBe(true);
    expect(maxs.every((n) => !Number.isNaN(n))).toBe(true);

    // All dropdown values should fall within the declared min/max envelope
    for (const n of [...mins, ...maxs]) {
      expect(n).toBeGreaterThanOrEqual(p.min - 1); // allow tiny tolerance
      expect(n).toBeLessThanOrEqual(p.max + 1);
    }
  });

  it("year: options ordering and range consistency", () => {
    const y = filterSections.year;
    expect(y.fromOptions.length).toBeGreaterThan(0);
    expect(y.toOptions.length).toBeGreaterThan(0);

    // fromOptions should be ascending — compare to a sorted copy
    const from = y.fromOptions as number[];
    expect(from).toEqual([...from].sort((a, b) => a - b));

    // toOptions should be descending — compare to a sorted (desc) copy
    const to = y.toOptions as number[];
    expect(to).toEqual([...to].sort((a, b) => b - a));

    expect(y.min).toBeLessThanOrEqual(y.max);
    expect(y.fromOptions[0]).toBeGreaterThanOrEqual(y.min);
    expect(y.toOptions[0]).toBeLessThanOrEqual(y.max);
  });

  it("mileage: ranges and quick filters present", () => {
    const m = filterSections.mileage;
    expect(typeof m.min).toBe("number");
    expect(typeof m.max).toBe("number");
    expect(m.min).toBeLessThanOrEqual(m.max);
    expect(Array.isArray(m.quickFilters)).toBe(true);
    expect(m.quickFilters.length).toBeGreaterThan(0);
  });

  it("several categorical sections are non-empty arrays", () => {
    const mustHave = [
      "bodyStyle",
      "popularModels",
      "fuelTypes",
      "safetyFeatures",
      "techFeatures",
      "transmissions",
    ] as const;

    for (const key of mustHave) {
      // @ts-expect-error - runtime check of known keys
      const arr = filterSections[key];
      expect(Array.isArray(arr)).toBe(true);
      expect(arr.length).toBeGreaterThan(0);
    }
  });

  it("navItems contains expected labels used in UI navigation", () => {
    const nav = filterSections.navItems.map((s) => s.toLowerCase());
    expect(nav).toContain("price");
    expect(nav).toContain("year");
    expect(nav).toContain("mileage");
  });
});
