import { act, render } from "@testing-library/react";
import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// Provide deterministic route + header constants used by the hook
vi.mock("@config/routes/constants", () => ({ API_ROUTES: { SEARCH: "/api/search" } }));
vi.mock("@features/tracking/constants", () => ({
  ARROW_HEADER: { SESSION_ID: "x-session", FP_ID: "x-fp", PROFILE_ID: "x-profile" },
}));

import { type UseSearchOptions, useSearch } from "../use-search";

// Hook host helper to expose return value
function HookHost({
  options,
  onReady,
}: {
  options?: UseSearchOptions;
  onReady: (api: any) => void;
}) {
  const api = useSearch(options);
  React.useEffect(() => {
    onReady(api);
  }, [api, onReady]);
  return null;
}

let fetchMock: any;
let originalAbort: any;

beforeEach(() => {
  fetchMock = vi.fn();
  (global as any).fetch = fetchMock;

  // Simple AbortController mock so tests can assert abort called and signal.aborted toggles
  originalAbort = (global as any).AbortController;
  (global as any).AbortController = class {
    signal: any;
    abort: any;
    constructor() {
      this.signal = { aborted: false };
      this.abort = vi.fn(() => {
        this.signal.aborted = true;
      });
    }
  } as any;
});

afterEach(() => {
  vi.restoreAllMocks();
  (global as any).AbortController = originalAbort;
});

describe("useSearch hook", () => {
  it("builds query params and sends headers, updating state on success", async () => {
    const mockData = { vehicles: [{ id: "v1" }], pagination: { page: 1, total: 1 } };
    fetchMock.mockResolvedValueOnce({ ok: true, json: async () => mockData });

    let api: any;
    render(
      React.createElement(HookHost, {
        options: { sessionId: "S1", fingerprintId: "F1", profileId: "P1" },
        onReady: (a: any) => (api = a),
      })
    );

    await act(async () => {
      await api.search({
        query: "toyota",
        pageSize: 20,
        priceMin: 0,
        bodyStyles: ["suv"],
        makes: ["toyota"],
      });
    });

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const calledUrl: string = fetchMock.mock.calls[0][0];
    expect(calledUrl).toContain("/api/search?");
    expect(calledUrl).toContain("query=toyota");
    expect(calledUrl).toContain("pageSize=20");
    expect(calledUrl).toContain("priceMin=0");
    expect(calledUrl).toContain("bodyStyles=suv");
    expect(calledUrl).toContain("makes=toyota");

    const fetchOptions = fetchMock.mock.calls[0][1];
    expect(fetchOptions.method).toBe("GET");
    expect(fetchOptions.credentials).toBe("include");
    expect(fetchOptions.headers["x-session"]).toBe("S1");
    expect(fetchOptions.headers["x-fp"]).toBe("F1");
    expect(fetchOptions.headers["x-profile"]).toBe("P1");

    expect(api.vehicles).toEqual(mockData.vehicles);
    expect(api.pagination).toEqual(mockData.pagination);
    expect(api.isLoading).toBe(false);
    expect(api.error).toBeNull();
  });

  it("merges query with state and defaults page to 1 on search", async () => {
    const mockData = { vehicles: [], pagination: { page: 1, total: 0 } };
    fetchMock.mockResolvedValue({ ok: true, json: async () => mockData });

    let api: any;
    render(
      React.createElement(HookHost, {
        options: { initialQuery: { query: "honda", page: 5 } },
        onReady: (a: any) => (api = a),
      })
    );

    await act(async () => {
      await api.search({ sortBy: "price" });
    });

    const calledUrl: string = fetchMock.mock.calls[0][0];
    expect(calledUrl).toContain("query=honda");
    // search merges and resets page to 1 unless provided
    expect(calledUrl).toContain("page=1");
    expect(calledUrl).toContain("sortBy=price");
  });

  it("setPage triggers a search preserving other query params", async () => {
    const mockData = { vehicles: [], pagination: { page: 2, total: 0 } };
    fetchMock.mockResolvedValue({ ok: true, json: async () => mockData });

    let api: any;
    render(
      React.createElement(HookHost, {
        options: { initialQuery: { query: "ford" } },
        onReady: (a: any) => (api = a),
      })
    );

    await act(async () => {
      await api.setPage(2);
    });

    const calledUrl: string = fetchMock.mock.calls[0][0];
    expect(calledUrl).toContain("query=ford");
    expect(calledUrl).toContain("page=2");
    expect(api.pagination.page).toBe(2);
  });

  it("sets error when response is not ok", async () => {
    fetchMock.mockResolvedValue({ ok: false, status: 500, statusText: "Bad" });

    let api: any;
    render(React.createElement(HookHost, { onReady: (a: any) => (api = a) }));

    await act(async () => {
      await api.search({ query: "x" });
    });

    expect(api.error).toBeInstanceOf(Error);
    expect(api.error?.message).toContain("Search failed: 500 Bad");
    expect(api.isLoading).toBe(false);
  });

  it("captures thrown errors (network) and sets error state", async () => {
    fetchMock.mockRejectedValue(new Error("network"));

    let api: any;
    render(React.createElement(HookHost, { onReady: (a: any) => (api = a) }));

    await act(async () => {
      await api.search({ query: "y" });
    });

    expect(api.error).toBeInstanceOf(Error);
    expect(api.error?.message).toBe("network");
    expect(api.isLoading).toBe(false);
  });

  it("abort controller is used and reset calls abort and clears state", async () => {
    // Make fetch hang so we can call reset while request is in-flight
    let rejectFetch: any;
    fetchMock.mockImplementation(() => new Promise((_res, rej) => (rejectFetch = rej)));

    let api: any;
    render(
      React.createElement(HookHost, {
        options: { initialQuery: { query: "z" } },
        onReady: (a: any) => (api = a),
      })
    );

    // start search (won't resolve)
    act(() => {
      api.search({ query: "z" });
    });

    // AbortController instance created should have abort called when reset invoked
    // We can't access the controller directly, but our mock sets abort as a spy on the instance
    await act(() => {
      api.reset();
    });

    // Verify fetch started
    expect(fetchMock).toHaveBeenCalled();

    // Ensure state is cleared to initial values
    expect(api.vehicles).toEqual([]);
    expect(api.pagination).toBeNull();
    expect(api.error).toBeNull();
    expect(api.isLoading).toBe(false);

    // reject pending fetch to exercise early-return on aborted signal
    rejectFetch(new Error("aborted"));
  });
});
