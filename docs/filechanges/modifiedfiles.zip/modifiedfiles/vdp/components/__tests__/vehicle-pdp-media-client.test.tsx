import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { VehiclePdpMediaClient } from "../vehicle-pdp-media-client";

vi.mock("../image-preview-modal", () => ({
  ImagePreviewModal: ({ isOpen, onClose }: any) => (
    <div data-open={isOpen} data-testid="image-preview-modal">
      {isOpen && (
        <button onClick={onClose} type="button">
          Close Preview
        </button>
      )}
    </div>
  ),
}));

vi.mock("../image-thumbnail-carousal", () => ({
  ImageCarousel: ({
    images,
    onImageClick,
    onImageIndexChange,
    getThumbnailButtonClassName,
  }: any) => (
    <div data-testid="image-carousel">
      {images.map((_img: any, idx: any) => {
        // exercise thumbnail class fn if provided (active for first, inactive for others)
        if (typeof getThumbnailButtonClassName === "function") {
          getThumbnailButtonClassName(idx === 0);
        }
        return (
          <button
            key={_img ?? `image-${idx}`}
            onClick={() => {
              onImageIndexChange?.(idx);
              onImageClick?.();
            }}
            type="button"
          >
            Image {idx + 1}
          </button>
        );
      })}
    </div>
  ),
}));

describe("VehiclePdpMediaClient", () => {
  const mockImages = [
    "https://example.com/img1.jpg",
    "https://example.com/img2.jpg",
    "https://example.com/img3.jpg",
  ];

  it("renders image carousel", () => {
    render(<VehiclePdpMediaClient images={mockImages} regionId="region-1" title="Test Vehicle" />);

    expect(screen.getByTestId("image-carousel")).toBeInTheDocument();
  });

  it("renders image preview modal", () => {
    render(<VehiclePdpMediaClient images={mockImages} regionId="region-1" title="Test Vehicle" />);

    expect(screen.getByTestId("image-preview-modal")).toBeInTheDocument();
  });

  it("opens preview when image is clicked", async () => {
    const user = userEvent.setup();
    render(<VehiclePdpMediaClient images={mockImages} regionId="region-1" title="Test Vehicle" />);

    const imageButton = screen.getByText("Image 1");
    await user.click(imageButton);

    const previewModal = screen.getByTestId("image-preview-modal");
    expect(previewModal).toHaveAttribute("data-open", "true");
  });

  it("closes preview modal", async () => {
    const user = userEvent.setup();
    render(<VehiclePdpMediaClient images={mockImages} regionId="region-1" title="Test Vehicle" />);

    const imageButton = screen.getByText("Image 1");
    await user.click(imageButton);

    const closeButton = screen.getByText("Close Preview");
    await user.click(closeButton);

    const previewModal = screen.getByTestId("image-preview-modal");
    expect(previewModal).toHaveAttribute("data-open", "false");
  });

  it("renders all images", () => {
    render(<VehiclePdpMediaClient images={mockImages} regionId="region-1" title="Test Vehicle" />);

    expect(screen.getByText("Image 1")).toBeInTheDocument();
    expect(screen.getByText("Image 2")).toBeInTheDocument();
    expect(screen.getByText("Image 3")).toBeInTheDocument();
  });

  it("tracks current image index", async () => {
    const user = userEvent.setup();
    render(<VehiclePdpMediaClient images={mockImages} regionId="region-1" title="Test Vehicle" />);

    const secondImageButton = screen.getByText("Image 2");
    await user.click(secondImageButton);

    expect(screen.getByTestId("image-carousel")).toBeInTheDocument();
  });

  it("handles single image", () => {
    render(
      <VehiclePdpMediaClient
        images={["https://example.com/single.jpg"]}
        regionId="region-1"
        title="Test Vehicle"
      />
    );

    expect(screen.getByText("Image 1")).toBeInTheDocument();
  });

  it("handles title in preview modal", () => {
    render(
      <VehiclePdpMediaClient images={mockImages} regionId="region-1" title="My Custom Vehicle" />
    );

    expect(screen.getByTestId("image-preview-modal")).toBeInTheDocument();
  });

  it("uses default title when not provided", () => {
    render(<VehiclePdpMediaClient images={mockImages} regionId="region-1" />);

    expect(screen.getByTestId("image-preview-modal")).toBeInTheDocument();
  });

  it("handles large number of images", () => {
    const manyImages = Array.from({ length: 10 }, (_, i) => `https://example.com/img${i}.jpg`);

    render(<VehiclePdpMediaClient images={manyImages} regionId="region-1" title="Test Vehicle" />);

    expect(screen.getByText("Image 1")).toBeInTheDocument();
    expect(screen.getByText("Image 10")).toBeInTheDocument();
  });

  it("syncs preview index with carousel index", async () => {
    const user = userEvent.setup();
    render(<VehiclePdpMediaClient images={mockImages} regionId="region-1" title="Test Vehicle" />);

    const thirdImageButton = screen.getByText("Image 3");
    await user.click(thirdImageButton);

    const previewModal = screen.getByTestId("image-preview-modal");
    expect(previewModal).toHaveAttribute("data-open", "true");
  });

  it("passes correct region id", () => {
    const { container } = render(
      <VehiclePdpMediaClient images={mockImages} regionId="custom-region-id" title="Test" />
    );

    expect(container).toBeInTheDocument();
  });
});
