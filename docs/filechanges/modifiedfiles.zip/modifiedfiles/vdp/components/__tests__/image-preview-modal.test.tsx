import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import React from "react";
import { afterEach, expect, test, vi } from "vitest";
import { ImagePreviewModal } from "../image-preview-modal";

// Mock the UI primitives to avoid testing shadcn internals
const PREVIEW_REGEX = /Preview image (\d+)/;

vi.mock("@tfs-ucmp/ui", async () => {
  const React = await import("react");
  let lastApi: any = null;
  let lastSetApi: any = null;

  function createApi() {
    const listeners: Record<string, (...args: unknown[]) => unknown> = {};
    const api: any = {
      _selected: 0,
      scrollTo: vi.fn((i: number) => {
        api._selected = i;
      }),
      scrollPrev: vi.fn(() => {
        api._selected = Math.max(0, (api._selected ?? 0) - 1);
      }),
      scrollNext: vi.fn(() => {
        api._selected = Math.min(10, (api._selected ?? 0) + 1);
      }),
      on: (e: string, cb: (...args: unknown[]) => unknown) => {
        listeners[e] = cb;
      },
      off: (e: string) => {
        delete listeners[e];
      },
      selectedScrollSnap: vi.fn(() => api._selected ?? 0),
      _listeners: listeners,
      trigger: (e: string) => {
        listeners[e]?.();
      },
    };
    return api;
  }

  const Button = (props: any) => {
    const aria = props["aria-label"] || props["aria-hidden"];
    const handleClick = (e: any) => {
      if (typeof props.onClick === "function") {
        props.onClick(e);
      }
      try {
        if (typeof aria === "string" && aria.includes("Previous")) {
          lastApi?.scrollPrev();
        } else if (typeof aria === "string" && aria.includes("Next")) {
          lastApi?.scrollNext();
        } else if (typeof aria === "string" && aria.startsWith("Preview image")) {
          const match = aria.match(PREVIEW_REGEX);
          const idx = match ? Number(match[1]) - 1 : undefined;
          if (typeof idx === "number") {
            lastApi?.scrollTo(idx);
          }
        }
      } catch (_err) {
        // swallow; tests assert on the mocked API
      }
    };
    return React.createElement("button", { ...props, onClick: handleClick }, props.children);
  };

  const Carousel = ({ setApi, children }: any) => {
    const api = createApi();
    lastApi = api;
    lastSetApi = setApi;
    React.useLayoutEffect(() => setApi(api), [setApi]);
    return React.createElement("div", { "data-testid": "carousel" }, children);
  };

  const CarouselContent = ({ children }: any) => React.createElement("div", null, children);
  const CarouselItem = ({ children }: any) => React.createElement("div", null, children);

  return {
    __esModule: true,
    Button,
    Carousel,
    CarouselContent,
    CarouselItem,
    getLastApi: () => lastApi,
    getLastSetApi: () => lastSetApi,
  };
});

// Simplify next/image
vi.mock("next/image", () => ({
  __esModule: true,
  default: (props: any) => React.createElement("span", { "data-src": props.src }, props.alt),
}));

// jsdom missing scrollIntoView
if (!HTMLElement.prototype.scrollIntoView) {
  HTMLElement.prototype.scrollIntoView = (() => undefined) as any;
}

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
});

const IMAGES = ["/a.jpg", "/b.jpg", "/c.jpg"];

test("renders nothing when closed", () => {
  const { container } = render(
    <ImagePreviewModal
      alt="x"
      currentIndex={0}
      images={IMAGES}
      isOpen={false}
      onClose={() => undefined}
      onIndexChange={() => undefined}
    />
  );
  expect(container.firstChild).toBeNull();
});

test("backdrop and close button call onClose", () => {
  const onClose = vi.fn();
  const onIndexChange = vi.fn();

  const { container } = render(
    <ImagePreviewModal
      alt="x"
      currentIndex={0}
      images={IMAGES}
      isOpen
      onClose={onClose}
      onIndexChange={onIndexChange}
    />
  );

  const backdrop = container.querySelector("button[aria-hidden]");
  expect(backdrop).toBeTruthy();
  fireEvent.click(backdrop as Element);
  expect(onClose).toHaveBeenCalledTimes(1);

  const closeBtn = screen.getByLabelText("Close preview");
  fireEvent.click(closeBtn);
  expect(onClose).toHaveBeenCalledTimes(2);
});

test("carousel controls, thumbnails and keyboard", async () => {
  const onClose = vi.fn();
  const onIndexChange = vi.fn();

  const { rerender } = render(
    <ImagePreviewModal
      alt="x"
      currentIndex={1}
      images={IMAGES}
      isOpen
      onClose={onClose}
      onIndexChange={onIndexChange}
    />
  );

  await screen.findByTestId("carousel");
  const ui: any = await import("@tfs-ucmp/ui");
  let api = ui.getLastApi();
  for (let i = 0; i < 10 && !api; i++) {
    await new Promise((r) => setTimeout(r, 0));
    api = ui.getLastApi();
  }
  expect(api).toBeTruthy();

  rerender(
    <ImagePreviewModal
      alt="x"
      currentIndex={1}
      images={IMAGES}
      isOpen
      onClose={onClose}
      onIndexChange={onIndexChange}
    />
  );

  const prev = screen.getByLabelText("Previous preview");
  fireEvent.click(prev);
  const next = screen.getByLabelText("Next preview");
  fireEvent.click(next);

  const thumb0 = screen.getByLabelText("Preview image 1");
  fireEvent.click(thumb0);
  expect(thumb0).toBeTruthy();

  await new Promise((r) => setTimeout(r, 0));
  fireEvent.keyDown(window, { key: "Escape" });
  expect(onClose).toHaveBeenCalled();

  if (api && typeof api.trigger === "function") {
    api._selected = 2;
    api.trigger("select");
  }
});

test("thumbnail active item scrollIntoView called when currentIndex changes", () => {
  const onClose = vi.fn();
  const onIndexChange = vi.fn();
  const spy = vi.spyOn(HTMLElement.prototype, "scrollIntoView");

  render(
    <ImagePreviewModal
      alt="x"
      currentIndex={2}
      images={IMAGES}
      isOpen
      onClose={onClose}
      onIndexChange={onIndexChange}
    />
  );
  expect(spy).toHaveBeenCalled();
});

test("calls api.scrollTo when api is available and currentIndex changes", async () => {
  const onClose = vi.fn();
  const onIndexChange = vi.fn();

  const { rerender } = render(
    <ImagePreviewModal
      alt="x"
      currentIndex={0}
      images={IMAGES}
      isOpen
      onClose={onClose}
      onIndexChange={onIndexChange}
    />
  );

  await screen.findByTestId("carousel");
  const ui: any = await import("@tfs-ucmp/ui");
  let api = ui.getLastApi();
  for (let i = 0; i < 10 && !api; i++) {
    await new Promise((r) => setTimeout(r, 0));
    api = ui.getLastApi();
  }
  expect(api).toBeTruthy();

  const setApi = ui.getLastSetApi?.();
  if (setApi) {
    setApi(api);
  }

  rerender(
    <ImagePreviewModal
      alt="x"
      currentIndex={2}
      images={IMAGES}
      isOpen
      onClose={onClose}
      onIndexChange={onIndexChange}
    />
  );
  await new Promise((r) => setTimeout(r, 0));
  if (api?.scrollTo) {
    expect(api.scrollTo).toHaveBeenCalledWith(2);
  }
});

test("registers select listener and restores body overflow on cleanup", async () => {
  const onClose = vi.fn();
  const onIndexChange = vi.fn();

  const original = document.body.style?.overflow || "";
  document.body.style.overflow = original;

  const { rerender } = render(
    <ImagePreviewModal
      alt="x"
      currentIndex={0}
      images={IMAGES}
      isOpen
      onClose={onClose}
      onIndexChange={onIndexChange}
    />
  );

  await screen.findByTestId("carousel");
  const ui: any = await import("@tfs-ucmp/ui");
  let api = ui.getLastApi();
  for (let i = 0; i < 10 && !api; i++) {
    await new Promise((r) => setTimeout(r, 0));
    api = ui.getLastApi();
  }
  expect(api).toBeTruthy();

  const setApi = ui.getLastSetApi?.();
  if (setApi) {
    setApi(api);
  }

  const onSpy = vi.spyOn(api, "on");
  const offSpy = vi.spyOn(api, "off");

  rerender(
    <ImagePreviewModal
      alt="x"
      currentIndex={0}
      images={IMAGES}
      isOpen
      onClose={onClose}
      onIndexChange={onIndexChange}
    />
  );
  expect(document.body.style.overflow).toBe("hidden");

  fireEvent.keyDown(window, { key: "ArrowLeft" });
  fireEvent.keyDown(window, { key: "ArrowRight" });
  expect(api.scrollPrev).toBeDefined();
  expect(api.scrollNext).toBeDefined();

  expect(onSpy).toHaveBeenCalled();

  cleanup();
  expect(offSpy).toHaveBeenCalled();
  expect(document.body.style.overflow).toBe(original);
});

test("exercises mocked UI component branches directly", async () => {
  const ui: any = await import("@tfs-ucmp/ui");

  const { container } = render(
    React.createElement(
      ui.Carousel,
      { setApi: (_: any) => undefined },
      React.createElement(ui.CarouselContent, null, React.createElement(ui.CarouselItem, null, "x"))
    )
  );

  let api = ui.getLastApi();
  for (let i = 0; i < 5 && !api; i++) {
    await new Promise((r) => setTimeout(r, 0));
    api = ui.getLastApi();
  }
  expect(api).toBeTruthy();

  const clickSpy = vi.fn();
  const Prev = render(
    React.createElement(ui.Button, { "aria-label": "Previous preview", onClick: clickSpy })
  );
  const Next = render(
    React.createElement(ui.Button, { "aria-label": "Next preview", onClick: clickSpy })
  );
  const Thumb = render(
    React.createElement(ui.Button, { "aria-label": "Preview image 3", onClick: clickSpy })
  );
  const Plain = render(React.createElement(ui.Button, { onClick: clickSpy }));

  const prevBtn =
    container.querySelector('button[aria-label="Previous preview"]') ||
    Prev.container.querySelector("button");
  const nextBtn =
    container.querySelector('button[aria-label="Next preview"]') ||
    Next.container.querySelector("button");
  const thumbBtn =
    container.querySelector('button[aria-label="Preview image 3"]') ||
    Thumb.container.querySelector("button");

  if (prevBtn) {
    fireEvent.click(prevBtn);
  }
  if (nextBtn) {
    fireEvent.click(nextBtn);
  }
  if (thumbBtn) {
    fireEvent.click(thumbBtn);
  }

  expect(api.scrollPrev).toBeDefined();
  expect(api.scrollNext).toBeDefined();
  expect(api.scrollTo).toBeDefined();

  const plainBtn = Plain.container.querySelector("button");
  if (plainBtn) {
    fireEvent.click(plainBtn as Element);
  }
  expect(clickSpy).toHaveBeenCalled();
});

test("select event triggers onIndexChange when registered", async () => {
  const onClose = vi.fn();
  const onIndexChange = vi.fn();

  render(
    <ImagePreviewModal
      alt="x"
      currentIndex={0}
      images={IMAGES}
      isOpen
      onClose={onClose}
      onIndexChange={onIndexChange}
    />
  );

  await screen.findByTestId("carousel");
  const ui: any = await import("@tfs-ucmp/ui");
  let api = ui.getLastApi();
  for (let i = 0; i < 10 && !api; i++) {
    await new Promise((r) => setTimeout(r, 0));
    api = ui.getLastApi();
  }
  expect(api).toBeTruthy();

  const setApi = ui.getLastSetApi?.();
  if (setApi) {
    setApi(api);
  }

  // wait until listener is registered
  for (let i = 0; i < 10 && !api._listeners?.select; i++) {
    // eslint-disable-next-line no-await-in-loop
    await new Promise((r) => setTimeout(r, 0));
  }

  api._selected = 1;
  if (typeof api.trigger === "function") {
    api.trigger("select");
  }

  expect(onIndexChange).toHaveBeenCalledWith(1);
});

test("early-return in api effect when api not yet wired", async () => {
  // reset module registry so we can temporarily override the Carousel behavior
  vi.resetModules();

  // temporary mock: Carousel sets API inside useEffect (delayed) so parent effect sees api undefined
  vi.doMock("@tfs-ucmp/ui", async () => {
    const React = await import("react");
    let lastApi: any = null;
    let lastSetApi: any = null;
    function createApi() {
      const listeners: Record<string, (...args: unknown[]) => unknown> = {};
      const api: any = {
        _selected: 0,
        scrollTo: vi.fn((i: number) => {
          api._selected = i;
        }),
        scrollPrev: vi.fn(() => {
          api._selected = Math.max(0, (api._selected ?? 0) - 1);
        }),
        scrollNext: vi.fn(() => {
          api._selected = Math.min(10, (api._selected ?? 0) + 1);
        }),
        on: (e: string, cb: (...args: unknown[]) => unknown) => {
          listeners[e] = cb;
        },
        off: (e: string) => {
          delete listeners[e];
        },
        selectedScrollSnap: vi.fn(() => api._selected ?? 0),
        _listeners: listeners,
        trigger: (e: string) => {
          listeners[e]?.();
        },
      };
      return api;
    }

    const Button = (props: any) =>
      React.createElement("button", { ...props, onClick: props.onClick }, props.children);
    const Carousel = ({ setApi, children }: any) => {
      const api = createApi();
      lastApi = api;
      lastSetApi = setApi;
      // useEffect (delayed) instead of useLayoutEffect to force parent effect to run first
      React.useEffect(() => setApi(api), [setApi]);
      return React.createElement("div", { "data-testid": "carousel" }, children);
    };
    const CarouselContent = ({ children }: any) => React.createElement("div", null, children);
    const CarouselItem = ({ children }: any) => React.createElement("div", null, children);
    return {
      __esModule: true,
      Button,
      Carousel,
      CarouselContent,
      CarouselItem,
      getLastApi: () => lastApi,
      getLastSetApi: () => lastSetApi,
    };
  });

  // simple next/image mock for this isolated import
  vi.doMock("next/image", () => ({
    __esModule: true,
    default: (props: any) => React.createElement("span", { "data-src": props.src }, props.alt),
  }));

  // import the component fresh under the temporary mocks
  const { ImagePreviewModal: Modal } = await import("../image-preview-modal");

  // render while Carousel hasn't wired the api yet — parent effect should early-return
  const onClose = vi.fn();
  const onIndexChange = vi.fn();
  render(
    <Modal
      alt="x"
      currentIndex={0}
      images={IMAGES}
      isOpen
      onClose={onClose}
      onIndexChange={onIndexChange}
    />
  );

  // give effects a tick so the parent effect runs (and should hit the early-return path)
  await new Promise((r) => setTimeout(r, 0));

  // restore module registry so subsequent tests use the top-level mocks
  vi.resetModules();
});

test("no active thumbnail when currentIndex out of range", async () => {
  const onClose = vi.fn();
  const onIndexChange = vi.fn();

  const spy = vi.spyOn(HTMLElement.prototype, "scrollIntoView");

  render(
    <ImagePreviewModal
      alt="x"
      currentIndex={10}
      images={IMAGES}
      isOpen
      onClose={onClose}
      onIndexChange={onIndexChange}
    />
  );

  // give effects a tick
  await new Promise((r) => setTimeout(r, 0));

  expect(spy).not.toHaveBeenCalled();
});
