/* istanbul ignore file */

import { render } from "@testing-library/react";
import React from "react";
import { describe, expect, it, vi } from "vitest";

// Mutable mock factories used per-test
let mockUsePromotionFlags = () => ({ context: { isCardTestEnabled: false }, isLoading: false });
const PROMOS: any[] = [];

// Helper to register simple card mocks per-test
const registerCardMocks = (prequalifyMock: any, testDriveMock: any, tradeInMock: any) => {
  vi.doMock("../prequalify-card", () => ({ PrequalifyCard: prequalifyMock }));
  vi.doMock("../test-drive-card", () => ({ TestDriveCard: testDriveMock }));
  vi.doMock("../trade-in-card", () => ({ TradeInCard: tradeInMock }));
};

// Named mock implementations to ensure coverage attribution
const prequalifyMockImpl = (props: any) =>
  React.createElement("div", {
    "data-testid": "vdp-card",
    "data-card-id": "prequalify",
    "data-button-text": props?.buttonText ?? "",
    "data-detailed": props?.detailed ? "true" : "false",
    "data-title": props?.title || "",
    "data-description": props?.description || "",
  });

const testDriveMockImpl = (props: any) =>
  React.createElement("div", {
    "data-testid": "vdp-card",
    "data-card-id": "testDrive",
    "data-button-text": props?.buttonText ?? "",
  });

const tradeInMockImpl = (props: any) =>
  React.createElement("div", {
    "data-testid": "vdp-card",
    "data-card-id": "tradeIn",
    "data-button-text": props?.buttonText ?? "",
  });

describe("VdpPromotionCards — behavior-only", () => {
  it("returns null while promotion flags are loading", async () => {
    vi.resetModules();

    mockUsePromotionFlags = () => ({ context: { isCardTestEnabled: false }, isLoading: true });
    vi.doMock("@features/vdp/hooks/use-promotion-flags", () => ({
      usePromotionFlags: () => mockUsePromotionFlags(),
    }));
    vi.doMock("../promotion-registry", () => ({ PROMOTION_CARDS: PROMOS }));
    registerCardMocks(
      () => React.createElement("div", { "data-testid": "vdp-card", "data-card-id": "prequalify" }),
      () => React.createElement("div", { "data-testid": "vdp-card", "data-card-id": "testDrive" }),
      () => React.createElement("div", { "data-testid": "vdp-card", "data-card-id": "tradeIn" })
    );

    PROMOS.length = 0;

    const { VdpPromotionCards } = await import("../vdp-promotion-cards");
    const { container } = render(React.createElement(VdpPromotionCards, {}));
    expect(container.innerHTML).toBe("");
  });

  it("coverage: execute mock registrations", async () => {
    vi.resetModules();

    mockUsePromotionFlags = () => ({ context: { isCardTestEnabled: false }, isLoading: false });
    vi.doMock("@features/vdp/hooks/use-promotion-flags", () => ({
      usePromotionFlags: () => mockUsePromotionFlags(),
    }));
    vi.doMock("../promotion-registry", () => ({ PROMOTION_CARDS: PROMOS }));
    registerCardMocks(
      () => React.createElement("div", { "data-testid": "vdp-card", "data-card-id": "prequalify" }),
      () => React.createElement("div", { "data-testid": "vdp-card", "data-card-id": "testDrive" }),
      () => React.createElement("div", { "data-testid": "vdp-card", "data-card-id": "tradeIn" })
    );

    PROMOS.length = 0;

    const { VdpPromotionCards } = await import("../vdp-promotion-cards");
    const { container } = render(React.createElement(VdpPromotionCards, {}));
    expect(container).toBeTruthy();
  });

  it("returns null when parent props hide all cards", async () => {
    vi.resetModules();

    mockUsePromotionFlags = () => ({ context: { isCardTestEnabled: false }, isLoading: false });
    vi.doMock("@features/vdp/hooks/use-promotion-flags", () => ({
      usePromotionFlags: () => mockUsePromotionFlags(),
    }));
    vi.doMock("../promotion-registry", () => ({ PROMOTION_CARDS: PROMOS }));
    registerCardMocks(
      (props: any) =>
        React.createElement("div", {
          "data-testid": "vdp-card",
          "data-card-id": "prequalify",
          "data-button-text": props.buttonText,
        }),
      (props: any) =>
        React.createElement("div", {
          "data-testid": "vdp-card",
          "data-card-id": "testDrive",
          "data-button-text": props.buttonText,
        }),
      (props: any) =>
        React.createElement("div", {
          "data-testid": "vdp-card",
          "data-card-id": "tradeIn",
          "data-button-text": props.buttonText,
        })
    );

    PROMOS.length = 0;
    PROMOS.push(
      { id: "prequalify", priority: 1, defaultButtonText: "Prequal", guard: () => true },
      { id: "testDrive", priority: 2, defaultButtonText: "TestDrive", guard: () => true }
    );

    const { VdpPromotionCards } = await import("../vdp-promotion-cards");
    const { container } = render(
      React.createElement(VdpPromotionCards, {
        showPrequal: false,
        showTestDrive: false,
        showTradeIn: false,
      } as any)
    );
    expect(container.innerHTML).toBe("");
  });

  it("uses entry.defaultButtonText when testDriveButtonText is not provided", async () => {
    vi.resetModules();

    mockUsePromotionFlags = () => ({ context: { isCardTestEnabled: false }, isLoading: false });
    vi.doMock("@features/vdp/hooks/use-promotion-flags", () => ({
      usePromotionFlags: () => mockUsePromotionFlags(),
    }));
    vi.doMock("../promotion-registry", () => ({ PROMOTION_CARDS: PROMOS }));
    registerCardMocks(
      (props: any) =>
        React.createElement("div", {
          "data-testid": "vdp-card",
          "data-card-id": "prequalify",
          "data-button-text": props.buttonText,
        }),
      (props: any) =>
        React.createElement("div", {
          "data-testid": "vdp-card",
          "data-card-id": "testDrive",
          "data-button-text": props.buttonText,
        }),
      (props: any) =>
        React.createElement("div", {
          "data-testid": "vdp-card",
          "data-card-id": "tradeIn",
          "data-button-text": props.buttonText,
        })
    );

    PROMOS.length = 0;
    PROMOS.push({
      id: "testDrive",
      priority: 1,
      defaultButtonText: "TD-DEFAULT",
      guard: () => true,
    });

    const { VdpPromotionCards } = await import("../vdp-promotion-cards");
    const { container } = render(React.createElement(VdpPromotionCards, {}));

    const node = container.querySelector('[data-card-id="testDrive"]');
    expect(node?.getAttribute("data-button-text")).toBe("TD-DEFAULT");
  });

  it("renders tradeIn when its guard is true", async () => {
    vi.resetModules();

    mockUsePromotionFlags = () => ({ context: { isCardTestEnabled: false }, isLoading: false });
    vi.doMock("@features/vdp/hooks/use-promotion-flags", () => ({
      usePromotionFlags: () => mockUsePromotionFlags(),
    }));
    vi.doMock("../promotion-registry", () => ({ PROMOTION_CARDS: PROMOS }));
    registerCardMocks(prequalifyMockImpl, testDriveMockImpl, tradeInMockImpl);

    PROMOS.length = 0;
    PROMOS.push({ id: "tradeIn", priority: 1, defaultButtonText: "Trade", guard: () => true });

    const { VdpPromotionCards } = await import("../vdp-promotion-cards");
    const { container } = render(
      React.createElement(VdpPromotionCards, { showTradeIn: true } as any)
    );

    const node = container.querySelector('[data-card-id="tradeIn"]');
    expect(node).toBeTruthy();
  });

  it("renders prequalify with detailed=false by default", async () => {
    vi.resetModules();

    mockUsePromotionFlags = () => ({ context: { isCardTestEnabled: false }, isLoading: false });
    vi.doMock("@features/vdp/hooks/use-promotion-flags", () => ({
      usePromotionFlags: () => mockUsePromotionFlags(),
    }));
    vi.doMock("../promotion-registry", () => ({ PROMOTION_CARDS: PROMOS }));
    registerCardMocks(prequalifyMockImpl, testDriveMockImpl, tradeInMockImpl);

    PROMOS.length = 0;
    PROMOS.push({ id: "prequalify", priority: 1, defaultButtonText: "Prequal", guard: () => true });

    const { VdpPromotionCards } = await import("../vdp-promotion-cards");
    const { container } = render(React.createElement(VdpPromotionCards, {}));

    const node = container.querySelector('[data-card-id="prequalify"]');
    expect(node?.getAttribute("data-detailed")).toBe("false");
  });

  it("renders visible cards, respects props and guard, and honors testDrive buttonText", async () => {
    vi.resetModules();

    mockUsePromotionFlags = () => ({ context: { isCardTestEnabled: false }, isLoading: false });
    vi.doMock("@features/vdp/hooks/use-promotion-flags", () => ({
      usePromotionFlags: () => mockUsePromotionFlags(),
    }));
    vi.doMock("../promotion-registry", () => ({ PROMOTION_CARDS: PROMOS }));
    registerCardMocks(prequalifyMockImpl, testDriveMockImpl, tradeInMockImpl);

    PROMOS.length = 0;
    PROMOS.push(
      { id: "prequalify", priority: 2, defaultButtonText: "Prequal", guard: () => true },
      { id: "testDrive", priority: 1, defaultButtonText: "TestDrive", guard: () => true },
      { id: "tradeIn", priority: 3, defaultButtonText: "Trade", guard: () => false }
    );

    const { VdpPromotionCards } = await import("../vdp-promotion-cards");
    const { container } = render(
      React.createElement(VdpPromotionCards, {
        showTradeIn: false,
        testDriveButtonText: "CUSTOM-TD",
      } as any)
    );

    const nodes = Array.from(container.querySelectorAll('[data-testid="vdp-card"]'));
    const ids = nodes.map((n) => n.getAttribute("data-card-id"));
    expect(ids).toContain("testDrive");
    expect(ids).toContain("prequalify");
    expect(ids.indexOf("testDrive")).toBeLessThan(ids.indexOf("prequalify"));

    const td = nodes.find((n) => n.getAttribute("data-card-id") === "testDrive");
    if (!td) {
      throw new Error("Test drive card not found");
    }
    expect(td.getAttribute("data-button-text")).toBe("CUSTOM-TD");
  });

  it("applies cardTestOverrides and detailed when context.isCardTestEnabled is true", async () => {
    vi.resetModules();

    mockUsePromotionFlags = () => ({ context: { isCardTestEnabled: true }, isLoading: false });
    vi.doMock("@features/vdp/hooks/use-promotion-flags", () => ({
      usePromotionFlags: () => mockUsePromotionFlags(),
    }));
    vi.doMock("../promotion-registry", () => ({ PROMOTION_CARDS: PROMOS }));
    registerCardMocks(prequalifyMockImpl, testDriveMockImpl, tradeInMockImpl);

    PROMOS.length = 0;
    PROMOS.push({
      id: "prequalify",
      priority: 1,
      defaultButtonText: "Prequal",
      guard: undefined,
      cardTestOverrides: { buttonText: "OVERRIDE", description: "OV desc", title: "OV title" },
    });

    const { VdpPromotionCards } = await import("../vdp-promotion-cards");
    const { container } = render(React.createElement(VdpPromotionCards, {}));

    const card = container.querySelector('[data-card-id="prequalify"]') as HTMLElement | null;
    expect(card).toBeTruthy();
    expect(card?.getAttribute("data-button-text")).toBe("OVERRIDE");
    expect(card?.getAttribute("data-detailed")).toBe("true");
    expect(card?.getAttribute("data-title")).toBe("OV title");
  });
});
