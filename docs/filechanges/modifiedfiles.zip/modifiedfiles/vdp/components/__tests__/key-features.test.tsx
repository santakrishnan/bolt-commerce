import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import React from "react";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";

const EXPAND_RE = /Expand All/i;
const COLLAPSE_RE = /Collapse/i;

// safely stub scrollIntoView to avoid jsdom issues and restore after tests
const _origScroll = (HTMLElement.prototype as any).scrollIntoView;
beforeAll(() => {
  // provide a no-op so we can spy on it later
  HTMLElement.prototype.scrollIntoView = (() => undefined) as any;
});
afterAll(() => {
  HTMLElement.prototype.scrollIntoView = _origScroll;
});

// Mock next/image
vi.mock("next/image", () => ({
  __esModule: true,
  default: (props: any) => {
    const { alt, src } = props;
    const srcVal = typeof src === "string" ? src : src?.src;
    return React.createElement("span", { "data-alt": alt, "data-src": srcVal }, props.children);
  },
}));

// Mock @tfs-ucmp/ui components. Collapsible/Trigger share module-level state
vi.mock("@tfs-ucmp/ui", () => {
  let _onOpenChange: ((v: boolean) => void) | undefined;
  let _open = false;

  const Collapsible = (props: any) => {
    _onOpenChange = props.onOpenChange;
    _open = !!props.open;
    return React.createElement("div", { "data-open": _open }, props.children);
  };

  const CollapsibleTrigger = (props: any) => {
    const child = React.Children.only(props.children) as React.ReactElement;
    return React.cloneElement(
      child as any,
      {
        onClick: () => {
          _onOpenChange?.(!_open);
          _open = !_open;
        },
      } as any
    );
  };

  const CollapsibleContent = (props: any) => React.createElement("div", null, props.children);

  const Heading = (props: any) =>
    React.createElement(`h${props.level ?? 2}`, { "data-heading": true }, props.children);

  return { __esModule: true, Collapsible, CollapsibleTrigger, CollapsibleContent, Heading };
});

import { VehicleKeyFeatures } from "../key-features";

describe("VehicleKeyFeatures", () => {
  it("renders non-collapsible variant with provided features and default icon", () => {
    render(<VehicleKeyFeatures className="c" collapsible={false} features={["f1", "f2"]} />);

    expect(screen.getByText("Key Highlights")).toBeInTheDocument();
    expect(screen.getByText("f1")).toBeInTheDocument();
    expect(screen.getByText("f2")).toBeInTheDocument();

    const icon = document.querySelector('span[data-src="/images/vdp/Vector_5.svg"]');
    expect(icon).toBeTruthy();
  });

  it("renders collapsible variant, shows visible and hidden features and toggles open state", async () => {
    const many = Array.from({ length: 12 }).map((_, i) => `feat-${i}`);
    render(<VehicleKeyFeatures features={many} />);

    // first (visible) feature should render (may appear multiple times due to mobile/desktop markup)
    expect(screen.getAllByText("feat-0").length).toBeGreaterThan(0);

    // a hidden feature (index >= 10) should also be mounted (forceMount)
    expect(screen.getAllByText("feat-11").length).toBeGreaterThan(0);

    // The trigger button starts with "Expand All"
    const btn = screen.getByRole("button", { name: EXPAND_RE });
    expect(btn).toBeInTheDocument();

    // Spy on scrollIntoView to ensure effect runs when expanded
    const spy = vi.spyOn(HTMLElement.prototype, "scrollIntoView");

    fireEvent.click(btn);

    // After clicking, the mocked CollapsibleTrigger calls onOpenChange which updates internal state
    await waitFor(() =>
      expect(screen.getByRole("button", { name: COLLAPSE_RE })).toBeInTheDocument()
    );

    // effect should call scrollIntoView
    await waitFor(() => expect(spy).toHaveBeenCalled());
  });
});
