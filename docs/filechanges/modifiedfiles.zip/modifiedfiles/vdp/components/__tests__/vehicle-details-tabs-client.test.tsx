import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { VehicleDetailsTabsClient } from "../vehicle-details-tabs-client";

vi.mock("@tfs-ucmp/ui", () => ({
  cn: (...args: any[]) => args.filter(Boolean).join(" "),
  Tabs: ({ children, onValueChange, value }: any) => (
    <div
      data-value={value}
      onClick={(e: any) => onValueChange?.(e.target.dataset.tabId)}
      onKeyUp={(e: any) => {
        if (e.key === "Enter" || e.key === " ") {
          onValueChange?.(e.target.dataset.tabId);
        }
      }}
      role="tablist"
      tabIndex={0}
    >
      {children}
    </div>
  ),
  TabsList: ({ children, className }: any) => <div className={className}>{children}</div>,
  TabsTrigger: ({ children, value, className }: any) => (
    <button className={className} data-tab-id={value} type="button">
      {children}
    </button>
  ),
}));

describe("VehicleDetailsTabsClient", () => {
  const mockTabDefs = [
    {
      id: "overview",
      label: "Overview",
      content: <div>Overview Content</div>,
    },
    {
      id: "features",
      label: "Features",
      content: <div>Features Content</div>,
    },
    {
      id: "pricing",
      label: "Pricing",
      content: <div>Pricing Content</div>,
    },
  ];

  it("renders all tab labels", () => {
    render(<VehicleDetailsTabsClient tabDefs={mockTabDefs} />);

    expect(screen.getByText("Overview")).toBeInTheDocument();
    expect(screen.getByText("Features")).toBeInTheDocument();
    expect(screen.getByText("Pricing")).toBeInTheDocument();
  });

  it("renders first tab content by default", () => {
    render(<VehicleDetailsTabsClient tabDefs={mockTabDefs} />);

    expect(screen.getByText("Overview Content")).toBeInTheDocument();
  });

  it("renders tab buttons", () => {
    render(<VehicleDetailsTabsClient tabDefs={mockTabDefs} />);

    const buttons = screen.getAllByRole("button");
    expect(buttons.length).toBe(mockTabDefs.length);
  });

  it("handles tab switching", async () => {
    const user = userEvent.setup();
    render(<VehicleDetailsTabsClient tabDefs={mockTabDefs} />);

    const featuresButton = screen.getByRole("button", { name: "Features" });
    await user.click(featuresButton);

    expect(screen.getByText("Features Content")).toBeInTheDocument();
  });

  it("renders with custom className", () => {
    const customClass = "custom-tabs";
    render(<VehicleDetailsTabsClient className={customClass} tabDefs={mockTabDefs} />);
    expect(screen.getByText("Overview")).toBeInTheDocument();
  });

  it("renders tab with custom content class", () => {
    const customContentClass = "custom-content-class";
    const tabsWithCustomContent = [
      {
        id: "overview",
        label: "Overview",
        content: <div>Overview</div>,
        contentClassName: customContentClass,
      },
    ];

    render(<VehicleDetailsTabsClient tabDefs={tabsWithCustomContent} />);
    const overviewMatches = screen.getAllByText("Overview");
    const overviewContent = overviewMatches.find((el) => el.tagName.toLowerCase() !== "button");
    expect(overviewContent).toBeDefined();
    expect(overviewContent).toBeInTheDocument();
  });

  it("renders all tab triggers with correct values", () => {
    render(<VehicleDetailsTabsClient tabDefs={mockTabDefs} />);

    const buttons = screen.getAllByRole("button");
    expect(buttons[0]).toHaveAttribute("data-tab-id", "overview");
    expect(buttons[1]).toHaveAttribute("data-tab-id", "features");
    expect(buttons[2]).toHaveAttribute("data-tab-id", "pricing");
  });

  it("handles single tab", () => {
    const singleTab = [
      {
        id: "only",
        label: "Only Tab",
        content: <div>Only Content</div>,
      },
    ];

    render(<VehicleDetailsTabsClient tabDefs={singleTab} />);

    expect(screen.getByText("Only Tab")).toBeInTheDocument();
    expect(screen.getByText("Only Content")).toBeInTheDocument();
  });

  it("renders empty content when not provided", () => {
    const tabsWithoutContent = [
      {
        id: "empty",
        label: "Empty",
        content: null,
      },
    ];

    render(<VehicleDetailsTabsClient tabDefs={tabsWithoutContent} />);

    expect(screen.getByText("Empty")).toBeInTheDocument();
  });

  it("handles empty tabDefs without crashing", () => {
    render(<VehicleDetailsTabsClient tabDefs={[]} />);

    // no tab triggers should be rendered and no default content should appear
    expect(screen.queryAllByRole("button").length).toBe(0);
    expect(screen.queryByText("Overview")).not.toBeInTheDocument();
  });

  it("maintains active tab state", () => {
    const { rerender } = render(<VehicleDetailsTabsClient tabDefs={mockTabDefs} />);

    expect(screen.getByText("Overview Content")).toBeInTheDocument();

    // Re-render and verify first tab is still active
    rerender(<VehicleDetailsTabsClient tabDefs={mockTabDefs} />);

    expect(screen.getByText("Overview Content")).toBeInTheDocument();
  });

  it("renders tab list with scrollable container", () => {
    render(<VehicleDetailsTabsClient tabDefs={mockTabDefs} />);
    const buttons = screen.getAllByRole("button");
    expect(buttons.length).toBeGreaterThan(0);
  });
});
