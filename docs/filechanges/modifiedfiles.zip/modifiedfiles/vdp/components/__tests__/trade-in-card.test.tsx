import { render, screen } from "@testing-library/react";
import React from "react";
import { describe, expect, it, vi } from "vitest";

// Minimal mocks to avoid CSS/shadcn/Next internals
vi.mock("@shared/components/action-card", () => {
  const React = require("react");
  return {
    ActionCard: (props: any) =>
      React.createElement(
        "div",
        {
          "data-testid": "action-card",
          "data-button-text": props.buttonText,
          "data-description": props.description,
          "data-title": props.title,
          "data-button-variant": props.buttonVariant,
          "data-button-size": props.buttonSize,
        },
        props.icon
          ? React.createElement("div", { "data-testid": "action-card-icon" }, props.icon)
          : null
      ),
  };
});

vi.mock("@shared/components/button", () => {
  const React = require("react");
  return {
    AppButton: ({ children, ...props }: any) =>
      React.createElement(
        "button",
        {
          "data-testid": "app-button",
          "data-size": props.size,
          "data-variant": props.variant,
          className: props.className,
        },
        children
      ),
  };
});

// Mock next/image to a simple img element
vi.mock("next/image", () => ({
  __esModule: true,
  default: (props: any) => React.createElement("img", props),
}));

import { TradeInCard } from "../trade-in-card";

describe("TradeInCard — behavior-only", () => {
  it("renders AppButton with default text and props when not detailed", () => {
    render(<TradeInCard />);

    const btn = screen.getByTestId("app-button");
    expect(btn).toBeTruthy();
    // default text
    expect(btn.textContent).toBe("Accept My Trade-In Offer");
    // props passed through as data attributes by our mock
    expect(btn.getAttribute("data-size")).toBe("md");
    expect(btn.getAttribute("data-variant")).toBe("secondary");
  });

  it("renders ActionCard with provided props when detailed=true", () => {
    render(
      <TradeInCard
        buttonText="Custom Text"
        description="Custom Desc"
        detailed
        title="Custom Title"
      />
    );

    const card = screen.getByTestId("action-card");
    expect(card).toBeTruthy();
    expect(card.getAttribute("data-button-text")).toBe("Custom Text");
    expect(card.getAttribute("data-title")).toBe("Custom Title");
    expect(card.getAttribute("data-description")).toBe("Custom Desc");

    // icon rendered inside the action card and should contain an img with the expected alt
    const iconWrapper = screen.getByTestId("action-card-icon");
    expect(iconWrapper).toBeTruthy();
    const img = iconWrapper.querySelector("img");
    expect(img).toBeTruthy();
    expect(img?.getAttribute("alt")).toBe("Arrow inspected icon");
  });
});
