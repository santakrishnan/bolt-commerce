import { act } from "@testing-library/react";
import React from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";

describe("VehiclePdpStickyClient (behavior-only)", () => {
  beforeEach(() => {
    vi.resetModules();
    document.body.innerHTML = "";
    // stub scrollTo to avoid JSDOM warnings
    // @ts-expect-error
    window.scrollTo = vi.fn();
  });

  it("passes computed props to VehicleStickyBanner and responds to scroll", async () => {
    // Mock sticky-banner module (return a DOM element with serialized props)
    vi.doMock("../sticky-banner", () => ({
      VehicleStickyBanner: (props: any) =>
        React.createElement("div", { "data-props": JSON.stringify(props) }),
    }));

    // Mock next/navigation pathname
    vi.doMock("next/navigation", () => ({ usePathname: () => "/vehicles/2021-toyota-corolla" }));

    const { render } = await import("@testing-library/react");
    const mod = await import("../vehicle-pdp-sticky-client");
    const { VehiclePdpStickyClient } = mod;

    // Create desktop target and header to produce a positive offset and showStickyCTA
    const desktop = document.createElement("div");
    desktop.id = "desktop-target";
    // mock getBoundingClientRect to control rect.top
    // mock getBoundingClientRect to control rect.top
    (desktop as any).getBoundingClientRect = () => ({ top: 50 });
    // mark as attached by defining an offsetParent getter (readonly in JSDOM)
    Object.defineProperty(desktop as any, "offsetParent", { get: () => ({}) });
    document.body.appendChild(desktop);

    const header = document.createElement("header");
    // @ts-expect-error
    header.getBoundingClientRect = () => ({ height: 80 });
    document.body.appendChild(header);

    // initial scrollY
    (window as any).scrollY = 0;

    const { container } = render(
      // @ts-expect-error - pass minimal dummy props
      React.createElement(VehiclePdpStickyClient, {
        vehicle: {} as any,
        slugParams: {} as any,
        desktopTargetId: "desktop-target",
        mobileTargetId: "mobile-target",
      })
    );

    const banner = container.querySelector("div[data-props]");
    if (!banner) {
      throw new Error("Banner not found");
    }
    const props = JSON.parse(banner.getAttribute("data-props") || "{}");

    // headerHeight 80 - rect.top 50 => offset 30
    expect(props.stickyScrollOffset).toBe(30);
    expect(props.showStickyCTA).toBe(true);
    // initial scrollDirection defaults to 'down'
    expect(props.scrollDirection).toBe("down");

    // simulate scroll down
    await act(async () => {
      (window as any).scrollY = 200;
      window.dispatchEvent(new Event("scroll"));
      await Promise.resolve();
    });

    const bannerAfterDown = container.querySelector("div[data-props]");
    if (!bannerAfterDown) {
      throw new Error("Banner not found after scroll down");
    }
    const propsAfterDown = JSON.parse(bannerAfterDown.getAttribute("data-props") || "{}");
    expect(propsAfterDown.scrollDirection).toBe("down");

    // simulate scroll up
    await act(async () => {
      (window as any).scrollY = 50;
      window.dispatchEvent(new Event("scroll"));
      await Promise.resolve();
    });

    const bannerAfterUp = container.querySelector("div[data-props]");
    if (!bannerAfterUp) {
      throw new Error("Banner not found after scroll up");
    }
    const propsAfterUp = JSON.parse(bannerAfterUp.getAttribute("data-props") || "{}");
    expect(propsAfterUp.scrollDirection).toBe("up");
  });

  it("renders with defaults when no target is found", async () => {
    vi.doMock("../sticky-banner", () => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const ReactLocal = require("react");
      return {
        VehicleStickyBanner: (props: any) =>
          ReactLocal.createElement("div", { "data-props": JSON.stringify(props) }),
      };
    });
    vi.doMock("next/navigation", () => ({ usePathname: () => "/x" }));

    const { render } = await import("@testing-library/react");
    const mod = await import("../vehicle-pdp-sticky-client");
    const { VehiclePdpStickyClient } = mod;

    // no desktop/mobile targets in DOM
    const { container } = render(
      // @ts-expect-error
      React.createElement(VehiclePdpStickyClient, {
        vehicle: {} as any,
        slugParams: {} as any,
        desktopTargetId: "nope",
        mobileTargetId: "also-no",
      })
    );

    const banner = container.querySelector("div[data-props]");
    if (!banner) {
      throw new Error("Banner not found in defaults test");
    }
    const props = JSON.parse(banner.getAttribute("data-props") || "{}");

    expect(props.stickyScrollOffset).toBe(0);
    expect(props.showStickyCTA).toBe(false);
  });

  it("coverage: exercise alternate branches (no pathname, mobile target used, no header)", async () => {
    // ensure window.scrollTo isn't called when pathname is undefined
    const scrollToSpy = vi.fn();
    // @ts-expect-error
    window.scrollTo = scrollToSpy;

    vi.doMock("../sticky-banner", () => ({
      VehicleStickyBanner: (props: any) =>
        React.createElement("div", { "data-props": JSON.stringify(props) }),
    }));
    // return undefined pathname to exercise the 'no pathname' branch
    vi.doMock("next/navigation", () => ({ usePathname: () => undefined }));

    const { render } = await import("@testing-library/react");
    const mod = await import("../vehicle-pdp-sticky-client");
    const { VehiclePdpStickyClient } = mod;

    // desktop exists but offsetParent is null -> mobile should be selected
    const desktop = document.createElement("div");
    desktop.id = "desktop-target-2";
    Object.defineProperty(desktop as any, "offsetParent", { get: () => null });
    (desktop as any).getBoundingClientRect = () => ({ top: 0 });
    document.body.appendChild(desktop);

    const mobile = document.createElement("div");
    mobile.id = "mobile-target";
    (mobile as any).getBoundingClientRect = () => ({ top: 200 });
    Object.defineProperty(mobile as any, "offsetParent", { get: () => ({}) });
    document.body.appendChild(mobile);

    // no header in DOM -> headerHeight default branch
    (window as any).scrollY = 0;

    const { container } = render(
      // @ts-expect-error
      React.createElement(VehiclePdpStickyClient, {
        vehicle: {} as any,
        slugParams: {} as any,
        desktopTargetId: "desktop-target-2",
        mobileTargetId: "mobile-target",
      })
    );

    // scrollTo should NOT have been invoked because pathname is undefined
    expect(scrollToSpy).not.toHaveBeenCalled();

    const banner = container.querySelector("div[data-props]");
    if (!banner) {
      throw new Error("Banner not found in coverage test");
    }
    const props = JSON.parse(banner.getAttribute("data-props") || "{}");
    // mobile rect.top 200 > default headerHeight 80 -> no sticky
    expect(props.stickyScrollOffset).toBe(0);
    expect(props.showStickyCTA).toBe(false);
  });
});
