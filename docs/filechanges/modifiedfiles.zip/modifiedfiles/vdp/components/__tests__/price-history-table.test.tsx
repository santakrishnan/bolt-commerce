import { render, screen } from "@testing-library/react";
import React from "react";
import { describe, expect, it, vi } from "vitest";

vi.mock("next/image", () => ({
  __esModule: true,
  default: ({ src, alt }: any) => React.createElement("img", { src, alt }),
}));

vi.mock("@tfs-ucmp/ui", () => ({
  __esModule: true,
  ScrollArea: ({ children }: any) =>
    React.createElement("div", { "data-scrollarea": "true" }, children),
}));

import { PriceHistoryTable } from "../price-history-table";

// helpers mirrored from component formatting to assert expected rendered strings
const formatShortDate = (isoDate: string) =>
  new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric" }).format(
    new Date(isoDate)
  );

const formatPrice = (value: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(value);

const formatChange = (change: number) => {
  const abs = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(Math.abs(change));
  return change >= 0 ? `+${abs}` : `-${abs}`;
};

describe("PriceHistoryTable", () => {
  it("renders up to 4 rows, formats date/price/change and shows arrows for non-current months", () => {
    const now = new Date();
    const currentIso = now.toISOString();

    // create several past dates (ensure they are not current month)
    const past1 = new Date(now.getFullYear(), now.getMonth() - 1, 5).toISOString();
    const past2 = new Date(now.getFullYear(), now.getMonth() - 2, 10).toISOString();
    const past3 = new Date(now.getFullYear(), now.getMonth() - 3, 15).toISOString();
    const past4 = new Date(now.getFullYear(), now.getMonth() - 4, 20).toISOString();

    // entries: first is latest (current), component slices first 4 and reverses so latest ends at bottom
    const entries: { date: string; price: number; change: number }[] = [
      { date: currentIso, price: 15_000, change: 0 },
      { date: past1, price: 14_000, change: -1000 },
      { date: past2, price: 16_000, change: 2000 },
      { date: past3, price: 15_500, change: -500 },
      { date: past4, price: 13_000, change: -2000 },
    ];

    render(React.createElement(PriceHistoryTable, { entries }));

    // the component uses slice(0,4) so the fifth entry should NOT appear
    expect(screen.queryByText(formatShortDate(past4))).toBeNull();

    // dates and prices for the first 4 entries must be present
    for (const e of entries.slice(0, 4)) {
      expect(screen.getByText(formatShortDate(e.date))).toBeInTheDocument();
      expect(screen.getByText(formatPrice(e.price))).toBeInTheDocument();
    }

    // current-month entry (entries[0]) should NOT render change text or arrow
    expect(screen.queryByText(formatChange(entries[0]?.change))).toBeNull();
    // at least one up and one down arrow must exist among non-current entries
    expect(screen.getAllByAltText("Price up").length).toBeGreaterThan(0);
    expect(screen.getAllByAltText("Price down").length).toBeGreaterThan(0);

    // specific change values from non-current entries must be shown
    const change1 = formatChange(entries[1]?.change);
    const change2 = formatChange(entries[2]?.change);
    expect(screen.getByText(change1)).toBeInTheDocument();
    expect(screen.getByText(change2)).toBeInTheDocument();
  });
});
