import { render } from "@testing-library/react";
import React from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";

describe("VehicleMetaBar — behavior-only", () => {
  beforeEach(() => {
    vi.resetModules();
    document.body.innerHTML = "";
    // mock the shadcn `cn` util to keep tests simple and CSS-free
    vi.doMock("@tfs-ucmp/ui", () => ({ cn: (...parts: any[]) => parts.filter(Boolean).join(" ") }));
  });

  it("renders expected chips and formats numeric mileage, no accidents path", async () => {
    const mod = await import("../vehicle-meta-bar");
    const { VehicleMetaBar } = mod;

    const vehicle = {
      drivetrain: "FWD",
      fuelType: undefined,
      transmission: undefined,
      miles: "12345",
      exteriorColor: "Wind Chill Pearl",
      interiorColor: "Black",
      certified: true,
      warranty: false,
      inspectionPassed: true,
      inspected: undefined,
    } as any;

    const specs: any[] = [
      { key: "fuel-type", value: "Gasoline" },
      { key: "transmission", value: "Automatic" },
    ];

    const historyData = { damageReported: 0, previousOwners: 1, titleStatus: undefined } as any;
    const vehicleStatus = { inspectionInProgress: false } as any;

    const { container } = render(
      // @ts-expect-error
      React.createElement(VehicleMetaBar, { vehicle, specs, historyData, vehicleStatus })
    );

    const text = container.textContent || "";
    // drivetrain
    expect(text).toContain("FWD");
    // fuel from specs
    expect(text).toContain("Gasoline");
    // transmission from specs
    expect(text).toContain("Automatic");
    // formatted mileage
    expect(text).toContain("12,345 mi");
    // exterior/interior labels
    expect(text).toContain("Ext");
    expect(text).toContain("Int");
    // no accidents
    expect(text).toContain("No Accidents");
    // owner singular
    expect(text).toContain("1 Owner");
    // certified label present
    expect(text).toContain("Certified");
    // inspection label present
    expect(text).toContain("160-Point Inspection");
  });

  it("renders alternate branches (plural accidents, non-numeric miles, missing swatch)", async () => {
    const mod = await import("../vehicle-meta-bar");
    const { VehicleMetaBar } = mod;

    const vehicle = {
      drivetrain: "AWD",
      miles: "unknown",
      exteriorColor: "Some Unknown Color",
      interiorColor: "Some Unknown Int",
      certified: false,
      warranty: false,
      inspectionPassed: false,
    } as any;

    const specs: any[] = [];
    const historyData = { damageReported: 2, previousOwners: 2, titleStatus: "Salvage" } as any;
    const vehicleStatus = { inspectionInProgress: true } as any;

    const { container } = render(
      // @ts-expect-error
      React.createElement(VehicleMetaBar, { vehicle, specs, historyData, vehicleStatus })
    );

    const text = container.textContent || "";
    expect(text).toContain("AWD");
    // non-numeric miles should render as provided
    expect(text).toContain("unknown");
    // plural accidents
    expect(text).toContain("2 Accidents");
    // plural owners
    expect(text).toContain("2 Owners");
    // titleStatus should be rendered
    expect(text).toContain("Salvage");
    // missing swatch should still render colorName text
    expect(text).toContain("Some Unknown Color");
  });

  // Note: avoid importing internal helpers from the module to respect SUT immutability.
});
