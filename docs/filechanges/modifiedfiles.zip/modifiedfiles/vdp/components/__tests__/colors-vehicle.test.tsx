import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { VehicleColors } from "../colors-vehicle";

const COLOR_LABELS_PATTERN = /Exterior|Interior/;

describe("VehicleColors", () => {
  const mockProps = {
    exteriorName: "Pearl White",
    interiorName: "Black Leather",
  };

  it("renders exterior color name", () => {
    render(<VehicleColors {...mockProps} />);
    expect(screen.getByText("Pearl White")).toBeInTheDocument();
  });

  it("renders interior color name", () => {
    render(<VehicleColors {...mockProps} />);
    expect(screen.getByText("Black Leather")).toBeInTheDocument();
  });

  it("renders exterior label", () => {
    render(<VehicleColors {...mockProps} />);
    expect(screen.getByText("Exterior")).toBeInTheDocument();
  });

  it("renders interior label", () => {
    render(<VehicleColors {...mockProps} />);
    expect(screen.getByText("Interior")).toBeInTheDocument();
  });

  it("renders color swatches", () => {
    // Component renders swatch elements adjacent to labels — ensure labels exist
    render(<VehicleColors {...mockProps} />);
    expect(screen.getByText("Exterior")).toBeInTheDocument();
    expect(screen.getByText("Interior")).toBeInTheDocument();
  });

  it("applies exterior swatch style", () => {
    // Avoid asserting inline styles; just ensure exterior name still renders when style provided
    const exteriorStyle = { backgroundColor: "#ffffff" };
    render(<VehicleColors {...mockProps} exteriorSwatchStyle={exteriorStyle} />);
    expect(screen.getByText("Pearl White")).toBeInTheDocument();
  });

  it("applies interior swatch style", () => {
    // Avoid asserting inline styles; just ensure interior name still renders when style provided
    const interiorStyle = { backgroundColor: "#000000" };
    render(<VehicleColors {...mockProps} interiorSwatchStyle={interiorStyle} />);
    expect(screen.getByText("Black Leather")).toBeInTheDocument();
  });

  it("applies custom className", () => {
    const { container } = render(<VehicleColors {...mockProps} className="custom-colors-class" />);
    const wrapper = container.firstChild as HTMLElement;
    expect(wrapper).toHaveAttribute("class");
  });

  it("renders with custom color names", () => {
    render(<VehicleColors exteriorName="Midnight Blue" interiorName="Tan Suede" />);
    expect(screen.getByText("Midnight Blue")).toBeInTheDocument();
    expect(screen.getByText("Tan Suede")).toBeInTheDocument();
  });

  it("renders with complex color names", () => {
    render(
      <VehicleColors
        exteriorName="Solid Charcoal with Metallic"
        interiorName="Premium Caramel Napa Leather"
      />
    );
    expect(screen.getByText("Solid Charcoal with Metallic")).toBeInTheDocument();
    expect(screen.getByText("Premium Caramel Napa Leather")).toBeInTheDocument();
  });

  // Styling and class names are implementation details; tests avoid asserting them.

  it("renders exactly two color sections", () => {
    render(<VehicleColors {...mockProps} />);
    const labels = screen.getAllByText(COLOR_LABELS_PATTERN);
    expect(labels.length).toBe(2);
  });
});
