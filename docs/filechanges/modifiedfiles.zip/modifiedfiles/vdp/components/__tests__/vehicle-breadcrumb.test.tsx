import { render, screen } from "@testing-library/react";
import React from "react";
import { describe, expect, it, vi } from "vitest";

// Mock the design system breadcrumbs and Next internals to keep tests behavior-only
vi.mock("@tfs-ucmp/ui", () => ({
  Breadcrumb: (props: any) => React.createElement("nav", props, props.children),
  BreadcrumbList: (props: any) => React.createElement("div", props, props.children),
  BreadcrumbItem: (props: any) => React.createElement("div", props, props.children),
  BreadcrumbLink: (props: any) => {
    const { asChild, ...rest } = props || {};
    return React.createElement("div", rest, props.children);
  },
  BreadcrumbPage: (props: any) => React.createElement("span", props, props.children),
  BreadcrumbSeparator: (props: any) => React.createElement("span", props, props.children),
}));

vi.mock("next/image", () => ({
  __esModule: true,
  default: (props: any) =>
    React.createElement("img", { "data-testid": "nb-image", alt: props.alt || "", src: props.src }),
}));

vi.mock("next/link", () => ({
  __esModule: true,
  default: ({ children, href }: any) => React.createElement("a", { href }, children),
}));

describe("VehicleBreadcrumbList — behavior-only", () => {
  it("renders year, capitalized make/model, trim (upper) and vin", async () => {
    vi.resetModules();
    const { VehicleBreadcrumbList } = await import("../vehicle-breadcrumb");

    const slugParams = {
      year: "2020",
      make: "toyota",
      model: "camry",
      trimSlug: "se",
      vin: "VIN123",
    } as any;
    const { container } = render(React.createElement(VehicleBreadcrumbList, { slugParams }));

    // year
    expect(screen.getByText("2020")).toBeTruthy();
    // capitalized make and model
    expect(screen.getByText("Toyota")).toBeTruthy();
    expect(screen.getByText("Camry")).toBeTruthy();
    // trimSlug uppercased
    expect(screen.getByText("SE")).toBeTruthy();
    // vin
    expect(screen.getByText("VIN123")).toBeTruthy();

    // image separators render as mocked img
    expect(container.querySelectorAll('[data-testid="nb-image"]').length).toBeGreaterThan(0);

    // ensure links render and point to used-cars routes
    const anchorNodes = container.querySelectorAll("a");
    let found = false;
    for (const n of Array.from(anchorNodes)) {
      const href = n.getAttribute("href") || "";
      if (href.includes("/used-cars")) {
        found = true;
        break;
      }
    }
    expect(found).toBeTruthy();
  });

  it("renders even if trimSlug is missing", async () => {
    vi.resetModules();
    const { VehicleBreadcrumbList } = await import("../vehicle-breadcrumb");

    const slugParams = { year: "2019", make: "honda", model: "civic", vin: "VIN456" } as any;
    render(React.createElement(VehicleBreadcrumbList, { slugParams }));

    expect(screen.getByText("2019")).toBeTruthy();
    expect(screen.getByText("Honda")).toBeTruthy();
    expect(screen.getByText("Civic")).toBeTruthy();
    expect(screen.getByText("VIN456")).toBeTruthy();
  });

  it("coverage: exercise mocked helper branches", async () => {
    // call next/image mock with and without alt to hit both branches
    const imgMod = await import("next/image");
    const Img = imgMod.default as any;
    expect(Img({ src: "/x", alt: "ALT" })).toBeTruthy();
    expect(Img({ src: "/y" })).toBeTruthy();

    // call BreadcrumbLink mock with and without asChild
    const ui = await import("@tfs-ucmp/ui");
    expect(ui.BreadcrumbLink({ asChild: true, children: "x" })).toBeTruthy();
    expect(ui.BreadcrumbLink({ children: "y" })).toBeTruthy();
  });
});
