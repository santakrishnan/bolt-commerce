import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { VehicleDetailsTabs } from "../vehicle-details-tabs";

vi.mock("next/dynamic", () => ({
  default: (fn: any) => {
    // execute the loader to exercise the dynamic import branch during tests
    try {
      fn();
    } catch (_e) {
      /* ignore loader errors in test environment */
    }
    const Component = vi.fn(() => <div>PricingTab Mock</div>);
    return Component;
  },
}));
const FEATURES_TAB_REGEX = /FeaturesTab Mock/;

vi.mock("../overview-tab", () => ({
  OverviewTab: () => <div>OverviewTab Mock</div>,
}));

vi.mock("../features-tab", () => ({
  FeaturesTab: ({ features, initialCount }: any) => (
    <div>
      FeaturesTab Mock - {features.length} features, initial: {initialCount}
    </div>
  ),
}));

vi.mock("../history-tab", () => ({
  HistoryTab: () => <div>HistoryTab Mock</div>,
}));

vi.mock("../vehicle-details-tabs-client", () => ({
  VehicleDetailsTabsClient: ({ tabDefs, className }: any) => (
    <div className={className}>
      {tabDefs.map((tab: any) => (
        <div data-testid={`tab-${tab.id}`} key={tab.id}>
          <div>{tab.label}</div>
          <div className={tab.contentClassName}>{tab.content}</div>
        </div>
      ))}
    </div>
  ),
}));

describe("VehicleDetailsTabs", () => {
  const mockSpecs = [{ name: "Spec 1", value: "Value 1" }] as any;
  const mockFeatures = [{ name: "Safety", items: ["Feature 1", "Feature 2"] }] as any;
  const mockPricingData = {
    currentPrice: 25_000,
    avgPrice: 30_000,
    priceHistory: [],
  } as any;
  const mockPriceHistory = [{ date: "2024-01-01", price: 26_000 }] as any;
  const mockHistoryData = { title: "History" } as any;

  it("renders all four tabs", () => {
    render(
      <VehicleDetailsTabs
        className=""
        features={mockFeatures}
        featuresInitialCount={5}
        historyData={mockHistoryData}
        priceHistory={mockPriceHistory}
        pricingData={mockPricingData}
        specs={mockSpecs}
        vehicle={{} as any}
        vehicleStatus={{} as any}
      />
    );

    expect(screen.getByTestId("tab-overview")).toBeInTheDocument();
    expect(screen.getByTestId("tab-features")).toBeInTheDocument();
    expect(screen.getByTestId("tab-pricing")).toBeInTheDocument();
    expect(screen.getByTestId("tab-history")).toBeInTheDocument();
  });

  it("renders tab labels correctly", () => {
    render(
      <VehicleDetailsTabs
        className=""
        features={mockFeatures}
        featuresInitialCount={5}
        historyData={mockHistoryData}
        priceHistory={mockPriceHistory}
        pricingData={mockPricingData}
        specs={mockSpecs}
        vehicle={{} as any}
        vehicleStatus={{} as any}
      />
    );

    expect(screen.getByText("Overview")).toBeInTheDocument();
    expect(screen.getByText("Features & Details")).toBeInTheDocument();
    expect(screen.getByText("Pricing")).toBeInTheDocument();
    expect(screen.getByText("History")).toBeInTheDocument();
  });

  it("passes specs to overview tab", () => {
    render(
      <VehicleDetailsTabs
        className=""
        features={mockFeatures}
        featuresInitialCount={5}
        historyData={mockHistoryData}
        priceHistory={mockPriceHistory}
        pricingData={mockPricingData}
        specs={mockSpecs}
        vehicle={{} as any}
        vehicleStatus={{} as any}
      />
    );

    // Verify tabs are rendered
    expect(screen.getByText("Overview")).toBeInTheDocument();
  });

  it("passes features to features tab", () => {
    render(
      <VehicleDetailsTabs
        className=""
        features={mockFeatures}
        featuresInitialCount={5}
        historyData={mockHistoryData}
        priceHistory={mockPriceHistory}
        pricingData={mockPricingData}
        specs={mockSpecs}
        vehicle={{} as any}
        vehicleStatus={{} as any}
      />
    );

    expect(screen.getByText(FEATURES_TAB_REGEX)).toBeInTheDocument();
  });

  it("applies custom className", () => {
    const customClass = "custom-tabs-class";
    render(
      <VehicleDetailsTabs
        className={customClass}
        features={mockFeatures}
        featuresInitialCount={5}
        historyData={mockHistoryData}
        priceHistory={mockPriceHistory}
        pricingData={mockPricingData}
        specs={mockSpecs}
        vehicle={{} as any}
        vehicleStatus={{} as any}
      />
    );

    // ensure rendering with a custom className doesn't break tabs rendering
    expect(screen.getByTestId("tab-overview")).toBeInTheDocument();
  });

  it("passes correct tab content class names", () => {
    const { container } = render(
      <VehicleDetailsTabs
        className=""
        features={mockFeatures}
        featuresInitialCount={5}
        historyData={mockHistoryData}
        priceHistory={mockPriceHistory}
        pricingData={mockPricingData}
        specs={mockSpecs}
        vehicle={{} as any}
        vehicleStatus={{} as any}
      />
    );

    expect(container).toBeInTheDocument();
  });

  it("handles empty specs array", () => {
    render(
      <VehicleDetailsTabs
        className=""
        features={mockFeatures}
        featuresInitialCount={5}
        historyData={mockHistoryData}
        priceHistory={mockPriceHistory}
        pricingData={mockPricingData}
        specs={[]}
        vehicle={{} as any}
        vehicleStatus={{} as any}
      />
    );

    expect(screen.getByText("Overview")).toBeInTheDocument();
  });

  it("handles multiple features categories", () => {
    const multiFeatures = [
      { name: "Safety", items: ["ABS", "ESP"] },
      { name: "Comfort", items: ["Power Seats", "Climate Control"] },
    ] as any;

    render(
      <VehicleDetailsTabs
        className=""
        features={multiFeatures}
        featuresInitialCount={10}
        historyData={mockHistoryData}
        priceHistory={mockPriceHistory}
        pricingData={mockPricingData}
        specs={mockSpecs}
        vehicle={{} as any}
        vehicleStatus={{} as any}
      />
    );

    expect(screen.getByText("Features & Details")).toBeInTheDocument();
  });

  it("renders tabs in correct order", () => {
    const { container } = render(
      <VehicleDetailsTabs
        className=""
        features={mockFeatures}
        featuresInitialCount={5}
        historyData={mockHistoryData}
        priceHistory={mockPriceHistory}
        pricingData={mockPricingData}
        specs={mockSpecs}
        vehicle={{} as any}
        vehicleStatus={{} as any}
      />
    );

    const tabs = container.querySelectorAll("[data-testid^='tab-']");
    expect(tabs[0]).toHaveAttribute("data-testid", "tab-overview");
    expect(tabs[1]).toHaveAttribute("data-testid", "tab-features");
    expect(tabs[2]).toHaveAttribute("data-testid", "tab-pricing");
    expect(tabs[3]).toHaveAttribute("data-testid", "tab-history");
  });
});
