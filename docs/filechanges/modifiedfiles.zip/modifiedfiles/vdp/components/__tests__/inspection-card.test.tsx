import { render, screen } from "@testing-library/react";
import React from "react";
import { describe, expect, it, vi } from "vitest";

// Mock next/image to a simple element that exposes src/alt via data- attributes
vi.mock("next/image", () => ({
  __esModule: true,
  default: (props: any) => {
    const { alt, src } = props;
    const srcVal = typeof src === "string" ? src : src?.src;
    return React.createElement("span", { "data-alt": alt, "data-src": srcVal });
  },
}));

// Mock Card from @tfs-ucmp/ui to avoid shadcn/css internals
vi.mock("@tfs-ucmp/ui", () => ({
  __esModule: true,
  Card: (props: any) => React.createElement("div", { "data-testid": "card" }, props.children),
}));

import { InspectionCard } from "../inspection-card";

describe("InspectionCard", () => {
  it("renders photo, icon, title and description", () => {
    render(
      <InspectionCard
        description="desc"
        iconSrc="/icon.png"
        photoAlt="Photo alt"
        photoSrc="/photo.jpg"
        title="My title"
      />
    );

    const photo = document.querySelector('span[data-src="/photo.jpg"]');
    expect(photo).toBeTruthy();

    const icon = document.querySelector('span[data-src="/icon.png"]');
    expect(icon).toBeTruthy();

    expect(screen.getByText("My title")).toBeInTheDocument();
    expect(screen.getByText("desc")).toBeInTheDocument();

    expect(screen.getByTestId("card")).toBeInTheDocument();
  });

  it("supports a ReactNode title", () => {
    render(
      <InspectionCard
        description="d"
        iconSrc="/i.png"
        photoAlt="alt"
        photoSrc="/p.jpg"
        title={
          <>
            <span>PartA</span>
            <span>PartB</span>
          </>
        }
      />
    );

    expect(screen.getByText("PartA")).toBeInTheDocument();
    expect(screen.getByText("PartB")).toBeInTheDocument();
  });
});
