import { act, renderHook, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { useStickyScroll } from "../use-sticky-scroll";

describe("useStickyScroll", () => {
  beforeEach(() => {
    // clear document between tests
    document.body.innerHTML = "";
    // reset scroll
    (window as any).scrollY = 0;
    vi.restoreAllMocks();
  });

  function makeTarget(top: number, offsetParentNotNull = true) {
    const el = document.createElement("div");
    // ensure offsetParent check behaves predictably
    Object.defineProperty(el, "offsetParent", {
      get: () => (offsetParentNotNull ? document.body : null),
    });
    // provide a stable getBoundingClientRect used by the hook
    (el as any).getBoundingClientRect = () => ({
      top,
      left: 0,
      right: 0,
      bottom: 0,
      width: 0,
      height: 0,
      x: 0,
      y: 0,
    });
    document.body.appendChild(el);
    return el;
  }

  function makeHeader(height: number) {
    const header = document.createElement("header");
    (header as any).getBoundingClientRect = () => ({ height });
    document.body.appendChild(header);
    return header;
  }

  it("toggles banner display and updates style on scroll down and up", async () => {
    // desktop target initially far from header (no sticky)
    const desktop = makeTarget(200, true);
    const mobile = makeTarget(200, false);
    makeHeader(80);

    const { result } = renderHook(() => useStickyScroll({ current: desktop }, { current: mobile }));

    // create a banner element and attach it to the hook's ref
    const bannerEl = document.createElement("div");
    // ensure style object exists
    bannerEl.style.opacity = "";
    bannerEl.style.transform = "";
    bannerEl.style.display = "";

    act(() => {
      result.current.bannerRef.current = bannerEl;
    });

    // initial scroll: target top 200, header 80 -> no sticky
    (window as any).scrollY = 0;
    act(() => window.dispatchEvent(new Event("scroll")));

    await waitFor(() => {
      expect(bannerEl.style.display === "" || bannerEl.style.display === "none").toBe(true);
    });

    // simulate scrolling so the target is above header and user scrolled down
    (desktop as any).getBoundingClientRect = () => ({ top: 10 });
    (window as any).scrollY = 100;
    act(() => window.dispatchEvent(new Event("scroll")));

    await waitFor(() => {
      expect(bannerEl.style.display).toBe("block");
      const opacity = Number.parseFloat(bannerEl.style.opacity || "0");
      expect(opacity).toBeGreaterThan(0);
      expect(bannerEl.style.transform).toContain("translateY(");
    });

    // now simulate scrolling up (decrease scrollY)
    (window as any).scrollY = 50;
    act(() => window.dispatchEvent(new Event("scroll")));

    await waitFor(() => {
      expect(bannerEl.style.transform).toBe("translateY(0px)");
    });
  });

  it("uses mobile target when desktop offsetParent is null and header missing", async () => {
    document.body.innerHTML = "";
    // desktop has no offsetParent -> mobile should be used
    const desktop = makeTarget(200, false);
    const mobile = makeTarget(10, true);

    const { result } = renderHook(() => useStickyScroll({ current: desktop }, { current: mobile }));

    const bannerEl = document.createElement("div");
    bannerEl.style.opacity = "";
    bannerEl.style.transform = "";
    bannerEl.style.display = "";

    act(() => {
      result.current.bannerRef.current = bannerEl;
    });

    // initial call to set prevScrollY
    (window as any).scrollY = 0;
    act(() => window.dispatchEvent(new Event("scroll")));

    // simulate scroll down then slightly up to exercise both directions
    (window as any).scrollY = 60;
    act(() => window.dispatchEvent(new Event("scroll")));

    (window as any).scrollY = 20;
    act(() => window.dispatchEvent(new Event("scroll")));

    await waitFor(() => {
      expect(bannerEl.style.display).toBe("block");
      expect(Number.parseFloat(bannerEl.style.opacity || "0")).toBeGreaterThanOrEqual(0);
    });
  });

  it("handles missing bannerRef gracefully (no throw)", async () => {
    document.body.innerHTML = "";
    const desktop = makeTarget(10, true);
    const mobile = makeTarget(200, false);

    const { result } = renderHook(() => useStickyScroll({ current: desktop }, { current: mobile }));

    act(() => {
      // explicitly leave bannerRef.current as null
      result.current.bannerRef.current = null as any;
    });

    (window as any).scrollY = 10;
    // should not throw
    act(() => window.dispatchEvent(new Event("scroll")));

    await waitFor(() => {
      expect(true).toBe(true);
    });
  });

  it("returns early when no target elements are provided", async () => {
    document.body.innerHTML = "";

    renderHook(() => useStickyScroll({ current: null }, { current: null }));

    // dispatch a scroll; handler should return early without throwing
    act(() => window.dispatchEvent(new Event("scroll")));

    await waitFor(() => {
      expect(true).toBe(true);
    });
  });
});
