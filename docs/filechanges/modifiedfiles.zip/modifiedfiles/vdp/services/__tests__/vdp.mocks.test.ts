import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

import { fetchMockVehicleData, fetchMockVinData } from "../vdp.mocks";

const filePath = path.resolve(import.meta.dirname, "..", "vdp.mocks.ts");
const PRIORITY_VIN_RE = /const PRIORITY_VIN = "([^"]+)"/;
const NOT_FOUND_RE = /not found/;

describe("vdp.mocks API", () => {
  it("returns vin data for priority vin", async () => {
    const src = fs.readFileSync(filePath, "utf8");
    const m = src.match(PRIORITY_VIN_RE);
    expect(m).toBeTruthy();
    const priorityVin = m?.[1];

    const vinData = await fetchMockVinData(priorityVin);
    expect(vinData).toBeDefined();
    expect(vinData.vehicle).toBeDefined();
    expect(vinData.vehicle.vin).toBe(priorityVin);
    expect(typeof vinData.pricing.currentPrice).toBe("number");
    expect(Array.isArray(vinData.priceHistory)).toBe(true);
  });

  it("returns vehicle data for id from vinData", async () => {
    const src = fs.readFileSync(filePath, "utf8");
    const m = src.match(PRIORITY_VIN_RE);
    const priorityVin = m?.[1];

    const vinData = await fetchMockVinData(priorityVin);
    const id = String(vinData.vehicle.id);

    const vehicleData = await fetchMockVehicleData(id);
    expect(vehicleData).toBeDefined();
    expect(Array.isArray(vehicleData.specs)).toBe(true);
    expect(typeof vehicleData.featuresInitialCount).toBe("number");
    expect(vehicleData.vehicleStatus).toBeDefined();
  });

  it("throws for unknown vin", async () => {
    await expect(fetchMockVinData("UNKNOWNVIN123")).rejects.toThrow(NOT_FOUND_RE);
  });

  it("throws for unknown id", async () => {
    await expect(fetchMockVehicleData("9999999")).rejects.toThrow(NOT_FOUND_RE);
  });
});
