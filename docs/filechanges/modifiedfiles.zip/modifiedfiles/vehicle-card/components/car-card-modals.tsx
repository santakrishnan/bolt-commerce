import { getVehicleFinancing } from "@features/search/lib/mock-financing-service";
import type { CarCardProps } from "./car-card-types";
import EstimationModal from "./estimation-modal";
import { RefineSearchModal } from "./refine-search-modal";

export function CarCardModals({
  showEstimation,
  setShowEstimation,
  estimation,
  price,
  showRefineSearch,
  setShowRefineSearch,
  activeFilters,
  onApplyRefineFilters,
  onSearch,
}: {
  showEstimation: boolean;
  setShowEstimation: (v: boolean) => void;
  estimation: CarCardProps["estimation"];
  price: string;
  showRefineSearch: boolean;
  setShowRefineSearch: (v: boolean) => void;
  activeFilters: CarCardProps["activeFilters"];
  onApplyRefineFilters: CarCardProps["onApplyRefineFilters"];
  onSearch: CarCardProps["onSearch"];
}) {
  return (
    <>
      {showEstimation &&
        (() => {
          const numericPrice = Number.parseInt(price.replace(/[^0-9]/g, ""), 10) || 0;
          const financing = getVehicleFinancing({ price: numericPrice });
          return (
            <>
              <div
                aria-hidden="true"
                onClick={(e) => e.stopPropagation()}
                onKeyDown={(e) => e.stopPropagation()}
                role="presentation"
                style={{ position: "absolute", inset: 0, zIndex: 1 }}
              />
              <fieldset
                style={{ border: 0, padding: 0, margin: 0, position: "relative", zIndex: 2 }}
              >
                <EstimationModal
                  apr={estimation?.apr ?? financing.apr}
                  creditScore={estimation?.creditScore ?? financing.creditScore}
                  estimatedMonthlyPayment={
                    estimation?.estimatedMonthlyPayment ?? financing.estimatedMonthlyPayment
                  }
                  isOpen={showEstimation}
                  onClose={() => setShowEstimation(false)}
                  termLength={estimation?.termLength ?? `${financing.termMonths} months`}
                />
              </fieldset>
            </>
          );
        })()}
      {showRefineSearch && (
        <>
          <div
            aria-hidden="true"
            onClick={(e) => e.stopPropagation()}
            onKeyDown={(e) => e.stopPropagation()}
            role="presentation"
            style={{ position: "absolute", inset: 0, zIndex: 1 }}
          />
          <fieldset style={{ border: 0, padding: 0, margin: 0, position: "relative", zIndex: 2 }}>
            <RefineSearchModal
              activeFilters={activeFilters}
              isOpen={showRefineSearch}
              onApplyFilters={onApplyRefineFilters}
              onClose={() => setShowRefineSearch(false)}
              onSearch={onSearch}
            />
          </fieldset>
        </>
      )}
    </>
  );
}
