"use client";

import { buildUsedCarsPath } from "@config/routes";
import { VehiclePreviewModal } from "@features/vehicle-preview";
import { useRouter } from "next/navigation";
import { useCallback, useMemo, useState } from "react";
import { CarCardContent } from "./car-card-content";
import { CarCardImageSection } from "./car-card-image-section";
import { CarCardModals } from "./car-card-modals";
import type { CarCardProps } from "./car-card-types";

export type { CarCardProps } from "./car-card-types";

export default function CarCard({
  activeFilters,
  carImage,
  carName,
  make,
  model,
  variant,
  year,
  vin,
  price,
  wasPrice,
  mileage,
  estimatedPayment,
  exteriorColor,
  exteriorColorHex,
  exteriorColorGradient,
  interiorColor,
  interiorColorHex,
  matchPercentage,
  dealerName,
  distance,
  badge,
  owners,
  features = { warranty: true, inspected: true, oneOwner: true },
  estimation,
  onApplyRefineFilters,
  onSearch,
  enablePreviewModal = true,
}: CarCardProps) {
  const [showEstimation, setShowEstimation] = useState(false);
  const [showRefineSearch, setShowRefineSearch] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const router = useRouter();

  const vehiclePreviewData = useMemo(
    () => ({
      title: carName,
      year,
      make,
      model,
      trim: variant,
      price: Number.parseInt(price.replace(/[^0-9]/g, ""), 10) || 0,
      originalPrice: wasPrice ? Number.parseInt(wasPrice.replace(/[^0-9]/g, ""), 10) : 0,
      warranty: features?.warranty ?? false,
      inspected: features?.inspected ?? false,
      miles: mileage,
      vin,
      exterior: exteriorColor,
      exteriorColorCode: exteriorColorHex,
      interior: interiorColor,
      interiorColorCode: interiorColorHex,
      dealer: dealerName,
      distance,
      images: Array.isArray(carImage) ? carImage : [carImage],
    }),
    [
      carName,
      year,
      make,
      model,
      variant,
      price,
      wasPrice,
      features,
      mileage,
      vin,
      exteriorColor,
      exteriorColorHex,
      interiorColor,
      interiorColorHex,
      dealerName,
      distance,
      carImage,
    ]
  );

  const vdpUrl = useMemo(
    () =>
      make && model && variant && year && vin
        ? buildUsedCarsPath({ type: "details", make, model, trim: variant, year, vin })
        : "#",
    [make, model, variant, year, vin]
  );

  const handleCardClick = useCallback(() => {
    if (enablePreviewModal) {
      setShowPreviewModal(true);
    }
  }, [enablePreviewModal]);

  const handlePrefetch = useCallback(() => {
    if (vdpUrl !== "#") {
      router.prefetch(vdpUrl);
    }
  }, [router, vdpUrl]);

  return (
    <>
      {/* Vehicle Preview Modal — Dialog portal, not bounded by the card */}
      <VehiclePreviewModal
        isOpen={showPreviewModal}
        onClose={() => setShowPreviewModal(false)}
        vdpUrl={vdpUrl}
        vehicle={vehiclePreviewData}
        vin={vin}
      />

      {/* biome-ignore lint/a11y/useSemanticElements: Card layout requires div structure for proper styling */}
      <div
        className="group relative flex w-full cursor-pointer flex-col overflow-hidden rounded-lg bg-white shadow-sm transition-shadow duration-300 hover:shadow-xl"
        onClick={handleCardClick}
        onFocus={handlePrefetch}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            handleCardClick();
          }
        }}
        onMouseEnter={handlePrefetch}
        role="button"
        tabIndex={0}
      >
        {/* Image Section */}
        <CarCardImageSection
          badge={badge}
          carImage={carImage}
          carName={carName}
          vdpUrl={vdpUrl}
          vin={vin ?? ""}
        />

        <CarCardContent
          carName={carName}
          dealerName={dealerName}
          distance={distance}
          estimatedPayment={estimatedPayment}
          exteriorColor={exteriorColor}
          exteriorColorGradient={exteriorColorGradient}
          exteriorColorHex={exteriorColorHex}
          features={features}
          interiorColor={interiorColor}
          interiorColorHex={interiorColorHex}
          matchPercentage={matchPercentage}
          mileage={mileage}
          onShowEstimation={() => setShowEstimation(true)}
          onShowRefineSearch={() => setShowRefineSearch(true)}
          owners={owners}
          price={price}
          wasPrice={wasPrice}
        />

        {/* ── In-card overlays (modals) ── */}
        <CarCardModals
          activeFilters={activeFilters}
          estimation={estimation}
          onApplyRefineFilters={onApplyRefineFilters}
          onSearch={onSearch}
          price={price}
          setShowEstimation={setShowEstimation}
          setShowRefineSearch={setShowRefineSearch}
          showEstimation={showEstimation}
          showRefineSearch={showRefineSearch}
        />
      </div>
    </>
  );
}
