/**
 * @vitest-environment jsdom
 */

import { fireEvent, render, screen } from "@arrow/vitest-config/test-utils";
import * as matchers from "@testing-library/jest-dom/matchers";
import { cleanup } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

expect.extend(matchers);
afterEach(cleanup);

import { GarageInfoCard } from "../garage-info-card";

// ─── Mocks ────────────────────────────────────────────────────────────────────

vi.mock("@tfs-ucmp/ui", () => ({
  Card: ({ children, className }: { children: React.ReactNode; className?: string }) => (
    <div className={className} data-testid="card">
      {children}
    </div>
  ),
  CardContent: ({ children, className }: { children: React.ReactNode; className?: string }) => (
    <div className={className} data-testid="card-content">
      {children}
    </div>
  ),
  CardHeader: ({ children, className }: { children: React.ReactNode; className?: string }) => (
    <div className={className} data-testid="card-header">
      {children}
    </div>
  ),
}));

vi.mock("@shared/components/button", () => ({
  AppButton: ({
    children,
    onClick,
    variant,
    size,
  }: {
    children: React.ReactNode;
    onClick?: () => void;
    variant?: string;
    size?: string;
    className?: string;
  }) => (
    <button data-size={size} data-variant={variant} onClick={onClick} type="button">
      {children}
    </button>
  ),
}));

// ─── Tests ───────────────────────────────────────────────────────────────────

describe("GarageInfoCard", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Rendering", () => {
    it("renders the card component", () => {
      render(
        <GarageInfoCard ctaLabel="Save Vehicle" heading="My Garage">
          <p>Card body</p>
        </GarageInfoCard>
      );
      expect(screen.getByTestId("card")).toBeInTheDocument();
    });

    it("renders the heading text", () => {
      render(
        <GarageInfoCard ctaLabel="Save Vehicle" heading="My Garage">
          <p>Content</p>
        </GarageInfoCard>
      );
      expect(screen.getByText("My Garage")).toBeInTheDocument();
    });

    it("renders a ReactNode heading", () => {
      render(
        <GarageInfoCard ctaLabel="Save Vehicle" heading={<span data-testid="custom-head">Hi</span>}>
          <p>Content</p>
        </GarageInfoCard>
      );
      expect(screen.getByTestId("custom-head")).toBeInTheDocument();
    });

    it("renders children content", () => {
      render(
        <GarageInfoCard ctaLabel="Save Vehicle" heading="Heading">
          <p data-testid="slot-content">Slot content here</p>
        </GarageInfoCard>
      );
      expect(screen.getByTestId("slot-content")).toBeInTheDocument();
    });

    it("renders the CTA button with provided label", () => {
      render(
        <GarageInfoCard ctaLabel="View All Cars" heading="Heading">
          <p>Content</p>
        </GarageInfoCard>
      );
      expect(screen.getByText("View All Cars")).toBeInTheDocument();
    });

    it("renders badge when provided", () => {
      render(
        <GarageInfoCard
          badge={<span data-testid="badge-node">NEW</span>}
          ctaLabel="Click Me"
          heading="Heading"
        >
          <p>Content</p>
        </GarageInfoCard>
      );
      expect(screen.getByTestId("badge-node")).toBeInTheDocument();
    });

    it("does not render badge when not provided", () => {
      render(
        <GarageInfoCard ctaLabel="Click Me" heading="Heading">
          <p>Content</p>
        </GarageInfoCard>
      );
      // No badge testid present
      expect(screen.queryByTestId("badge-node")).not.toBeInTheDocument();
    });
  });

  describe("CTA button variant", () => {
    it("defaults to primary variant", () => {
      render(
        <GarageInfoCard ctaLabel="CTA" heading="Heading">
          <p>Content</p>
        </GarageInfoCard>
      );
      const cta = screen.getByText("CTA");
      expect(cta).toHaveAttribute("data-variant", "primary");
    });

    it("uses secondary variant when specified", () => {
      render(
        <GarageInfoCard ctaLabel="CTA" ctaVariant="secondary" heading="Heading">
          <p>Content</p>
        </GarageInfoCard>
      );
      expect(screen.getByText("CTA")).toHaveAttribute("data-variant", "secondary");
    });

    it("uses tertiary variant when specified", () => {
      render(
        <GarageInfoCard ctaLabel="CTA" ctaVariant="tertiary" heading="Heading">
          <p>Content</p>
        </GarageInfoCard>
      );
      expect(screen.getByText("CTA")).toHaveAttribute("data-variant", "tertiary");
    });
  });

  describe("CTA click handler", () => {
    it("calls onCtaClick when CTA button is clicked", () => {
      const onCtaClick = vi.fn();
      render(
        <GarageInfoCard ctaLabel="Click Me" heading="Heading" onCtaClick={onCtaClick}>
          <p>Content</p>
        </GarageInfoCard>
      );
      fireEvent.click(screen.getByText("Click Me"));
      expect(onCtaClick).toHaveBeenCalledTimes(1);
    });

    it("does not throw when onCtaClick is undefined", () => {
      render(
        <GarageInfoCard ctaLabel="Click Me" heading="Heading">
          <p>Content</p>
        </GarageInfoCard>
      );
      expect(() => fireEvent.click(screen.getByText("Click Me"))).not.toThrow();
    });
  });
});
