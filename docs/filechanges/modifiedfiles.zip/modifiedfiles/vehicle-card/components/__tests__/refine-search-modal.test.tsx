/**
 * @vitest-environment jsdom
 */

import { fireEvent, render, screen } from "@arrow/vitest-config/test-utils";
import * as matchers from "@testing-library/jest-dom/matchers";
import { cleanup } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

expect.extend(matchers);
afterEach(cleanup);

import { RefineSearchModal } from "../refine-search-modal";

// ─── Mocks ────────────────────────────────────────────────────────────────────

vi.mock("next/image", async () => {
  const actual = await vi.importActual("next/image");
  return {
    __esModule: true,
    default: actual.default,
  };
});

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({
    children,
    onClick,
    onMouseEnter,
    onMouseLeave,
  }: {
    children: React.ReactNode;
    onClick?: () => void;
    onMouseEnter?: () => void;
    onMouseLeave?: () => void;
    className?: string;
    type?: string;
    variant?: string;
  }) => (
    <button onClick={onClick} onMouseEnter={onMouseEnter} onMouseLeave={onMouseLeave} type="button">
      {children}
    </button>
  ),
  Heading: ({
    children,
    className,
  }: {
    children: React.ReactNode;
    className?: string;
    level?: number;
    weight?: string;
  }) => <h3 className={className}>{children}</h3>,
}));

vi.mock("@shared/components/button", () => ({
  AppButton: ({
    children,
    onClick,
  }: {
    children: React.ReactNode;
    onClick?: () => void;
    className?: string;
    variant?: string;
  }) => (
    <button onClick={onClick} type="button">
      {children}
    </button>
  ),
}));

vi.mock("@shared/components/custom-chips", () => ({
  CustomChips: ({
    label,
    onClick,
    type,
  }: {
    label: string;
    onClick: () => void;
    type: "selected" | "unselected";
  }) => (
    <button data-chip-type={type} data-testid={`chip-${label}`} onClick={onClick} type="button">
      {label}
    </button>
  ),
}));

vi.mock("@shared/hooks/use-single-modal", () => ({
  useSingletonModal: vi.fn(),
}));

// Mock the heavy search service modules so tests are fast
vi.mock("@features/search/lib/mock-vehicles", () => ({
  mockVehicles: [],
}));

vi.mock("@features/search/lib/mock-search-service", () => ({
  buildAllAvailableFilters: () => ({
    comfortFeatures: ["Heated Seats", "Sunroof", "Ambient Lighting"],
    techFeatures: ["Apple CarPlay", "Android Auto", "Navigation"],
    safetyFeatures: ["Lane Assist", "Blind Spot Monitor"],
    exteriorFeatures: ["Moonroof", "Roof Rails"],
    performanceFeatures: ["Sport Mode", "Paddle Shifters"],
  }),
}));

// Top-level regex constant — avoids re-creation on every slugify call (biome useTopLevelRegex)
const WHITESPACE_RE = /\s+/g;

vi.mock("utils", () => ({
  slugify: (text: string) => text.toLowerCase().replace(WHITESPACE_RE, "-"),
}));

// ─── Default Props ────────────────────────────────────────────────────────────

const defaultProps = {
  isOpen: true,
  onClose: vi.fn(),
  onApplyFilters: vi.fn(),
  onSearch: vi.fn(),
  activeFilters: [],
};

// ─── Tests ───────────────────────────────────────────────────────────────────

describe("RefineSearchModal", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Visibility", () => {
    it("renders when isOpen is true", () => {
      render(<RefineSearchModal {...defaultProps} isOpen={true} />);
      expect(screen.getByRole("dialog")).toBeInTheDocument();
    });

    it("returns null when isOpen is false", () => {
      const { container } = render(<RefineSearchModal {...defaultProps} isOpen={false} />);
      expect(container.firstChild).toBeNull();
    });
  });

  describe("Content", () => {
    it("renders Your Filters section heading", () => {
      render(<RefineSearchModal {...defaultProps} />);
      expect(screen.getByText("Your Filters")).toBeInTheDocument();
    });

    it("renders Suggested section heading", () => {
      render(<RefineSearchModal {...defaultProps} />);
      expect(screen.getByText("Suggested")).toBeInTheDocument();
    });

    it("renders filter chips from the service", () => {
      render(<RefineSearchModal {...defaultProps} />);
      // buildAllAvailableFilters returns comfort + tech features
      expect(screen.getByTestId("chip-Heated Seats")).toBeInTheDocument();
    });

    it("renders Apply Filter button", () => {
      render(<RefineSearchModal {...defaultProps} />);
      expect(screen.getByText("Apply Filter")).toBeInTheDocument();
    });

    it("renders Reset button", () => {
      render(<RefineSearchModal {...defaultProps} />);
      expect(screen.getByText("Reset")).toBeInTheDocument();
    });

    it("renders Close button", () => {
      render(<RefineSearchModal {...defaultProps} />);
      expect(screen.getByText("Close")).toBeInTheDocument();
    });
  });

  describe("Close interactions", () => {
    it("calls onClose when Close button is clicked", () => {
      const onClose = vi.fn();
      render(<RefineSearchModal {...defaultProps} onClose={onClose} />);
      fireEvent.click(screen.getByText("Close"));
      expect(onClose).toHaveBeenCalledTimes(1);
    });

    it("calls onClose when Escape key is pressed on the dialog", () => {
      const onClose = vi.fn();
      render(<RefineSearchModal {...defaultProps} onClose={onClose} />);
      const dialog = screen.getByRole("dialog");
      fireEvent.keyDown(dialog, { key: "Escape" });
      expect(onClose).toHaveBeenCalledTimes(1);
    });

    it("does not call onClose for non-Escape keys", () => {
      const onClose = vi.fn();
      render(<RefineSearchModal {...defaultProps} onClose={onClose} />);
      const dialog = screen.getByRole("dialog");
      fireEvent.keyDown(dialog, { key: "Enter" });
      expect(onClose).not.toHaveBeenCalled();
    });
  });

  describe("Filter toggling", () => {
    it("marks a chip as selected when clicked", () => {
      render(<RefineSearchModal {...defaultProps} />);
      const chip = screen.getByTestId("chip-Heated Seats");
      expect(chip).toHaveAttribute("data-chip-type", "unselected");
      fireEvent.click(chip);
      expect(chip).toHaveAttribute("data-chip-type", "selected");
    });

    it("deselects a chip when clicked again", () => {
      render(<RefineSearchModal {...defaultProps} />);
      const chip = screen.getByTestId("chip-Heated Seats");
      fireEvent.click(chip); // select
      fireEvent.click(chip); // deselect
      expect(chip).toHaveAttribute("data-chip-type", "unselected");
    });
  });

  describe("Apply filters", () => {
    it("calls onApplyFilters and onSearch with selected filters on Apply click", () => {
      const onApplyFilters = vi.fn();
      const onSearch = vi.fn();
      render(
        <RefineSearchModal {...defaultProps} onApplyFilters={onApplyFilters} onSearch={onSearch} />
      );
      fireEvent.click(screen.getByTestId("chip-Sunroof")); // select a filter
      fireEvent.click(screen.getByText("Apply Filter"));
      expect(onApplyFilters).toHaveBeenCalledTimes(1);
      expect(onSearch).toHaveBeenCalledTimes(1);
    });

    it("calls onClose after applying filters", () => {
      const onClose = vi.fn();
      render(<RefineSearchModal {...defaultProps} onClose={onClose} />);
      fireEvent.click(screen.getByText("Apply Filter"));
      expect(onClose).toHaveBeenCalledTimes(1);
    });

    it("works when onApplyFilters is not provided", () => {
      render(<RefineSearchModal {...defaultProps} onApplyFilters={undefined} />);
      expect(() => fireEvent.click(screen.getByText("Apply Filter"))).not.toThrow();
    });
  });

  describe("Reset filters", () => {
    it("clears all selected filters on Reset click", () => {
      render(<RefineSearchModal {...defaultProps} />);
      const chip = screen.getByTestId("chip-Heated Seats");
      fireEvent.click(chip); // select
      expect(chip).toHaveAttribute("data-chip-type", "selected");

      fireEvent.click(screen.getByText("Reset"));
      expect(chip).toHaveAttribute("data-chip-type", "unselected");
    });

    it("calls onApplyFilters with empty array on Reset", () => {
      const onApplyFilters = vi.fn();
      render(<RefineSearchModal {...defaultProps} onApplyFilters={onApplyFilters} />);
      fireEvent.click(screen.getByText("Reset"));
      expect(onApplyFilters).toHaveBeenCalledWith([]);
    });

    it("calls onSearch on Reset", () => {
      const onSearch = vi.fn();
      render(<RefineSearchModal {...defaultProps} onSearch={onSearch} />);
      fireEvent.click(screen.getByText("Reset"));
      expect(onSearch).toHaveBeenCalledTimes(1);
    });

    it("does NOT call onClose after Reset (modal stays open)", () => {
      const onClose = vi.fn();
      render(<RefineSearchModal {...defaultProps} onClose={onClose} />);
      fireEvent.click(screen.getByText("Reset"));
      // handleReset does not close the modal — only the Close button does
      expect(onClose).not.toHaveBeenCalled();
    });
  });

  describe("initialActiveFilters", () => {
    it("pre-selects chips that match initialActiveFilters labels", () => {
      render(
        <RefineSearchModal
          {...defaultProps}
          activeFilters={[{ label: "Heated Seats", type: "feature", value: "heated-seats" }]}
        />
      );
      const chip = screen.getByTestId("chip-Heated Seats");
      expect(chip).toHaveAttribute("data-chip-type", "selected");
    });
  });

  describe("Propagation", () => {
    it("stops click propagation from dialog backdrop", () => {
      const parentHandler = vi.fn();
      render(
        // biome-ignore lint/a11y/noStaticElementInteractions lint/a11y/useKeyWithClickEvents lint/a11y/noNoninteractiveElementInteractions: test only
        <div onClick={parentHandler}>
          <RefineSearchModal {...defaultProps} />
        </div>
      );
      const dialog = screen.getByRole("dialog");
      fireEvent.click(dialog);
      expect(parentHandler).not.toHaveBeenCalled();
    });

    it("stops mousedown propagation from dialog backdrop", () => {
      const parentHandler = vi.fn();
      render(
        // biome-ignore lint/a11y/noStaticElementInteractions lint/a11y/noNoninteractiveElementInteractions: test only
        <div onMouseDown={parentHandler}>
          <RefineSearchModal {...defaultProps} />
        </div>
      );
      const dialog = screen.getByRole("dialog");
      fireEvent.mouseDown(dialog);
      expect(parentHandler).not.toHaveBeenCalled();
    });
  });

  describe("Error handling", () => {
    it("handles onSearch throwing during apply without crashing", () => {
      const onSearch = vi.fn().mockImplementation(() => {
        throw new Error("search error");
      });
      render(<RefineSearchModal {...defaultProps} onSearch={onSearch} />);
      expect(() => fireEvent.click(screen.getByText("Apply Filter"))).not.toThrow();
    });

    it("handles onSearch throwing during reset without crashing", () => {
      const onSearch = vi.fn().mockImplementation(() => {
        throw new Error("search error");
      });
      render(<RefineSearchModal {...defaultProps} onSearch={onSearch} />);
      expect(() => fireEvent.click(screen.getByText("Reset"))).not.toThrow();
    });
  });

  describe("initialActiveFilters with mismatched value", () => {
    it("adds the service-derived filter when initial label matches but value differs", () => {
      // "Heated Seats" label matches a service filter (id="heated-seats"),
      // but the initial value is different — so the component pushes the matching entry
      render(
        <RefineSearchModal
          {...defaultProps}
          activeFilters={[{ label: "Heated Seats", type: "feature", value: "some-other-value" }]}
        />
      );
      // The chip should appear as selected since the merged state includes "heated-seats"
      const chip = screen.getByTestId("chip-Heated Seats");
      expect(chip).toBeInTheDocument();
    });
  });

  describe("Mouse hover on close button", () => {
    it("applies hover state on close button mouseEnter", () => {
      render(<RefineSearchModal {...defaultProps} />);
      const closeBtn = screen.getByText("Close").closest("button") as HTMLElement;
      fireEvent.mouseEnter(closeBtn);
      expect(closeBtn).toBeInTheDocument();
    });

    it("restores normal state on mouseLeave", () => {
      render(<RefineSearchModal {...defaultProps} />);
      const closeBtn = screen.getByText("Close").closest("button") as HTMLElement;
      fireEvent.mouseEnter(closeBtn);
      fireEvent.mouseLeave(closeBtn);
      expect(closeBtn).toBeInTheDocument();
    });
  });
});
