/**
 * @vitest-environment jsdom
 */

import { fireEvent, render, screen } from "@arrow/vitest-config/test-utils";
import * as matchers from "@testing-library/jest-dom/matchers";
import { cleanup } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

expect.extend(matchers);
afterEach(cleanup);

import EstimationModal from "../estimation-modal";

// ─── Mocks ────────────────────────────────────────────────────────────────────

vi.mock("next/image", async () => {
  const actual = await vi.importActual("next/image");
  return {
    __esModule: true,
    default: actual.default,
  };
});

vi.mock("@tfs-ucmp/ui", () => ({
  Heading: ({
    children,
    className,
  }: {
    children: React.ReactNode;
    className?: string;
    level?: number;
    weight?: string;
  }) => <h3 className={className}>{children}</h3>,
  Button: ({
    children,
    onClick,
    onMouseEnter,
    onMouseLeave,
    "aria-label": ariaLabel,
  }: {
    children: React.ReactNode;
    onClick?: () => void;
    onMouseEnter?: () => void;
    onMouseLeave?: () => void;
    "aria-label"?: string;
    className?: string;
    type?: string;
    variant?: string;
  }) => (
    <button
      aria-label={ariaLabel}
      onClick={onClick}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
      type="button"
    >
      {children}
    </button>
  ),
}));

vi.mock("@shared/components/button", () => ({
  AppButton: ({
    children,
    onClick,
  }: {
    children: React.ReactNode;
    onClick?: () => void;
    className?: string;
    variant?: string;
  }) => (
    <button onClick={onClick} type="button">
      {children}
    </button>
  ),
}));

vi.mock("@shared/hooks/use-single-modal", () => ({
  useSingletonModal: vi.fn(),
}));

// ─── Regex Patterns ──────────────────────────────────────────────────────────

const DISCLAIMER_TEXT_REGEX = /Tax, title, and tags vary by state/i;

// ─── Default Props ────────────────────────────────────────────────────────────

const defaultProps = {
  apr: "5.9%",
  creditScore: "750",
  estimatedMonthlyPayment: "$450/mo",
  isOpen: true,
  onClose: vi.fn(),
  termLength: "72 months",
};

// ─── Tests ───────────────────────────────────────────────────────────────────

describe("EstimationModal", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Rendering", () => {
    it("renders the modal", () => {
      const { container } = render(<EstimationModal {...defaultProps} />);
      expect(container.firstChild).toBeInTheDocument();
    });

    it("renders the Summary heading", () => {
      render(<EstimationModal {...defaultProps} />);
      expect(screen.getByText("Summary")).toBeInTheDocument();
    });

    it("renders credit score label and value", () => {
      render(<EstimationModal {...defaultProps} />);
      expect(screen.getByText("Credit Score:")).toBeInTheDocument();
      expect(screen.getByText("750")).toBeInTheDocument();
    });

    it("renders APR label and value", () => {
      render(<EstimationModal {...defaultProps} />);
      expect(screen.getByText("APR:")).toBeInTheDocument();
      expect(screen.getByText("5.9%")).toBeInTheDocument();
    });

    it("renders term length label and value", () => {
      render(<EstimationModal {...defaultProps} />);
      expect(screen.getByText("Term Length:")).toBeInTheDocument();
      expect(screen.getByText("72 months")).toBeInTheDocument();
    });

    it("renders estimated monthly payment label and value", () => {
      render(<EstimationModal {...defaultProps} />);
      expect(screen.getByText("Estimated Monthly Payment:")).toBeInTheDocument();
      expect(screen.getByText("$450/mo")).toBeInTheDocument();
    });

    it("renders Get Prequalified button", () => {
      render(<EstimationModal {...defaultProps} />);
      expect(screen.getByText("Get Prequalified")).toBeInTheDocument();
    });

    it("renders Close button in footer", () => {
      render(<EstimationModal {...defaultProps} />);
      // There are multiple 'Close' texts — the button in header and footer
      const closeButtons = screen.getAllByText("Close");
      expect(closeButtons.length).toBeGreaterThanOrEqual(1);
    });

    it("renders disclaimer text", () => {
      render(<EstimationModal {...defaultProps} />);
      expect(screen.getByText(DISCLAIMER_TEXT_REGEX)).toBeInTheDocument();
    });
  });

  describe("Close interactions", () => {
    it("calls onClose when header Close button is clicked", () => {
      const onClose = vi.fn();
      render(<EstimationModal {...defaultProps} onClose={onClose} />);
      // Click first Close element (header button)
      const closeButtons = screen.getAllByText("Close");
      fireEvent.click(closeButtons[0]);
      expect(onClose).toHaveBeenCalled();
    });

    it("calls onClose when footer Close button is clicked", () => {
      const onClose = vi.fn();
      render(<EstimationModal {...defaultProps} onClose={onClose} />);
      const closeButtons = screen.getAllByText("Close");
      fireEvent.click(closeButtons.at(-1));
      expect(onClose).toHaveBeenCalled();
    });
  });

  describe("Mouse hover state", () => {
    it("applies hover style on close button mouseenter", () => {
      const { container } = render(<EstimationModal {...defaultProps} />);
      const closeBtn = container.querySelector("[aria-label='Close']") as HTMLElement;
      fireEvent.mouseEnter(closeBtn);
      // After mouseEnter, component updates state; verify it does not throw
      expect(closeBtn).toBeInTheDocument();
    });

    it("restores normal style on close button mouseleave", () => {
      const { container } = render(<EstimationModal {...defaultProps} />);
      const closeBtn = container.querySelector("[aria-label='Close']") as HTMLElement;
      fireEvent.mouseEnter(closeBtn);
      fireEvent.mouseLeave(closeBtn);
      expect(closeBtn).toBeInTheDocument();
    });
  });

  describe("isOpen prop", () => {
    it("still renders the modal regardless of isOpen (controlled by container)", () => {
      // EstimationModal is always rendered when called; visibility is controlled by parent
      const { container } = render(<EstimationModal {...defaultProps} isOpen={false} />);
      expect(container.firstChild).toBeInTheDocument();
    });
  });

  describe("Get Prequalified button", () => {
    it("clicking Get Prequalified does not throw", () => {
      render(<EstimationModal {...defaultProps} />);
      const btn = screen.getByText("Get Prequalified");
      expect(() => fireEvent.click(btn)).not.toThrow();
    });
  });
});
