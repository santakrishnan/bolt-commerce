import path from "node:path";
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  async headers() {
    return [
      {
        source: "/used-cars/:make/:model/:year/:trim/:vin",
        headers: [
          {
            key: "Cache-Control",
            value: "public, s-maxage=300, stale-while-revalidate=86400",
          },
        ],
      },
      {
        source: "/used-cars",
        headers: [
          { key: "Cache-Control", value: "public, s-maxage=60, stale-while-revalidate=300" },
        ],
      },
      {
        source: "/used-cars/:bodyType",
        headers: [
          { key: "Cache-Control", value: "public, s-maxage=60, stale-while-revalidate=300" },
        ],
      },
    ];
  },
  reactStrictMode: true,
  cacheComponents: true,
  cacheLife: {
    /**
     * Landing page data (hero stats, vehicle finder, vehicle count).
     * 15-min stale window, 15-min revalidation, 1-hour hard expiry.
     */
    landing: { stale: 900, revalidate: 900, expire: 3600 },
    /**
     * Visitor profile — shorter stale window for fresher personalisation.
     * 5-min stale, 10-min revalidation, 1-hour hard expiry.
     */
    profile: { stale: 300, revalidate: 600, expire: 3600 },
  },
  transpilePackages: ["@tfs-ucmp/ui", "@tfs-ucmp/ui-theme"],
  poweredByHeader: false,
  compress: true,
  output: "standalone",
  experimental: {
    optimizePackageImports: ["lucide-react"],
  },
  images: {
    formats: ["image/avif", "image/webp"],
    remotePatterns: [],
  },
  turbopack: {
    root: path.resolve(import.meta.dirname, "..", ".."),
  },
};

export default nextConfig;
