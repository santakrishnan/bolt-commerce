/**
 * @vitest-environment jsdom
 */

/**
 * Unit tests for UsedCarsDetails async server component.
 * @module app/used-cars/[[...params]]/views/__tests__/details
 */

import { render, screen } from "@arrow/vitest-config/test-utils";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { UsedCarsDetails } from "../details";

// =============================================================================
// MOCKS
// =============================================================================

vi.mock("@features/vdp/components", () => ({
  DealerInfoCard: ({ dealer }: any) => (
    <div data-dealer-id={dealer?.id} data-testid="dealer-info-card" />
  ),
  DealerNotesSection: ({ data }: any) => (
    <div data-description={data?.vehicleDescription} data-testid="dealer-notes-section" />
  ),
  VehicleDetailsTabs: ({
    features,
    featuresInitialCount,
    featuresTableView,
    historyData,
    priceHistory,
    pricingData,
    showInspectionSection,
    specs,
    vehicle,
    vehicleStatus,
  }: any) => (
    <div
      data-features-count={features?.length}
      data-features-initial={featuresInitialCount}
      data-features-table-view={String(featuresTableView)}
      data-history-vin={historyData?.vin}
      data-price-history-count={priceHistory?.length}
      data-pricing-current={pricingData?.currentPrice}
      data-show-inspection={String(showInspectionSection)}
      data-specs-count={specs?.length}
      data-testid="vehicle-details-tabs"
      data-vehicle-status-no-longer={String(vehicleStatus?.noLongerAvailable)}
      data-vehicle-vin={vehicle?.vin}
    />
  ),
  VehiclePDP: ({ slugParams, vehicle }: any) => (
    <div
      data-make={slugParams?.make}
      data-model={slugParams?.model}
      data-testid="vehicle-pdp"
      data-trim={slugParams?.trimSlug}
      data-vehicle-vin={vehicle?.vin}
      data-vin={slugParams?.vin}
      data-year={slugParams?.year}
    />
  ),
  VehicleRating: ({ distribution, rating, reviewCount, title }: any) => (
    <div
      data-distribution-count={distribution?.length}
      data-rating={rating}
      data-review-count={reviewCount}
      data-testid="vehicle-rating"
      data-title={title}
    />
  ),
}));

// =============================================================================
// FIXTURES
// =============================================================================

const mockVehicleDetail = {
  certified: false,
  condition: "used",
  dealer: { name: "Toyota of FW", location: "Fort Worth, TX", distance: "6.1 mi" },
  drivetrain: "FWD",
  exteriorColor: "White",
  fuelType: "Gasoline",
  highlights: ["Backup Camera"],
  id: "veh-001",
  images: ["/img/1.jpg"],
  inspected: true,
  inspectionPassed: true,
  interiorColor: "Black",
  make: "Toyota",
  miles: "12,345 mi",
  model: "Camry",
  mpg: "32/41",
  originalPrice: 35_000,
  price: 32_000,
  stock: "STK001",
  title: "2024 Toyota Camry XSE",
  transmission: "Automatic",
  trim: "XSE",
  vin: "VIN001",
  warranty: true,
  year: 2024,
};

const mockHistoryData = {
  damageReported: 0,
  lastOdometerReading: 12_345,
  ownerTypes: ["personal"],
  previousOwners: 1,
  repairsReported: 0,
  servicesOnRecord: 3,
  titleStatus: "Clean",
  vehicleDescription: "Great car, well maintained",
  vin: "VIN001",
};

const mockPriceHistory = [
  { change: -500, date: "2024-01-01", price: 32_000 },
  { change: -300, date: "2024-02-01", price: 31_700 },
];

const mockPricingData = {
  avgPrice: 33_000,
  currentPrice: 32_000,
  daysOnSite: 30,
  saves: 10,
  views: 200,
};

const mockVinData = {
  history: mockHistoryData,
  priceHistory: mockPriceHistory,
  pricing: mockPricingData,
  vehicle: mockVehicleDetail,
};

const mockRatingDistribution = [
  { count: 50, id: "5star", stars: 5 },
  { count: 10, id: "4star", stars: 4 },
];

const mockRating = {
  distribution: mockRatingDistribution,
  rating: 4.8,
  reviewCount: 60,
};

const mockVehicleStatus = {
  featuresTableView: false,
  historyReportPending: false,
  inspectionInProgress: false,
  limitedPhotos: false,
  noLongerAvailable: false,
};

const mockSpecs = [
  { key: "engine", label: "Engine", value: "2.5L 4-Cylinder" },
  { key: "drivetrain", label: "Drivetrain", value: "FWD" },
];

const mockFeatures = [
  { name: "Safety", features: ["Backup Camera", "Lane Assist"] },
  { name: "Tech", features: ["Apple CarPlay"] },
];

const mockVehicleData = {
  features: mockFeatures,
  featuresInitialCount: 3,
  rating: mockRating,
  specs: mockSpecs,
  vehicleStatus: mockVehicleStatus,
};

const mockDealerData = {
  dealer: {
    id: "toyota-fort-worth",
    name: "Toyota of Fort Worth",
    address: "Fort Worth, TX 76116",
    phone: "(817) 555-0123",
    hours: "Mon-Sat: 9:00 AM - 8:00 PM",
    rating: 4.8,
    dealershipImage: "/images/vdp/dealer.png",
  },
  vehicleDescription: "Well maintained vehicle with low miles.",
  vehicleImage: "/images/vdp/dealer_info.png",
};

// =============================================================================
// HELPERS
// =============================================================================

function buildProps(overrides: Partial<Parameters<typeof UsedCarsDetails>[0]> = {}) {
  return {
    dealerDataPromise: Promise.resolve(mockDealerData),
    make: "Toyota",
    model: "Camry",
    trim: "XSE",
    vehicleBundlePromise: Promise.resolve({
      vinData: mockVinData,
      vehicleData: mockVehicleData,
    }),
    vin: "VIN001",
    year: 2024,
    ...overrides,
  };
}

async function renderDetails(overrides: Partial<Parameters<typeof UsedCarsDetails>[0]> = {}) {
  const jsx = await UsedCarsDetails(buildProps(overrides));
  return render(jsx as React.ReactElement);
}

// =============================================================================
// TESTS
// =============================================================================

describe("UsedCarsDetails", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  // ---------------------------------------------------------------------------
  // Rendering — all child components present
  // ---------------------------------------------------------------------------
  describe("rendering", () => {
    it("renders VehiclePDP", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-pdp")).toBeInTheDocument();
    });

    it("renders VehicleDetailsTabs", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-details-tabs")).toBeInTheDocument();
    });

    it("renders VehicleRating", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-rating")).toBeInTheDocument();
    });

    it("renders DealerNotesSection", async () => {
      await renderDetails();
      expect(screen.getByTestId("dealer-notes-section")).toBeInTheDocument();
    });

    it("renders DealerInfoCard", async () => {
      await renderDetails();
      expect(screen.getByTestId("dealer-info-card")).toBeInTheDocument();
    });
  });

  // ---------------------------------------------------------------------------
  // trim → trimSlug mapping
  // ---------------------------------------------------------------------------
  describe("trim to trimSlug conversion", () => {
    it("passes trim value as trimSlug when trim is not '-'", async () => {
      await renderDetails({ trim: "XSE" });
      expect(screen.getByTestId("vehicle-pdp")).toHaveAttribute("data-trim", "XSE");
    });

    it("passes null trimSlug when trim equals '-'", async () => {
      await renderDetails({ trim: "-" });
      // React omits attributes when the value is null, so data-trim must be absent
      const pdp = screen.getByTestId("vehicle-pdp");
      expect(pdp).not.toHaveAttribute("data-trim");
    });
  });

  // ---------------------------------------------------------------------------
  // VehiclePDP slug params
  // ---------------------------------------------------------------------------
  describe("VehiclePDP slug params", () => {
    it("passes make to VehiclePDP", async () => {
      await renderDetails({ make: "Honda" });
      expect(screen.getByTestId("vehicle-pdp")).toHaveAttribute("data-make", "Honda");
    });

    it("passes model to VehiclePDP", async () => {
      await renderDetails({ model: "Civic" });
      expect(screen.getByTestId("vehicle-pdp")).toHaveAttribute("data-model", "Civic");
    });

    it("passes year to VehiclePDP", async () => {
      await renderDetails({ year: 2022 });
      expect(screen.getByTestId("vehicle-pdp")).toHaveAttribute("data-year", "2022");
    });

    it("passes vin to VehiclePDP slug params", async () => {
      await renderDetails({ vin: "TESTVIN123" });
      expect(screen.getByTestId("vehicle-pdp")).toHaveAttribute("data-vin", "TESTVIN123");
    });

    it("passes vehicle detail to VehiclePDP from vinData", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-pdp")).toHaveAttribute(
        "data-vehicle-vin",
        mockVehicleDetail.vin
      );
    });
  });

  // ---------------------------------------------------------------------------
  // VehicleDetailsTabs props forwarding
  // ---------------------------------------------------------------------------
  describe("VehicleDetailsTabs props forwarding", () => {
    it("passes features from vehicleData", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-details-tabs")).toHaveAttribute(
        "data-features-count",
        String(mockFeatures.length)
      );
    });

    it("passes featuresInitialCount from vehicleData", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-details-tabs")).toHaveAttribute(
        "data-features-initial",
        String(mockVehicleData.featuresInitialCount)
      );
    });

    it("passes featuresTableView from vehicleStatus", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-details-tabs")).toHaveAttribute(
        "data-features-table-view",
        String(mockVehicleStatus.featuresTableView)
      );
    });

    it("passes historyData from vinData", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-details-tabs")).toHaveAttribute(
        "data-history-vin",
        mockHistoryData.vin
      );
    });

    it("passes priceHistory from vinData", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-details-tabs")).toHaveAttribute(
        "data-price-history-count",
        String(mockPriceHistory.length)
      );
    });

    it("passes pricingData from vinData", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-details-tabs")).toHaveAttribute(
        "data-pricing-current",
        String(mockPricingData.currentPrice)
      );
    });

    it("always passes showInspectionSection=true", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-details-tabs")).toHaveAttribute(
        "data-show-inspection",
        "true"
      );
    });

    it("passes specs from vehicleData", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-details-tabs")).toHaveAttribute(
        "data-specs-count",
        String(mockSpecs.length)
      );
    });

    it("passes vehicle from vinData to tabs", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-details-tabs")).toHaveAttribute(
        "data-vehicle-vin",
        mockVehicleDetail.vin
      );
    });

    it("passes vehicleStatus from vehicleData", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-details-tabs")).toHaveAttribute(
        "data-vehicle-status-no-longer",
        String(mockVehicleStatus.noLongerAvailable)
      );
    });
  });

  // ---------------------------------------------------------------------------
  // VehicleRating props forwarding
  // ---------------------------------------------------------------------------
  describe("VehicleRating props forwarding", () => {
    it("passes rating from rating data", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-rating")).toHaveAttribute(
        "data-rating",
        String(mockRating.rating)
      );
    });

    it("passes reviewCount from rating data", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-rating")).toHaveAttribute(
        "data-review-count",
        String(mockRating.reviewCount)
      );
    });

    it("passes distribution from rating data", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-rating")).toHaveAttribute(
        "data-distribution-count",
        String(mockRatingDistribution.length)
      );
    });

    it("passes vehicle title as rating title", async () => {
      await renderDetails();
      expect(screen.getByTestId("vehicle-rating")).toHaveAttribute(
        "data-title",
        mockVehicleDetail.title
      );
    });

    it("passes empty string when vehicle title is undefined", async () => {
      const vehicleDetailNoTitle = { ...mockVehicleDetail, title: undefined };
      const customVinData = { ...mockVinData, vehicle: vehicleDetailNoTitle };
      await renderDetails({
        vehicleBundlePromise: Promise.resolve({
          vinData: customVinData,
          vehicleData: mockVehicleData,
        }),
      });
      expect(screen.getByTestId("vehicle-rating")).toHaveAttribute("data-title", "");
    });
  });

  // ---------------------------------------------------------------------------
  // DealerNotesSection and DealerInfoCard — dealer data forwarding
  // ---------------------------------------------------------------------------
  describe("dealer data forwarding", () => {
    it("passes full dealerData to DealerNotesSection", async () => {
      await renderDetails();
      expect(screen.getByTestId("dealer-notes-section")).toHaveAttribute(
        "data-description",
        mockDealerData.vehicleDescription
      );
    });

    it("passes dealer from dealerData to DealerInfoCard", async () => {
      await renderDetails();
      expect(screen.getByTestId("dealer-info-card")).toHaveAttribute(
        "data-dealer-id",
        mockDealerData.dealer.id
      );
    });
  });

  // ---------------------------------------------------------------------------
  // Parallel data fetching — both promises are awaited
  // ---------------------------------------------------------------------------
  describe("parallel data fetching", () => {
    it("resolves both vehicleBundlePromise and dealerDataPromise", async () => {
      const vehicleResolved = vi.fn().mockResolvedValue({
        vinData: mockVinData,
        vehicleData: mockVehicleData,
      });
      const dealerResolved = vi.fn().mockResolvedValue(mockDealerData);

      await UsedCarsDetails({
        dealerDataPromise: dealerResolved(),
        make: "Toyota",
        model: "Camry",
        trim: "XSE",
        vehicleBundlePromise: vehicleResolved(),
        vin: "VIN001",
        year: 2024,
      });

      expect(vehicleResolved).toHaveBeenCalledOnce();
      expect(dealerResolved).toHaveBeenCalledOnce();
    });
  });
});
