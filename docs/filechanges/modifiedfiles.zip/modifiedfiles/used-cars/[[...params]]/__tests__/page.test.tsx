/**
 * @vitest-environment jsdom
 */

/**
 * Unit tests for the UsedCars catch-all page.
 * @module app/used-cars/[[...params]]/__tests__/page
 */

import { render, screen } from "@arrow/vitest-config/test-utils";
import { beforeEach, describe, expect, it, vi } from "vitest";

// =============================================================================
// MOCKS  (must be hoisted before imports)
// =============================================================================

vi.mock("next/navigation", () => ({
  notFound: vi.fn(() => {
    throw new Error("NEXT_NOT_FOUND");
  }),
  redirect: vi.fn((url: string) => {
    throw new Error(`NEXT_REDIRECT:${url}`);
  }),
}));

vi.mock("next/headers", () => ({
  headers: vi.fn(),
}));

vi.mock("@config/messages/used-cars", () => ({
  getUsedCarsPageMetadata: vi.fn(() => ({
    title: "Mock Title",
    description: "Mock Description",
  })),
}));

vi.mock("@features/search/context", () => ({
  SearchWrapper: ({ initialBodyType, initialSearchQuery }: any) => (
    <div
      data-body-type={initialBodyType ?? ""}
      data-search-query={initialSearchQuery ?? ""}
      data-testid="search-wrapper"
    />
  ),
}));

vi.mock("@features/vdp/services/vdp-api", () => ({
  getDealerDetailsFromApi: vi.fn().mockResolvedValue({}),
  getVehicleBundleFromApi: vi.fn().mockResolvedValue({}),
}));

// Relative to this test file → resolves to [[...params]]/views/details
vi.mock("../views/details", () => ({
  UsedCarsDetails: ({
    dealerDataPromise,
    make,
    model,
    trim,
    vehicleBundlePromise,
    vin,
    year,
  }: any) => (
    <div
      data-dealer-promise={String(!!dealerDataPromise)}
      data-make={make}
      data-model={model}
      data-testid="used-cars-details"
      data-trim={trim}
      data-vehicle-promise={String(!!vehicleBundlePromise)}
      data-vin={vin}
      data-year={String(year)}
    />
  ),
}));

// =============================================================================
// DEFERRED IMPORTS  (after vi.mock calls)
// =============================================================================

import { getUsedCarsPageMetadata } from "@config/messages/used-cars";
import { getDealerDetailsFromApi, getVehicleBundleFromApi } from "@features/vdp/services/vdp-api";
import { headers } from "next/headers";
import { notFound, redirect } from "next/navigation";
import UsedCarsPage, { generateMetadata } from "../page";

// =============================================================================
// CONSTANTS
// =============================================================================

/** Valid 17-character VIN (A-HJ-NPR-Z0-9, no I/O/Q). */
const VALID_VIN = "1HGBH41JXMN109186";

/** Canonical details segments (all lowercase / uppercase VIN). */
const DETAILS_SEGMENTS = ["details", "toyota", "camry", "xse", "2024", VALID_VIN] as string[];

// =============================================================================
// HELPERS
// =============================================================================

/** Build a minimal Headers-like stub from a plain map. */
function makeHeaders(map: Record<string, string | null> = {}): Headers {
  return {
    get: (name: string) => map[name] ?? null,
  } as unknown as Headers;
}

/** Wrap `params` and `searchParams` in promises as Next.js provides them. */
function buildProps(
  segments: string[] | undefined,
  query?: string
): Parameters<typeof UsedCarsPage>[0] {
  return {
    params: Promise.resolve({ params: segments }),
    searchParams: Promise.resolve({ q: query }),
  };
}

async function renderPage(segments?: string[], query?: string) {
  const jsx = await UsedCarsPage(buildProps(segments, query));
  return render(jsx as React.ReactElement);
}

// =============================================================================
// TESTS
// =============================================================================

describe("UsedCarsPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    // Default headers: a plain host with no proto override
    (headers as ReturnType<typeof vi.fn>).mockResolvedValue(
      makeHeaders({ host: "localhost:3000" })
    );
  });

  // ---------------------------------------------------------------------------
  // resolveRoute — notFound branch
  // ---------------------------------------------------------------------------
  describe("resolveRoute — notFound", () => {
    it("calls notFound for a malformed details URL (too few segments)", async () => {
      // "details" alone → only 1 segment, parseDetailsRoute needs 6 → returns null
      await expect(renderPage(["details"])).rejects.toThrow("NEXT_NOT_FOUND");
      expect(notFound).toHaveBeenCalledOnce();
    });

    it("calls notFound for a malformed details URL (invalid VIN)", async () => {
      // VIN too short → schema fails
      await expect(
        renderPage(["details", "toyota", "camry", "xse", "2024", "BADVIN"])
      ).rejects.toThrow("NEXT_NOT_FOUND");
      expect(notFound).toHaveBeenCalledOnce();
    });

    it("calls notFound for a malformed details URL (bad year)", async () => {
      await expect(
        renderPage(["details", "toyota", "camry", "xse", "abcd", VALID_VIN])
      ).rejects.toThrow("NEXT_NOT_FOUND");
      expect(notFound).toHaveBeenCalledOnce();
    });
  });

  // ---------------------------------------------------------------------------
  // generateMetadata
  // ---------------------------------------------------------------------------
  describe("generateMetadata", () => {
    it("calls notFound when segments are invalid", async () => {
      await expect(
        generateMetadata({
          params: Promise.resolve({ params: ["details"] }),
          searchParams: Promise.resolve({}),
        })
      ).rejects.toThrow("NEXT_NOT_FOUND");
      expect(notFound).toHaveBeenCalledOnce();
    });

    it("returns metadata for SRP route (no segments)", async () => {
      const meta = await generateMetadata({
        params: Promise.resolve({ params: undefined }),
        searchParams: Promise.resolve({}),
      });
      expect(getUsedCarsPageMetadata).toHaveBeenCalledOnce();
      expect(meta).toEqual({
        title: "Mock Title",
        description: "Mock Description",
        openGraph: { title: "Mock Title", type: "website" },
      });
    });

    it("returns metadata for SRP route (make filter)", async () => {
      const meta = await generateMetadata({
        params: Promise.resolve({ params: ["toyota"] }),
        searchParams: Promise.resolve({}),
      });
      expect(getUsedCarsPageMetadata).toHaveBeenCalledOnce();
      expect(meta.title).toBe("Mock Title");
      expect(meta.openGraph).toMatchObject({ title: "Mock Title" });
    });

    it("returns metadata for a valid details route", async () => {
      const meta = await generateMetadata({
        params: Promise.resolve({ params: DETAILS_SEGMENTS }),
        searchParams: Promise.resolve({}),
      });
      expect(getUsedCarsPageMetadata).toHaveBeenCalledOnce();
      expect(meta).toMatchObject({
        title: "Mock Title",
        description: "Mock Description",
        openGraph: { title: "Mock Title", type: "website" },
      });
    });
  });

  // ---------------------------------------------------------------------------
  // Canonical redirect
  // ---------------------------------------------------------------------------
  describe("canonical redirect", () => {
    it("redirects when SRP path has wrong casing (segments uppercase)", async () => {
      // "TOYOTA" → currentPath "/used-cars/TOYOTA" vs canonical "/used-cars/toyota"
      await expect(renderPage(["TOYOTA"])).rejects.toThrow("NEXT_REDIRECT:/used-cars/toyota");
      expect(redirect).toHaveBeenCalledWith("/used-cars/toyota");
    });

    it("redirects when details path has wrong casing in make segment", async () => {
      const upper = ["details", "TOYOTA", "camry", "xse", "2024", VALID_VIN];
      // currentPath: /used-cars/details/TOYOTA/camry/xse/2024/<vin>
      // canonicalPath: /used-cars/details/toyota/camry/xse/2024/<vin>
      await expect(renderPage(upper)).rejects.toThrow(
        `NEXT_REDIRECT:/used-cars/details/toyota/camry/xse/2024/${VALID_VIN}`
      );
      expect(redirect).toHaveBeenCalledOnce();
    });

    it("does NOT redirect when SRP path already matches canonical", async () => {
      await renderPage(["toyota"]);
      expect(redirect).not.toHaveBeenCalled();
    });

    it("does NOT redirect when SRP path is root (no segments)", async () => {
      await renderPage(undefined);
      expect(redirect).not.toHaveBeenCalled();
    });

    it("does NOT redirect when details path matches canonical", async () => {
      await renderPage(DETAILS_SEGMENTS);
      expect(redirect).not.toHaveBeenCalled();
    });
  });

  // ---------------------------------------------------------------------------
  // SRP branch — SearchWrapper rendering
  // ---------------------------------------------------------------------------
  describe("SRP route", () => {
    it("renders SearchWrapper", async () => {
      await renderPage(undefined);
      expect(screen.getByTestId("search-wrapper")).toBeInTheDocument();
    });

    it("does NOT render UsedCarsDetails for SRP", async () => {
      await renderPage(undefined);
      expect(screen.queryByTestId("used-cars-details")).not.toBeInTheDocument();
    });

    it("passes initialBodyType to SearchWrapper when bodyType segment present", async () => {
      await renderPage(["suv"]);
      expect(screen.getByTestId("search-wrapper")).toHaveAttribute("data-body-type", "suv");
    });

    it("passes undefined initialBodyType when route has no bodyType", async () => {
      await renderPage(["toyota"]);
      // When bodyType is undefined the mock renders it as empty string
      expect(screen.getByTestId("search-wrapper")).toHaveAttribute("data-body-type", "");
    });

    it("passes initialSearchQuery to SearchWrapper", async () => {
      await renderPage(undefined, "hybrid camry");
      expect(screen.getByTestId("search-wrapper")).toHaveAttribute(
        "data-search-query",
        "hybrid camry"
      );
    });

    it("passes empty string when no search query provided", async () => {
      await renderPage(undefined);
      expect(screen.getByTestId("search-wrapper")).toHaveAttribute("data-search-query", "");
    });
  });

  // ---------------------------------------------------------------------------
  // Details branch — UsedCarsDetails rendering
  // ---------------------------------------------------------------------------
  describe("details route", () => {
    it("renders UsedCarsDetails", async () => {
      await renderPage(DETAILS_SEGMENTS);
      expect(screen.getByTestId("used-cars-details")).toBeInTheDocument();
    });

    it("does NOT render SearchWrapper for details", async () => {
      await renderPage(DETAILS_SEGMENTS);
      expect(screen.queryByTestId("search-wrapper")).not.toBeInTheDocument();
    });

    it("passes make to UsedCarsDetails", async () => {
      await renderPage(DETAILS_SEGMENTS);
      expect(screen.getByTestId("used-cars-details")).toHaveAttribute("data-make", "toyota");
    });

    it("passes model to UsedCarsDetails", async () => {
      await renderPage(DETAILS_SEGMENTS);
      expect(screen.getByTestId("used-cars-details")).toHaveAttribute("data-model", "camry");
    });

    it("passes trim to UsedCarsDetails", async () => {
      await renderPage(DETAILS_SEGMENTS);
      expect(screen.getByTestId("used-cars-details")).toHaveAttribute("data-trim", "xse");
    });

    it("passes year to UsedCarsDetails", async () => {
      await renderPage(DETAILS_SEGMENTS);
      expect(screen.getByTestId("used-cars-details")).toHaveAttribute("data-year", "2024");
    });

    it("passes vin to UsedCarsDetails", async () => {
      await renderPage(DETAILS_SEGMENTS);
      expect(screen.getByTestId("used-cars-details")).toHaveAttribute("data-vin", VALID_VIN);
    });

    it("passes vehicleBundlePromise to UsedCarsDetails", async () => {
      await renderPage(DETAILS_SEGMENTS);
      expect(screen.getByTestId("used-cars-details")).toHaveAttribute(
        "data-vehicle-promise",
        "true"
      );
    });

    it("passes dealerDataPromise to UsedCarsDetails", async () => {
      await renderPage(DETAILS_SEGMENTS);
      expect(screen.getByTestId("used-cars-details")).toHaveAttribute(
        "data-dealer-promise",
        "true"
      );
    });

    it("calls getVehicleBundleFromApi with the VIN", async () => {
      await renderPage(DETAILS_SEGMENTS);
      expect(getVehicleBundleFromApi).toHaveBeenCalledOnce();
      expect(getVehicleBundleFromApi).toHaveBeenCalledWith(
        VALID_VIN,
        expect.objectContaining({ baseUrl: expect.any(String) })
      );
    });

    it("calls getDealerDetailsFromApi with the VIN", async () => {
      await renderPage(DETAILS_SEGMENTS);
      expect(getDealerDetailsFromApi).toHaveBeenCalledOnce();
      expect(getDealerDetailsFromApi).toHaveBeenCalledWith(
        VALID_VIN,
        expect.objectContaining({ baseUrl: expect.any(String) })
      );
    });
  });

  // ---------------------------------------------------------------------------
  // getRequestOrigin — baseUrl construction
  // ---------------------------------------------------------------------------
  describe("getRequestOrigin", () => {
    it("uses x-forwarded-host over host", async () => {
      (headers as ReturnType<typeof vi.fn>).mockResolvedValue(
        makeHeaders({
          "x-forwarded-host": "forwarded.example.com",
          host: "origin.example.com",
          "x-forwarded-proto": "https",
        })
      );
      await renderPage(DETAILS_SEGMENTS);
      expect(getVehicleBundleFromApi).toHaveBeenCalledWith(
        VALID_VIN,
        expect.objectContaining({ baseUrl: "https://forwarded.example.com" })
      );
    });

    it("falls back to host when x-forwarded-host is absent", async () => {
      (headers as ReturnType<typeof vi.fn>).mockResolvedValue(makeHeaders({ host: "myhost.com" }));
      await renderPage(DETAILS_SEGMENTS);
      expect(getVehicleBundleFromApi).toHaveBeenCalledWith(
        VALID_VIN,
        expect.objectContaining({ baseUrl: "http://myhost.com" })
      );
    });

    it("uses x-forwarded-proto in the origin", async () => {
      (headers as ReturnType<typeof vi.fn>).mockResolvedValue(
        makeHeaders({ host: "secure.com", "x-forwarded-proto": "https" })
      );
      await renderPage(DETAILS_SEGMENTS);
      expect(getVehicleBundleFromApi).toHaveBeenCalledWith(
        VALID_VIN,
        expect.objectContaining({ baseUrl: "https://secure.com" })
      );
    });

    it("defaults proto to 'http' when x-forwarded-proto is absent", async () => {
      (headers as ReturnType<typeof vi.fn>).mockResolvedValue(makeHeaders({ host: "plain.com" }));
      await renderPage(DETAILS_SEGMENTS);
      expect(getVehicleBundleFromApi).toHaveBeenCalledWith(
        VALID_VIN,
        expect.objectContaining({ baseUrl: "http://plain.com" })
      );
    });

    it("throws when neither x-forwarded-host nor host is present", async () => {
      (headers as ReturnType<typeof vi.fn>).mockResolvedValue(makeHeaders({}));
      await expect(renderPage(DETAILS_SEGMENTS)).rejects.toThrow(
        "Unable to resolve request host for VDP API fetch"
      );
    });
  });

  // ---------------------------------------------------------------------------
  // buildProxyHeaders — passthrough header forwarding
  // ---------------------------------------------------------------------------
  describe("buildProxyHeaders", () => {
    it("forwards all passthrough headers when all are present", async () => {
      (headers as ReturnType<typeof vi.fn>).mockResolvedValue(
        makeHeaders({
          host: "localhost:3000",
          cookie: "session=abc",
          "user-agent": "TestBrowser/1.0",
          "accept-language": "en-US",
          referer: "https://example.com",
        })
      );
      await renderPage(DETAILS_SEGMENTS);
      expect(getVehicleBundleFromApi).toHaveBeenCalledWith(
        VALID_VIN,
        expect.objectContaining({
          headers: {
            cookie: "session=abc",
            "user-agent": "TestBrowser/1.0",
            "accept-language": "en-US",
            referer: "https://example.com",
          },
        })
      );
    });

    it("omits headers that are not present", async () => {
      (headers as ReturnType<typeof vi.fn>).mockResolvedValue(
        makeHeaders({ host: "localhost:3000", cookie: "tok=xyz" })
      );
      await renderPage(DETAILS_SEGMENTS);
      const call = (getVehicleBundleFromApi as ReturnType<typeof vi.fn>).mock.calls[0];
      const opts = call?.[1];
      expect(opts.headers).toEqual({ cookie: "tok=xyz" });
      expect(opts.headers).not.toHaveProperty("user-agent");
      expect(opts.headers).not.toHaveProperty("accept-language");
      expect(opts.headers).not.toHaveProperty("referer");
    });

    it("passes empty headers object when no passthrough headers are present", async () => {
      (headers as ReturnType<typeof vi.fn>).mockResolvedValue(
        makeHeaders({ host: "localhost:3000" })
      );
      await renderPage(DETAILS_SEGMENTS);
      const call = (getVehicleBundleFromApi as ReturnType<typeof vi.fn>).mock.calls[0];
      const opts = call?.[1];
      expect(opts.headers).toEqual({});
    });
  });
});
