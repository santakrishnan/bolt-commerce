/** Shared type definitions for My Garage components. */

import type { Vehicle } from "@shared/types";
import type { ReactNode } from "react";

export interface SavedVehicleCardProps {
  id: number | string;
  imageUrl: string;
  miles: string;
  onClick?: () => void;
  onRemove?: () => void;
  price: string;
  title: string;
}

export interface RecentSearchCardProps {
  disabled?: boolean;
  highlighted?: boolean;
  id: string;
  onRemove?: () => void;
  search: string;
  url: string;
}

export interface FinancingCardProps {
  daysRemaining?: number;
  onBuyOnline?: () => void;
  onGetPrequalified?: () => void;
  prequalified: boolean;
}

export interface TradeOfferCardProps {
  expiresIn?: string;
  hasSubmittedTradeIn: boolean;
  imageUrl?: string;
  miles?: string;
  onGetEstimate?: () => void;
  onShopWithTradeIn?: () => void;
  price?: string;
  title?: string;
}

export interface TestDriveCardProps {
  dealershipName?: string;
  onBookAppointment?: () => void;
  onScheduleTestDrive?: () => void;
  scheduled: boolean;
}

export interface MyGarageCardsProps {
  financing: FinancingCardProps;
  onSavedVehicleClick?: (id: number | string) => void;
  recentSearches: RecentSearchCardProps[];
  savedVehicles: SavedVehicleCardProps[];
  testDrive?: TestDriveCardProps;
  tradeOffer: TradeOfferCardProps;
}

export interface MyGarageClientProps {
  /** Cars specifically for the "Because You Viewed" section */
  becauseViewedCars?: Vehicle[];
  cars: Vehicle[];
  children?: ReactNode;
  /** Days remaining for prequalification offer (out of 30) */
  daysRemaining?: number;
  /** Customer trade-in submission status */
  hasTradeInSubmitted?: boolean;
  /** Customer prequalification status */
  isPreQualified?: boolean;
}
