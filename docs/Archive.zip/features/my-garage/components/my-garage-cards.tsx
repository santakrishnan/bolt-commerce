"use client";

// Scrollable cards for My Garage
/* eslint-disable */
/* biome:disable */

import { Button, ScrollArea } from "@tfs-ucmp/ui";
import Image from "next/image";
import type { FC } from "react";
import { Fragment } from "react";
import {
  FinancingCard,
  RecentSearchCard,
  SavedVehicleCard,
  TestDriveCard,
  TradeOfferCard,
} from "./my-garage-sub-cards";
import type { MyGarageCardsProps } from "./types";

export type { GarageInfoCardProps } from "@features/vehicle-card";

export const MyGarageCards: FC<
  MyGarageCardsProps & {
    onRemoveSavedVehicle?: (id: number | string) => void;
    onRemoveSearch?: (id: string) => void;
    onClearAllSearches?: () => void;
  }
> = ({
  savedVehicles,
  recentSearches,
  financing,
  tradeOffer,
  testDrive,
  onRemoveSavedVehicle,
  onRemoveSearch,
  onClearAllSearches,
  onSavedVehicleClick,
}) => (
  <div className="flex w-full flex-col gap-4 lg:flex-row">
    <div className="flex min-w-65 flex-1 flex-col rounded-md bg-white py-4 shadow">
      <div className="mb-6 flex items-center justify-between px-4 pb-0">
        <div className="flex items-center gap-2 font-semibold text-sm">
          <Image
            alt="Saved Vehicles"
            className="shrink-0"
            height={20}
            src="/images/garage/heart-filled.svg"
            width={20}
          />
          <span className="font-semibold text-[length:var(--font-size-xl)] text-[var(--Core-surfaces-foreground,#0A0A0A)] leading-[115%] [font-family:var(--font-family)] [leading-trim:both] [text-edge:cap]">
            Saved Vehicles ({savedVehicles.length})
          </span>
        </div>
        <Button
          className="h-auto p-0 font-normal text-[length:var(--font-size-sm,14px)] text-[var(--Core-surfaces-foreground,#0A0A0A)] leading-[125%] tracking-[-0.14px] underline [font-family:var(--font-family)]"
          variant="link"
        >
          View All
        </Button>
      </div>
      <div className="mx-4 mt-[23px] h-px bg-black opacity-10" />
      <div className="py-2">
        <div className="relative">
          <ScrollArea className="h-78 px-4 pr-3">
            {savedVehicles.length === 0 ? (
              <div className="flex h-full items-center justify-center py-10 text-center text-gray-400 text-sm">
                No saved vehicles yet. Click the heart icon on a vehicle to save it.
              </div>
            ) : (
              savedVehicles.map((props, idx) => (
                <Fragment key={props.id}>
                  <SavedVehicleCard
                    {...props}
                    onClick={onSavedVehicleClick ? () => onSavedVehicleClick(props.id) : undefined}
                    onRemove={
                      onRemoveSavedVehicle ? () => onRemoveSavedVehicle(props.id) : undefined
                    }
                  />
                  {idx !== savedVehicles.length - 1 && (
                    <div className="h-px w-full bg-black opacity-10" />
                  )}
                </Fragment>
              ))
            )}
          </ScrollArea>
          <div
            className="pointer-events-none absolute bottom-0 left-0 z-10 h-8 w-full"
            style={{ background: "linear-gradient(to bottom, #ffffff00 0%, #ffffff 100%)" }}
          />
        </div>
      </div>
    </div>
    <div className="flex min-w-65 flex-1 flex-col rounded-lg bg-white py-4 shadow">
      <div className="mb-6 flex items-center justify-between px-4 pb-0">
        <div className="flex items-center gap-2 font-semibold text-sm">
          <Image
            alt="Recent Searches"
            className="shrink-0"
            height={20}
            src="/images/garage/stars-icon.svg"
            width={20}
          />
          <span className="font-semibold text-[length:var(--font-size-xl)] text-[var(--Core-surfaces-foreground,#0A0A0A)] leading-[115%] [font-family:var(--font-family)] [leading-trim:both] [text-edge:cap]">
            Recent Searches ({recentSearches.length})
          </span>
        </div>
        {recentSearches.length > 0 && onClearAllSearches && (
          <Button
            className="h-auto p-0 font-normal text-[length:var(--Font-Size-Scale---font-size-sm,14px)] text-[var(--Core-surfaces-foreground,#0A0A0A)] leading-[125%] tracking-[-0.14px] underline [font-family:var(--font-family)]"
            onClick={onClearAllSearches}
            variant="link"
          >
            Clear All
          </Button>
        )}
      </div>
      <div className="mx-4 h-px bg-black opacity-10" />
      <div className="py-2">
        <div className="relative">
          <ScrollArea className="h-55 px-4 pr-3">
            {recentSearches.length === 0 ? (
              <div className="flex h-full items-center justify-center py-10 text-center text-gray-400 text-sm">
                No recent searches yet. Try searching for a vehicle above.
              </div>
            ) : (
              recentSearches.map((props, idx) => (
                <Fragment key={props.id}>
                  <RecentSearchCard
                    {...props}
                    onRemove={onRemoveSearch ? () => onRemoveSearch(props.id) : undefined}
                  />
                  {idx !== recentSearches.length - 1 && (
                    <div className="h-px w-full bg-black opacity-10" />
                  )}
                </Fragment>
              ))
            )}
          </ScrollArea>
          <div
            className="pointer-events-none absolute bottom-0 left-0 z-10 h-8 w-full"
            style={{ background: "linear-gradient(to bottom, #ffffff00 0%, #ffffff 100%)" }}
          />
        </div>
      </div>
    </div>
    <div className="flex min-w-65 flex-1 flex-col gap-4">
      <FinancingCard {...financing} />
      <TradeOfferCard {...tradeOffer} />
      {testDrive && <TestDriveCard {...testDrive} />}
    </div>
  </div>
);
