"use client";

import { buildUsedCarsPath } from "@config/routes";
import { useFavorites } from "@features/favorites";
import { MyGarageCards } from "@features/my-garage/components/my-garage-cards";
import { TestDriveBanner } from "@features/my-garage/components/test-drive-banner";
import { getBadgeType, parseDealerInfo } from "@features/my-garage/lib/helpers";
import { useSearchHistory } from "@features/search";
import type { Vehicle } from "@features/search/lib/mock-vehicles";
import { getVehicleEstimation } from "@features/search/lib/mock-vehicles";
import { CarCard } from "@features/vehicle-card";
import { VehiclePreviewModal } from "@features/vehicle-preview";
import { Heading } from "@tfs-ucmp/ui";
import { useCallback, useEffect, useMemo, useState } from "react";

import type { MyGarageClientProps } from "./types";

export function MyGarageClient({
  cars,
  becauseViewedCars,
  children,
  isPreQualified = false,
  hasTradeInSubmitted = false,
  daysRemaining = 27,
}: MyGarageClientProps) {
  const [previewVin, setPreviewVin] = useState<string | null>(null);
  const { savedVins, removeVehicle } = useFavorites();
  const { searches, removeSearch, clearAll: clearAllSearches } = useSearchHistory();

  useEffect(() => {
    setPreviewVin(null);
  }, []);

  // Memoize derived state to avoid recomputation on every render
  const recentSearchCards = useMemo(
    () =>
      searches.map((entry) => ({
        id: entry.id,
        search: entry.query,
        url: entry.url,
      })),
    [searches]
  );

  // Memoize saved vehicles lookup
  const savedVehicles = useMemo(
    () =>
      savedVins
        .map((vin) => cars.find((c) => c.vin === vin))
        .filter((car): car is Vehicle => car !== undefined)
        .map((car) => ({
          id: car.vin,
          imageUrl: Array.isArray(car.image) ? (car.image[0] ?? "") : car.image,
          title: car.title,
          price: `$${car.price.toLocaleString()}`,
          miles: car.odometer,
        })),
    [savedVins, cars]
  );

  // Memoize cars with price drops for recent price drop section
  const priceDropCars = useMemo(() => cars.filter((car) => car.oldPrice), [cars]);

  // Use useCallback for stable event handler references
  const handleRemoveSavedVehicle = useCallback(
    (id: number | string) => {
      removeVehicle(String(id));
    },
    [removeVehicle]
  );

  // Find the selected vehicle for the modal
  const selectedVehicle = previewVin ? cars.find((c) => c.vin === previewVin) : undefined;

  return (
    <div className="relative min-h-screen">
      {/* Background layer with image and gradient overlay */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: "url('/images/garage/background.svg')",
          backgroundSize: "cover",
          backgroundPosition: "center top",
          backgroundRepeat: "no-repeat",
        }}
      />
      {/* Gradient overlay: solid #F5F5F5 at top only, transparent below to show background image */}
      <div
        className="pointer-events-none absolute inset-0 z-0"
        style={{
          background:
            "linear-gradient(to bottom, #F5F5F5 0%, #F5F5F5 350px, rgba(245,245,245,0) 600px, rgba(245,245,245,0) 100%)",
        }}
      />
      {/* Content */}
      <div className="relative z-0">
        <Heading
          className="mx-auto mb-8 w-full max-w-(--container-2xl) px-4 pt-8 text-left text-lg sm:px-6 md:text-lg lg:px-20"
          level={2}
          weight="semibold"
        >
          My Garage
        </Heading>
        <div className="mx-auto mb-10 w-full max-w-(--container-2xl) px-4 sm:px-6 lg:px-20">
          <MyGarageCards
            financing={{
              prequalified: isPreQualified,
              daysRemaining,
            }}
            onClearAllSearches={clearAllSearches}
            onRemoveSavedVehicle={handleRemoveSavedVehicle}
            onRemoveSearch={removeSearch}
            onSavedVehicleClick={(id) => setPreviewVin(String(id))}
            recentSearches={recentSearchCards}
            savedVehicles={savedVehicles}
            tradeOffer={{
              imageUrl: hasTradeInSubmitted ? "/images/vehicles/offer.png" : undefined,
              title: hasTradeInSubmitted ? "2019 Audi A7" : undefined,
              price: hasTradeInSubmitted ? "$15,500" : undefined,
              miles: hasTradeInSubmitted ? "68,150 miles" : undefined,
              expiresIn: hasTradeInSubmitted ? "2 days" : undefined,
              hasSubmittedTradeIn: hasTradeInSubmitted,
            }}
          />
          {selectedVehicle &&
            (() => {
              const dealerInfo = parseDealerInfo(selectedVehicle.miles);
              const vdpUrl =
                selectedVehicle.make &&
                selectedVehicle.model &&
                selectedVehicle.variant &&
                selectedVehicle.year &&
                selectedVehicle.vin
                  ? buildUsedCarsPath({
                      type: "details",
                      make: selectedVehicle.make,
                      model: selectedVehicle.model,
                      trim: selectedVehicle.variant,
                      year: selectedVehicle.year,
                      vin: selectedVehicle.vin,
                    })
                  : "#";

              return (
                <VehiclePreviewModal
                  isOpen={!!previewVin}
                  onClose={() => setPreviewVin(null)}
                  vdpUrl={vdpUrl}
                  vehicle={{
                    year: selectedVehicle.year,
                    make: selectedVehicle.make,
                    model: selectedVehicle.model,
                    price: selectedVehicle.price,
                    originalPrice: selectedVehicle.oldPrice ?? 0,
                    condition: selectedVehicle.labels[0] ?? "",
                    warranty: false,
                    inspected: false,
                    miles: selectedVehicle.odometer,
                    drivetrain: "",
                    mpg: "",
                    stock: "",
                    vin: selectedVehicle.vin,
                    exterior: selectedVehicle.extColorName,
                    exteriorColorCode: selectedVehicle.extColorCode,
                    interior: selectedVehicle.intColorName,
                    interiorColorCode: selectedVehicle.intColorCode,
                    dealer: dealerInfo.dealerName,
                    location: dealerInfo.dealerName,
                    distance: dealerInfo.distance,
                    images: Array.isArray(selectedVehicle.image)
                      ? selectedVehicle.image
                      : [selectedVehicle.image],
                    features: [],
                  }}
                  vin={selectedVehicle.vin}
                />
              );
            })()}
        </div>

        <Heading
          className="mx-auto mb-6 w-full max-w-(--container-2xl) px-4 text-left text-xl sm:px-6 md:text-xl lg:px-20"
          level={2}
          weight="semibold"
        >
          Best Matches for you
        </Heading>
        <div className="mx-auto grid max-w-(--container-2xl) grid-cols-1 gap-4 px-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-3 lg:px-20 xl:grid-cols-4">
          {cars.slice(0, 12).map((car) => {
            const firstLabel = car.labels[0];
            const { dealerName, distance } = parseDealerInfo(car.miles);
            const estimation = getVehicleEstimation(car);
            const badgeType = getBadgeType(firstLabel);

            return (
              <CarCard
                activeFilters={[]}
                badge={badgeType && firstLabel ? { type: badgeType, text: firstLabel } : undefined}
                carImage={car.image}
                carName={car.title}
                dealerName={dealerName}
                distance={distance}
                enablePreviewModal={false}
                estimatedPayment={`Est. ${estimation.estimatedMonthlyPayment}/mo`}
                estimation={estimation}
                exteriorColor="White"
                exteriorColorHex="#FFFFFF"
                features={{ warranty: true, inspected: true, oneOwner: car.owners === 1 }}
                interiorColor="Black"
                interiorColorHex="#000000"
                key={car.id}
                make={car.make}
                matchPercentage={car.match > 0 ? car.match.toString() : undefined}
                mileage={car.odometer}
                model={car.model}
                onSearch={Function.prototype as () => void}
                owners={car.owners}
                price={`$${car.price.toLocaleString()}`}
                variant={car.variant}
                vin={car.vin}
                wasPrice={car.oldPrice ? `$${car.oldPrice.toLocaleString()}` : undefined}
                year={car.year}
              />
            );
          })}
        </div>

        {children}

        <div className="mx-auto mt-20 mb-10 w-full">
          <TestDriveBanner />
        </div>
        {/* Because You Viewed Toyota Camry */}
        <Heading
          className="mx-auto mb-8 w-full max-w-(--container-2xl) px-4 text-left text-xl sm:px-6 md:text-xl lg:px-20"
          level={2}
          weight="semibold"
        >
          Because You Viewed Toyota Camry
        </Heading>
        <div className="mx-auto mb-16 grid max-w-(--container-2xl) grid-cols-1 gap-4 px-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-3 lg:px-20 xl:grid-cols-4">
          {(becauseViewedCars ?? cars).slice(0, 4).map((car) => {
            const badgeLabel = car.labels[0];
            const { dealerName, distance } = parseDealerInfo(car.miles);
            const estimation = getVehicleEstimation(car);
            const badgeType = getBadgeType(badgeLabel);

            return (
              <CarCard
                activeFilters={[]}
                badge={
                  badgeType && badgeLabel
                    ? {
                        type: badgeType,
                        text: badgeLabel,
                      }
                    : undefined
                }
                carImage={car.image}
                carName={car.title}
                dealerName={dealerName}
                distance={distance}
                enablePreviewModal={false}
                estimatedPayment={`Est. ${estimation.estimatedMonthlyPayment}/mo`}
                estimation={estimation}
                exteriorColor="White"
                exteriorColorHex="#FFFFFF"
                features={{ warranty: true, inspected: true, oneOwner: car.owners === 1 }}
                interiorColor="Black"
                interiorColorHex="#000000"
                key={car.id}
                make={car.make}
                matchPercentage={car.match > 0 ? String(car.match) : undefined}
                mileage={car.odometer}
                model={car.model}
                onSearch={Function.prototype as () => void}
                owners={car.owners}
                price={`$${car.price.toLocaleString()}`}
                variant={car.variant}
                vin={car.vin}
                wasPrice={car.oldPrice ? `$${car.oldPrice.toLocaleString()}` : undefined}
                year={car.year}
              />
            );
          })}
        </div>

        {/* Recent Price Drop - only cars with oldPrice */}
        <Heading
          className="mx-auto mb-8 w-full max-w-(--container-2xl) px-4 text-left text-xl sm:px-6 md:text-xl lg:px-20"
          level={2}
          weight="semibold"
        >
          Recent Price Drop
        </Heading>
        <div className="mx-auto grid max-w-(--container-2xl) grid-cols-1 gap-4 px-4 pb-16 sm:grid-cols-2 sm:px-6 lg:grid-cols-3 lg:px-20 xl:grid-cols-4">
          {priceDropCars.slice(0, 4).map((car) => {
            const { dealerName, distance } = parseDealerInfo(car.miles);
            const estimation = getVehicleEstimation(car);

            return (
              <CarCard
                activeFilters={[]}
                badge={{ type: "priceDrop", text: "Price Drop" }}
                carImage={car.image}
                carName={car.title}
                dealerName={dealerName}
                distance={distance}
                enablePreviewModal={false}
                estimatedPayment={`Est. ${estimation.estimatedMonthlyPayment}/mo`}
                estimation={estimation}
                exteriorColor="White"
                exteriorColorHex="#FFFFFF"
                features={{ warranty: true, inspected: true, oneOwner: car.owners === 1 }}
                interiorColor="Black"
                interiorColorHex="#000000"
                key={car.id}
                make={car.make}
                matchPercentage={car.match > 0 ? String(car.match) : undefined}
                mileage={car.odometer}
                model={car.model}
                onSearch={Function.prototype as () => void}
                owners={car.owners}
                price={`$${car.price.toLocaleString()}`}
                variant={car.variant}
                vin={car.vin}
                wasPrice={`$${car.oldPrice?.toLocaleString()}`}
                year={car.year}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
}
