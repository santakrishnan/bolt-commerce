// Only re-export types and client-safe services from the barrel.
// Server-only services (fingerprint.service, visitor-profile.service)
// use `cacheTag`/`cacheLife` and must be imported directly to avoid
// pulling server-only code into client bundles.

export { trackEvent } from "./events.service";
export type {
  EventTrackingIds,
  TrackEventPayload,
  TrackEventResult,
} from "./events-types";
export type {
  FingerprintApiResponse,
  FingerprintBrowserDetails,
  FingerprintEventData,
  FingerprintIdentification,
  FingerprintIpGeolocation,
  FingerprintIpInfo,
} from "./fingerprint-types";
export { unsealFingerprintResult } from "./sealed.service";
export type {
  ProfileResolveApiResponse,
  ProfileResolvePayload,
  ProfileResolveResult,
  VisitorDevice,
  VisitorLocation,
  VisitorProfile,
  VisitorProfileApiResponse,
  VisitorTrustSignals,
  VisitorUserFlags,
} from "./visitor-profile-types";
