import { act, renderHook } from "@testing-library/react";
import type { ReactNode } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// Hoisted mock refs
const mockPost = vi.hoisted(() => vi.fn(() => Promise.resolve({})));
const mockArrowReady = vi.hoisted(() => ({ value: false }));
const mockFingerprintData = vi.hoisted(() => ({
  value: null as {
    geo?: { postalCode?: string; city?: string; stateCode?: string };
  } | null,
}));

// Module mocks
vi.mock("@features/tracking", () => ({
  useArrow: () => ({
    fingerprintData: mockFingerprintData.value,
    isReady: mockArrowReady.value,
  }),
}));

vi.mock("@features/tracking/lib/client-api", () => ({
  useArrowClient: () => ({
    post: mockPost,
    get: vi.fn(),
    put: vi.fn(),
    delete: vi.fn(),
  }),
}));

// Minimal mock covering all resolveHeroState / resolveBackgroundImageKey branches.
vi.mock("@shared/data/state-hero-config.json", () => ({
  default: {
    defaultState: "TX",
    backgroundImages: {
      southwest: {
        image: "/images/heroes/southwest/hero.png",
        focalPoints: {
          horizontal: { x: 60, y: 40 },
          vertical: { x: 64, y: 20 },
        },
        zoomLevels: {
          horizontal: 1.1,
          vertical: 1.2,
        },
      },
      southeast: {
        image: "/images/heroes/southeast/hero.png",
        focalPoints: {
          horizontal: { x: 52, y: 50 },
          vertical: { x: 52, y: 50 },
        },
        zoomLevels: {
          horizontal: 1.08,
          vertical: 1.18,
        },
      },
    },
    zipPrefixes: {
      TX: { min: 750, max: 799 },
      FL: { min: 320, max: 349 },
      // NOKEY has no backgroundImageKey in states → exercises the fallback
      NOKEY: { min: 1, max: 9 },
    },
    states: {
      TX: {
        backgroundImageKey: "southwest",
        zipCode: "75001",
        description: "Plano, TX",
      },
      FL: {
        backgroundImageKey: "southeast",
        zipCode: "33101",
        description: "Miami, FL",
      },
      // Intentionally no backgroundImageKey → triggers resolveBackgroundImageKey fallback
      NOKEY: {
        zipCode: "00500",
        description: "No Key State",
      },
    },
  },
}));

import { LocationProvider, useLocation } from "../location-provider";

function makeWrapper(initialZip?: string | null) {
  return function Wrapper({ children }: { children: ReactNode }) {
    return <LocationProvider initialZip={initialZip ?? null}>{children}</LocationProvider>;
  };
}

function setManualZipCookie(value?: string | null) {
  if (typeof document === "undefined") {
    return;
  }

  try {
    const cs = (globalThis as any).cookieStore;
    if (cs && typeof cs.set === "function") {
      // cookieStore API (jsdom may not implement this, but keep for completeness)
      if (value) {
        cs.set({ name: "arrow_manual_zip", value });
      } else {
        cs.delete?.("arrow_manual_zip");
      }
      return;
    }

    const cookieValue = value
      ? `arrow_manual_zip=${value}; path=/`
      : "arrow_manual_zip=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
    Object.defineProperty(document, "cookie", {
      configurable: true,
      writable: true,
      value: cookieValue,
    });
  } catch {
    // noop — tests run in varied environments
  }
}

describe("useLocation — outside provider", () => {
  it("throws when used outside LocationProvider", () => {
    expect(() => renderHook(() => useLocation())).toThrowError(
      "useLocation must be used within LocationProvider"
    );
  });
});

describe("LocationProvider — initial state", () => {
  beforeEach(() => {
    mockFingerprintData.value = null;
    mockArrowReady.value = false;
    mockPost.mockResolvedValue({});
  });

  it("renders children and exposes state + actions", () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    expect(result.current.state).toBeDefined();
    expect(result.current.actions.setZip).toBeTypeOf("function");
    expect(result.current.actions.clearManualZip).toBeTypeOf("function");
  });

  it("uses defaultZip when no fingerprint or manual zip", () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    expect(result.current.state.displayZip).toBe("75001");
    expect(result.current.state.isManualZip).toBe(false);
    expect(result.current.state.isResolved).toBe(false);
    expect(result.current.state.description).toBeUndefined();
  });

  it("hydrates from initialZip (server cookie) immediately", () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper("33101"),
    });
    expect(result.current.state.displayZip).toBe("33101");
    expect(result.current.state.isManualZip).toBe(true);
    expect(result.current.state.isResolved).toBe(true);
  });

  it("isResolved becomes true when arrow is ready", () => {
    mockArrowReady.value = true;
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    expect(result.current.state.isResolved).toBe(true);
  });
});

describe("LocationProvider — fingerprint data", () => {
  beforeEach(() => {
    mockArrowReady.value = true;
    mockPost.mockResolvedValue({});
  });

  it("uses fingerprint postalCode when valid and no manual zip", () => {
    mockFingerprintData.value = {
      geo: { postalCode: "75201", city: "Dallas", stateCode: "TX" },
    };
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    expect(result.current.state.displayZip).toBe("75201");
    expect(result.current.state.displayCity).toBe("Dallas");
    expect(result.current.state.displayState).toBe("TX");
  });

  it("falls back to defaultZip when fingerprint postalCode is invalid", () => {
    mockFingerprintData.value = {
      geo: { postalCode: "XXXXX", city: "Nowhere", stateCode: "XX" },
    };
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    expect(result.current.state.displayZip).toBe("75001");
  });

  it("falls back to defaultZip when fingerprint postalCode is absent", () => {
    mockFingerprintData.value = { geo: {} };
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    expect(result.current.state.displayZip).toBe("75001");
  });
});

describe("resolveHeroState — via displayZip", () => {
  beforeEach(() => {
    mockFingerprintData.value = null;
    mockArrowReady.value = false;
    mockPost.mockResolvedValue({});
  });

  it("resolves to TX for a zip in the TX range (750–799)", () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper("75001"),
    });
    expect(result.current.state.heroState).toBe("TX");
    expect(result.current.state.backgroundImageKey).toBe("southwest");
    expect(result.current.state.backgroundImage).toBe("/images/heroes/southwest/hero.png");
    expect(result.current.state.backgroundFocalPointVertical).toEqual({ x: 64, y: 20 });
    expect(result.current.state.backgroundZoomVertical).toBe(1.2);
  });

  it("resolves to FL for a zip in the FL range (320–349)", () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper("33101"),
    });
    expect(result.current.state.heroState).toBe("FL");
    expect(result.current.state.backgroundImageKey).toBe("southeast");
  });

  it("falls back to defaultState (TX) for a zip not in any range", () => {
    // prefix 123 is not mapped in the minimal mock
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper("12345"),
    });
    expect(result.current.state.heroState).toBe("TX");
  });

  it("falls back to defaultState (TX) for a non-numeric zip prefix (NaN path)", () => {
    // prefix 000 is outside all ranges → falls back to defaultState
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper("00001"),
    });
    expect(result.current.state.heroState).toBe("TX");
  });
});

describe("resolveBackgroundImageKey — fallback branch", () => {
  beforeEach(() => {
    mockFingerprintData.value = null;
    mockArrowReady.value = false;
    mockPost.mockResolvedValue({});
  });

  it("falls back to first backgroundImages key when state has no backgroundImageKey", () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper("00500"),
    });
    expect(result.current.state.heroState).toBe("NOKEY");
    expect(result.current.state.backgroundImageKey).toBe("southwest");
    expect(result.current.state.backgroundImage).toBe("/images/heroes/southwest/hero.png");
  });
});

describe("setZip action", () => {
  beforeEach(() => {
    mockFingerprintData.value = null;
    mockArrowReady.value = false;
    mockPost.mockReset();
    mockPost.mockResolvedValue({});
    // Clear any residual cookies
    setManualZipCookie(null);
  });

  afterEach(() => {
    setManualZipCookie(null);
    vi.unstubAllGlobals();
  });

  it("saveManualZipToCookie skips when document is undefined (SSR guard)", () => {
    const { result } = renderHook(() => useLocation(), { wrapper: makeWrapper() });
    const originalDoc = global.document;
    vi.stubGlobal("document", undefined);
    expect(() => result.current.actions.setZip("75001")).not.toThrow();
    vi.stubGlobal("document", originalDoc);
  });

  it("updates displayZip and sets isManualZip to true", () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    act(() => {
      result.current.actions.setZip("33101");
    });
    expect(result.current.state.displayZip).toBe("33101");
    expect(result.current.state.isManualZip).toBe(true);
    expect(result.current.state.isResolved).toBe(true);
  });

  it("clears city and state when manual zip is set", () => {
    mockFingerprintData.value = {
      geo: { postalCode: "75201", city: "Dallas", stateCode: "TX" },
    };
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    act(() => {
      result.current.actions.setZip("33101");
    });
    expect(result.current.state.displayCity).toBe("");
    expect(result.current.state.displayState).toBe("");
  });

  it("writes the manual zip to document.cookie", () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    act(() => {
      result.current.actions.setZip("75001");
    });
    expect(document.cookie).toContain("arrow_manual_zip");
  });

  it("fires a tracking event with correct payload", () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    act(() => {
      result.current.actions.setZip("33101");
    });
    expect(mockPost).toHaveBeenCalledWith(
      "/api/events/track",
      expect.objectContaining({
        event: "location_zip_changed",
        properties: expect.objectContaining({
          newZip: "33101",
          isManualOverride: true,
        }),
      })
    );
  });

  it("does nothing when zip is an empty string", () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    const before = result.current.state.displayZip;
    act(() => {
      result.current.actions.setZip("");
    });
    expect(result.current.state.displayZip).toBe(before);
    expect(mockPost).not.toHaveBeenCalled();
  });

  it("does nothing when zip format is invalid (letters)", () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    const before = result.current.state.displayZip;
    act(() => {
      result.current.actions.setZip("ABCDE");
    });
    expect(result.current.state.displayZip).toBe(before);
    expect(mockPost).not.toHaveBeenCalled();
  });

  it("does nothing when zip has fewer than 5 digits", () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    const before = result.current.state.displayZip;
    act(() => {
      result.current.actions.setZip("1234");
    });
    expect(result.current.state.displayZip).toBe(before);
  });

  it("swallows tracking API errors silently", async () => {
    mockPost.mockRejectedValueOnce(new Error("network error"));
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => undefined);
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    act(() => {
      result.current.actions.setZip("75001");
    });
    await Promise.resolve();
    expect(consoleSpy).toHaveBeenCalledWith(
      expect.stringContaining("[LocationProvider]"),
      expect.any(Error)
    );
    consoleSpy.mockRestore();
  });

  it("exposes description when manual zip is set", async () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    act(() => {
      result.current.actions.setZip("33101");
    });
    await Promise.resolve();
    expect(result.current.state.description).toBe("Miami, FL");
  });
});

describe("clearManualZip action", () => {
  beforeEach(() => {
    mockFingerprintData.value = null;
    mockArrowReady.value = false;
    mockPost.mockReset();
    mockPost.mockResolvedValue({});
    setManualZipCookie(null);
  });

  afterEach(() => {
    setManualZipCookie(null);
    vi.unstubAllGlobals();
  });

  it("clearManualZipCookie skips when document is undefined (SSR guard)", () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper("33101"),
    });
    const originalDoc = global.document;
    vi.stubGlobal("document", undefined);
    expect(() => result.current.actions.clearManualZip()).not.toThrow();
    vi.stubGlobal("document", originalDoc);
  });

  it("clears manual zip and reverts to default zip", async () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper("33101"),
    });
    expect(result.current.state.isManualZip).toBe(true);
    act(() => {
      result.current.actions.clearManualZip();
    });
    await Promise.resolve();
    expect(result.current.state.isManualZip).toBe(false);
    expect(result.current.state.displayZip).toBe("75001"); // defaultZip
  });

  it("clears manual zip and reverts to fingerprint zip when valid", async () => {
    mockFingerprintData.value = {
      geo: { postalCode: "75201", city: "Dallas", stateCode: "TX" },
    };
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper("33101"),
    });
    act(() => {
      result.current.actions.clearManualZip();
    });
    await Promise.resolve();
    expect(result.current.state.displayZip).toBe("75201");
    expect(result.current.state.displayCity).toBe("Dallas");
  });

  it("fires a tracking event with previousZip when there was a manual zip", async () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper("33101"),
    });
    act(() => {
      result.current.actions.clearManualZip();
    });
    await Promise.resolve();
    expect(mockPost).toHaveBeenCalledWith(
      "/api/events/track",
      expect.objectContaining({
        event: "location_zip_cleared",
        properties: expect.objectContaining({
          previousZip: "33101",
        }),
      })
    );
  });

  it("does NOT fire a tracking event when there was no previous manual zip", async () => {
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper(),
    });
    act(() => {
      result.current.actions.clearManualZip();
    });
    await Promise.resolve();
    expect(mockPost).not.toHaveBeenCalled();
  });

  it("swallows tracking errors on clear silently", async () => {
    mockPost.mockRejectedValueOnce(new Error("network error"));
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => undefined);
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper("33101"),
    });
    act(() => {
      result.current.actions.clearManualZip();
    });
    await Promise.resolve();
    expect(consoleSpy).toHaveBeenCalledWith(
      expect.stringContaining("[LocationProvider]"),
      expect.any(Error)
    );
    consoleSpy.mockRestore();
  });

  it("revertedToFingerprint is false when fingerprint zip is invalid", async () => {
    mockFingerprintData.value = { geo: { postalCode: "XXXXX" } };
    const { result } = renderHook(() => useLocation(), {
      wrapper: makeWrapper("33101"),
    });
    act(() => {
      result.current.actions.clearManualZip();
    });
    await Promise.resolve();
    expect(mockPost).toHaveBeenCalledWith(
      "/api/events/track",
      expect.objectContaining({
        properties: expect.objectContaining({
          revertedToFingerprint: false,
        }),
      })
    );
  });
});
