/**
 * Unit tests for useDebouncedValue hook
 * @module shared/hooks/__tests__/use-debounced-value
 */

import { act, renderHook } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { useDebouncedValue } from "../use-debounced-value";

describe("useDebouncedValue", () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.restoreAllMocks();
    vi.useRealTimers();
  });

  it("returns initial value immediately", () => {
    const { result } = renderHook(() => useDebouncedValue("initial"));

    expect(result.current[0]).toBe("initial");
  });

  it("debounces value changes with default delay (300ms)", () => {
    const { result, rerender } = renderHook(({ value }) => useDebouncedValue(value), {
      initialProps: { value: "initial" },
    });

    expect(result.current[0]).toBe("initial");

    rerender({ value: "updated" });
    expect(result.current[0]).toBe("initial");

    act(() => {
      vi.advanceTimersByTime(299);
    });
    expect(result.current[0]).toBe("initial");

    act(() => {
      vi.advanceTimersByTime(1);
    });
    expect(result.current[0]).toBe("updated");
  });

  it("debounces value changes with custom delay", () => {
    const { result, rerender } = renderHook(({ value, delay }) => useDebouncedValue(value, delay), {
      initialProps: { value: "initial", delay: 500 },
    });

    rerender({ value: "updated", delay: 500 });

    act(() => {
      vi.advanceTimersByTime(499);
    });
    expect(result.current[0]).toBe("initial");

    act(() => {
      vi.advanceTimersByTime(1);
    });
    expect(result.current[0]).toBe("updated");
  });

  it("cancels previous timer when value changes rapidly", () => {
    const { result, rerender } = renderHook(({ value }) => useDebouncedValue(value, 300), {
      initialProps: { value: "initial" },
    });

    rerender({ value: "first" });
    act(() => {
      vi.advanceTimersByTime(100);
    });

    rerender({ value: "second" });
    act(() => {
      vi.advanceTimersByTime(100);
    });

    rerender({ value: "third" });
    act(() => {
      vi.advanceTimersByTime(300);
    });

    expect(result.current[0]).toBe("third");
  });

  it("works with different data types - numbers", () => {
    const { result, rerender } = renderHook(({ value }) => useDebouncedValue(value, 300), {
      initialProps: { value: 0 },
    });

    rerender({ value: 42 });
    act(() => {
      vi.advanceTimersByTime(300);
    });

    expect(result.current[0]).toBe(42);
  });

  it("works with different data types - booleans", () => {
    const { result, rerender } = renderHook(({ value }) => useDebouncedValue(value, 300), {
      initialProps: { value: false },
    });

    rerender({ value: true });
    act(() => {
      vi.advanceTimersByTime(300);
    });

    expect(result.current[0]).toBe(true);
  });

  it("works with different data types - objects", () => {
    const initialObj = { name: "John", age: 30 };
    const updatedObj = { name: "Jane", age: 25 };

    const { result, rerender } = renderHook(({ value }) => useDebouncedValue(value, 300), {
      initialProps: { value: initialObj },
    });

    rerender({ value: updatedObj });
    act(() => {
      vi.advanceTimersByTime(300);
    });

    expect(result.current[0]).toEqual(updatedObj);
  });

  it("works with different data types - arrays", () => {
    const initialArray = [1, 2, 3];
    const updatedArray = [4, 5, 6];

    const { result, rerender } = renderHook(({ value }) => useDebouncedValue(value, 300), {
      initialProps: { value: initialArray },
    });

    rerender({ value: updatedArray });
    act(() => {
      vi.advanceTimersByTime(300);
    });

    expect(result.current[0]).toEqual(updatedArray);
  });

  it("works with null and undefined values", () => {
    const { result, rerender } = renderHook(
      ({ value }) => useDebouncedValue<string | null | undefined>(value, 300),
      { initialProps: { value: "initial" as string | null | undefined } }
    );

    rerender({ value: null });
    act(() => {
      vi.advanceTimersByTime(300);
    });
    expect(result.current[0]).toBe(null);

    rerender({ value: undefined });
    act(() => {
      vi.advanceTimersByTime(300);
    });
    expect(result.current[0]).toBe(undefined);
  });

  it("clears timer on unmount", () => {
    const clearTimeoutSpy = vi.spyOn(window, "clearTimeout");

    const { unmount, rerender } = renderHook(({ value }) => useDebouncedValue(value, 300), {
      initialProps: { value: "initial" },
    });

    rerender({ value: "updated" });
    unmount();

    expect(clearTimeoutSpy).toHaveBeenCalled();
    clearTimeoutSpy.mockRestore();
  });

  it("handles zero delay", () => {
    const { result, rerender } = renderHook(({ value }) => useDebouncedValue(value, 0), {
      initialProps: { value: "initial" },
    });

    rerender({ value: "updated" });
    act(() => {
      vi.advanceTimersByTime(0);
    });

    expect(result.current[0]).toBe("updated");
  });

  it("handles very long delays", () => {
    const { result, rerender } = renderHook(({ value }) => useDebouncedValue(value, 5000), {
      initialProps: { value: "initial" },
    });

    rerender({ value: "updated" });

    act(() => {
      vi.advanceTimersByTime(4999);
    });
    expect(result.current[0]).toBe("initial");

    act(() => {
      vi.advanceTimersByTime(1);
    });
    expect(result.current[0]).toBe("updated");
  });

  it("handles multiple rapid changes and settles on final value", () => {
    const { result, rerender } = renderHook(({ value }) => useDebouncedValue(value, 300), {
      initialProps: { value: 0 },
    });

    for (let i = 1; i <= 10; i++) {
      rerender({ value: i });
      act(() => {
        vi.advanceTimersByTime(50);
      });
    }

    expect(result.current[0]).toBe(0);

    act(() => {
      vi.advanceTimersByTime(300);
    });

    expect(result.current[0]).toBe(10);
  });

  it("updates when value changes after debounce completes", () => {
    const { result, rerender } = renderHook(({ value }) => useDebouncedValue(value, 300), {
      initialProps: { value: "first" },
    });

    rerender({ value: "second" });
    act(() => {
      vi.advanceTimersByTime(300);
    });
    expect(result.current[0]).toBe("second");

    rerender({ value: "third" });
    act(() => {
      vi.advanceTimersByTime(300);
    });
    expect(result.current[0]).toBe("third");
  });

  it("handles same value being set multiple times", () => {
    const { result, rerender } = renderHook(({ value }) => useDebouncedValue(value, 300), {
      initialProps: { value: "test" },
    });

    rerender({ value: "test" });
    act(() => {
      vi.advanceTimersByTime(300);
    });
    expect(result.current[0]).toBe("test");

    rerender({ value: "test" });
    act(() => {
      vi.advanceTimersByTime(300);
    });
    expect(result.current[0]).toBe("test");
  });

  it("creates new timer for each value change", () => {
    const setTimeoutSpy = vi.spyOn(window, "setTimeout");

    const { rerender } = renderHook(({ value }) => useDebouncedValue(value, 300), {
      initialProps: { value: "initial" },
    });

    const initialCallCount = setTimeoutSpy.mock.calls.length;

    rerender({ value: "first" });
    expect(setTimeoutSpy).toHaveBeenCalledTimes(initialCallCount + 1);

    rerender({ value: "second" });
    expect(setTimeoutSpy).toHaveBeenCalledTimes(initialCallCount + 2);

    setTimeoutSpy.mockRestore();
  });

  it("clears previous timer before setting new one", () => {
    const clearTimeoutSpy = vi.spyOn(window, "clearTimeout");

    const { rerender } = renderHook(({ value }) => useDebouncedValue(value, 300), {
      initialProps: { value: "initial" },
    });

    rerender({ value: "first" });
    const firstClearCount = clearTimeoutSpy.mock.calls.length;

    rerender({ value: "second" });
    expect(clearTimeoutSpy.mock.calls.length).toBeGreaterThan(firstClearCount);

    clearTimeoutSpy.mockRestore();
  });
});
