import { describe, expect, it } from "vitest";
import {
  normalizeHeroDeviceTypeOverride,
  resolveHeroDeviceType,
  resolveHeroDeviceTypeFromUserAgent,
  resolveHeroLayoutProfile,
} from "../device-type";

describe("resolveHeroDeviceTypeFromUserAgent", () => {
  it("detects mobile user agents", () => {
    expect(
      resolveHeroDeviceTypeFromUserAgent("Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)")
    ).toBe("mobile");
  });

  it("detects tablet user agents", () => {
    expect(
      resolveHeroDeviceTypeFromUserAgent("Mozilla/5.0 (iPad; CPU OS 17_0 like Mac OS X)")
    ).toBe("tablet");
  });

  it("falls back to desktop", () => {
    expect(resolveHeroDeviceTypeFromUserAgent("Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0)")).toBe(
      "desktop"
    );
  });
});

describe("normalizeHeroDeviceTypeOverride", () => {
  it("accepts known override values and ignores auto/invalid values", () => {
    expect(normalizeHeroDeviceTypeOverride("desktop")).toBe("desktop");
    expect(normalizeHeroDeviceTypeOverride("mobile")).toBe("mobile");
    expect(normalizeHeroDeviceTypeOverride("tablet")).toBeUndefined();
    expect(normalizeHeroDeviceTypeOverride("auto")).toBeUndefined();
    expect(normalizeHeroDeviceTypeOverride("random")).toBeUndefined();
  });
});

describe("resolveHeroDeviceType", () => {
  it("prefers explicit override over user-agent detection", () => {
    expect(
      resolveHeroDeviceType("Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)", "desktop")
    ).toBe("desktop");
  });
});

describe("resolveHeroLayoutProfile", () => {
  it("maps mobile to vertical and desktop/tablet to horizontal", () => {
    expect(resolveHeroLayoutProfile("mobile")).toBe("vertical");
    expect(resolveHeroLayoutProfile("desktop")).toBe("horizontal");
    expect(resolveHeroLayoutProfile("tablet")).toBe("horizontal");
  });
});
