import { describe, expect, it } from "vitest";
import {
  resolveFocalImageStyle,
  resolveFocalObjectPosition,
  resolveTitleSafeFocalPoint,
} from "../hero-image";

describe("resolveFocalObjectPosition", () => {
  it("returns center fallback when focal point is absent", () => {
    expect(resolveFocalObjectPosition()).toBe("50% 50%");
  });

  it("returns clamped object-position from x and y", () => {
    expect(resolveFocalObjectPosition({ x: 72, y: 52 })).toBe("72% 52%");
    expect(resolveFocalObjectPosition({ x: -10, y: 120 })).toBe("0% 100%");
  });

  it("returns center fallback when x/y are incomplete", () => {
    expect(resolveFocalObjectPosition({ x: 40 })).toBe("50% 50%");
    expect(resolveFocalObjectPosition({ y: 20 })).toBe("50% 50%");
  });
});

describe("resolveFocalImageStyle", () => {
  it("returns centered style when focal point and zoom are absent", () => {
    expect(resolveFocalImageStyle(undefined, false)).toEqual({
      appliedZoom: 1,
      objectPosition: "50% 50%",
      targetX: 50,
      targetY: 50,
      transform: "translate(0%, 0%) scale(1)",
      transformOrigin: "50% 50%",
    });
  });

  it("aligns focal point to the desktop target by adapting zoom and translate", () => {
    expect(resolveFocalImageStyle({ x: 70, y: 10 }, false, 1.25)).toEqual({
      appliedZoom: 1.64,
      objectPosition: "70% 10%",
      targetX: 72,
      targetY: 42,
      transform: "translate(2%, 32%) scale(1.64)",
      transformOrigin: "70% 10%",
    });
  });
});

describe("resolveTitleSafeFocalPoint", () => {
  it("shifts desktop focal point right to avoid left title area", () => {
    expect(resolveTitleSafeFocalPoint({ x: 40, y: 42 }, false)).toEqual({ x: 58, y: 42 });
    expect(resolveTitleSafeFocalPoint({ x: 72, y: 42 }, false)).toEqual({ x: 72, y: 42 });
  });

  it("shifts mobile focal point upward to avoid bottom-centered title area", () => {
    expect(resolveTitleSafeFocalPoint({ x: 50, y: 60 }, true)).toEqual({ x: 50, y: 38 });
    expect(resolveTitleSafeFocalPoint({ x: 50, y: 10 }, true)).toEqual({ x: 50, y: 10 });
  });
});
