/**
 * Search History — mock server-side service (in-memory Map keyed by visitor ID).
 * Replace each function body with the real BED HTTP call when available; signatures stay the same.
 */

import { ROUTES } from "@config/routes/constants";
import type { SearchEntry } from "./types";

const MAX_SEARCHES = 10;

// ── Dev seed ────────────────────────────────────────────────────────────────
// Per-profile seed data so each sample user sees distinct recent searches.
const SEED_SEARCHES_BY_PROFILE: Record<string, SearchEntry[]> = {
  // Alice Demo — compact SUVs, fuel-efficient, Los Angeles area
  authenticatedPrequalified: [
    {
      id: "seed-alice-1",
      query: "Toyota RAV4 Hybrid under $35,000",
      url: `${ROUTES.USED_CARS}?q=Toyota+RAV4+Hybrid+under+%2435%2C000`,
      timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      type: "nlp",
    },
    {
      id: "seed-alice-2",
      query: "Corolla Cross low mileage Los Angeles",
      url: `${ROUTES.USED_CARS}?q=Corolla+Cross+low+mileage+Los+Angeles`,
      timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      type: "nlp",
    },
    {
      id: "seed-alice-3",
      query: "Certified Pre-Owned SUV 2023",
      url: `${ROUTES.USED_CARS}?q=Certified+Pre-Owned+SUV+2023`,
      timestamp: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
      type: "nlp",
    },
  ],
  // Bob / Sarah Johnson — larger vehicles, San Francisco area
  authenticatedNotPrequalified: [
    {
      id: "seed-bob-1",
      query: "Toyota Tacoma TRD Pro 4x4",
      url: `${ROUTES.USED_CARS}?q=Toyota+Tacoma+TRD+Pro+4x4`,
      timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      type: "nlp",
    },
    {
      id: "seed-bob-2",
      query: "Highlander Hybrid 3rd row seating San Francisco",
      url: `${ROUTES.USED_CARS}?q=Highlander+Hybrid+3rd+row+seating+San+Francisco`,
      timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
      type: "nlp",
    },
    {
      id: "seed-bob-3",
      query: "Venza Limited under $40,000",
      url: `${ROUTES.USED_CARS}?q=Venza+Limited+under+%2440%2C000`,
      timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      type: "nlp",
    },
  ],
};

const stores = new Map<string, SearchEntry[]>();

function getStore(visitorId: string): SearchEntry[] {
  let store = stores.get(visitorId);
  if (!store) {
    store = [];
    stores.set(visitorId, store);
  }
  return store;
}

/** Retrieve all search entries for a visitor (most recent first). */
export function getAll(visitorId: string): Promise<SearchEntry[]> {
  return Promise.resolve([...getStore(visitorId)]);
}

/**
 * Add a search entry.
 * - Skips empty or single-character queries (returns unchanged list).
 * - Duplicate queries are moved to the top with an updated timestamp.
 * - Oldest entries are pruned when the list exceeds MAX_SEARCHES.
 * Returns the full updated list.
 */
export function add(
  visitorId: string,
  query: string,
  url: string,
  type: "nlp" | "filter" = "nlp"
): Promise<SearchEntry[]> {
  const trimmed = query.trim();
  if (trimmed.length <= 1) {
    return Promise.resolve([...getStore(visitorId)]);
  }

  const entries = [...getStore(visitorId)];
  const existingIdx = entries.findIndex((e) => e.query.toLowerCase() === trimmed.toLowerCase());

  if (existingIdx === -1) {
    entries.unshift({
      id: Date.now().toString(),
      query: trimmed,
      url,
      timestamp: new Date().toISOString(),
      type,
    });
  } else {
    const existing = entries[existingIdx] as SearchEntry;
    entries.splice(existingIdx, 1);
    entries.unshift({ ...existing, url, timestamp: new Date().toISOString() });
  }

  const pruned = entries.slice(0, MAX_SEARCHES);
  stores.set(visitorId, pruned);
  return Promise.resolve([...pruned]);
}

/**
 * Remove a search entry by id.
 * Returns the full updated list.
 */
export function remove(visitorId: string, id: string): Promise<SearchEntry[]> {
  const filtered = getStore(visitorId).filter((e) => e.id !== id);
  stores.set(visitorId, filtered);
  return Promise.resolve([...filtered]);
}

/** Clear all search history. Returns an empty array. */
export function clearAll(visitorId: string): Promise<SearchEntry[]> {
  stores.set(visitorId, []);
  return Promise.resolve([]);
}

/**
 * Reset search history to the seed state for the given profile.
 * Seeds directly into the Map so the next GET returns the correct data immediately.
 */
export function reset(visitorId: string, profile?: string): void {
  const seeds = profile ? SEED_SEARCHES_BY_PROFILE[profile] : undefined;
  stores.set(
    visitorId,
    process.env.NODE_ENV === "production" || !seeds ? [] : seeds.map((s) => ({ ...s }))
  );
}
