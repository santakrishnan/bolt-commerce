/**
 * Saved Vehicles — mock server-side service (in-memory Map keyed by visitor ID).
 * Replace each function body with the real BED HTTP call when available; signatures stay the same.
 */

const MAX_SAVED = 30;

// ── Dev seed ────────────────────────────────────────────────────────────────
// Per-profile seed data so each sample user sees distinct saved vehicles.
const SEED_VINS_BY_PROFILE: Record<string, string[]> = {
  // Alice Demo — compact SUVs, fuel-efficient
  authenticatedPrequalified: [
    "JTDEPMAE5PJ100001", // 2023 Toyota Corolla Cross
    "2T3P1RFV8NW100002", // 2022 Toyota RAV4 Hybrid
    "JTDEPMAE7PJ100007", // 2023 Toyota Corolla Cross
  ],
  // Bob / Sarah Johnson — larger vehicles, diverse styles
  authenticatedNotPrequalified: [
    "JTEBU5JR5L5100009", // 2020 Toyota Venza Limited Edition
    "5TDFZRBH5RS100015", // 2024 Toyota Highlander Hybrid
    "3TMCZ5AN5NM100016", // 2022 Toyota Tacoma TRD Pro — Truck
  ],
};

const stores = new Map<string, string[]>();

function getStore(visitorId: string): string[] {
  let store = stores.get(visitorId);
  if (!store) {
    store = [];
    stores.set(visitorId, store);
  }
  return store;
}

/** Retrieve all saved VINs for a visitor. */
export function getAll(visitorId: string): Promise<string[]> {
  return Promise.resolve([...getStore(visitorId)]);
}

/**
 * Save a vehicle by VIN.
 * No-op if already saved. Throws if at capacity.
 * Returns the full updated list.
 */
export function save(visitorId: string, vin: string): Promise<string[]> {
  const store = getStore(visitorId);

  if (store.includes(vin)) {
    return Promise.resolve([...store]);
  }

  if (store.length >= MAX_SAVED) {
    return Promise.reject(new Error(`Cannot save more than ${MAX_SAVED} vehicles.`));
  }

  store.push(vin);
  return Promise.resolve([...store]);
}

/**
 * Remove a saved vehicle by VIN.
 * Returns the full updated list.
 */
export function remove(visitorId: string, vin: string): Promise<string[]> {
  const store = getStore(visitorId);
  const filtered = store.filter((v) => v !== vin);
  stores.set(visitorId, filtered);
  return Promise.resolve([...filtered]);
}

/** Clear all saved vehicles. Returns an empty array. */
export function clearAll(visitorId: string): Promise<string[]> {
  stores.set(visitorId, []);
  return Promise.resolve([]);
}

/**
 * Reset saved vehicles to the seed state for the given profile.
 * Seeds directly into the Map so the next GET returns the correct data immediately.
 */
export function reset(visitorId: string, profile?: string): void {
  const seeds = profile ? SEED_VINS_BY_PROFILE[profile] : undefined;
  stores.set(visitorId, process.env.NODE_ENV === "production" || !seeds ? [] : [...seeds]);
}
