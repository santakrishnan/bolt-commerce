export type HeroDeviceType = "desktop" | "tablet" | "mobile";
export type HeroLayoutProfile = "horizontal" | "vertical";

const TABLET_UA_REGEX = /(ipad|tablet)/i;
const MOBILE_UA_REGEX = /(mobile|iphone|android)/i;

export function resolveHeroDeviceTypeFromUserAgent(userAgent: string): HeroDeviceType {
  const ua = userAgent.toLowerCase();

  // Tablet check before mobile because many tablet UAs include the word "mobile".
  if (TABLET_UA_REGEX.test(ua)) {
    return "tablet";
  }

  if (MOBILE_UA_REGEX.test(ua)) {
    return "mobile";
  }

  return "desktop";
}

export function normalizeHeroDeviceTypeOverride(
  override: string | null | undefined
): Exclude<HeroDeviceType, "tablet"> | undefined {
  if (!override) {
    return undefined;
  }

  const normalized = override.toLowerCase();
  if (normalized === "auto") {
    return undefined;
  }

  if (normalized === "desktop" || normalized === "mobile") {
    return normalized;
  }

  return undefined;
}

export function resolveHeroDeviceType(userAgent: string, override?: string | null): HeroDeviceType {
  const overrideDeviceType = normalizeHeroDeviceTypeOverride(override);
  if (overrideDeviceType) {
    return overrideDeviceType;
  }

  return resolveHeroDeviceTypeFromUserAgent(userAgent);
}

export function resolveHeroLayoutProfile(deviceType: HeroDeviceType): HeroLayoutProfile {
  return deviceType === "mobile" ? "vertical" : "horizontal";
}
