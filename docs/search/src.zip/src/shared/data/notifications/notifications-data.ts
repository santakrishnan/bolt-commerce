import { cache } from "react";
import type { NotificationSettings } from "~/features/my-account/components/notifications/types";
import notifications from "./notifications.json";

export const getNotificationSettings = cache(
  function getNotificationSettings(): Promise<NotificationSettings> {
    return Promise.resolve(notifications as NotificationSettings);
  }
);
