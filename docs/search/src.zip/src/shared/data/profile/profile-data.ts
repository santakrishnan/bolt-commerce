import { getCurrentUser } from "@config/flags/server";

import { cache } from "react";
import type { UserDetailsFormData } from "~/features/my-account/components/user-details/types";

export const getUserDetails = cache(async function getUserDetails(): Promise<UserDetailsFormData> {
  const user = await getCurrentUser();

  return {
    firstName: user.firstName || "",
    lastName: user.lastName || "",
    email: user.email || "",
    phone: user.phone || "",
    month: user.month || "",
    day: user.day || "",
    year: user.year || "",
    streetAddress: user.streetAddress || "",
    city: user.city || "",
    state: user.state || "",
    zip: user.zip || "",
  };
});
