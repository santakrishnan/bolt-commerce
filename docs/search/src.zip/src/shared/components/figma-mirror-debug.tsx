"use client";

import { Heading } from "@tfs-ucmp/ui";
import Image from "next/image";
import { type ChangeEvent, useEffect, useMemo, useRef, useState } from "react";

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

interface FigmaReference {
  name: string;
  url: string;
}

async function fetchFigmaReferences(): Promise<FigmaReference[]> {
  try {
    const response = await fetch("/api/debug/figma-references", { cache: "no-store" });
    if (!response.ok) {
      return [];
    }

    const data = (await response.json()) as { references?: FigmaReference[] };
    return data.references ?? [];
  } catch {
    return [];
  }
}

/** Dev-only overlay for visually comparing a live page against a Figma export. */
export function FigmaMirrorDebug() {
  const [isOpen, setIsOpen] = useState(false);
  const [isOverlayVisible, setIsOverlayVisible] = useState(true);
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [opacity, setOpacity] = useState(0.5);
  const [clipPercent, setClipPercent] = useState(50);
  const [topMarginPx, setTopMarginPx] = useState(0);
  const [viewportWidth, setViewportWidth] = useState(0);
  const [viewportHeight, setViewportHeight] = useState(0);
  const [scrollY, setScrollY] = useState(0);
  const [isDraggingClipper, setIsDraggingClipper] = useState(false);
  const [references, setReferences] = useState<FigmaReference[]>([]);
  const [selectedReferenceUrl, setSelectedReferenceUrl] = useState("");
  const [isLoadingReferences, setIsLoadingReferences] = useState(false);
  const scrollRafRef = useRef<number | null>(null);

  useEffect(() => {
    const syncViewport = () => {
      setViewportWidth(window.innerWidth);
      setViewportHeight(window.innerHeight);
    };

    const scheduleScrollSync = () => {
      if (scrollRafRef.current !== null) {
        return;
      }

      scrollRafRef.current = window.requestAnimationFrame(() => {
        scrollRafRef.current = null;
        setScrollY(window.scrollY);
      });
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key.toLowerCase() === "d") {
        setIsOverlayVisible((current) => !current);
      }
    };

    syncViewport();
    setScrollY(window.scrollY);

    window.addEventListener("resize", syncViewport);
    window.addEventListener("scroll", scheduleScrollSync, { passive: true });
    window.addEventListener("keydown", handleKeyDown);

    return () => {
      window.removeEventListener("resize", syncViewport);
      window.removeEventListener("scroll", scheduleScrollSync);
      window.removeEventListener("keydown", handleKeyDown);

      if (scrollRafRef.current !== null) {
        window.cancelAnimationFrame(scrollRafRef.current);
        scrollRafRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (!isOpen) {
      return;
    }

    let isCancelled = false;

    const loadReferences = async () => {
      setIsLoadingReferences(true);

      const nextReferences = await fetchFigmaReferences();
      if (!isCancelled) {
        setReferences(nextReferences);
      }

      if (!(isCancelled || isCancelled)) {
        setIsLoadingReferences(false);
      }
    };

    loadReferences().catch(() => {
      if (!isCancelled) {
        setReferences([]);
        setIsLoadingReferences(false);
      }
    });

    return () => {
      isCancelled = true;
    };
  }, [isOpen]);

  const overlayWidthPx = useMemo(() => {
    return viewportWidth;
  }, [viewportWidth]);

  const clipperLeftPx = useMemo(() => {
    return (clipPercent / 100) * overlayWidthPx;
  }, [clipPercent, overlayWidthPx]);

  const clipperHeightPx = useMemo(() => {
    return Math.max(0, viewportHeight - topMarginPx);
  }, [topMarginPx, viewportHeight]);

  useEffect(() => {
    if (!isDraggingClipper) {
      return;
    }

    const handleMouseMove = (event: MouseEvent) => {
      if (overlayWidthPx <= 0) {
        return;
      }

      const x = clamp(event.clientX, 0, overlayWidthPx);
      setClipPercent(clamp((x / overlayWidthPx) * 100, 0, 100));
    };

    const handleMouseUp = () => {
      setIsDraggingClipper(false);
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isDraggingClipper, overlayWidthPx]);

  const handleReferenceChange = (event: ChangeEvent<HTMLSelectElement>) => {
    const nextUrl = event.target.value;
    setSelectedReferenceUrl(nextUrl);

    if (!nextUrl) {
      setImageSrc(null);
      return;
    }

    setImageSrc(nextUrl);
    setIsOverlayVisible(true);
  };

  if (process.env.NODE_ENV === "production") {
    return null;
  }

  return (
    <>
      {imageSrc && isOverlayVisible && (
        <>
          <div
            data-testid="figma-mirror-overlay"
            id="figma-mirror-overlay"
            style={{
              backgroundColor: "transparent",
              height: "100vh",
              left: 0,
              maxWidth: `${overlayWidthPx}px`,
              opacity,
              overflow: "hidden",
              pointerEvents: "none",
              position: "fixed",
              top: `${topMarginPx}px`,
              width: `${overlayWidthPx}px`,
              zIndex: 999_998,
            }}
          >
            <div
              style={{
                clipPath: `inset(0 ${100 - clipPercent}% 0 0)`,
                inset: 0,
                overflow: "hidden",
                position: "absolute",
                WebkitClipPath: `inset(0 ${100 - clipPercent}% 0 0)`,
                willChange: "clip-path",
              }}
            >
              <Image
                alt="Figma mirror overlay"
                height={Math.max(viewportHeight, 1)}
                priority
                src={imageSrc}
                style={{
                  height: "auto",
                  left: 0,
                  objectFit: "contain",
                  pointerEvents: "none",
                  position: "absolute",
                  top: 0,
                  transform: `translate3d(0, ${-scrollY}px, 0)`,
                  userSelect: "none",
                  width: "100%",
                  willChange: "transform",
                }}
                unoptimized
                width={Math.max(overlayWidthPx, 1)}
              />
            </div>
          </div>

          <button
            aria-label="Figma mirror clipper"
            data-testid="figma-mirror-clipper"
            id="figma-mirror-clipper"
            onMouseDown={(event) => {
              event.preventDefault();
              setIsDraggingClipper(true);
            }}
            style={{
              appearance: "none",
              backgroundColor: "#007AFF",
              border: "none",
              cursor: "ew-resize",
              height: `${clipperHeightPx}px`,
              left: `${clipperLeftPx}px`,
              padding: 0,
              position: "fixed",
              top: `${topMarginPx}px`,
              userSelect: "none",
              width: "4px",
              zIndex: 999_999,
            }}
            type="button"
          />
        </>
      )}

      <div className="fixed right-4 bottom-20 z-[9999]">
        <button
          className="flex h-12 w-12 items-center justify-center rounded-full bg-slate-800 font-semibold text-white shadow-lg hover:bg-slate-900"
          onClick={() => setIsOpen((current) => !current)}
          title="Figma Mirror Debug"
          type="button"
        >
          FM
        </button>

        {isOpen && (
          <div className="absolute right-0 bottom-16 w-80 rounded-lg border border-gray-200 bg-white p-4 shadow-xl">
            <div className="mb-3 flex items-center justify-between">
              <Heading className="text-gray-900 text-sm md:text-sm" level={3} weight="bold">
                Figma Mirror
              </Heading>
              <button
                aria-label="Close Figma Mirror panel"
                className="text-gray-400 hover:text-gray-600"
                onClick={() => setIsOpen(false)}
                type="button"
              >
                X
              </button>
            </div>

            <div className="mb-3 space-y-3 text-sm">
              <label className="block text-gray-700">
                <span className="mb-1 block font-medium text-xs">Reference Image</span>
                <select
                  className="w-full rounded border border-gray-300 px-2 py-1.5 text-xs"
                  onChange={handleReferenceChange}
                  value={selectedReferenceUrl}
                >
                  <option value="">Select reference image</option>
                  {references.map((reference) => (
                    <option key={reference.url} value={reference.url}>
                      {reference.name}
                    </option>
                  ))}
                </select>
                <span className="mt-1 block text-gray-500 text-xs">
                  {isLoadingReferences
                    ? "Loading local debug references..."
                    : `Paste screenshots into apps/web/debug/figma-references (${references.length} found)`}
                </span>
              </label>

              <label className="block text-gray-700">
                <span className="mb-1 block font-medium text-xs">Opacity</span>
                <input
                  className="w-full"
                  max="1"
                  min="0.1"
                  onChange={(event) => setOpacity(Number(event.target.value))}
                  step="0.01"
                  type="range"
                  value={opacity}
                />
              </label>

              <div className="text-gray-700">
                <span className="mb-1 block font-medium text-xs">Top Margin (px)</span>
                <div className="flex items-center gap-2">
                  <input
                    className="flex-1"
                    max="200"
                    min="-200"
                    onChange={(event) =>
                      setTopMarginPx(clamp(Number(event.target.value) || 0, -200, 200))
                    }
                    step="1"
                    type="range"
                    value={topMarginPx}
                  />
                  <input
                    className="w-18 rounded border border-gray-300 px-2 py-1 text-xs"
                    max="200"
                    min="-200"
                    onChange={(event) =>
                      setTopMarginPx(clamp(Number(event.target.value) || 0, -200, 200))
                    }
                    step="1"
                    type="number"
                    value={topMarginPx}
                  />
                </div>
              </div>

              <label className="block text-gray-700">
                <span className="mb-1 block font-medium text-xs">Clip Position</span>
                <input
                  className="w-full"
                  max="100"
                  min="0"
                  onChange={(event) => setClipPercent(Number(event.target.value))}
                  step="1"
                  type="range"
                  value={clipPercent}
                />
              </label>
            </div>

            <div className="flex items-center justify-between gap-2">
              <button
                className="rounded bg-blue-600 px-3 py-2 font-medium text-white text-xs hover:bg-blue-700"
                onClick={() => setIsOverlayVisible((current) => !current)}
                type="button"
              >
                {isOverlayVisible ? "Hide Overlay" : "Show Overlay"}
              </button>
              {!imageSrc && (
                <span className="text-gray-500 text-xs">Select a local reference image</span>
              )}
            </div>
          </div>
        )}
      </div>
    </>
  );
}
