import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import type { ReactNode } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// Hoist commonly used regexes to top-level to avoid per-call allocations
const RE_FIRST_TIME = /First time user or last visit/i;
const RE_UNAUTH = /Unauthenticated, both cards completed/i;

// Hoisted mock refs
const getCookieMock = vi.hoisted(() => vi.fn((): string | null => null));

// Module mocks (hoisted automatically by vitest)
vi.mock("@config/flags/config", () => ({
  FLAG_COOKIE_NAME: "feature-flags-user",
  HERO_DEVICE_OVERRIDE_COOKIE_NAME: "hero-device-override",
  mockUsers: {
    firstTimeVisitor: {
      flags: {
        showDefaultLandingHero: true,
        showPersonalizedHeroBanner: false,
        customerPreQualified: false,
        customerTestDriveScheduled: false,
        customerTradeInSubmitted: false,
        redirectToMyGarage: false,
      },
      description: "First time user or last visit",
    },
    authenticatedPrequalified: {
      flags: {
        showDefaultLandingHero: false,
        showPersonalizedHeroBanner: true,
        customerPreQualified: true,
        customerTestDriveScheduled: true,
        customerTradeInSubmitted: true,
        redirectToMyGarage: false,
      },
      description: "Authenticated, prequalified",
    },
    returningUnauthenticated: {
      flags: {
        showDefaultLandingHero: false,
        showPersonalizedHeroBanner: true,
        customerPreQualified: false,
        customerTestDriveScheduled: true,
        customerTradeInSubmitted: true,
        redirectToMyGarage: false,
      },
      description: "Unauthenticated, both cards completed",
    },
  },
}));

vi.mock("@shared/lib/cookie-cache", () => ({
  getCookie: getCookieMock,
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Heading: ({ children }: { children?: ReactNode }) => (
    <span data-testid="heading">{children}</span>
  ),
}));

import { FeatureFlagDebug } from "../feature-flag-debug";

function makeFakeStorage() {
  const store: Record<string, string> = {};
  return {
    store,
    setItem: vi.fn((k: string, v: string) => {
      store[k] = v;
    }),
    getItem: vi.fn((k: string) => store[k] ?? null),
    removeItem: vi.fn((k: string) => {
      delete store[k];
    }),
    clear: vi.fn(() => {
      for (const k of Object.keys(store)) {
        delete store[k];
      }
    }),
    key: vi.fn((i: number) => Object.keys(store)[i] ?? null),
    get length() {
      return Object.keys(store).length;
    },
  };
}

function setupLocationReload() {
  const reloadMock = vi.fn();
  vi.stubGlobal("location", { reload: reloadMock } as unknown as Location);
  return reloadMock;
}

// Tests

describe("FeatureFlagDebug", () => {
  let fakeStorage: ReturnType<typeof makeFakeStorage>;

  beforeEach(() => {
    getCookieMock.mockReturnValue(null);
    fakeStorage = makeFakeStorage();
    vi.stubGlobal("localStorage", fakeStorage);
    Reflect.deleteProperty(window, "cookieStore");
  });

  afterEach(() => {
    vi.unstubAllEnvs();
    vi.unstubAllGlobals();
  });

  // Production guard

  it("returns null in production", () => {
    vi.stubEnv("NODE_ENV", "production");
    const { container } = render(<FeatureFlagDebug />);
    expect(container.firstChild).toBeNull();
  });

  // Development rendering

  it("renders the floating toggle button in development", () => {
    render(<FeatureFlagDebug />);
    expect(screen.getByTitle("Feature Flags Debug")).toBeTruthy();
  });

  // useEffect: cookie sync on mount

  it("reads a valid cookie on mount and syncs to localStorage", async () => {
    getCookieMock.mockReturnValue("authenticatedPrequalified");
    render(<FeatureFlagDebug />);
    await waitFor(() => {
      expect(fakeStorage.store["feature-flags-user"]).toBe("authenticatedPrequalified");
    });
  });

  it("ignores a cookie value that has no matching mockUser", async () => {
    getCookieMock.mockReturnValue("unknownUser");
    render(<FeatureFlagDebug />);
    await waitFor(() => {
      expect(fakeStorage.store["feature-flags-user"]).toBeUndefined();
    });
  });

  it("does nothing when cookie is null on mount", async () => {
    getCookieMock.mockReturnValue(null);
    render(<FeatureFlagDebug />);
    await waitFor(() => {
      expect(fakeStorage.store["feature-flags-user"]).toBeUndefined();
    });
  });

  // Panel open / close

  it("opens the debug panel when the button is clicked", () => {
    render(<FeatureFlagDebug />);
    fireEvent.click(screen.getByTitle("Feature Flags Debug"));
    expect(screen.getByTestId("heading")).toBeTruthy();
  });

  it("closes the debug panel when ✕ is clicked", () => {
    render(<FeatureFlagDebug />);
    fireEvent.click(screen.getByTitle("Feature Flags Debug"));
    fireEvent.click(screen.getByText("✕"));
    expect(screen.queryByTestId("heading")).toBeNull();
  });

  it("toggles panel closed when toggle button is clicked again", () => {
    render(<FeatureFlagDebug />);
    const btn = screen.getByTitle("Feature Flags Debug");
    fireEvent.click(btn);
    fireEvent.click(btn);
    expect(screen.queryByTestId("heading")).toBeNull();
  });

  // handleUserChange: cookieStore path

  it("sets cookie via cookieStore when available and reloads the page", () => {
    const cookieStoreSet = vi.fn();
    vi.stubGlobal("cookieStore", { set: cookieStoreSet } as unknown as CookieStore);
    const reloadMock = setupLocationReload();

    render(<FeatureFlagDebug />);
    fireEvent.click(screen.getByTitle("Feature Flags Debug"));

    const select = screen.getByLabelText("Select test user scenario");
    fireEvent.change(select, { target: { value: "authenticatedPrequalified" } });

    expect(cookieStoreSet).toHaveBeenCalledWith(
      expect.objectContaining({
        name: "feature-flags-user",
        value: "authenticatedPrequalified",
        path: "/",
      })
    );
    expect(fakeStorage.store["feature-flags-user"]).toBe("authenticatedPrequalified");
    expect(reloadMock).toHaveBeenCalledTimes(1);
  });

  // handleUserChange: document.cookie fallback

  it("falls back to document.cookie when cookieStore is unavailable and reloads", () => {
    const reloadMock = setupLocationReload();

    render(<FeatureFlagDebug />);
    fireEvent.click(screen.getByTitle("Feature Flags Debug"));

    const select = screen.getByLabelText("Select test user scenario");
    fireEvent.change(select, { target: { value: "firstTimeVisitor" } });

    expect(fakeStorage.store["feature-flags-user"]).toBe("firstTimeVisitor");
    expect(reloadMock).toHaveBeenCalledTimes(1);
    expect(document.cookie).toContain("feature-flags-user=firstTimeVisitor");
  });

  // User description

  it("shows the description for the current user selection", () => {
    render(<FeatureFlagDebug />);
    fireEvent.click(screen.getByTitle("Feature Flags Debug"));
    expect(screen.getByText(RE_FIRST_TIME)).toBeTruthy();
  });

  it("shows updated description after changing the user", () => {
    setupLocationReload();
    render(<FeatureFlagDebug />);
    fireEvent.click(screen.getByTitle("Feature Flags Debug"));
    const select = screen.getByLabelText("Select test user scenario");
    fireEvent.change(select, { target: { value: "returningUnauthenticated" } });
    expect(screen.getByText(RE_UNAUTH)).toBeTruthy();
  });

  // getUserFlags: flag display

  it("renders active flags for the current user", () => {
    getCookieMock.mockReturnValue("authenticatedPrequalified");
    render(<FeatureFlagDebug />);
    fireEvent.click(screen.getByTitle("Feature Flags Debug"));
    expect(screen.getByText("showPersonalizedHeroBanner")).toBeTruthy();
  });

  it("renders flag rows with check/cross icons", () => {
    getCookieMock.mockReturnValue("firstTimeVisitor");
    render(<FeatureFlagDebug />);
    fireEvent.click(screen.getByTitle("Feature Flags Debug"));
    const checks = screen.getAllByText("✓");
    const crosses = screen.getAllByText("✗");
    expect(checks.length).toBeGreaterThan(0);
    expect(crosses.length).toBeGreaterThan(0);
  });

  it("renders no flag rows when getUserFlags returns undefined (unknown user type)", () => {
    render(<FeatureFlagDebug />);
    fireEvent.click(screen.getByTitle("Feature Flags Debug"));
    expect(screen.getByText("showDefaultLandingHero")).toBeTruthy();
  });
});
