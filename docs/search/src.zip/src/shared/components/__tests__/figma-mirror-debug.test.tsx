import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import type { ReactNode } from "react";
import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("@tfs-ucmp/ui", () => ({
  Heading: ({ children }: { children?: ReactNode }) => <span>{children}</span>,
}));

import { FigmaMirrorDebug } from "../figma-mirror-debug";

describe("FigmaMirrorDebug", () => {
  afterEach(() => {
    vi.unstubAllEnvs();
    vi.unstubAllGlobals();
  });

  it("returns null in production", () => {
    vi.stubEnv("NODE_ENV", "production");
    const { container } = render(<FigmaMirrorDebug />);
    expect(container.firstChild).toBeNull();
  });

  it("renders the floating toggle button in development", () => {
    render(<FigmaMirrorDebug />);
    expect(screen.getByTitle("Figma Mirror Debug")).toBeTruthy();
  });

  it("loads local references when the panel opens", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: true,
        json: async () => ({
          references: [{ name: "home-page.png", url: "/api/debug/figma-references/home-page.png" }],
        }),
      })
    );

    render(<FigmaMirrorDebug />);

    fireEvent.click(screen.getByTitle("Figma Mirror Debug"));

    await waitFor(() => {
      expect(screen.getByRole("option", { name: "home-page.png" })).toBeTruthy();
    });
  });

  it("opens the panel and toggles the button label", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: true,
        json: async () => ({ references: [] }),
      })
    );

    render(<FigmaMirrorDebug />);

    fireEvent.click(screen.getByTitle("Figma Mirror Debug"));
    await waitFor(() => {
      expect(screen.getByText("Figma Mirror")).toBeTruthy();
    });
    expect(screen.getByRole("button", { name: "Hide Overlay" })).toBeTruthy();

    fireEvent.click(screen.getByRole("button", { name: "Hide Overlay" }));
    expect(screen.getByRole("button", { name: "Show Overlay" })).toBeTruthy();
  });
});
