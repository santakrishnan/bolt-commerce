import { render, screen } from "@arrow/vitest-config/test-utils";
import { beforeEach, describe, expect, it, vi } from "vitest";
import MyGaragePage from "../page";

vi.mock("@config/flags/flags", () => ({
  getUserInfo: vi.fn(),
}));

vi.mock("@features/my-garage", () => ({
  MyGarageWrapper: vi.fn(() => <div>MyGarageWrapper</div>),
}));

import { getUserInfo } from "@config/flags/flags";
import { MyGarageWrapper } from "@features/my-garage";

describe("MyGaragePage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders MyGarageWrapper for unauthenticated users with showUserName=false", async () => {
    (getUserInfo as any).mockResolvedValue({ isAuthenticated: false });

    const component = await MyGaragePage();
    render(component);

    expect(screen.getByText("MyGarageWrapper")).toBeInTheDocument();
    expect(MyGarageWrapper).toHaveBeenCalledWith(
      { bannerHeightClass: "h-[422px] lg:h-87.5", showUserName: false },
      undefined
    );
  });

  it("renders MyGarageWrapper for authenticated users with showUserName=true", async () => {
    (getUserInfo as any).mockResolvedValue({ isAuthenticated: true });

    const component = await MyGaragePage();
    render(component);

    expect(screen.getByText("MyGarageWrapper")).toBeInTheDocument();
    expect(MyGarageWrapper).toHaveBeenCalledWith(
      { bannerHeightClass: "h-[422px] lg:h-87.5", showUserName: true },
      undefined
    );
  });

  it("always calls getUserInfo", async () => {
    (getUserInfo as any).mockResolvedValue({ isAuthenticated: false });

    await MyGaragePage();

    expect(getUserInfo).toHaveBeenCalledOnce();
  });
});
