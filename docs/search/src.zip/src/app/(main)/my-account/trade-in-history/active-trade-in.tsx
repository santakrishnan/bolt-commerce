"use client";

import { AppButton } from "@shared/components/button";
import Image from "next/image";

export interface ActiveTradeInProps {
  current_status?: "expires" | "completed" | "expired";
  imageSrc?: string;
  mileage?: string;
  offerAmount?: string;
  vehicle?: {
    year?: number;
    make?: string;
    model?: string;
    trim?: string;
  };
}

export default function ActiveTradeIn({
  vehicle,
  offerAmount = "$12,500",
  mileage = "42,000 mi",
  imageSrc,
}: ActiveTradeInProps) {
  const vehicleLabel = vehicle
    ? `${vehicle.year ?? ""} ${vehicle.make ?? ""} ${vehicle.model ?? ""}`.trim()
    : "Unknown vehicle";
  return (
    <div className="w-full rounded-none border-border border-t border-r border-b border-l p-1 md:rounded-[var(--radius-md)] md:border md:border-border md:p-4">
      <div className="flex w-full flex-col gap-3">
        <div className="flex items-center justify-center">
          <p className="font-bold text-sm">Recent Valuations</p>
        </div>
        <hr className="mb-4 border-structure-interaction-subtle-border" />
        <div className="flex w-full flex-col gap-4 md:flex-row md:items-center md:justify-center">
          <div className="w-full flex-shrink-0 md:w-2/5">
            {imageSrc ? (
              <div className="relative h-40 w-full overflow-hidden rounded">
                <Image alt="vehicle" fill src={imageSrc} style={{ objectFit: "cover" }} />
              </div>
            ) : (
              <div className="flex h-40 w-full items-center justify-center rounded bg-gray-100">
                <svg
                  aria-hidden
                  height="40"
                  viewBox="0 0 160 80"
                  width="80"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <title>Vehicle placeholder</title>
                  <rect fill="#E5E7EB" height="80" rx="8" width="160" />
                  <path d="M20 50 h120" stroke="#d1d5db" strokeLinecap="round" strokeWidth="6" />
                  <circle cx="45" cy="62" fill="#9CA3AF" r="8" />
                  <circle cx="115" cy="62" fill="#9CA3AF" r="8" />
                </svg>
              </div>
            )}
          </div>

          <div className="flex w-full flex-col justify-center text-center md:w-auto md:text-left">
            <div>
              <div className="mb-2 font-bold text-lg">{vehicleLabel}</div>
              <div className="flex gap-4 text-sm">
                <div className="w-full sm:w-auto">
                  <div className="text-sm">Offer Amount</div>
                  <div className="font-bold text-sm md:text-lg">{offerAmount}</div>
                </div>
                <div className="w-full sm:w-auto">
                  <div className="text-sm">Mileage</div>
                  <div className="font-bold text-sm md:text-lg">{mileage}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4 flex w-full items-center justify-center text-center">
        <hr className="mb-4 border-structure-interaction-subtle-border" />
        <div className="flex w-full flex-col justify-center gap-2 sm:gap-3 md:flex-row">
          <div className="w-full md:w-auto">
            <AppButton className="w-full md:w-auto" size="md" variant="primary">
              Shop With Your Trade-In
            </AppButton>
          </div>
          <div className="sm:w-full md:w-auto">
            <AppButton className="w-full md:w-auto" size="md" variant="tertiary">
              Contact Dealer
            </AppButton>
          </div>
          <div className="w-full md:w-auto">
            <AppButton className="w-full md:w-auto" size="md" variant="tertiary">
              Contact TFS
            </AppButton>
          </div>
        </div>
      </div>
    </div>
  );
}
