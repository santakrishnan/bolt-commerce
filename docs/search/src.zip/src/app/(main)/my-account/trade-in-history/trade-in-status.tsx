"use client";

export interface TradeInStatusProps {
  expiresInDays?: number;
  status?: "expires" | "completed" | "expired";
}

export default function TradeInStatus({ status = "expires", expiresInDays }: TradeInStatusProps) {
  let label: string;
  if (status === "expired") {
    label = "Expired";
  } else if (status === "completed") {
    label = "Completed";
  } else {
    label = `Expires in ${typeof expiresInDays === "number" ? expiresInDays : 7} days`;
  }

  const shared: React.CSSProperties = {
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    borderRadius: 9999,
    padding: "1px 6px",
    fontSize: 10,
    fontWeight: 500,
  };

  const styles = {
    completed: {
      ...shared,
      border: "1px solid #BBF7D0",
      background: "#ECFDF5",
      color: "#166534",
    } as React.CSSProperties,
    expired: {
      ...shared,
      border: "1px solid #E5E7EB",
      background: "#F8FAFC",
      color: "#6B7280",
    } as React.CSSProperties,
    expires: {
      ...shared,
      border: "1px solid #FBBF24",
      background: "#FFFBEB",
      color: "#92400E",
    } as React.CSSProperties,
  };

  let style: React.CSSProperties;
  if (status === "expired") {
    style = styles.expired;
  } else if (status === "completed") {
    style = styles.completed;
  } else {
    style = styles.expires;
  }

  return <span style={style}>{label}</span>;
}
