"use client";

import Image from "next/image";
import Link from "next/link";

export interface PastTradeInProps {
  id?: string;
  imageSrc?: string;
  offerAmount?: string;
  status?: "completed" | "expired" | string;
  submitted?: string;
  vehicle?: { year?: number; make?: string; model?: string; trim?: string };
}

export default function PastTradeIn({
  id,
  vehicle,
  imageSrc,
  offerAmount = "$0",
  submitted,
}: PastTradeInProps) {
  const vehicleLabel = vehicle
    ? `${vehicle.year ?? ""} ${vehicle.make ?? ""} ${vehicle.model ?? ""}`.trim()
    : "Unknown vehicle";

  return (
    <div className="flex w-full items-center gap-[var(--spacing-md)] rounded-[var(--radius-sm)]">
      <div className="flex w-full flex-col items-center justify-between md:flex-row">
        <div className="flex w-full flex-col items-center gap-[var(--spacing-md)] md:flex-row">
          <div className="w-full flex-shrink-0 md:w-34">
            {imageSrc ? (
              <div className="relative h-35 w-full overflow-hidden rounded-[var(--radius-md)] md:h-24">
                <Image alt="vehicle" fill src={imageSrc} style={{ objectFit: "cover" }} />
              </div>
            ) : (
              <div className="flex h-34 w-full items-center justify-center rounded-[var(--radius-md)] bg-[color:var(--color-brand-surface)]">
                <svg
                  aria-hidden
                  height="30"
                  viewBox="0 0 160 80"
                  width="60"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <title>Vehicle placeholder</title>
                  <rect fill="var(--color-brand-surface)" height="80" rx="8" width="160" />
                </svg>
              </div>
            )}
          </div>

          <div className="flex w-full flex-col text-left">
            <div className="font-bold text-[length:var(--text-md)]">{vehicleLabel}</div>
            <div className="text-[color:var(--color-states-muted-foreground)] text-[length:var(--text-xs)]">{`Submitted ${submitted ?? ""}`}</div>
          </div>
        </div>

        <div className="mt-[var(--spacing-sm)] flex w-full flex-col items-center gap-[var(--spacing-2xs)] md:mt-0 md:w-3/5 md:flex-row md:gap-[var(--spacing-5)]">
          <div className="flex w-full items-center justify-between md:justify-end">
            <div className="w-full text-left text-sm md:text-right xl:w-28">
              <div>Offer</div>
              <div className="font-bold text-base">{offerAmount}</div>
            </div>
          </div>
          <div className="mt-[var(--spacing-sm)] flex w-full items-center text-left md:mt-0 md:text-right lg:w-40">
            <Link
              className="flex gap-[var(--spacing-2xs)] font-bold text-[length:var(--text-xs)]"
              href={`/my-account/trade-in-history/${id ?? ""}`}
            >
              View details
              <Image alt="arrow" height={4} src="/images/vdp/vdp_arrow_right.svg" width={5} />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export interface PastTradeInListProps {
  items?: PastTradeInProps[];
}

export function PastTradeInList({ items }: PastTradeInListProps) {
  if (!items || items.length === 0) {
    return null;
  }

  return (
    <div className="flex flex-col">
      <h3 className="font-bold text-base">Past Trade-Ins</h3>
      <div className="mt-[var(--spacing-xs)] h-[var(--border-width-1)] bg-[color:var(--color-structure-interaction-subtle-border)]" />
      <div className="mt-3 flex flex-col">
        <style>{`
          @keyframes slideInFromRight {
            0% { opacity: 0; transform: translateX(20px); }
            100% { opacity: 1; transform: translateX(0); }
          }
        `}</style>
        {(() => {
          const ordered = [...items].sort((a, b) => {
            const aExpired = a.status === "expired";
            const bExpired = b.status === "expired";
            if (aExpired === bExpired) {
              return 0;
            }
            return aExpired ? 1 : -1;
          });
          return ordered.map((it, idx) => (
            <div
              key={it.id ?? idx}
              style={{ animation: `slideInFromRight 400ms ease-out ${idx * 80}ms both` }}
            >
              <PastTradeIn {...it} />
              <div className="mt-[var(--spacing-sm)] h-[var(--border-width-1)] bg-[color:var(--color-structure-interaction-subtle-border)]" />
            </div>
          ));
        })()}
      </div>
    </div>
  );
}
