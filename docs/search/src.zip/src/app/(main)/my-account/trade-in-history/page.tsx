"use client";

import { AppButton } from "@shared/components/button";
import { Heading } from "@/components/heading";
import ActiveTradeIn from "./active-trade-in";
import { PastTradeInList } from "./past-trade-in";
import tradeInData from "./trade-in-data.json";

export default function TradeInHistoryPage() {
  return (
    <div className="flex flex-col gap-y-[var(--spacing-xl)] rounded-[var(--radius-md)] bg-white p-[var(--spacing-xl)] lg:px-[var(--spacing-xl)] lg:py-[var(--spacing-2xl)] xl:p-[var(--spacing-2xl)]">
      <div className="flex flex-col items-center justify-between gap-x-[var(--spacing-md)] md:flex-row">
        <div className="flex flex-col gap-y-[var(--spacing-md)] text-center md:text-left">
          <Heading
            className="text-[color:var(--color-core-surfaces-foreground)]"
            level={2}
            weight="semibold"
          >
            Trade-In History
          </Heading>
          <p className="text-[color:var(--color-states-muted-foreground)]">
            Choose How and when you to be notified
          </p>
        </div>

        <div className="mt-4 flex w-full items-center justify-center md:mt-0 md:w-auto">
          <AppButton size="md" variant="primary">
            Get a new trade-in value
          </AppButton>
        </div>
      </div>
      <div className="h-px bg-structure-interaction-subtle-border" />

      <div>
        {tradeInData && tradeInData.length > 0 ? (
          <ActiveTradeIn {...tradeInData[0]} />
        ) : (
          <ActiveTradeIn />
        )}
      </div>
      <div className="mt-4">
        {tradeInData && tradeInData.length > 1 ? (
          <PastTradeInList items={tradeInData.slice(1)} />
        ) : null}
      </div>
    </div>
  );
}
