import "@testing-library/jest-dom";
import { beforeEach, describe, expect, it, vi } from "vitest";

// Mock next/navigation
const mockRedirect = vi.fn();
vi.mock("next/navigation", () => ({
  redirect: (path: string) => mockRedirect(path),
}));

// Mock getUserInfo
vi.mock("@config/flags/flags", () => ({
  getUserInfo: vi.fn(),
}));

import * as flags from "@config/flags/flags";
import MyAccountPage from "../page";

describe("MyAccountPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("redirects unauthenticated users to home page", async () => {
    vi.mocked(flags.getUserInfo).mockResolvedValue({
      isAuthenticated: false,
    } as any);

    await MyAccountPage();

    expect(mockRedirect).toHaveBeenCalledWith("/");
  });

  it("redirects authenticated users to my-details page", async () => {
    vi.mocked(flags.getUserInfo).mockResolvedValue({
      isAuthenticated: true,
    } as any);

    await MyAccountPage();

    expect(mockRedirect).toHaveBeenCalledWith("/my-account/my-details");
  });

  it("calls getUserInfo to check authentication status", async () => {
    vi.mocked(flags.getUserInfo).mockResolvedValue({
      isAuthenticated: true,
    } as any);

    await MyAccountPage();

    expect(flags.getUserInfo).toHaveBeenCalled();
  });
});
