import UserDetailsWrapper from "~/features/my-account/components/user-details/user-details-wrapper";
export default async function Page() {
  return <UserDetailsWrapper />;
}
