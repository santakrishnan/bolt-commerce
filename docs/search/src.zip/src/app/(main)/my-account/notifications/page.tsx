import NotificationsWrapper from "~/features/my-account/components/notifications/notifications-wrapper";

export default async function Page() {
  return <NotificationsWrapper />;
}
