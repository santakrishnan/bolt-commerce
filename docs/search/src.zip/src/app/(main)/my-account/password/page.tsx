import { PasswordForm } from "~/features/my-account/components/password/password-form";

export default function Page() {
  return <PasswordForm />;
}
