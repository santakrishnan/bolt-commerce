import { headers } from "next/headers";
import { PreQualificationHeader } from "~/features/my-account/components/pre-qualification/pre-qualification-header";
import { TestDrive } from "~/features/my-account/components/pre-qualification/test-drive";
import type { VehicleData } from "~/features/my-account/components/pre-qualification/vehicle-card";
import { VehicleList } from "~/features/my-account/components/pre-qualification/vehicle-list";
import { WhatToBring } from "~/features/my-account/components/pre-qualification/what-to-bring";
import testDriveData from "./test-drive.json";
import vehiclesData from "./vehicles.json";
import whatToBringData from "./what-to-bring.json";

const vehicles: VehicleData[] = vehiclesData;

const bringItems: string[] = whatToBringData.items;

export default async function PreQualificationPage() {
  await headers();
  const currentTimeMs = Date.now();

  return (
    <div className="flex flex-col gap-[var(--spacing-2xl)] rounded-[var(--radius-md)] bg-[var(--color-surface)] p-[var(--spacing-2xl)]">
      <PreQualificationHeader
        subtitle="Your pre-qualification details and next steps."
        title="Pre-Qualification"
      />

      <VehicleList currentTimeMs={currentTimeMs} vehicles={vehicles} />

      <WhatToBring items={bringItems} tradeInNote={whatToBringData.tradeInNote} />

      <TestDrive
        locationName={testDriveData.locationName}
        vehicleName={testDriveData.vehicleName}
      />
    </div>
  );
}
