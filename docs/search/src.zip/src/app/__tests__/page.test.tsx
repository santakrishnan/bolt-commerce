import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

const garageRegex = /Garage/;

vi.mock("next/headers", () => ({
  headers: vi.fn(async () => ({
    get: vi.fn(() => "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)"),
  })),
}));

vi.mock("@config/flags/flags", () => ({
  redirectToMyGarage: vi.fn(() => Promise.resolve(false)),
  getUserInfo: vi.fn(() => Promise.resolve({ isAuthenticated: false, firstName: "" })),
  showPersonalizedHeroBanner: vi.fn(() => Promise.resolve(false)),
  customerPreQualified: vi.fn(() => Promise.resolve(false)),
  heroDeviceTypeOverride: vi.fn(() => Promise.resolve("auto")),
}));
vi.mock("@features/my-garage", () => ({
  MyGarageWrapper: ({ showUserName }: { showUserName: boolean }) => (
    <div>Garage {showUserName ? "User" : ""}</div>
  ),
}));
vi.mock("@features/landing", () => ({
  HomeHero: () => <div>HomeHero</div>,
  BuyingProcess: () => <div>BuyingProcess</div>,
  ArrowInspectedSectionWrapper: () => <div>ArrowInspectedSection</div>,
  ArrowInspectedSkeleton: () => <div>ArrowInspectedSkeleton</div>,
  CustomerJourneyCarouselSection: () => <div>CustomerJourneyCarouselSection</div>,
  CustomerJourneySkeleton: () => <div>CustomerJourneySkeleton</div>,
  VehicleFinderQuickLinks: () => <div>VehicleFinderQuickLinks</div>,
  VehicleFinderSkeleton: () => <div>VehicleFinderSkeleton</div>,
  VehicleTypeSelectorSkeleton: () => <div>VehicleTypeSelectorSkeleton</div>,
  VehicleTypeSelectorWrapper: () => <div>VehicleTypeSelectorWrapper</div>,
}));
vi.mock("next/dynamic", () => ({
  default: (fn: () => Promise<{ default: React.ComponentType }>) => {
    let Component: React.ComponentType | null = null;
    fn().then((mod) => {
      Component = mod.default;
    });
    return (props: Record<string, unknown>) => (Component ? <Component {...props} /> : null);
  },
}));

type MockFn = ReturnType<typeof vi.fn>;

describe("HomePageGateCheck", () => {
  beforeEach(() => {
    vi.resetModules();
  });

  it("renders MyGarageWrapper when authenticated user has redirectToMyGarage=true", async () => {
    const flags = await import("@config/flags/flags");
    (flags.redirectToMyGarage as unknown as MockFn).mockResolvedValue(true);
    (flags.getUserInfo as unknown as MockFn).mockResolvedValue({
      isAuthenticated: true,
      firstName: "Sarah",
    });

    const { HomePageGateCheck } = await import("../(main)/page");
    render(await HomePageGateCheck());

    expect(await screen.findByText(garageRegex)).toBeInTheDocument();
    expect(screen.queryByText("HomeHero")).not.toBeInTheDocument();
  }, 15_000);

  it("renders MyGarageWrapper for returning unauthenticated user when redirectToMyGarage=true", async () => {
    const flags = await import("@config/flags/flags");
    (flags.redirectToMyGarage as unknown as MockFn).mockResolvedValue(true);
    (flags.getUserInfo as unknown as MockFn).mockResolvedValue({
      isAuthenticated: false,
      firstName: "Emily",
    });

    const { HomePageGateCheck } = await import("../(main)/page");
    render(await HomePageGateCheck());

    expect(await screen.findByText(garageRegex)).toBeInTheDocument();
    expect(screen.queryByText("HomeHero")).not.toBeInTheDocument();
  }, 15_000);

  it("renders HomeHero for new user", async () => {
    const flags = await import("@config/flags/flags");
    (flags.redirectToMyGarage as unknown as MockFn).mockResolvedValue(false);
    (flags.getUserInfo as unknown as MockFn).mockResolvedValue({
      isAuthenticated: false,
      firstName: "",
    });
    (flags.showPersonalizedHeroBanner as unknown as MockFn).mockResolvedValue(false);

    const { HomePageGateCheck } = await import("../(main)/page");
    render(await HomePageGateCheck());

    expect(await screen.findByText("HomeHero")).toBeInTheDocument();
    expect(screen.queryByText(garageRegex)).not.toBeInTheDocument();
  }, 15_000);
});
