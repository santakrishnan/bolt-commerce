import { afterEach, beforeEach, describe, expect, it, type Mock, vi } from "vitest";

vi.mock("@features/tracking/lib/server-api", () => ({
  extractForwardHeaders: vi.fn(),
}));
vi.mock("@features/tracking/services/visitor-profile.service", () => ({
  getCachedVisitorProfile: vi.fn(),
  resolveProfile: vi.fn(),
}));
vi.mock("next/server", () => ({
  NextResponse: { json: vi.fn() },
}));

import { extractForwardHeaders } from "@features/tracking/lib/server-api";
import {
  getCachedVisitorProfile,
  resolveProfile,
} from "@features/tracking/services/visitor-profile.service";
import { NextResponse } from "next/server";
import { GET, POST } from "../route";

const mockExtract = extractForwardHeaders as unknown as Mock;
const mockGetCached = getCachedVisitorProfile as unknown as Mock;
const mockResolve = resolveProfile as unknown as Mock;
const mockNextJson = NextResponse.json as unknown as Mock;

describe("visitor-profile route", () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  it("GET returns 400 when visitorId missing", async () => {
    mockNextJson.mockReturnValue({ ok: false });

    const req = { url: "https://example.com/api/visitor-profile" } as any;
    const res = await GET(req);

    expect(mockNextJson).toHaveBeenCalledWith(
      { error: "visitorId query parameter is required", code: "MISSING_VISITOR_ID" },
      { status: 400 }
    );
    expect(res).toEqual({ ok: false });
  });

  it("GET returns 404 when profile not found", async () => {
    mockGetCached.mockResolvedValue(null);
    mockNextJson.mockReturnValue({ ok: false });

    const req = { url: "https://example.com/api/visitor-profile?visitorId=missing" } as any;
    const res = await GET(req);

    expect(mockGetCached).toHaveBeenCalledWith("missing");
    expect(mockNextJson).toHaveBeenCalledWith(
      { error: "Visitor profile not found", code: "NOT_FOUND" },
      { status: 404 }
    );
    expect(res).toEqual({ ok: false });
  });

  it("GET returns profile on success", async () => {
    const profile = { id: "p1", name: "Alice" };
    mockGetCached.mockResolvedValue(profile);
    mockNextJson.mockReturnValue({ ok: true });

    const req = { url: "https://example.com/api/visitor-profile?visitorId=fp1" } as any;
    const res = await GET(req);

    expect(mockGetCached).toHaveBeenCalledWith("fp1");
    expect(mockNextJson).toHaveBeenCalledWith({ profile });
    expect(res).toEqual({ ok: true });
  });

  it("GET returns 500 on exception", async () => {
    mockGetCached.mockRejectedValue(new Error("boom"));
    mockNextJson.mockReturnValue({ ok: false });

    const req = { url: "https://example.com/api/visitor-profile?visitorId=fp1" } as any;
    const res = await GET(req);

    expect(mockNextJson).toHaveBeenCalledWith(
      { error: "Internal server error", code: "INTERNAL_ERROR" },
      { status: 500 }
    );
    expect(res).toEqual({ ok: false });
  });

  it("POST returns 400 when ids missing", async () => {
    mockNextJson.mockReturnValue({ ok: false });

    const req = { json: async () => ({}) } as any;
    const res = await POST(req);

    expect(mockNextJson).toHaveBeenCalledWith(
      { error: "fingerprintId and sessionId are required", code: "MISSING_IDS" },
      { status: 400 }
    );
    expect(res).toEqual({ ok: false });
  });

  it("POST returns 400 for unknown action", async () => {
    mockNextJson.mockReturnValue({ ok: false });

    const req = { json: async () => ({ action: "nope" }) } as any;
    const res = await POST(req);

    expect(mockNextJson).toHaveBeenCalledWith(
      { error: "Unknown action: nope", code: "UNKNOWN_ACTION" },
      { status: 400 }
    );
    expect(res).toEqual({ ok: false });
  });

  it("POST resolve calls resolveProfile and returns profileId", async () => {
    const profileId = "prof-1";
    mockExtract.mockReturnValue({ some: "hdr" });
    mockResolve.mockResolvedValue(profileId);
    mockNextJson.mockReturnValue({ ok: true });

    const body = { fingerprintId: "fp1", sessionId: "s1", metadata: { x: 1 } };
    const req = { json: async () => body } as any;

    const res = await POST(req);

    expect(mockResolve).toHaveBeenCalledWith({
      payload: {
        fingerprintId: "fp1",
        sessionId: "s1",
        metadata: { x: 1 },
        fingerprintDetails: null,
      },
      ids: { sessionId: "s1", fingerprintId: "fp1", profileId: null },
      forwardHeaders: { some: "hdr" },
    });
    expect(mockNextJson).toHaveBeenCalledWith({ profileId });
    expect(res).toEqual({ ok: true });
  });

  it("POST rejects when resolveProfile throws (unawaited handler)", async () => {
    mockExtract.mockReturnValue({ some: "hdr" });
    mockResolve.mockRejectedValue(new Error("fail"));

    const body = { fingerprintId: "fp1", sessionId: "s1" };
    const req = { json: async () => body } as any;

    await expect(POST(req)).rejects.toThrow("fail");
    expect(mockNextJson).not.toHaveBeenCalled();
  });

  it("POST returns 500 when request.json throws", async () => {
    mockNextJson.mockReturnValue({ ok: false });

    const req = {
      json: () => {
        throw new Error("bad-json");
      },
    } as any;
    const res = await POST(req);

    expect(mockNextJson).toHaveBeenCalledWith(
      { error: "Internal server error", code: "INTERNAL_ERROR" },
      { status: 500 }
    );
    expect(res).toEqual({ ok: false });
  });
});
