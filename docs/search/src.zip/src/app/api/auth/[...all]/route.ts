import { auth } from "@features/auth/lib/auth";
import { toNextJsHandler } from "better-auth/next-js";

/**
 * Catch-all route that delegates all /api/auth/* requests to better-auth.
 *
 * Handles: sign-up, sign-in, sign-out, session, and future OAuth callbacks.
 */
export const { GET, POST, PATCH, PUT, DELETE } = toNextJsHandler(auth);
