import { afterEach, beforeEach, describe, expect, it, type Mock, vi } from "vitest";

vi.mock("next/server", () => ({
  connection: vi.fn(),
  NextResponse: { json: vi.fn() },
}));

import { connection, NextResponse } from "next/server";
import { GET } from "../route";

const mockConnection = connection as unknown as Mock;
const mockNextJson = NextResponse.json as unknown as Mock;

describe("GET /api/health", () => {
  const FIXED_TIME = new Date("2026-03-22T12:34:56.789Z");

  beforeEach(() => {
    vi.resetAllMocks();
    vi.useFakeTimers();
    vi.setSystemTime(FIXED_TIME);
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("calls connection and returns NextResponse.json with status ok and timestamp", async () => {
    const fakeResponse = { foo: "bar" };
    mockConnection.mockResolvedValue(undefined);
    mockNextJson.mockReturnValue(fakeResponse);

    const res = await GET();

    expect(mockConnection).toHaveBeenCalled();
    expect(mockNextJson).toHaveBeenCalledWith({
      status: "ok",
      timestamp: new Date().toISOString(),
    });
    expect(res).toBe(fakeResponse);
  });

  it("propagates errors from connection and does not call NextResponse.json", async () => {
    mockConnection.mockRejectedValue(new Error("conn-failed"));

    await expect(GET()).rejects.toThrow("conn-failed");
    expect(mockNextJson).not.toHaveBeenCalled();
  });
});
