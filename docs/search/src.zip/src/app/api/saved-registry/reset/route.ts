/**
 * Saved Registry Reset — Dev Utility Route
 *
 * DELETE /api/saved-registry/reset
 *
 * Removes the visitor's saved vehicles and search history entries from the
 * in-memory stores so they are re-seeded from defaults on the next read.
 * Called automatically on sign-out to restore the demo state.
 */

import { extractArrowIds } from "@features/tracking/lib/server-api";
import * as searchHistoryService from "@shared/lib/saved-registry/search-history.service";
import * as vehiclesService from "@shared/lib/saved-registry/vehicles.service";
import { type NextRequest, NextResponse } from "next/server";

function resolveVisitorId(req: NextRequest): string {
  const { fingerprintId } = extractArrowIds(req);
  return fingerprintId ?? "anonymous";
}

export function DELETE(req: NextRequest) {
  try {
    const visitorId = resolveVisitorId(req);
    const profile = req.nextUrl.searchParams.get("profile") ?? undefined;
    vehiclesService.reset(visitorId, profile);
    searchHistoryService.reset(visitorId, profile);
    return new NextResponse(null, { status: 204 });
  } catch (error) {
    console.error("[SavedRegistryReset] DELETE error:", error);
    return NextResponse.json({ error: "Failed to reset saved registry" }, { status: 500 });
  }
}
