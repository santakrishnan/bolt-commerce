import { readdir } from "node:fs/promises";
import { NextResponse } from "next/server";
import {
  getFigmaReferencesDir,
  getReferenceUrl,
  isDebugRouteEnabled,
  isSupportedReferenceFile,
} from "./_lib";

export async function GET() {
  if (!isDebugRouteEnabled()) {
    return NextResponse.json({ references: [] }, { status: 404 });
  }

  try {
    const entries = await readdir(getFigmaReferencesDir(), { withFileTypes: true });
    const references = entries
      .filter((entry) => entry.isFile() && isSupportedReferenceFile(entry.name))
      .map((entry) => ({
        name: entry.name,
        url: getReferenceUrl(entry.name),
      }))
      .sort((left, right) => left.name.localeCompare(right.name));

    return NextResponse.json({ references }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return NextResponse.json({ references: [] }, { headers: { "Cache-Control": "no-store" } });
  }
}
