import { existsSync } from "node:fs";
import path from "node:path";

const IMAGE_EXTENSIONS = new Set([".gif", ".jpeg", ".jpg", ".png", ".svg", ".webp"]);

export function isDebugRouteEnabled() {
  return process.env.NODE_ENV !== "production";
}

export function getFigmaReferencesDir(): string {
  const candidates = [
    path.resolve(process.cwd(), "debug/figma-references"),
    path.resolve(process.cwd(), "apps/web/debug/figma-references"),
  ] as const;

  for (const candidate of candidates) {
    if (existsSync(candidate)) {
      return candidate;
    }
  }

  return candidates[0];
}

export function isSupportedReferenceFile(fileName: string) {
  return IMAGE_EXTENSIONS.has(path.extname(fileName).toLowerCase());
}

export function getImageContentType(fileName: string) {
  const ext = path.extname(fileName).toLowerCase();

  switch (ext) {
    case ".gif":
      return "image/gif";
    case ".jpeg":
    case ".jpg":
      return "image/jpeg";
    case ".png":
      return "image/png";
    case ".svg":
      return "image/svg+xml";
    case ".webp":
      return "image/webp";
    default:
      return "application/octet-stream";
  }
}

export function getReferenceUrl(fileName: string) {
  return `/api/debug/figma-references/${encodeURIComponent(fileName)}`;
}
