/**
 * My Garage Profile API Route
 *
 * GET /api/garage/profile
 *
 * Proxy to the upstream Profile Service for personalized vehicle data.
 * Falls back to mock data when PROFILE_SERVICE_URL is not configured.
 *
 * ─── MOCK MODE (current) ────────────────────────────────────────────────────
 * Active when PROFILE_SERVICE_URL env var is not set or USE_MOCK_PROFILE=true.
 * Data is sourced from:
 *   - bestMatches          → shuffled mockVehicles (@features/search/lib/mock-vehicles)
 *   - becauseYouViewed     → shuffled dataset (services/mock-because-viewed.ts)
 *   - recentPriceDrop      → filtered subset of bestMatches where oldPrice is set
 *   - becauseYouViewedLabel → randomly picked from ["Toyota Camry", "Toyota Tundra", "Toyota RAV4"]
 *
 * ─── PRODUCTION MODE (future) ───────────────────────────────────────────────
 * Set PROFILE_SERVICE_URL to enable. Calls:
 *   GET {PROFILE_SERVICE_URL}/profile/garage
 * with optional Bearer token from PROFILE_API_KEY.
 * Falls back to mock data if the upstream call fails.
 *
 * ─── RELATED MOCKS ──────────────────────────────────────────────────────────
 * Feature flags / user auth state:
 *   src/config/flags/config.ts                              — mock user profiles (Emily, Sarah, James, Marcus)
 *   src/config/flags/flags.ts                               — getUserInfo(), customerPreQualified(), etc.
 *
 * Vehicle data:
 *   src/features/search/lib/mock-vehicles.ts                — shared vehicle dataset (bestMatches)
 *   src/features/my-garage/services/mock-because-viewed.ts  — because-you-viewed dataset
 *
 * Saved vehicles / search history:
 *   /api/saved-registry/vehicles                            — proxied, currently mocked in BED
 *   /api/saved-registry/search-history                      — proxied, currently mocked in BED
 *
 * Pre-qualification days remaining:
 *   Sourced from MockUser.daysRemaining in config.ts (James=12, others default to 30)
 */

import { getMyGarageData } from "@features/my-garage/services/my-garage.service";
import { type NextRequest, NextResponse } from "next/server";

const isDev = process.env.NODE_ENV === "development";
const log = isDev ? console.log.bind(console, "[MyGarageAPI]") : (_msg: unknown) => undefined;
const logError = console.error.bind(console, "[MyGarageAPI]");

export async function GET(_request: NextRequest) {
  try {
    log("Fetching my garage data");
    const data = await getMyGarageData();
    return NextResponse.json({ data });
  } catch (error) {
    logError("GET error:", error);
    return NextResponse.json(
      { error: "Internal server error", code: "INTERNAL_ERROR" },
      { status: 500 }
    );
  }
}
