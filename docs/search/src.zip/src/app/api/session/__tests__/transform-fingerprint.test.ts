import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@features/tracking/services/sealed.service", () => ({
  unsealFingerprintResult: vi.fn(),
}));
vi.mock("@features/tracking/services/fingerprint.service", () => ({
  fetchFingerprintDetails: vi.fn(),
}));

import { resolveFingerprint, transformClientData } from "../transform-fingerprint";

describe("transform-fingerprint", () => {
  beforeEach(() => {
    vi.resetModules();
    vi.restoreAllMocks();
  });

  it("transformClientData maps fields correctly", () => {
    const clientData: any = {
      ip: "1.2.3.4",
      browserDetails: {
        browserName: "B",
        browserMajorVersion: 1,
        os: "OS",
        osVersion: "v",
        device: "d",
      },
      confidence: 0.5,
      visitorFound: true,
      ipLocation: {
        accuracyRadius: 1,
        latitude: 2,
        longitude: 3,
        postalCode: "P",
        timezone: "T",
        city: { name: "C" },
        country: { code: "US", name: "USA" },
        continent: { code: "NA", name: "North" },
        subdivisions: [{ isoCode: "S", name: "Sub" }],
      },
      bot: false,
      incognito: false,
      vpn: false,
      proxy: false,
      tampering: false,
      suspectScore: 0.1,
    };

    const out = transformClientData("fid", "eid", clientData as any);
    expect(out.event_id).toBe("eid");
    expect(out.visitor_id).toBe("fid");
    expect(out.ip_address).toBe("1.2.3.4");
    expect(out.identification?.confidence.score).toBe(0.5);
    expect(out.ip_info).toBeDefined();
  });

  it("resolveFingerprint returns sealed data when unseal succeeds", async () => {
    const sealed = { event_id: "e", visitor_id: "v" } as any;
    const svc = await import("@features/tracking/services/sealed.service");
    (svc.unsealFingerprintResult as any).mockResolvedValue(sealed);

    const out = await resolveFingerprint("fid", "eid", "sealed", undefined as any);
    expect(out).toEqual(sealed);
  });

  it("resolveFingerprint falls back to server API when unseal returns null", async () => {
    const sealedSvc = await import("@features/tracking/services/sealed.service");
    (sealedSvc.unsealFingerprintResult as any).mockResolvedValue(null);
    const fp = await import("@features/tracking/services/fingerprint.service");
    const server = { event_id: "srv" } as any;
    (fp.fetchFingerprintDetails as any).mockResolvedValue(server);

    const out = await resolveFingerprint("fid", "eid", "sealed", undefined as any);
    expect(out).toEqual(server);
  });

  it("resolveFingerprint falls back to clientData when server fails", async () => {
    const sealedSvc = await import("@features/tracking/services/sealed.service");
    (sealedSvc.unsealFingerprintResult as any).mockResolvedValue(null);
    const fp = await import("@features/tracking/services/fingerprint.service");
    (fp.fetchFingerprintDetails as any).mockResolvedValue(null);

    const clientData: any = { ip: "1.1.1.1" };
    const out = await resolveFingerprint("fid", "eid", undefined, clientData);
    expect(out).toBeTruthy();
    expect(out?.visitor_id).toBe("fid");
  });

  it("resolveFingerprint returns null when all strategies fail", async () => {
    const sealedSvc = await import("@features/tracking/services/sealed.service");
    (sealedSvc.unsealFingerprintResult as any).mockResolvedValue(null);
    const fp = await import("@features/tracking/services/fingerprint.service");
    (fp.fetchFingerprintDetails as any).mockRejectedValue(new Error("nope"));

    const out = await resolveFingerprint("fid", "eid", undefined, undefined);
    expect(out).toBeNull();
  });
});
