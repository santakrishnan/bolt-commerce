/**
 * Session API Tests
 *
 * Tests for the Session API route with client-side fingerprinting.
 */

import { ARROW_COOKIE } from "@features/tracking/constants";
import { NextRequest } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

// -----------------------
// Mock some internals before importing route (leave session-cookies real)
// -----------------------
const resolveFingerprintMock = vi.fn();
vi.mock("./transform-fingerprint", () => ({
  resolveFingerprint: (...args: any[]) => resolveFingerprintMock(...args),
}));

const resolveProfileMock = vi.fn();
vi.mock("@features/tracking/services/visitor-profile.service", () => ({
  resolveProfile: (...args: any[]) => resolveProfileMock(...args),
}));

vi.mock("@features/tracking/lib/server-api", () => ({
  extractForwardHeaders: () => ({ "x-forwarded-for": "127.0.0.1" }),
}));

let POST: any;
let GET: any;

const UUID_V4_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const PROF_MOCK_REGEX = /^prof_mock_/;

// Mock environment variables
const mockEnv = {
  USE_MOCK_PROFILE: "true",
  NODE_ENV: "test",
};

describe("Session API", () => {
  const env = process.env as Record<string, string | undefined>;

  beforeEach(
    async () => {
      vi.clearAllMocks();
      Object.assign(process.env, mockEnv);

      // Default mock behaviours
      resolveFingerprintMock.mockResolvedValue(null);
      // resolveProfile returns a unique id per call to avoid collisions in tests
      resolveProfileMock.mockImplementation(() =>
        Promise.resolve(`prof_mock_${Math.random().toString(36).slice(2, 10)}`)
      );

      // Import route after mocks so the module uses the mocked helpers
      const mod = await import("../route");
      POST = mod.POST;
      GET = mod.GET;
    },
    30_000 // 30 seconds timeout
  );

  describe("POST /api/session", () => {
    it("should require fingerprintId in request", async () => {
      const request = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        body: JSON.stringify({}),
      });

      const response = await POST(request);
      const data = await response.json();

      expect(response.status).toBe(400);
      expect(data.error).toBe("Fingerprint ID or sealed result is required");
      expect(data.code).toBe("MISSING_FINGERPRINT");
    });

    it("should return all IDs when fingerprintId is provided", async () => {
      const request = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        body: JSON.stringify({
          fingerprintId: "fp_mock_test123",
          fingerprintMetadata: {
            confidence: 0.95,
            requestId: "1234567890.abc",
            visitorFound: true,
          },
        }),
      });

      const response = await POST(request);
      const data = await response.json();

      expect(response.status).toBe(200);
      expect(data).toHaveProperty("sessionId");
      expect(data).toHaveProperty("fingerprintId");
      expect(data).toHaveProperty("profileId");
      expect(data).toHaveProperty("fingerprintMetadata");

      // Check ID formats
      expect(data.sessionId).toMatch(UUID_V4_REGEX);
      expect(data.fingerprintId).toBe("fp_mock_test123");
      expect(data.profileId).toMatch(PROF_MOCK_REGEX);
    });

    it("should preserve fingerprint metadata from client", async () => {
      const request = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        body: JSON.stringify({
          fingerprintId: "fp_client_abc123",
          fingerprintMetadata: {
            confidence: 0.97,
            requestId: "9876543210.xyz",
            visitorFound: true,
          },
        }),
      });

      const response = await POST(request);
      const data = await response.json();

      expect(data.fingerprintMetadata).toBeDefined();
      expect(data.fingerprintMetadata.confidence).toBe(0.97);
      expect(data.fingerprintMetadata.requestId).toBe("9876543210.xyz");
      expect(data.fingerprintMetadata.visitorFound).toBe(true);
    });

    it("should set individual cookies with correct TTLs", async () => {
      const request = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        body: JSON.stringify({
          fingerprintId: "fp_test",
          eventId: "evt_123",
        }),
      });

      const response = await POST(request);
      const cookies = response.cookies;

      // All 4 individual cookies should be set
      const sessionCookie = cookies.get(ARROW_COOKIE.SESSION_ID);
      const fpCookie = cookies.get(ARROW_COOKIE.FP_ID);
      const profileCookie = cookies.get(ARROW_COOKIE.PROFILE_ID);
      const eventCookie = cookies.get(ARROW_COOKIE.FP_EID);

      expect(sessionCookie).toBeDefined();
      expect(fpCookie).toBeDefined();
      expect(profileCookie).toBeDefined();
      expect(eventCookie).toBeDefined();

      // Check session cookie properties
      expect(sessionCookie?.httpOnly).toBe(true);
      expect(sessionCookie?.sameSite).toBe("lax");
      expect(sessionCookie?.path).toBe("/");

      // Check fingerprint cookie properties
      expect(fpCookie?.httpOnly).toBe(true);
      expect(fpCookie?.sameSite).toBe("lax");
      expect(fpCookie?.path).toBe("/");
    });

    it("should generate unique session IDs on each request", async () => {
      const request1 = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        body: JSON.stringify({ fingerprintId: "fp_test1" }),
      });

      const request2 = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        body: JSON.stringify({ fingerprintId: "fp_test2" }),
      });

      const response1 = await POST(request1);
      const response2 = await POST(request2);

      const data1 = await response1.json();
      const data2 = await response2.json();

      // Session IDs should be unique
      expect(data1.sessionId).not.toBe(data2.sessionId);

      // Fingerprint IDs should match what client sent
      expect(data1.fingerprintId).toBe("fp_test1");
      expect(data2.fingerprintId).toBe("fp_test2");

      // Profile IDs should be unique
      expect(data1.profileId).not.toBe(data2.profileId);
    });

    it("should handle invalid JSON gracefully", async () => {
      const request = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        body: "invalid json",
      });

      const response = await POST(request);

      // Should return error for invalid JSON
      expect(response.status).toBe(500);
    });

    it("should work without fingerprint metadata", async () => {
      const request = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        body: JSON.stringify({
          fingerprintId: "fp_minimal",
        }),
      });

      const response = await POST(request);
      const data = await response.json();

      expect(response.status).toBe(200);
      expect(data.fingerprintId).toBe("fp_minimal");
      expect(data.sessionId).toBeDefined();
      expect(data.profileId).toBeDefined();
    });
  });

  describe("Bootstrap and GET coverage", () => {
    it("GET should return initialized true when session cookie present", async () => {
      // Create a real session via POST so cookies are set on the response
      const initReq = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        body: JSON.stringify({ fingerprintId: "fp_init" }),
      });
      const initRes = await POST(initReq as any);

      // Build cookie header from response cookies
      const cookieHeader = initRes.cookies
        .getAll()
        .map((c: any) => `${c.name}=${c.value}`)
        .join("; ");

      const getReq = new NextRequest("http://localhost:3000/api/session", {
        headers: { cookie: cookieHeader },
      });
      const res = GET(getReq as any);
      const body = await res.json();
      expect(body.initialized).toBe(true);
    });

    it("POST with mode bootstrap returns fed data when fed cookie present", async () => {
      // Make resolveFingerprint return fingerprint details so writeFedData sets FED cookie
      resolveFingerprintMock.mockResolvedValueOnce({
        visitor_id: "fp_init",
        incognito: false,
        ip_info: {
          v4: {
            geolocation: {
              city_name: "C",
              country_name: "X",
              country_code: "XX",
              subdivisions: [{ name: "S", iso_code: "SC" }],
              postal_code: "123",
              timezone: "TZ",
            },
          },
        },
      });

      const initReq = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        body: JSON.stringify({ fingerprintId: "fp_init2" }),
      });
      const initRes = await POST(initReq as any);

      const cookieHeader = initRes.cookies
        .getAll()
        .map((c: any) => `${c.name}=${c.value}`)
        .join("; ");

      // Spy readFedData to return the FED data for bootstrap (avoids flaky cookie parsing)
      const sess = await import("../session-cookies");
      vi.spyOn(sess, "readFedData").mockReturnValue({
        visitorId: "fp_init",
        incognito: false,
      } as any);

      const req = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        headers: { cookie: cookieHeader },
        body: JSON.stringify({ mode: "bootstrap" }),
      });

      const res = await POST(req as any);
      const data = await res.json();

      expect(data.initialized).toBe(true);
      expect(data.fingerprintDetails).toMatchObject({ visitorId: "fp_init" });
    });

    it("POST bootstrap returns initialized:false in development when no session", async () => {
      const orig = env.NODE_ENV;
      env.NODE_ENV = "development";

      // no session cookies
      const req = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        body: JSON.stringify({ mode: "bootstrap" }),
      });

      const res = await POST(req as any);
      const data = await res.json();

      expect(data.initialized).toBe(false);

      env.NODE_ENV = orig;
    });
  });

  describe("Mock vs Real Profile Service", () => {
    it("should use mock profile service when USE_MOCK_PROFILE is true", async () => {
      process.env.USE_MOCK_PROFILE = "true";

      const request = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        body: JSON.stringify({ fingerprintId: "fp_test" }),
      });

      const response = await POST(request);
      const data = await response.json();

      // Mock profile service should return IDs with specific prefix
      expect(data.profileId).toMatch(PROF_MOCK_REGEX);
    });

    it("should use mock profile service when PROFILE_SERVICE_URL is not configured", async () => {
      process.env.PROFILE_SERVICE_URL = undefined;
      process.env.USE_MOCK_PROFILE = "false";

      const request = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        body: JSON.stringify({ fingerprintId: "fp_test" }),
      });

      const response = await POST(request);
      const data = await response.json();

      // Should still work with mock profile service
      expect(data.sessionId).toBeDefined();
      expect(data.fingerprintId).toBe("fp_test");
      expect(data.profileId).toBeDefined();
    });
  });

  describe("Cookie Security", () => {
    it("should set secure flag in production", async () => {
      const originalEnv = env.NODE_ENV;
      env.NODE_ENV = "production";

      const request = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        body: JSON.stringify({ fingerprintId: "fp_test" }),
      });

      const response = await POST(request);
      const cookies = response.cookies;

      // In production, cookies use __Host- prefix
      const sessionCookie = cookies.get(`__Host-${ARROW_COOKIE.SESSION_ID}`);
      const fpCookie = cookies.get(`__Host-${ARROW_COOKIE.FP_ID}`);

      expect(sessionCookie?.secure).toBe(true);
      expect(fpCookie?.secure).toBe(true);

      env.NODE_ENV = originalEnv;
    });

    it("should not set secure flag in development", async () => {
      env.NODE_ENV = "development";

      const request = new NextRequest("http://localhost:3000/api/session", {
        method: "POST",
        body: JSON.stringify({ fingerprintId: "fp_test" }),
      });

      const response = await POST(request);
      const cookies = response.cookies;

      const sessionCookie = cookies.get(ARROW_COOKIE.SESSION_ID);
      const fpCookie = cookies.get(ARROW_COOKIE.FP_ID);

      expect(sessionCookie?.secure).toBe(false);
      expect(fpCookie?.secure).toBe(false);
    });
  });
});
