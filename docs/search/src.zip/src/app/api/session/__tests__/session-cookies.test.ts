import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@shared/lib/sealed-cookie", () => ({
  getCookieConfigs: () => ({
    session: { name: "s", maxAge: 1000, httpOnly: true, secure: false, sameSite: "lax", path: "/" },
    fingerprint: {
      name: "f",
      maxAge: 1000,
      httpOnly: true,
      secure: false,
      sameSite: "lax",
      path: "/",
    },
    profile: { name: "p", maxAge: 1000, httpOnly: true, secure: false, sameSite: "lax", path: "/" },
    event: { name: "e", maxAge: 1000, httpOnly: true, secure: false, sameSite: "lax", path: "/" },
  }),
  decodeCookieValue: (v: string) => v,
  encodeCookieValue: (v: string) => v,
}));

import { readFedData, readSession, writeFedData, writeSession } from "../session-cookies";

describe("session-cookies", () => {
  beforeEach(() => {
    vi.resetModules();
    vi.restoreAllMocks();
  });

  it("readSession returns null when cookies missing", () => {
    const req: any = { cookies: { get: (_: string) => undefined } };
    const out = readSession(req as any);
    expect(out).toBeNull();
  });

  it("readSession returns payload when required cookies present", () => {
    const req: any = {
      cookies: {
        get: (name: string) => {
          if (name === "s") {
            return { value: "sid" };
          }
          if (name === "f") {
            return { value: "fid" };
          }
          if (name === "p") {
            return { value: "pid" };
          }
          return { value: undefined };
        },
      },
    };

    const out = readSession(req as any);
    expect(out).toEqual({
      sessionId: "sid",
      fingerprintId: "fid",
      profileId: "pid",
      eventId: undefined,
    });
  });

  it("writeSession sets cookies on response", () => {
    const sets: any[] = [];
    const res: any = {
      cookies: {
        set: (name: string, value: string, opts: any) => sets.push({ name, value, opts }),
      },
    };

    writeSession(res as any, { sessionId: "S", fingerprintId: "F", profileId: "P", eventId: "E" });

    expect(sets.find((s) => s.name === "s")).toBeTruthy();
    expect(sets.find((s) => s.name === "f")).toBeTruthy();
    expect(sets.find((s) => s.name === "p")).toBeTruthy();
    expect(sets.find((s) => s.name === "e")).toBeTruthy();
  });

  it("readFedData returns parsed object and writeFedData sets cookie", () => {
    const data = { visitorId: "v1", incognito: false };

    const req: any = { cookies: { get: (_name: string) => ({ value: JSON.stringify(data) }) } };
    const out = readFedData(req as any);
    expect(out).toEqual(data);

    const sets: any[] = [];
    const res: any = {
      cookies: {
        set: (name: string, value: string, opts: any) => sets.push({ name, value, opts }),
      },
    };
    writeFedData(res as any, data);
    expect(sets.length).toBe(1);
  });

  it("readFedData returns null for invalid JSON", () => {
    const req: any = { cookies: { get: (_name: string) => ({ value: "not-json" }) } };
    // because decodeCookieValue returns same string, JSON.parse will throw and readFedData must return null
    const out = readFedData(req as any);
    expect(out).toBeNull();
  });
});
