import { ROUTES } from "../../config/routes";

interface AccountItem {
  action?: "logout";
  href: string;
  icon: string;
  label: string;
}

export const ACCOUNT_ITEMS = [
  {
    label: "My Details",
    href: ROUTES.MY_DETAILS,
    icon: "/images/header/icon-user.svg",
  },
  {
    label: "My Garage",
    href: ROUTES.MY_GARAGE,
    icon: "/images/header/icon-heart.svg",
  },
  {
    label: "Password",
    href: ROUTES.PASSWORD,
    icon: "/images/header/icon-lock.svg",
  },
  {
    label: "Pre-Qualification",
    href: ROUTES.PRE_QUALIFICATION,
    icon: "/images/header/icon-pre-qualification.svg",
  },
  {
    label: "Notification Preferences",
    href: ROUTES.NOTIFICATION_PREFERENCES,
    icon: "/images/header/icon-clock.svg",
  },
  {
    label: "Log out",
    href: ROUTES.HOME,
    icon: "/images/header/icon-logout.svg",
    action: "logout",
  },
] as const satisfies readonly AccountItem[];
