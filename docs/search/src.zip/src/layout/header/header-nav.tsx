import { ROUTES } from "@config/routes/constants";
import Link from "next/link";
import { cn } from "@/lib/utils";

export const HeaderNav = ({ useSolidStyles }: { useSolidStyles: boolean }) => {
  const navLinkClass = cn(
    "font-normal text-sm leading-[125%] [font-family:var(--font-toyota-type)] hover:underline hover:underline-offset-4",
    useSolidStyles ? "text-[var(--Core-surfaces-card-foreground)]" : "text-inverse-foreground"
  );

  return (
    <nav
      className={cn(
        "hidden items-center gap-[var(--spacing-2xl)] lg:flex xl:gap-[var(--spacing-2xl)]",
        !useSolidStyles && "mt-[2px]"
      )}
    >
      <Link className={navLinkClass} href={ROUTES.USED_CARS}>
        Buy
      </Link>
      <Link className={navLinkClass} href={ROUTES.FINANCE}>
        Finance
      </Link>
      <Link className={navLinkClass} href={ROUTES.ABOUT}>
        Why Arrow
      </Link>
    </nav>
  );
};
