"use client";
import { ROUTES } from "@config/routes/constants";
import { authClient } from "@features/auth/lib/auth-client";
import { resetFeatureFlagProfileToDefault } from "@features/auth/lib/feature-flag-profile";
import { Button } from "@tfs-ucmp/ui";
import Image from "next/image";
import Link from "next/link";
import { ACCOUNT_ITEMS } from "./constants";

interface MyAccountMenuProps {
  onBack: () => void;
  onClose: () => void;
}

const Divider = () => <div className="h-(--border-width-1) w-full shrink-0 bg-divider" />;

export function MyAccountMenu({ onClose, onBack }: MyAccountMenuProps) {
  const handleLogout = async () => {
    try {
      await authClient.signOut();
    } catch {
      // Best-effort sign out for development fixtures.
    } finally {
      resetFeatureFlagProfileToDefault();
      onClose();
      window.location.assign(ROUTES.HOME);
    }
  };

  return (
    <div className="absolute top-full right-0 left-0 w-full animate-[menuSlideInFromRight_0.2s_ease-out_forwards] lg:hidden">
      <div className="flex flex-col gap-6 rounded-br-md rounded-bl-md border-[#525252] border-t bg-white px-4 py-6">
        {/* Row 1: Back + title */}
        <div className="flex flex-row items-center gap-2.5">
          <Button
            aria-label="Back to menu"
            className="flex items-center justify-center p-0"
            onClick={onBack}
            variant="search"
          >
            <Image
              alt=""
              aria-hidden="true"
              height={12}
              src="/images/header/chevron_left_red.svg"
              width={22}
            />
          </Button>
          <span className="font-[var(--font-weight-semibold)] text-[length:var(--text-md)] leading-[115%]">
            My Account
          </span>
        </div>

        {/* Row 2: Divider */}
        <Divider />

        {/* Row 3: Account items */}
        <div className="flex flex-col gap-3">
          {ACCOUNT_ITEMS.map((item) =>
            "action" in item && item.action === "logout" ? (
              <button
                className="flex flex-row items-center justify-start gap-2 py-3.75 text-left"
                key={item.label}
                onClick={handleLogout}
                type="button"
              >
                <Image alt="" aria-hidden="true" height={16} src={item.icon} width={16} />
                <span className="font-normal text-[#525252] text-[14px] leading-[125%] tracking-[0.01em]">
                  {item.label}
                </span>
              </button>
            ) : (
              <Link
                className="flex flex-row items-center justify-start gap-2 py-3.75"
                href={item.href}
                key={item.label}
                onClick={onClose}
              >
                <Image alt="" aria-hidden="true" height={16} src={item.icon} width={16} />
                <span className="font-normal text-[#525252] text-[14px] leading-[125%] tracking-[0.01em]">
                  {item.label}
                </span>
              </Link>
            )
          )}
        </div>
      </div>
    </div>
  );
}
