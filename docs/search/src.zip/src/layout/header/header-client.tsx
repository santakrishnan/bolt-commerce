"use client";

import { ROUTES } from "@config/routes/constants";
import { useEscapeKey } from "@shared/hooks/use-escape-key";
import { useOutsideClick } from "@shared/hooks/use-outside-click";
import { Button, MenuIcon } from "@tfs-ucmp/ui";
import Image from "next/image";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { AvatarButton, SignInButton } from "./auth-buttons";
import { DesktopAccountMenu } from "./desktop-account-menu";
import { FavoritesButton } from "./favorites-button";
import { HamburgerMenu } from "./hamburger-menu";
import { HeaderNav } from "./header-nav";
import { LocationBlock } from "./location-block";
import { MyAccountMenu } from "./my-account-menu";

interface HeaderClientProps {
  initialFirstName: string;
  initialShowPersonalized: boolean;
}

/**
 * Client header managing nav, auth buttons, and mobile menu state.
 */
export function HeaderClient({ initialShowPersonalized, initialFirstName }: HeaderClientProps) {
  const pathname = usePathname();
  const router = useRouter();
  const isHomePage = pathname === ROUTES.HOME;
  const isMyGaragePage = pathname === ROUTES.MY_GARAGE;
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [backdropVisible, setBackdropVisible] = useState(false);
  const [mobilePanel, setMobilePanel] = useState<"main" | "my-account">("main");
  const [hamburgerFromLeft, setHamburgerFromLeft] = useState(false);
  const [desktopAccountOpen, setDesktopAccountOpen] = useState(false);
  const desktopAccountRef = useRef<HTMLDivElement>(null);

  useEscapeKey(() => setDesktopAccountOpen(false), desktopAccountOpen);
  useOutsideClick(desktopAccountRef, () => setDesktopAccountOpen(false));

  const [showUserAvatar, setShowUserAvatar] = useState(initialShowPersonalized);
  const [userFirstName, setUserFirstName] = useState(initialFirstName);

  useEffect(() => {
    setShowUserAvatar(initialShowPersonalized);
    setUserFirstName(initialFirstName);
  }, [initialShowPersonalized, initialFirstName]);

  useEffect(() => {
    const update = () => setIsScrolled(window.scrollY > 150);
    update();

    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, []);

  useEffect(() => {
    if (mobileMenuOpen) {
      setBackdropVisible(true);
      return;
    }
    const timer = setTimeout(() => setBackdropVisible(false), 200);
    return () => clearTimeout(timer);
  }, [mobileMenuOpen]);

  const useSolidStyles = !(isHomePage || isMyGaragePage) || isScrolled;

  useEffect(() => {
    const { classList } = document.documentElement;
    classList.toggle("bg-white", useSolidStyles);
    classList.toggle("bg-black", !useSolidStyles);
  }, [useSolidStyles]);

  return (
    <>
      <header
        className={cn(
          "absolute top-0 right-0 left-0 z-[35] w-full border-b",
          useSolidStyles
            ? "slide-down fixed border-[var(--color-border)] bg-white"
            : "border-transparent bg-transparent"
        )}
      >
        <div
          className={cn(
            "mx-auto flex h-16 max-w-[var(--container-2xl)] items-center px-4 sm:h-20 sm:px-6 lg:mt-0 lg:px-20",
            !useSolidStyles && "pt-[29px]"
          )}
        >
          <div className="flex items-center lg:flex-1 xl:flex-1">
            <Link className="flex items-center gap-2.5" href={ROUTES.HOME}>
              <div
                aria-hidden="true"
                className="h-10 w-10 bg-[var(--color-brand)] lg:h-[50px] lg:w-[50px]"
              />
              <span
                className={cn(
                  "inline-flex h-4 transition-all duration-300 lg:h-[17px]",
                  !useSolidStyles && "mt-[1px]",
                  useSolidStyles ? "brightness-0" : ""
                )}
              >
                <Image
                  alt="Arrow Logo"
                  className="h-full w-full"
                  height={17}
                  src="/images/header/ARROW.svg"
                  width={89}
                />
              </span>
            </Link>
          </div>

          <HeaderNav useSolidStyles={useSolidStyles} />

          <div className="flex flex-1 items-center justify-end">
            <div className="flex items-center gap-[var(--spacing-xs)] lg:hidden">
              <FavoritesButton useSolidStyles={useSolidStyles} />

              {showUserAvatar ? (
                <div className="relative" ref={desktopAccountRef}>
                  <AvatarButton
                    firstName={userFirstName}
                    isOpen={desktopAccountOpen}
                    onClick={() => router.push(ROUTES.MY_DETAILS)}
                    useSolidStyles={useSolidStyles}
                  />
                </div>
              ) : (
                <SignInButton useSolidStyles={useSolidStyles} />
              )}

              <Button
                aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
                className={cn(
                  "h-10 w-10 rounded-full border transition-colors",
                  useSolidStyles
                    ? "border-border-light hover:bg-muted"
                    : "border-overlay hover:bg-background-overlay-hover",
                  mobileMenuOpen ? "border-[#EB0A1E]" : "border-border-light"
                )}
                onClick={() => {
                  setMobileMenuOpen((s) => !s);
                  setMobilePanel("main");
                  setHamburgerFromLeft(false);
                }}
                size="icon"
                type="button"
                variant="ghost"
              >
                <MenuIcon
                  className={cn(
                    "h-5 w-5 transition-all duration-200",
                    mobileMenuOpen ? "rotate-90 opacity-0" : "rotate-0 opacity-100",
                    useSolidStyles ? "text-icon-primary" : "text-[var(--color-surface)]"
                  )}
                />
                <Image
                  alt=""
                  aria-hidden="true"
                  className={cn(
                    "absolute transition-all duration-200",
                    mobileMenuOpen
                      ? "rotate-0 scale-100 opacity-100"
                      : "rotate-90 scale-75 opacity-0"
                  )}
                  height={16}
                  src="/images/header/icon-close.svg"
                  width={16}
                />
              </Button>
            </div>

            <div className="hidden items-center lg:flex lg:gap-[var(--spacing-sm)]">
              <LocationBlock useSolidStyles={useSolidStyles} />

              <FavoritesButton useSolidStyles={useSolidStyles} />

              {showUserAvatar ? (
                <div className="relative" ref={desktopAccountRef}>
                  <AvatarButton
                    firstName={userFirstName}
                    isOpen={desktopAccountOpen}
                    onClick={() => setDesktopAccountOpen((s) => !s)}
                    useSolidStyles={useSolidStyles}
                  />
                  {desktopAccountOpen && (
                    <DesktopAccountMenu onClose={() => setDesktopAccountOpen(false)} />
                  )}
                </div>
              ) : (
                <SignInButton useSolidStyles={useSolidStyles} />
              )}
            </div>
          </div>
        </div>

        {mobileMenuOpen && mobilePanel === "main" && (
          <HamburgerMenu
            animFromLeft={hamburgerFromLeft}
            onClose={() => setMobileMenuOpen(false)}
            onMyAccountClick={() => {
              setHamburgerFromLeft(false);
              setMobilePanel("my-account");
            }}
          />
        )}
        {mobileMenuOpen && mobilePanel === "my-account" && (
          <MyAccountMenu
            onBack={() => {
              setHamburgerFromLeft(true);
              setMobilePanel("main");
            }}
            onClose={() => setMobileMenuOpen(false)}
          />
        )}
      </header>

      {backdropVisible && (
        <div
          aria-hidden="true"
          className={cn(
            "fixed inset-0 z-34 backdrop-blur-sm transition-opacity duration-200 lg:hidden",
            mobileMenuOpen ? "bg-black/40 opacity-100" : "bg-black/0 opacity-0"
          )}
          onClick={() => {
            setMobileMenuOpen(false);
            setMobilePanel("main");
          }}
        />
      )}

      {useSolidStyles && <div aria-hidden="true" className="h-16 sm:h-20" />}
    </>
  );
}
