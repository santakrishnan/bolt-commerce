import { SAMPLE_USERS } from "@config/auth/sample-users";
import { describe, expect, it } from "vitest";
import { auth, seedReady } from "../auth";

// ── Sample users config ──────────────────────────────────────────────────────

describe("SAMPLE_USERS config", () => {
  it("has at least one user", () => {
    expect(SAMPLE_USERS.length).toBeGreaterThan(0);
  });

  it("every user has a non-empty email", () => {
    for (const user of SAMPLE_USERS) {
      expect(user.email).toBeTruthy();
    }
  });

  it("every user has a non-empty password", () => {
    for (const user of SAMPLE_USERS) {
      expect(user.password).toBeTruthy();
    }
  });

  it("every user has a non-empty name", () => {
    for (const user of SAMPLE_USERS) {
      expect(user.name).toBeTruthy();
    }
  });

  it("all emails are unique", () => {
    const emails = SAMPLE_USERS.map((u) => u.email);
    expect(new Set(emails).size).toBe(emails.length);
  });

  it("all passwords meet the 8-character minimum", () => {
    for (const user of SAMPLE_USERS) {
      expect(user.password.length).toBeGreaterThanOrEqual(8);
    }
  });
});

// ── Auth instance ────────────────────────────────────────────────────────────

describe("auth server instance", () => {
  it("exposes a handler function", () => {
    expect(typeof auth.handler).toBe("function");
  });

  it("exposes the signUpEmail API endpoint", () => {
    expect(typeof auth.api.signUpEmail).toBe("function");
  });

  it("exposes the signInEmail API endpoint", () => {
    expect(typeof auth.api.signInEmail).toBe("function");
  });

  it("exposes the getSession API endpoint", () => {
    expect(typeof auth.api.getSession).toBe("function");
  });
});

// ── Sample-user seeding ──────────────────────────────────────────────────────

describe("sample-user seeding", () => {
  function getFirstSampleUser() {
    const user = SAMPLE_USERS[0];
    if (!user) {
      throw new Error("Expected at least one sample user");
    }
    return user;
  }

  it("seedReady resolves without error", async () => {
    await expect(seedReady).resolves.toBeUndefined();
  });

  it("seeded users can sign in with correct credentials", async () => {
    await seedReady;

    const alice = getFirstSampleUser();

    const result = await auth.api.signInEmail({
      body: { email: alice.email, password: alice.password },
    });

    expect(result.user.email).toBe(alice.email);
  });

  it("sign-in fails with an incorrect password", async () => {
    await seedReady;

    const alice = getFirstSampleUser();

    await expect(
      auth.api.signInEmail({
        body: { email: alice.email, password: "wrong-password" },
      })
    ).rejects.toThrow();
  });

  it("seeds all sample users", async () => {
    await seedReady;

    for (const user of SAMPLE_USERS) {
      const result = await auth.api.signInEmail({
        body: { email: user.email, password: user.password },
      });
      expect(result.user.email).toBe(user.email);
    }
  });
});
