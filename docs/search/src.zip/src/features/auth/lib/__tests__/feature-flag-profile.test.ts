import { createLocalStorageMock } from "@arrow/vitest-config/test-utils";
import { FLAG_COOKIE_NAME } from "@config/flags/config";
import { beforeEach, describe, expect, it, vi } from "vitest";

import {
  resetFeatureFlagProfileToDefault,
  setFeatureFlagProfileForSampleUser,
} from "../feature-flag-profile";

vi.stubGlobal("localStorage", createLocalStorageMock());

describe("feature-flag-profile", () => {
  beforeEach(() => {
    localStorage.clear();
    // biome-ignore lint/suspicious/noDocumentCookie: Cookie setup is required for this browser behavior test.
    document.cookie = `${FLAG_COOKIE_NAME}=; path=/; max-age=0`;
  });

  it("sets mapped profile for a known sample user", () => {
    setFeatureFlagProfileForSampleUser("alice@example.com");

    expect(localStorage.getItem(FLAG_COOKIE_NAME)).toBe("authenticatedPrequalified");
    expect(document.cookie).toContain(`${FLAG_COOKIE_NAME}=authenticatedPrequalified`);
  });

  it("does not overwrite profile for an unknown user", () => {
    setFeatureFlagProfileForSampleUser("unknown@example.com");

    expect(localStorage.getItem(FLAG_COOKIE_NAME)).toBeNull();
  });

  it("resets profile to default user", () => {
    setFeatureFlagProfileForSampleUser("alice@example.com");

    resetFeatureFlagProfileToDefault();

    expect(localStorage.getItem(FLAG_COOKIE_NAME)).toBe("firstTimeVisitor");
    expect(document.cookie).toContain(`${FLAG_COOKIE_NAME}=firstTimeVisitor`);
  });
});
