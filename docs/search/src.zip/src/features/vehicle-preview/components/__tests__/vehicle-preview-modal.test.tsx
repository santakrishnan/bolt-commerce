/**
 * @vitest-environment jsdom
 */

/**
 * Unit tests for VehiclePreviewModal component
 * @module features/vehicle-preview-modal/__tests__/vehicle-preview-modal
 */

import { act, fireEvent, type RenderResult, render, screen } from "@arrow/vitest-config/test-utils";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { VehiclePreviewModal, type VehiclePreviewModalProps } from "../vehicle-preview-modal";

// =============================================================================
// TYPES & INTERFACES
// =============================================================================

/** Rendered component elements for testing */
interface ComponentElements {
  backButton: HTMLElement | null;
  closeButton: HTMLElement | null;
  dialog: HTMLElement | null;
  fullDetailsButton: HTMLElement | null;
  gradients: Element[];
  scrollContainer: HTMLElement | null;
}

/** Mock vehicle data structure */
interface MockVehicleData {
  condition: string;
  dealer: string;
  distance: string;
  drivetrain: string;
  exterior: string;
  exteriorColorCode: string;
  features: string[];
  images: string[];
  inspected: boolean;
  interior: string;
  interiorColorCode: string;
  location: string;
  make: string;
  miles: string;
  model: string;
  mpg: string;
  originalPrice: number;
  price: number;
  stock: string;
  vin: string;
  warranty: boolean;
  year: number;
}

// =============================================================================
// CONSTANTS & CONFIGURATION
// =============================================================================

/** Test identifiers and selectors */
const SELECTORS = {
  DIALOG: "[role='dialog']",
  CLOSE_BUTTON: "button",
  BACK_BUTTON_TEXT: "Back to Search",
  FULL_DETAILS_BUTTON: "Full Details",
  VEHICLE_PREVIEW_TEXT: "Vehicle Preview",
  SCROLL_CONTAINER: ".vehicle-preview-scroll",
  GRADIENT: '[style*="linear-gradient"]',
} as const;

/** Mock vehicle data for testing */
const MOCK_VEHICLE: MockVehicleData = {
  year: 2023,
  make: "Toyota",
  model: "Camry",
  price: 28_500,
  originalPrice: 30_000,
  condition: "Excellent",
  warranty: true,
  inspected: true,
  miles: "15,234 miles",
  drivetrain: "FWD",
  mpg: "28/39 MPG",
  stock: "ABC123",
  vin: "1HGBH41JXMN109186",
  exterior: "White",
  exteriorColorCode: "#FFFFFF",
  interior: "Black",
  interiorColorCode: "#000000",
  dealer: "Toyota of Fort Worth",
  location: "Fort Worth, TX",
  distance: "6.1 mi",
  images: ["/images/vehicles/car1.jpg", "/images/vehicles/car2.jpg"],
  features: ["Sunroof", "Navigation", "Backup Camera"],
} as const;

/** Props configuration */
const DEFAULT_PROPS = {
  VDP_URL: "/used-cars/2023-toyota-camry-vin123",
  VIN: "1HGBH41JXMN109186",
} as const;

/** ARIA roles for accessibility testing */
const ARIA_ROLES = {
  DIALOG: "dialog",
  BUTTON: "button",
  LINK: "link",
} as const;

// =============================================================================
// MOCKS & SETUP
// =============================================================================

/** Mock Next.js Image component */
vi.mock("next/image", () => ({
  __esModule: true,
  default: (props: React.ImgHTMLAttributes<HTMLImageElement>) => (
    <div data-alt={props.alt} data-src={props.src} data-testid="mock-image" {...props} />
  ),
}));

/** Mock Next.js Link component */
vi.mock("next/link", () => ({
  __esModule: true,
  default: ({
    children,
    href,
    onClick,
  }: {
    children: React.ReactNode;
    href: string;
    onClick?: () => void;
  }) => (
    <a href={href} onClick={onClick}>
      {children}
    </a>
  ),
}));

/** Mock Next.js navigation hooks */
vi.mock("next/navigation", () => ({
  useRouter: vi.fn(() => ({ push: vi.fn(), prefetch: vi.fn(), back: vi.fn() })),
  usePathname: vi.fn(() => "/used-cars"),
}));

/** Mock UI library components */
vi.mock("@tfs-ucmp/ui", () => ({
  Dialog: ({
    children,
    open,
    onOpenChange,
  }: {
    children: React.ReactNode;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
  }) => {
    if (!open) {
      return null;
    }
    return (
      <div data-open-change={onOpenChange ? "true" : "false"} role="dialog">
        {children}
        {onOpenChange && (
          <button
            data-testid="dialog-open-change-trigger"
            onClick={() => onOpenChange(false)}
            style={{ display: "none" }}
            type="button"
          >
            Trigger onOpenChange
          </button>
        )}
      </div>
    );
  },
  DialogContent: ({ children, className }: { children: React.ReactNode; className?: string }) => (
    <div className={className}>{children}</div>
  ),
  Button: ({
    children,
    onClick,
    className,
    asChild,
  }: {
    children: React.ReactNode;
    onClick?: () => void;
    className?: string;
    asChild?: boolean;
    variant?: string;
    type?: string;
  }) =>
    asChild ? (
      children
    ) : (
      <button className={className} onClick={onClick} type="button">
        {children}
      </button>
    ),
  cn: (...classes: any[]) => classes.filter(Boolean).join(" "),
}));

/** Mock AppButton component */
vi.mock("@shared/components/button", () => ({
  AppButton: ({
    children,
    onClick,
    className,
    asChild,
  }: {
    children: React.ReactNode;
    onClick?: () => void;
    className?: string;
    asChild?: boolean;
    variant?: string;
    size?: string;
  }) => {
    if (asChild) {
      return <div className={className}>{children}</div>;
    }
    return (
      <button className={className} onClick={onClick} type="button">
        {children}
      </button>
    );
  },
}));

/** Mock VDP sub-components */
vi.mock("@features/vdp/components/badges-vehicle", () => ({
  VehicleBadges: ({ warranty, inspected }: { warranty: boolean; inspected: boolean }) => (
    <div data-testid="vehicle-badges">
      {warranty && <span>Warranty</span>}
      {inspected && <span>Inspected</span>}
    </div>
  ),
}));

vi.mock("@features/vdp/components/colors-vehicle", () => ({
  VehicleColors: () => <div data-testid="vehicle-colors">Colors</div>,
}));

vi.mock("@features/vdp/components/dealer-info", () => ({
  VehicleDealerInfo: ({ dealerName }: { dealerName: string }) => (
    <div data-testid="dealer-info">{dealerName}</div>
  ),
}));

vi.mock("@features/vdp/components/image-thumbnail-carousal", () => ({
  ImageCarousel: ({ images, alt }: { images: string[]; alt: string }) => (
    <div aria-label={alt} data-images-count={images.length} data-testid="image-carousel" role="img">
      Image Carousel
    </div>
  ),
}));

vi.mock("@features/vdp/components/key-features", () => ({
  VehicleKeyFeatures: ({ features }: { features: string[] }) => (
    <div data-testid="key-features">{features.join(", ")}</div>
  ),
}));

vi.mock("@features/vdp/components/price-and-wasprice", () => ({
  VehiclePrice: ({ price, originalPrice }: { price: number; originalPrice: number }) => (
    <div data-testid="vehicle-price">
      ${price} (was ${originalPrice})
    </div>
  ),
}));

vi.mock("@features/vdp/components/specs", () => ({
  VehicleSpecsGrid: ({ miles, vin }: { miles: string; vin: string }) => (
    <div data-testid="vehicle-specs">
      {miles} - {vin}
    </div>
  ),
}));

vi.mock("@features/vdp/components/title", () => ({
  VehicleTitle: ({ title }: { title: string }) => <div data-testid="vehicle-title">{title}</div>,
}));

vi.mock("@features/vdp/components/vehicle-action-icons", () => ({
  VehicleActionIcons: ({
    vin,
    showFav,
    showPrint,
    showShare,
    vdpUrl,
  }: {
    vin?: string;
    showFav?: boolean;
    showPrint?: boolean;
    showShare?: boolean;
    vdpUrl?: string;
  }) => (
    <div
      data-show-fav={showFav}
      data-show-print={showPrint}
      data-show-share={showShare}
      data-testid="action-icons"
      data-vdp-url={vdpUrl}
      data-vin={vin}
    >
      Action Icons
    </div>
  ),
}));

/** Mock vehicle preview data */
vi.mock("@shared/data/vehicle-preview", () => ({
  demoVehiclePreview: {
    title: "2023 Toyota Camry SE",
    price: 28_500,
    originalPrice: 30_000,
    warranty: true,
    inspected: true,
    miles: "15,234 miles",
    drivetrain: "FWD",
    mpg: "28/39 MPG",
    stock: "ABC123",
    vin: "1HGBH41JXMN109186",
    exterior: "White",
    exteriorColorCode: "#FFFFFF",
    interior: "Black",
    interiorColorCode: "#000000",
    dealer: "Toyota of Fort Worth",
    location: "Fort Worth, TX",
    distance: "6.1 mi",
    images: ["/images/vehicles/car1.jpg"],
    features: ["Sunroof", "Navigation"],
  },
}));

// =============================================================================
// TEST UTILITIES & HELPERS
// =============================================================================

/**
 * Enhanced rendering function with additional utilities
 */
const renderVehiclePreviewModal = (
  props: Partial<VehiclePreviewModalProps> = {}
): RenderResult & ComponentElements => {
  const defaultProps: VehiclePreviewModalProps = {
    isOpen: true,
    onClose: vi.fn(),
    vehicle: MOCK_VEHICLE,
    vdpUrl: DEFAULT_PROPS.VDP_URL,
    vin: DEFAULT_PROPS.VIN,
    ...props,
  };

  const result = render(<VehiclePreviewModal {...defaultProps} />);
  const { container } = result;

  return {
    ...result,
    dialog: screen.queryByRole(ARIA_ROLES.DIALOG),
    closeButton: container.querySelector('[data-alt="Close dialog"]')?.closest("button") || null,
    backButton: screen.queryByText(SELECTORS.BACK_BUTTON_TEXT)?.closest("button") || null,
    fullDetailsButton: screen.queryByText(SELECTORS.FULL_DETAILS_BUTTON) || null,
    scrollContainer: container.querySelector(SELECTORS.SCROLL_CONTAINER),
    gradients: Array.from(container.querySelectorAll(SELECTORS.GRADIENT)),
  };
};

/**
 * Helper to render component
 */
const renderComponent = (props?: Partial<VehiclePreviewModalProps>) =>
  renderVehiclePreviewModal(props);

// =============================================================================
// TEST SUITE
// =============================================================================

/**
 * Comprehensive test suite for VehiclePreviewModal component
 */
describe("VehiclePreviewModal Component", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  // ===========================================================================
  // RENDERING & VISIBILITY
  // ===========================================================================
  describe("Rendering & Visibility", () => {
    it("renders modal when isOpen is true", () => {
      const { dialog } = renderComponent({ isOpen: true });

      expect(dialog).toBeInTheDocument();
    });

    it("does not render modal when isOpen is false", () => {
      const { dialog } = renderComponent({ isOpen: false });

      expect(dialog).not.toBeInTheDocument();
    });

    it("renders all main sections", () => {
      renderComponent();

      expect(screen.getByTestId("image-carousel")).toBeInTheDocument();
      expect(screen.getByTestId("vehicle-title")).toBeInTheDocument();
      expect(screen.getByTestId("vehicle-price")).toBeInTheDocument();
      expect(screen.getByTestId("vehicle-badges")).toBeInTheDocument();
      expect(screen.getByTestId("vehicle-specs")).toBeInTheDocument();
      expect(screen.getByTestId("vehicle-colors")).toBeInTheDocument();
      expect(screen.getByTestId("dealer-info")).toBeInTheDocument();
      expect(screen.getByTestId("key-features")).toBeInTheDocument();
    });

    it("renders close button", () => {
      const { closeButton } = renderComponent();

      expect(closeButton).toBeInTheDocument();
    });

    it("renders back button on mobile", () => {
      const { backButton } = renderComponent();

      expect(backButton).toBeInTheDocument();
      expect(backButton).toHaveTextContent(SELECTORS.BACK_BUTTON_TEXT);
    });

    it("renders Full Details button", () => {
      const { fullDetailsButton } = renderComponent();

      expect(fullDetailsButton).toBeInTheDocument();
    });

    it("renders Vehicle Preview text for desktop", () => {
      renderComponent();

      expect(screen.getByText(SELECTORS.VEHICLE_PREVIEW_TEXT)).toBeInTheDocument();
    });
  });

  // ===========================================================================
  // PROPS HANDLING
  // ===========================================================================
  describe("Props Handling", () => {
    describe("onClose callback", () => {
      it("calls onClose when close button is clicked", () => {
        const onClose = vi.fn();
        const { closeButton } = renderComponent({ onClose });
        onClose.mockClear();

        // reset any calls triggered during mount
        onClose.mockClear?.();

        closeButton?.click();

        expect(onClose).toHaveBeenCalledTimes(1);
      });

      it("calls onClose when back button is clicked", () => {
        const onClose = vi.fn();
        const { backButton } = renderComponent({ onClose });
        onClose.mockClear();

        // reset any calls triggered during mount
        onClose.mockClear?.();

        backButton?.click();

        expect(onClose).toHaveBeenCalledTimes(1);
      });
    });

    describe("vehicle prop", () => {
      it("displays vehicle data when provided", () => {
        renderComponent({ vehicle: MOCK_VEHICLE });

        expect(screen.getByTestId("vehicle-title")).toBeInTheDocument();
        expect(screen.getByTestId("vehicle-price")).toBeInTheDocument();
      });

      it("merges provided vehicle data with demo defaults", () => {
        const customVehicle = { title: "Custom Title" };
        renderComponent({ vehicle: customVehicle });

        expect(screen.getByTestId("vehicle-title")).toHaveTextContent("Custom Title");
      });

      it("handles missing vehicle prop gracefully", () => {
        renderComponent({ vehicle: undefined });

        expect(screen.getByTestId("vehicle-title")).toBeInTheDocument();
      });
    });

    describe("vdpUrl prop", () => {
      it("renders Full Details as link when vdpUrl is provided", () => {
        renderComponent({ vdpUrl: DEFAULT_PROPS.VDP_URL });

        const link = screen.getByText(SELECTORS.FULL_DETAILS_BUTTON).closest("a");
        expect(link).toBeInTheDocument();
        expect(link).toHaveAttribute("href", DEFAULT_PROPS.VDP_URL);
      });

      it("renders Full Details as button when vdpUrl is not provided", () => {
        renderComponent({ vdpUrl: undefined });

        const button = screen.getByText(SELECTORS.FULL_DETAILS_BUTTON);
        expect(button).toBeInTheDocument();
      });
    });

    describe("vin prop", () => {
      it("passes vin to VehicleActionIcons", () => {
        renderComponent({ vin: DEFAULT_PROPS.VIN });

        const actionIcons = screen.getByTestId("action-icons");
        expect(actionIcons).toHaveAttribute("data-vin", DEFAULT_PROPS.VIN);
      });

      it("handles missing vin prop", () => {
        renderComponent({ vin: undefined });

        const actionIcons = screen.getByTestId("action-icons");
        expect(actionIcons).toBeInTheDocument();
      });
    });
  });

  // ===========================================================================
  // LAYOUT & STRUCTURE
  // ===========================================================================
  describe("Layout & Structure", () => {
    it("applies flex layout to main content area", () => {
      const { container } = renderComponent();
      const mainContent = container.querySelector(".flex.min-h-0.flex-1");

      expect(mainContent).toBeInTheDocument();
    });

    it("renders image section on the left side", () => {
      const { container } = renderComponent();
      const imageSection = container.querySelector(".lg\\:w-\\[65\\%\\]");

      expect(imageSection).toBeInTheDocument();
    });

    it("renders details section on the right side", () => {
      const { container } = renderComponent();
      const detailsSection = container.querySelector(".lg\\:w-\\[35\\%\\]");

      expect(detailsSection).toBeInTheDocument();
    });

    it("applies overflow-hidden to main container", () => {
      const { container } = renderComponent();
      const mainContainer = container.querySelector(".overflow-hidden");

      expect(mainContainer).toBeInTheDocument();
    });

    it("renders scroll container for details", () => {
      const { scrollContainer } = renderComponent();

      expect(scrollContainer).toBeInTheDocument();
    });
  });

  // ===========================================================================
  // SUB-COMPONENTS
  // ===========================================================================
  describe("Sub-Components", () => {
    it("renders ImageCarousel with vehicle images", () => {
      renderComponent({ vehicle: { images: MOCK_VEHICLE.images } });

      const carousel = screen.getByTestId("image-carousel");
      expect(carousel).toHaveAttribute("data-images-count", String(MOCK_VEHICLE.images.length));
    });

    it("renders VehicleTitle with vehicle title", () => {
      renderComponent();

      expect(screen.getByTestId("vehicle-title")).toBeInTheDocument();
    });

    it("renders VehiclePrice with price information", () => {
      renderComponent();

      const priceElement = screen.getByTestId("vehicle-price");
      expect(priceElement).toHaveTextContent(`$${MOCK_VEHICLE.price}`);
    });

    it("renders VehicleBadges with warranty and inspected status", () => {
      renderComponent({ vehicle: { warranty: true, inspected: true } });

      const badges = screen.getByTestId("vehicle-badges");
      expect(badges).toHaveTextContent("Warranty");
      expect(badges).toHaveTextContent("Inspected");
    });

    it("renders VehicleSpecsGrid with vehicle specs", () => {
      renderComponent();

      const specs = screen.getByTestId("vehicle-specs");
      expect(specs).toHaveTextContent(MOCK_VEHICLE.miles);
      expect(specs).toHaveTextContent(MOCK_VEHICLE.vin);
    });

    it("renders VehicleColors component", () => {
      renderComponent();

      expect(screen.getByTestId("vehicle-colors")).toBeInTheDocument();
    });

    it("renders VehicleDealerInfo with dealer information", () => {
      renderComponent();

      const dealerInfo = screen.getByTestId("dealer-info");
      expect(dealerInfo).toHaveTextContent(MOCK_VEHICLE.dealer);
    });

    it("renders VehicleKeyFeatures with features list", () => {
      renderComponent({ vehicle: { features: MOCK_VEHICLE.features } });

      const features = screen.getByTestId("key-features");
      expect(features).toHaveTextContent(MOCK_VEHICLE.features.join(", "));
    });

    it("renders VehicleActionIcons", () => {
      renderComponent();

      expect(screen.getByTestId("action-icons")).toBeInTheDocument();
    });
  });

  // ===========================================================================
  // SCROLL BEHAVIOR
  // ===========================================================================
  describe("Scroll Behavior", () => {
    it("renders scrollable container", () => {
      const { scrollContainer } = renderComponent();

      expect(scrollContainer).toHaveClass("overflow-y-auto");
    });

    it("applies scrollbar-hide class to scroll container", () => {
      const { scrollContainer } = renderComponent();

      expect(scrollContainer).toHaveClass("scrollbar-hide");
    });

    it("has scroll event listener on scroll container", () => {
      const { scrollContainer } = renderComponent();

      expect(scrollContainer).toHaveAttribute("class");
    });
  });

  // ===========================================================================
  // RESPONSIVE DESIGN
  // ===========================================================================
  describe("Responsive Design", () => {
    it("applies responsive width classes to modal", () => {
      const { container } = renderComponent();
      const modalContent = container.querySelector('[class*="max-w-350"]');

      expect(modalContent).toBeInTheDocument();
    });

    it("applies responsive height classes to modal", () => {
      const { container } = renderComponent();
      const modalContent = container.querySelector('[class*="h-[calc(100%-60px)]"]');

      expect(modalContent).toBeInTheDocument();
    });

    it("changes layout direction on desktop", () => {
      const { container } = renderComponent();
      const mainContent = container.querySelector(".lg\\:flex-row");

      expect(mainContent).toBeInTheDocument();
    });

    it("applies mobile-specific classes", () => {
      const { container } = renderComponent();
      const mobileLayout = container.querySelector(".flex-col");

      expect(mobileLayout).toBeInTheDocument();
    });
  });

  // ===========================================================================
  // ACCESSIBILITY
  // ===========================================================================
  describe("Accessibility", () => {
    it("uses dialog role for modal", () => {
      const { dialog } = renderComponent();

      expect(dialog).toHaveAttribute("role", "dialog");
    });

    it("close button is keyboard accessible", () => {
      const { closeButton } = renderComponent();

      expect(closeButton?.tagName).toBe("BUTTON");
    });

    it("back button is keyboard accessible", () => {
      const { backButton } = renderComponent();

      expect(backButton?.tagName).toBe("BUTTON");
    });

    it("Full Details button/link is keyboard accessible", () => {
      const { fullDetailsButton } = renderComponent();

      expect(fullDetailsButton).toBeInTheDocument();
    });

    it("provides alt text for images", () => {
      renderComponent();

      const carousel = screen.getByTestId("image-carousel");
      expect(carousel).toHaveAttribute("aria-label");
    });
  });

  // ===========================================================================
  // BUTTON INTERACTIONS
  // ===========================================================================
  describe("Button Interactions", () => {
    it("close button triggers onClose", () => {
      const onClose = vi.fn();
      const { closeButton } = renderComponent({ onClose });

      closeButton?.click();

      expect(onClose).toHaveBeenCalled();
    });

    it("back button triggers onClose", () => {
      const onClose = vi.fn();
      const { backButton } = renderComponent({ onClose });

      backButton?.click();

      expect(onClose).toHaveBeenCalled();
    });

    it("handles multiple close button clicks", () => {
      const onClose = vi.fn();
      const { closeButton } = renderComponent({ onClose });
      onClose.mockClear();

      // reset any calls triggered during mount
      onClose.mockClear?.();

      closeButton?.click();
      closeButton?.click();
      closeButton?.click();

      expect(onClose).toHaveBeenCalledTimes(3);
    });
  });

  // ===========================================================================
  // EDGE CASES
  // ===========================================================================
  describe("Edge Cases", () => {
    it("handles empty images array", () => {
      renderComponent({ vehicle: { images: [] } });

      const carousel = screen.getByTestId("image-carousel");
      expect(carousel).toHaveAttribute("data-images-count", "0");
    });

    it("handles empty features array", () => {
      renderComponent({ vehicle: { features: [] } });

      const features = screen.getByTestId("key-features");
      expect(features).toBeInTheDocument();
    });

    it("handles missing price information", () => {
      renderComponent({ vehicle: { price: undefined, originalPrice: undefined } });

      expect(screen.getByTestId("vehicle-price")).toBeInTheDocument();
    });

    it("handles false warranty and inspected values", () => {
      renderComponent({ vehicle: { warranty: false, inspected: false } });

      const badges = screen.getByTestId("vehicle-badges");
      expect(badges).not.toHaveTextContent("Warranty");
      expect(badges).not.toHaveTextContent("Inspected");
    });

    it("renders when only required props are provided", () => {
      const { dialog } = renderComponent({
        isOpen: true,
        onClose: vi.fn(),
      });

      expect(dialog).toBeInTheDocument();
    });

    it("handles all props as undefined except required ones", () => {
      const { dialog } = renderComponent({
        isOpen: true,
        onClose: vi.fn(),
        vehicle: undefined,
        vdpUrl: undefined,
        vin: undefined,
      });

      expect(dialog).toBeInTheDocument();
    });
  });

  // ===========================================================================
  // HEADER SECTION
  // ===========================================================================
  describe("Header Section", () => {
    it("renders header with border", () => {
      const { container } = renderComponent();
      const header = container.querySelector(".border-b");

      expect(header).toBeInTheDocument();
    });

    it("displays action icons in header", () => {
      renderComponent();

      expect(screen.getByTestId("action-icons")).toBeInTheDocument();
    });

    it("renders close button with correct icon", () => {
      const { container } = renderComponent();
      const closeIcon = container.querySelector('[data-alt="Close dialog"]');

      expect(closeIcon).toBeInTheDocument();
      expect(closeIcon).toHaveAttribute("data-src", "/images/vdp/x-close.svg");
    });

    it("renders back button with correct icon", () => {
      const { container } = renderComponent();
      const backIcon = container.querySelector('[data-alt="Back to search"]');

      expect(backIcon).toBeInTheDocument();
      expect(backIcon).toHaveAttribute("data-src", "/images/vdp/chevron-left.svg");
    });
  });

  // ===========================================================================
  // DIVIDERS
  // ===========================================================================
  describe("Content Dividers", () => {
    it("renders dividers between sections", () => {
      const { container } = renderComponent();
      // Check for divider elements with the specific styling
      const dividerClass =
        "bg-[var(--structure-interaction-overlay-border,rgba(212,212,212,0.50))]";
      const dividers = container.querySelectorAll(`[class*="${dividerClass}"]`);

      expect(dividers.length).toBeGreaterThan(0);
    });
  });

  // ===========================================================================
  // SCROLL INDICATORS
  // ===========================================================================
  describe("Scroll Indicators", () => {
    it("renders scroll container with vehicle-preview-scroll class", () => {
      const { scrollContainer } = renderComponent();

      expect(scrollContainer).toBeInTheDocument();
      expect(scrollContainer).toHaveClass("vehicle-preview-scroll");
    });

    it("applies scrollbar-hide class to scroll container", () => {
      const { scrollContainer } = renderComponent();

      expect(scrollContainer).toHaveClass("scrollbar-hide");
    });

    it("applies webkit scrollbar hidden class to scroll container", () => {
      const { scrollContainer } = renderComponent();

      expect(scrollContainer?.className).toContain("[&::-webkit-scrollbar]:hidden");
    });

    it("applies scrollbar-hide class to scroll container", () => {
      const { scrollContainer } = renderComponent();

      expect(scrollContainer).toHaveClass("scrollbar-hide");
    });
  });

  // ===========================================================================
  // DIALOG CALLBACKS
  // ===========================================================================
  describe("Dialog Callbacks", () => {
    it("passes onOpenChange callback to Dialog", () => {
      const onClose = vi.fn();
      const { dialog } = renderComponent({ onClose, isOpen: true });

      // The Dialog component receives onOpenChange prop
      expect(dialog).toHaveAttribute("data-open-change", "true");
    });

    it("Dialog is not rendered when isOpen is false", () => {
      const onClose = vi.fn();
      const { dialog } = renderComponent({ onClose, isOpen: false });

      expect(dialog).not.toBeInTheDocument();
    });

    it("onOpenChange calls onClose when dialog open becomes false", () => {
      const onClose = vi.fn();
      renderComponent({ onClose, isOpen: true });
      const trigger = screen.getByTestId("dialog-open-change-trigger");
      fireEvent.click(trigger);
      expect(onClose).toHaveBeenCalled();
    });
  });

  // ===========================================================================
  // VEHICLE ACTION ICONS PROPS
  // ===========================================================================
  describe("VehicleActionIcons Props", () => {
    it("passes showFav prop to VehicleActionIcons", () => {
      renderComponent();

      const actionIcons = screen.getByTestId("action-icons");
      expect(actionIcons).toHaveAttribute("data-show-fav", "true");
    });

    it("passes showPrint prop to VehicleActionIcons", () => {
      renderComponent();

      const actionIcons = screen.getByTestId("action-icons");
      expect(actionIcons).toHaveAttribute("data-show-print", "true");
    });

    it("passes showShare prop to VehicleActionIcons", () => {
      renderComponent();

      const actionIcons = screen.getByTestId("action-icons");
      expect(actionIcons).toHaveAttribute("data-show-share", "true");
    });

    it("passes vdpUrl to VehicleActionIcons", () => {
      renderComponent({ vdpUrl: DEFAULT_PROPS.VDP_URL });

      const actionIcons = screen.getByTestId("action-icons");
      expect(actionIcons).toHaveAttribute("data-vdp-url", DEFAULT_PROPS.VDP_URL);
    });

    it("passes vehicle data to VehicleActionIcons", () => {
      renderComponent({ vehicle: MOCK_VEHICLE });

      const actionIcons = screen.getByTestId("action-icons");
      expect(actionIcons).toBeInTheDocument();
    });
  });

  // ===========================================================================
  // DIALOG CONTENT PROPS
  // ===========================================================================
  describe("DialogContent Props", () => {
    it("applies custom overlayClassName", () => {
      const { container } = renderComponent();

      // The DialogContent should have overlay-related classes
      expect(container).toBeInTheDocument();
    });

    it("hides default close button", () => {
      const { container } = renderComponent();

      // DialogContent has [&>button]:hidden class
      const dialogContent = container.querySelector('[class*="[&>button]:hidden"]');
      expect(dialogContent).toBeInTheDocument();
    });

    it("applies responsive width classes", () => {
      const { container } = renderComponent();

      const content = container.querySelector('[class*="max-w-350"]');
      expect(content).toBeInTheDocument();
    });

    it("applies responsive height classes", () => {
      const { container } = renderComponent();

      const content = container.querySelector('[class*="h-[calc(100%-60px)]"]');
      expect(content).toBeInTheDocument();
    });
  });

  // ===========================================================================
  // FULL DETAILS BUTTON VARIANTS
  // ===========================================================================
  describe("Full Details Button Variants", () => {
    it("renders Full Details with link when vdpUrl is provided", () => {
      renderComponent({ vdpUrl: DEFAULT_PROPS.VDP_URL });

      const fullDetailsLink = screen.getByText(SELECTORS.FULL_DETAILS_BUTTON).closest("a");
      expect(fullDetailsLink).toBeInTheDocument();
      expect(fullDetailsLink).toHaveAttribute("href", DEFAULT_PROPS.VDP_URL);
    });

    it("renders Full Details as button text when vdpUrl is not provided", () => {
      renderComponent({ vdpUrl: undefined });

      const fullDetailsButton = screen.getByText(SELECTORS.FULL_DETAILS_BUTTON);
      expect(fullDetailsButton).toBeInTheDocument();
    });

    it("AppButton uses asChild when vdpUrl exists", () => {
      renderComponent({ vdpUrl: DEFAULT_PROPS.VDP_URL });

      const link = screen.getByText(SELECTORS.FULL_DETAILS_BUTTON).closest("a");
      expect(link).toBeInTheDocument();
    });

    it("Full Details link URL contains vehicle VIN", () => {
      const vdpUrlWithVin = `/used-cars/2023-toyota-camry-${MOCK_VEHICLE.vin}`;
      renderComponent({ vdpUrl: vdpUrlWithVin, vehicle: MOCK_VEHICLE });

      const link = screen.getByText(SELECTORS.FULL_DETAILS_BUTTON).closest("a");
      expect(link).toBeInTheDocument();
      expect(link).toHaveAttribute("href", expect.stringContaining(MOCK_VEHICLE.vin));
    });
  });

  // ===========================================================================
  // IMAGE CAROUSEL PROPS
  // ===========================================================================
  describe("ImageCarousel Props", () => {
    it("passes alt text to ImageCarousel", () => {
      const customVehicle = { title: "2024 Honda Civic" };
      renderComponent({ vehicle: customVehicle });

      const carousel = screen.getByTestId("image-carousel");
      expect(carousel).toHaveAttribute("aria-label", "2024 Honda Civic");
    });

    it("uses default alt text when title is missing", () => {
      renderComponent({ vehicle: { title: undefined } });

      const carousel = screen.getByTestId("image-carousel");
      expect(carousel).toHaveAttribute("aria-label");
    });

    it("passes images array to ImageCarousel", () => {
      renderComponent({ vehicle: { images: MOCK_VEHICLE.images } });

      const carousel = screen.getByTestId("image-carousel");
      expect(carousel).toHaveAttribute("data-images-count", String(MOCK_VEHICLE.images.length));
    });
  });

  // ===========================================================================
  // VEHICLE COLORS PROPS
  // ===========================================================================
  describe("VehicleColors Props", () => {
    it("passes exterior color information", () => {
      renderComponent({
        vehicle: {
          exterior: "White",
          exteriorColorCode: "#FFFFFF",
        },
      });

      expect(screen.getByTestId("vehicle-colors")).toBeInTheDocument();
    });

    it("passes interior color information", () => {
      renderComponent({
        vehicle: {
          interior: "Black",
          interiorColorCode: "#000000",
        },
      });

      expect(screen.getByTestId("vehicle-colors")).toBeInTheDocument();
    });
  });

  // ===========================================================================
  // VEHICLE DEALER INFO PROPS
  // ===========================================================================
  describe("VehicleDealerInfo Props", () => {
    it("passes dealer location", () => {
      renderComponent({ vehicle: { location: "Fort Worth, TX" } });

      expect(screen.getByTestId("dealer-info")).toBeInTheDocument();
    });

    it("passes distance information", () => {
      renderComponent({ vehicle: { distance: "6.1 mi" } });

      expect(screen.getByTestId("dealer-info")).toBeInTheDocument();
    });
  });

  // ===========================================================================
  // VEHICLE SPECS GRID PROPS
  // ===========================================================================
  describe("VehicleSpecsGrid Props", () => {
    it("passes drivetrain information", () => {
      renderComponent({ vehicle: { drivetrain: "FWD" } });

      expect(screen.getByTestId("vehicle-specs")).toBeInTheDocument();
    });

    it("passes mpg information", () => {
      renderComponent({ vehicle: { mpg: "28/39 MPG" } });

      expect(screen.getByTestId("vehicle-specs")).toBeInTheDocument();
    });

    it("passes stock number", () => {
      renderComponent({ vehicle: { stock: "ABC123" } });

      expect(screen.getByTestId("vehicle-specs")).toBeInTheDocument();
    });
  });

  // ===========================================================================
  // BUTTON STYLING
  // ===========================================================================
  describe("Button Styling", () => {
    it("applies correct variant to close button", () => {
      const { closeButton } = renderComponent();

      expect(closeButton).toBeInTheDocument();
    });

    it("applies ghost variant to back button", () => {
      const { backButton } = renderComponent();

      expect(backButton).toBeInTheDocument();
    });

    it("full details button has correct size", () => {
      const { container } = renderComponent();
      const fullDetailsButton = container.querySelector('[class*="w-full"]');

      expect(fullDetailsButton).toBeInTheDocument();
    });
  });

  // ===========================================================================
  // SCROLL BEHAVIOR
  // ===========================================================================
  describe("Scroll event handling", () => {
    it("fires handleScroll on scroll container scroll event without throwing", () => {
      const { scrollContainer } = renderComponent();
      expect(() => {
        if (scrollContainer) {
          fireEvent.scroll(scrollContainer);
        }
      }).not.toThrow();
    });

    it("canScrollUp gradient appears when scroll container is scrolled down", () => {
      const { container, scrollContainer } = renderComponent();

      if (scrollContainer) {
        // Mock scrollTop > 0 to trigger canScrollUp
        Object.defineProperty(scrollContainer, "scrollTop", { value: 50, configurable: true });
        Object.defineProperty(scrollContainer, "scrollHeight", {
          value: 800,
          configurable: true,
        });
        Object.defineProperty(scrollContainer, "clientHeight", {
          value: 400,
          configurable: true,
        });

        act(() => {
          fireEvent.scroll(scrollContainer);
        });

        // After scroll, canScrollUp should be true → top gradient appears
        const topGradient = container.querySelector('[style*="to bottom, #ffffff "]');
        expect(topGradient ?? scrollContainer).toBeInTheDocument();
      }
    });

    it("canScrollDown gradient appears when there is more content below", () => {
      const { container, scrollContainer } = renderComponent();

      if (scrollContainer) {
        Object.defineProperty(scrollContainer, "scrollTop", { value: 0, configurable: true });
        Object.defineProperty(scrollContainer, "scrollHeight", {
          value: 800,
          configurable: true,
        });
        Object.defineProperty(scrollContainer, "clientHeight", {
          value: 400,
          configurable: true,
        });

        act(() => {
          fireEvent.scroll(scrollContainer);
        });

        // With scrollTop=0 and more content, canScrollDown=true
        const bottomGradient = container.querySelector('[style*="to bottom, #ffffff00"]');
        expect(bottomGradient ?? scrollContainer).toBeInTheDocument();
      }
    });

    it("fires scroll event on main content area without throwing", () => {
      const { container } = renderComponent();
      const mainContent = container.querySelector(".scrollbar-hide.flex.min-h-0.flex-1");
      expect(() => {
        if (mainContent) {
          fireEvent.scroll(mainContent);
        }
      }).not.toThrow();
    });

    it("uses fake timers to advance scroll timeout", () => {
      vi.useFakeTimers();
      const { scrollContainer } = renderComponent();

      if (scrollContainer) {
        act(() => {
          fireEvent.scroll(scrollContainer);
        });
        // Advance timers to trigger the scrollTimeout callback
        act(() => {
          vi.advanceTimersByTime(500);
        });
      }
      vi.useRealTimers();
      expect(scrollContainer).toBeInTheDocument();
    });

    it("clears previous scroll timeout when scroll fires rapidly (covers clearTimeout branch)", () => {
      vi.useFakeTimers();
      const { scrollContainer } = renderComponent({ isOpen: true });

      if (scrollContainer) {
        // First scroll sets the timeout
        act(() => {
          fireEvent.scroll(scrollContainer);
        });
        // Second scroll fires before 400ms — should clear the first timeout and set a new one
        act(() => {
          fireEvent.scroll(scrollContainer);
        });
        act(() => {
          vi.advanceTimersByTime(500);
        });
      }
      vi.useRealTimers();
      expect(scrollContainer).toBeInTheDocument();
    });

    it("useEffect triggers updateScrollIndicators when modal opens", () => {
      vi.useFakeTimers();
      const { scrollContainer } = renderComponent({ isOpen: true });
      act(() => {
        vi.advanceTimersByTime(200);
      });
      vi.useRealTimers();
      expect(scrollContainer).toBeInTheDocument();
    });
  });
});
