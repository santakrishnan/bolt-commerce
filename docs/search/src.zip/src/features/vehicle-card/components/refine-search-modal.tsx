"use client";

import type { ActiveFilter } from "@features/search";
import { AppButton } from "@shared/components/button";
import { CustomChips } from "@shared/components/custom-chips";
import { useSingletonModal } from "@shared/hooks/use-single-modal";
import { Button, Heading } from "@tfs-ucmp/ui";
import Image from "next/image";
import { useCallback, useEffect, useMemo, useState } from "react";

import { FILTERS_PER_SECTION, type FilterOption } from "./refine-search-modal.helpers";

interface RefineSearchModalProps {
  activeFilters?: ActiveFilter[];
  isOpen: boolean;
  onApplyFilters?: (filters: { id: string; label: string }[]) => void;
  onClose: () => void;
  onSearch: () => void;
  /** Per-vehicle features from API response — used to build refine options. */
  vehicleFeatures: string[];
}

/**
 * Build filter options from per-vehicle features. Splits the flat feature
 * list into "Your Filters" (first half) and "Suggested" (second half).
 */
function buildFromVehicleFeatures(features: string[]): {
  yourFilters: FilterOption[];
  suggestedFilters: FilterOption[];
  allFilters: FilterOption[];
} {
  const mid = Math.ceil(features.length / 2);
  const yourFilters: FilterOption[] = features
    .slice(0, Math.min(mid, FILTERS_PER_SECTION))
    .map((label) => ({ id: label.toLowerCase().replace(/\s+/g, "-"), label }));
  const suggestedFilters: FilterOption[] = features
    .slice(mid, mid + FILTERS_PER_SECTION)
    .map((label) => ({ id: label.toLowerCase().replace(/\s+/g, "-"), label }));
  return {
    yourFilters,
    suggestedFilters,
    allFilters: [...yourFilters, ...suggestedFilters],
  };
}

export function RefineSearchModal({
  activeFilters: initialActiveFilters = [],
  isOpen,
  onClose,
  onApplyFilters,
  onSearch,
  vehicleFeatures,
}: RefineSearchModalProps) {
  // Memoize so allFilters is a stable reference — prevents infinite loop
  // in the useEffect → setActiveFilters → re-render cycle.
  const { yourFilters, suggestedFilters, allFilters } = useMemo(
    () => buildFromVehicleFeatures(vehicleFeatures),
    [vehicleFeatures]
  );

  const deriveActiveRefineFilters = useCallback(
    (sourceFilters: ActiveFilter[]) => {
      const matchedFilters: ActiveFilter[] = sourceFilters.filter(
        (f) => f.type === "refineSearch" || f.isRefineSearch === true
      );

      for (const initialFilter of sourceFilters) {
        const matchingFilter = allFilters.find(
          (f) => f.label.toLowerCase() === initialFilter.label.toLowerCase()
        );

        if (matchingFilter && !matchedFilters.some((mf) => mf.value === matchingFilter.id)) {
          matchedFilters.push({
            label: matchingFilter.label,
            type: "feature",
            value: matchingFilter.id,
            isRefineSearch: true,
          });
        }
      }

      return matchedFilters;
    },
    [allFilters]
  );

  const [activeFilters, setActiveFilters] = useState<ActiveFilter[]>(() =>
    deriveActiveRefineFilters(initialActiveFilters)
  );
  const [isCloseHovered, setIsCloseHovered] = useState(false);
  useSingletonModal("vehicle-modal-open", isOpen, onClose);

  useEffect(() => {
    if (!isOpen) {
      return;
    }

    setActiveFilters(deriveActiveRefineFilters(initialActiveFilters));
  }, [initialActiveFilters, isOpen, deriveActiveRefineFilters]);

  if (!isOpen) {
    return null;
  }

  const toggleFilter = (filterId: string) => {
    setActiveFilters((prev) => {
      const existingIndex = prev.findIndex((f) => f.value === filterId);
      if (existingIndex !== -1) {
        return prev.filter((_, i) => i !== existingIndex);
      }
      const filterOption = allFilters.find((f) => f.id === filterId);
      if (filterOption) {
        return [
          ...prev,
          {
            label: filterOption.label,
            type: "feature",
            value: filterId,
            isRefineSearch: true,
          },
        ];
      }
      return prev;
    });
  };

  const handleApplyFilters = () => {
    const selected = activeFilters
      .filter((f) => f.isRefineSearch === true || f.type === "feature" || f.type === "refineSearch")
      .map((f) => ({ id: f.value, label: f.label }))
      .filter((f, idx, arr) => arr.findIndex((a) => a.id === f.id) === idx);
    onApplyFilters?.(selected);

    try {
      onSearch();
    } catch {
      // noop if parent didn't provide a handler
    }
    onClose();
  };

  const handleReset = () => {
    setActiveFilters([]);
    // Inform parent that refine filters are cleared and trigger a search
    onApplyFilters?.([]);
    try {
      onSearch();
    } catch {
      // noop
    }
  };

  return (
    // biome-ignore lint/a11y/noNoninteractiveElementInteractions: Modal backdrop needs click handler to close modal
    <div
      aria-label="Close modal"
      aria-modal="true"
      className="pointer-events-auto absolute inset-0 z-30 flex h-full w-full flex-col overflow-y-auto overflow-x-hidden rounded-lg bg-white shadow-xl"
      onClick={(e) => {
        e.stopPropagation();
      }}
      onKeyDown={(e) => {
        if (e.key === "Escape") {
          onClose();
        }
      }}
      onMouseDown={(e) => {
        e.stopPropagation();
      }}
      role="dialog"
      tabIndex={-1}
    >
      <div className="flex justify-end px-4 pt-1">
        <Button
          className="flex items-center gap-2 underline hover:bg-transparent"
          onClick={onClose}
          onMouseEnter={() => setIsCloseHovered(true)}
          onMouseLeave={() => setIsCloseHovered(false)}
          type="button"
          variant="ghost"
        >
          <span
            className={`text-sm ${
              isCloseHovered ? "text-muted-foreground" : "text-(--color-brand-text)"
            }`}
          >
            Close
          </span>
          <Image
            alt="Close"
            className={`mt-1 ml-1 ${isCloseHovered ? "opacity-60" : "opacity-100"}`}
            height={7.15}
            src="/images/cross.svg"
            width={7.15}
          />
        </Button>
      </div>

      <div className="mt-3 h-px bg-black opacity-10" />

      <div className="flex min-w-0 flex-1 flex-col justify-between overflow-y-auto p-3">
        <div className="flex min-w-0 flex-col gap-4">
          <Heading
            className="text-(--color-brand-text) text-sm md:text-sm"
            level={3}
            weight="semibold"
          >
            Your Filters
          </Heading>
          <div className="flex flex-wrap gap-1.5">
            {yourFilters.map((filter) => (
              <CustomChips
                key={filter.id}
                label={filter.label}
                onClick={() => toggleFilter(filter.id)}
                type={activeFilters.some((f) => f.value === filter.id) ? "selected" : "unselected"}
              />
            ))}
          </div>
        </div>

        <div className="flex min-w-0 flex-col gap-4">
          <Heading
            className="font-semibold text-(--color-brand-text) text-sm md:text-sm"
            level={3}
            weight="semibold"
          >
            Suggested
          </Heading>
          <div className="flex flex-wrap gap-1.5">
            {suggestedFilters.map((filter) => (
              <CustomChips
                key={filter.id}
                label={filter.label}
                onClick={() => toggleFilter(filter.id)}
                type={activeFilters.some((f) => f.value === filter.id) ? "selected" : "unselected"}
              />
            ))}
          </div>
        </div>
      </div>

      <div className="flex gap-4 px-4 pt-2 pb-3.5">
        <AppButton className="flex-1" onClick={handleApplyFilters} variant="primary">
          Apply Filter
        </AppButton>
        <AppButton className="flex-1" onClick={handleReset} variant="tertiary">
          Reset
        </AppButton>
      </div>
    </div>
  );
}
