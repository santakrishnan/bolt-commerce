import { CustomBadge } from "@shared/components/custom-badge";
import { Button, Heading } from "@tfs-ucmp/ui";
import Image from "next/image";
import type { CarCardProps } from "./car-card-types";

interface CarCardContentProps {
  carName: string;
  dealerName: string;
  distance: string;
  estimatedPayment: string;
  exteriorColor: string;
  exteriorColorGradient?: string;
  exteriorColorHex: string;
  features: NonNullable<CarCardProps["features"]>;
  interiorColor: string;
  interiorColorHex: string;
  matchPercentage?: string;
  mileage: string;
  onShowEstimation: () => void;
  onShowRefineSearch?: () => void;
  owners: number;
  price: string;
  wasPrice?: string;
}

export function CarCardContent({
  carName,
  price,
  wasPrice,
  mileage,
  estimatedPayment,
  exteriorColor,
  exteriorColorHex,
  exteriorColorGradient,
  interiorColor,
  interiorColorHex,
  matchPercentage,
  dealerName,
  distance,
  owners,
  features,
  onShowEstimation,
  onShowRefineSearch,
}: CarCardContentProps) {
  return (
    <div className="flex flex-col gap-3 p-4 pb-3">
      {/* Divider */}
      <div className="h-px bg-black opacity-10" />

      <div className="min-h-[71px]">
        {/* Car Name and Price */}
        <div className="flex items-start justify-between py-0">
          <Heading
            className="max-w-[185px] font-bold text-[color:var(--Core-surfaces-foreground)] text-base leading-5.5 md:text-base"
            level={3}
            weight="bold"
          >
            {carName.length > 39 ? `${carName.slice(0, 39)}…` : carName}
          </Heading>
          <div className="ml-2 flex flex-col items-end gap-1.5">
            {wasPrice ? (
              <span className="text-gray-400 text-xs">
                <span className="line-through">{wasPrice.toLocaleString()}</span>
              </span>
            ) : (
              <span className="text-white text-xs">-</span>
            )}
            <p className="font-semibold text-[var(--color-card-price)] text-xl">{price}</p>
          </div>
        </div>

        <div className="flex h-6 items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Image
              alt="Mileage"
              className="pt-0.5"
              height={14}
              src="/images/garage/odometer.svg"
              width={14}
            />
            <span className="text-[color:var(--color-inverse-muted)] text-sm">{mileage}</span>
          </div>
          <div className="items-normal flex gap-1.5">
            <span className="text-[color:var(--color-card-badge-price-drop)] text-sm">
              {estimatedPayment}
            </span>

            <Image
              alt="Info"
              className="cursor-pointer"
              height={15}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onShowEstimation();
              }}
              src="/images/i.svg"
              width={15}
            />
          </div>
        </div>
      </div>

      {/* Divider */}
      <div className="h-px bg-black opacity-10" />

      {/* Exterior Color */}
      <div className="flex items-center justify-between">
        <span className="font-normal text-[color:var(--color-inverse-muted)] text-sm">
          Exterior:
        </span>
        <div className="flex items-center gap-3">
          <span className="font-normal text-[color:var(--color-inverse-muted)] text-sm">
            {exteriorColor}
          </span>
          <div className="relative h-6 w-6">
            {exteriorColorGradient ? (
              <div
                className="h-6 w-6 rounded-full border border-[var(--color-states-muted)]"
                style={{ background: exteriorColorGradient }}
              />
            ) : (
              <div
                className="h-6 w-6 rounded-full border border-[var(--color-states-muted)]"
                style={{ backgroundColor: exteriorColorHex }}
              />
            )}
          </div>
        </div>
      </div>

      <div className="h-px bg-black opacity-10" />

      <div className="flex items-center justify-between">
        <span className="font-normal text-[color:var(--color-inverse-muted)] text-sm">
          Interior:
        </span>
        <div className="flex items-center gap-3">
          <span className="font-normal text-[color:var(--color-inverse-muted)] text-sm">
            {interiorColor}
          </span>
          <div
            className="h-6 w-6 rounded-full border border-[var(--color-states-muted)]"
            style={{ backgroundColor: interiorColorHex }}
          />
        </div>
      </div>

      <div className="h-px bg-black opacity-10" />

      <div className="flex items-center justify-between">
        {matchPercentage && (
          <CustomBadge matchPercentage={Number(matchPercentage)} type="matchingPercentage" />
        )}
        {onShowRefineSearch && (
          <Button
            className="h-auto p-0 font-normal text-[var(--color-card-title)] text-sm underline hover:bg-transparent hover:text-[color:var(--color-inverse-muted)]"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onShowRefineSearch();
            }}
            type="button"
            variant="ghost"
          >
            Refine your search
          </Button>
        )}
      </div>

      {/* Divider */}
      <div className="h-px bg-black opacity-10" />

      {/* Dealer Info */}
      <div className="flex h-6 items-center justify-between">
        <Button
          className="h-auto p-0 text-[color:var(--color-inverse-muted)] text-sm no-underline hover:bg-transparent hover:text-[var(--color-card-title)]"
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
          }}
          type="button"
          variant="ghost"
        >
          {dealerName}
        </Button>
        <div className="flex items-center gap-1.5">
          <Image
            alt="Distance"
            className="pt-1"
            height={12}
            src="/images/search/distance.svg"
            style={{ width: "auto" }}
            width={10}
          />
          <span className="text-[color:var(--color-inverse-muted)] text-sm">{distance}</span>
        </div>
      </div>

      {/* Divider */}
      <div className="h-px bg-black opacity-10" />

      {/* Features — three fixed slots: warranty left, inspected center, owner right */}
      <div className="grid grid-cols-3 items-center">
        <div className="flex justify-start">
          {features.warranty && (
            <CustomBadge
              className="px-[0] font-normal text-[color:var(--color-inverse-muted)] text-[length:var(--text-sm)]"
              text="Warranty"
              type="warranty"
            />
          )}
        </div>
        <div className="flex justify-center">
          {features.inspected && (
            <CustomBadge
              className="px-[0] font-normal text-[color:var(--color-inverse-muted)] text-[length:var(--text-sm)]"
              text="Inspected"
              type="Inspected"
            />
          )}
        </div>
        <div className="flex justify-end">
          {owners === 1 && (
            <CustomBadge
              className="px-[0] font-normal text-[color:var(--color-inverse-muted)] text-[length:var(--text-sm)]"
              ownerCount={owners}
              type="owner"
            />
          )}
        </div>
      </div>
    </div>
  );
}
