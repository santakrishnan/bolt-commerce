import { defaultFilterState } from "@features/search/components/filter-sidebar/types";
import { generateQuickFilterPills } from "@features/search/components/search-bar/services/nlp-autocomplete";
import { getInventoryPool, runMockFacetedSearch } from "@features/search/lib/mock-faceted-search";
import type { SearchResponse } from "@features/search/lib/search-types";
import { cacheLife, cacheTag } from "next/cache";

/** Returns quick-filter pill labels derived from the inventory pool. */
export function fetchQuickFilterPills(): string[] {
  return generateQuickFilterPills(getInventoryPool());
}

// Fetch initial SRP results
export async function fetchInitialSrpResults(
  bodyType?: string,
  searchQuery?: string
): Promise<SearchResponse> {
  "use cache";
  cacheLife("srp");
  cacheTag("srp", bodyType ? `srp-${bodyType}` : "srp-all");

  const filterState = {
    ...defaultFilterState,
    ...(bodyType ? { selectedBodyStyles: [bodyType] } : {}),
  };

  return await runMockFacetedSearch({
    filterState,
    searchQuery: searchQuery ?? "",
    page: 1,
    pageSize: 20,
    includeFacets: false,
    sortOption: "recommended",
  });
}
