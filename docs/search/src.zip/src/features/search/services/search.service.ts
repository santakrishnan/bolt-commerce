import { SEARCH_PAGE_SIZE } from "@features/search/lib/constants";
import {
  ArrowServerError,
  type ArrowServerIds,
  createArrowServerClient,
} from "@features/tracking/lib/server-api";
import type { SearchQuery, SearchResult, SearchVehicle } from "./types";

let _client: ReturnType<typeof createArrowServerClient> | null = null;

function getSearchClient() {
  if (!_client) {
    _client = createArrowServerClient({
      baseUrl: process.env.SEARCH_SERVICE_URL ?? "",
      authToken: process.env.SEARCH_API_KEY,
      serviceName: "SearchService",
      timeout: 15_000,
      retries: 1,
    });
  }
  return _client;
}

function isMockMode(): boolean {
  return !process.env.SEARCH_SERVICE_URL || process.env.USE_MOCK_SEARCH === "true";
}

function shuffle<T>(arr: readonly T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = copy[i];
    copy[i] = copy[j] as T;
    copy[j] = tmp as T;
  }
  return copy;
}

async function getMockResults(query: SearchQuery): Promise<SearchResult> {
  const { mockVehicles } = await import("@features/search/lib/mock-vehicles");

  let vehicles: SearchVehicle[] = shuffle(
    mockVehicles.map((v) => ({
      ...v,
      // Jitter the match score ±5 so "sort by relevance" varies per request
      match: Math.max(0, Math.min(100, v.match + Math.floor(Math.random() * 11) - 5)),
      estimation: v.estimation ?? undefined,
    }))
  );

  // Apply basic filtering
  if (query.query) {
    const q = query.query.toLowerCase();

    // Named shortcuts — same logic as the search page's runMockFacetedSearch
    const shortcuts: Record<string, (v: SearchVehicle) => boolean> = {
      "cars-under-$20,000": (v) => v.price < 20_000,
      "shop-excellent-deals": (v) =>
        v.labels.some((l) => l.toLowerCase().includes("excellent price")),
      "price-drop": (v) => v.labels.some((l) => l.toLowerCase().includes("price drop")),
      "low-miles": (v) => Number.parseInt(v.odometer.replace(/\D/g, ""), 10) < 20_000,
    };

    const shortcut = shortcuts[q];
    if (shortcut) {
      vehicles = vehicles.filter(shortcut);
    } else {
      vehicles = vehicles.filter(
        (v) =>
          v.title.toLowerCase().includes(q) ||
          v.make.toLowerCase().includes(q) ||
          v.model.toLowerCase().includes(q)
      );
    }
  }

  if (query.priceMin != null) {
    const min = query.priceMin;
    vehicles = vehicles.filter((v) => v.price >= min);
  }
  if (query.priceMax != null) {
    const max = query.priceMax;
    vehicles = vehicles.filter((v) => v.price <= max);
  }
  if (query.yearMin != null) {
    const min = query.yearMin;
    vehicles = vehicles.filter((v) => v.year >= min);
  }
  if (query.yearMax != null) {
    const max = query.yearMax;
    vehicles = vehicles.filter((v) => v.year <= max);
  }
  if (query.mileageMax != null) {
    const max = query.mileageMax;
    vehicles = vehicles.filter((v) => Number.parseInt(v.odometer.replace(/\D/g, ""), 10) <= max);
  }
  if (query.labels != null && query.labels.length > 0) {
    const labels = query.labels.map((l) => l.toLowerCase());
    vehicles = vehicles.filter((v) =>
      labels.some((l) => v.labels.some((vl) => vl.toLowerCase().includes(l)))
    );
  }

  // Sorting
  const sortBy = query.sortBy ?? "match";
  const sortOrder = query.sortOrder ?? "desc";
  const dir = sortOrder === "asc" ? 1 : -1;

  vehicles.sort((a, b) => {
    switch (sortBy) {
      case "price":
        return (a.price - b.price) * dir;
      case "year":
        return (a.year - b.year) * dir;
      case "match":
        return (a.match - b.match) * dir;
      default:
        return 0;
    }
  });

  // Pagination
  const page = query.page ?? 1;
  const pageSize = query.pageSize ?? SEARCH_PAGE_SIZE;
  const totalResults = vehicles.length;
  const totalPages = Math.ceil(totalResults / pageSize);
  const start = (page - 1) * pageSize;
  const paged = vehicles.slice(start, start + pageSize);

  return {
    vehicles: paged,
    pagination: { page, pageSize, totalResults, totalPages },
  };
}

// ─── Public API ─────────────────────────────────────────────────────────────

export interface SearchOptions {
  forwardHeaders?: Record<string, string>;
  ids?: ArrowServerIds;
  query: SearchQuery;
}

// Execute a vehicle search
export async function searchVehicles({
  query,
  ids,
  forwardHeaders,
}: SearchOptions): Promise<SearchResult> {
  if (isMockMode()) {
    console.log("[SearchService] Mock mode — filtering local data");
    return getMockResults(query);
  }

  try {
    const data = await getSearchClient().post<SearchResult>("/vehicles/search", query, {
      ids,
      headers: forwardHeaders,
    });
    return data;
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[SearchService] BED error:", error.message);
    } else {
      console.error("[SearchService] Unexpected error:", error);
    }

    return {
      vehicles: [],
      pagination: {
        page: query.page ?? 1,
        pageSize: query.pageSize ?? SEARCH_PAGE_SIZE,
        totalResults: 0,
        totalPages: 0,
      },
    };
  }
}
