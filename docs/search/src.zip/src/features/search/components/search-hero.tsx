"use client";
import { SearchBar } from "@features/search/components/search-bar/search-bar";
import { SearchProgressBar } from "@features/search/components/search-progress-bar";
import { useSearchContext } from "@features/search/context/search-context";
import { AppButton } from "@shared/components/button";
import { CustomChips } from "@shared/components/custom-chips";
import { useIntersectionObserver } from "@shared/hooks/use-intersection-observer";
import { Heading } from "@tfs-ucmp/ui";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AutocompleteProxyService } from "~/features/search/components/search-bar/services/autocomplete-proxy";
import { SortFilterBar } from "./sort-filter-bar";
import type { ActiveFilter } from "./vehicle-results";

const autocompleteService = new AutocompleteProxyService();

export interface SearchHeroProps {
  activeFilters: ActiveFilter[];
  onBlurOverlayChange?: (showOverlay: boolean) => void;
  onRemoveFilter: (type: string, value: string) => void;
  onReset?: () => void;
  onSearch: () => void;
  onSearchChange: (query: string) => void;
  onToggleFilter?: () => void;
  placeholder?: string;
  searchQuery: string;
  showQuickFilters?: boolean;
  showTitle?: boolean;
  suggestedPills?: string[];
  vehicleCount?: number;
}

export function SearchHero({
  searchQuery,
  onSearchChange,
  onBlurOverlayChange,
  showTitle = true,
  showQuickFilters = true,
  placeholder = "Try: 'SUV under 35k with heated seats near San Francisco",
  onToggleFilter,
  onReset,
  vehicleCount,
  activeFilters,
  onRemoveFilter,
  suggestedPills,
  onSearch,
}: SearchHeroProps) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [localQuery, setLocalQuery] = useState(searchQuery);
  const [isEditing, setIsEditing] = useState(false);

  useEffect((): void => {
    if (!isEditing) {
      setLocalQuery(searchQuery);
    }
  }, [searchQuery, isEditing]);
  const sectionRef = useRef<HTMLElement>(null);
  const [isHeroVisible, setIsHeroVisible] = useState(true);
  const [isStickyDropdownOpen, setIsStickyDropdownOpen] = useState(false);
  const { isSearching, inventorySize } = useSearchContext();

  const resolvedPills = useMemo(() => suggestedPills ?? [], [suggestedPills]);

  useIntersectionObserver(
    sectionRef,
    (entries) => setIsHeroVisible(entries[0]?.isIntersecting ?? true),
    { threshold: 0 }
  );

  const handleSubmit = useCallback((): void => {
    onSearchChange(localQuery);
    onSearch();
  }, [localQuery, onSearchChange, onSearch]);

  const handleValueChange = useCallback((v: string) => {
    setIsEditing(true);
    setLocalQuery(v);
  }, []);

  const handleQuickFilterSelect = useCallback(
    (filter: string) => {
      setLocalQuery(filter);
      setIsEditing(false);
      onSearchChange(filter);
      onSearch();
    },
    [onSearchChange, onSearch]
  );

  const handleHeroOpenChange = useCallback(
    (open: boolean) => {
      setIsDropdownOpen(open);
      if (open) {
        setIsStickyDropdownOpen(false);
      }
      onBlurOverlayChange?.(open);
    },
    [onBlurOverlayChange]
  );

  const handleStickyOpenChange = useCallback(
    (open: boolean) => {
      setIsStickyDropdownOpen(open);
      if (open) {
        setIsDropdownOpen(false);
      }
      onBlurOverlayChange?.(open);
    },
    [onBlurOverlayChange]
  );

  const heroSearchBarConfig = useMemo(
    () => ({
      displayMode: "pills" as const,
      pillsPlacement: "below" as const,
      withBorder: false,
      placeholder,
      showSearchButton: true,
      enableSearchHistory: false,
      quickFilters: showQuickFilters ? resolvedPills : undefined,
      customPlaceholder: (
        <>
          SUV under 35K with <span className="font-[var(--font-weight-bold)]">low miles</span>.
        </>
      ),
    }),
    [placeholder, showQuickFilters, resolvedPills]
  );

  const stickySearchBarConfig = useMemo(
    () => ({
      displayMode: "pills" as const,
      withBorder: true,
      placeholder,
      showSearchButton: true,
      enableSearchHistory: false,
      quickFilters: resolvedPills,
      customPlaceholder: (
        <>
          SUV under 35K with <span className="font-[var(--font-weight-bold)]">low miles</span>.
        </>
      ),
    }),
    [placeholder, resolvedPills]
  );

  return (
    <>
      {!isHeroVisible && (
        <div className="fixed top-0 right-0 left-0 z-[35] bg-white">
          <div className="mx-auto flex min-h-20 max-w-[var(--container-2xl)] flex-col items-start justify-between gap-4 px-[var(--spacing-2xs)] py-[var(--spacing-xs)] sm:flex-row sm:px-6 lg:px-20">
            {activeFilters.length > 0 ? (
              <SortFilterBar
                className="flex shrink-0 items-center gap-[var(--spacing-sm)]"
                onToggleFilter={onToggleFilter}
                vehicleCount={vehicleCount ?? 0}
              />
            ) : (
              <div className="flex shrink-0 items-center gap-2">
                {onToggleFilter && (
                  <SortFilterBar
                    className="flex shrink-0 items-center gap-[var(--spacing-sm)]"
                    onToggleFilter={onToggleFilter}
                    vehicleCount={vehicleCount ?? 0}
                  />
                )}
              </div>
            )}
            <div
              className={`relative w-full min-w-0 max-w-[848px] flex-1 ${isStickyDropdownOpen ? "z-[50]" : ""}`}
            >
              {activeFilters.length === 0 && (
                <SearchBar
                  autocompleteService={autocompleteService}
                  config={stickySearchBarConfig}
                  onOpenChange={handleStickyOpenChange}
                  onQuickFilterSelect={handleQuickFilterSelect}
                  onSubmit={handleSubmit}
                  onValueChange={handleValueChange}
                  value={localQuery}
                />
              )}
              {activeFilters.length > 0 && (
                <div className="flex-1">
                  <div className="flex flex-wrap items-center justify-center gap-[var(--spacing-2xs)] md:justify-end">
                    {activeFilters.map((filter) => (
                      <CustomChips
                        isRefineSearch={filter.isRefineSearch}
                        key={`${filter.type}-${filter.value}`}
                        label={filter.label}
                        onRemove={() => onRemoveFilter(filter.type, filter.value)}
                        type="applied"
                      />
                    ))}
                    <AppButton onClick={onReset} size="sm" type="button" variant="secondary">
                      Reset
                    </AppButton>
                  </div>
                </div>
              )}
            </div>
          </div>
          <SearchProgressBar isSearching={isSearching} />
        </div>
      )}

      <section
        className={`${isDropdownOpen ? "bg-[var(--color-core-surfaces-background)]" : "bg-[var(--color-core-surfaces-background)]"} py-[var(--spacing-10)] pt-8 pb-6 md:pb-[var(--spacing-lg)] ${isDropdownOpen ? "relative z-30" : ""} ${showTitle ? "" : "py-0"}`}
        ref={sectionRef}
      >
        <div className="mx-auto max-w-[var(--container-2xl)] px-0 sm:px-[var(--spacing-lg)] lg:px-[var(--spacing-4xl)]">
          <div className="flex flex-col gap-6 lg:min-h-[120px] lg:flex-row lg:items-start lg:justify-between">
            {/* Title */}
            {showTitle && (
              <div className="flex flex-col items-center justify-center text-center md:items-start md:justify-start md:text-left">
                <Heading
                  className="mb-[var(--spacing-3)] text-[color:var(--color-core-surfaces-foreground)] text-[length:var(--text-lg)] uppercase leading-[56px] tracking-[-0.449px] md:mb-0 md:text-[length:var(--text-2xl)] lg:text-[length:var(--text-2xl)]"
                  level={1}
                  weight="bold"
                >
                  FIND YOUR NEXT CAR
                </Heading>
                <p className="font-normal text-[length:var(--font-size-sm)] text-brand-text-primary leading-normal">
                  {inventorySize} Vehicles Available
                </p>
              </div>
            )}

            <div
              className={`relative w-full min-w-0 max-w-[848px] flex-1 md:pt-4 ${isDropdownOpen ? "z-50" : ""}`}
            >
              <SearchBar
                autocompleteService={autocompleteService}
                config={heroSearchBarConfig}
                onOpenChange={handleHeroOpenChange}
                onQuickFilterSelect={handleQuickFilterSelect}
                onSubmit={handleSubmit}
                onValueChange={handleValueChange}
                value={localQuery}
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
