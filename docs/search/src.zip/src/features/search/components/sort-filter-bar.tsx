"use client";

import { useSearchContext } from "@features/search/context/search-context";
import { AppButton } from "@shared/components/button";
import Image from "next/image";
import { useEffect, useRef } from "react";
import { syncSortSelectWidth } from "./sort-filter-bar-utils";
import type { SortOption } from "./sort-labels";
import { SORT_LABELS } from "./sort-labels";

export interface SortFilterBarProps {
  className?: string;
  onToggleFilter?: () => void;
  vehicleCount: number;
}

export function SortFilterBar({ vehicleCount, onToggleFilter, className }: SortFilterBarProps) {
  const { sortOption, setSortOption } = useSearchContext();

  const selectRef = useRef<HTMLSelectElement>(null);
  const measureRef = useRef<HTMLSpanElement>(null);

  // biome-ignore lint/correctness/useExhaustiveDependencies: sortOption triggers width recalculation when label text changes
  useEffect((): void => {
    syncSortSelectWidth(measureRef.current, selectRef.current);
  }, [sortOption]);

  return (
    <div className={className}>
      <AppButton
        className="h-10 w-10"
        onClick={onToggleFilter}
        size="xs"
        type="button"
        variant="primary"
      >
        <Image
          alt="Filter"
          className="h-4 w-4 max-w-none"
          height={16}
          src="/images/filter_one.svg"
          width={16}
        />
      </AppButton>

      <div className="mx-auto flex w-fit flex-row items-center gap-[var(--spacing-sm)] md:mx-0 md:flex-col md:items-start md:gap-0">
        <div className="font-[var(--font-family)] font-semibold text-[length:var(--font-size-xs)] text-[var(--color-core-surfaces-foreground)] leading-normal md:text-[length:var(--font-size-md)]">
          {vehicleCount} vehicles found
        </div>

        <span className="mb-[var(--spacing-2xs)] text-[var(--color-brand-border-medium)] md:hidden">
          |
        </span>

        <div className="font-[var(--font-family)] font-semibold text-[length:var(--font-size-xs)] text-[var(--color-core-surfaces-foreground)] leading-normal">
          Sort by:{" "}
          <div className="inline-flex items-center gap-[var(--spacing-sm)] font-semibold">
            <span
              aria-hidden
              className="pointer-events-none invisible absolute whitespace-nowrap font-medium"
              ref={measureRef}
            >
              {SORT_LABELS[sortOption as SortOption]}
            </span>

            <select
              className="cursor-pointer appearance-none border-none bg-transparent font-medium text-black outline-none"
              onChange={(e) => setSortOption(e.target.value as SortOption)}
              ref={selectRef}
              value={sortOption}
            >
              <option value="recommended">Recommended</option>
              <option value="low-high">Low to High</option>
              <option value="high-low">High to Low</option>
            </select>

            <Image
              alt="Dropdown"
              className="h-1.75 w-[var(--spacing-sm)]"
              height={7}
              src="/images/dropdown-arrow.svg"
              width={12}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
