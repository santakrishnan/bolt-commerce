/**
 * SRP Suspense skeleton — lightweight placeholder that prevents CLS while
 * search data streams in. Matches the SRP layout: hero section (title +
 * search bar + quick filter pills) + results header + vehicle card grid.
 *
 * No "use client" — this is a pure server component that streams on the
 * first byte of HTML. Uses only CSS animations (no JS needed).
 */

export function SkeletonBlock({ className }: { className?: string }) {
  return (
    <div
      className={`animate-pulse rounded-[var(--radius-lg)] bg-foreground/5 ${className ?? ""}`}
    />
  );
}

function SkeletonCard() {
  return (
    <div className="overflow-hidden rounded-lg bg-white shadow-sm">
      {/* Image placeholder */}
      <SkeletonBlock className="h-48 w-full rounded-none" />
      {/* Content */}
      <div className="space-y-3 p-4">
        {/* Title */}
        <SkeletonBlock className="h-4 w-3/4" />
        {/* Price */}
        <SkeletonBlock className="h-5 w-1/3" />
        {/* Details row */}
        <div className="flex gap-2">
          <SkeletonBlock className="h-3 w-16" />
          <SkeletonBlock className="h-3 w-20" />
          <SkeletonBlock className="h-3 w-14" />
        </div>
        {/* Dealer */}
        <SkeletonBlock className="h-3 w-1/2" />
      </div>
    </div>
  );
}

function SkeletonPill() {
  return <SkeletonBlock className="h-8 w-24 rounded-full" />;
}

export function SrpSkeleton() {
  return (
    <div className="flex min-h-screen flex-col bg-gray-50">
      {/* ── Hero section ─────────────────────────────────────────── */}
      <section className="bg-[var(--color-core-surfaces-background)] pt-8 pb-6 md:pb-[var(--spacing-lg)]">
        <div className="mx-auto max-w-[var(--container-2xl)] px-0 sm:px-[var(--spacing-lg)] lg:px-[var(--spacing-4xl)]">
          <div className="flex flex-col gap-6 lg:min-h-[120px] lg:flex-row lg:items-start lg:justify-between">
            {/* Title placeholder */}
            <div className="flex flex-col items-center gap-2 md:items-start">
              <SkeletonBlock className="h-10 w-64 md:h-12 md:w-80" />
              <SkeletonBlock className="h-4 w-36" />
            </div>

            {/* Search bar placeholder */}
            <div className="relative w-full min-w-0 max-w-[848px] flex-1 pt-4">
              <SkeletonBlock className="h-12 w-full rounded-full" />
              {/* Quick filter pills placeholder */}
              <div className="mt-3 flex flex-wrap justify-center gap-2 md:justify-start">
                <SkeletonPill />
                <SkeletonPill />
                <SkeletonPill />
                <SkeletonPill />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Progress bar placeholder ──────────────────────────────── */}
      <div className="mx-6 md:mx-0">
        <div className="h-px bg-(--color-structure-interaction-subtle-border)" />
      </div>

      {/* ── Results section ───────────────────────────────────────── */}
      <main className="relative flex-1 bg-gray-100">
        <section className="bg-[var(--color-core-surfaces-background)]">
          <div className="mx-auto px-[var(--spacing-md)] sm:px-[var(--spacing-lg)] lg:px-[var(--spacing-4xl)] 2xl:max-w-[var(--container-2xl)]">
            {/* Results header: filter button + count + sort */}
            <div className="flex min-h-[120px] flex-col gap-[var(--spacing-sm)] py-[var(--spacing-xl)] md:flex-row md:items-start">
              <div className="flex flex-1 items-center justify-center gap-[var(--spacing-sm)] md:flex-none md:justify-start lg:w-[25%]">
                <SkeletonBlock className="h-10 w-10 rounded-lg" />
                <div className="flex flex-col gap-1">
                  <SkeletonBlock className="h-4 w-32" />
                  <SkeletonBlock className="h-3 w-24" />
                </div>
              </div>
              {/* Smart filter chip placeholders */}
              <div className="flex flex-wrap items-center justify-center gap-[var(--spacing-xs)] md:justify-end">
                <SkeletonPill />
                <SkeletonPill />
                <SkeletonPill />
              </div>
            </div>

            {/* Vehicle card grid — matches sm:grid-cols-2 lg:grid-cols-3 */}
            <div className="mb-[var(--spacing-3xl)] grid w-full grid-cols-1 gap-[var(--spacing-md)] sm:grid-cols-2 lg:grid-cols-3">
              <SkeletonCard />
              <SkeletonCard />
              <SkeletonCard />
              <SkeletonCard />
              <SkeletonCard />
              <SkeletonCard />
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
