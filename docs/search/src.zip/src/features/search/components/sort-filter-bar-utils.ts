export function syncSortSelectWidth(
  measureEl: HTMLSpanElement | null,
  selectEl: HTMLSelectElement | null
): boolean {
  if (!(measureEl && selectEl)) {
    return false;
  }

  const width = measureEl.offsetWidth;
  if (width > 0) {
    selectEl.style.width = `${width}px`;
    return true;
  }

  return false;
}
