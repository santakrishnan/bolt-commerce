"use client";

import { getUsedCarsSrpNoResultsMessage } from "@config/messages/used-cars";
import type { FilterState } from "@features/search/components/filter-sidebar/types";
import { useSearchContext } from "@features/search/context/search-context";
import type { RefineSearchFilter } from "@features/search/context/search-context-types";
import type { SmartFilterGroup, SmartFilterOption } from "@features/search/lib/search-types";
import {
  mileageLabelFromOption,
  priceLabelFromOption,
} from "@features/search/lib/smart-filter-utils";
import { vehicleToCarCardProps } from "@features/search/lib/vehicle-to-card-props";
import { CarCard } from "@features/vehicle-card";
import { AppButton } from "@shared/components/button";
import { CustomChips } from "@shared/components/custom-chips";
import type { Vehicle } from "@shared/vehicle";
import { Button } from "@tfs-ucmp/ui";
import Image from "next/image";
import { cn } from "@/lib/utils";
import SmartFilterChip from "./smart-filter-chip";
import { SortFilterBar } from "./sort-filter-bar";

export interface ActiveFilter {
  isRefineSearch?: boolean;
  label: string;
  type: string;
  value: string;
}

export interface VehicleResultsProps {
  activeFilters: ActiveFilter[];
  currentPage: number;
  isInitialLoading?: boolean;
  isPending?: boolean;
  onApplyRefineFilters?: (filters: { id: string; label: string }[]) => void;
  onPageChange: (page: number) => void;
  onRemoveFilter: (type: string, value: string) => void;
  onReset: () => void;
  onSearch: () => void;
  onToggleFilter: () => void;
  searchQuery: string;
  totalCount: number;
  /** Total pages from API response — no client-side math needed. */
  totalPages: number;
  vehicles: Vehicle[];
}

export function VehicleResults({
  vehicles,
  totalCount,
  searchQuery,
  activeFilters,
  isInitialLoading = false,
  isPending = false,
  onToggleFilter,
  onRemoveFilter,
  onReset,
  onSearch,
  onApplyRefineFilters,
  currentPage,
  totalPages,
  onPageChange,
}: VehicleResultsProps) {
  const activeFilterCount = activeFilters.length;

  const {
    smartFilters = [],
    applyFiltersSearch,
    filterState,
    setFilterState,
    refineSearchFilters,
  } = useSearchContext();

  /** Render smart filter chips — shared between no-filter and active-filter views. */
  const renderSmartFilterChips = (prefix = "") =>
    smartFilters.map((group: SmartFilterGroup) =>
      group.options?.map((opt: SmartFilterOption) => (
        <SmartFilterChip
          applyFiltersSearch={applyFiltersSearch}
          computeSmartFilterChange={computeSmartFilterChange}
          filterState={filterState}
          group={group}
          key={`${prefix}${group.name}-${opt.value}`}
          onApplyRefineFilters={onApplyRefineFilters}
          opt={opt}
          prefix={prefix}
          refineSearchFilters={refineSearchFilters}
          setFilterState={setFilterState}
        />
      ))
    );

  function handleBodyStyle(
    opt: SmartFilterOption,
    currentFilterState: FilterState
  ): { handledAsRefine: false; next: FilterState } {
    const next: FilterState = { ...currentFilterState } as FilterState;
    next.selectedBodyStyles = currentFilterState.selectedBodyStyles?.includes(opt.value)
      ? currentFilterState.selectedBodyStyles.filter((v) => v !== opt.value)
      : [...(currentFilterState.selectedBodyStyles || []), opt.value];
    return { handledAsRefine: false, next };
  }

  function handlePriceRange(
    opt: SmartFilterOption,
    currentFilterState: FilterState
  ): { handledAsRefine: false; next: FilterState } {
    const next: FilterState = { ...currentFilterState } as FilterState;
    const label = priceLabelFromOption(opt);
    next.selectedPriceQuick = currentFilterState.selectedPriceQuick === label ? "" : label;
    return { handledAsRefine: false, next };
  }

  function handleMileageOrDistance(
    opt: SmartFilterOption,
    currentFilterState: FilterState
  ): { handledAsRefine: false; next: FilterState } {
    const next: FilterState = { ...currentFilterState } as FilterState;
    const label = mileageLabelFromOption(opt);
    next.selectedMileage = currentFilterState.selectedMileage === label ? "" : (label ?? "");
    return { handledAsRefine: false, next };
  }

  function handleComfortFeature(
    opt: SmartFilterOption,
    currentFilterState: FilterState
  ): { handledAsRefine: false; next: FilterState } {
    const next: FilterState = { ...currentFilterState } as FilterState;
    next.selectedComfortFeatures = currentFilterState.selectedComfortFeatures?.includes(opt.value)
      ? currentFilterState.selectedComfortFeatures.filter((v) => v !== opt.value)
      : [...(currentFilterState.selectedComfortFeatures || []), opt.value];
    return { handledAsRefine: false, next };
  }

  function handleRefineToggle(
    group: SmartFilterGroup,
    opt: SmartFilterOption,
    currentRefines: RefineSearchFilter[] | undefined
  ): { handledAsRefine: true; nextRefines: RefineSearchFilter[] } {
    const refineId = `${group.name}:${opt.value}`;
    const isRefineApplied = currentRefines?.some((f) => f.id === refineId);
    const nextRefines = isRefineApplied
      ? (currentRefines || []).filter((f) => f.id !== refineId)
      : [...(currentRefines || []), { id: refineId, label: opt.display_name ?? opt.value }];
    return { handledAsRefine: true, nextRefines };
  }

  type SmartFilterChange =
    | { handledAsRefine: false; next: FilterState }
    | { handledAsRefine: true; nextRefines: RefineSearchFilter[] };

  function computeSmartFilterChange(
    group: SmartFilterGroup,
    opt: SmartFilterOption,
    currentFilterState: FilterState,
    currentRefines: RefineSearchFilter[] | undefined
  ): SmartFilterChange {
    if (group.name === "body_style") {
      return handleBodyStyle(opt, currentFilterState);
    }
    if (group.name === "Comfort_and_Convenience" || group.name.toLowerCase().includes("comfort")) {
      return handleComfortFeature(opt, currentFilterState);
    }
    if (group.name === "price_range") {
      return handlePriceRange(opt, currentFilterState);
    }
    if (group.name === "mileage_condition" || group.name === "distance_range") {
      return handleMileageOrDistance(opt, currentFilterState);
    }

    return handleRefineToggle(group, opt, currentRefines);
  }

  const handlePageChange = (page: number): void => {
    onPageChange(page);
  };
  const noResultsMessage = getUsedCarsSrpNoResultsMessage({
    query: searchQuery,
    hasActiveFilters: activeFilterCount > 0,
  });

  return (
    <section className="bg-[var(--color-core-surfaces-background)]">
      <div className="mx-auto px-[var(--spacing-md)] sm:px-[var(--spacing-lg)] lg:px-[var(--spacing-4xl)] 2xl:max-w-[var(--container-2xl)]">
        {activeFilterCount === 0 && (
          <div className="flex min-h-[120px] flex-col gap-[var(--spacing-sm)] bg-[var(--color-core-surfaces-background)] py-[var(--spacing-xl)] md:flex-row md:items-start">
            <SortFilterBar
              className="flex flex-1 items-center justify-center gap-[var(--spacing-sm)] md:flex-none md:justify-start lg:w-[25%]"
              onToggleFilter={onToggleFilter}
              vehicleCount={totalCount}
            />
            {/* Smart filter chips */}
            <div className="flex flex-wrap items-center justify-center gap-[var(--spacing-xs)] md:justify-end">
              {renderSmartFilterChips()}
            </div>
          </div>
        )}
        {activeFilterCount > 0 && (
          <div className="flex min-h-[120px] flex-col gap-[var(--spacing-lg)] bg-[var(--color-core-surfaces-background)] py-[var(--spacing-xl)] md:flex-row md:items-start">
            <SortFilterBar
              className="flex items-center justify-center gap-[var(--spacing-sm)] md:flex-none md:justify-start lg:w-[25%]"
              onToggleFilter={onToggleFilter}
              vehicleCount={totalCount}
            />

            <div className="flex-1">
              <div className="flex flex-wrap items-center justify-center gap-[var(--spacing-xs)] md:justify-end">
                {activeFilters.map((filter) => (
                  <CustomChips
                    isRefineSearch={filter.isRefineSearch}
                    key={`${filter.type}-${filter.value}`}
                    label={filter.label}
                    onRemove={() => onRemoveFilter(filter.type, filter.value)}
                    type="applied"
                  />
                ))}

                {/* render smart filters alongside active filters so they remain visible */}
                {renderSmartFilterChips("active-")}
                <AppButton onClick={onReset} size="sm" type="button" variant="secondary">
                  Reset
                </AppButton>
              </div>
            </div>
          </div>
        )}

        <div
          className={cn(
            "mb-[var(--spacing-3xl)] grid w-full grid-cols-1 gap-[var(--spacing-md)] transition-opacity duration-300 ease-in-out sm:grid-cols-2 lg:grid-cols-3",
            isPending && "pointer-events-none opacity-60"
          )}
        >
          {vehicles.map((vehicle) => (
            <CarCard
              key={vehicle.id}
              {...vehicleToCarCardProps(vehicle)}
              activeFilters={activeFilters}
              onApplyRefineFilters={onApplyRefineFilters}
              onSearch={onSearch}
            />
          ))}
        </div>

        {totalPages > 1 && (
          <div className="my-[var(--spacing-3xl)] flex items-center justify-center gap-[var(--spacing-xl)]">
            <Button
              className={cn(
                "flex items-center gap-[var(--spacing-xs)] rounded-full bg-transparent px-0 py-[var(--spacing-xs)] font-semibold text-[var(--Core-surfaces-foreground)] text-xs leading-[125%] tracking-[-0.12px] transition-colors [font-family:var(--font-family)] [leading-trim:both] [text-edge:cap]",
                "hover:bg-gray-100 hover:text-[var(--Core-surfaces-foreground)] disabled:cursor-not-allowed disabled:opacity-50"
              )}
              disabled={currentPage === 1}
              onClick={() => handlePageChange(currentPage - 1)}
              type="button"
              variant="ghost"
            >
              <Image
                alt="Previous page"
                className="mt-[var(--spacing-2xs)] h-[var(--spacing-sd)] w-[var(--spacing-sd)]"
                height={14}
                src="/images/pagination_arrow.svg"
                width={14}
              />
              Previous
            </Button>

            <div className="flex items-center gap-[var(--spacing-xl)]">
              {(() => {
                const pages: (number | "...")[] = [];
                if (totalPages <= 4) {
                  for (let i = 1; i <= totalPages; i++) {
                    pages.push(i);
                  }
                } else if (currentPage <= 3) {
                  pages.push(1, 2, 3, "...", totalPages);
                } else if (currentPage >= totalPages - 2) {
                  pages.push(1, "...", totalPages - 2, totalPages - 1, totalPages);
                } else {
                  pages.push(1, "...", currentPage, "...", totalPages);
                }
                return pages.map((page, idx) => {
                  if (page === "...") {
                    const prev = pages[idx - 1];
                    const next = pages[idx + 1];
                    const ellipsisKey = `ellipsis-${String(prev ?? "start")}-${String(next ?? "end")}`;
                    return (
                      <span
                        className="var(--font-size-xs)] font-semibold text-[length: text-[var(--Core-surfaces-foreground)] leading-[125%] tracking-[-0.12px] [font-family:var(--font-family)] [leading-trim:both] [text-edge:cap]"
                        key={ellipsisKey}
                      >
                        ...
                      </span>
                    );
                  }

                  return (
                    <Button
                      className={cn(
                        "bg-transparent font-semibold text-[length:var(--font-size-sm)] leading-[125%] tracking-[-0.12px] transition-colors [font-family:var(--font-family)] [leading-trim:both] [text-edge:cap]",
                        currentPage === page
                          ? "flex h-10 w-10 items-center justify-center rounded-full bg-[var(--color-actions-accent)] p-0 text-white hover:bg-[var(--color-actions-accent)] hover:text-white"
                          : "h-auto w-auto p-0 text-[var(--Core-surfaces-foreground)] hover:bg-transparent hover:text-[var(--Core-surfaces-foreground)] hover:opacity-70"
                      )}
                      key={`page-${page}`}
                      onClick={() => handlePageChange(page)}
                      type="button"
                      variant="ghost"
                    >
                      {page}
                    </Button>
                  );
                });
              })()}
            </div>

            <Button
              className={cn(
                "var(--font-size-xs)] flex items-center gap-[var(--spacing-xs)] rounded-full bg-transparent px-0 py-[var(--spacing-xs)] font-semibold text-[length: text-[var(--Core-surfaces-foreground)] leading-[125%] tracking-[-0.12px] transition-colors [font-family:var(--font-family)] [leading-trim:both] [text-edge:cap]",
                "hover:bg-gray-100 hover:text-[var(--Core-surfaces-foreground)] disabled:cursor-not-allowed disabled:opacity-50"
              )}
              disabled={currentPage === totalPages}
              onClick={() => handlePageChange(currentPage + 1)}
              type="button"
              variant="ghost"
            >
              Next
              <Image
                alt="Next page"
                className="mt-[var(--spacing-2xs)] h-[var(--spacing-sd)] w-[var(--spacing-sd)] rotate-180"
                height={14}
                src="/images/pagination_arrow.svg"
                width={14}
              />
            </Button>
          </div>
        )}

        {totalCount === 0 && isInitialLoading && (
          <div className="grid grid-cols-1 gap-6 py-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              // biome-ignore lint/suspicious/noArrayIndexKey: static placeholder skeletons with no reordering
              <div className="animate-pulse overflow-hidden rounded-lg bg-white shadow-sm" key={i}>
                <div className="h-48 w-full bg-gray-200" />
                <div className="space-y-3 p-4">
                  <div className="h-4 w-3/4 rounded bg-gray-200" />
                  <div className="h-4 w-1/2 rounded bg-gray-200" />
                  <div className="h-6 w-1/3 rounded bg-gray-200" />
                </div>
              </div>
            ))}
          </div>
        )}

        {totalCount === 0 && !isInitialLoading && (
          <div className="py-[var(--spacing-2xl)] text-center">
            <p className="text-[length:var(--font-size-lg)] text-[var(--color-brand-text-secondary)]">
              {noResultsMessage.title}
            </p>
            <p className="mt-[var(--spacing-xs)] text-[length:var(--font-size-sm)] text-[var(--color-brand-text-tertiary)]">
              {noResultsMessage.hint}
            </p>
          </div>
        )}
      </div>
    </section>
  );
}
