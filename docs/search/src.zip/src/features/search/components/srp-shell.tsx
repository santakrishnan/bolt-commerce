import { getUsedCarsPageTitle } from "@config/messages/used-cars";
import type { SrpUrlFilters } from "@config/routes/used-cars";
import type { ReactNode } from "react";

interface SrpShellProps {
  children?: ReactNode;
  filters?: SrpUrlFilters;
}

/**
 * SrpShell — pure RSC layout wrapper for the Search Results Page.
 *
 * Supported URL patterns:
 *   /used-cars               → "Used Cars for Sale"
 *   /used-cars/truck         → "Used Truck Cars for Sale"
 *   /used-cars/toyota        → "Used Toyota Cars for Sale"
 *   /used-cars/toyota/camry  → "Used Toyota Camry for Sale"
 */
export function SrpShell({ children, filters = {} }: SrpShellProps) {
  const title = getUsedCarsPageTitle({ type: "srp", filters });

  return (
    <div className="flex min-h-screen flex-col bg-gray-50">
      <h1 className="sr-only">{title}</h1>
      {children}
    </div>
  );
}
