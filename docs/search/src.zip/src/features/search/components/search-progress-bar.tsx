"use client";

import { useCallback, useState } from "react";

/**
 * CSS-transition-driven horizontal progress bar for search API calls.
 *
 * Uses React 18+ "adjust state during render" pattern to derive animation
 * phase from `isSearching` — no useEffect, no setTimeout, no extra re-renders.
 *
 * Phase cycle:  idle → filling → completing → idle
 *   - idle:       bar hidden at 0% width
 *   - filling:    bar animates from 0% → 90% (left-to-right fill)
 *   - completing: bar snaps to 100% then fades out
 */

type Phase = "idle" | "filling" | "completing";

interface SearchProgressBarProps {
  isSearching: boolean;
}

const STYLES: Record<Phase, React.CSSProperties> = {
  idle: {
    width: "0%",
    opacity: 0,
    transition: "none",
  },
  filling: {
    width: "90%",
    opacity: 1,
    transition: "width 2s cubic-bezier(0.05, 0.6, 0.1, 1), opacity 0.15s ease",
  },
  completing: {
    width: "100%",
    opacity: 0,
    transition: "width 0.25s ease-in, opacity 0.4s ease 0.2s",
  },
};

export function SearchProgressBar({ isSearching }: SearchProgressBarProps) {
  const [phase, setPhase] = useState<Phase>("idle");

  // Derive phase during render (React 18+ pattern — no useEffect needed).
  // React will re-render immediately with the corrected phase before committing.
  if (isSearching && phase !== "filling") {
    setPhase("filling");
  } else if (!isSearching && phase === "filling") {
    setPhase("completing");
  }

  // Reset to idle after the completion fade-out transition ends.
  const handleTransitionEnd = useCallback((e: React.TransitionEvent) => {
    if (e.propertyName === "opacity") {
      setPhase("idle");
    }
  }, []);

  return (
    <div className="mx-6 md:mx-0">
      <div className="relative h-px overflow-hidden bg-(--color-structure-interaction-subtle-border)">
        <div
          aria-hidden
          className="absolute top-0 left-0 h-full bg-[var(--primary)]"
          data-phase={phase}
          onTransitionEnd={handleTransitionEnd}
          style={STYLES[phase]}
          suppressHydrationWarning
        />
      </div>
    </div>
  );
}
