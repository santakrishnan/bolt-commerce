/**
 * Shared utilities for smart filter label formatting.
 * Used by both VehicleResults and SmartFilterChip components.
 */

import type { SmartFilterOption } from "@features/search/lib/search-types";

const PRICE_REGEX = /Less than \$?(\d+)[kK]/;
const FIRST_CHAR_REGEX = /^./;

/** Format a price smart filter option into a display label (e.g. "$30k or less"). */
export function priceLabelFromOption(option: SmartFilterOption): string {
  const dn = option.display_name || option.value || "";
  const m = PRICE_REGEX.exec(dn);
  if (m) {
    return `$${m[1]}k or less`;
  }
  return dn;
}

/** Format a mileage smart filter option into a display label (e.g. "Low Miles"). */
export function mileageLabelFromOption(option: SmartFilterOption): string {
  const mapping: Record<string, string> = {
    essentially_new: "Under 15k mi",
    very_low: "Low Miles",
  };
  const mapped = mapping[option.value];
  if (mapped) {
    return mapped;
  }
  const dn = option.display_name || option.value || "";
  const normalized = dn.trim().length
    ? dn.trim().replace(FIRST_CHAR_REGEX, (c) => c.toUpperCase())
    : dn;
  return normalized;
}
