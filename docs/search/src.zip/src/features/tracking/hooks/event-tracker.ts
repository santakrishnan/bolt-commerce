"use client";

import { API_ROUTES } from "@config/routes/constants";
import { ARROW_HEADER } from "@features/tracking/constants";
import { useArrowSafe } from "@features/tracking/context/arrow-provider";
import {
  ARROW_ENCRYPTED_HEADER,
  encryptPayload,
  resolveEncryptionKey,
} from "@features/tracking/lib/encryption";
import { useCallback, useRef } from "react";

interface EventTrackRequest {
  eventName: string;
  fingerprintId: string | null;
  profileId: string | null;
  properties?: Record<string, unknown>;
  sessionId: string;
  timestamp: number;
}

interface EventTracker {
  trackEvent(request: EventTrackRequest): Promise<void>;
}

/**
 * Factory that returns an EventTracker for sending (optionally encrypted)
 * events to the configured event service endpoint.
 */
export function createEventTracker(): EventTracker {
  const baseUrl = process.env.NEXT_PUBLIC_EVENT_SERVICE_URL || API_ROUTES.EVENTS;
  const encryptionKey = resolveEncryptionKey();

  return {
    async trackEvent(request: EventTrackRequest): Promise<void> {
      const payload = {
        event: request.eventName,
        properties: request.properties,
        timestamp: request.timestamp,
      };

      const isEncrypted = !!encryptionKey;
      const body = isEncrypted
        ? await encryptPayload(payload, encryptionKey)
        : JSON.stringify(payload);

      const headers: Record<string, string> = {
        "Content-Type": isEncrypted ? "text/plain" : "application/json",
      };
      if (request.sessionId && request.sessionId !== "anonymous") {
        headers[ARROW_HEADER.SESSION_ID] = request.sessionId;
      }
      if (request.fingerprintId) {
        headers[ARROW_HEADER.FP_ID] = request.fingerprintId;
      }
      if (request.profileId) {
        headers[ARROW_HEADER.PROFILE_ID] = request.profileId;
      }
      if (isEncrypted) {
        headers[ARROW_ENCRYPTED_HEADER] = "true";
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10_000);

      let response: Response;
      try {
        response = await fetch(`${baseUrl}/track`, {
          method: "POST",
          headers,
          body,
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timeoutId);
      }

      if (!response.ok) {
        throw new Error(`Event tracking failed: ${response.statusText}`);
      }
    },
  };
}

/**
 * React hook that exposes a `trackEvent` function which sends events using
 * Arrow context IDs (session, fingerprint, profile) when available.
 */
export function useEventTracking() {
  const arrow = useArrowSafe();
  const sessionId = arrow?.sessionId ?? null;
  const fingerprintId = arrow?.fingerprintId ?? null;
  const profileId = arrow?.profileId ?? null;
  const invalidateProfile = arrow?.invalidateProfile ?? null;

  const eventTracker = useRef(createEventTracker());

  const trackEvent = useCallback(
    async (eventName: string, properties?: Record<string, unknown>) => {
      try {
        await eventTracker.current.trackEvent({
          eventName,
          properties,
          sessionId: sessionId ?? "anonymous",
          fingerprintId,
          profileId,
          timestamp: Date.now(),
        });

        invalidateProfile?.().catch((err) => {
          console.error("[Arrow] Failed to invalidate profile after event:", err);
        });
      } catch (error) {
        console.error("[Arrow] Failed to track event:", error);
      }
    },
    [sessionId, fingerprintId, profileId, invalidateProfile]
  );

  return { trackEvent };
}
