"use client";

import { FpjsProvider } from "@fingerprintjs/fingerprintjs-pro-react";
import type { ReactNode } from "react";

const isDev = process.env.NODE_ENV === "development";
function noop() {
  /* no-op */
}
const log = isDev ? console.log.bind(console, "[Fingerprint]") : noop;
const logError = console.error.bind(console, "[Fingerprint]");

interface FingerprintClientProviderProps {
  children: ReactNode;
}

/**
 * Initializes and provides the Fingerprint.js client with
 * endpoints for use by descendant components.
 */
export function FingerprintClientProvider({ children }: FingerprintClientProviderProps) {
  const apiKey = process.env.NEXT_PUBLIC_FINGERPRINT_API_KEY;

  if (!apiKey) {
    logError("API key not configured. Set NEXT_PUBLIC_FINGERPRINT_API_KEY in .env.local");
    return <>{children}</>;
  }

  log("Initializing with API key:", `${apiKey.substring(0, 8)}...`);

  const region = process.env.NEXT_PUBLIC_FINGERPRINT_REGION as "us" | "eu" | "ap" | undefined;

  const useProxy = process.env.NEXT_PUBLIC_USE_FPJS_PROXY === "true";

  if (useProxy) {
    log("Using Next.js rewrites for proxy — endpoint: /fpjs-api");

    return (
      <FpjsProvider
        loadOptions={{
          apiKey,
          endpoint: "/fpjs-api",
          scriptUrlPattern: "/fpjs-cdn/v<version>/<apiKey>/loader_v<loaderVersion>.js",
          region,
        }}
      >
        {children}
      </FpjsProvider>
    );
  }

  const customEndpoint = process.env.NEXT_PUBLIC_FINGERPRINT_ENDPOINT;

  if (customEndpoint) {
    log("Using custom endpoint:", customEndpoint);
    return (
      <FpjsProvider
        loadOptions={{
          apiKey,
          endpoint: customEndpoint,
          region,
        }}
      >
        {children}
      </FpjsProvider>
    );
  }

  log("Using default Fingerprint.js endpoints");
  return (
    <FpjsProvider
      loadOptions={{
        apiKey,
        region,
      }}
    >
      {children}
    </FpjsProvider>
  );
}
