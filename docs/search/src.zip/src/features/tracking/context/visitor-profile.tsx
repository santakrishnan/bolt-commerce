"use client";
import { API_ROUTES } from "@config/routes/constants";
import { ARROW_HEADER } from "@features/tracking/constants";
import {
  createContext,
  type ReactNode,
  use,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

export interface VisitorProfile {
  features?: Record<string, boolean>;
  isKnown?: boolean;
  metadata?: Record<string, unknown>;
  preferences?: Record<string, unknown>;
  profileId: string;
  segment?: string;
  updatedAt?: string;
  userFlags?: {
    prequalified?: boolean;
    tradeIn?: boolean;
    testDrive?: boolean;
  };
}

export interface VisitorProfileState {
  error: Error | null;
  isLoading: boolean;
  isStale: boolean;
  lastFetchedAt: number | null;
  profile: VisitorProfile | null;
}

export interface VisitorProfileActions {
  invalidateProfile(): Promise<void>;
  refreshProfile(): Promise<void>;
}

export type VisitorProfileContextValue = VisitorProfileState & VisitorProfileActions;

export interface VisitorProfileConfig {
  autoFetch?: boolean;
  cacheTtlMs?: number;
  profileEndpoint?: string;
}

const DEFAULT_CONFIG: Required<VisitorProfileConfig> = {
  profileEndpoint: API_ROUTES.VISITOR_PROFILE,
  cacheTtlMs: 5 * 60 * 1000,
  autoFetch: true,
};

const VisitorProfileContext = createContext<VisitorProfileContextValue | null>(null);

interface VisitorProfileProviderProps {
  children: ReactNode;
  config?: VisitorProfileConfig;
  fingerprintId: string | null;
  profileId: string | null;
  sessionId: string | null;
}

/**
 * Provides visitor profile state and actions, fetching profile data when
 * a fingerprint is available and exposing invalidate/refresh helpers.
 */
export function VisitorProfileProvider({
  children,
  sessionId,
  fingerprintId,
  profileId,
  config: userConfig,
}: VisitorProfileProviderProps) {
  const config = useMemo(() => ({ ...DEFAULT_CONFIG, ...userConfig }), [userConfig]);

  const [state, setState] = useState<VisitorProfileState>({
    profile: null,
    isLoading: false,
    error: null,
    lastFetchedAt: null,
    isStale: false,
  });

  const fetchInFlight = useRef(false);
  const version = useRef(0);

  const buildProfileHeaders = useCallback((): Record<string, string> => {
    const headers: Record<string, string> = {};
    if (sessionId) {
      headers[ARROW_HEADER.SESSION_ID] = sessionId;
    }
    if (fingerprintId) {
      headers[ARROW_HEADER.FP_ID] = fingerprintId;
    }
    if (profileId) {
      headers[ARROW_HEADER.PROFILE_ID] = profileId;
    }
    return headers;
  }, [sessionId, fingerprintId, profileId]);

  const fetchProfile = useCallback(
    async (force = false) => {
      if (!fingerprintId) {
        return;
      }

      if (!force && state.lastFetchedAt && Date.now() - state.lastFetchedAt < config.cacheTtlMs) {
        return;
      }

      if (fetchInFlight.current) {
        return;
      }
      fetchInFlight.current = true;

      const currentVersion = ++version.current;

      setState((prev) => ({ ...prev, isLoading: true, error: null }));

      try {
        const url = `${config.profileEndpoint}?visitorId=${encodeURIComponent(fingerprintId)}`;
        const res = await fetch(url, {
          method: "GET",
          headers: buildProfileHeaders(),
          credentials: "include",
        });

        if (currentVersion !== version.current) {
          return;
        }

        if (!res.ok) {
          throw new Error(`Profile fetch failed: ${res.status} ${res.statusText}`);
        }

        const data = await res.json();

        const profile: VisitorProfile = data.profile ?? {
          profileId: data.profileId ?? profileId ?? "",
          segment: data.segment,
          isKnown: !!data.profileId,
          preferences: data.preferences,
          features: data.features,
          metadata: data.metadata,
          updatedAt: data.updatedAt ?? new Date().toISOString(),
        };

        setState({
          profile,
          isLoading: false,
          error: null,
          lastFetchedAt: Date.now(),
          isStale: false,
        });
      } catch (err) {
        if (currentVersion !== version.current) {
          return;
        }
        setState((prev) => ({
          ...prev,
          isLoading: false,
          error: err as Error,
          isStale: true,
        }));
      } finally {
        fetchInFlight.current = false;
      }
    },
    [fingerprintId, profileId, config, state.lastFetchedAt, buildProfileHeaders]
  );

  const invalidateProfile = useCallback(async () => {
    setState((prev) => ({ ...prev, isStale: true, lastFetchedAt: null }));
    await fetchProfile(true);
  }, [fetchProfile]);

  const refreshProfile = useCallback(async () => {
    await invalidateProfile();
  }, [invalidateProfile]);

  useEffect(() => {
    if (config.autoFetch && fingerprintId) {
      fetchProfile();
    }
  }, [fingerprintId, config.autoFetch, fetchProfile]);

  const value: VisitorProfileContextValue = useMemo(
    () => ({
      ...state,
      invalidateProfile,
      refreshProfile,
    }),
    [state, invalidateProfile, refreshProfile]
  );

  return <VisitorProfileContext value={value}>{children}</VisitorProfileContext>;
}

/**
 * Hook to read visitor profile context; throws if used outside provider.
 */
export function useVisitorProfile(): VisitorProfileContextValue {
  const ctx = use(VisitorProfileContext);
  if (!ctx) {
    throw new Error("useVisitorProfile must be used within <ArrowProvider>");
  }
  return ctx;
}
