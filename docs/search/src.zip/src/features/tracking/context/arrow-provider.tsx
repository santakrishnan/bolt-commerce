"use client";

import type { ArrowFingerprintData } from "@features/tracking/lib/fingerprint-filter";
import { createContext, type ReactNode, use, useCallback, useMemo } from "react";
import { FingerprintClientProvider } from "./fingerprint-client";
import { ProfileProvider, useProfileContext } from "./profile-context";
import {
  useVisitorProfile,
  type VisitorProfile,
  type VisitorProfileConfig,
  VisitorProfileProvider,
} from "./visitor-profile";

export interface ArrowContextValue {
  error: Error | null;
  fingerprintData: ArrowFingerprintData | undefined;
  fingerprintId: string | null;
  getTrackingIds(): {
    sessionId: string | null;
    fingerprintId: string | null;
    profileId: string | null;
  };
  invalidateProfile(): Promise<void>;
  isLoading: boolean;
  isProfileLoading: boolean;
  isProfileStale: boolean;
  isReady: boolean;
  profileId: string | null;
  refreshIds(): Promise<void>;
  refreshProfile(): Promise<void>;
  sessionId: string | null;
  visitorProfile: VisitorProfile | null;
}

const ArrowContext = createContext<ArrowContextValue | null>(null);

/**
 * Builds the Arrow context value from profile and visitor data, memoizing
 * fingerprint details and exposing tracking helpers to consumers.
 */
function ArrowBridge({ children }: { children: ReactNode }) {
  const profile = useProfileContext();
  const vp = useVisitorProfile();
  const fingerprintData = useMemo<ArrowFingerprintData | undefined>(() => {
    const fed = profile.fingerprintDetails;
    if (!fed) {
      return undefined;
    }
    return {
      identity: {
        visitorId: fed.visitorId,
        confidence: 0,
        visitorFound: true,
      },
      geo: fed.location
        ? {
            city: fed.location.city,
            country: fed.location.country,
            countryCode: fed.location.countryCode,
            state: fed.location.state,
            stateCode: fed.location.stateCode,
            postalCode: fed.location.postalCode,
            timezone: fed.location.timezone,
          }
        : undefined,
      trust: fed.incognito === undefined ? undefined : { incognito: fed.incognito },
      eventId: "",
      timestamp: 0,
    };
  }, [profile.fingerprintDetails]);

  const getTrackingIds = useCallback(
    () => ({
      sessionId: profile.sessionId,
      fingerprintId: profile.fingerprintId,
      profileId: profile.profileId,
    }),
    [profile.sessionId, profile.fingerprintId, profile.profileId]
  );

  const value: ArrowContextValue = useMemo(
    () => ({
      isReady: profile.isInitialized,
      isLoading: profile.isLoading,
      sessionId: profile.sessionId,
      fingerprintId: profile.fingerprintId,
      profileId: profile.profileId,
      fingerprintData,
      visitorProfile: vp.profile,
      isProfileLoading: vp.isLoading,
      isProfileStale: vp.isStale,
      error: profile.error,
      getTrackingIds,
      refreshIds: profile.refreshIds,
      invalidateProfile: vp.invalidateProfile,
      refreshProfile: vp.refreshProfile,
    }),
    [profile, fingerprintData, getTrackingIds, vp]
  );

  return <ArrowContext value={value}>{children}</ArrowContext>;
}

interface ArrowProviderProps {
  children: ReactNode;
  profileConfig?: VisitorProfileConfig;
}

/**
 * Composes the tracking providers (fingerprint client, profile and visitor
 * profile) and exposes the Arrow context to its children.
 */
export function ArrowProvider({ children, profileConfig }: ArrowProviderProps) {
  return (
    <FingerprintClientProvider>
      <ProfileProvider>
        <ArrowProfileBridge config={profileConfig}>
          <ArrowBridge>{children}</ArrowBridge>
        </ArrowProfileBridge>
      </ProfileProvider>
    </FingerprintClientProvider>
  );
}

/**
 * Wraps children with `VisitorProfileProvider` using the current profile
 * context values (sessionId, fingerprintId, profileId) and optional config.
 */
function ArrowProfileBridge({
  children,
  config,
}: {
  children: ReactNode;
  config?: VisitorProfileConfig;
}) {
  const { sessionId, fingerprintId, profileId } = useProfileContext();

  const mergedConfig = useMemo<VisitorProfileConfig>(() => ({ ...config }), [config]);

  return (
    <VisitorProfileProvider
      config={mergedConfig}
      fingerprintId={fingerprintId}
      profileId={profileId}
      sessionId={sessionId}
    >
      {children}
    </VisitorProfileProvider>
  );
}
/**
 * Returns the `ArrowContext` value and throws if used outside an
 * `ArrowProvider`.
 */
export function useArrow(): ArrowContextValue {
  const ctx = use(ArrowContext);
  if (!ctx) {
    throw new Error("useArrow must be used within <ArrowProvider>");
  }
  return ctx;
}

/**
 * Safe variant that returns the `ArrowContext` value or `null` if not
 * inside an `ArrowProvider`.
 */
export function useArrowSafe(): ArrowContextValue | null {
  return use(ArrowContext);
}
