"use client";

import { API_ROUTES } from "@config/routes/constants";
import { extractSealedResult } from "@features/tracking/lib/sdk-transforms";
import type {
  FedFingerprintData,
  ProfileContextState,
  ProfileContextValue,
} from "@features/tracking/types";
import { useVisitorData } from "@fingerprintjs/fingerprintjs-pro-react";
import { createContext, type ReactNode, use, useCallback, useEffect, useState } from "react";

const isDev = process.env.NODE_ENV === "development";
function noop() {
  /* no-op */
}
const log = isDev ? console.log.bind(console, "[ProfileContext]") : noop;
const logError = console.error.bind(console, "[ProfileContext]");

const ProfileContext = createContext<ProfileContextValue | null>(null);

interface ProfileProviderProps {
  children: ReactNode;
}

let didInit = false;

/**
 * Provides the ProfileContext and manages fingerprint/session/profile lifecycle.
 */
export function ProfileProvider({ children }: ProfileProviderProps) {
  const [state, setState] = useState<ProfileContextState>({
    isInitialized: false,
    isLoading: true,
    sessionId: null,
    fingerprintId: null,
    profileId: null,
    error: null,
  });

  const { getData } = useVisitorData<true>({ extendedResult: true }, { immediate: false });

  /**
   * Initialize session/profile from the Fingerprint SDK and server proxy.
   */
  const initializeFromSdk = useCallback(
    async (signal?: AbortSignal) => {
      const fpData = await getData();

      if (!fpData) {
        throw new Error("Fingerprint SDK returned no data");
      }

      const { visitorId, requestId: eventId } = fpData;
      const confidence = fpData.confidence?.score;
      const sealedResult = extractSealedResult(fpData as never);
      if (!(visitorId || sealedResult)) {
        throw new Error(
          "Fingerprint SDK returned no visitorId and no sealed result. " +
            "Check your API key and dashboard configuration."
        );
      }

      log("SDK obtained:", {
        visitorId: visitorId ?? "(Zero Trust — from sealed result)",
        eventId,
        confidence,
        hasSealedResult: !!sealedResult,
      });

      const response = await fetch(API_ROUTES.SESSION, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        signal,
        body: JSON.stringify({
          mode: "initialize",
          fingerprintId: visitorId ?? undefined,
          eventId,
          sealedResult,
          fingerprintMetadata: {
            confidence,
            requestId: eventId,
            visitorFound: fpData.visitorFound,
          },
        }),
      });

      if (!response.ok) {
        throw new Error(`Profile proxy init failed: ${response.status}`);
      }

      const data = await response.json();

      const fedData: FedFingerprintData | undefined = data.fingerprintDetails;

      setState({
        isInitialized: true,
        isLoading: false,
        sessionId: data.sessionId,
        fingerprintId: data.fingerprintId,
        profileId: data.profileId,
        fingerprintMetadata: {
          confidence,
          requestId: eventId,
          visitorFound: fpData.visitorFound,
        },
        fingerprintDetails: fedData,
        error: null,
      });
    },
    [getData]
  );

  useEffect(() => {
    if (didInit) {
      return;
    }
    didInit = true;

    const controller = new AbortController();

    async function initialize() {
      try {
        log("Bootstrap: checking server cookies...");

        const res = await fetch(API_ROUTES.SESSION, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          signal: controller.signal,
          body: JSON.stringify({ mode: "bootstrap" }),
        });

        if (res.ok) {
          const data = await res.json();

          if (data.initialized) {
            log("Session restored from cookies");
            const details: FedFingerprintData | undefined = data.fingerprintDetails;

            if (details) {
              log("FED fingerprint data available:", {
                visitorId: details.visitorId,
                hasLocation: !!details.location,
                incognito: details.incognito,
              });
            }

            setState((prev) => ({
              ...prev,
              isInitialized: true,
              isLoading: false,
              fingerprintDetails: details,
              error: null,
            }));
            return;
          }
        }

        log("No valid session, calling Fingerprint SDK...");
        await initializeFromSdk(controller.signal);
      } catch (error) {
        if (controller.signal.aborted) {
          return;
        }
        logError("Initialization failed:", error);
        setState((prev) => ({
          ...prev,
          isLoading: false,
          error: error as Error,
        }));
      }
    }

    initialize();

    return () => {
      controller.abort();
    };
  }, [initializeFromSdk]);

  const getTrackingIds = useCallback(
    () => ({
      sessionId: state.sessionId,
      fingerprintId: state.fingerprintId,
      profileId: state.profileId,
    }),
    [state.sessionId, state.fingerprintId, state.profileId]
  );

  const refreshIds = useCallback(async () => {
    setState((prev) => ({ ...prev, isLoading: true }));

    try {
      log("Refreshing IDs...");
      await initializeFromSdk();
    } catch (error) {
      logError("Failed to refresh IDs:", error);
      setState((prev) => ({
        ...prev,
        isLoading: false,
        error: error as Error,
      }));
    }
  }, [initializeFromSdk]);

  const value: ProfileContextValue = {
    ...state,
    getTrackingIds,
    refreshIds,
  };

  return <ProfileContext value={value}>{children}</ProfileContext>;
}

/**
 * Returns the `ProfileContext` value and throws if used outside the provider.
 */
export function useProfileContext(): ProfileContextValue {
  const context = use(ProfileContext);
  if (!context) {
    throw new Error("useProfileContext must be used within ProfileProvider");
  }
  return context;
}
