import * as jose from "jose";

export const ARROW_ENCRYPTED_HEADER = "X-Arrow-Encrypted";

/**
 * Decode Arrow encryption key from environment and return as Uint8Array or null.
 */
export function resolveEncryptionKey(): Uint8Array | null {
  const raw =
    process.env?.ARROW_ENCRYPTION_KEY ?? process.env?.NEXT_PUBLIC_ARROW_ENCRYPTION_KEY ?? null;

  if (!raw) {
    return null;
  }

  return jose.base64url.decode(raw);
}

/**
 * Encrypts the given payload into a compact JWE string using the provided key.
 */
export async function encryptPayload(payload: unknown, key: Uint8Array): Promise<string> {
  const plaintext = new TextEncoder().encode(JSON.stringify(payload));

  const jwe = await new jose.CompactEncrypt(plaintext)
    .setProtectedHeader({ alg: "A256KW", enc: "A256GCM" })
    .encrypt(key);

  return jwe;
}
/**
 * Decrypts a compact JWE string using the provided key and returns the parsed payload.
 */
export async function decryptPayload<T = unknown>(jwe: string, key: Uint8Array): Promise<T> {
  const { plaintext } = await jose.compactDecrypt(jwe, key);
  return JSON.parse(new TextDecoder().decode(plaintext)) as T;
}
