export interface SdkV4Result {
  cacheHit?: boolean;
  confidence?: { score: number };
  requestId: string;
  sealedResult?: string;
  suspectScore?: number;
  visitorFound?: boolean;
  visitorId?: string;
}

/**
 * Detect SDK v4 result shape: has sealedResult or lacks legacy v3 fields.
 */
export function isSdkV4Result(result: unknown): result is SdkV4Result {
  if (!result || typeof result !== "object") {
    return false;
  }

  return "sealedResult" in result || !("browserName" in result || "ipLocation" in result);
}

/**
 * Return the `sealedResult` when `fpData` is an SDK v4 result, otherwise undefined.
 */
export function extractSealedResult(fpData: Record<string, unknown>): string | undefined {
  if (isSdkV4Result(fpData)) {
    return fpData.sealedResult;
  }
  return undefined;
}
