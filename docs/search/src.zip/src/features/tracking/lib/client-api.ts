"use client";

import { ARROW_HEADER } from "@features/tracking/constants";
import { useArrow } from "@features/tracking/context/arrow-provider";
import { useMemo } from "react";
import { ARROW_ENCRYPTED_HEADER, encryptPayload, resolveEncryptionKey } from "./encryption";

export interface ArrowClientIds {
  fingerprintId: string | null;
  profileId: string | null;
  sessionId: string | null;
}

export interface ArrowClientConfig {
  baseUrl?: string;
  defaultHeaders?: Record<string, string>;
  timeout?: number;
}

export interface ArrowRequestOptions extends Omit<RequestInit, "body" | "method"> {
  encrypt?: boolean;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}

export class ArrowClientError extends Error {
  readonly status: number;
  readonly code: string;
  readonly body?: unknown;

  constructor(message: string, status: number, code: string, body?: unknown) {
    super(message);
    this.name = "ArrowClientError";
    this.status = status;
    this.code = code;
    this.body = body;
  }
}

export interface ArrowClient {
  delete<T = unknown>(path: string, opts?: ArrowRequestOptions): Promise<T>;
  get<T = unknown>(path: string, opts?: ArrowRequestOptions): Promise<T>;
  post<T = unknown>(path: string, body?: unknown, opts?: ArrowRequestOptions): Promise<T>;
  put<T = unknown>(path: string, body?: unknown, opts?: ArrowRequestOptions): Promise<T>;
}

/**
 * Factory that creates an `ArrowClient` for making requests with Arrow IDs,
 * optional encryption and timeout handling.
 */
export function createArrowClient(
  ids: ArrowClientIds,
  config: ArrowClientConfig = {}
): ArrowClient {
  const { baseUrl = "", defaultHeaders = {}, timeout = 30_000 } = config;

  function buildHeaders(extra?: Record<string, string>): Record<string, string> {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      ...defaultHeaders,
    };

    if (ids.sessionId) {
      headers[ARROW_HEADER.SESSION_ID] = ids.sessionId;
    }
    if (ids.fingerprintId) {
      headers[ARROW_HEADER.FP_ID] = ids.fingerprintId;
    }
    if (ids.profileId) {
      headers[ARROW_HEADER.PROFILE_ID] = ids.profileId;
    }

    if (extra) {
      Object.assign(headers, extra);
    }

    return headers;
  }

  async function serialiseBody(
    body: unknown,
    encrypt?: boolean
  ): Promise<{ serialised: string; extraHeaders: Record<string, string> }> {
    const extraHeaders: Record<string, string> = {};

    if (encrypt) {
      const key = resolveEncryptionKey();
      if (!key) {
        throw new ArrowClientError(
          "Encryption requested but NEXT_PUBLIC_ARROW_ENCRYPTION_KEY is not set",
          0,
          "ENCRYPTION_KEY_MISSING"
        );
      }
      const serialised = await encryptPayload(body, key);
      extraHeaders[ARROW_ENCRYPTED_HEADER] = "true";
      extraHeaders["Content-Type"] = "text/plain";
      return { serialised, extraHeaders };
    }

    return { serialised: JSON.stringify(body), extraHeaders };
  }

  async function parseErrorResponse(response: Response): Promise<never> {
    let errorBody: unknown;
    try {
      errorBody = await response.json();
    } catch {
      errorBody = await response.text().catch(() => null);
    }
    const code = (errorBody as Record<string, string>)?.code ?? `HTTP_${response.status}`;
    throw new ArrowClientError(
      `Arrow API error: ${response.status} ${response.statusText}`,
      response.status,
      code,
      errorBody
    );
  }

  async function request<T>(
    method: string,
    path: string,
    body?: unknown,
    opts?: ArrowRequestOptions
  ): Promise<T> {
    const url = `${baseUrl}${path}`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);

    let serialisedBody: string | undefined;
    let extraHeaders: Record<string, string> = {};

    if (body !== undefined) {
      const result = await serialiseBody(body, opts?.encrypt);
      serialisedBody = result.serialised;
      extraHeaders = result.extraHeaders;
    }

    try {
      const response = await fetch(url, {
        method,
        headers: buildHeaders({ ...extraHeaders, ...opts?.headers }),
        body: serialisedBody,
        credentials: "include",
        signal: opts?.signal ?? controller.signal,
        ...opts,
      });

      if (!response.ok) {
        await parseErrorResponse(response);
      }

      if (response.status === 204) {
        return undefined as T;
      }

      return (await response.json()) as T;
    } catch (error) {
      if (error instanceof ArrowClientError) {
        throw error;
      }
      if ((error as Error).name === "AbortError") {
        throw new ArrowClientError(`Request to ${path} timed out after ${timeout}ms`, 0, "TIMEOUT");
      }
      throw new ArrowClientError(`Network error: ${(error as Error).message}`, 0, "NETWORK_ERROR");
    } finally {
      clearTimeout(timeoutId);
    }
  }

  return {
    get: <T = unknown>(path: string, opts?: ArrowRequestOptions) =>
      request<T>("GET", path, undefined, opts),
    post: <T = unknown>(path: string, body?: unknown, opts?: ArrowRequestOptions) =>
      request<T>("POST", path, body, opts),
    put: <T = unknown>(path: string, body?: unknown, opts?: ArrowRequestOptions) =>
      request<T>("PUT", path, body, opts),
    delete: <T = unknown>(path: string, opts?: ArrowRequestOptions) =>
      request<T>("DELETE", path, undefined, opts),
  };
}

/**
 * React hook that returns an `ArrowClient` bound to the current Arrow IDs
 * from context and the provided config.
 */
export function useArrowClient(config?: ArrowClientConfig): ArrowClient {
  const { sessionId, fingerprintId, profileId } = useArrow();

  const client = useMemo(
    () => createArrowClient({ sessionId, fingerprintId, profileId }, config),
    [sessionId, fingerprintId, profileId, config]
  );

  return client;
}

/**
 * Return headers containing only the provided Arrow IDs (session, fingerprint, profile).
 */
export function buildArrowHeaders(ids: ArrowClientIds): Record<string, string> {
  const headers: Record<string, string> = {};

  if (ids.sessionId) {
    headers[ARROW_HEADER.SESSION_ID] = ids.sessionId;
  }
  if (ids.fingerprintId) {
    headers[ARROW_HEADER.FP_ID] = ids.fingerprintId;
  }
  if (ids.profileId) {
    headers[ARROW_HEADER.PROFILE_ID] = ids.profileId;
  }

  return headers;
}
