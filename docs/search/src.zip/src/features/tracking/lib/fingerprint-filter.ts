export interface ArrowFingerprintIdentity {
  confidence: number;
  requestId?: string;
  visitorFound: boolean;
  visitorId: string;
}

export interface ArrowBrowserInfo {
  browserName?: string;
  browserVersion?: string;
  device?: string;
  os?: string;
  osVersion?: string;
}

export interface ArrowGeoLocation {
  city?: string;
  country?: string;
  countryCode?: string;
  latitude?: number;
  longitude?: number;
  postalCode?: string;
  state?: string;
  stateCode?: string;
  timezone?: string;
}

export interface ArrowTrustSignals {
  bot?: string;
  incognito?: boolean;
  proxy?: boolean;
  suspectScore?: number;
  tampering?: boolean;
  vpn?: boolean;
}

export interface ArrowFingerprintData {
  browser?: ArrowBrowserInfo;
  eventId: string;
  geo?: ArrowGeoLocation;
  identity: ArrowFingerprintIdentity;
  ip?: string;
  timestamp: number;
  trust?: ArrowTrustSignals;
}

/**
 * Return geo location from Arrow fingerprint data, if available.
 */
export function extractGeoFromArrowData(
  data: ArrowFingerprintData | undefined
): ArrowGeoLocation | undefined {
  return data?.geo;
}

/**
 * Return identity object from Arrow fingerprint data, if present.
 */
export function extractIdentityFromArrowData(
  data: ArrowFingerprintData | undefined
): ArrowFingerprintIdentity | undefined {
  return data?.identity;
}
