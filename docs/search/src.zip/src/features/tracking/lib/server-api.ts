import { ARROW_COOKIE, ARROW_HEADER } from "@features/tracking/constants";
import { decodeCookieValue } from "@shared/lib/sealed-cookie";
import type { NextRequest } from "next/server";
import { ARROW_ENCRYPTED_HEADER, decryptPayload, resolveEncryptionKey } from "./encryption";

/**
 * Decrypt request body when Arrow encryption header is set; otherwise parse JSON.
 */
export async function decryptArrowPayload<T = unknown>(request: NextRequest): Promise<T> {
  const isEncrypted = request.headers.get(ARROW_ENCRYPTED_HEADER) === "true";

  if (!isEncrypted) {
    return (await request.json()) as T;
  }

  const key = resolveEncryptionKey();
  if (!key) {
    throw new ArrowServerError(
      "Encrypted request received but ARROW_ENCRYPTION_KEY is not configured",
      400,
      "ENCRYPTION_KEY_MISSING",
      "Arrow"
    );
  }

  const jwe = await request.text();
  try {
    return await decryptPayload<T>(jwe, key);
  } catch (error) {
    throw new ArrowServerError(
      `Failed to decrypt payload: ${(error as Error).message}`,
      400,
      "DECRYPTION_FAILED",
      "Arrow"
    );
  }
}

export interface ArrowServerIds {
  eventId?: string | null;
  fingerprintId: string | null;
  profileId: string | null;
  sessionId: string | null;
}

export interface ArrowServerClientConfig {
  apiKey?: { headerName: string; value: string };
  authToken?: string;
  baseUrl: string;
  defaultHeaders?: Record<string, string>;
  retries?: number;
  retryDelay?: number;
  serviceName?: string;
  timeout?: number;
}

export interface ArrowServerRequestOptions {
  headers?: Record<string, string>;
  ids?: ArrowServerIds;
  next?: NextFetchRequestConfig;
  timeout?: number;
}

interface NextFetchRequestConfig {
  revalidate?: number | false;
  tags?: string[];
}

/**
 * Error type for Arrow server requests, includes status, code and body.
 */
export class ArrowServerError extends Error {
  readonly status: number;
  readonly code: string;
  readonly service: string;
  readonly body?: unknown;

  constructor(message: string, status: number, code: string, service: string, body?: unknown) {
    super(message);
    this.name = "ArrowServerError";
    this.status = status;
    this.code = code;
    this.service = service;
    this.body = body;
  }

  get isRetryable(): boolean {
    return this.status === 0 || this.status >= 500;
  }

  toJSON() {
    return {
      name: this.name,
      message: this.message,
      status: this.status,
      code: this.code,
      service: this.service,
      body: this.body,
    };
  }
}

/**
 * Extract Arrow IDs from headers or cookies, preferring headers and ignoring 'anonymous'.
 */
export function extractArrowIds(request: NextRequest): ArrowServerIds {
  const cookieValue = (cookieName: string): string | null => {
    const raw = request.cookies.get(cookieName)?.value;
    return raw ? (decodeCookieValue(raw) ?? raw) : null;
  };

  const fromHeaderOrCookie = (headerName: string, cookieName: string): string | null => {
    const header = request.headers.get(headerName);
    if (header && header !== "anonymous") {
      return header;
    }
    return cookieValue(cookieName);
  };

  return {
    sessionId: fromHeaderOrCookie(ARROW_HEADER.SESSION_ID, ARROW_COOKIE.SESSION_ID),
    fingerprintId: fromHeaderOrCookie(ARROW_HEADER.FP_ID, ARROW_COOKIE.FP_ID),
    profileId: fromHeaderOrCookie(ARROW_HEADER.PROFILE_ID, ARROW_COOKIE.PROFILE_ID),
    eventId: fromHeaderOrCookie(ARROW_HEADER.FP_EID, ARROW_COOKIE.FP_EID),
  };
}

const FORWARDABLE_HEADERS: ReadonlySet<string> = new Set([
  "user-agent",
  "accept-language",
  "referer",
  "x-forwarded-for",
  "x-real-ip",
  "cf-connecting-ip",
  "x-request-id",
  "x-correlation-id",
  ARROW_HEADER.SESSION_ID.toLowerCase(),
  ARROW_HEADER.FP_ID.toLowerCase(),
  ARROW_HEADER.PROFILE_ID.toLowerCase(),
  ARROW_HEADER.FP_EID.toLowerCase(),
]);

/**
 * Extract forwardable request headers for sending to downstream services.
 */
export function extractForwardHeaders(request: NextRequest): Record<string, string> {
  const forwarded: Record<string, string> = {};

  for (const [name, value] of request.headers.entries()) {
    if (FORWARDABLE_HEADERS.has(name.toLowerCase()) && value) {
      forwarded[name] = value;
    }
  }

  return forwarded;
}

export interface ArrowServerClient {
  delete<T = unknown>(path: string, opts?: ArrowServerRequestOptions): Promise<T>;
  get<T = unknown>(path: string, opts?: ArrowServerRequestOptions): Promise<T>;
  patch<T = unknown>(path: string, body?: unknown, opts?: ArrowServerRequestOptions): Promise<T>;
  post<T = unknown>(path: string, body?: unknown, opts?: ArrowServerRequestOptions): Promise<T>;
  put<T = unknown>(path: string, body?: unknown, opts?: ArrowServerRequestOptions): Promise<T>;
}

const isDev = process.env.NODE_ENV === "development";

export function createArrowServerClient(config: ArrowServerClientConfig): ArrowServerClient {
  const {
    baseUrl,
    authToken,
    apiKey,
    defaultHeaders = {},
    timeout: defaultTimeout = 15_000,
    retries = 1,
    retryDelay = 500,
    serviceName = "BED",
  } = config;

  const logPrefix = `[Arrow→${serviceName}]`;

  /**
   * Build request headers including Arrow IDs and extra headers.
   */
  function buildHeaders(
    ids?: ArrowServerIds,
    extra?: Record<string, string>
  ): Record<string, string> {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...defaultHeaders,
    };

    if (authToken) {
      headers.Authorization = `Bearer ${authToken}`;
    }
    if (apiKey) {
      headers[apiKey.headerName] = apiKey.value;
    }

    if (ids?.sessionId) {
      headers[ARROW_HEADER.SESSION_ID] = ids.sessionId;
    }
    if (ids?.fingerprintId) {
      headers[ARROW_HEADER.FP_ID] = ids.fingerprintId;
    }
    if (ids?.profileId) {
      headers[ARROW_HEADER.PROFILE_ID] = ids.profileId;
    }
    if (ids?.eventId) {
      headers[ARROW_HEADER.FP_EID] = ids.eventId;
    }

    if (extra) {
      Object.assign(headers, extra);
    }

    return headers;
  }

  /**
   * Sleep for the specified number of milliseconds.
   */
  function sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /**
   * Parse non-OK response body and produce an ArrowServerError.
   */
  async function parseErrorResponse(
    response: Response,
    method: string,
    path: string
  ): Promise<ArrowServerError> {
    let errorBody: unknown;
    try {
      errorBody = await response.json();
    } catch {
      errorBody = await response.text().catch(() => null);
    }
    const code = (errorBody as Record<string, string>)?.code ?? `HTTP_${response.status}`;
    return new ArrowServerError(
      `${serviceName} API error: ${response.status} ${response.statusText} — ${method} ${path}`,
      response.status,
      code,
      serviceName,
      errorBody
    );
  }

  /**
   * Wrap caught exceptions into ArrowServerError (timeout or network).
   */
  function wrapCaughtError(error: unknown, path: string, reqTimeout: number): ArrowServerError {
    if ((error as Error).name === "AbortError") {
      return new ArrowServerError(
        `${serviceName} request to ${path} timed out after ${reqTimeout}ms`,
        0,
        "TIMEOUT",
        serviceName
      );
    }
    return new ArrowServerError(
      `${serviceName} network error: ${(error as Error).message}`,
      0,
      "NETWORK_ERROR",
      serviceName
    );
  }

  /**
   * Determine whether the error is retryable and perform backoff sleep.
   */
  async function shouldRetry(error: ArrowServerError, attempt: number): Promise<boolean> {
    if (error.isRetryable && attempt < retries) {
      if (isDev) {
        console.warn(`${logPrefix} Retryable error, retrying in ${retryDelay * 2 ** attempt}ms...`);
      }
      await sleep(retryDelay * 2 ** attempt);
      return true;
    }
    return false;
  }

  /**
   * Build RequestInit for fetch, attaching headers, body and signal.
   */
  function buildFetchInit(
    method: string,
    body: unknown,
    signal: AbortSignal,
    opts?: ArrowServerRequestOptions
  ): RequestInit & { next?: NextFetchRequestConfig } {
    const fetchInit: RequestInit & { next?: NextFetchRequestConfig } = {
      method,
      headers: buildHeaders(opts?.ids, opts?.headers),
      body: body === undefined ? undefined : JSON.stringify(body),
      signal,
    };
    if (opts?.next) {
      fetchInit.next = opts.next;
    }
    return fetchInit;
  }

  /**
   * Execute a single HTTP attempt with timeout and return data or error.
   */
  async function executeSingleAttempt<T>(
    url: string,
    method: string,
    path: string,
    body: unknown,
    reqTimeout: number,
    opts?: ArrowServerRequestOptions
  ): Promise<{ data: T } | { error: ArrowServerError }> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), reqTimeout);

    try {
      if (isDev) {
        console.log(`${logPrefix} ${method} ${path}`);
      }

      const response = await fetch(url, buildFetchInit(method, body, controller.signal, opts));

      if (!response.ok) {
        return { error: await parseErrorResponse(response, method, path) };
      }

      if (response.status === 204) {
        return { data: undefined as T };
      }

      const data = (await response.json()) as T;

      if (isDev) {
        console.log(`${logPrefix} ${method} ${path} → ${response.status}`);
      }

      return { data };
    } catch (error) {
      if (error instanceof ArrowServerError) {
        return { error };
      }
      return { error: wrapCaughtError(error, path, reqTimeout) };
    } finally {
      clearTimeout(timeoutId);
    }
  }

  /**
   * Perform request with retries and return parsed response data.
   */
  async function request<T>(
    method: string,
    path: string,
    body?: unknown,
    opts?: ArrowServerRequestOptions
  ): Promise<T> {
    const url = `${baseUrl}${path}`;
    const reqTimeout = opts?.timeout ?? defaultTimeout;
    let lastError: ArrowServerError | null = null;

    for (let attempt = 0; attempt <= retries; attempt++) {
      const result = await executeSingleAttempt<T>(url, method, path, body, reqTimeout, opts);

      if ("data" in result) {
        return result.data;
      }

      lastError = result.error;

      if (await shouldRetry(lastError, attempt)) {
        continue;
      }

      throw lastError;
    }

    throw lastError ?? new ArrowServerError("Unexpected error", 0, "UNKNOWN", serviceName);
  }

  return {
    get: <T = unknown>(path: string, opts?: ArrowServerRequestOptions) =>
      request<T>("GET", path, undefined, opts),
    post: <T = unknown>(path: string, body?: unknown, opts?: ArrowServerRequestOptions) =>
      request<T>("POST", path, body, opts),
    put: <T = unknown>(path: string, body?: unknown, opts?: ArrowServerRequestOptions) =>
      request<T>("PUT", path, body, opts),
    patch: <T = unknown>(path: string, body?: unknown, opts?: ArrowServerRequestOptions) =>
      request<T>("PATCH", path, body, opts),
    delete: <T = unknown>(path: string, opts?: ArrowServerRequestOptions) =>
      request<T>("DELETE", path, undefined, opts),
  };
}
