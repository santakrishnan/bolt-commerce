import { describe, expect, it, vi } from "vitest";

vi.mock("@features/tracking/context/arrow-provider", () => ({
  ArrowProvider: () => null,
  useArrow: () => ({}),
}));

vi.mock("@features/tracking/context/fingerprint-client", () => ({
  FingerprintClientProvider: () => null,
}));

vi.mock("@features/tracking/context/profile-context", () => ({
  ProfileProvider: () => null,
  useProfileContext: () => ({}),
}));

vi.mock("@features/tracking/context/visitor-profile", () => ({
  useVisitorProfile: () => ({}),
  VisitorProfileProvider: () => null,
}));

vi.mock("@features/tracking/hooks/event-tracker", () => ({
  createEventTracker: () => ({}),
  useEventTracking: () => ({}),
}));

vi.mock("@features/tracking/lib/client-api", () => ({ createArrowClient: () => ({}) }));

vi.mock("@features/tracking/lib/encryption", () => ({
  decryptPayload: () => ({}),
  encryptPayload: () => ({}),
}));

vi.mock("@features/tracking/lib/fingerprint-filter", () => ({
  extractGeoFromArrowData: () => ({}),
  extractIdentityFromArrowData: () => ({}),
}));

vi.mock("@features/tracking/lib/sdk-transforms", () => ({
  extractSealedResult: () => ({}),
  isSdkV4Result: () => false,
}));

vi.mock("@features/tracking/lib/server-api", () => ({
  ArrowServerError: class ArrowServerError extends Error {},
  createArrowServerClient: () => ({}),
  extractArrowIds: () => ({}),
}));

vi.mock("@features/tracking/services/events.service", () => ({ trackEvent: () => null }));

vi.mock("@features/tracking/services/sealed.service", () => ({
  unsealFingerprintResult: () => ({}),
}));

describe("public index exports", () => {
  it("re-exports constants from index", async () => {
    const index = await import("@features/tracking/index");
    const constants = await import("@features/tracking/constants");

    expect(index.ARROW_COOKIE).toEqual(constants.ARROW_COOKIE);
    expect(index.ARROW_HEADER).toEqual(constants.ARROW_HEADER);
    expect(typeof index.trackEvent).toBe("function");
  });
});
