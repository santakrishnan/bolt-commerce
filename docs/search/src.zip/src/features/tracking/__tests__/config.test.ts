import {
  ConfigValidationError,
  getTrackingConfig,
  isClientConfigValid,
  isServerConfigValid,
  validateClientConfig,
  validateServerConfig,
} from "@features/tracking/config";
import { afterEach, beforeEach, describe, expect, it } from "vitest";

describe("config module", () => {
  const OLD_ENV = process.env;

  beforeEach(() => {
    process.env = { ...OLD_ENV };
  });

  afterEach(() => {
    process.env = OLD_ENV;
  });

  it("throws ConfigValidationError when server vars are missing", () => {
    process.env.FINGERPRINT_SERVICE_URL = undefined;
    process.env.FINGERPRINT_API_KEY = undefined;

    try {
      validateServerConfig();
      throw new Error("expected to throw");
    } catch (err) {
      expect(err).toBeInstanceOf(ConfigValidationError);
      const e = err as ConfigValidationError;
      expect(e.missingVars).toContain("FINGERPRINT_SERVICE_URL");
      expect(e.missingVars).toContain("FINGERPRINT_API_KEY");
    }
  });

  it("throws when server url is invalid", () => {
    process.env.FINGERPRINT_SERVICE_URL = "not-a-url";
    process.env.FINGERPRINT_API_KEY = "ok";

    try {
      validateServerConfig();
      throw new Error("expected to throw");
    } catch (err) {
      expect(err).toBeInstanceOf(ConfigValidationError);
      const e = err as ConfigValidationError;
      expect(e.invalidVars.some((s) => s.includes("FINGERPRINT_SERVICE_URL"))).toBe(true);
    }
  });

  it("returns server config when envs are valid", () => {
    process.env.FINGERPRINT_SERVICE_URL = "https://fp.example";
    process.env.FINGERPRINT_API_KEY = "apikey";

    const cfg = validateServerConfig();
    expect(cfg.fingerprintApiKey).toBe("apikey");
    expect(cfg.fingerprintServiceUrl).toBe("https://fp.example");
  });

  it("validateClientConfig throws on invalid NEXT_PUBLIC urls", () => {
    process.env.NEXT_PUBLIC_PROFILE_SERVICE_URL = "bad-url";
    process.env.NEXT_PUBLIC_EVENT_SERVICE_URL = "also-bad";

    expect(() => validateClientConfig()).toThrow(ConfigValidationError);
  });

  it("validateClientConfig returns provided urls when valid", () => {
    process.env.NEXT_PUBLIC_PROFILE_SERVICE_URL = "https://profile.example";
    process.env.NEXT_PUBLIC_EVENT_SERVICE_URL = "https://events.example";

    const cfg = validateClientConfig();
    expect(cfg.profileServiceUrl).toBe("https://profile.example");
    expect(cfg.eventServiceUrl).toBe("https://events.example");
  });

  it("getTrackingConfig returns combined config", () => {
    process.env.FINGERPRINT_SERVICE_URL = "https://fp.example";
    process.env.FINGERPRINT_API_KEY = "apikey";
    process.env.NEXT_PUBLIC_PROFILE_SERVICE_URL = "https://profile.example";

    const t = getTrackingConfig();
    expect(t.server.fingerprintApiKey).toBe("apikey");
    expect(t.client.profileServiceUrl).toBe("https://profile.example");
  });

  it("isServerConfigValid / isClientConfigValid behave as expected", () => {
    process.env.FINGERPRINT_SERVICE_URL = undefined;
    process.env.FINGERPRINT_API_KEY = undefined;
    expect(isServerConfigValid()).toBe(false);

    process.env.FINGERPRINT_SERVICE_URL = "https://fp.example";
    process.env.FINGERPRINT_API_KEY = "apikey";
    expect(isServerConfigValid()).toBe(true);

    process.env.NEXT_PUBLIC_PROFILE_SERVICE_URL = "not-a-url";
    expect(isClientConfigValid()).toBe(false);

    process.env.NEXT_PUBLIC_PROFILE_SERVICE_URL = "https://profile.example";
    expect(isClientConfigValid()).toBe(true);
  });
});
