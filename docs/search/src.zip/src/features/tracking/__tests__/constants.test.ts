import { ARROW_COOKIE, ARROW_HEADER, ARROW_TTL } from "@features/tracking/constants";
import { describe, expect, it } from "vitest";

describe("constants", () => {
  it("exports expected cookie and header names", () => {
    expect(ARROW_COOKIE.SESSION_ID).toBe("_arrow_session_id");
    expect(ARROW_COOKIE.FP_ID).toBe("_arrow_fp_id");
    expect(ARROW_HEADER.SESSION_ID).toBe("X-Arrow-Session-Id");
    expect(ARROW_HEADER.FP_ID).toBe("X-Arrow-Fp-Id");
  });

  it("exports numeric TTLs", () => {
    expect(typeof ARROW_TTL.SESSION).toBe("number");
    expect(ARROW_TTL.FINGERPRINT).toBe(24 * 60 * 60);
  });
});
