import { cacheLife, cacheTag } from "next/cache";
import type { FingerprintApiResponse, FingerprintEventData } from "./fingerprint-types";

const isDev = process.env.NODE_ENV === "development";
function noop() {
  /*no-op */
}
const log = isDev ? console.log.bind(console, "[FingerprintService]") : noop;
const logWarn = isDev ? console.warn.bind(console, "[FingerprintService]") : noop;
const logError = console.error.bind(console, "[FingerprintService]");
const FINGERPRINT_API_BASE_URL = process.env.FINGERPRINT_API_BASE_URL ?? "https://api.fpjs.io";

/**
 * Transforms a raw Fingerprint Server API v4 response into the canonical
 * `FingerprintEventData` shape.
 */
function transformFingerprintApiResponse(
  eventId: string,
  data: FingerprintApiResponse
): FingerprintEventData {
  const identification = data.identification;

  return {
    event_id: data.event_id ?? eventId,
    visitor_id: identification?.visitor_id ?? "",
    timestamp: data.timestamp ?? Date.now(),
    url: data.url,
    ip_address: data.ip_address,
    user_agent: data.user_agent,
    browser_details: data.browser_details,
    identification: {
      visitor_id: identification?.visitor_id ?? "",
      confidence: {
        score: identification?.confidence?.score ?? 0,
      },
      visitor_found: identification?.visitor_found ?? false,
    },
    ip_info: data.ip_info,
    bot: data.bot,
    incognito: data.incognito,
    vpn: data.vpn,
    proxy: data.proxy,
    tampering: data.tampering,
    suspect_score: data.suspect_score,
  };
}

/**
 * Fetch fingerprint details from FP API, cache and return transformed data or null.
 */
export async function fetchFingerprintDetails(
  eventId: string
): Promise<FingerprintEventData | null> {
  "use cache";
  cacheLife("days");
  cacheTag("fingerprint", `fp-event-${eventId}`);

  const apiKey = process.env.FINGERPRINT_SECRET_API_KEY;

  if (!apiKey) {
    logWarn("FINGERPRINT_SECRET_API_KEY not configured, skipping Server API call");
    return null;
  }
  console.log("Fetching fingerprint details for event ID:", eventId);
  try {
    log("Fetching visitor details from Fingerprint Server API...");

    const response = await fetch(`${FINGERPRINT_API_BASE_URL}/v4/events/${eventId}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${apiKey}`,
      },
    });

    if (!response.ok) {
      logError("Fingerprint Server API error:", response.status, response.statusText);
      return null;
    }

    const data: FingerprintApiResponse = await response.json();

    const eventData = transformFingerprintApiResponse(eventId, data);

    log("Fingerprint Server API response received:", {
      visitor_id: eventData.visitor_id,
      confidence: eventData.identification?.confidence.score,
      bot: eventData.bot,
    });

    return eventData;
  } catch (error) {
    logError("Failed to fetch Fingerprint details:", error);
    return null;
  }
}
