import type { FingerprintEventData } from "./fingerprint-types";

export interface ProfileResolvePayload {
  fingerprintDetails: FingerprintEventData | null;
  fingerprintId: string;
  metadata?: {
    confidence?: number;
    requestId?: string;
    visitorFound?: boolean;
  };
  sessionId: string;
}

export interface ProfileResolveResult {
  profileId: string;
}

export interface ProfileResolveApiResponse {
  id?: string;
  profileId?: string;
}

export interface VisitorLocation {
  city?: string;
  country?: string;
  countryCode?: string;
  latitude?: number;
  longitude?: number;
  postalCode?: string;
  state?: string;
  stateCode?: string;
  timezone?: string;
}

export interface VisitorDevice {
  browserName?: string;
  browserVersion?: string;
  device?: string;
  os?: string;
  osVersion?: string;
}

export interface VisitorTrustSignals {
  bot?: boolean;
  incognito?: boolean;
  proxy?: boolean;
  suspectScore?: number;
  vpn?: boolean;
}

export interface VisitorUserFlags {
  prequalified?: boolean;
  testDrive?: boolean;
  tradeIn?: boolean;
}

export interface VisitorProfile {
  device?: VisitorDevice;
  firstSeen: string;
  lastSeen: string;
  location?: VisitorLocation;
  metadata?: Record<string, unknown>;
  profileId: string | null;
  tags?: string[];
  trust?: VisitorTrustSignals;
  userFlags?: VisitorUserFlags;
  visitCount: number;
  visitorId: string;
}

export interface VisitorProfileApiResponse {
  error?: string;
  profile?: VisitorProfile;
}
