export interface FingerprintBrowserDetails {
  browser_major_version?: string;
  browser_name?: string;
  device?: string;
  os?: string;
  os_version?: string;
}

export interface FingerprintIdentification {
  confidence: {
    score: number;
  };
  visitor_found: boolean;
  visitor_id: string;
}

export interface FingerprintIpGeolocation {
  accuracy_radius?: number;
  city_name?: string;
  continent_code?: string;
  continent_name?: string;
  country_code?: string;
  country_name?: string;
  latitude?: number;
  longitude?: number;
  postal_code?: string;
  subdivisions?: Array<{ iso_code?: string; name?: string }>;
  timezone?: string;
}

export interface FingerprintIpInfo {
  v4?: {
    address?: string;
    geolocation?: FingerprintIpGeolocation;
  };
}

export interface FingerprintEventData {
  bot?: string;
  browser_details?: FingerprintBrowserDetails;
  event_id: string;
  identification?: FingerprintIdentification;
  incognito?: boolean;
  ip_address?: string;
  ip_info?: FingerprintIpInfo;
  proxy?: boolean;
  suspect_score?: number;
  tampering?: boolean;
  timestamp: number;
  url?: string;
  user_agent?: string;
  visitor_id: string;
  vpn?: boolean;
}

export interface FingerprintApiResponse {
  bot?: string;
  browser_details?: FingerprintBrowserDetails;
  event_id?: string;
  identification?: {
    visitor_id?: string;
    confidence?: { score?: number };
    visitor_found?: boolean;
  };
  incognito?: boolean;
  ip_address?: string;
  ip_info?: FingerprintIpInfo;
  proxy?: boolean;
  suspect_score?: number;
  tampering?: boolean;
  timestamp?: number;
  url?: string;
  user_agent?: string;
  vpn?: boolean;
}
