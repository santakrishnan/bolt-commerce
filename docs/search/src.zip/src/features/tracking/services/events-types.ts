export interface EventTrackingIds {
  fingerprintId: string | null;
  profileId: string | null;
  sessionId: string;
}

export interface TrackEventPayload {
  event: string;
  properties?: Record<string, unknown>;
  timestamp: number;
  trackingIds: EventTrackingIds;
}

export interface TrackEventResult {
  eventId: string;
}
