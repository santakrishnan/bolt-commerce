import {
  ArrowServerError,
  type ArrowServerIds,
  createArrowServerClient,
} from "@features/tracking/lib/server-api";
import { cacheLife, cacheTag } from "next/cache";
import { v4 as uuidv4 } from "uuid";
import type {
  ProfileResolveApiResponse,
  ProfileResolvePayload,
  VisitorProfile,
  VisitorProfileApiResponse,
} from "./visitor-profile-types";

let _client: ReturnType<typeof createArrowServerClient> | null = null;

/**
 * Return singleton Arrow server client for the profile service; creates on first call.
 */
function getProfileClient() {
  if (!_client) {
    _client = createArrowServerClient({
      baseUrl: process.env.PROFILE_SERVICE_URL ?? "",
      authToken: process.env.PROFILE_API_KEY,
      serviceName: "VisitorProfileService",
      timeout: 10_000,
      retries: 1,
    });
  }
  return _client;
}

/**
 * Return true when profile service is disabled or mock profile mode is enabled.
 */
function isMockMode(): boolean {
  return !process.env.PROFILE_SERVICE_URL || process.env.USE_MOCK_PROFILE === "true";
}

/**
 * Create a short mock profile ID used for mock profiles in tests/dev.
 */
function createMockProfileId(): string {
  return `prof_mock_${uuidv4().substring(0, 16)}`;
}

/**
 * Create a mock VisitorProfile for the given visitorId (used in mock mode).
 */
function createMockVisitorProfile(visitorId: string): VisitorProfile {
  const now = new Date().toISOString();
  return {
    visitorId,
    profileId: createMockProfileId(),
    firstSeen: now,
    lastSeen: now,
    visitCount: 1,
    location: {
      city: "San Francisco",
      state: "California",
      stateCode: "CA",
      country: "United States",
      countryCode: "US",
      postalCode: "94105",
      timezone: "America/Los_Angeles",
      latitude: 37.7749,
      longitude: -122.4194,
    },
    device: {
      browserName: "Chrome",
      browserVersion: "125",
      os: "macOS",
      osVersion: "14.5",
      device: "Desktop",
    },
    trust: {
      incognito: false,
      bot: false,
      vpn: false,
      proxy: false,
      suspectScore: 0.02,
    },
    userFlags: {
      prequalified: false,
      tradeIn: false,
      testDrive: false,
    },
    tags: ["returning-visitor"],
    metadata: { source: "mock" },
  };
}

export interface ResolveProfileOptions {
  forwardHeaders?: Record<string, string>;
  ids?: ArrowServerIds;
  payload: ProfileResolvePayload;
}

/**
 * Resolve a profile by calling the profile service or returning a mock ID.
 */
export async function resolveProfile({
  payload,
  ids,
  forwardHeaders,
}: ResolveProfileOptions): Promise<string | null> {
  if (isMockMode()) {
    const profileId = createMockProfileId();
    console.log("[VisitorProfileService] Using mock profile:", profileId);
    return profileId;
  }

  try {
    const data = await getProfileClient().post<ProfileResolveApiResponse>(
      "/profiles/resolve",
      payload,
      { ids, headers: forwardHeaders }
    );

    const profileId = data.profileId ?? data.id;

    if (!profileId) {
      console.warn("[VisitorProfileService] Upstream returned no profileId");
      return null;
    }

    console.log("[VisitorProfileService] Profile resolved:", profileId);
    return profileId;
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[VisitorProfileService] BED error:", error.message);
    } else {
      console.error("[VisitorProfileService] Unexpected error:", error);
    }
    return null;
  }
}

export interface FetchVisitorProfileOptions {
  forwardHeaders?: Record<string, string>;
  ids?: ArrowServerIds;
  visitorId: string;
}

/**
 * Fetch a visitor profile from the profile service or return a mock profile.
 */
export async function fetchVisitorProfile({
  visitorId,
  ids,
  forwardHeaders,
}: FetchVisitorProfileOptions): Promise<VisitorProfile | null> {
  if (isMockMode()) {
    const profile = createMockVisitorProfile(visitorId);
    console.log("[VisitorProfileService] Using mock visitor profile for:", visitorId);
    return profile;
  }

  try {
    const data = await getProfileClient().get<VisitorProfileApiResponse>(
      `/profiles/${encodeURIComponent(visitorId)}`,
      { ids, headers: forwardHeaders }
    );

    if (!data.profile) {
      console.warn("[VisitorProfileService] No profile found for:", visitorId);
      return null;
    }

    return data.profile;
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[VisitorProfileService] BED error:", error.message);
    } else {
      console.error("[VisitorProfileService] Unexpected error:", error);
    }
    return null;
  }
}

// biome-ignore lint/suspicious/useAwait: async is required by the "use cache" Next.js directive
export async function getCachedVisitorProfile(visitorId: string): Promise<VisitorProfile | null> {
  "use cache";
  cacheTag("visitor-profile", `visitor-profile-${visitorId}`);
  cacheLife("profile");

  return fetchVisitorProfile({ visitorId });
}
