import { render, screen } from "@arrow/vitest-config/test-utils";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { MyGarageWrapper } from "../my-garagewrapper";

vi.mock("next/headers", () => ({
  headers: vi.fn(async () => ({
    get: vi.fn(() => "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)"),
  })),
}));

const FIND_YOUR_VEHICLE_REGEX = /find your vehicle/i;

const flagsState = {
  isPreQualified: false,
  hasTradeInSubmitted: false,
  firstName: "Jane",
  lastName: "Doe",
  isAuthenticated: true,
  isNewUser: false,
};

const mockCars = [
  {
    id: 1,
    vin: "VIN001",
    title: "2024 Toyota Camry",
    make: "Toyota",
    model: "Camry",
    variant: "XSE",
    year: 2024,
    price: 32_000,
    odometer: "12,345 mi",
    miles: "Toyota of Fort Worth - 6.1mi",
    image: "/images/camry.jpg",
    labels: [],
    match: 0,
    owners: 1,
    bodyType: "Sedan",
    drivetrain: "FWD",
    fuelType: "Gasoline",
    transmission: "Automatic",
    extColorCode: "#FFFFFF",
    extColorName: "White",
    intColorCode: "#000000",
    intColorName: "Black",
    mileage: 12_345,
    inspection160: true,
    seatingCapacity: ["5"],
    features: { comfort: [], exterior: [], performance: [], safety: [], tech: [] },
  },
];

vi.mock("@config/flags/flags", () => ({
  getUserInfo: vi.fn(async () => ({
    firstName: flagsState.firstName,
    lastName: flagsState.lastName,
    isAuthenticated: flagsState.isAuthenticated,
  })),
  customerPreQualified: vi.fn(async () => flagsState.isPreQualified),
  customerTradeInSubmitted: vi.fn(async () => flagsState.hasTradeInSubmitted),
  showDefaultLandingHero: vi.fn(async () => flagsState.isNewUser),
  heroDeviceTypeOverride: vi.fn(async () => "auto"),
}));

vi.mock("@features/my-garage/hooks/fetch-garage-cars", () => ({
  fetchGarageCars: vi.fn(async () => mockCars),
}));

vi.mock("@features/my-garage/hooks/fetch-because-viewed-cars", () => ({
  fetchBecauseYouViewedCars: vi.fn(async () => []),
}));

vi.mock("@features/landing", () => ({
  HomeHero: ({ title, knownUser, heightClassName, bannerHeightClass, showSearch }: any) => (
    <div data-testid="home-hero">
      <div data-testid="hero-title">{title}</div>
      <div data-testid="hero-banner-title">{knownUser?.bannerTitle ?? ""}</div>
      <div data-testid="hero-username">{knownUser?.userName}</div>
      <div data-testid="hero-show-cards">{String(knownUser?.showCards)}</div>
      <div data-testid="hero-height">{heightClassName}</div>
      <div data-testid="hero-banner-height">{String(bannerHeightClass)}</div>
      <div data-testid="hero-show-search">{String(showSearch)}</div>
    </div>
  ),
}));

vi.mock("@features/landing/components/vehicle-quick-links", () => ({
  VehicleQuickLinksGrid: ({ cardBackgroundColor }: any) => (
    <div data-bg={cardBackgroundColor} data-testid="vehicle-quick-links" />
  ),
}));

vi.mock("@features/my-garage/components/my-garageclient", () => ({
  MyGarageClient: ({
    becauseViewedCars,
    cars,
    daysRemaining,
    hasTradeInSubmitted,
    isPreQualified,
    isFirstTimeVisitor,
    children,
  }: any) => (
    <div data-testid="my-garage-client">
      <div data-testid="mgc-because-viewed-length">{becauseViewedCars?.length ?? 0}</div>
      <div data-testid="mgc-cars-length">{cars?.length ?? 0}</div>
      <div data-testid="mgc-days">{daysRemaining}</div>
      <div data-testid="mgc-trade">{String(hasTradeInSubmitted)}</div>
      <div data-testid="mgc-prequalified">{String(isPreQualified)}</div>
      <div data-testid="mgc-first-time-visitor">{String(isFirstTimeVisitor)}</div>
      <div data-testid="mgc-children">{children}</div>
    </div>
  ),
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Heading: ({ children, level, className, weight }: any) => {
    const Tag = `h${level}` as "h1" | "h2" | "h3" | "h4" | "h5" | "h6";
    return (
      <Tag className={className} data-weight={weight}>
        {children}
      </Tag>
    );
  },
}));

async function renderWrapper(props: Parameters<typeof MyGarageWrapper>[0] = {}) {
  const jsx = await MyGarageWrapper(props);
  return render(jsx as React.ReactElement);
}

describe("MyGarageWrapper", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    flagsState.isPreQualified = false;
    flagsState.hasTradeInSubmitted = false;
    flagsState.firstName = "Jane";
    flagsState.lastName = "Doe";
    flagsState.isAuthenticated = true;
    flagsState.isNewUser = false;
  });

  describe("rendering", () => {
    it("renders HomeHero", async () => {
      await renderWrapper();
      expect(screen.getByTestId("home-hero")).toBeInTheDocument();
    });

    it("renders MyGarageClient", async () => {
      await renderWrapper();
      expect(screen.getByTestId("my-garage-client")).toBeInTheDocument();
    });

    it("renders 'Find your vehicle' heading", async () => {
      await renderWrapper();
      expect(screen.getByRole("heading", { name: FIND_YOUR_VEHICLE_REGEX })).toBeInTheDocument();
    });

    it("renders VehicleQuickLinksGrid with bg-white background", async () => {
      await renderWrapper();
      const grid = screen.getByTestId("vehicle-quick-links");
      expect(grid).toBeInTheDocument();
      expect(grid).toHaveAttribute("data-bg", "bg-white");
    });
  });

  describe("showUserName = false (default)", () => {
    it("does not set bannerTitle (falls back to WELCOME BACK in component)", async () => {
      await renderWrapper();
      expect(screen.getByTestId("hero-banner-title").textContent).toBe("");
    });

    it("passes empty userName to HomeHero", async () => {
      await renderWrapper();
      expect(screen.getByTestId("hero-username").textContent).toBe("");
    });
  });

  describe("showUserName = true", () => {
    it("passes uppercased firstName as userName to HomeHero", async () => {
      flagsState.firstName = "Alice";
      await renderWrapper({ showUserName: true });
      expect(screen.getByTestId("hero-username").textContent).toBe("ALICE");
    });

    it("uppercases firstName for any casing (e.g. lowercase 'bob')", async () => {
      flagsState.firstName = "bob";
      await renderWrapper({ showUserName: true });
      expect(screen.getByTestId("hero-username").textContent).toBe("BOB");
    });
  });

  describe("first-time visitor (isNewUser = true)", () => {
    it("passes bannerTitle='MY GARAGE' to knownUser", async () => {
      flagsState.isNewUser = true;
      await renderWrapper();
      expect(screen.getByTestId("hero-banner-title").textContent).toBe("MY GARAGE");
    });

    it("passes isFirstTimeVisitor=true to MyGarageClient", async () => {
      flagsState.isNewUser = true;
      await renderWrapper();
      expect(screen.getByTestId("mgc-first-time-visitor").textContent).toBe("true");
    });
  });

  describe("known user (isNewUser = false)", () => {
    it("does not set bannerTitle on knownUser", async () => {
      flagsState.isNewUser = false;
      await renderWrapper();
      expect(screen.getByTestId("hero-banner-title").textContent).toBe("");
    });

    it("passes isFirstTimeVisitor=false to MyGarageClient", async () => {
      flagsState.isNewUser = false;
      await renderWrapper();
      expect(screen.getByTestId("mgc-first-time-visitor").textContent).toBe("false");
    });
  });

  describe("knownUser defaults", () => {
    it("sets showCards to false by default", async () => {
      await renderWrapper();
      expect(screen.getByTestId("hero-show-cards").textContent).toBe("false");
    });

    it("forwards knownUserOverrides.showCards=true", async () => {
      await renderWrapper({ knownUserOverrides: { showCards: true } });
      expect(screen.getByTestId("hero-show-cards").textContent).toBe("true");
    });

    it("knownUserOverrides does not affect userName when showUserName=false", async () => {
      await renderWrapper({ knownUserOverrides: { showCards: true } });
      expect(screen.getByTestId("hero-username").textContent).toBe("");
    });
  });

  describe("bannerHeightClass prop", () => {
    it("uses default 'h-[422px] lg:h-90' when not provided", async () => {
      await renderWrapper();
      expect(screen.getByTestId("hero-height").textContent).toBe("h-[422px] lg:h-90");
    });

    it("forwards custom bannerHeightClass as heightClassName to HomeHero", async () => {
      await renderWrapper({ bannerHeightClass: "h-[300px]" });
      expect(screen.getByTestId("hero-height").textContent).toBe("h-[300px]");
    });

    it("always passes bannerHeightClass to HomeHero", async () => {
      await renderWrapper();
      expect(screen.getByTestId("hero-banner-height").textContent).toBe("h-[422px] lg:h-90");
    });
  });

  describe("MyGarageClient prop forwarding", () => {
    it("always passes daysRemaining=27", async () => {
      await renderWrapper();
      expect(screen.getByTestId("mgc-days").textContent).toBe("27");
    });

    it("forwards isPreQualified=false when flag returns false", async () => {
      flagsState.isPreQualified = false;
      await renderWrapper();
      expect(screen.getByTestId("mgc-prequalified").textContent).toBe("false");
    });

    it("forwards isPreQualified=true when flag returns true", async () => {
      flagsState.isPreQualified = true;
      await renderWrapper();
      expect(screen.getByTestId("mgc-prequalified").textContent).toBe("true");
    });

    it("forwards hasTradeInSubmitted=false when flag returns false", async () => {
      flagsState.hasTradeInSubmitted = false;
      await renderWrapper();
      expect(screen.getByTestId("mgc-trade").textContent).toBe("false");
    });

    it("forwards hasTradeInSubmitted=true when flag returns true", async () => {
      flagsState.hasTradeInSubmitted = true;
      await renderWrapper();
      expect(screen.getByTestId("mgc-trade").textContent).toBe("true");
    });
  });

  describe("parallel data fetching", () => {
    it("calls getUserInfo, customerPreQualified, customerTradeInSubmitted, showDefaultLandingHero", async () => {
      const {
        getUserInfo,
        customerPreQualified,
        customerTradeInSubmitted,
        showDefaultLandingHero,
      } = await import("@config/flags/flags");
      const { fetchGarageCars } = await import("@features/my-garage/hooks/fetch-garage-cars");
      const { fetchBecauseYouViewedCars } = await import(
        "@features/my-garage/hooks/fetch-because-viewed-cars"
      );

      await renderWrapper();

      expect(getUserInfo).toHaveBeenCalledOnce();
      expect(customerPreQualified).toHaveBeenCalledOnce();
      expect(customerTradeInSubmitted).toHaveBeenCalledOnce();
      expect(showDefaultLandingHero).toHaveBeenCalledOnce();
      expect(fetchGarageCars).toHaveBeenCalledOnce();
      expect(fetchBecauseYouViewedCars).toHaveBeenCalledOnce();
      expect(screen.getByTestId("mgc-cars-length").textContent).toBe("1");
      expect(screen.getByTestId("mgc-because-viewed-length").textContent).toBe("0");
    });
  });

  describe("children slot", () => {
    it("passes 'Find your vehicle' section as children to MyGarageClient", async () => {
      await renderWrapper();
      const children = screen.getByTestId("mgc-children");
      expect(children.textContent).toContain("Find your vehicle");
    });
  });

  describe("HomeHero static props", () => {
    it("passes showSearch=true to HomeHero", async () => {
      await renderWrapper();
      expect(screen.getByTestId("hero-show-search").textContent).toBe("true");
    });
  });
});
