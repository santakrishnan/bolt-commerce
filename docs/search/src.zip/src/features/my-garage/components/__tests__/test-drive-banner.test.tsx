import { type RenderResult, render, screen } from "@arrow/vitest-config/test-utils";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { TestDriveBanner, type TestDriveBannerProps } from "../test-drive-banner";

interface ComponentElements {
  button: HTMLElement | null;
  description: HTMLElement | null;
  gradientOverlays: Element[];
  heading: HTMLElement | null;
  image: HTMLElement | null;
  section: HTMLElement | null;
}

interface PropsTestConfig {
  buttonText: string;
  description: string;
  imageAlt: string;
  title: string;
}

const DEFAULT_PROPS = {
  TITLE: "SCHEDULE A TEST DRIVE",
  DESCRIPTION:
    "Book a test drive at a time that works for you. Choose your preferred model and we'll have it ready when you arrive.",
  BUTTON_TEXT: "Book Your Test Drive",
  IMAGE_ALT: "Car rear view for test drive banner",
  IMAGE_SRC: "/images/vehicle-toyota/car6.png",
} as const;

const CUSTOM_PROPS: PropsTestConfig = {
  title: "Custom Test Drive Title",
  description: "Custom description text for test drive scheduling",
  buttonText: "Schedule Now",
  imageAlt: "Custom alt text",
} as const;

const SELECTORS = {
  SECTION: "section",
  HEADING: "h2",
  DESCRIPTION: "p",
  BUTTON: "button",
  IMAGE: "img",
  GRADIENT_DESKTOP: '[class*="linear-gradient(90deg"]',
  GRADIENT_MOBILE: '[class*="linear-gradient(to_top"]',
} as const;

const ARIA_ROLES = {
  HEADING: "heading",
  BUTTON: "button",
  IMG: "img",
} as const;

vi.mock("next/image", () => ({
  __esModule: true,
  default: ({ src, alt, className, draggable, fill, sizes, ...props }: any) => (
    <div
      aria-label={alt}
      className={className}
      data-alt={alt}
      data-fill={fill}
      data-src={src || "/images/vehicle-toyota/car6.png"}
      data-testid="mock-image"
      draggable={draggable}
      role="img"
      sizes={sizes}
      {...props}
    />
  ),
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Heading: ({
    children,
    level,
    className,
    weight,
  }: {
    children: React.ReactNode;
    level: number;
    className?: string;
    weight?: string;
  }) => {
    if (level === 2) {
      return (
        <h2 className={className} data-weight={weight}>
          {children}
        </h2>
      );
    }
    if (level === 3) {
      return (
        <h3 className={className} data-weight={weight}>
          {children}
        </h3>
      );
    }
    if (level === 4) {
      return (
        <h4 className={className} data-weight={weight}>
          {children}
        </h4>
      );
    }
    if (level === 5) {
      return (
        <h5 className={className} data-weight={weight}>
          {children}
        </h5>
      );
    }
    if (level === 6) {
      return (
        <h6 className={className} data-weight={weight}>
          {children}
        </h6>
      );
    }
    return (
      <h1 className={className} data-weight={weight}>
        {children}
      </h1>
    );
  },
}));

vi.mock("@shared/components/button", () => ({
  AppButton: ({
    children,
    onClick,
    className,
    variant,
  }: {
    children: React.ReactNode;
    onClick?: () => void;
    className?: string;
    variant?: string;
  }) => (
    <button className={className} data-variant={variant} onClick={onClick} type="button">
      {children}
    </button>
  ),
}));

/** Renders TestDriveBanner and returns the result alongside key queried DOM elements. */
const renderTestDriveBanner = (
  props: Partial<TestDriveBannerProps> = {}
): RenderResult & ComponentElements => {
  const result = render(<TestDriveBanner {...props} />);
  const { container } = result;

  return {
    ...result,
    section: container.querySelector(SELECTORS.SECTION),
    heading: screen.queryByRole(ARIA_ROLES.HEADING, { level: 2 }),
    description: container.querySelector(SELECTORS.DESCRIPTION),
    button: screen.queryByRole(ARIA_ROLES.BUTTON),
    image: screen.queryByRole(ARIA_ROLES.IMG),
    gradientOverlays: Array.from(container.querySelectorAll('[class*="linear-gradient"]')),
  };
};

/** Returns the root section element from the rendered container. */
const getSection = (container: HTMLElement): HTMLElement | null => {
  return container.querySelector(SELECTORS.SECTION);
};

/** Returns all elements with a Tailwind linear-gradient class from the container. */
const getGradientOverlays = (container: HTMLElement): Element[] => {
  return Array.from(container.querySelectorAll('[class*="linear-gradient"]'));
};

/** Convenience wrapper around renderTestDriveBanner for use in all test cases. */
const renderComponent = (props?: Partial<TestDriveBannerProps>) => renderTestDriveBanner(props);

// Tests cover rendering, props, styling, interactions, and accessibility

describe("TestDriveBanner Component", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Rendering", () => {
    it("renders a semantic section element", () => {
      const { section } = renderComponent();

      expect(section).toBeInTheDocument();
    });

    it("renders the heading with default title", () => {
      const { heading } = renderComponent();

      expect(heading).toBeInTheDocument();
      expect(heading).toHaveTextContent(DEFAULT_PROPS.TITLE);
    });

    it("renders the description with default text", () => {
      const { description } = renderComponent();

      expect(description).toBeInTheDocument();
      expect(description).toHaveTextContent(DEFAULT_PROPS.DESCRIPTION);
    });

    it("renders a button with default text", () => {
      const { button } = renderComponent();

      expect(button).toBeInTheDocument();
      expect(button).toHaveTextContent(DEFAULT_PROPS.BUTTON_TEXT);
    });

    it("renders an image with default alt text", () => {
      const { image } = renderComponent();

      expect(image).toBeInTheDocument();
      expect(image).toHaveAttribute("aria-label", DEFAULT_PROPS.IMAGE_ALT);
    });

    it("renders gradient overlays for visual effect", () => {
      const { gradientOverlays } = renderComponent();

      expect(gradientOverlays.length).toBeGreaterThan(0);
    });
  });

  describe("Props Handling", () => {
    describe("title prop", () => {
      it("displays custom title when provided", () => {
        const { heading } = renderComponent({ title: CUSTOM_PROPS.title });

        expect(heading).toHaveTextContent(CUSTOM_PROPS.title);
      });

      it("uses default title when not provided", () => {
        const { heading } = renderComponent();

        expect(heading).toHaveTextContent(DEFAULT_PROPS.TITLE);
      });
    });

    describe("description prop", () => {
      it("displays custom description when provided", () => {
        const { description } = renderComponent({ description: CUSTOM_PROPS.description });

        expect(description).toHaveTextContent(CUSTOM_PROPS.description);
      });

      it("uses default description when not provided", () => {
        const { description } = renderComponent();

        expect(description).toHaveTextContent(DEFAULT_PROPS.DESCRIPTION);
      });
    });

    describe("buttonText prop", () => {
      it("displays custom button text when provided", () => {
        const { button } = renderComponent({ buttonText: CUSTOM_PROPS.buttonText });

        expect(button).toHaveTextContent(CUSTOM_PROPS.buttonText);
      });

      it("uses default button text when not provided", () => {
        const { button } = renderComponent();

        expect(button).toHaveTextContent(DEFAULT_PROPS.BUTTON_TEXT);
      });
    });

    describe("imageAlt prop", () => {
      it("uses custom alt text when provided", () => {
        const { image } = renderComponent({ imageAlt: CUSTOM_PROPS.imageAlt });

        expect(image).toHaveAttribute("aria-label", CUSTOM_PROPS.imageAlt);
      });

      it("uses default alt text when not provided", () => {
        const { image } = renderComponent();

        expect(image).toHaveAttribute("aria-label", DEFAULT_PROPS.IMAGE_ALT);
      });
    });

    describe("onButtonClick prop", () => {
      it("calls the callback when button is clicked", () => {
        const onButtonClick = vi.fn();
        const { button } = renderComponent({ onButtonClick });

        button?.click();

        expect(onButtonClick).toHaveBeenCalledTimes(1);
      });

      it("does not throw error when callback is not provided", () => {
        const { button } = renderComponent();

        expect(() => button?.click()).not.toThrow();
      });

      it("calls the callback multiple times on multiple clicks", () => {
        const onButtonClick = vi.fn();
        const { button } = renderComponent({ onButtonClick });

        button?.click();
        button?.click();
        button?.click();

        expect(onButtonClick).toHaveBeenCalledTimes(3);
      });
    });
  });

  describe("Layout", () => {
    it("applies responsive height classes to section", () => {
      const { section } = renderComponent();

      expect(section?.className).toContain("h-auto");
      expect(section?.className).toContain("lg:h-");
    });

    it("applies flex direction classes for responsive layout", () => {
      const { section } = renderComponent();

      expect(section?.className).toContain("flex-col");
      expect(section?.className).toContain("md:flex-row");
    });

    it("applies background color to section", () => {
      const { section } = renderComponent();

      expect(section).toHaveClass("bg-black");
    });

    it("uses flex layout for content arrangement", () => {
      const { section } = renderComponent();

      expect(section).toHaveClass("flex");
    });

    it("applies overflow hidden to prevent scroll", () => {
      const { section } = renderComponent();

      expect(section).toHaveClass("overflow-hidden");
    });
  });

  describe("Gradient Overlays", () => {
    it("renders desktop gradient overlay", () => {
      const { container } = renderComponent();
      const gradients = getGradientOverlays(container);

      const hasDesktopGradient = gradients.some((el) => {
        const className = el.getAttribute("class") ?? "";
        return (
          className.includes("linear-gradient(90deg") ||
          className.includes("linear-gradient(90deg".replace("(", "("))
        );
      });

      expect(hasDesktopGradient).toBe(true);
    });

    it("renders mobile gradient overlay", () => {
      const { container } = renderComponent();
      const gradients = getGradientOverlays(container);

      const hasMobileGradient = gradients.some((el) => {
        const className = el.getAttribute("class") ?? "";
        return (
          className.includes("linear-gradient(to_top") ||
          className.includes("linear-gradient(to top")
        );
      });

      expect(hasMobileGradient).toBe(true);
    });

    it("applies pointer-events-none to gradient overlays", () => {
      const { gradientOverlays } = renderComponent();

      for (const overlay of gradientOverlays) {
        expect(overlay.classList.contains("pointer-events-none")).toBe(true);
      }
    });
  });

  describe("Image Configuration", () => {
    it("uses correct image source", () => {
      const { image } = renderComponent();

      expect(image).toHaveAttribute("data-src", DEFAULT_PROPS.IMAGE_SRC);
    });

    it("applies fill layout to image", () => {
      const { image } = renderComponent();

      expect(image).toBeInTheDocument();
    });

    it("sets image as non-draggable", () => {
      const { image } = renderComponent();

      expect(image).toHaveAttribute("draggable", "false");
    });

    it("applies object-cover and object-center classes", () => {
      const { image } = renderComponent();

      expect(image).toHaveClass("object-cover", "object-center");
    });

    it("applies responsive object positioning", () => {
      const { image } = renderComponent();

      expect(image).toHaveClass("md:object-right");
    });

    it("includes responsive sizes attribute for optimization", () => {
      const { image } = renderComponent();

      expect(image).toHaveAttribute("sizes", "(max-width: 768px) 100vw, 50vw");
    });
  });

  describe("Responsive Design", () => {
    it("applies responsive padding to content area", () => {
      const { container } = renderComponent();
      const contentArea = container.querySelector(".z-20");

      expect(contentArea?.className).toContain("px-");
      expect(contentArea?.className).toContain("lg:px-");
    });

    it("applies responsive width classes to content area", () => {
      const { container } = renderComponent();
      const contentArea = container.querySelector(".z-20");

      expect(contentArea?.className).toContain("md:w-");
    });

    it("applies responsive height classes to image wrapper", () => {
      const { container } = renderComponent();
      const imageWrapper = container.querySelector('[class*="h-[280px]"]');

      expect(imageWrapper).toBeInTheDocument();
      expect(imageWrapper?.className).toContain("sm:h-");
    });

    it("shows/hides gradient overlays based on breakpoint classes", () => {
      const { container } = renderComponent();
      const gradients = getGradientOverlays(container);

      expect(gradients.length).toBeGreaterThanOrEqual(2);
    });
  });

  describe("Accessibility", () => {
    it("uses semantic section element", () => {
      const { section } = renderComponent();

      expect(section?.tagName).toBe("SECTION");
    });

    it("uses proper heading hierarchy with h2", () => {
      const { heading } = renderComponent();

      expect(heading?.tagName).toBe("H2");
    });

    it("provides descriptive alt text for image", () => {
      const { image } = renderComponent();

      expect(image).toHaveAttribute("aria-label");
      expect(image?.getAttribute("aria-label")).not.toBe("");
    });

    it("button is keyboard accessible", () => {
      const { button } = renderComponent();

      expect(button?.tagName).toBe("BUTTON");
    });

    it("heading has appropriate text styling for readability", () => {
      const { heading } = renderComponent();

      expect(heading?.className).toContain("text-[");
    });

    it("description has appropriate contrast with background", () => {
      const { description } = renderComponent();

      expect(description).toHaveClass("text-primary-foreground/80");
    });
  });

  describe("Button Interactions", () => {
    it("button has primary variant styling", () => {
      const { button } = renderComponent();

      expect(button).toHaveAttribute("data-variant", "primary");
    });

    it("button has appropriate padding and text size", () => {
      const { button } = renderComponent();

      expect(button).toHaveClass("px-5", "py-2", "text-sm");
    });

    it("button has w-fit width class", () => {
      const { button } = renderComponent();

      expect(button?.className).toContain("w-fit");
    });

    it("handles rapid button clicks correctly", () => {
      const onButtonClick = vi.fn();
      const { button } = renderComponent({ onButtonClick });

      for (let i = 0; i < 5; i++) {
        button?.click();
      }

      expect(onButtonClick).toHaveBeenCalledTimes(5);
    });

    it("button has correct type attribute", () => {
      const { button } = renderComponent();

      expect(button).toHaveAttribute("type", "button");
    });

    it("button click invokes callback with no arguments", () => {
      const onButtonClick = vi.fn();
      const { button } = renderComponent({ onButtonClick });

      button?.click();

      expect(onButtonClick).toHaveBeenCalledWith();
    });
  });

  describe("Edge Cases", () => {
    it("handles empty string title", () => {
      const { heading } = renderComponent({ title: "" });

      expect(heading).toBeInTheDocument();
      expect(heading).toHaveTextContent("");
    });

    it("handles empty string description", () => {
      const { description } = renderComponent({ description: "" });

      expect(description).toBeInTheDocument();
      expect(description).toHaveTextContent("");
    });

    it("handles empty string button text", () => {
      const { button } = renderComponent({ buttonText: "" });

      expect(button).toBeInTheDocument();
      expect(button).toHaveTextContent("");
    });

    it("handles very long title text", () => {
      const longTitle = "A".repeat(200);
      const { heading } = renderComponent({ title: longTitle });

      expect(heading).toHaveTextContent(longTitle);
    });

    it("handles very long description text", () => {
      const longDescription = "A".repeat(500);
      const { description } = renderComponent({ description: longDescription });

      expect(description).toHaveTextContent(longDescription);
    });

    it("handles undefined callback gracefully", () => {
      const { button } = renderComponent({ onButtonClick: undefined });

      expect(() => button?.click()).not.toThrow();
    });

    it("renders correctly with all custom props", () => {
      const onButtonClick = vi.fn();
      const { heading, description, button, image } = renderComponent({
        ...CUSTOM_PROPS,
        onButtonClick,
      });

      expect(heading).toHaveTextContent(CUSTOM_PROPS.title);
      expect(description).toHaveTextContent(CUSTOM_PROPS.description);
      expect(button).toHaveTextContent(CUSTOM_PROPS.buttonText);
      expect(image).toHaveAttribute("aria-label", CUSTOM_PROPS.imageAlt);

      button?.click();
      expect(onButtonClick).toHaveBeenCalled();
    });
  });

  describe("Content Structure", () => {
    it("renders content and image in correct order", () => {
      const { container } = renderComponent();
      const section = getSection(container);
      const children = section?.children;

      expect(children && children.length > 0).toBe(true);
    });

    it("wraps content in max-width container", () => {
      const { container } = renderComponent();
      const centeredContainer = container.querySelector(".mx-auto");

      expect(centeredContainer).toBeTruthy();
      expect(centeredContainer?.className).toContain("mx-auto");
    });

    it("applies z-index layering correctly", () => {
      const { container } = renderComponent();
      const gradientOverlay = container.querySelector(".z-10");
      const contentArea = container.querySelector(".z-20");

      expect(gradientOverlay).toBeInTheDocument();
      expect(contentArea).toBeInTheDocument();
    });

    it("applies flex-col-reverse on mobile for content ordering", () => {
      const { container } = renderComponent();
      const innerContainer = container.querySelector('[class*="flex-col-reverse"]');

      expect(innerContainer).toBeInTheDocument();
      expect(innerContainer?.classList.contains("md:flex-row")).toBe(true);
    });

    it("content area has shrink-0 to prevent unwanted shrinking", () => {
      const { container } = renderComponent();
      const contentArea = container.querySelector(".z-20");

      expect(contentArea?.className).toContain("shrink-0");
    });

    it("image wrapper has responsive shrink classes", () => {
      const { container } = renderComponent();
      const imageWrapper = container.querySelector('[class*="h-[280px]"]');

      expect(imageWrapper?.className).toContain("shrink");
    });
  });

  describe("Typography", () => {
    it("heading has text styling classes", () => {
      const { heading } = renderComponent();

      expect(heading?.className).toContain("text-");
    });

    it("heading has responsive behavior", () => {
      const { heading } = renderComponent();

      expect(heading?.className).toContain("xl:text-nowrap");
    });

    it("description has text styling", () => {
      const { description } = renderComponent();

      expect(description?.className).toContain("text-");
    });
  });

  describe("Container Classes", () => {
    it("content area has padding classes", () => {
      const { container } = renderComponent();
      const contentArea = container.querySelector(".z-20");

      expect(contentArea?.className).toContain("py-");
      expect(contentArea?.className).toContain("px-");
    });

    it("content area has width constraints", () => {
      const { container } = renderComponent();
      const contentArea = container.querySelector(".z-20");

      expect(contentArea?.className).toContain("md:w-");
    });

    it("image wrapper has width constraints", () => {
      const { container } = renderComponent();
      const imageWrapper = container.querySelector('[class*="h-[280px]"]');

      expect(imageWrapper?.className).toContain("md:w-");
    });

    it("image wrapper has height constraints", () => {
      const { container } = renderComponent();
      const imageWrapper = container.querySelector('[class*="h-[280px]"]');

      expect(imageWrapper?.className).toContain("md:min-h-");
    });
  });
});
