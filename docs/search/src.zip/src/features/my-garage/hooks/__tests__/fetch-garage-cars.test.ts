/**
 * @vitest-environment jsdom
 */

import type { Vehicle } from "@shared/types";
import { describe, expect, it, vi } from "vitest";

const mockBestMatches: Vehicle[] = [
  {
    id: 1,
    vin: "VIN001",
    title: "2024 Toyota Camry",
    make: "Toyota",
    model: "Camry",
    variant: "XSE",
    year: 2024,
    price: 32_000,
    odometer: "12,345 mi",
    miles: "Toyota of Fort Worth - 6.1mi",
    image: "/images/camry.jpg",
    labels: [],
    match: 0,
    owners: 1,
    bodyType: "Sedan",
    drivetrain: "FWD",
    fuelType: "Gasoline",
    transmission: "Automatic",
    extColorCode: "#FFFFFF",
    extColorName: "White",
    intColorCode: "#000000",
    intColorName: "Black",
    mileage: 12_345,
    inspection160: true,
    seatingCapacity: ["5"],
    features: { comfort: [], exterior: [], performance: [], safety: [], tech: [] },
    warranty: false,
    dealerId: "toyota-plano",
    dealerLocation: "Plano, TX 75001",
    dealerName: "Toyota of Plano",
    mpg: "28-39",
    stock: "STK00001",
  },
];

vi.mock("@features/my-garage/services/my-garage.service", () => ({
  getMyGarageData: vi.fn(async () => ({
    bestMatches: mockBestMatches,
    becauseYouViewed: [],
    becauseYouViewedLabel: "Toyota Camry",
    recentPriceDrop: [],
  })),
}));

import { fetchGarageCars } from "../fetch-garage-cars";

describe("fetchGarageCars (deprecated — delegates to service)", () => {
  it("returns bestMatches from getMyGarageData", async () => {
    const result = await fetchGarageCars();
    expect(result).toEqual(mockBestMatches);
  });

  it("returns an array of Vehicle objects", async () => {
    const result = await fetchGarageCars();
    expect(Array.isArray(result)).toBe(true);
    for (const vehicle of result) {
      expect(vehicle).toHaveProperty("vin");
      expect(vehicle).toHaveProperty("title");
      expect(vehicle).toHaveProperty("price");
    }
  });
});
