import type { Vehicle } from "@shared/types";
import { describe, expect, it, vi } from "vitest";

const mockBecauseViewed: Vehicle[] = [
  {
    id: 1,
    vin: "VIN001",
    title: "2023 Toyota Corolla Cross",
    make: "toyota",
    model: "corolla-cross",
    variant: "le",
    year: 2023,
    price: 31_250,
    odometer: "18,000mi",
    miles: "Toyota of Fort Worth - 6.1mi",
    image: "/images/corolla-cross.png",
    labels: [],
    match: 88,
    owners: 1,
    bodyType: "SUV",
    drivetrain: "FWD",
    fuelType: "Gasoline",
    transmission: "CVT",
    extColorCode: "#E8E6E1",
    extColorName: "Wind Chill Pearl",
    intColorCode: "#1C1C1C",
    intColorName: "Black SofTex",
    mileage: 18_000,
    inspection160: true,
    seatingCapacity: ["5"],
    features: { comfort: [], exterior: [], performance: [], safety: [], tech: [] },
    warranty: true,
    dealerId: "dealer-fort-worth",
    dealerLocation: "Fort Worth, TX 76116",
    dealerName: "Toyota of Fort Worth",
    mpg: "29-32",
    stock: "CC23001",
  },
];

vi.mock("@features/my-garage/services/my-garage.service", () => ({
  getMyGarageData: vi.fn(async () => ({
    bestMatches: [],
    becauseYouViewed: mockBecauseViewed,
    becauseYouViewedLabel: "Toyota Camry",
    recentPriceDrop: [],
  })),
}));

import { fetchBecauseYouViewedCars } from "../fetch-because-viewed-cars";

describe("fetchBecauseYouViewedCars (deprecated — delegates to service)", () => {
  it("returns becauseYouViewed from getMyGarageData", async () => {
    const result = await fetchBecauseYouViewedCars();
    expect(result).toEqual(mockBecauseViewed);
  });

  it("returns an array of Vehicle objects", async () => {
    const result = await fetchBecauseYouViewedCars();
    expect(Array.isArray(result)).toBe(true);
    for (const vehicle of result) {
      expect(vehicle).toHaveProperty("vin");
      expect(vehicle).toHaveProperty("title");
      expect(vehicle).toHaveProperty("price");
    }
  });
});
