import { render, screen } from "@testing-library/react";
import React from "react";
import { describe, expect, it, vi } from "vitest";

vi.mock("@tfs-ucmp/ui", () => {
  const makeIcon = (name: string) => (props: any) =>
    React.createElement("span", { "data-icon": name, "data-size": props?.size ?? "" });

  return {
    __esModule: true,
    Heading: (props: any) => React.createElement("div", { "data-heading": true }, props.children),
    cn: (...args: any[]) => args.filter(Boolean).join(" "),
    EngineIcon: makeIcon("EngineIcon"),
    ColorsIcon: makeIcon("ColorsIcon"),
    MPGIcon: makeIcon("MPGIcon"),
    FuelTypeIcon: makeIcon("FuelTypeIcon"),
    MileageIcon: makeIcon("MileageIcon"),
    MarkerPinIcon: makeIcon("MarkerPinIcon"),
    BatteryIcon: makeIcon("BatteryIcon"),
    TransmissionIcon: makeIcon("TransmissionIcon"),
  };
});

vi.mock("@shared/components/button", () => ({
  __esModule: true,
  AppButton: (props: any) =>
    React.createElement("button", { "data-testid": "app-button", type: "button" }, props.children),
}));

import { OverviewTab } from "../overview-tab";

const SAMPLE_SPECS = [
  { key: "engine", label: "Engine", value: "2.0L" },
  { key: "mpg", label: "MPG", value: "28" },
  { key: "mileage", label: "Mileage", value: "12k" },
  { key: "location", label: "Location", value: "NY" },
  { key: "fuel-type", label: "Fuel", value: "Gas" },
  { key: "transmission", label: "Transmission", value: "Auto" },
];

describe("OverviewTab", () => {
  it("renders header, action button and all specs with icons and values", () => {
    render(<OverviewTab specs={SAMPLE_SPECS as any} />);

    // Header and action
    expect(screen.getByText("Overview")).toBeInTheDocument();
    expect(screen.getByTestId("app-button")).toHaveTextContent("View All Specs");

    // Each spec label and value are rendered (mobile + desktop markup may duplicate)
    for (const s of SAMPLE_SPECS) {
      const labels = screen.getAllByText(s.label);
      expect(labels.length).toBeGreaterThan(0);
      const values = screen.getAllByText(s.value);
      expect(values.length).toBeGreaterThan(0);
    }

    // Ensure at least one icon for mapped keys is present
    expect(document.querySelector('span[data-icon="EngineIcon"]')).toBeTruthy();
    expect(document.querySelector('span[data-icon="MPGIcon"]')).toBeTruthy();
    expect(document.querySelector('span[data-icon="MarkerPinIcon"]')).toBeTruthy();
  });
});
