import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { DealerInfoCard } from "../dealer-info-card";

vi.mock("next/image", () => ({
  default: ({ alt, src }: any) => <span aria-label={alt} data-src={src} role="img" />,
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Card: ({ children, className }: any) => <div className={className}>{children}</div>,
  CardContent: ({ children, className }: any) => <div className={className}>{children}</div>,
  Heading: ({ children, level, weight, className }: any) => (
    <div className={className} data-level={level} data-weight={weight}>
      {children}
    </div>
  ),
  StarIcon: () => <span>★</span>,
  cn: (...args: any[]) => args.filter(Boolean).join(" "),
}));

vi.mock("@shared/components/button", () => ({
  AppButton: ({ children, size, variant }: any) => (
    <button data-size={size} data-variant={variant} type="button">
      {children}
    </button>
  ),
}));

describe("DealerInfoCard", () => {
  const mockDealer = {
    id: "dealer-1",
    name: "John's Toyota",
    rating: 4.5,
    reviewCount: 120,
    dealershipImage: "https://example.com/dealer.jpg",
    timeZone: "EST",
    phone: "555-1234",
    hours: "9AM - 6PM",
    address: "123 Main St",
  };

  it("renders dealer name", () => {
    render(<DealerInfoCard dealer={mockDealer} />);

    expect(screen.getByText("John's Toyota")).toBeInTheDocument();
  });

  it("renders dealer image", () => {
    render(<DealerInfoCard dealer={mockDealer} />);

    const image = screen.getByRole("img", { name: "John's Toyota" });
    expect(image).toBeInTheDocument();
    expect(image).toHaveAttribute("data-src", "https://example.com/dealer.jpg");
  });

  it("renders star icons based on rating", () => {
    render(<DealerInfoCard dealer={mockDealer} />);

    const stars = screen.getAllByText("★");
    expect(stars.length).toBeGreaterThan(0);
  });

  it("uses a gap-aware fill width for fractional dealer ratings", () => {
    const { container } = render(<DealerInfoCard dealer={mockDealer} />);

    const filledStars = container.querySelector('[role="img"] > div.absolute');
    expect(filledStars).toHaveStyle("width: calc(4.5 * var(--spacing-sm) * 1.5 + 4 * 0.125rem)");
  });

  it("renders review count", () => {
    render(<DealerInfoCard dealer={mockDealer} />);

    expect(screen.getByText("View Reviews")).toBeInTheDocument();
  });

  it("renders dealer hours", () => {
    render(<DealerInfoCard dealer={mockDealer} />);

    expect(screen.getByText("9AM - 6PM")).toBeInTheDocument();
  });

  it("renders dealer address", () => {
    render(<DealerInfoCard dealer={mockDealer} />);

    expect(screen.getByText("123 Main St")).toBeInTheDocument();
  });

  it("renders phone number", () => {
    render(<DealerInfoCard dealer={mockDealer} />);

    expect(screen.getByText("555-1234")).toBeInTheDocument();
  });

  it("renders contact button", () => {
    render(<DealerInfoCard dealer={mockDealer} />);

    const buttons = screen.getAllByRole("button");
    expect(buttons.length).toBeGreaterThan(0);
  });

  it("applies custom className", () => {
    const customClass = "custom-dealer-card";
    const { container } = render(<DealerInfoCard className={customClass} dealer={mockDealer} />);

    expect(container.textContent).toBeDefined();
  });

  it("renders all dealer information together", () => {
    render(<DealerInfoCard dealer={mockDealer} />);

    expect(screen.getByText("John's Toyota")).toBeInTheDocument();
    expect(screen.getByText("9AM - 6PM")).toBeInTheDocument();
    expect(screen.getByText("123 Main St")).toBeInTheDocument();
  });

  it("handles dealer with no review count", () => {
    const dealerNoReviews = { ...mockDealer, reviewCount: 0 };
    render(<DealerInfoCard dealer={dealerNoReviews} />);

    expect(screen.getByText("John's Toyota")).toBeInTheDocument();
  });
});
