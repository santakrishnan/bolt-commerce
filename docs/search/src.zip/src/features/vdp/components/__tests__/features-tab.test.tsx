import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { FeaturesTab } from "../features-tab";

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({ children, ...rest }: any) => <button {...rest}>{children}</button>,
  Heading: ({ children }: any) => <div>{children}</div>,
  VectorRightOutlineIcon: () => <span data-testid="icon" />,
  cn: (...args: any[]) => args.filter(Boolean).join(" "),
}));

const TOGGLE_REGEX = /View All Features|View Less/;

describe("FeaturesTab", () => {
  const makeCategory = (name: string, features: string[]) => ({ name, features });

  it("renders heading and categories when count <= initialCount (no toggle)", () => {
    const categories = [
      makeCategory("Category A", ["f1", "f2"]),
      makeCategory("Category B", ["f3"]),
    ];

    render(<FeaturesTab features={categories} initialCount={4} />);

    expect(screen.getByText("Key Features")).toBeInTheDocument();
    expect(screen.getByText("Category A")).toBeInTheDocument();
    expect(screen.getByText("Category B")).toBeInTheDocument();
    expect(screen.queryByText(TOGGLE_REGEX)).toBeNull();
  });

  it("shows toggle when categories > initialCount and toggles expanded state", () => {
    const categories = Array.from({ length: 6 }, (_, i) => makeCategory(`C${i + 1}`, ["a", "b"]));

    render(<FeaturesTab features={categories} initialCount={4} />);

    const buttons = screen.getAllByRole("button");
    expect(buttons.length).toBeGreaterThanOrEqual(1);
    const button = buttons[0] as Element;
    expect(button).toBeInTheDocument();
    expect(button).toHaveTextContent("View All Features");

    fireEvent.click(button);
    expect(button).toHaveTextContent("View Less");
  });

  it("renders 'No features listed' for empty category and fallback when no categories", () => {
    const categories = [makeCategory("EmptyCat", [])];
    render(<FeaturesTab features={categories} initialCount={4} />);
    expect(screen.getByText("No features listed")).toBeInTheDocument();

    render(<FeaturesTab features={[]} initialCount={4} />);
    expect(screen.getAllByText("No features listed").length).toBeGreaterThanOrEqual(1);
  });
});
