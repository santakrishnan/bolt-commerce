"use client";

import { API_ROUTES } from "@config/routes";
import { AppButton } from "@shared/components/button";
import { Checkbox, Input, Label } from "@tfs-ucmp/ui";
import Image from "next/image";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";

function useAutoClearError(delay = 5000) {
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!error) {
      return;
    }
    const t = setTimeout(() => setError(null), delay);
    return () => clearTimeout(t);
  }, [error, delay]);

  return [error, setError] as const;
}

function FlexDivider() {
  return <hr className="flex-1 border-[var(--color-structure-interaction-subtle-border)]" />;
}

const INPUT_STYLES =
  "bg-[var(--color-core-surfaces-background)] text-[color:var(--color-core-surfaces-foreground)] rounded-[var(--radius-md)] border-0 shadow-none focus:border focus:border-[var(--color-core-surfaces-foreground)] focus-visible:outline-none focus-visible:ring-0 placeholder:text-[color:var(--color-states-muted-foreground)] mb-0 h-[var(--spacing-2xl)] px-[var(--spacing-md)] py-0";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const LETTER_REGEX = /[a-zA-Z]/;
const NUMBER_REGEX = /[0-9]/;
const SPECIAL_CHAR_REGEX = /[^a-zA-Z0-9]/;

function validateEmail(email: string): string | null {
  if (!email) {
    return "Email is required.";
  }
  if (!EMAIL_REGEX.test(email)) {
    return "Please enter a valid email address.";
  }
  return null;
}

function validatePassword(password: string): string | null {
  if (!password) {
    return "Password is required.";
  }
  if (password.length <= 8) {
    return "Password must be more than 8 characters.";
  }
  if (!LETTER_REGEX.test(password)) {
    return "Password must contain at least one letter.";
  }
  if (!NUMBER_REGEX.test(password)) {
    return "Password must contain at least one number.";
  }
  if (!SPECIAL_CHAR_REGEX.test(password)) {
    return "Password must contain at least one special character.";
  }
  return null;
}

function validateConfirmPassword(password: string, confirmPassword: string): string | null {
  if (!confirmPassword) {
    return "Please confirm your password.";
  }
  if (password !== confirmPassword) {
    return "Passwords do not match.";
  }
  return null;
}

function validateTerms(termsChecked: boolean): string | null {
  if (!termsChecked) {
    return "You must agree to the Terms of Service and Privacy Policy.";
  }
  return null;
}

interface ValidationError {
  field: "name" | "form" | "confirmPassword" | "terms";
  message: string;
}

function getSignupValidationError(
  nameVal: string,
  emailVal: string,
  passwordVal: string,
  confirmPasswordVal: string,
  termsVal: boolean
): ValidationError | null {
  if (!nameVal) {
    return { field: "name", message: "Name is required." };
  }
  const emailErr = validateEmail(emailVal);
  if (emailErr) {
    return { field: "form", message: emailErr };
  }
  const passwordErr = validatePassword(passwordVal);
  if (passwordErr) {
    return { field: "form", message: passwordErr };
  }
  const confirmErr = validateConfirmPassword(passwordVal, confirmPasswordVal);
  if (confirmErr) {
    return { field: "confirmPassword", message: confirmErr };
  }
  const termsErr = validateTerms(termsVal);
  if (termsErr) {
    return { field: "terms", message: termsErr };
  }
  return null;
}

export default function CreateAccountWrapper() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [termsChecked, setTermsChecked] = useState(false);
  const [nameError, setNameError] = useAutoClearError();
  const [formError, setFormError] = useAutoClearError();
  const [confirmPasswordError, setConfirmPasswordError] = useAutoClearError();
  const [termsError, setTermsError] = useAutoClearError();
  const isSubmitting = useRef(false);

  const allFilled =
    name.trim() !== "" &&
    email.trim() !== "" &&
    password !== "" &&
    confirmPassword !== "" &&
    termsChecked;

  const handleFormSubmit = async (ev: React.FormEvent<HTMLFormElement>) => {
    if (isSubmitting.current) {
      return;
    }
    ev.preventDefault();
    isSubmitting.current = true;
    setFormError(null);
    setConfirmPasswordError(null);

    const nameVal = name.trim();
    const emailVal = email.trim();
    const validationErr = getSignupValidationError(
      nameVal,
      emailVal,
      password,
      confirmPassword,
      termsChecked
    );
    if (validationErr) {
      if (validationErr.field === "name") {
        setNameError(validationErr.message);
      } else if (validationErr.field === "confirmPassword") {
        setConfirmPasswordError(validationErr.message);
      } else if (validationErr.field === "terms") {
        setTermsError(validationErr.message);
      } else {
        setFormError(validationErr.message);
      }
      isSubmitting.current = false;
      return;
    }

    try {
      await fetch(API_ROUTES.SIGN_UP, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: nameVal, email: emailVal, password }),
      });
    } catch (err) {
      console.error("Signup failed:", err);
      setFormError("Signup failed. Please try again.");
    } finally {
      isSubmitting.current = false;
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center bg-black py-[var(--spacing-2xl)] sm:py-[var(--spacing-4xl)]">
      <Image
        alt=""
        aria-hidden="true"
        className="absolute inset-0 object-cover"
        fill
        src="/images/Sign-up-bg.svg"
      />
      <div className="relative z-10 mx-[var(--spacing-md)] flex w-full max-w-md flex-col gap-[var(--spacing-xl)] rounded-[var(--radius-lg)] bg-[var(--color-core-surfaces-card)] px-[var(--spacing-lg)] py-[var(--spacing-xl)]">
        <div className="flex items-center justify-center gap-[var(--spacing-3)]">
          <div aria-hidden="true" className="h-10 w-10 bg-icon-primary" />
          <span className="font-bold font-sans text-base uppercase leading-normal">ARROW</span>
        </div>

        <FlexDivider />

        <h3 className="text-center font-sans font-semibold text-2xl text-[color:var(--color-core-surfaces-foreground)] leading-[115%]">
          Create Your Account
        </h3>

        <div className="flex flex-col gap-[var(--spacing-lg)]">
          <div>
            <div className="flex flex-col gap-[var(--spacing-xs)]">
              <Label
                className="font-normal text-[color:var(--color-states-muted-foreground)] text-sm leading-[125%] tracking-[0.01em]"
                htmlFor="name"
              >
                Name
              </Label>
              <Input
                className={INPUT_STYLES}
                id="name"
                name="name"
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your name"
                type="text"
                value={name}
              />
            </div>
            <div
              aria-live="polite"
              className={`mt-[var(--spacing-2xs)] text-[color:var(--color-destructive)] text-xs transition-opacity duration-300 ${
                nameError ? "opacity-100" : "pointer-events-none opacity-0"
              }`}
            >
              {nameError}
            </div>
          </div>

          <div>
            <form onSubmit={handleFormSubmit}>
              <div className="grid gap-[var(--spacing-lg)]">
                <div className="grid gap-[var(--spacing-xs)]">
                  <Label
                    className="font-normal text-[color:var(--color-states-muted-foreground)] text-sm leading-[125%] tracking-[0.01em]"
                    htmlFor="email"
                  >
                    Email
                  </Label>
                  <Input
                    className={INPUT_STYLES}
                    id="email"
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="m@example.com"
                    type="email"
                    value={email}
                  />
                </div>
                <div className="grid gap-[var(--spacing-xs)]">
                  <Label
                    className="font-normal text-[color:var(--color-states-muted-foreground)] text-sm leading-[125%] tracking-[0.01em]"
                    htmlFor="password"
                  >
                    Password
                  </Label>
                  <div className="relative w-full">
                    <Input
                      className={`${INPUT_STYLES} pr-10`}
                      id="password"
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Toyota@12"
                      type={showPassword ? "text" : "password"}
                      value={password}
                    />
                    <button
                      aria-label={showPassword ? "Hide password" : "Show password"}
                      aria-pressed={showPassword}
                      className="absolute top-1/2 right-2 inline-flex -translate-y-1/2 cursor-pointer items-center justify-center p-1 text-[color:var(--color-states-muted-foreground)] transition-colors hover:text-[color:var(--color-core-surfaces-foreground)]"
                      onClick={() => setShowPassword((s) => !s)}
                      type="button"
                    >
                      <Image
                        alt=""
                        aria-hidden="true"
                        className={`absolute transition-all duration-200 ${showPassword ? "scale-100 opacity-100" : "scale-75 opacity-0"}`}
                        height={18}
                        src="/images/password-eye.svg"
                        width={18}
                      />
                      <Image
                        alt=""
                        aria-hidden="true"
                        className={`transition-all duration-200 ${showPassword ? "scale-75 opacity-0" : "scale-100 opacity-100"}`}
                        height={18}
                        src="/images/password-eye-off.svg"
                        width={18}
                      />
                    </button>
                  </div>
                </div>
                <div className="grid gap-[var(--spacing-xs)]">
                  <Label
                    className="font-normal text-[color:var(--color-states-muted-foreground)] text-sm leading-[125%] tracking-[0.01em]"
                    htmlFor="confirm-password"
                  >
                    Confirm Password
                  </Label>
                  <div className="relative w-full">
                    <Input
                      className={`${INPUT_STYLES} pr-10`}
                      id="confirm-password"
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Toyota@12"
                      type={showConfirmPassword ? "text" : "password"}
                      value={confirmPassword}
                    />
                    <button
                      aria-label={showConfirmPassword ? "Hide password" : "Show password"}
                      aria-pressed={showConfirmPassword}
                      className="absolute top-1/2 right-2 inline-flex -translate-y-1/2 cursor-pointer items-center justify-center p-1 text-[color:var(--color-states-muted-foreground)] transition-colors hover:text-[color:var(--color-core-surfaces-foreground)]"
                      onClick={() => setShowConfirmPassword((s) => !s)}
                      type="button"
                    >
                      <Image
                        alt=""
                        aria-hidden="true"
                        className={`absolute transition-all duration-200 ${showConfirmPassword ? "scale-100 opacity-100" : "scale-75 opacity-0"}`}
                        height={18}
                        src="/images/password-eye.svg"
                        width={18}
                      />
                      <Image
                        alt=""
                        aria-hidden="true"
                        className={`transition-all duration-200 ${showConfirmPassword ? "scale-75 opacity-0" : "scale-100 opacity-100"}`}
                        height={18}
                        src="/images/password-eye-off.svg"
                        width={18}
                      />
                    </button>
                  </div>
                </div>

                <div>
                  <div className="flex items-start gap-[var(--spacing-xs)]">
                    <Checkbox
                      checked={termsChecked}
                      className="mt-0.5"
                      id="terms"
                      name="terms"
                      onCheckedChange={(checked) => setTermsChecked(checked as boolean)}
                    />
                    <Label
                      className="cursor-pointer font-normal text-[color:var(--color-states-muted-foreground)] text-sm leading-[125%] tracking-[0.01em]"
                      htmlFor="terms"
                    >
                      I agree to the{" "}
                      <Link
                        className="text-[color:var(--color-destructive)] underline"
                        href="/terms"
                      >
                        Terms of Service
                      </Link>{" "}
                      and{" "}
                      <Link
                        className="text-[color:var(--color-destructive)] underline"
                        href="/privacy"
                      >
                        Privacy Policy
                      </Link>
                    </Label>
                  </div>
                  <div
                    aria-live="polite"
                    className={`mt-[var(--spacing-2xs)] text-[color:var(--color-destructive)] text-xs transition-opacity duration-300 ${
                      termsError ? "opacity-100" : "pointer-events-none opacity-0"
                    }`}
                  >
                    {termsError}
                  </div>
                </div>

                {formError && (
                  <p
                    aria-live="polite"
                    className="mt-[var(--spacing-xs)] text-[color:var(--color-destructive)] text-xs"
                    role="alert"
                  >
                    {formError}
                  </p>
                )}

                {confirmPasswordError && (
                  <p
                    aria-live="polite"
                    className="text-[color:var(--color-destructive)] text-xs"
                    role="alert"
                  >
                    {confirmPasswordError}
                  </p>
                )}

                <AppButton className="w-full" disabled={!allFilled} type="submit" variant="primary">
                  Create your account
                </AppButton>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
