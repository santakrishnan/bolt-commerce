"use client";

import CreateAccountWrapper from "./create-account-wrapper";

export function CreateAccount() {
  return <CreateAccountWrapper />;
}
