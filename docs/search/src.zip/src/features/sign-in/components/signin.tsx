"use client";

import SignInWrapper from "./sign-in-wrapper";

export function SignIn() {
  return <SignInWrapper />;
}
