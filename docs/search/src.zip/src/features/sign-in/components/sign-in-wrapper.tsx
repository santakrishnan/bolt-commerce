"use client";
import { ROUTES } from "@config/routes";
import { authClient } from "@features/auth/lib/auth-client";
import { setFeatureFlagProfileForSampleUser } from "@features/auth/lib/feature-flag-profile";
import { AppButton } from "@shared/components/button";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useRef, useState } from "react";
import { Input } from "@/components/input";

function FlexDivider() {
  return <hr className="flex-1 border-(--color-structure-interaction-subtle-border)" />;
}

const INPUT_STYLES =
  "bg-(--color-core-surfaces-background) text-(--color-core-surfaces-foreground) rounded-[var(--radius-md)] border-0 shadow-none focus:border focus:border-(--color-core-surfaces-foreground) focus-visible:outline-none focus-visible:ring-0 placeholder:text-(--color-states-muted-foreground) mb-0 h-[var(--spacing-2xl)] px-[var(--spacing-md)] py-0";

export default function SignInWrapper() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const isSubmitting = useRef(false);

  const allFilled = email.trim() !== "" && password !== "";

  const handleClose = () => {
    if (window.history.length > 1) {
      router.back();
      return;
    }
    router.push(ROUTES.HOME);
  };

  const handleSubmit = async (ev: React.FormEvent<HTMLFormElement>) => {
    if (isSubmitting.current) {
      return;
    }
    ev.preventDefault();
    isSubmitting.current = true;
    setError(null);

    const { error: authError } = await authClient.signIn.email({
      email: email.trim(),
      password,
      callbackURL: ROUTES.MY_GARAGE,
    });

    if (authError) {
      setError(authError.message ?? "Sign in failed. Please check your credentials.");
      isSubmitting.current = false;
      return;
    }
    console.log("Sign in successful, redirecting...");
    setFeatureFlagProfileForSampleUser(email);
    router.push(ROUTES.MY_GARAGE);
    router.refresh();
  };

  return (
    <div className="relative flex min-h-dvh items-center justify-center bg-black p-(--spacing-md) sm:p-(--spacing-xl)">
      <Image
        alt=""
        aria-hidden="true"
        className="absolute inset-0 object-cover"
        fill
        src="/images/Sign-up-bg.svg"
      />
      <div className="relative z-10 mx-(--spacing-md) flex w-full max-w-md flex-col gap-(--spacing-xl) rounded-lg bg-(--color-core-surfaces-card) px-(--spacing-lg) py-(--spacing-xl)">
        <button
          aria-label="Close sign in"
          className="absolute top-(--spacing-md) right-(--spacing-md) inline-flex h-8 w-8 items-center justify-center rounded-full border border-(--color-structure-interaction-subtle-border) text-(--color-core-surfaces-foreground) text-sm transition-colors hover:bg-(--color-core-surfaces-background)"
          onClick={handleClose}
          type="button"
        >
          X
        </button>
        <div className="flex items-center justify-center gap-3">
          <div aria-hidden="true" className="h-10 w-10 bg-icon-primary" />
          <span className="font-bold font-sans text-base uppercase leading-normal">ARROW</span>
        </div>

        <FlexDivider />

        <h3 className="text-center font-sans font-semibold text-(--color-core-surfaces-foreground) text-2xl leading-[115%]">
          Sign in
        </h3>

        <div>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-(--spacing-lg)">
              <div className="grid gap-(--spacing-xs)">
                <label className="font-medium text-sm leading-none" htmlFor="email">
                  Email
                </label>
                <Input
                  className={INPUT_STYLES}
                  id="email"
                  onChange={(e) => setEmail(e.target.value)}
                  type="email"
                  value={email}
                />
              </div>
              <div className="grid gap-(--spacing-xs)">
                <div className="flex items-center">
                  <label className="font-medium text-sm leading-none" htmlFor="password">
                    Password
                  </label>
                </div>
                <div className="relative w-full">
                  <Input
                    className={`${INPUT_STYLES} pr-10`}
                    id="password"
                    onChange={(e) => setPassword(e.target.value)}
                    type={showPassword ? "text" : "password"}
                    value={password}
                  />
                  <button
                    aria-label={showPassword ? "Hide password" : "Show password"}
                    className="absolute top-1/2 right-2 inline-flex -translate-y-1/2 cursor-pointer items-center justify-center p-1 text-(--color-states-muted-foreground) transition-colors hover:text-(--color-core-surfaces-foreground)"
                    onClick={() => setShowPassword((s) => !s)}
                    type="button"
                  >
                    <Image
                      alt=""
                      aria-hidden="true"
                      className={`absolute transition-all duration-200 ${showPassword ? "scale-100 opacity-100" : "scale-75 opacity-0"}`}
                      height={18}
                      src="/images/password-eye.svg"
                      width={18}
                    />
                    <Image
                      alt=""
                      aria-hidden="true"
                      className={`transition-all duration-200 ${showPassword ? "scale-75 opacity-0" : "scale-100 opacity-100"}`}
                      height={18}
                      src="/images/password-eye-off.svg"
                      width={18}
                    />
                  </button>
                </div>
                <Link
                  className="ml-auto text-sm underline-offset-4 hover:underline"
                  href="/forgot-password"
                >
                  Forgot your password?
                </Link>
              </div>
              <AppButton className="w-full" disabled={!allFilled} type="submit" variant="primary">
                Login
              </AppButton>
            </div>
          </form>
          {error && (
            <p className="mt-(--spacing-xs) text-center text-destructive text-sm" role="alert">
              {error}
            </p>
          )}
        </div>

        <div className="flex items-center">
          <FlexDivider />
          <span className="px-(--spacing-md) text-(--color-states-muted-foreground) text-sm">
            or
          </span>
          <FlexDivider />
        </div>

        <div className="flex flex-col gap-(--spacing-md)">
          <AppButton variant="tertiary">Continue with Google</AppButton>
          <AppButton variant="secondary">Continue with Apple</AppButton>
        </div>

        <div className="flex justify-center gap-(--spacing-xs)">
          <span className="font-normal text-(--color-states-muted-foreground) text-sm leading-[125%] tracking-[0.01em]">
            Don't have an account?
          </span>
          <Link
            className="font-semibold text-destructive text-sm leading-[125%] tracking-[0.01em]"
            href="/create-account"
          >
            Create Your Account
          </Link>
        </div>
      </div>
    </div>
  );
}
