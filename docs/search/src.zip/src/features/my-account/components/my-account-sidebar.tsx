"use client";

import CustomBadge from "@shared/components/custom-badge";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const ITEMS: { key: string; label: string; icon: string }[] = [
  { key: "my-details", label: "My Details", icon: "/images/header/icon-user.svg" },
  { key: "password", label: "Password", icon: "/images/header/icon-lock.svg" },
  {
    key: "pre-qualification",
    label: "Pre-Qualification",
    icon: "/images/header/icon-pre-qualification.svg",
  },
  {
    key: "notifications",
    label: "Notification Preferences",
    icon: "/images/header/icon-clock.svg",
  },
];

export default function MyAccountSidebar() {
  const pathname = usePathname();
  const activeKey = pathname?.split("/").pop() || "my-details";

  return (
    <nav className="hidden rounded-[var(--radius-md)] bg-white lg:block lg:p-[var(--spacing-md)]">
      <ul className="hidden flex-col gap-y-[var(--spacing-2xs)] lg:flex">
        {ITEMS.map((item) => {
          const isActive = activeKey === item.key;

          let itemClassName =
            "flex w-full justify-start gap-x-[var(--spacing-xs)] rounded px-[var(--spacing-sm)] py-[var(--spacing-sm)] text-left transition-colors";
          if (isActive) {
            itemClassName = cn(
              itemClassName,
              "bg-core-surfaces-background font-semibold text-[var(--color-core-surfaces-foreground)]"
            );
          } else {
            itemClassName = cn(
              itemClassName,
              "text-[var(--color-states-muted-foreground)] hover:bg-core-surfaces-background hover:font-semibold hover:text-[var(--color-core-surfaces-foreground)]"
            );
          }

          return (
            <li key={item.key}>
              <Link
                aria-current={isActive ? "page" : undefined}
                className={itemClassName}
                href={`/my-account/${item.key}`}
              >
                <span className="inline-flex items-center gap-[var(--spacing-xs)]">
                  <Image
                    alt=""
                    className="h-4 w-4 shrink-0"
                    height={16}
                    src={item.icon}
                    width={16}
                  />
                  <span className="leading-[125%] tracking-[1%]">{item.label}</span>
                </span>
                {item.key === "pre-qualification" && (
                  <CustomBadge className="ml-auto" text="Prequalified" type="preQualifies" />
                )}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
