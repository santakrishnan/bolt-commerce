export type { NotificationSettings } from "~/features/my-account/components/notifications/types";
export type { UserDetailsFormData } from "~/features/my-account/components/user-details/types";

import type { NotificationSettings as _NotificationSettings } from "~/features/my-account/components/notifications/types";
import type { UserDetailsFormData as _UserDetailsFormData } from "~/features/my-account/components/user-details/types";

export interface UpdateUserDetailsRequest {
  city?: string;
  day?: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  month?: string;
  phone?: string;
  state?: string;
  streetAddress?: string;
  year?: string;
  zip?: string;
}

export interface UpdateUserDetailsResponse {
  data?: _UserDetailsFormData;
  error?: string;
  success: boolean;
}

export interface UpdateNotificationSettingsRequest {
  sections: _NotificationSettings["sections"];
}

export interface UpdateNotificationSettingsResponse {
  data?: _NotificationSettings;
  error?: string;
  success: boolean;
}

/**
 * Active session for the user (password page)
 */
export interface UserSession {
  deviceName: string;
  id: string;
  isCurrent: boolean;
  lastActive: string;
  location: string;
}

/**
 * Response from fetching user sessions
 */
export interface GetSessionsResponse {
  sessions: UserSession[];
}
