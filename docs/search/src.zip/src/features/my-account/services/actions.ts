"use server";

import type {
  UpdateNotificationSettingsRequest,
  UpdateNotificationSettingsResponse,
  UpdateUserDetailsRequest,
  UpdateUserDetailsResponse,
} from "./types";

export async function updateUserDetailsAction(
  data: UpdateUserDetailsRequest
): Promise<UpdateUserDetailsResponse> {
  const { updateUserDetails } = await import("./account.service");
  return updateUserDetails(data);
}

export async function updateNotificationSettingsAction(
  data: UpdateNotificationSettingsRequest
): Promise<UpdateNotificationSettingsResponse> {
  const { updateNotificationSettings } = await import("./account.service");
  return updateNotificationSettings(data);
}
