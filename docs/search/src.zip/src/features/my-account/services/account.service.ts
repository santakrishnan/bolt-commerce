import { cache } from "react";
import type {
  GetSessionsResponse,
  NotificationSettings,
  UpdateNotificationSettingsRequest,
  UpdateNotificationSettingsResponse,
  UpdateUserDetailsRequest,
  UpdateUserDetailsResponse,
  UserDetailsFormData,
} from "./types";

function isMockMode(): boolean {
  return !process.env.ACCOUNT_SERVICE_URL || process.env.USE_MOCK_ACCOUNT === "true";
}

async function fetchUserDetailsFromMock(): Promise<UserDetailsFormData> {
  const { getMockUserDetails } = await import("./account.mocks");
  return getMockUserDetails();
}

async function fetchNotificationSettingsFromMock(): Promise<NotificationSettings> {
  const { getMockNotificationSettings } = await import("./account.mocks");
  return getMockNotificationSettings();
}

async function updateUserDetailsInMock(
  updates: UpdateUserDetailsRequest
): Promise<UpdateUserDetailsResponse> {
  const { updateMockUserDetails } = await import("./account.mocks");
  return updateMockUserDetails(updates);
}

async function updateNotificationSettingsInMock(
  updates: UpdateNotificationSettingsRequest
): Promise<UpdateNotificationSettingsResponse> {
  const { updateMockNotificationSettings } = await import("./account.mocks");
  return updateMockNotificationSettings(updates);
}

async function fetchSessionsFromMock(): Promise<GetSessionsResponse> {
  const { getMockSessions } = await import("./account.mocks");
  return getMockSessions();
}

async function fetchUserDetailsFromAPI(): Promise<UserDetailsFormData> {
  const baseUrl = process.env.ACCOUNT_SERVICE_URL;
  if (!baseUrl) {
    throw new Error("[AccountService] ACCOUNT_SERVICE_URL is not configured");
  }

  const res = await fetch(`${baseUrl}/account/user`, {
    headers: {
      ...(process.env.ACCOUNT_API_KEY && {
        Authorization: `Bearer ${process.env.ACCOUNT_API_KEY}`,
      }),
    },
    next: { revalidate: 60 },
  });

  if (!res.ok) {
    throw new Error(`[AccountService] API error: ${res.status} ${res.statusText}`);
  }

  const json = (await res.json()) as { data: UserDetailsFormData };
  return json.data;
}

async function fetchNotificationSettingsFromAPI(): Promise<NotificationSettings> {
  const baseUrl = process.env.ACCOUNT_SERVICE_URL;
  if (!baseUrl) {
    throw new Error("[AccountService] ACCOUNT_SERVICE_URL is not configured");
  }

  const res = await fetch(`${baseUrl}/account/notifications`, {
    headers: {
      ...(process.env.ACCOUNT_API_KEY && {
        Authorization: `Bearer ${process.env.ACCOUNT_API_KEY}`,
      }),
    },
    next: { revalidate: 60 },
  });

  if (!res.ok) {
    throw new Error(`[AccountService] API error: ${res.status} ${res.statusText}`);
  }

  const json = (await res.json()) as { data: NotificationSettings };
  return json.data;
}

async function updateUserDetailsInAPI(
  updates: UpdateUserDetailsRequest
): Promise<UpdateUserDetailsResponse> {
  const baseUrl = process.env.ACCOUNT_SERVICE_URL;
  if (!baseUrl) {
    throw new Error("[AccountService] ACCOUNT_SERVICE_URL is not configured");
  }

  const res = await fetch(`${baseUrl}/account/user`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      ...(process.env.ACCOUNT_API_KEY && {
        Authorization: `Bearer ${process.env.ACCOUNT_API_KEY}`,
      }),
    },
    body: JSON.stringify(updates),
  });

  if (!res.ok) {
    const errorText = await res.text();
    return {
      success: false,
      error: `API error: ${res.status} ${errorText}`,
    };
  }

  const json = (await res.json()) as { data: UserDetailsFormData };
  return {
    success: true,
    data: json.data,
  };
}

async function updateNotificationSettingsInAPI(
  updates: UpdateNotificationSettingsRequest
): Promise<UpdateNotificationSettingsResponse> {
  const baseUrl = process.env.ACCOUNT_SERVICE_URL;
  if (!baseUrl) {
    throw new Error("[AccountService] ACCOUNT_SERVICE_URL is not configured");
  }

  const res = await fetch(`${baseUrl}/account/notifications`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      ...(process.env.ACCOUNT_API_KEY && {
        Authorization: `Bearer ${process.env.ACCOUNT_API_KEY}`,
      }),
    },
    body: JSON.stringify(updates),
  });

  if (!res.ok) {
    const errorText = await res.text();
    return {
      success: false,
      error: `API error: ${res.status} ${errorText}`,
    };
  }

  const json = (await res.json()) as { data: NotificationSettings };
  return {
    success: true,
    data: json.data,
  };
}

async function fetchSessionsFromAPI(): Promise<GetSessionsResponse> {
  const baseUrl = process.env.ACCOUNT_SERVICE_URL;
  if (!baseUrl) {
    throw new Error("[AccountService] ACCOUNT_SERVICE_URL is not configured");
  }

  const res = await fetch(`${baseUrl}/account/sessions`, {
    headers: {
      ...(process.env.ACCOUNT_API_KEY && {
        Authorization: `Bearer ${process.env.ACCOUNT_API_KEY}`,
      }),
    },
    next: { revalidate: 60 },
  });

  if (!res.ok) {
    throw new Error(`[AccountService] API error: ${res.status} ${res.statusText}`);
  }

  const json = (await res.json()) as GetSessionsResponse;
  return json;
}

export const getUserDetails = cache(async function getUserDetails(): Promise<UserDetailsFormData> {
  if (isMockMode()) {
    console.log("[AccountService] Using mock user details");
    return fetchUserDetailsFromMock();
  }

  try {
    return await fetchUserDetailsFromAPI();
  } catch (error) {
    console.error("[AccountService] Falling back to mock user details due to error:", error);
    return fetchUserDetailsFromMock();
  }
});

export const getNotificationSettings = cache(
  async function getNotificationSettings(): Promise<NotificationSettings> {
    if (isMockMode()) {
      console.log("[AccountService] Using mock notification settings");
      return fetchNotificationSettingsFromMock();
    }

    try {
      return await fetchNotificationSettingsFromAPI();
    } catch (error) {
      console.error(
        "[AccountService] Falling back to mock notification settings due to error:",
        error
      );
      return fetchNotificationSettingsFromMock();
    }
  }
);

/* Update user details */
export async function updateUserDetails(
  updates: UpdateUserDetailsRequest
): Promise<UpdateUserDetailsResponse> {
  if (isMockMode()) {
    return updateUserDetailsInMock(updates);
  }

  try {
    return await updateUserDetailsInAPI(updates);
  } catch (error) {
    console.error("[AccountService] Error updating user details:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

/* Update notification settings */
export async function updateNotificationSettings(
  updates: UpdateNotificationSettingsRequest
): Promise<UpdateNotificationSettingsResponse> {
  if (isMockMode()) {
    return updateNotificationSettingsInMock(updates);
  }

  try {
    return await updateNotificationSettingsInAPI(updates);
  } catch (error) {
    console.error("[AccountService] Error updating notification settings:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

/* Fetch active user sessions (Password page)*/
export const getSessions = cache(async function getSessions(): Promise<GetSessionsResponse> {
  if (isMockMode()) {
    console.log("[AccountService] Using mock sessions");
    return fetchSessionsFromMock();
  }

  try {
    return await fetchSessionsFromAPI();
  } catch (error) {
    console.error("[AccountService] Falling back to mock sessions due to error:", error);
    return fetchSessionsFromMock();
  }
});
