import type {
  GetSessionsResponse,
  NotificationSettings,
  UpdateNotificationSettingsResponse,
  UpdateUserDetailsResponse,
  UserDetailsFormData,
  UserSession,
} from "./types";

/* Mock notification settings */
export const MOCK_NOTIFICATION_SETTINGS: NotificationSettings = {
  sections: [
    {
      id: "vertical-alerts",
      title: "Vertical Alerts",
      items: [
        {
          id: "price-change",
          title: "Price changes on saved vehicle",
          email: true,
          mobile: false,
        },
        {
          id: "saved-vehicle",
          title: "New matches for saved vehicles",
          email: true,
          mobile: false,
        },
      ],
    },
    {
      id: "financing",
      title: "Financing & Trade-In",
      items: [
        {
          id: "pre-qualification",
          title: "Pre-qualification status updates",
          email: true,
          mobile: false,
        },
        {
          id: "trade-in-update",
          title: "Trade-in offer updates",
          email: true,
          mobile: true,
        },
      ],
    },
    {
      id: "promotions",
      title: "Promotions & Updates",
      items: [
        {
          id: "arrow-updates",
          title: "Arrow news and updates",
          email: false,
          mobile: false,
        },
        {
          id: "special-offers",
          title: "Special offers and promotions",
          email: true,
          mobile: false,
        },
      ],
    },
  ],
};

/* Mock user sessions for the password/security page */
export const MOCK_USER_SESSIONS: UserSession[] = [
  {
    id: "session-1",
    deviceName: "Chrome on Windows",
    location: "Seattle, WA",
    lastActive: "Active now",
    isCurrent: true,
  },
  {
    id: "session-2",
    deviceName: "Safari on iPhone",
    location: "Seattle, WA",
    lastActive: "2 hours ago",
    isCurrent: false,
  },
  {
    id: "session-3",
    deviceName: "Chrome on Mac",
    location: "Portland, OR",
    lastActive: "Yesterday",
    isCurrent: false,
  },
];

export async function getMockUserDetails(): Promise<UserDetailsFormData> {
  const { getCurrentUser } = await import("@config/flags/server");
  const user = await getCurrentUser();

  return {
    firstName: user.firstName || "",
    lastName: user.lastName || "",
    email: user.email || "",
    phone: user.phone || "",
    month: user.month || "",
    day: user.day || "",
    year: user.year || "",
    streetAddress: user.streetAddress || "",
    city: user.city || "",
    state: user.state || "",
    zip: user.zip || "",
  };
}

export function getMockNotificationSettings(): Promise<NotificationSettings> {
  return Promise.resolve(MOCK_NOTIFICATION_SETTINGS);
}

export async function updateMockUserDetails(
  updates: Partial<UserDetailsFormData>
): Promise<UpdateUserDetailsResponse> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 300));

  const currentDetails = await getMockUserDetails();
  const updatedDetails = { ...currentDetails, ...updates };

  console.log("[AccountService:Mock] Updated user details:", updates);

  return {
    success: true,
    data: updatedDetails,
  };
}

export async function updateMockNotificationSettings(
  updates: Partial<NotificationSettings>
): Promise<UpdateNotificationSettingsResponse> {
  await new Promise((resolve) => setTimeout(resolve, 300));

  const updatedSettings = {
    sections: updates.sections || MOCK_NOTIFICATION_SETTINGS.sections,
  };

  console.log("[AccountService:Mock] Updated notification settings");

  return {
    success: true,
    data: updatedSettings,
  };
}

export function getMockSessions(): Promise<GetSessionsResponse> {
  return Promise.resolve({ sessions: MOCK_USER_SESSIONS });
}
