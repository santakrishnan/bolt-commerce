import { beforeEach, describe, expect, it, vi } from "vitest";
import { fetchBatchCounts, fetchVehicleFinderBatchCounts } from "../batch-counts-api";

describe("Batch Counts API Client", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    global.fetch = vi.fn();
  });

  describe("fetchBatchCounts", () => {
    it("fetches counts for multiple queries", async () => {
      const mockResponse = {
        counts: {
          "under-20k": 1234,
          "excellent-deals": 567,
        },
      };

      vi.mocked(global.fetch).mockResolvedValue({
        ok: true,
        json: async () => mockResponse,
      } as Response);

      const queries = [
        { id: "under-20k", searchQuery: "cars-under-$20,000" },
        { id: "excellent-deals", searchQuery: "shop-excellent-deals" },
      ];

      const result = await fetchBatchCounts(queries);

      expect(result).toEqual({
        "under-20k": 1234,
        "excellent-deals": 567,
      });

      expect(global.fetch).toHaveBeenCalledWith(
        "/api/search/batch-counts",
        expect.objectContaining({
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({ queries }),
        })
      );
    });

    it("throws error when API fails", async () => {
      vi.mocked(global.fetch).mockResolvedValue({
        ok: false,
        status: 500,
      } as Response);

      const queries = [{ id: "under-20k", searchQuery: "cars-under-$20,000" }];

      await expect(fetchBatchCounts(queries)).rejects.toThrow("Batch counts API failed: 500");
    });
  });

  describe("fetchVehicleFinderBatchCounts", () => {
    it("fetches all vehicle finder counts", async () => {
      const mockResponse = {
        counts: {
          "under-20k": 1234,
          "excellent-deals": 567,
          "price-drop": 89,
          "low-miles": 432,
        },
      };

      vi.mocked(global.fetch).mockResolvedValue({
        ok: true,
        json: async () => mockResponse,
      } as Response);

      const result = await fetchVehicleFinderBatchCounts();

      expect(result).toEqual(mockResponse.counts);

      // Verify it called with all 4 predefined queries
      const callArgs = vi.mocked(global.fetch).mock.calls[0];
      const body = JSON.parse((callArgs?.[1]?.body ?? "") as string);
      expect(body.queries).toHaveLength(4);
      expect(body.queries.map((q: { id: string }) => q.id)).toEqual([
        "under-20k",
        "excellent-deals",
        "price-drop",
        "low-miles",
      ]);
    });
  });
});
