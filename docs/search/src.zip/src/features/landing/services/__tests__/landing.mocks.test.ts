import { describe, expect, it } from "vitest";
import { DEFAULT_HERO_STATS, DEFAULT_VEHICLE_FINDER_OPTIONS } from "../landing.defaults";

describe("landing.defaults", () => {
  it("exports hero stats array with expected fields", () => {
    expect(Array.isArray(DEFAULT_HERO_STATS)).toBe(true);
    expect(DEFAULT_HERO_STATS.length).toBeGreaterThan(0);
    for (const s of DEFAULT_HERO_STATS as any) {
      expect(typeof s.id).toBe("string");
      expect(typeof s.value).toBe("string");
      expect(typeof s.label).toBe("string");
      expect(typeof s.icon).toBe("string");
    }
  });

  it("exports vehicle finder options with expected fields", () => {
    expect(Array.isArray(DEFAULT_VEHICLE_FINDER_OPTIONS)).toBe(true);

    for (const opt of DEFAULT_VEHICLE_FINDER_OPTIONS as any) {
      expect(typeof opt.id).toBe("string");
      expect(typeof opt.title).toBe("string");
      expect(typeof opt.icon).toBe("string");
    }
  });
});
