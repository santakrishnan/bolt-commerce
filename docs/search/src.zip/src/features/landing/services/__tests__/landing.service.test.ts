import { beforeEach, describe, expect, it, vi } from "vitest";

//next/cache functions are available in the test environment as no-ops
vi.doMock("next/cache", () => ({ cacheLife: vi.fn(), cacheTag: vi.fn() }));

import {
  transformHeroStats,
  transformRawHeroStat,
  transformVehicleFinderCounts,
} from "../landing.service";

describe("landing.service transforms", () => {
  it("transformRawHeroStat maps fields correctly (id/value/label/icon)", () => {
    const raw = { id: "x", value: 10, label: "L", icon: "/i.svg" } as any;
    const out = transformRawHeroStat(raw);
    expect(out.id).toBe("x");
    expect(out.value).toBe("10");
    expect(out.label).toBe("L");
    expect(out.icon).toBe("/i.svg");
  });

  it("transformRawHeroStat handles alternate keys", () => {
    const raw = { key: "k", metric_value: 42, display_name: "D", icon_url: "/u.svg" } as any;
    const out = transformRawHeroStat(raw);
    expect(out.id).toBe("k");
    expect(out.value).toBe("42");
    expect(out.label).toBe("D");
    expect(out.icon).toBe("/u.svg");
  });

  it("transformHeroStats picks array from features/stats/metrics/data", () => {
    const base = { features: [{ id: "a", value: 1, label: "A", icon: "i" }] } as any;
    const out = transformHeroStats(base as any);
    expect(out.length).toBe(1);
    expect(out.some((it: any) => it.id === "a")).toBe(true);
  });

  it("transformVehicleFinderCounts normalizes counts and defaults missing to 0", () => {
    const rawTop = { "under-20k": "5", "excellent-deals": 2 } as any;
    const outTop = transformVehicleFinderCounts(rawTop as any);
    expect(outTop["under-20k"]).toBe(5);
    expect(outTop["price-drop"]).toBe(0);

    const rawCounts = { counts: { "low-miles": "3" } } as any;
    const outCounts = transformVehicleFinderCounts(rawCounts as any);
    expect(outCounts["low-miles"]).toBe(3);
  });
});

describe("landing.service fetch functions (mocking upstream)", () => {
  beforeEach(() => {
    vi.resetModules();
    process.env.LANDING_SERVICE_URL = undefined as any;
    process.env.USE_MOCK_LANDING = undefined as any;
  });

  it("returns default stats with live vehicle count in mock mode (no LANDING_SERVICE_URL)", async () => {
    const mod = await import("../landing.service");
    const { DEFAULT_VEHICLE_FINDER_OPTIONS } = await import("../landing.defaults");

    const hs = await mod.fetchHeroStats();
    // Vehicle count should be injected from searchVehicles, not the static default
    const vehicleStat = hs.find((s: any) => s.id === "vehicles");
    expect(vehicleStat).toBeDefined();
    expect(Number(vehicleStat?.value.replace(/,/g, ""))).toBeGreaterThan(0);
    // Other stats should match defaults
    expect(hs.find((s: any) => s.id === "vin")?.value).toBe("100%");
    expect(hs.find((s: any) => s.id === "money-back")?.value).toBe("7-Day");

    const opts = await mod.fetchVehicleFinderOptions();
    expect(opts).toEqual(DEFAULT_VEHICLE_FINDER_OPTIONS);

    const counts = await mod.fetchVehicleFinderCounts();
    expect(counts["excellent-deals"]).toBeTypeOf("number");
    expect(counts["low-miles"]).toBeTypeOf("number");
    expect(counts["price-drop"]).toBeTypeOf("number");
    expect(counts["under-20k"]).toBeTypeOf("number");
  });

  it("calls upstream client when LANDING_SERVICE_URL is set and returns transformed data", async () => {
    vi.doMock("next/cache", () => ({ cacheLife: vi.fn(), cacheTag: vi.fn() }));

    class FakeError extends Error {}
    const getMock = vi
      .fn()
      .mockResolvedValue({ features: [{ id: "h1", value: 7, label: "L", icon: "i" }] });
    const createClientMock = vi.fn().mockReturnValue({ get: getMock });

    vi.doMock("@features/tracking/lib/server-api", () => ({
      ArrowServerError: FakeError,
      createArrowServerClient: createClientMock,
    }));

    // set env to force non-mock mode
    process.env.LANDING_SERVICE_URL = "http://example.local";

    const mod = await import("../landing.service");

    const hs = await mod.fetchHeroStats();
    expect(getMock).toHaveBeenCalled();
    expect(hs.some((it: any) => it.id === "h1")).toBe(true);
  });

  it("falls back to default stats with live vehicle count when upstream throws ArrowServerError", async () => {
    vi.doMock("next/cache", () => ({ cacheLife: vi.fn(), cacheTag: vi.fn() }));

    class FakeError extends Error {}
    const getMock = vi.fn().mockRejectedValue(new FakeError("upstream"));
    const createClientMock = vi.fn().mockReturnValue({ get: getMock });

    vi.doMock("@features/tracking/lib/server-api", () => ({
      ArrowServerError: FakeError,
      createArrowServerClient: createClientMock,
    }));

    process.env.LANDING_SERVICE_URL = "http://example.local";

    const mod = await import("../landing.service");

    const hs = await mod.fetchHeroStats();
    // Should fall back to defaults but with live vehicle count injected
    const vehicleStat = hs.find((s: any) => s.id === "vehicles");
    expect(vehicleStat).toBeDefined();
    expect(hs.find((s: any) => s.id === "vin")?.value).toBe("100%");
  });
});
