export function getCarouselTransform(
  containerRef: React.RefObject<HTMLDivElement | null>,
  currentIndex: number
): string {
  if (!containerRef.current) {
    return "translateX(0)";
  }

  const container = containerRef.current;
  const track = container.querySelector("[data-carousel-track]") as HTMLElement | null;
  const cards = track?.children;

  if (!(track && cards) || cards.length === 0 || currentIndex >= cards.length) {
    return "translateX(0)";
  }

  const containerWidth = container.offsetWidth;
  const activeCard = cards[currentIndex] as HTMLElement;
  const cardLeft = activeCard.offsetLeft;
  const cardWidth = activeCard.offsetWidth;
  const centerOffset = (containerWidth - cardWidth) / 2;

  return `translateX(${centerOffset - cardLeft}px)`;
}
