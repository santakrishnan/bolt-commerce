"use client";

import { ROUTES } from "@config/routes/constants";
import { Card, CardContent, cn, Heading } from "@tfs-ucmp/ui";
import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import type { ReactElement } from "react";
import { useCallback, useEffect, useRef, useState } from "react";
import config from "./buying-process-config.json";
import { getCarouselTransform } from "./carousel-transform";
import type { BuyingProcessCarouselProps } from "./types";

const iconMap = config.iconPaths;

const PASSIVE_LISTENER_OPTIONS = { passive: true } as const;

export function BuyingProcessCarousel({ steps }: BuyingProcessCarouselProps): ReactElement {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [carouselTransform, setCarouselTransform] = useState("translateX(0)");
  const containerRef = useRef<HTMLDivElement>(null);
  const touchStartX = useRef(0);
  const touchEndX = useRef(0);
  const isSwiping = useRef(false);

  const totalSteps = steps.length;

  const goToSlide = useCallback(
    (index: number) => {
      setCurrentIndex(((index % totalSteps) + totalSteps) % totalSteps);
    },
    [totalSteps]
  );

  const handleTouchStart = useCallback((e: TouchEvent): void => {
    const touch = e.touches[0];
    if (!touch) {
      return;
    }
    touchStartX.current = touch.clientX;
    isSwiping.current = true;
  }, []);

  const handleTouchMove = useCallback((e: TouchEvent): void => {
    if (!isSwiping.current) {
      return;
    }
    const touch = e.touches[0];
    if (!touch) {
      return;
    }
    touchEndX.current = touch.clientX;
  }, []);

  const handleTouchEnd = useCallback((): void => {
    if (!isSwiping.current) {
      return;
    }
    isSwiping.current = false;

    const swipeDistance = touchStartX.current - touchEndX.current;
    const minSwipeDistance = config.carousel.minSwipeDistance;

    if (swipeDistance > minSwipeDistance) {
      setCurrentIndex((prev) => (prev + 1) % totalSteps);
    } else if (swipeDistance < -minSwipeDistance) {
      setCurrentIndex((prev) => (prev - 1 + totalSteps) % totalSteps);
    }
  }, [totalSteps]);

  // Compute the centered transform after mount (when ref is available) and on every index / resize change
  useEffect(() => {
    const updateTransform = () => {
      setCarouselTransform(getCarouselTransform(containerRef, currentIndex));
    };

    updateTransform();
    window.addEventListener("resize", updateTransform);
    return () => window.removeEventListener("resize", updateTransform);
  }, [currentIndex]);

  useEffect(() => {
    const element = containerRef.current;
    if (!element) {
      return;
    }

    element.addEventListener("touchstart", handleTouchStart, PASSIVE_LISTENER_OPTIONS);
    element.addEventListener("touchmove", handleTouchMove, PASSIVE_LISTENER_OPTIONS);
    element.addEventListener("touchend", handleTouchEnd, PASSIVE_LISTENER_OPTIONS);

    return () => {
      element.removeEventListener("touchstart", handleTouchStart);
      element.removeEventListener("touchmove", handleTouchMove);
      element.removeEventListener("touchend", handleTouchEnd);
    };
  }, [handleTouchStart, handleTouchMove, handleTouchEnd]);

  return (
    <motion.div
      className="w-full"
      initial={{ opacity: 0 }}
      transition={{ duration: 0.6, delay: 0.3 }}
      whileInView={{ opacity: 1 }}
    >
      <div ref={containerRef}>
        <div className="relative overflow-visible">
          <div
            className="flex gap-(--spacing-xs) transition-transform duration-300 ease-in-out"
            data-carousel-track=""
            style={{ transform: carouselTransform }}
          >
            {steps.map((step) => {
              const iconSrc = iconMap[step.icon] ?? "";
              return (
                <div className="w-[90%] shrink-0" key={step.title}>
                  <Card className="group h-full border-0 bg-card shadow-lg">
                    <CardContent className="flex h-full flex-col items-center px-(--spacing-md) py-[var(--spacing-5)] text-center">
                      <div className="mb-(--spacing-md) flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
                        <Image
                          alt={step.title}
                          className="shrink-0"
                          height={36}
                          src={iconSrc}
                          width={36}
                        />
                      </div>
                      <Heading
                        className="mb-sm text-(--color-core-surfaces-foreground) text-base md:text-base"
                        level={3}
                        weight="semibold"
                      >
                        {step.title}
                      </Heading>
                      <p className="text-(length:--font-size-sm) text-(--color-core-surfaces-foreground) leading-relaxed">
                        {step.description}
                      </p>
                      {step.linkText &&
                        step.linkHref &&
                        (() => {
                          const href =
                            step.linkHref === "/used-cars" ? ROUTES.USED_CARS : step.linkHref;
                          return (
                            <Link
                              className="text-(length:--font-size-sm) mt-auto pt-sm font-semibold text-primary underline underline-offset-4 hover:text-primary-hover"
                              href={href}
                            >
                              {step.linkText}
                            </Link>
                          );
                        })()}
                    </CardContent>
                  </Card>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-(--spacing-lg) flex justify-center gap-(--spacing-xs)">
          {steps.map((step, index) => (
            <button
              aria-label={`Go to step ${index + 1}`}
              className={cn(
                "h-2 w-2 rounded-full transition-all",
                index === currentIndex
                  ? "bg-background ring-2 ring-background ring-offset-2 ring-offset-foreground"
                  : "bg-background/40 hover:bg-background/60"
              )}
              key={step.title}
              onClick={() => goToSlide(index)}
              type="button"
            />
          ))}
        </div>
      </div>
    </motion.div>
  );
}
