import type { InspectionFeature } from "@shared/data/inspection/features";
import { Card, CardContent, cn, Heading } from "@tfs-ucmp/ui";
import Image from "next/image";
import { INSPECTION_ICON_MAP } from "./constants";

export interface InspectionFeatureCardProps {
  className?: string;
  feature: InspectionFeature;
}

export function InspectionFeatureCard({ feature, className }: InspectionFeatureCardProps) {
  const iconSrc = INSPECTION_ICON_MAP[feature.icon] ?? "";

  return (
    <Card className={cn("h-full border-none shadow-none", className)}>
      <CardContent className="flex h-full flex-col rounded-[var(--radius-md)] bg-white p-0">
        <div className="relative aspect-[320/213] w-full overflow-hidden rounded-t-[var(--radius-md)]">
          <Image
            alt={feature.title}
            className="object-cover"
            fill
            sizes="(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 25vw"
            src={feature.image}
          />
        </div>
        <div className="flex flex-1 flex-col gap-[var(--spacing-md)] rounded-b-[var(--radius-md)] px-[var(--spacing-md)] py-[var(--spacing-lg)] lg:gap-[var(--spacing-lg)] lg:px-[var(--spacing-lg)] lg:py-[var(--spacing-xl)]">
          <div className="flex items-center gap-[var(--spacing-md)] lg:gap-[var(--spacing-lg)]">
            <Image
              alt={feature.title}
              className="h-6 w-6 flex-shrink-0 lg:h-8 lg:w-8"
              height={32}
              src={iconSrc}
              width={32}
            />
            <Heading
              className="font-bold text-[var(--color-core-surfaces-foreground)] text-base leading-normal md:text-base lg:font-semibold lg:text-[length:var(--font-size-xl)] lg:leading-[115%]"
              level={3}
            >
              {feature.title}
            </Heading>
          </div>
          <p className="font-normal text-[length:var(--font-size-sm)] text-[var(--color-core-surfaces-foreground)] leading-normal tracking-[-0.42px] lg:text-[length:var(--font-size-sm)] lg:text-[var(--Core-surfaces-card-foreground)] lg:leading-[125%] lg:tracking-[-0.14px]">
            {feature.description}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
