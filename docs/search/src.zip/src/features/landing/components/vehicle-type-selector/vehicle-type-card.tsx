import { Card, CardContent, cn, Heading } from "@tfs-ucmp/ui";
import { cva, type VariantProps } from "class-variance-authority";
import Image from "next/image";

const cardVariants = cva(
  [
    "group relative cursor-pointer transition-all duration-200 ease-in-out",
    "min-h-[140px] sm:min-h-[160px]",
    "border-none shadow-none",
  ],
  {
    variants: {
      selected: {
        true: "bg-[var(--color-core-surfaces-background)]",
        false:
          "bg-[var(--color-core-surfaces-background)] hover:bg-[var(--color-destructive-foreground)]",
      },
    },
    defaultVariants: {
      selected: false,
    },
  }
);

export interface VehicleTypeCardProps extends VariantProps<typeof cardVariants> {
  className?: string;
  description?: string;
  image: string;
  name: string;
  selected?: boolean;
}

export function VehicleTypeCard({
  image,
  name,
  description,
  selected = false,
  className,
}: VehicleTypeCardProps) {
  return (
    <Card className={cn(cardVariants({ selected }), className)}>
      <CardContent className="flex flex-col items-center justify-center rounded-[var(--radius-md)] p-[var(--spacing-md)] sm:p-[var(--spacing-lg)]">
        <div className="relative mx-auto mb-[var(--spacing-md)] aspect-[165/124] h-[70px] w-full max-w-[165px] overflow-hidden sm:mb-[var(--spacing-8)] sm:h-[116px] lg:aspect-[320/122] lg:max-w-[320px]">
          <Image
            alt={name}
            className="object-contain transition-transform duration-200 group-hover:scale-105"
            fill
            sizes="(max-width: 1024px) 100vw, 320px"
            src={image}
          />
        </div>

        <div className="flex flex-col items-center gap-[var(--spacing-xs)]">
          <Heading
            className="m-0 truncate text-center text-[length:var(--font-size-md)] uppercase leading-[115%] sm:text-[length:var(--font-size-xl)] md:text-[length:var(--font-size-xl)][var(--color-core-surfaces-foreground)]"
            level={3}
            weight="semibold"
          >
            {name}
          </Heading>

          {description && (
            <p className="m-0 truncate text-center font-normal text-[length:var(--font-size-sm)] text-[var(--color-core-surfaces-foreground)] leading-[125%] sm:text-[length:var(--font-size-sm)]">
              {description}
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
