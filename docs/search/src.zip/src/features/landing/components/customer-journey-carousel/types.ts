import type { CustomerJourneySlide } from "./carousel-data";

export interface PromotionFlags {
  showPrequalifyBanner: boolean;
  showTestDriveBanner: boolean;
  showTradeInBanner: boolean;
}

export interface AnimatingCarouselProps {
  className?: string;
  flags: PromotionFlags;
}

export interface StyleState {
  filter: string;
  opacity: number;
  transform: string;
  transition: string;
}

export interface SingleSlideCarouselProps {
  className?: string;
  slide: CustomerJourneySlide;
}

export interface ImageContainerProps {
  slide: CustomerJourneySlide;
  style: StyleState;
  zIndex: number;
}

export interface TextContainerProps {
  isActive: boolean;
  slide: CustomerJourneySlide;
  style: StyleState;
  zIndex: number;
}

export interface NavigationDotsProps {
  currentIndex: number | null;
  onDotClick: (index: number) => void;
  slides: CustomerJourneySlide[];
}

export interface SlideContentProps {
  slide: CustomerJourneySlide;
}

export interface TextContentProps {
  slide: CustomerJourneySlide;
}
