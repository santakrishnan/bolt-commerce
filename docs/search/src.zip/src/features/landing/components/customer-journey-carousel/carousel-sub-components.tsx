import { AppButton } from "@shared/components/button";
import { useIsFullyVisible } from "@shared/hooks/use-is-fully-visible";
import { cn, Heading } from "@tfs-ucmp/ui";
import { motion } from "framer-motion";
import Image from "next/image";
import { useLayoutEffect, useRef } from "react";
import type {
  ImageContainerProps,
  NavigationDotsProps,
  SingleSlideCarouselProps,
  SlideContentProps,
  TextContainerProps,
  TextContentProps,
} from "./types";

export function SlideContent({ slide }: SlideContentProps) {
  return (
    <div className="h-full w-full">
      <div className="flex h-full w-full flex-col sm:hidden">
        <div className="relative h-50 w-full shrink-0">
          <Image
            alt={slide.title}
            className="object-cover"
            fill
            priority
            sizes="100vw"
            src={slide.image}
          />
        </div>
        <div className="flex-1 bg-[color:var(--color-core-surfaces-foreground)]" />
      </div>

      <div className="relative hidden h-full w-full sm:block">
        <Image
          alt={slide.title}
          className="object-cover"
          fill
          priority
          sizes="100vw"
          src={slide.image}
        />
      </div>
    </div>
  );
}

export function TextContent({ slide }: TextContentProps) {
  return (
    <div className="h-full w-full">
      <div className="flex h-full w-full flex-col sm:hidden">
        <div className="h-50 w-full shrink-0" />
        <div className="flex flex-1 flex-col justify-start px-[var(--spacing-lg)] pt-[var(--spacing-lg)] text-center text-[color:var(--color-core-surfaces-card)]">
          <Heading
            className="mb-[var(--spacing-lg)] text-[length:var(--font-size-lg)] uppercase will-change-transform md:text-[length:var(--text-xl)]"
            level={2}
            weight="bold"
          >
            {slide.title}
          </Heading>
          <p className="mb-[var(--spacing-lg)] text-[length:var(--text-sm)] leading-relaxed will-change-transform">
            {slide.subtitle}
          </p>
          <div className="will-change-transform">
            <AppButton
              onClick={() => {
                // TODO: wire up slide CTA action
              }}
              size="md"
              variant="primary"
            >
              {slide.ctaText}
            </AppButton>
          </div>
        </div>
      </div>

      <div className="relative hidden h-full w-full sm:block">
        <div className="absolute inset-0 flex w-1/2 flex-col items-start justify-center gap-[var(--spacing-xl)] px-[var(--spacing-2xl)] text-[color:var(--color-core-surfaces-card)] lg:px-[var(--spacing-3xl)] xl:w-[40%]">
          <Heading
            className="text-[length:var(--font-size-lg)] uppercase leading-tight will-change-transform lg:text-[length:var(--font-size-2xl)]"
            level={2}
            weight="bold"
          >
            {slide.title}
          </Heading>
          <p className="font-semibold text-sm leading-relaxed will-change-transform lg:text-base">
            {slide.subtitle}
          </p>
          <div className="will-change-transform">
            <AppButton
              onClick={() => {
                // TODO: wire up slide CTA action
              }}
              size="md"
              variant="primary"
            >
              {slide.ctaText}
            </AppButton>
          </div>
        </div>
      </div>
    </div>
  );
}

export function ImageContainer({ style, zIndex, slide }: ImageContainerProps) {
  const ref = useRef<HTMLDivElement | null>(null);

  useLayoutEffect(() => {
    const el = ref.current;
    if (el) {
      el.style.filter = style.filter ?? "";
      el.style.opacity = String(style.opacity ?? "");
      el.style.transform = style.transform ?? "";
      el.style.transition = style.transition ?? "";
      el.style.zIndex = zIndex == null ? "" : String(zIndex);
    }
  }, [style, zIndex]);

  return (
    <div className="absolute inset-0 will-change-transform" ref={ref}>
      <SlideContent slide={slide} />
    </div>
  );
}

export function TextContainer({ style, zIndex, isActive, slide }: TextContainerProps) {
  const ref = useRef<HTMLDivElement | null>(null);
  const pointerClass = isActive ? "pointer-events-auto" : "pointer-events-none";

  useLayoutEffect(() => {
    const el = ref.current;
    if (el) {
      el.style.filter = style.filter ?? "";
      el.style.opacity = String(style.opacity ?? "");
      el.style.transform = style.transform ?? "";
      el.style.transition = style.transition ?? "";
      el.style.zIndex = zIndex == null ? "" : String(zIndex);
    }
  }, [style, zIndex]);

  return (
    <div className={`absolute inset-0 will-change-transform ${pointerClass}`} ref={ref}>
      <TextContent slide={slide} />
    </div>
  );
}

export function GradientOverlays() {
  return (
    <>
      <div className="pointer-events-none absolute inset-x-0 bottom-65 z-[15] h-32 bg-linear-to-b from-transparent to-[color:var(--color-core-surfaces-foreground)] sm:hidden" />
      <div className="pointer-events-none absolute inset-0 z-[15] hidden bg-[linear-gradient(91.94deg,_var(--color-core-surfaces-foreground)_28.21%,_rgba(0,0,0,0)_50.16%)] sm:block" />
    </>
  );
}

export function NavigationDots({ slides, currentIndex, onDotClick }: NavigationDotsProps) {
  return (
    <div className="absolute right-0 bottom-[var(--spacing-lg)] left-0 z-30 flex justify-center gap-[var(--spacing-3)] pt-0 sm:bottom-[var(--spacing-md)]">
      {slides.map((slide, i) => {
        const isActive = i === currentIndex;
        return (
          <button
            aria-label={`Go to slide ${i + 1}`}
            className={cn(
              "relative flex items-center justify-center border-none bg-transparent p-0",
              "h-4 w-4",
              isActive ? "" : "cursor-pointer"
            )}
            key={slide.id}
            onClick={() => onDotClick(i)}
            type="button"
          >
            <span
              className={cn(
                "block h-2 w-2 transition-all",
                "rounded-[var(--radius-md)]",
                isActive
                  ? "bg-[color:var(--color-core-surfaces-card)] ring-1 ring-[color:var(--color-core-surfaces-card)] ring-offset-2 ring-offset-[color:var(--color-core-surfaces-foreground)]"
                  : "bg-[color:var(--color-core-surfaces-card)]/40 hover:bg-[color:var(--color-core-surfaces-card)]/60"
              )}
            />
          </button>
        );
      })}
    </div>
  );
}

export function SingleSlideCarousel({ className, slide }: SingleSlideCarouselProps) {
  const { ref: carouselRef, isFullyVisible } = useIsFullyVisible<HTMLDivElement>();

  return (
    <motion.div
      animate={{ opacity: isFullyVisible ? 1 : 0 }}
      className={cn("relative w-full", className)}
      initial={{ opacity: 0 }}
      ref={carouselRef}
      transition={{ duration: 0.6 }}
    >
      <div className="relative h-115 w-full overflow-hidden rounded-[var(--radius-xl)] sm:h-100 lg:h-125">
        <SlideContent slide={slide} />
        <GradientOverlays />
        <div className="absolute inset-0 z-[25]">
          <TextContent slide={slide} />
        </div>
      </div>
    </motion.div>
  );
}
