"use client";

import { useIsFullyVisible } from "@shared/hooks/use-is-fully-visible";
import { cn } from "@tfs-ucmp/ui";
import { motion } from "framer-motion";
import { useEffect, useMemo } from "react";
import { customerJourneySlides } from "./carousel-data";
import {
  GradientOverlays,
  ImageContainer,
  NavigationDots,
  SingleSlideCarousel,
  TextContainer,
} from "./carousel-sub-components";
import { SLIDE_INTERVAL } from "./constants";
import type { AnimatingCarouselProps } from "./types";
import { useContainerStyles, useSlideTransition } from "./use-slide-transition";

export function CustomerJourneyCarousel({ className, flags }: AnimatingCarouselProps) {
  const { showPrequalifyBanner, showTestDriveBanner, showTradeInBanner } = flags;

  const filteredSlides = useMemo(() => {
    return customerJourneySlides.filter((slide) => {
      if (slide.id === "prequalify" && !showPrequalifyBanner) {
        return false;
      }
      if (slide.id === "trade-in" && !showTradeInBanner) {
        return false;
      }
      if (slide.id === "test-drive" && !showTestDriveBanner) {
        return false;
      }
      return true;
    });
  }, [showPrequalifyBanner, showTestDriveBanner, showTradeInBanner]);

  const numSlides = filteredSlides.length;

  const containerStyles = useContainerStyles();

  const {
    containerAIndex,
    containerBIndex,
    activeContainer,
    currentVisibleIndex,
    goToSlide,
    isAnimatingRef,
  } = useSlideTransition({
    containerStyles,
    numSlides,
  });

  const { containerAStyle, containerBStyle, textAStyle, textBStyle } = containerStyles;

  const { ref: carouselRef, isFullyVisible } = useIsFullyVisible<HTMLDivElement>();

  // Auto-advance timer — only runs when fully visible
  useEffect(() => {
    if (numSlides <= 1 || !isFullyVisible) {
      return;
    }

    const timer = setTimeout(() => {
      if (!isAnimatingRef.current) {
        const current = currentVisibleIndex ?? 0;
        const next = (current + 1) % numSlides;
        goToSlide(next);
      }
    }, SLIDE_INTERVAL);

    return () => clearTimeout(timer);
  }, [currentVisibleIndex, numSlides, goToSlide, isAnimatingRef, isFullyVisible]);

  if (numSlides === 0) {
    return null;
  }

  const firstSlide = filteredSlides[0];
  if (numSlides === 1 && firstSlide) {
    return <SingleSlideCarousel className={className} slide={firstSlide} />;
  }

  const slideA = filteredSlides[containerAIndex];
  const slideB = containerBIndex === null ? null : filteredSlides[containerBIndex];

  if (!slideA) {
    return null;
  }

  return (
    <motion.div
      animate={{ opacity: 1 }}
      className={cn("relative w-full rounded-[var(--radius-md)] bg-black", className)}
      initial={{ opacity: 0 }}
      ref={carouselRef}
      transition={{ duration: 0.6 }}
    >
      <div className="relative h-115 w-full overflow-hidden rounded-[var(--radius-xl)] bg-black sm:h-100 lg:h-125">
        <ImageContainer
          slide={slideA}
          style={containerAStyle}
          zIndex={activeContainer === "A" ? 10 : 5}
        />

        {slideB && (
          <ImageContainer
            slide={slideB}
            style={containerBStyle}
            zIndex={activeContainer === "B" ? 10 : 5}
          />
        )}

        <GradientOverlays />

        <TextContainer
          isActive={activeContainer === "A"}
          slide={slideA}
          style={textAStyle}
          zIndex={activeContainer === "A" ? 25 : 20}
        />

        {slideB && (
          <TextContainer
            isActive={activeContainer === "B"}
            slide={slideB}
            style={textBStyle}
            zIndex={activeContainer === "B" ? 25 : 20}
          />
        )}

        <NavigationDots
          currentIndex={currentVisibleIndex}
          onDotClick={goToSlide}
          slides={filteredSlides}
        />
      </div>
    </motion.div>
  );
}
