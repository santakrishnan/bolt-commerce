export const QUICK_LINK_ICON_MAP: Record<string, string> = {
  "arrow-down": "/images/find-vehicle/icon-price-drop.svg",
  badge: "/images/find-vehicle/icon-excellent-deals.svg",
  "price-tag": "/images/find-vehicle/icon-under-20k.svg",
  speedometer: "/images/find-vehicle/icon-low-miles.svg",
};

export const WHITESPACE_REGEX = /\s+/g;
