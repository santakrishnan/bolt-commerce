"use client";

import { resolveFocalImageStyle } from "@shared/lib/hero-image";
import { useLocation } from "@shared/providers/location-provider";
import { cn } from "@tfs-ucmp/ui";
import Image from "next/image";
import type React from "react";
import {
  KNOWN_USER_DESKTOP_BG,
  resolveContainerHeightClass,
  resolveContainerWidthClass,
  resolveObjectPositionClass,
} from "./home-hero-static.config";
import type { HomeHeroStaticProps } from "./types";

function resolveActiveBackground(effectiveKnownUser: boolean, backgroundImage: string): string {
  if (effectiveKnownUser) {
    return KNOWN_USER_DESKTOP_BG;
  }

  return backgroundImage;
}

function resolveActiveFocalPoint(
  effectiveKnownUser: boolean,
  profile: "horizontal" | "vertical",
  backgroundFocalPointHorizontal?: { x?: number; y?: number },
  backgroundFocalPointVertical?: { x?: number; y?: number }
) {
  if (effectiveKnownUser) {
    return undefined;
  }

  if (profile === "vertical") {
    return backgroundFocalPointVertical;
  }

  return backgroundFocalPointHorizontal;
}

function resolveActiveZoom(
  effectiveKnownUser: boolean,
  profile: "horizontal" | "vertical",
  backgroundZoomHorizontal?: number,
  backgroundZoomVertical?: number
): number {
  if (effectiveKnownUser) {
    return 1;
  }

  if (profile === "vertical") {
    return backgroundZoomVertical ?? 1;
  }

  return backgroundZoomHorizontal ?? 1;
}

function clampPercentage(value?: number): number {
  if (typeof value !== "number" || Number.isNaN(value)) {
    return 50;
  }

  return Math.max(0, Math.min(100, value));
}

export function HomeHeroStatic({
  isKnownUser = false,
  useLocationBackground = false,
  bannerHeightClass,
  deviceType = "desktop",
  showFocalDebugOverlay = true,
}: HomeHeroStaticProps): React.JSX.Element {
  const { state: locationState } = useLocation();
  const {
    backgroundImage,
    backgroundFocalPointHorizontal,
    backgroundFocalPointVertical,
    backgroundZoomHorizontal,
    backgroundZoomVertical,
    backgroundImageKey,
  } = locationState;

  const effectiveKnownUser = isKnownUser && !useLocationBackground;
  const isMobileViewport = deviceType === "mobile";
  const activeProfile = isMobileViewport ? "vertical" : "horizontal";

  const activeBg = resolveActiveBackground(effectiveKnownUser, backgroundImage);
  const activeFocalPoint = resolveActiveFocalPoint(
    effectiveKnownUser,
    activeProfile,
    backgroundFocalPointHorizontal,
    backgroundFocalPointVertical
  );
  const composedFocalPoint = activeFocalPoint;
  const activeZoom = resolveActiveZoom(
    effectiveKnownUser,
    activeProfile,
    backgroundZoomHorizontal,
    backgroundZoomVertical
  );
  const imageObjectClass = composedFocalPoint
    ? "object-center"
    : resolveObjectPositionClass(effectiveKnownUser, backgroundImageKey);
  const focalImageStyle = composedFocalPoint
    ? resolveFocalImageStyle(composedFocalPoint, isMobileViewport, activeZoom)
    : undefined;
  const objectPositionStyle = focalImageStyle
    ? {
        objectPosition: focalImageStyle.objectPosition,
        transform: focalImageStyle.transform,
        transformOrigin: focalImageStyle.transformOrigin,
      }
    : undefined;
  const focalCursorStyle = composedFocalPoint
    ? {
        left: `${clampPercentage(composedFocalPoint.x)}%`,
        top: `${clampPercentage(composedFocalPoint.y)}%`,
      }
    : undefined;
  const shouldShowFocalDebugOverlay =
    process.env.NODE_ENV === "development" && showFocalDebugOverlay;

  const containerHeightClass = resolveContainerHeightClass(
    effectiveKnownUser,
    backgroundImageKey,
    bannerHeightClass
  );

  const containerWidthClass = resolveContainerWidthClass(backgroundImageKey);

  return (
    <section aria-label="Hero background" className="absolute inset-0 bg-black">
      <div
        className={cn(
          "absolute overflow-hidden",
          containerWidthClass,
          bannerHeightClass ? "inset-x-0 top-0" : "inset-0",
          containerHeightClass,
          "hero-mobile-vignette relative"
        )}
      >
        <div className="hero-gradient-overlay pointer-events-none absolute inset-0 z-10" />
        <Image
          alt="Hero background"
          className={cn("object-cover", imageObjectClass)}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 100vw, (max-width: 1200px) 90vw, 1200px"
          src={activeBg}
          style={objectPositionStyle}
        />
        {shouldShowFocalDebugOverlay && focalCursorStyle ? (
          <div
            aria-hidden="true"
            className="pointer-events-none absolute z-20 h-7 w-7 -translate-x-1/2 -translate-y-1/2"
            style={focalCursorStyle}
          >
            <span className="absolute inset-0 rounded-full border-2 border-white/95 shadow-[0_0_0_1px_rgba(0,0,0,0.55)]" />
            <span className="absolute top-1/2 left-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white shadow-[0_0_0_1px_rgba(0,0,0,0.55)]" />
            <span className="absolute top-0 left-1/2 h-2 w-px -translate-x-1/2 -translate-y-1/2 bg-white/95 shadow-[0_0_0_1px_rgba(0,0,0,0.4)]" />
            <span className="absolute top-full left-1/2 h-2 w-px -translate-x-1/2 translate-y-[-2px] bg-white/95 shadow-[0_0_0_1px_rgba(0,0,0,0.4)]" />
            <span className="absolute top-1/2 left-0 h-px w-2 -translate-x-1/2 -translate-y-1/2 bg-white/95 shadow-[0_0_0_1px_rgba(0,0,0,0.4)]" />
            <span className="absolute top-1/2 left-full h-px w-2 translate-x-[-2px] -translate-y-1/2 bg-white/95 shadow-[0_0_0_1px_rgba(0,0,0,0.4)]" />
          </div>
        ) : null}
      </div>
    </section>
  );
}
