"use client";

import { ROUTES } from "@config/routes/constants";
import { SearchBar } from "@features/search/components/search-bar/search-bar";
import { MockAutocompleteService } from "@features/search/components/search-bar/services/mock-autocomplete";
import { useSearchNavigation } from "@features/search/hooks/use-search-navigation";
import { usePathname } from "next/navigation";
import { useRef, useState } from "react";

const autocompleteService = new MockAutocompleteService();

export function HomeHeroSearch() {
  const pathname = usePathname();
  const isOnUsedCarsPage = pathname.startsWith(ROUTES.USED_CARS);

  const { navigate } = useSearchNavigation({
    mode: isOnUsedCarsPage ? ("replace" as const) : ("push" as const),
    scroll: !isOnUsedCarsPage,
    recordHistory: !isOnUsedCarsPage,
  });

  const [searchQuery, setSearchQuery] = useState("");
  const prevPathnameRef = useRef(pathname);

  if (prevPathnameRef.current !== pathname) {
    prevPathnameRef.current = pathname;
    setSearchQuery("");
  }

  const handleSearch = () => {
    navigate(searchQuery, { source: "nlp" });
  };

  return (
    <div className="relative w-full lg:w-131">
      <SearchBar
        autocompleteService={autocompleteService}
        config={{
          displayMode: "dropdown",
          withBorder: false,
          placeholder: "SUV under 35K with low miles.",
          customPlaceholder: (
            <>
              SUV under 35K with <span className="font-[var(--font-weight-bold)]">low miles</span>.
            </>
          ),
          showSearchButton: true,
          maxSuggestions: 4,
          lightTheme: true,
          withBackdropBlur: false,
          enableSearchHistory: false,
        }}
        onSubmit={handleSearch}
        onValueChange={setSearchQuery}
        value={searchQuery}
      />
    </div>
  );
}
