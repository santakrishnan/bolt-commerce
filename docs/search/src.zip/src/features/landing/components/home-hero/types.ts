import type { HeroStat } from "@features/landing/services";
import type { HeroDeviceType } from "@shared/lib/device-type";

export interface SavedVehicle {
  image?: string;
  make: string;
  mileage?: number;
  model: string;
  price: number;
  stockNumber?: string;
  vin?: string;
  year: number;
}

export interface TradeInOffer {
  expiresInDays: number;
  make: string;
  model: string;
  offerAmount: number;
  year: number;
}

export interface HomeHeroTitleProps {
  className?: string;
  showSubtitle?: boolean;
  subtitle?: string;
  title?: string;
}

export interface HomeHeroStatsProps {
  stats: HeroStat[];
}

export interface HomeHeroStaticProps {
  /** Optional class to control banner height (mobile/tablet/desktop responsive classes allowed) */
  bannerHeightClass?: string;
  deviceType?: HeroDeviceType;
  isKnownUser?: boolean;
  /** Enable the focal-point debug overlay (dev/staging only) */
  showFocalDebugOverlay?: boolean;
  useLocationBackground?: boolean;
}

export interface HomeHeroKnownUserContentProps {
  bannerTitle?: string;
  isPreQualified?: boolean;
  onAcceptOffer?: () => void;
  onBuyOnline?: () => void;
  onContinueShopping?: () => void;
  onScheduleTestDrive?: () => void;
  preQualifiedVehicle?: SavedVehicle;
  savedVehicle?: SavedVehicle;
  showCards?: boolean;
  showContinueShopping?: boolean;
  showSubtitle?: boolean;
  tradeInOffer?: TradeInOffer;
  userName: string;
}

export interface HomeHeroProps {
  /** Optional banner height to forward to HomeHeroStatic */
  bannerHeightClass?: string;
  deviceType?: HeroDeviceType;
  heightClassName?: boolean | string;
  knownUser?: HomeHeroKnownUserContentProps;
  showSearch?: boolean;
  showStats?: boolean;
  showSubtitle?: boolean;
  subtitle?: string;
  title?: string;
  useLocationBackground?: boolean;
}
