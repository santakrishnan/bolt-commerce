import { AppButton } from "@shared/components/button";
import { Card, CardContent, CardHeader, Heading } from "@tfs-ucmp/ui";
import Image from "next/image";
import type { SavedVehicle, TradeInOffer } from "./types";

const priceFormatter = new Intl.NumberFormat("en-US", {
  currency: "USD",
  minimumFractionDigits: 0,
  style: "currency",
});

function formatPrice(price: number): string {
  return priceFormatter.format(price);
}

interface GreatStartCardProps {
  isPreQualified: boolean;
  onBuyOnline?: () => void;
  savedVehicle: SavedVehicle;
}

export function GreatStartCard({ savedVehicle, isPreQualified, onBuyOnline }: GreatStartCardProps) {
  return (
    <div
      className="w-full space-y-4 md:flex md:min-w-0 md:flex-1 md:flex-col md:space-y-2"
      key="saved-vehicle"
    >
      <Heading
        className="text-[color:var(--color-core-surfaces-card)] text-[length:var(--text-xl)] tracking-wide md:pl-[var(--spacing-md)] md:text-[length:var(--font-size-xs)] lg:text-[length:var(--text-xs)] xl:text-[length:var(--font-size-xl)]"
        level={2}
        weight="semibold"
      >
        Great Start
      </Heading>
      <Card className="w-full overflow-hidden border-0 bg-white md:flex md:flex-1 md:flex-col">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 rounded-t-[var(--radius-xl)] bg-background-light py-[var(--spacing-sm)] pr-[var(--spacing-3)] pl-[var(--spacing-md)] lg:py-[var(--spacing-xs)] lg:pl-[var(--spacing-sm)]">
          {isPreQualified && (
            <div className="flex items-center gap-[var(--spacing-sm)]">
              <Image
                alt="Check"
                height={16}
                src="/images/hero-know-user-content/know-user-icons/Verified-tick.svg"
                width={16}
              />
              <Heading
                className="text-center font-semibold text-[color:var(--color-text-primary)] text-[length:var(--font-size-sm)] leading-normal [leading-trim:both] [text-edge:cap] md:text-[length:var(--font-size-sm)] lg:text-[length:var(--font-size-xs)]"
                level={3}
                weight="normal"
              >
                Pre-Qualified
              </Heading>
            </div>
          )}
          <Heading
            className="text-right text-[length:var(--text-2xs)] text-[var(--color-text-primary)] uppercase leading-normal [leading-trim:both] [text-edge:cap] md:text-[length:var(--text-2xs)]"
            level={3}
            weight="semibold"
          >
            AUTO-FINANCING
          </Heading>
        </CardHeader>
        <CardContent className="flex flex-col gap-y-[var(--spacing-md)] px-[var(--spacing-md)] pb-[var(--spacing-md)] md:flex-1 md:justify-between lg:gap-y-[var(--spacing-sm)] lg:px-[var(--spacing-sm)] lg:pb-[var(--spacing-sm)]">
          <div className="flex items-center justify-center gap-[var(--spacing-xs)]">
            {savedVehicle.image && (
              <div className="relative h-15 w-38 shrink-0 overflow-hidden rounded lg:h-11 lg:w-28">
                <Image
                  alt={`${savedVehicle.year} ${savedVehicle.make} ${savedVehicle.model}`}
                  className="aspect-[75/29] object-contain"
                  fill
                  sizes="(max-width: 1023px) 100vw, 107px"
                  src="/images/hero-know-user-content/know-user-images/card-car.png"
                />
              </div>
            )}
            <div className="flex min-w-0 flex-col justify-center">
              <span className="font-semibold text-[length:var(--text-2xs)] text-[var(--color-text-primary)] capitalize leading-normal [leading-trim:both] [text-edge:cap]">
                Approved Vehicle
              </span>
              <p className="truncate font-bold text-[length:var(--text-md)] text-[var(--color-text-primary)] leading-normal lg:text-[length:var(--text-sm)] xl:text-[length:var(--text-md)]">
                {savedVehicle.year} {savedVehicle.make} {savedVehicle.model}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 items-center gap-[var(--spacing-2xs)] text-[length:var(--text-md)] lg:grid-cols-5 lg:text-[length:var(--text-sm)] xl:text-[length:var(--text-md)]">
            <div>
              <span className="font-semibold text-[length:var(--text-2xs)] text-[var(--color-text-primary)] leading-normal opacity-50 [leading-trim:both] [text-edge:cap]">
                VIN
              </span>
              <p className="truncate font-semibold text-[length:var(--text-xs)] text-[var(--color-text-primary)] leading-normal lg:text-[length:var(--text-xs)]">
                {savedVehicle.stockNumber || "N/A"}
              </p>
            </div>
            <div>
              <span className="font-semibold text-[length:var(--text-2xs)] text-[var(--color-text-primary)] leading-normal opacity-50 [leading-trim:both] [text-edge:cap]">
                Miles
              </span>
              <p className="font-semibold text-[length:var(--text-xs)] text-[var(--color-text-primary)] leading-normal">
                {savedVehicle.mileage?.toLocaleString() || "N/A"}
              </p>
            </div>
            <div>
              <span className="font-semibold text-[length:var(--text-2xs)] text-[var(--color-text-primary)] leading-normal opacity-50 [leading-trim:both] [text-edge:cap]">
                Price
              </span>
              <p className="font-semibold text-[length:var(--text-xs)] text-[var(--color-text-primary)] leading-normal">
                {formatPrice(savedVehicle.price)}
              </p>
            </div>
            <div>
              <span className="font-semibold text-[length:var(--text-2xs)] text-[var(--color-text-primary)] leading-normal opacity-50 [leading-trim:both] [text-edge:cap]">
                Monthly
              </span>
              <p className="font-semibold text-[length:var(--text-xs)] text-[var(--color-text-primary)] leading-normal">
                $468
              </p>
            </div>
            <div>
              <span className="font-semibold text-[length:var(--text-2xs)] text-[var(--color-text-primary)] leading-normal opacity-50 [leading-trim:both] [text-edge:cap]">
                APR
              </span>
              <p className="font-semibold text-[length:var(--text-xs)] text-[var(--color-text-primary)] leading-normal">
                5.49%
              </p>
            </div>
          </div>
          <AppButton onClick={onBuyOnline} size="md" variant="primary">
            Buy Online
          </AppButton>
        </CardContent>
      </Card>
    </div>
  );
}

interface ReadyWhenYouAreCardProps {
  onScheduleTestDrive?: () => void;
  preQualifiedVehicle: SavedVehicle;
}

export function ReadyWhenYouAreCard({
  preQualifiedVehicle,
  onScheduleTestDrive,
}: ReadyWhenYouAreCardProps) {
  return (
    <div
      className="w-full space-y-4 md:flex md:min-w-0 md:flex-1 md:flex-col md:space-y-2"
      key="test-drive"
    >
      <Heading
        className="text-[color:var(--color-core-surfaces-card)] text-[length:var(--text-xl)] tracking-wide md:pl-[var(--spacing-md)] md:text-[length:var(--font-size-xs)] lg:text-[length:var(--text-xs)] xl:text-[length:var(--font-size-xl)]"
        level={2}
        weight="semibold"
      >
        Ready when you are
      </Heading>
      <Card className="w-full overflow-hidden border-0 bg-white md:flex md:flex-1 md:flex-col">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 rounded-t-[var(--radius-xl)] bg-background-light py-[var(--spacing-sm)] pr-[var(--spacing-3)] pl-[var(--spacing-md)] lg:py-[var(--spacing-xs)] lg:pl-[var(--spacing-sm)]">
          <div className="flex items-center gap-[var(--spacing-xs)]">
            <Image
              alt="Calendar"
              className="h-[var(--size-icon-sm)] w-[var(--size-icon-sm)]"
              height={16}
              src="/images/hero-know-user-content/know-user-icons/calendar.svg"
              width={16}
            />
            <Heading
              className="text-center font-semibold text-[length:var(--text-sm)] text-[var(--color-card-title)] leading-normal [leading-trim:both] [text-edge:cap] md:text-[length:var(--text-sm)] lg:text-[length:var(--text-xs)]"
              level={3}
              weight="normal"
            >
              Schedule a Test Drive
            </Heading>
          </div>
          <Heading
            className="text-right font-semibold text-[length:var(--text-2xs)] text-[var(--color-card-title)] uppercase leading-normal [leading-trim:both] [text-edge:cap] md:text-[length:var(--text-2xs)]"
            level={3}
            weight="semibold"
          >
            3 SAVED VEHICLES
          </Heading>
        </CardHeader>
        <CardContent className="flex flex-col gap-[var(--spacing-sm)] p-[var(--spacing-md)] md:flex-1 md:justify-between lg:gap-[var(--spacing-xs)] lg:p-[var(--spacing-sm)]">
          <div className="rounded-[var(--radius-md)] border border-[var(--color-structure-interaction-border-two,rgba(0,0,0,0.1))] px-[var(--spacing-sm)] py-[var(--spacing-xs)]">
            <p className="flex justify-center font-normal text-[length:var(--text-md)] leading-normal md:justify-start lg:text-[length:var(--text-sm)] xl:text-[length:var(--text-md)]">
              <span className="font-semibold text-[var(--color-card-title)]">Pre-Qualified:</span>
              &nbsp;
              <span className="font-normal text-[var(--color-card-title)]">
                {preQualifiedVehicle.year} {preQualifiedVehicle.make} {preQualifiedVehicle.model}
              </span>
            </p>
          </div>
          <div className="flex items-center gap-[var(--spacing-sm)]">
            <Image
              alt="Toyota"
              className="h-[var(--size-avatar-sm)] w-[var(--size-avatar-sm)] shrink-0 lg:h-7 lg:w-7"
              height={32}
              src="/images/garage/Toyota-logo.svg"
              width={32}
            />
            <div className="flex flex-col">
              <p className="font-semibold text-[length:var(--text-md)] text-[var(--color-brand-text-primary)] leading-normal lg:text-[length:var(--text-sm)] xl:text-[length:var(--text-md)]">
                Toyota of Fort Worth, TX 76116
              </p>
              <p className="font-normal text-[length:var(--text-xs)] text-[var(--color-brand-text-secondary)] leading-normal">
                We are ready to schedule your test drive
              </p>
            </div>
          </div>
          <AppButton onClick={onScheduleTestDrive} size="md" variant="secondary">
            Book Test Drive
          </AppButton>
        </CardContent>
      </Card>
    </div>
  );
}

interface DontMissOutCardProps {
  onAcceptOffer?: () => void;
  tradeInOffer: TradeInOffer;
}

export function DontMissOutCard({ tradeInOffer, onAcceptOffer }: DontMissOutCardProps) {
  return (
    <div
      className="w-full space-y-4 md:flex md:min-w-0 md:flex-1 md:flex-col md:space-y-2"
      key="trade-in"
    >
      <Heading
        className="text-[color:var(--color-core-surfaces-card)] text-[length:var(--text-xl)] tracking-wide md:pl-[var(--spacing-md)] md:text-[length:var(--font-size-xs)] lg:text-[length:var(--text-xs)] xl:text-[length:var(--font-size-xl)]"
        level={2}
        weight="semibold"
      >
        Don't miss out
      </Heading>
      <Card className="w-full overflow-hidden border-0 bg-white md:flex md:flex-1 md:flex-col">
        <CardHeader className="flex flex-row items-center gap-[var(--spacing-xs)] space-y-0 rounded-t-[var(--radius-xl)] bg-[#F2F2F2] px-[var(--spacing-md)] py-[var(--spacing-sm)] lg:px-[var(--spacing-sm)] lg:py-[var(--spacing-xs)]">
          <Image
            alt="Trade-in"
            className="h-[var(--size-icon-sm)] w-[var(--size-icon-sm)]"
            height={16}
            src="/images/hero-know-user-content/know-user-icons/trade-in.svg"
            width={16}
          />
          <Heading
            className="font-semibold text-[length:var(--font-size-sm)] text-[var(--color-text-primary)] md:text-[length:var(--font-size-sm)] lg:text-[length:var(--font-size-xs)]"
            level={3}
            weight="normal"
          >
            Trade-In Offer
          </Heading>
        </CardHeader>
        <CardContent className="flex flex-col gap-[var(--spacing-md)] p-[var(--spacing-md)] md:flex-1 md:justify-between lg:gap-[var(--spacing-sm)] lg:p-[var(--spacing-sm)]">
          <div className="flex flex-col gap-[var(--spacing-xs)] rounded-[var(--radius-md)] border border-[var(--color-structure-interaction-border-two,rgba(0,0,0,0.1))] py-[var(--spacing-xs)] lg:gap-[var(--spacing-2xs)] lg:py-[var(--spacing-2xs)]">
            <div className="flex items-center justify-center gap-[var(--spacing-xs)]">
              <p className="font-bold text-[length:var(--font-size-md)] text-[var(--color-card-price)] leading-normal lg:text-[length:var(--font-size-sm)]">
                {formatPrice(tradeInOffer.offerAmount)}
              </p>
              <p className="py-[var(--spacing-2xs)] font-normal text-[length:var(--text-md)] text-[var(--color-card-title)] leading-normal lg:text-[length:var(--text-sm)] xl:text-[length:var(--text-md)]">
                {tradeInOffer.year} {tradeInOffer.make} {tradeInOffer.model}
              </p>
            </div>
            <div className="h-[var(--border-width-1,1px)] bg-[color:var(--color-structure-interaction-border-two)]" />
            <div className="flex items-center justify-around">
              <Image
                alt="Clock"
                className="h-7.5 w-7.5 lg:h-6 lg:w-6"
                height={30}
                src="/images/hero-know-user-content/know-user-icons/clock.svg"
                width={30}
              />
              <p className="py-[var(--spacing-2xs)] font-semibold text-[length:var(--text-md)] text-[var(--color-brand-text-primary)] leading-normal lg:text-[length:var(--text-sm)] xl:text-[length:var(--text-md)]">
                Expires in {tradeInOffer.expiresInDays} days
              </p>
              <p className="font-normal text-[length:var(--text-xs)] text-[var(--color-brand-text-secondary)] leading-normal lg:text-[length:var(--text-2xs)]">
                Don't miss out on this offer!
              </p>
            </div>
          </div>
          <AppButton onClick={onAcceptOffer} size="md" variant="secondary">
            Accept Offer Now
          </AppButton>
        </CardContent>
      </Card>
    </div>
  );
}
