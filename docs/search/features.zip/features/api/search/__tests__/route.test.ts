import { describe, expect, it, vi } from "vitest";

import * as route from "../route";

vi.mock("@features/search/services", () => ({
  searchVehicles: vi.fn(async () => ({ results: [], metadata: {} })),
}));

vi.mock("@features/tracking/lib/server-api", () => ({
  extractForwardHeaders: vi.fn(() => ({})),
}));

// Tests for exported route handlers — ensure behaviors are validated once.
describe("Search route handlers", () => {
  it("GET calls searchVehicles with parsed query", async () => {
    const mockReq: any = {
      url: "http://localhost/api/search?q=toyota&page=3",
      headers: { get: () => null },
    };

    const searchSpy = (await import("@features/search/services")).searchVehicles as any;

    await (route as any).GET(mockReq as any);

    expect(searchSpy).toHaveBeenCalled();
    const calledWith = searchSpy.mock.calls[0][0];
    expect(calledWith.query.query).toBe("toyota");
    expect(calledWith.query.page).toBe(3);
  });

  it("POST merges query and body and calls runMockFacetedSearch", async () => {
    const runMock = vi.fn(() => ({ results: [], metadata: {} }));

    const body = { searchQuery: "ford", updatedSections: ["filters"] };
    const mockReq: any = {
      url: "http://localhost/api/search?page=1&pageSize=5",
      json: async () => body,
    };

    const mockSearch = vi
      .spyOn(await import("@features/search/lib/mock-faceted-search"), "runMockFacetedSearch")
      .mockImplementation(runMock as any);

    await (route as any).POST(mockReq as any);

    expect(mockSearch).toHaveBeenCalled();
    mockSearch.mockRestore();
  });
});
