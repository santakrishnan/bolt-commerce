import { describe, expect, it, vi } from "vitest";

import * as route from "../route";

vi.mock("@features/search/lib/mock-faceted-search", () => ({
  runMockFilterSearch: vi.fn(() => ({ facets: [], counts: {} })),
  defaultFilterState: {},
}));

describe("Filters route", () => {
  it("POST handles empty body and returns result", async () => {
    const req: any = { url: "http://localhost/api/search/filters", json: async () => ({}) };
    const res = await (route as any).POST(req as any);
    expect(res).toBeTruthy();
  });

  it("POST forwards body fields to runMockFilterSearch", async () => {
    const body = {
      filterState: { some: "state" },
      searchQuery: "honda",
      labelFilter: "label-1",
      refineFilters: [{ id: "f" }],
      updatedSections: ["Price"],
      searchId: "s1",
      filterId: "fid",
    };

    const spy = (await import("@features/search/lib/mock-faceted-search"))
      .runMockFilterSearch as any;
    spy.mockImplementationOnce((req: any) => {
      expect(req.searchQuery).toBe("honda");
      expect(req.filterState).toEqual(body.filterState);
      expect(req.labelFilter).toBe("label-1");
      expect(req.updatedSections).toEqual(["Price"]);
      expect(req.searchId).toBe("s1");
      expect(req.filterId).toBe("fid");
      return { facets: [], counts: {} };
    });

    const req: any = { url: "http://localhost/api/search/filters", json: async () => body };
    const res = await (route as any).POST(req as any);
    expect(res).toBeTruthy();
    spy.mockRestore?.();
  });

  it("returns 500 when runMockFilterSearch throws", async () => {
    const spy = (await import("@features/search/lib/mock-faceted-search"))
      .runMockFilterSearch as any;
    spy.mockImplementationOnce(() => {
      throw new Error("boom");
    });

    const req: any = { url: "http://localhost/api/search/filters", json: async () => ({}) };
    const res = await (route as any).POST(req as any);
    expect(res).toBeTruthy();
    spy.mockRestore?.();
  });
});
