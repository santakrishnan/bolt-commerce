/**
 * Autocomplete API Route
 *
 * GET /api/search/autocomplete?q=<query>&max=<maxResults>
 *
 * Returns NLP-aware typeahead suggestions for the search bar.
 * In production this would proxy to a backend NLP/autocomplete service;
 * for now it uses the mock NlpAutocompleteService with the inventory pool.
 */

import {
  generateQuickFilterPills,
  NlpAutocompleteService,
} from "@features/search/components/search-bar/services/nlp-autocomplete";
import type { Suggestion } from "@features/search/components/search-bar/types";
import { getInventoryPool } from "@features/search/lib/mock-faceted-search";
import { type NextRequest, NextResponse } from "next/server";

export interface AutocompleteResponse {
  autoCompletions: Suggestion[];
  quickFilters: string[];
}

export async function GET(request: NextRequest): Promise<NextResponse<AutocompleteResponse>> {
  const { searchParams } = new URL(request.url);
  const query = searchParams.get("q") ?? "";
  const maxResults = Math.min(Number.parseInt(searchParams.get("max") ?? "4", 10) || 4, 10);

  const pool = getInventoryPool();
  const service = new NlpAutocompleteService(pool);

  const autoCompletions = await service.getSuggestions(query, maxResults);
  const quickFilters = generateQuickFilterPills(pool);

  return NextResponse.json({ autoCompletions, quickFilters });
}
