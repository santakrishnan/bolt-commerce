import { describe, expect, it, vi } from "vitest";

import * as route from "../[vin]/route";

vi.mock("@features/vdp/services/vdp.service", () => ({
  fetchVinData: vi.fn(async (vin: string) => ({
    dealerNotes: "Well maintained vehicle.",
    vehicle: {
      vin,
      images: ["/img.jpg"],
      dealer: { dealerId: "dealer-001", name: "Dealer", location: "Addr" },
      year: 2020,
      make: "M",
      model: "X",
      trim: "LE",
    },
    pricing: { currentPrice: 30_000 },
    priceHistory: [],
    history: { vin },
  })),
}));

vi.mock("@features/vdp/services/dealer.service", () => ({
  fetchDealerByVin: vi.fn(async () => ({
    id: "dealer-001",
    name: "Toyota of Fort Worth",
    address: "Fort Worth, TX 76116",
    phone: "(817) 555-0123",
    hours: "Mon-Sat: 9:00 AM - 8:00 PM",
    rating: 4.8,
    dealershipImage: "/images/vdp/dealer.png",
  })),
}));

describe("Dealer route", () => {
  it("returns dealer data assembled from vinData and dealer service", async () => {
    const reqUrl = "http://localhost/api/search/dealer/vin123";
    const req: any = {
      url: reqUrl,
      method: "GET",
      nextUrl: new URL(reqUrl),
      headers: {
        get: (_k: string) => null,
        entries: () => [][Symbol.iterator](),
      },
      cookies: {
        get: (_: string) => undefined,
      },
    };
    const ctx: any = { params: Promise.resolve({ vin: "VIN123" }) };

    const res = await (route as any).GET(req as any, ctx as any);
    expect(res).toBeTruthy();
    const body = await res.json();
    expect(body.data.dealer.id).toBe("dealer-001");
    expect(body.data.vehicleDescription).toBe("Well maintained vehicle.");
    expect(body.data.vehicleImage).toBe("/img.jpg");
  });

  it("calls fetchVinData and fetchDealerByVin in parallel", async () => {
    const reqUrl = "http://localhost/api/search/dealer/vin-parallel";
    const req: any = {
      url: reqUrl,
      method: "GET",
      nextUrl: new URL(reqUrl),
      headers: { get: () => null, entries: () => [][Symbol.iterator]() },
      cookies: { get: () => undefined },
    };
    const ctx: any = { params: Promise.resolve({ vin: "VIN-PAR" }) };

    await (route as any).GET(req as any, ctx as any);

    const vdpSvc = await import("@features/vdp/services/vdp.service");
    const dealerSvc = await import("@features/vdp/services/dealer.service");
    expect(vdpSvc.fetchVinData).toHaveBeenCalled();
    expect(dealerSvc.fetchDealerByVin).toHaveBeenCalled();
  });

  it("returns 400 when vin is missing", async () => {
    const reqUrl = "http://localhost/api/search/dealer/";
    const req: any = {
      url: reqUrl,
      method: "GET",
      nextUrl: new URL(reqUrl),
      headers: { get: () => null, entries: () => [][Symbol.iterator]() },
      cookies: { get: () => undefined },
    };
    const ctx: any = { params: Promise.resolve({ vin: "" }) };

    const res = await (route as any).GET(req as any, ctx as any);
    const body = await res.json();
    expect(body.error).toBe("VIN is required");
  });
});
