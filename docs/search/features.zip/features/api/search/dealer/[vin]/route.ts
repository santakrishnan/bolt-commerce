import { extractArrowIds, extractForwardHeaders } from "@features/tracking/lib/server-api";
import { fetchDealerByVin } from "@features/vdp/services/dealer.service";
import { fetchVinData } from "@features/vdp/services/vdp.service";
import type { DealerNotes } from "@shared/data/dealer/dealer-data";
import { type NextRequest, NextResponse } from "next/server";

const isDev = process.env.NODE_ENV === "development";
function noop() {
  /* no-op */
}
const log = isDev ? console.log.bind(console, "[SearchDealerAPI]") : noop;

interface RouteContext {
  params: Promise<{ vin: string }>;
}

export async function GET(request: NextRequest, context: RouteContext) {
  try {
    const { vin } = await context.params;
    log("REQ", {
      method: request.method,
      path: request.nextUrl.pathname,
      vin,
      sessionId: request.headers.get("x-arrow-session-id"),
      fingerprintId: request.headers.get("x-arrow-fp-id"),
      profileId: request.headers.get("x-arrow-profile-id"),
    });

    if (!vin) {
      log("RES", { status: 400, code: "MISSING_VIN" });
      return NextResponse.json(
        { data: null, error: "VIN is required", code: "MISSING_VIN" },
        { status: 400 }
      );
    }

    const ids = extractArrowIds(request);
    const forwardHeaders = extractForwardHeaders(request);
    const [vinData, dealerInfo] = await Promise.all([
      fetchVinData(vin, { ids, forwardHeaders }),
      fetchDealerByVin(vin, { forwardHeaders }),
    ]);
    const dealerData: DealerNotes = {
      vehicleDescription: vinData.dealerNotes,
      vehicleImage: vinData.vehicle.images[0] ?? "/images/vdp/dealer_info.png",
      dealer: dealerInfo,
    };
    log("RES", {
      status: 200,
      vin,
      dealerId: dealerData.dealer.id,
      dealerName: dealerData.dealer.name,
      vehicleImage: dealerData.vehicleImage,
    });

    return NextResponse.json({ data: dealerData });
  } catch (error) {
    console.error("[SearchDealerAPI] GET error:", error);
    return NextResponse.json(
      { data: null, error: "Failed to fetch dealer details", code: "INTERNAL_ERROR" },
      { status: 500 }
    );
  }
}
