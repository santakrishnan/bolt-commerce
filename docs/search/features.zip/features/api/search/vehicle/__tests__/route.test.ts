import { describe, expect, it, vi } from "vitest";

import * as route from "../[id]/route";

vi.mock("@features/vdp/services/vdp.service", () => ({
  fetchVinData: vi.fn(async (id: string) => ({
    vehicle: { id, vin: id, make: "Make", model: "Model" },
  })),
}));

describe("Vehicle route", () => {
  it("GET calls fetchVinData and returns data", async () => {
    const reqUrl = "http://localhost/api/search/vehicle/vid123";
    const req: any = {
      url: reqUrl,
      method: "GET",
      nextUrl: new URL(reqUrl),
      headers: { get: () => null, entries: () => [][Symbol.iterator]() },
      cookies: { get: (_: string) => undefined },
    };
    const ctx: any = { params: Promise.resolve({ id: "vid123" }) };

    const res = await (route as any).GET(req as any, ctx as any);
    expect(res).toBeTruthy();
  });

  it("returns 400 when id is missing", async () => {
    const reqUrl = "http://localhost/api/search/vehicle/";
    const req: any = {
      url: reqUrl,
      method: "GET",
      nextUrl: new URL(reqUrl),
      headers: { get: () => null, entries: () => [][Symbol.iterator]() },
      cookies: { get: (_: string) => undefined },
    };
    const ctx: any = { params: Promise.resolve({ id: "" }) };

    const res = await (route as any).GET(req as any, ctx as any);
    expect(res).toBeTruthy();
  });

  it("returns 500 when fetchVinData throws", async () => {
    const reqUrl = "http://localhost/api/search/vehicle/errorvin";
    const req: any = {
      url: reqUrl,
      method: "GET",
      nextUrl: new URL(reqUrl),
      headers: { get: () => null, entries: () => [][Symbol.iterator]() },
      cookies: { get: (_: string) => undefined },
    };
    const ctx: any = { params: Promise.resolve({ id: "errorvin" }) };

    const svc = await import("@features/vdp/services/vdp.service");
    const spy = svc.fetchVinData as any;
    spy.mockImplementationOnce(() => {
      throw new Error("boom");
    });

    const res = await (route as any).GET(req as any, ctx as any);
    expect(res).toBeTruthy();
  });

  it("handles forward headers and arrow ids from headers", async () => {
    const reqUrl = "http://localhost/api/search/vehicle/withheaders";
    const req: any = {
      url: reqUrl,
      method: "GET",
      nextUrl: new URL(reqUrl),
      headers: {
        get: (k: string) => {
          if (k === "x-arrow-session-id") {
            return "sess-1";
          }
          if (k === "user-agent") {
            return "UA";
          }
          return null;
        },
        entries: () => [["user-agent", "UA"]][Symbol.iterator](),
      },
      cookies: { get: (_: string) => undefined },
    };
    const ctx: any = { params: Promise.resolve({ id: "withheaders" }) };

    const res = await (route as any).GET(req as any, ctx as any);
    expect(res).toBeTruthy();
  });
});
