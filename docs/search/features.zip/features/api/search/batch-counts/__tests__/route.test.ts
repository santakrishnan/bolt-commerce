import { runMockFacetedSearch } from "@features/search/lib/mock-faceted-search";
import { NextRequest } from "next/server";
import { vi } from "vitest";
import { POST } from "../route";

// Mock the search service
vi.mock("@features/search/lib/mock-faceted-search", () => ({
  runMockFacetedSearch: vi.fn(),
  ALL_FACET_SECTIONS: [],
}));

vi.mock("@features/search/components/filter-sidebar/types", () => ({
  defaultFilterState: {
    selectedPriceQuick: "",
    selectedYearQuick: "",
    selectedMileage: "",
    selectedBodyStyles: [],
    selectedExteriorColors: [],
    selectedInteriorColors: [],
    selectedFuelTypes: [],
    selectedModels: [],
    selectedSafetyFeatures: [],
    selectedComfortFeatures: [],
    selectedTechFeatures: [],
    selectedExteriorFeatures: [],
    selectedPerformanceFeatures: [],
    selectedSeatingCapacity: [],
    selectedDrivetrains: [],
    selectedTransmissions: [],
    inspection160: false,
  },
}));

describe("POST /api/search/batch-counts", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("returns counts for multiple queries", async () => {
    // Mock the search function to return different counts
    vi.mocked(runMockFacetedSearch).mockImplementation((request) => {
      const counts: Record<string, number> = {
        "cars-under-$20,000": 1234,
        "shop-excellent-deals": 567,
        "price-drop": 89,
        "low-miles": 432,
      };

      return {
        vehicles: [],
        totalCount: counts[request.searchQuery] ?? 0,
        metadata: {
          searchId: "test-search-id",
          inventorySize: 10_000,
        },
        facets: {
          availableFilters: {},
          facetCounts: {},
        },
      };
    });

    const request = new NextRequest("http://localhost:3000/api/search/batch-counts", {
      method: "POST",
      body: JSON.stringify({
        queries: [
          { id: "under-20k", searchQuery: "cars-under-$20,000" },
          { id: "excellent-deals", searchQuery: "shop-excellent-deals" },
          { id: "price-drop", searchQuery: "price-drop" },
          { id: "low-miles", searchQuery: "low-miles" },
        ],
      }),
    });

    const response = await POST(request);
    const data = await response.json();

    expect(response.status).toBe(200);
    expect(data).toEqual({
      counts: {
        "under-20k": 1234,
        "excellent-deals": 567,
        "price-drop": 89,
        "low-miles": 432,
      },
    });

    // Verify all queries were executed
    expect(runMockFacetedSearch).toHaveBeenCalledTimes(4);
  });

  it("returns 400 for invalid request without queries array", async () => {
    const request = new NextRequest("http://localhost:3000/api/search/batch-counts", {
      method: "POST",
      body: JSON.stringify({}),
    });

    const response = await POST(request);
    const data = await response.json();

    expect(response.status).toBe(400);
    expect(data.error).toContain("queries array is required");
  });

  it("handles empty queries array", async () => {
    const request = new NextRequest("http://localhost:3000/api/search/batch-counts", {
      method: "POST",
      body: JSON.stringify({
        queries: [],
      }),
    });

    const response = await POST(request);
    const data = await response.json();

    expect(response.status).toBe(200);
    expect(data.counts).toEqual({});
    expect(runMockFacetedSearch).not.toHaveBeenCalled();
  });

  it("handles search errors gracefully", async () => {
    vi.mocked(runMockFacetedSearch).mockRejectedValue(new Error("Search failed"));

    const request = new NextRequest("http://localhost:3000/api/search/batch-counts", {
      method: "POST",
      body: JSON.stringify({
        queries: [{ id: "under-20k", searchQuery: "cars-under-$20,000" }],
      }),
    });

    const response = await POST(request);
    const data = await response.json();

    expect(response.status).toBe(500);
    expect(data.error).toBe("Internal server error");
  });
});
