/**
 * Batch Search Counts API Route
 *
 * POST /api/search/batch-counts — Returns vehicle counts for multiple queries in one call
 *
 * This endpoint is optimized for the landing page vehicle finder section,
 * allowing it to fetch counts for all quick-link queries (under-20k, excellent-deals,
 * price-drop, low-miles) in a single request instead of 4 separate calls.
 *
 * Request body:
 * {
 *   "queries": [
 *     { "id": "under-20k", "searchQuery": "cars-under-$20,000" },
 *     { "id": "excellent-deals", "searchQuery": "shop-excellent-deals" },
 *     { "id": "price-drop", "searchQuery": "price-drop" },
 *     { "id": "low-miles", "searchQuery": "low-miles" }
 *   ]
 * }
 *
 * Response:
 * {
 *   "counts": {
 *     "under-20k": 1234,
 *     "excellent-deals": 567,
 *     "price-drop": 89,
 *     "low-miles": 432
 *   }
 * }
 */

import { defaultFilterState } from "@features/search/components/filter-sidebar/types";
import { runMockFacetedSearch } from "@features/search/lib/mock-faceted-search";
import type { SearchRequest } from "@features/search/lib/search-types";
import { type NextRequest, NextResponse } from "next/server";

const isDev = process.env.NODE_ENV === "development";
function noop() {
  /* no-op */
}
const log = isDev ? console.log.bind(console, "[BatchCountsAPI]") : noop;
const logError = console.error.bind(console, "[BatchCountsAPI]");

interface BatchCountQuery {
  id: string;
  searchQuery: string;
}

interface BatchCountRequest {
  queries: BatchCountQuery[];
}

interface BatchCountResponse {
  counts: Record<string, number>;
}

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as BatchCountRequest;

    if (!(body.queries && Array.isArray(body.queries))) {
      return NextResponse.json(
        { error: "Invalid request: queries array is required", code: "INVALID_REQUEST" },
        { status: 400 }
      );
    }

    log(`Fetching counts for ${body.queries.length} queries`);

    // Execute all search queries in parallel
    const countPromises = body.queries.map(async (query) => {
      const searchRequest: SearchRequest = {
        filterState: defaultFilterState,
        searchQuery: query.searchQuery,
        labelFilter: "",
        refineFilters: [],
        sortOption: "recommended",
        page: 1,
        pageSize: 1, // We only need the count, not the actual vehicles
        includeFacets: false,
      };

      const result = await runMockFacetedSearch(searchRequest);
      return {
        id: query.id,
        count: result.totalCount,
      };
    });

    const results = await Promise.all(countPromises);

    // Transform results into a map
    const counts: Record<string, number> = {};
    for (const result of results) {
      counts[result.id] = result.count;
    }

    const response: BatchCountResponse = { counts };

    log("Batch counts result:", counts);

    return NextResponse.json(response);
  } catch (error) {
    logError("POST error:", error);
    return NextResponse.json(
      { error: "Internal server error", code: "INTERNAL_ERROR" },
      { status: 500 }
    );
  }
}
