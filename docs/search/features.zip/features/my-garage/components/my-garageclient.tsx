"use client";

import { buildUsedCarsPath } from "@config/routes";
import { useFavorites } from "@features/favorites";
import { MyGarageCards } from "@features/my-garage/components/my-garage-cards";
import { TestDriveBanner } from "@features/my-garage/components/test-drive-banner";
import { useSearchHistory } from "@features/search";
import { getVehicleEstimation } from "@features/search/lib/mock-vehicles";
import { CarCard } from "@features/vehicle-card";
import { VehiclePreviewModal } from "@features/vehicle-preview";
import type { Vehicle } from "@shared/types";
import { Heading } from "@tfs-ucmp/ui";
import { type ReactNode, useCallback, useEffect, useMemo, useState } from "react";

function parseDealerInfo(miles: string) {
  const parts = miles.split(" - ");
  return { dealerName: parts[0] ?? miles, distance: parts[1] ?? "" };
}

function getBadgeType(
  label: string | undefined
): "excellent" | "priceDrop" | "available" | undefined {
  if (!label) {
    return undefined;
  }
  if (label === "Excellent Price") {
    return "excellent";
  }
  if (label === "Price Drop") {
    return "priceDrop";
  }
  return "available";
}

interface MyGarageClientProps {
  becauseViewedCars?: Vehicle[];
  cars: Vehicle[];
  children?: ReactNode;
  daysRemaining?: number;
  hasTradeInSubmitted?: boolean;
  isFirstTimeVisitor?: boolean;
  isPreQualified?: boolean;
}

export function MyGarageClient({
  cars,
  becauseViewedCars,
  children,
  isPreQualified = false,
  hasTradeInSubmitted = false,
  isFirstTimeVisitor = false,
  daysRemaining = 27,
}: MyGarageClientProps) {
  const [previewVin, setPreviewVin] = useState<string | null>(null);
  const { savedVins, removeVehicle } = useFavorites();
  const { searches, removeSearch, clearAll: clearAllSearches } = useSearchHistory();

  useEffect(() => {
    setPreviewVin(null);
  }, []);

  const recentSearchCards = useMemo(
    () => searches.map((entry) => ({ id: entry.id, search: entry.query, url: entry.url })),
    [searches]
  );

  const savedVehicles = useMemo(
    () =>
      savedVins
        .map((vin) => cars.find((c) => c.vin === vin))
        .filter((car): car is Vehicle => car !== undefined)
        .map((car) => ({
          id: car.vin,
          imageUrl: Array.isArray(car.image) ? (car.image[0] ?? "") : car.image,
          title: car.title,
          price: `$${car.price.toLocaleString()}`,
          miles: car.odometer,
        })),
    [savedVins, cars]
  );

  const priceDropCars = useMemo(() => cars.filter((car) => car.oldPrice), [cars]);

  const handleRemoveSavedVehicle = useCallback(
    (id: number | string) => {
      removeVehicle(String(id));
    },
    [removeVehicle]
  );

  const selectedVehicle = previewVin ? cars.find((c) => c.vin === previewVin) : undefined;

  return (
    <div className="relative min-h-screen">
      <div className="absolute inset-0 z-0 bg-[url('/images/garage/background.svg')] bg-cover bg-position-[center_top] bg-no-repeat" />
      <div className="pointer-events-none absolute inset-0 z-0 bg-[linear-gradient(to_bottom,#F5F5F5_0%,#F5F5F5_350px,rgba(245,245,245,0)_600px,rgba(245,245,245,0)_100%)]" />
      <div className="relative z-0 pt-xl">
        {!isFirstTimeVisitor && (
          <Heading
            className="mx-auto mb-8 w-full max-w-(--container-2xl) px-4 text-left text-lg sm:px-6 md:text-lg lg:px-20"
            level={2}
            weight="semibold"
          >
            My Garage
          </Heading>
        )}

        <div className="mx-auto mb-10 w-full max-w-(--container-2xl) px-4 sm:px-6 lg:px-20">
          {" "}
          <MyGarageCards
            financing={{ prequalified: isPreQualified, daysRemaining }}
            onClearAllSearches={clearAllSearches}
            onRemoveSavedVehicle={handleRemoveSavedVehicle}
            onRemoveSearch={removeSearch}
            onSavedVehicleClick={(id) => setPreviewVin(String(id))}
            recentSearches={recentSearchCards}
            savedVehicles={savedVehicles}
            tradeOffer={{
              imageUrl: hasTradeInSubmitted ? "/images/vehicles/offer.png" : undefined,
              title: hasTradeInSubmitted ? "2019 Audi A7" : undefined,
              price: hasTradeInSubmitted ? "$15,500" : undefined,
              miles: hasTradeInSubmitted ? "68,150 miles" : undefined,
              expiresIn: hasTradeInSubmitted ? "2 days" : undefined,
              hasSubmittedTradeIn: hasTradeInSubmitted,
            }}
          />
          {selectedVehicle &&
            (() => {
              const dealerInfo = parseDealerInfo(selectedVehicle.miles);
              const vdpUrl =
                selectedVehicle.make &&
                selectedVehicle.model &&
                selectedVehicle.variant &&
                selectedVehicle.year &&
                selectedVehicle.vin
                  ? buildUsedCarsPath({
                      type: "details",
                      make: selectedVehicle.make,
                      model: selectedVehicle.model,
                      trim: selectedVehicle.variant,
                      year: selectedVehicle.year,
                      vin: selectedVehicle.vin,
                    })
                  : "#";
              return (
                <VehiclePreviewModal
                  isOpen={!!previewVin}
                  onClose={() => setPreviewVin(null)}
                  vdpUrl={vdpUrl}
                  vehicle={{
                    year: selectedVehicle.year,
                    make: selectedVehicle.make,
                    model: selectedVehicle.model,
                    price: selectedVehicle.price,
                    originalPrice: selectedVehicle.oldPrice ?? 0,
                    condition: selectedVehicle.labels[0] ?? "",
                    warranty: false,
                    inspected: false,
                    miles: selectedVehicle.odometer,
                    drivetrain: "",
                    mpg: "",
                    stock: "",
                    vin: selectedVehicle.vin,
                    exterior: selectedVehicle.extColorName,
                    exteriorColorCode: selectedVehicle.extColorCode,
                    interior: selectedVehicle.intColorName,
                    interiorColorCode: selectedVehicle.intColorCode,
                    dealer: dealerInfo.dealerName,
                    location: dealerInfo.dealerName,
                    distance: dealerInfo.distance,
                    images: Array.isArray(selectedVehicle.image)
                      ? selectedVehicle.image
                      : [selectedVehicle.image],
                    features: [],
                  }}
                  vin={selectedVehicle.vin}
                />
              );
            })()}
        </div>

        <Heading
          className="mx-auto mb-6 w-full max-w-(--container-2xl) px-4 text-left text-xl sm:px-6 md:text-xl lg:px-20"
          level={2}
          weight="semibold"
        >
          Best Matches for you
        </Heading>
        <div className="mx-auto grid max-w-(--container-2xl) grid-cols-1 gap-4 px-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-3 lg:px-20 xl:grid-cols-4">
          {cars.slice(0, 8).map((car, index) => {
            const firstLabel = car.labels[0];
            const { dealerName, distance } = parseDealerInfo(car.miles);
            const estimation = getVehicleEstimation(car);
            const badgeType = getBadgeType(firstLabel);
            return (
              <div className={index >= 6 ? "lg:hidden xl:block" : undefined} key={car.id}>
                <CarCard
                  badge={
                    badgeType && firstLabel ? { type: badgeType, text: firstLabel } : undefined
                  }
                  carImage={car.image}
                  carName={car.title}
                  dealerName={dealerName}
                  distance={distance}
                  estimatedPayment={`Est. ${estimation.estimatedMonthlyPayment}/mo`}
                  estimation={estimation}
                  exteriorColor="White"
                  exteriorColorHex="#FFFFFF"
                  features={{ warranty: true, inspected: true, oneOwner: car.owners === 1 }}
                  interiorColor="Black"
                  interiorColorHex="#000000"
                  make={car.make}
                  matchPercentage={car.match > 0 ? car.match.toString() : undefined}
                  mileage={car.odometer}
                  model={car.model}
                  owners={car.owners}
                  price={`$${car.price.toLocaleString()}`}
                  variant={car.variant}
                  vin={car.vin}
                  wasPrice={car.oldPrice ? `$${car.oldPrice.toLocaleString()}` : undefined}
                  year={car.year}
                />
              </div>
            );
          })}
        </div>

        {children}

        <div className="mx-auto mt-20 mb-10 w-full">
          <TestDriveBanner />
        </div>
        <Heading
          className="mx-auto mb-8 w-full max-w-(--container-2xl) px-4 text-left text-xl sm:px-6 md:text-xl lg:px-20"
          level={2}
          weight="semibold"
        >
          Because You Viewed Toyota Camry
        </Heading>
        <div className="mx-auto mb-16 grid max-w-(--container-2xl) grid-cols-1 gap-4 px-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-3 lg:px-20 xl:grid-cols-4">
          {(becauseViewedCars ?? cars).slice(0, 4).map((car, index) => {
            const badgeLabel = car.labels[0];
            const { dealerName, distance } = parseDealerInfo(car.miles);
            const estimation = getVehicleEstimation(car);
            const badgeType = getBadgeType(badgeLabel);
            return (
              <div className={index >= 3 ? "lg:hidden xl:block" : undefined} key={car.id}>
                <CarCard
                  badge={
                    badgeType && badgeLabel ? { type: badgeType, text: badgeLabel } : undefined
                  }
                  carImage={car.image}
                  carName={car.title}
                  dealerName={dealerName}
                  distance={distance}
                  estimatedPayment={`Est. ${estimation.estimatedMonthlyPayment}/mo`}
                  estimation={estimation}
                  exteriorColor="White"
                  exteriorColorHex="#FFFFFF"
                  features={{ warranty: true, inspected: true, oneOwner: car.owners === 1 }}
                  interiorColor="Black"
                  interiorColorHex="#000000"
                  make={car.make}
                  matchPercentage={car.match > 0 ? String(car.match) : undefined}
                  mileage={car.odometer}
                  model={car.model}
                  owners={car.owners}
                  price={`$${car.price.toLocaleString()}`}
                  variant={car.variant}
                  vin={car.vin}
                  wasPrice={car.oldPrice ? `$${car.oldPrice.toLocaleString()}` : undefined}
                  year={car.year}
                />
              </div>
            );
          })}
        </div>

        <Heading
          className="mx-auto mb-8 w-full max-w-(--container-2xl) px-4 text-left text-xl sm:px-6 md:text-xl lg:px-20"
          level={2}
          weight="semibold"
        >
          Recent Price Drop
        </Heading>
        <div className="mx-auto grid max-w-(--container-2xl) grid-cols-1 gap-4 px-4 pb-16 sm:grid-cols-2 sm:px-6 lg:grid-cols-3 lg:px-20 xl:grid-cols-4">
          {priceDropCars.slice(0, 4).map((car, index) => {
            const { dealerName, distance } = parseDealerInfo(car.miles);
            const estimation = getVehicleEstimation(car);
            return (
              <div className={index >= 3 ? "lg:hidden xl:block" : undefined} key={car.id}>
                <CarCard
                  badge={{ type: "priceDrop", text: "Price Drop" }}
                  carImage={car.image}
                  carName={car.title}
                  dealerName={dealerName}
                  distance={distance}
                  estimatedPayment={`Est. ${estimation.estimatedMonthlyPayment}/mo`}
                  estimation={estimation}
                  exteriorColor="White"
                  exteriorColorHex="#FFFFFF"
                  features={{ warranty: true, inspected: true, oneOwner: car.owners === 1 }}
                  interiorColor="Black"
                  interiorColorHex="#000000"
                  make={car.make}
                  matchPercentage={car.match > 0 ? String(car.match) : undefined}
                  mileage={car.odometer}
                  model={car.model}
                  owners={car.owners}
                  price={`$${car.price.toLocaleString()}`}
                  variant={car.variant}
                  vin={car.vin}
                  wasPrice={`$${car.oldPrice?.toLocaleString()}`}
                  year={car.year}
                />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
