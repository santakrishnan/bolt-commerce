import { render, screen, waitFor } from "@arrow/vitest-config/test-utils";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { MyGarageCards } from "../my-garage-cards";
import {
  FinancingCard,
  RecentSearchCard,
  SavedVehicleCard,
  TestDriveCard,
  TradeOfferCard,
} from "../my-garage-sub-cards";

const REGEX_PATTERNS = {
  TOYOTA_CAMRY: /toyota camry/i,
  REMOVE_SAVED_VEHICLE: /remove saved vehicle/i,
  REMOVE_RECENT_SEARCH: /remove recent search/i,
  GET_STARTED: /get started/i,
  BUY_ONLINE: /buy online/i,
  SEE_MY_OFFER: /see my offer/i,
  EXPIRES_IN_7_DAYS: /expires in 7 days/i,
  EXPIRES_IN_DAYS_DYNAMIC: /expires in \d+ days/i,
  SHOP_WITH_TRADE_IN: /shop with your trade-in/i,
  SCHEDULE_TEST_DRIVE_TODAY: /schedule a test drive today/i,
  BOOK_APPOINTMENT: /book an appointment/i,
  SCHEDULE_TEST_DRIVE: /schedule a test drive/i,
  READY_TO_DRIVE: /ready to drive it/i,
  SAVED_VEHICLES: /saved vehicles/i,
  RECENT_SEARCHES: /recent searches/i,
  KNOW_BUYING_POWER: /know your buying power/i,
  NO_SAVED_VEHICLES: /no saved vehicles yet/i,
  NO_RECENT_SEARCHES: /no recent searches yet/i,
  CLEAR_ALL: /clear all/i,
  TOYOTA_FORT_WORTH: /toyota of fort worth/i,
  TOYOTA_DALLAS: /toyota of dallas/i,
  TOYOTA_CAMRY_2024: /toyota camry 2024/i,
  HONDA_ACCORD_HYBRID: /honda accord hybrid/i,
  FORD_F150_TRUCK: /ford f-150 truck/i,
  SAVED_VEHICLES_COUNT_3: /saved vehicles \(3\)/i,
  RECENT_SEARCHES_COUNT_3: /recent searches \(3\)/i,
  SAVED_VEHICLES_COUNT_1: /saved vehicles \(1\)/i,
  RECENT_SEARCHES_COUNT_1: /recent searches \(1\)/i,
  VIEW_ALL: /view all/i,
} as const;

const MOCK_SAVED_VEHICLE = {
  id: 1,
  imageUrl: "/images/vehicles/car1.jpg",
  title: "2024 Toyota Camry",
  price: "$32,500",
  miles: "15,000 miles",
};

const MOCK_RECENT_SEARCH = {
  id: "search-1",
  search: "Toyota Camry 2024 hybrid fuel efficient",
  url: "/search?q=toyota-camry",
  highlighted: false,
  disabled: false,
};

const MOCK_FINANCING_UNQUALIFIED = {
  prequalified: false,
  onBuyOnline: vi.fn(),
  onGetPrequalified: vi.fn(),
};

const MOCK_FINANCING_QUALIFIED = {
  prequalified: true,
  daysRemaining: 25,
  onBuyOnline: vi.fn(),
  onGetPrequalified: vi.fn(),
};

const MOCK_TRADE_OFFER_WITHOUT = {
  hasSubmittedTradeIn: false,
  onShopWithTradeIn: vi.fn(),
  onGetEstimate: vi.fn(),
};

const MOCK_TRADE_OFFER_WITH = {
  imageUrl: "/images/vehicles/trade-car.jpg",
  title: "2020 Honda Accord",
  price: "$18,000",
  miles: "45,000 miles",
  expiresIn: "7 days",
  hasSubmittedTradeIn: true,
  onShopWithTradeIn: vi.fn(),
  onGetEstimate: vi.fn(),
};

const MOCK_TEST_DRIVE_UNSCHEDULED = {
  scheduled: false,
  dealershipName: "Toyota of Fort Worth",
  onBookAppointment: vi.fn(),
  onScheduleTestDrive: vi.fn(),
};

const MOCK_TEST_DRIVE_SCHEDULED = {
  scheduled: true,
  dealershipName: "Toyota of Dallas",
  onBookAppointment: vi.fn(),
  onScheduleTestDrive: vi.fn(),
};

const mockPush = vi.fn();
const mockRouter = { push: mockPush };

vi.mock("next/navigation", () => ({
  useRouter: () => mockRouter,
  usePathname: vi.fn(() => "/my-garage"),
}));

vi.mock("next/image", () => ({
  default: ({ src, alt, ...props }: any) => (
    <div data-alt={alt} data-src={src} data-testid="mock-image" {...props} />
  ),
}));

vi.mock("next/link", () => ({
  default: ({ href, children, ...props }: any) => (
    <a href={href} {...props}>
      {children}
    </a>
  ),
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({ children, onClick, className, variant, ...props }: any) => (
    <button className={className} data-variant={variant} onClick={onClick} {...props}>
      {children}
    </button>
  ),
  ScrollArea: ({ children, className }: any) => <div className={className}>{children}</div>,
  Dialog: ({ children, open }: any) => (open ? <div role="dialog">{children}</div> : null),
  DialogContent: ({ children }: any) => <div>{children}</div>,
}));

vi.mock("@features/vehicle-preview", () => ({
  VehiclePreviewModal: ({ isOpen, onClose }: any) =>
    isOpen ? (
      <div data-testid="vehicle-preview-modal">
        <button onClick={onClose} type="button">
          Close Preview
        </button>
      </div>
    ) : null,
}));

vi.mock("@features/vehicle-card", () => ({
  GarageInfoCard: ({ heading, children, ctaLabel, onCtaClick, badge }: any) => (
    <div data-testid="garage-info-card">
      {badge && <div data-testid="badge">{badge}</div>}
      <div data-testid="heading">{heading}</div>
      <div data-testid="content">{children}</div>
      {ctaLabel && (
        <button data-testid="cta-button" onClick={onCtaClick} type="button">
          {ctaLabel}
        </button>
      )}
    </div>
  ),
}));

vi.mock("@shared/components/circular-progress", () => ({
  CircularProgress: ({ value, total }: any) => (
    <div data-testid="circular-progress" data-total={total} data-value={value} />
  ),
}));

vi.mock("@shared/components/custom-badge", () => ({
  CustomBadge: ({ type, text, expiresInDays }: any) => (
    <div data-testid="custom-badge" data-type={type}>
      {text || `Expires in ${expiresInDays} days`}
    </div>
  ),
}));

vi.mock("@config/routes", () => ({
  buildVdpPath: vi.fn(({ vin }) => `/used-cars/${vin}`),
}));

vi.mock("@config/routes/constants", () => ({
  ROUTES: {
    FAVORITES: "/favorites",
    TEMP_SAMPLE_VDP: "/coming-soon",
  },
}));

describe("SavedVehicleCard", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders vehicle information", () => {
    render(<SavedVehicleCard {...MOCK_SAVED_VEHICLE} />);

    expect(screen.getByText("2024 Toyota Camry")).toBeInTheDocument();
    expect(screen.getByText("$32,500")).toBeInTheDocument();
    expect(screen.getByText("15,000 miles")).toBeInTheDocument();

    const images = screen.getAllByTestId("mock-image");
    const vehicleImage = images.find((img) => img.getAttribute("data-alt") === "2024 Toyota Camry");
    expect(vehicleImage).toHaveAttribute("data-src", "/images/vehicles/car1.jpg");
  });

  it("calls onClick when card is clicked", async () => {
    const onClick = vi.fn();
    render(<SavedVehicleCard {...MOCK_SAVED_VEHICLE} onClick={onClick} />);

    const card = screen.getByRole("button", { name: REGEX_PATTERNS.TOYOTA_CAMRY });
    card.click();

    await waitFor(() => {
      expect(onClick).toHaveBeenCalledOnce();
    });
  });

  it("calls onRemove when remove button is clicked", async () => {
    const onRemove = vi.fn();
    render(<SavedVehicleCard {...MOCK_SAVED_VEHICLE} onRemove={onRemove} />);

    const removeBtn = screen.getByRole("button", { name: REGEX_PATTERNS.REMOVE_SAVED_VEHICLE });
    removeBtn.click();

    await waitFor(() => {
      expect(onRemove).toHaveBeenCalledOnce();
    });
  });

  it("prevents card click when remove button is clicked", async () => {
    const onClick = vi.fn();
    const onRemove = vi.fn();
    render(<SavedVehicleCard {...MOCK_SAVED_VEHICLE} onClick={onClick} onRemove={onRemove} />);

    const removeBtn = screen.getByRole("button", { name: REGEX_PATTERNS.REMOVE_SAVED_VEHICLE });
    removeBtn.click();

    await waitFor(() => {
      expect(onRemove).toHaveBeenCalledOnce();
      expect(onClick).not.toHaveBeenCalled();
    });
  });

  it("calls onClick when Enter key is pressed", async () => {
    const onClick = vi.fn();
    render(<SavedVehicleCard {...MOCK_SAVED_VEHICLE} onClick={onClick} />);

    const card = screen.getByRole("button", { name: REGEX_PATTERNS.TOYOTA_CAMRY });
    card.focus();
    card.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));

    await waitFor(() => {
      expect(onClick).toHaveBeenCalledOnce();
    });
  });

  it("calls onClick when Space key is pressed", async () => {
    const onClick = vi.fn();
    render(<SavedVehicleCard {...MOCK_SAVED_VEHICLE} onClick={onClick} />);

    const card = screen.getByRole("button", { name: REGEX_PATTERNS.TOYOTA_CAMRY });
    card.focus();
    card.dispatchEvent(new KeyboardEvent("keydown", { key: " ", bubbles: true }));

    await waitFor(() => {
      expect(onClick).toHaveBeenCalledOnce();
    });
  });

  it("does not call onClick for other keys", async () => {
    const onClick = vi.fn();
    render(<SavedVehicleCard {...MOCK_SAVED_VEHICLE} onClick={onClick} />);

    const card = screen.getByRole("button", { name: REGEX_PATTERNS.TOYOTA_CAMRY });
    card.focus();
    card.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab", bubbles: true }));

    await waitFor(() => {
      expect(onClick).not.toHaveBeenCalled();
    });
  });

  it("renders without onClick handler", () => {
    render(<SavedVehicleCard {...MOCK_SAVED_VEHICLE} />);

    expect(screen.getByText("2024 Toyota Camry")).toBeInTheDocument();
  });

  it("renders without onRemove handler", () => {
    render(<SavedVehicleCard {...MOCK_SAVED_VEHICLE} />);

    const removeBtn = screen.getByRole("button", { name: REGEX_PATTERNS.REMOVE_SAVED_VEHICLE });
    expect(removeBtn).toBeInTheDocument();
  });
});

describe("RecentSearchCard", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders search text and link", () => {
    render(<RecentSearchCard {...MOCK_RECENT_SEARCH} />);

    const link = screen.getByRole("link");
    expect(link).toHaveTextContent("Toyota Camry 2024 hybrid fuel efficient");
    expect(link).toHaveAttribute("href", "/search?q=toyota-camry");
  });

  it("truncates long search text", () => {
    const longSearch = {
      ...MOCK_RECENT_SEARCH,
      search: "A".repeat(60),
    };
    render(<RecentSearchCard {...longSearch} />);

    const link = screen.getByRole("link");
    expect(link.textContent).toContain("...");
    expect(link.textContent?.length).toBeLessThan(60);
  });

  it("shows title with full text when truncated", () => {
    const longSearch = {
      ...MOCK_RECENT_SEARCH,
      search: "A".repeat(60),
    };
    render(<RecentSearchCard {...longSearch} />);

    const link = screen.getByRole("link");
    expect(link).toHaveAttribute("title", "A".repeat(60));
  });

  it("calls onRemove when remove button is clicked", async () => {
    const onRemove = vi.fn();
    render(<RecentSearchCard {...MOCK_RECENT_SEARCH} onRemove={onRemove} />);

    const removeBtn = screen.getByRole("button", { name: REGEX_PATTERNS.REMOVE_RECENT_SEARCH });
    removeBtn.click();

    await waitFor(() => {
      expect(onRemove).toHaveBeenCalledOnce();
    });
  });

  it("does not show remove button when disabled", () => {
    render(<RecentSearchCard {...MOCK_RECENT_SEARCH} disabled={true} />);

    const removeBtn = screen.queryByRole("button", { name: REGEX_PATTERNS.REMOVE_RECENT_SEARCH });
    expect(removeBtn).not.toBeInTheDocument();
  });

  it("applies highlighted styling", () => {
    const { container } = render(<RecentSearchCard {...MOCK_RECENT_SEARCH} highlighted={true} />);

    const card = container.querySelector(".text-icon-primary");
    expect(card).toBeInTheDocument();
  });

  it("renders search text with more than 8 words on two lines", () => {
    const longSearch = {
      ...MOCK_RECENT_SEARCH,
      search: "one two three four five six seven eight nine",
    };
    render(<RecentSearchCard {...longSearch} />);

    const link = screen.getByRole("link");
    const spans = link.querySelectorAll("span");
    expect(spans.length).toBe(2);
    expect(spans[0]).toHaveTextContent("one two three four five six seven eight");
    expect(spans[1]).toHaveTextContent("nine");
  });

  it("renders search text with 8 or fewer words on single line", () => {
    const shortSearch = {
      ...MOCK_RECENT_SEARCH,
      search: "one two three four five six seven eight",
    };
    render(<RecentSearchCard {...shortSearch} />);

    const link = screen.getByRole("link");
    const spans = link.querySelectorAll("span");
    expect(spans.length).toBe(0);
    expect(link).toHaveTextContent("one two three four five six seven eight");
  });

  it("renders without onRemove handler", () => {
    const { search, url } = MOCK_RECENT_SEARCH;
    render(<RecentSearchCard id="test" search={search} url={url} />);

    expect(screen.getByRole("link")).toBeInTheDocument();
  });

  it("applies disabled styling when disabled", () => {
    const { container } = render(<RecentSearchCard {...MOCK_RECENT_SEARCH} disabled={true} />);

    const card = container.querySelector(".pointer-events-none");
    expect(card).toBeInTheDocument();
  });
});

describe("FinancingCard", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("when not prequalified", () => {
    it("renders Know Your Buying Power heading", () => {
      render(<FinancingCard {...MOCK_FINANCING_UNQUALIFIED} />);

      expect(screen.getByText("Know Your Buying Power")).toBeInTheDocument();
    });

    it("renders Get Started button", () => {
      render(<FinancingCard {...MOCK_FINANCING_UNQUALIFIED} />);

      expect(screen.getByRole("button", { name: REGEX_PATTERNS.GET_STARTED })).toBeInTheDocument();
    });

    it("calls onGetPrequalified when button clicked", async () => {
      render(<FinancingCard {...MOCK_FINANCING_UNQUALIFIED} />);

      const button = screen.getByRole("button", { name: REGEX_PATTERNS.GET_STARTED });
      button.click();

      await waitFor(() => {
        expect(MOCK_FINANCING_UNQUALIFIED.onGetPrequalified).toHaveBeenCalledOnce();
      });
    });

    it("renders without onGetPrequalified callback", () => {
      render(<FinancingCard prequalified={false} />);

      expect(screen.getByText("Know Your Buying Power")).toBeInTheDocument();
      expect(screen.getByRole("button", { name: REGEX_PATTERNS.GET_STARTED })).toBeInTheDocument();
    });
  });

  describe("when prequalified", () => {
    it("renders Your Financing heading", () => {
      render(<FinancingCard {...MOCK_FINANCING_QUALIFIED} />);

      expect(screen.getByText("Your Financing")).toBeInTheDocument();
    });

    it("renders Pre-qualified badge", () => {
      render(<FinancingCard {...MOCK_FINANCING_QUALIFIED} />);

      expect(screen.getByText("Pre-qualified")).toBeInTheDocument();
    });

    it("renders Buy Online button", () => {
      render(<FinancingCard {...MOCK_FINANCING_QUALIFIED} />);

      expect(screen.getByRole("button", { name: REGEX_PATTERNS.BUY_ONLINE })).toBeInTheDocument();
    });

    it("renders circular progress with days remaining", () => {
      render(<FinancingCard {...MOCK_FINANCING_QUALIFIED} />);

      const progress = screen.getByTestId("circular-progress");
      expect(progress).toHaveAttribute("data-value", "25");
      expect(progress).toHaveAttribute("data-total", "30");
    });

    it("calls onBuyOnline and navigates when button clicked", async () => {
      render(<FinancingCard {...MOCK_FINANCING_QUALIFIED} />);

      const button = screen.getByRole("button", { name: REGEX_PATTERNS.BUY_ONLINE });
      button.click();

      await waitFor(() => {
        expect(MOCK_FINANCING_QUALIFIED.onBuyOnline).toHaveBeenCalledOnce();
        expect(mockPush).toHaveBeenCalledWith(expect.stringContaining("coming-soon"));
      });
    });

    it("renders with default daysRemaining when not provided", () => {
      render(<FinancingCard prequalified={true} />);

      const progress = screen.getByTestId("circular-progress");
      expect(progress).toHaveAttribute("data-value", "30");
      expect(progress).toHaveAttribute("data-total", "30");
    });

    it("navigates even without onBuyOnline callback", async () => {
      render(<FinancingCard daysRemaining={20} prequalified={true} />);

      const button = screen.getByRole("button", { name: REGEX_PATTERNS.BUY_ONLINE });
      button.click();

      await waitFor(() => {
        expect(mockPush).toHaveBeenCalledWith(expect.stringContaining("coming-soon"));
      });
    });
  });
});

describe("TradeOfferCard", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("without submitted trade-in", () => {
    it("renders What's Your Car Worth heading", () => {
      render(<TradeOfferCard {...MOCK_TRADE_OFFER_WITHOUT} />);

      expect(screen.getByText("What's Your Car Worth?")).toBeInTheDocument();
    });

    it("renders See My Offer button", () => {
      render(<TradeOfferCard {...MOCK_TRADE_OFFER_WITHOUT} />);

      expect(screen.getByRole("button", { name: REGEX_PATTERNS.SEE_MY_OFFER })).toBeInTheDocument();
    });

    it("calls onGetEstimate when button clicked", async () => {
      render(<TradeOfferCard {...MOCK_TRADE_OFFER_WITHOUT} />);

      const button = screen.getByRole("button", { name: REGEX_PATTERNS.SEE_MY_OFFER });
      button.click();

      await waitFor(() => {
        expect(MOCK_TRADE_OFFER_WITHOUT.onGetEstimate).toHaveBeenCalledOnce();
      });
    });

    it("renders without onGetEstimate callback", () => {
      render(<TradeOfferCard hasSubmittedTradeIn={false} />);

      expect(screen.getByText("What's Your Car Worth?")).toBeInTheDocument();
      expect(screen.getByRole("button", { name: REGEX_PATTERNS.SEE_MY_OFFER })).toBeInTheDocument();
    });
  });

  describe("with submitted trade-in", () => {
    it("renders Sell/Trade Offer heading", () => {
      render(<TradeOfferCard {...MOCK_TRADE_OFFER_WITH} />);

      expect(screen.getByText("Sell/Trade Offer")).toBeInTheDocument();
    });

    it("renders expiration badge", () => {
      render(<TradeOfferCard {...MOCK_TRADE_OFFER_WITH} />);

      const badge = screen.getByTestId("custom-badge");
      expect(badge).toHaveTextContent(REGEX_PATTERNS.EXPIRES_IN_DAYS_DYNAMIC);
    });

    it("renders vehicle information", () => {
      render(<TradeOfferCard {...MOCK_TRADE_OFFER_WITH} />);

      expect(screen.getByText("2020 Honda Accord")).toBeInTheDocument();
      expect(screen.getByText("$18,000")).toBeInTheDocument();
      expect(screen.getByText("45,000 miles")).toBeInTheDocument();
    });

    it("calls onShopWithTradeIn and navigates when button clicked", async () => {
      render(<TradeOfferCard {...MOCK_TRADE_OFFER_WITH} />);

      const button = screen.getByRole("button", { name: REGEX_PATTERNS.SHOP_WITH_TRADE_IN });
      button.click();

      await waitFor(() => {
        expect(MOCK_TRADE_OFFER_WITH.onShopWithTradeIn).toHaveBeenCalledOnce();
        expect(mockPush).toHaveBeenCalledWith(expect.stringContaining("coming-soon"));
      });
    });

    it("navigates even without onShopWithTradeIn callback", async () => {
      const { onShopWithTradeIn, ...propsWithoutCallback } = MOCK_TRADE_OFFER_WITH;
      render(<TradeOfferCard {...propsWithoutCallback} />);

      const button = screen.getByRole("button", { name: REGEX_PATTERNS.SHOP_WITH_TRADE_IN });
      button.click();

      await waitFor(() => {
        expect(mockPush).toHaveBeenCalledWith(expect.stringContaining("coming-soon"));
      });
    });

    it("falls back to non-submitted state if any required field is missing", () => {
      const incompleteData = {
        hasSubmittedTradeIn: true,
        imageUrl: "/images/vehicles/trade-car.jpg",
        title: "2020 Honda Accord",
      };
      render(<TradeOfferCard {...incompleteData} onGetEstimate={vi.fn()} />);

      expect(screen.getByText("What's Your Car Worth?")).toBeInTheDocument();
    });
  });
});

describe("TestDriveCard", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("when not scheduled", () => {
    it("renders Schedule a Test drive today heading", () => {
      render(<TestDriveCard {...MOCK_TEST_DRIVE_UNSCHEDULED} />);

      expect(screen.getByText(REGEX_PATTERNS.SCHEDULE_TEST_DRIVE_TODAY)).toBeInTheDocument();
    });

    it("renders Book an Appointment button", () => {
      render(<TestDriveCard {...MOCK_TEST_DRIVE_UNSCHEDULED} />);

      expect(
        screen.getByRole("button", { name: REGEX_PATTERNS.BOOK_APPOINTMENT })
      ).toBeInTheDocument();
    });

    it("displays dealership name", () => {
      render(<TestDriveCard {...MOCK_TEST_DRIVE_UNSCHEDULED} />);

      expect(screen.getByText(REGEX_PATTERNS.TOYOTA_FORT_WORTH)).toBeInTheDocument();
    });

    it("calls onBookAppointment when button clicked", async () => {
      render(<TestDriveCard {...MOCK_TEST_DRIVE_UNSCHEDULED} />);

      const button = screen.getByRole("button", { name: REGEX_PATTERNS.BOOK_APPOINTMENT });
      button.click();

      await waitFor(() => {
        expect(MOCK_TEST_DRIVE_UNSCHEDULED.onBookAppointment).toHaveBeenCalledOnce();
      });
    });

    it("renders without onBookAppointment callback", () => {
      render(<TestDriveCard scheduled={false} />);

      expect(screen.getByText(REGEX_PATTERNS.SCHEDULE_TEST_DRIVE_TODAY)).toBeInTheDocument();
      expect(
        screen.getByRole("button", { name: REGEX_PATTERNS.BOOK_APPOINTMENT })
      ).toBeInTheDocument();
    });

    it("uses default dealership name when not provided", () => {
      render(<TestDriveCard scheduled={false} />);

      expect(screen.getByText(REGEX_PATTERNS.TOYOTA_FORT_WORTH)).toBeInTheDocument();
    });
  });

  describe("when scheduled", () => {
    it("renders Ready to Drive it heading", () => {
      render(<TestDriveCard {...MOCK_TEST_DRIVE_SCHEDULED} />);

      expect(screen.getByText(REGEX_PATTERNS.READY_TO_DRIVE)).toBeInTheDocument();
    });

    it("renders Schedule a Test Drive button", () => {
      render(<TestDriveCard {...MOCK_TEST_DRIVE_SCHEDULED} />);

      expect(
        screen.getByRole("button", { name: REGEX_PATTERNS.SCHEDULE_TEST_DRIVE })
      ).toBeInTheDocument();
    });

    it("displays dealership name", () => {
      render(<TestDriveCard {...MOCK_TEST_DRIVE_SCHEDULED} />);

      expect(screen.getByText(REGEX_PATTERNS.TOYOTA_DALLAS)).toBeInTheDocument();
    });

    it("calls onScheduleTestDrive when button clicked", async () => {
      render(<TestDriveCard {...MOCK_TEST_DRIVE_SCHEDULED} />);

      const button = screen.getByRole("button", { name: REGEX_PATTERNS.SCHEDULE_TEST_DRIVE });
      button.click();

      await waitFor(() => {
        expect(MOCK_TEST_DRIVE_SCHEDULED.onScheduleTestDrive).toHaveBeenCalledOnce();
      });
    });

    it("renders without onScheduleTestDrive callback", () => {
      render(<TestDriveCard dealershipName="Toyota of Dallas" scheduled={true} />);

      expect(screen.getByText(REGEX_PATTERNS.READY_TO_DRIVE)).toBeInTheDocument();
      expect(
        screen.getByRole("button", { name: REGEX_PATTERNS.SCHEDULE_TEST_DRIVE })
      ).toBeInTheDocument();
    });
  });
});

describe("MyGarageCards", () => {
  const defaultProps = {
    savedVehicles: [MOCK_SAVED_VEHICLE],
    recentSearches: [MOCK_RECENT_SEARCH],
    financing: MOCK_FINANCING_UNQUALIFIED,
    tradeOffer: MOCK_TRADE_OFFER_WITHOUT,
    testDrive: MOCK_TEST_DRIVE_UNSCHEDULED,
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders all three main sections", () => {
    render(<MyGarageCards {...defaultProps} />);

    expect(screen.getByText(REGEX_PATTERNS.SAVED_VEHICLES)).toBeInTheDocument();
    expect(screen.getByText(REGEX_PATTERNS.RECENT_SEARCHES)).toBeInTheDocument();
    expect(screen.getByText(REGEX_PATTERNS.KNOW_BUYING_POWER)).toBeInTheDocument();
  });

  it("displays saved vehicles count", () => {
    render(<MyGarageCards {...defaultProps} />);

    expect(screen.getByText(REGEX_PATTERNS.SAVED_VEHICLES_COUNT_1)).toBeInTheDocument();
  });

  it("displays recent searches count", () => {
    render(<MyGarageCards {...defaultProps} />);

    expect(screen.getByText(REGEX_PATTERNS.RECENT_SEARCHES_COUNT_1)).toBeInTheDocument();
  });

  it("renders empty state for saved vehicles", () => {
    render(<MyGarageCards {...defaultProps} savedVehicles={[]} />);

    expect(screen.getByText(REGEX_PATTERNS.NO_SAVED_VEHICLES)).toBeInTheDocument();
  });

  it("renders empty state for recent searches", () => {
    render(<MyGarageCards {...defaultProps} recentSearches={[]} />);

    expect(screen.getByText(REGEX_PATTERNS.NO_RECENT_SEARCHES)).toBeInTheDocument();
  });

  it("calls onRemoveSavedVehicle when vehicle removed", async () => {
    const onRemove = vi.fn();
    render(<MyGarageCards {...defaultProps} onRemoveSavedVehicle={onRemove} />);

    const removeBtn = screen.getByRole("button", { name: REGEX_PATTERNS.REMOVE_SAVED_VEHICLE });
    removeBtn.click();

    await waitFor(() => {
      expect(onRemove).toHaveBeenCalledWith(1);
    });
  });

  it("calls onSavedVehicleClick when vehicle clicked", async () => {
    const onClick = vi.fn();
    render(<MyGarageCards {...defaultProps} onSavedVehicleClick={onClick} />);

    const card = screen.getByRole("button", { name: REGEX_PATTERNS.TOYOTA_CAMRY });
    card.click();

    await waitFor(() => {
      expect(onClick).toHaveBeenCalledWith(1);
    });
  });

  it("calls onRemoveSearch when search removed", async () => {
    const onRemove = vi.fn();
    render(<MyGarageCards {...defaultProps} onRemoveSearch={onRemove} />);

    const removeBtn = screen.getByRole("button", { name: REGEX_PATTERNS.REMOVE_RECENT_SEARCH });
    removeBtn.click();

    await waitFor(() => {
      expect(onRemove).toHaveBeenCalledWith("search-1");
    });
  });

  it("calls onClearAllSearches when Clear All clicked", async () => {
    const onClearAll = vi.fn();
    render(<MyGarageCards {...defaultProps} onClearAllSearches={onClearAll} />);

    const clearBtn = screen.getByRole("button", { name: REGEX_PATTERNS.CLEAR_ALL });
    clearBtn.click();

    await waitFor(() => {
      expect(onClearAll).toHaveBeenCalledOnce();
    });
  });

  it("does not show Clear All when no searches", () => {
    render(<MyGarageCards {...defaultProps} recentSearches={[]} />);

    const clearBtn = screen.queryByRole("button", { name: REGEX_PATTERNS.CLEAR_ALL });
    expect(clearBtn).not.toBeInTheDocument();
  });

  it("renders test drive card when provided", () => {
    render(<MyGarageCards {...defaultProps} />);

    expect(screen.getByText(REGEX_PATTERNS.SCHEDULE_TEST_DRIVE_TODAY)).toBeInTheDocument();
  });

  it("does not render test drive card when not provided", () => {
    render(<MyGarageCards {...defaultProps} testDrive={undefined} />);

    expect(screen.queryByText(REGEX_PATTERNS.SCHEDULE_TEST_DRIVE_TODAY)).not.toBeInTheDocument();
  });

  it("renders multiple saved vehicles", () => {
    const multipleVehicles = [
      MOCK_SAVED_VEHICLE,
      { ...MOCK_SAVED_VEHICLE, id: 2, title: "2023 Honda Civic" },
      { ...MOCK_SAVED_VEHICLE, id: 3, title: "2022 Ford Focus" },
    ];

    render(<MyGarageCards {...defaultProps} savedVehicles={multipleVehicles} />);

    expect(screen.getByText("2024 Toyota Camry")).toBeInTheDocument();
    expect(screen.getByText("2023 Honda Civic")).toBeInTheDocument();
    expect(screen.getByText("2022 Ford Focus")).toBeInTheDocument();
    expect(screen.getByText(REGEX_PATTERNS.SAVED_VEHICLES_COUNT_3)).toBeInTheDocument();
  });

  it("renders multiple recent searches", () => {
    const multipleSearches = [
      MOCK_RECENT_SEARCH,
      { ...MOCK_RECENT_SEARCH, id: "search-2", search: "Honda Accord hybrid" },
      { ...MOCK_RECENT_SEARCH, id: "search-3", search: "Ford F-150 truck" },
    ];

    render(<MyGarageCards {...defaultProps} recentSearches={multipleSearches} />);

    expect(screen.getByText(REGEX_PATTERNS.TOYOTA_CAMRY_2024)).toBeInTheDocument();
    expect(screen.getByText(REGEX_PATTERNS.HONDA_ACCORD_HYBRID)).toBeInTheDocument();
    expect(screen.getByText(REGEX_PATTERNS.FORD_F150_TRUCK)).toBeInTheDocument();
    expect(screen.getByText(REGEX_PATTERNS.RECENT_SEARCHES_COUNT_3)).toBeInTheDocument();
  });

  it("renders View All button when one vehicle is saved", () => {
    render(<MyGarageCards {...defaultProps} />);

    expect(screen.getByRole("button", { name: REGEX_PATTERNS.VIEW_ALL })).toBeInTheDocument();
  });

  it("does not render View All button when no vehicles are saved", () => {
    render(<MyGarageCards {...defaultProps} savedVehicles={[]} />);

    expect(screen.queryByRole("button", { name: REGEX_PATTERNS.VIEW_ALL })).not.toBeInTheDocument();
  });

  it("uses the same wrapper and header layout for saved vehicles and recent searches", () => {
    render(<MyGarageCards {...defaultProps} onClearAllSearches={vi.fn()} />);

    const savedSection = screen.getByTestId("saved-vehicles-section");
    const recentSection = screen.getByTestId("recent-searches-section");
    const savedHeader = screen.getByTestId("saved-vehicles-header");
    const recentHeader = screen.getByTestId("recent-searches-header");

    expect(savedSection.className).toBe(recentSection.className);
    expect(savedHeader.className).toBe(recentHeader.className);
  });

  it("renders gradient overlays at bottom of scrollable sections", () => {
    const { container } = render(<MyGarageCards {...defaultProps} />);

    const gradients = container.querySelectorAll('[class*="linear-gradient"]');
    expect(gradients.length).toBeGreaterThanOrEqual(1);
  });

  it("renders dividers between saved vehicle items", () => {
    const multipleVehicles = [
      MOCK_SAVED_VEHICLE,
      { ...MOCK_SAVED_VEHICLE, id: 2, title: "2023 Honda Civic" },
      { ...MOCK_SAVED_VEHICLE, id: 3, title: "2022 Ford Focus" },
    ];

    const { container } = render(
      <MyGarageCards {...defaultProps} savedVehicles={multipleVehicles} />
    );

    const dividers = container.querySelectorAll(".h-px.bg-black.opacity-10");
    expect(dividers.length).toBeGreaterThan(0);
  });

  it("renders dividers between recent search items", () => {
    const multipleSearches = [
      MOCK_RECENT_SEARCH,
      { ...MOCK_RECENT_SEARCH, id: "search-2", search: "Honda Accord hybrid" },
      { ...MOCK_RECENT_SEARCH, id: "search-3", search: "Ford F-150 truck" },
    ];

    const { container } = render(
      <MyGarageCards {...defaultProps} recentSearches={multipleSearches} />
    );

    const dividers = container.querySelectorAll(".h-px.bg-black.opacity-10");
    expect(dividers.length).toBeGreaterThan(0);
  });

  it("renders without optional callbacks", () => {
    render(
      <MyGarageCards
        financing={MOCK_FINANCING_UNQUALIFIED}
        recentSearches={[MOCK_RECENT_SEARCH]}
        savedVehicles={[MOCK_SAVED_VEHICLE]}
        tradeOffer={MOCK_TRADE_OFFER_WITHOUT}
      />
    );

    expect(screen.getByText(REGEX_PATTERNS.SAVED_VEHICLES)).toBeInTheDocument();
    expect(screen.getByText(REGEX_PATTERNS.RECENT_SEARCHES)).toBeInTheDocument();
  });

  it("renders correctly with prequalified financing and submitted trade-in", () => {
    render(
      <MyGarageCards
        {...defaultProps}
        financing={MOCK_FINANCING_QUALIFIED}
        testDrive={MOCK_TEST_DRIVE_SCHEDULED}
        tradeOffer={MOCK_TRADE_OFFER_WITH}
      />
    );

    expect(screen.getByText("Your Financing")).toBeInTheDocument();
    expect(screen.getByText("Sell/Trade Offer")).toBeInTheDocument();
    expect(screen.getByText(REGEX_PATTERNS.READY_TO_DRIVE)).toBeInTheDocument();
  });
});
