import "@testing-library/jest-dom";
import { fireEvent, render, screen, waitFor } from "@arrow/vitest-config/test-utils";
import { beforeEach, describe, expect, it, vi } from "vitest";

import {
  FinancingCard,
  RecentSearchCard,
  SavedVehicleCard,
  TestDriveCard,
  TradeOfferCard,
} from "../my-garage-sub-cards";

const mockPush = vi.fn();

vi.mock("next/navigation", () => ({
  useRouter: () => ({ push: mockPush }),
  usePathname: vi.fn(() => "/my-garage"),
}));

vi.mock("next/image", () => ({
  default: ({ src, alt, className, height, width, ...rest }: any) => (
    // biome-ignore lint/performance/noImgElement: test mock for next/image
    // biome-ignore lint/correctness/useImageSize: explicit dimensions passed via props
    <img
      alt={alt}
      className={className}
      data-height={height}
      data-src={src}
      data-testid="mock-image"
      data-width={width}
      src={src}
      {...rest}
    />
  ),
}));

vi.mock("next/link", () => ({
  default: ({ href, children, className, title, ...rest }: any) => (
    <a className={className} href={href} title={title} {...rest}>
      {children}
    </a>
  ),
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({ children, onClick, className, "aria-label": ariaLabel, ...rest }: any) => (
    <button aria-label={ariaLabel} className={className} onClick={onClick} type="button" {...rest}>
      {children}
    </button>
  ),
}));

vi.mock("@features/vehicle-card", () => ({
  GarageInfoCard: ({ heading, children, ctaLabel, onCtaClick, badge, ctaVariant }: any) => (
    <div data-testid="garage-info-card">
      {badge && <div data-testid="badge">{badge}</div>}
      <div data-testid="heading">{heading}</div>
      <div data-testid="content">{children}</div>
      {ctaLabel && (
        <button
          data-cta-variant={ctaVariant}
          data-testid="cta-button"
          onClick={onCtaClick}
          type="button"
        >
          {ctaLabel}
        </button>
      )}
    </div>
  ),
}));

vi.mock("@shared/components/circular-progress", () => ({
  CircularProgress: ({ value, total }: any) => (
    <div data-testid="circular-progress" data-total={total} data-value={value} />
  ),
}));

vi.mock("@shared/components/custom-badge", () => ({
  CustomBadge: ({ type, text, expiresInDays }: any) => (
    <div data-expires-in-days={expiresInDays} data-testid="custom-badge" data-type={type}>
      {text ?? `Expires in ${expiresInDays} days`}
    </div>
  ),
}));

vi.mock("@config/routes/constants", () => ({
  ROUTES: {
    TEMP_SAMPLE_VDP: "/coming-soon",
  },
}));

const SAVED_VEHICLE = {
  id: 1,
  imageUrl: "/images/cars/camry.jpg",
  title: "2024 Toyota Camry",
  price: "$32,500",
  miles: "12,000 miles",
};

const RECENT_SEARCH = {
  id: "s1",
  search: "Toyota Camry hybrid sedan",
  url: "/search?q=camry",
};

// Regex constants extracted to module level (biome: useTopLevelRegex)
const RE_REMOVE_SAVED = /remove saved vehicle/i;
const RE_CAMRY_TITLE = /2024 toyota camry/i;
const RE_REMOVE_RECENT = /remove recent search/i;
const RE_GET_STARTED = /get started/i;
const RE_UNLOCK_BUYING_POWER = /unlock your buying power/i;
const RE_BUY_ONLINE = /buy online/i;
const RE_MONTHLY_PAYMENTS = /see real monthly payments/i;
const RE_FREE_ESTIMATE = /get a free estimate in minutes/i;
const RE_SEE_MY_OFFER = /see my offer/i;
const RE_SHOP_WITH_TRADE = /shop with your trade-in/i;
const RE_SCHEDULE_DRIVE_TODAY = /schedule a test drive today/i;
const RE_BOOK_APPOINTMENT = /book an appointment/i;
const RE_FORT_WORTH = /toyota of fort worth/i;
const RE_TOYOTA_DALLAS = /toyota of dallas/i;
const RE_TOYOTA_PLANO = /toyota of plano/i;
const RE_READY_TO_DRIVE = /ready to drive it/i;
const RE_SCHEDULE_TEST_DRIVE = /schedule a test drive/i;
const RE_EXPERIENCE_FIRSTHAND = /experience this vehicle firsthand at/i;

describe("SavedVehicleCard", () => {
  beforeEach(() => vi.clearAllMocks());

  it("renders title, price, miles, and image", () => {
    render(<SavedVehicleCard {...SAVED_VEHICLE} />);
    expect(screen.getByText("2024 Toyota Camry")).toBeInTheDocument();
    expect(screen.getByText("$32,500")).toBeInTheDocument();
    expect(screen.getByText("12,000 miles")).toBeInTheDocument();
    const imgs = screen.getAllByTestId("mock-image");
    const vehicleImg = imgs.find((img) => img.getAttribute("alt") === "2024 Toyota Camry");
    expect(vehicleImg).toHaveAttribute("src", "/images/cars/camry.jpg");
  });

  it("renders the remove button with correct aria-label", () => {
    render(<SavedVehicleCard {...SAVED_VEHICLE} />);
    expect(screen.getByRole("button", { name: RE_REMOVE_SAVED })).toBeInTheDocument();
  });

  it("calls onClick when card button is clicked", async () => {
    const onClick = vi.fn();
    render(<SavedVehicleCard {...SAVED_VEHICLE} onClick={onClick} />);
    fireEvent.click(screen.getByRole("button", { name: RE_CAMRY_TITLE }));
    await waitFor(() => expect(onClick).toHaveBeenCalledTimes(1));
  });

  it("calls onRemove when remove button is clicked", async () => {
    const onRemove = vi.fn();
    render(<SavedVehicleCard {...SAVED_VEHICLE} onRemove={onRemove} />);
    fireEvent.click(screen.getByRole("button", { name: RE_REMOVE_SAVED }));
    await waitFor(() => expect(onRemove).toHaveBeenCalledTimes(1));
  });

  it("does not call onClick when remove button is clicked (stopPropagation)", async () => {
    const onClick = vi.fn();
    const onRemove = vi.fn();
    render(<SavedVehicleCard {...SAVED_VEHICLE} onClick={onClick} onRemove={onRemove} />);
    fireEvent.click(screen.getByRole("button", { name: RE_REMOVE_SAVED }));
    await waitFor(() => {
      expect(onRemove).toHaveBeenCalledTimes(1);
      expect(onClick).not.toHaveBeenCalled();
    });
  });

  it("calls onClick when Enter key is pressed on card", async () => {
    const onClick = vi.fn();
    render(<SavedVehicleCard {...SAVED_VEHICLE} onClick={onClick} />);
    const cardBtn = screen.getByRole("button", { name: RE_CAMRY_TITLE });
    fireEvent.keyDown(cardBtn, { key: "Enter" });
    await waitFor(() => expect(onClick).toHaveBeenCalledTimes(1));
  });

  it("calls onClick when Space key is pressed on card", async () => {
    const onClick = vi.fn();
    render(<SavedVehicleCard {...SAVED_VEHICLE} onClick={onClick} />);
    const cardBtn = screen.getByRole("button", { name: RE_CAMRY_TITLE });
    fireEvent.keyDown(cardBtn, { key: " " });
    await waitFor(() => expect(onClick).toHaveBeenCalledTimes(1));
  });

  it("does not call onClick for unhandled keys", async () => {
    const onClick = vi.fn();
    render(<SavedVehicleCard {...SAVED_VEHICLE} onClick={onClick} />);
    const cardBtn = screen.getByRole("button", { name: RE_CAMRY_TITLE });
    fireEvent.keyDown(cardBtn, { key: "Tab" });
    await waitFor(() => expect(onClick).not.toHaveBeenCalled());
  });

  it("renders without onClick or onRemove handlers", () => {
    expect(() => render(<SavedVehicleCard {...SAVED_VEHICLE} />)).not.toThrow();
  });
});

describe("RecentSearchCard", () => {
  beforeEach(() => vi.clearAllMocks());

  it("renders the search text as a link", () => {
    render(<RecentSearchCard {...RECENT_SEARCH} />);
    const link = screen.getByRole("link");
    expect(link).toHaveTextContent("Toyota Camry hybrid sedan");
    expect(link).toHaveAttribute("href", "/search?q=camry");
  });

  it("does not truncate search text at or under 50 characters", () => {
    const search = "A".repeat(50);
    render(<RecentSearchCard id="s2" search={search} url="/search" />);
    const link = screen.getByRole("link");
    expect(link.textContent).not.toContain("...");
    expect(link).not.toHaveAttribute("title");
  });

  it("truncates search text longer than 50 characters and adds ellipsis", () => {
    const search = "A".repeat(51);
    render(<RecentSearchCard id="s3" search={search} url="/search" />);
    const link = screen.getByRole("link");
    expect(link.textContent).toContain("...");
    expect(link.textContent?.length).toBeLessThan(55);
  });

  it("sets title attribute on link when truncated", () => {
    const search = "B".repeat(55);
    render(<RecentSearchCard id="s4" search={search} url="/search" />);
    const link = screen.getByRole("link");
    expect(link).toHaveAttribute("title", search);
  });

  it("does not set title attribute when text is not truncated", () => {
    render(<RecentSearchCard {...RECENT_SEARCH} />);
    expect(screen.getByRole("link")).not.toHaveAttribute("title");
  });

  it("splits text with more than 8 words into two spans", () => {
    const search = "one two three four five six seven eight nine";
    render(<RecentSearchCard id="s5" search={search} url="/search" />);
    const link = screen.getByRole("link");
    const spans = link.querySelectorAll("span");
    expect(spans).toHaveLength(2);
    expect(spans[0]).toHaveTextContent("one two three four five six seven eight");
    expect(spans[1]).toHaveTextContent("nine");
  });

  it("renders text with 8 or fewer words on a single line (no spans)", () => {
    const search = "one two three four five six seven eight";
    render(<RecentSearchCard id="s6" search={search} url="/search" />);
    const link = screen.getByRole("link");
    expect(link.querySelectorAll("span")).toHaveLength(0);
    expect(link).toHaveTextContent(search);
  });

  it("applies text-icon-primary class when highlighted", () => {
    const { container } = render(<RecentSearchCard {...RECENT_SEARCH} highlighted />);
    expect(container.firstChild).toHaveClass("text-icon-primary");
  });

  it("does not apply highlighted class when not highlighted", () => {
    const { container } = render(<RecentSearchCard {...RECENT_SEARCH} highlighted={false} />);
    expect(container.firstChild).not.toHaveClass("text-icon-primary");
  });

  it("applies pointer-events-none class when disabled", () => {
    const { container } = render(<RecentSearchCard {...RECENT_SEARCH} disabled />);
    expect(container.firstChild).toHaveClass("pointer-events-none");
  });

  it("hides remove button when disabled", () => {
    render(<RecentSearchCard {...RECENT_SEARCH} disabled />);
    expect(screen.queryByRole("button", { name: RE_REMOVE_RECENT })).not.toBeInTheDocument();
  });

  it("shows remove button when not disabled", () => {
    render(<RecentSearchCard {...RECENT_SEARCH} />);
    expect(screen.getByRole("button", { name: RE_REMOVE_RECENT })).toBeInTheDocument();
  });

  it("calls onRemove when remove button is clicked", async () => {
    const onRemove = vi.fn();
    render(<RecentSearchCard {...RECENT_SEARCH} onRemove={onRemove} />);
    fireEvent.click(screen.getByRole("button", { name: RE_REMOVE_RECENT }));
    await waitFor(() => expect(onRemove).toHaveBeenCalledTimes(1));
  });

  it("does not throw when onRemove is not provided", () => {
    render(<RecentSearchCard {...RECENT_SEARCH} />);
    expect(() =>
      fireEvent.click(screen.getByRole("button", { name: RE_REMOVE_RECENT }))
    ).not.toThrow();
  });
});

describe("FinancingCard", () => {
  beforeEach(() => vi.clearAllMocks());

  describe("when not prequalified", () => {
    it("renders 'Know Your Buying Power' heading", () => {
      render(<FinancingCard prequalified={false} />);
      expect(screen.getByText("Know Your Buying Power")).toBeInTheDocument();
    });

    it("renders the 'Get Started' CTA button", () => {
      render(<FinancingCard prequalified={false} />);
      expect(screen.getByRole("button", { name: RE_GET_STARTED })).toBeInTheDocument();
    });

    it("renders the verified image", () => {
      render(<FinancingCard prequalified={false} />);
      const imgs = screen.getAllByTestId("mock-image");
      expect(imgs.some((img) => img.getAttribute("alt") === "Verified")).toBe(true);
    });

    it("renders buying power copy text", () => {
      render(<FinancingCard prequalified={false} />);
      expect(screen.getByText(RE_UNLOCK_BUYING_POWER)).toBeInTheDocument();
    });

    it("calls onGetPrequalified when 'Get Started' is clicked", async () => {
      const onGetPrequalified = vi.fn();
      render(<FinancingCard onGetPrequalified={onGetPrequalified} prequalified={false} />);
      fireEvent.click(screen.getByRole("button", { name: RE_GET_STARTED }));
      await waitFor(() => expect(onGetPrequalified).toHaveBeenCalledTimes(1));
    });

    it("does not throw when onGetPrequalified is not provided", () => {
      render(<FinancingCard prequalified={false} />);
      expect(() =>
        fireEvent.click(screen.getByRole("button", { name: RE_GET_STARTED }))
      ).not.toThrow();
    });

    it("does not render a badge", () => {
      render(<FinancingCard prequalified={false} />);
      expect(screen.queryByTestId("badge")).not.toBeInTheDocument();
    });

    it("does not render CircularProgress", () => {
      render(<FinancingCard prequalified={false} />);
      expect(screen.queryByTestId("circular-progress")).not.toBeInTheDocument();
    });
  });

  describe("when prequalified", () => {
    it("renders 'Your Financing' heading", () => {
      render(<FinancingCard prequalified />);
      expect(screen.getByText("Your Financing")).toBeInTheDocument();
    });

    it("renders the Pre-qualified badge", () => {
      render(<FinancingCard prequalified />);
      const badge = screen.getByTestId("custom-badge");
      expect(badge).toHaveTextContent("Pre-qualified");
      expect(badge).toHaveAttribute("data-type", "preQualifies");
    });

    it("renders the 'Buy Online' CTA button", () => {
      render(<FinancingCard prequalified />);
      expect(screen.getByRole("button", { name: RE_BUY_ONLINE })).toBeInTheDocument();
    });

    it("renders CircularProgress with correct daysRemaining value", () => {
      render(<FinancingCard daysRemaining={20} prequalified />);
      const progress = screen.getByTestId("circular-progress");
      expect(progress).toHaveAttribute("data-value", "20");
      expect(progress).toHaveAttribute("data-total", "30");
    });

    it("uses default daysRemaining=30 when not provided", () => {
      render(<FinancingCard prequalified />);
      expect(screen.getByTestId("circular-progress")).toHaveAttribute("data-value", "30");
    });

    it("renders 'You are pre-qualified' sub-text", () => {
      render(<FinancingCard prequalified />);
      expect(screen.getByText("You are pre-qualified")).toBeInTheDocument();
    });

    it("renders monthly payments sub-text", () => {
      render(<FinancingCard prequalified />);
      expect(screen.getByText(RE_MONTHLY_PAYMENTS)).toBeInTheDocument();
    });

    it("calls onBuyOnline and navigates to VDP when 'Buy Online' is clicked", async () => {
      const onBuyOnline = vi.fn();
      render(<FinancingCard onBuyOnline={onBuyOnline} prequalified />);
      fireEvent.click(screen.getByRole("button", { name: RE_BUY_ONLINE }));
      await waitFor(() => {
        expect(onBuyOnline).toHaveBeenCalledTimes(1);
        expect(mockPush).toHaveBeenCalledWith("/coming-soon");
      });
    });

    it("navigates to VDP even when onBuyOnline is not provided", async () => {
      render(<FinancingCard prequalified />);
      fireEvent.click(screen.getByRole("button", { name: RE_BUY_ONLINE }));
      await waitFor(() => expect(mockPush).toHaveBeenCalledWith("/coming-soon"));
    });
  });
});

const TRADE_OFFER_FULL = {
  hasSubmittedTradeIn: true,
  imageUrl: "/images/cars/trade.jpg",
  title: "2020 Honda Accord",
  price: "$18,000",
  miles: "45,000 miles",
  expiresIn: "3 days",
};

describe("TradeOfferCard", () => {
  beforeEach(() => vi.clearAllMocks());

  describe("when trade-in has NOT been submitted", () => {
    it("renders 'What's Your Car Worth?' heading", () => {
      render(<TradeOfferCard hasSubmittedTradeIn={false} />);
      expect(screen.getByText("What's Your Car Worth?")).toBeInTheDocument();
    });

    it("renders the 'See My Offer' CTA button", () => {
      render(<TradeOfferCard hasSubmittedTradeIn={false} />);
      expect(screen.getByRole("button", { name: RE_SEE_MY_OFFER })).toBeInTheDocument();
    });

    it("renders the growth icon", () => {
      render(<TradeOfferCard hasSubmittedTradeIn={false} />);
      const imgs = screen.getAllByTestId("mock-image");
      expect(imgs.some((img) => img.getAttribute("alt") === "Growth")).toBe(true);
    });

    it("renders the estimate copy text", () => {
      render(<TradeOfferCard hasSubmittedTradeIn={false} />);
      expect(screen.getByText(RE_FREE_ESTIMATE)).toBeInTheDocument();
    });

    it("calls onGetEstimate when 'See My Offer' is clicked", async () => {
      const onGetEstimate = vi.fn();
      render(<TradeOfferCard hasSubmittedTradeIn={false} onGetEstimate={onGetEstimate} />);
      fireEvent.click(screen.getByRole("button", { name: RE_SEE_MY_OFFER }));
      await waitFor(() => expect(onGetEstimate).toHaveBeenCalledTimes(1));
    });

    it("does not throw when onGetEstimate is not provided", () => {
      render(<TradeOfferCard hasSubmittedTradeIn={false} />);
      expect(() =>
        fireEvent.click(screen.getByRole("button", { name: RE_SEE_MY_OFFER }))
      ).not.toThrow();
    });

    it("does not render a badge", () => {
      render(<TradeOfferCard hasSubmittedTradeIn={false} />);
      expect(screen.queryByTestId("badge")).not.toBeInTheDocument();
    });
  });

  describe("when trade-in HAS been submitted (all required fields present)", () => {
    it("renders 'Sell/Trade Offer' heading", () => {
      render(<TradeOfferCard {...TRADE_OFFER_FULL} />);
      expect(screen.getByText("Sell/Trade Offer")).toBeInTheDocument();
    });

    it("renders the ExpiresAt badge", () => {
      render(<TradeOfferCard {...TRADE_OFFER_FULL} />);
      const badge = screen.getByTestId("custom-badge");
      expect(badge).toHaveAttribute("data-type", "ExpiresAt");
      expect(badge).toHaveAttribute("data-expires-in-days", "2");
    });

    it("renders vehicle title, price, and miles", () => {
      render(<TradeOfferCard {...TRADE_OFFER_FULL} />);
      expect(screen.getByText("2020 Honda Accord")).toBeInTheDocument();
      expect(screen.getByText("$18,000")).toBeInTheDocument();
      expect(screen.getByText("45,000 miles")).toBeInTheDocument();
    });

    it("renders the trade-in vehicle image", () => {
      render(<TradeOfferCard {...TRADE_OFFER_FULL} />);
      const imgs = screen.getAllByTestId("mock-image");
      const tradeImg = imgs.find((img) => img.getAttribute("alt") === "2020 Honda Accord");
      expect(tradeImg).toHaveAttribute("src", "/images/cars/trade.jpg");
    });

    it("renders the divider line", () => {
      const { container } = render(<TradeOfferCard {...TRADE_OFFER_FULL} />);
      expect(container.querySelector(".h-px.w-full.bg-black.opacity-10")).toBeInTheDocument();
    });

    it("renders the 'Shop With Your Trade-In' CTA button", () => {
      render(<TradeOfferCard {...TRADE_OFFER_FULL} />);
      expect(screen.getByRole("button", { name: RE_SHOP_WITH_TRADE })).toBeInTheDocument();
    });

    it("calls onShopWithTradeIn and navigates when CTA is clicked", async () => {
      const onShopWithTradeIn = vi.fn();
      render(<TradeOfferCard {...TRADE_OFFER_FULL} onShopWithTradeIn={onShopWithTradeIn} />);
      fireEvent.click(screen.getByRole("button", { name: RE_SHOP_WITH_TRADE }));
      await waitFor(() => {
        expect(onShopWithTradeIn).toHaveBeenCalledTimes(1);
        expect(mockPush).toHaveBeenCalledWith("/coming-soon");
      });
    });

    it("navigates even when onShopWithTradeIn is not provided", async () => {
      const { onShopWithTradeIn: _, ...rest } = TRADE_OFFER_FULL as any;
      render(<TradeOfferCard {...rest} />);
      fireEvent.click(screen.getByRole("button", { name: RE_SHOP_WITH_TRADE }));
      await waitFor(() => expect(mockPush).toHaveBeenCalledWith("/coming-soon"));
    });
  });

  describe("falls back to not-submitted state when any required field is missing", () => {
    const cases = [
      { label: "missing imageUrl", props: { ...TRADE_OFFER_FULL, imageUrl: undefined } },
      { label: "missing title", props: { ...TRADE_OFFER_FULL, title: undefined } },
      { label: "missing price", props: { ...TRADE_OFFER_FULL, price: undefined } },
      { label: "missing miles", props: { ...TRADE_OFFER_FULL, miles: undefined } },
      { label: "missing expiresIn", props: { ...TRADE_OFFER_FULL, expiresIn: undefined } },
    ];

    for (const { label, props } of cases) {
      it(`shows 'What's Your Car Worth?' when ${label}`, () => {
        render(<TradeOfferCard {...(props as any)} />);
        expect(screen.getByText("What's Your Car Worth?")).toBeInTheDocument();
      });
    }
  });
});

describe("TestDriveCard", () => {
  beforeEach(() => vi.clearAllMocks());

  describe("when NOT scheduled", () => {
    it("renders 'Schedule a Test drive today.' heading", () => {
      render(<TestDriveCard scheduled={false} />);
      expect(screen.getByText(RE_SCHEDULE_DRIVE_TODAY)).toBeInTheDocument();
    });

    it("renders the 'Book an Appointment' CTA button", () => {
      render(<TestDriveCard scheduled={false} />);
      expect(screen.getByRole("button", { name: RE_BOOK_APPOINTMENT })).toBeInTheDocument();
    });

    it("renders the default dealership name", () => {
      render(<TestDriveCard scheduled={false} />);
      expect(screen.getByText(RE_FORT_WORTH)).toBeInTheDocument();
    });

    it("renders a custom dealership name", () => {
      render(<TestDriveCard dealershipName="Toyota of Dallas" scheduled={false} />);
      expect(screen.getByText(RE_TOYOTA_DALLAS)).toBeInTheDocument();
    });

    it("renders the Toyota logo image", () => {
      render(<TestDriveCard scheduled={false} />);
      const imgs = screen.getAllByTestId("mock-image");
      expect(imgs.some((img) => img.getAttribute("alt") === "Toyota")).toBe(true);
    });

    it("renders the car icon", () => {
      render(<TestDriveCard scheduled={false} />);
      const imgs = screen.getAllByTestId("mock-image");
      expect(imgs.some((img) => img.getAttribute("alt") === "Car")).toBe(true);
    });

    it("calls onBookAppointment when 'Book an Appointment' is clicked", async () => {
      const onBookAppointment = vi.fn();
      render(<TestDriveCard onBookAppointment={onBookAppointment} scheduled={false} />);
      fireEvent.click(screen.getByRole("button", { name: RE_BOOK_APPOINTMENT }));
      await waitFor(() => expect(onBookAppointment).toHaveBeenCalledTimes(1));
    });

    it("does not throw when onBookAppointment is not provided", () => {
      render(<TestDriveCard scheduled={false} />);
      expect(() =>
        fireEvent.click(screen.getByRole("button", { name: RE_BOOK_APPOINTMENT }))
      ).not.toThrow();
    });
  });

  describe("when scheduled", () => {
    it("renders 'Ready to Drive it?' heading", () => {
      render(<TestDriveCard scheduled />);
      expect(screen.getByText(RE_READY_TO_DRIVE)).toBeInTheDocument();
    });

    it("renders the 'Schedule a Test Drive' CTA button", () => {
      render(<TestDriveCard scheduled />);
      expect(screen.getByRole("button", { name: RE_SCHEDULE_TEST_DRIVE })).toBeInTheDocument();
    });

    it("renders the default dealership name in the content", () => {
      render(<TestDriveCard scheduled />);
      expect(screen.getByText(RE_FORT_WORTH)).toBeInTheDocument();
    });

    it("renders a custom dealership name in the content", () => {
      render(<TestDriveCard dealershipName="Toyota of Plano" scheduled />);
      expect(screen.getByText(RE_TOYOTA_PLANO)).toBeInTheDocument();
    });

    it("renders 'Experience this vehicle firsthand at' text", () => {
      render(<TestDriveCard scheduled />);
      expect(screen.getByText(RE_EXPERIENCE_FIRSTHAND)).toBeInTheDocument();
    });

    it("renders the Toyota logo image", () => {
      render(<TestDriveCard scheduled />);
      const imgs = screen.getAllByTestId("mock-image");
      expect(imgs.some((img) => img.getAttribute("alt") === "Toyota")).toBe(true);
    });

    it("calls onScheduleTestDrive when CTA is clicked", async () => {
      const onScheduleTestDrive = vi.fn();
      render(<TestDriveCard onScheduleTestDrive={onScheduleTestDrive} scheduled />);
      fireEvent.click(screen.getByRole("button", { name: RE_SCHEDULE_TEST_DRIVE }));
      await waitFor(() => expect(onScheduleTestDrive).toHaveBeenCalledTimes(1));
    });

    it("does not throw when onScheduleTestDrive is not provided", () => {
      render(<TestDriveCard scheduled />);
      expect(() =>
        fireEvent.click(screen.getByRole("button", { name: RE_SCHEDULE_TEST_DRIVE }))
      ).not.toThrow();
    });
  });
});
