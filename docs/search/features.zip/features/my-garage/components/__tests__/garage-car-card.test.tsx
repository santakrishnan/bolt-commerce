import { render, screen } from "@arrow/vitest-config/test-utils";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { GarageCarCard } from "../garage-car-card";

// ─── Mocks ────────────────────────────────────────────────────────────────────

vi.mock("@features/my-garage/lib/helpers", () => ({
  parseDealerInfo: vi.fn((miles: string) => {
    const parts = miles.split(" - ");
    return { dealerName: parts[0] ?? miles, distance: parts[1] ?? "" };
  }),
  getBadgeType: vi.fn((label: string | undefined) => {
    if (!label) {
      return undefined;
    }
    if (label === "Excellent Price") {
      return "excellent";
    }
    if (label === "Price Drop") {
      return "priceDrop";
    }
    return "available";
  }),
}));

vi.mock("@features/search/lib/mock-vehicles", () => ({
  getVehicleEstimation: vi.fn(() => ({
    estimatedMonthlyPayment: "$450",
    apr: "5.9%",
    creditScore: "700",
    termLength: "60 months",
  })),
}));

vi.mock("@features/vehicle-card", () => ({
  CarCard: (props: any) => (
    <div data-testid="car-card">
      <span data-testid="prop-vin">{props.vin}</span>
      <span data-testid="prop-car-name">{props.carName}</span>
      <span data-testid="prop-price">{props.price}</span>
      <span data-testid="prop-mileage">{props.mileage}</span>
      <span data-testid="prop-make">{props.make}</span>
      <span data-testid="prop-model">{props.model}</span>
      <span data-testid="prop-variant">{props.variant}</span>
      <span data-testid="prop-year">{props.year}</span>
      <span data-testid="prop-dealer-name">{props.dealerName}</span>
      <span data-testid="prop-distance">{props.distance}</span>
      <span data-testid="prop-estimated-payment">{props.estimatedPayment}</span>
      <span data-testid="prop-exterior-color">{props.exteriorColor}</span>
      <span data-testid="prop-interior-color">{props.interiorColor}</span>
      <span data-testid="prop-match">{props.matchPercentage}</span>
      <span data-testid="prop-was-price">{props.wasPrice}</span>
      <span data-testid="prop-badge-type">{props.badge?.type}</span>
      <span data-testid="prop-badge-text">{props.badge?.text}</span>
      <span data-testid="prop-one-owner">{String(props.features?.oneOwner)}</span>
      <span data-testid="prop-owners">{props.owners}</span>
    </div>
  ),
}));

// ─── Fixture ──────────────────────────────────────────────────────────────────

/** Builds a fully-populated Vehicle fixture, merging any provided overrides. */
function buildCar(overrides: Record<string, unknown> = {}) {
  return {
    id: 1,
    vin: "VIN001",
    title: "2024 Toyota Camry",
    make: "Toyota",
    model: "Camry",
    variant: "XSE",
    year: 2024,
    price: 32_000,
    oldPrice: undefined as number | undefined,
    odometer: "12,345 mi",
    miles: "Toyota of Fort Worth - 6.1mi",
    image: "/images/camry.jpg",
    labels: [] as string[],
    match: 0,
    owners: 1,
    bodyType: "Sedan",
    drivetrain: "FWD",
    fuelType: "Gasoline",
    transmission: "Automatic",
    extColorCode: "#FFFFFF",
    extColorName: "White",
    intColorCode: "#000000",
    intColorName: "Black",
    mileage: 12_345,
    inspection160: true,
    seatingCapacity: ["5"],
    features: { comfort: [], exterior: [], performance: [], safety: [], tech: [] },
    warranty: false,
    dealerId: "toyota-plano",
    dealerLocation: "Plano, TX 75001",
    dealerName: "Toyota of Plano",
    mpg: "28-39",
    stock: "STK001",
    ...overrides,
  } as any;
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe("GarageCarCard", () => {
  beforeEach(() => vi.clearAllMocks());

  describe("renders CarCard with correct base props", () => {
    it("renders the CarCard component", () => {
      render(<GarageCarCard car={buildCar()} />);
      expect(screen.getByTestId("car-card")).toBeInTheDocument();
    });

    it("passes vin to CarCard", () => {
      render(<GarageCarCard car={buildCar({ vin: "TESTVINUM" })} />);
      expect(screen.getByTestId("prop-vin")).toHaveTextContent("TESTVINUM");
    });

    it("passes carName (title) to CarCard", () => {
      render(<GarageCarCard car={buildCar()} />);
      expect(screen.getByTestId("prop-car-name")).toHaveTextContent("2024 Toyota Camry");
    });

    it("formats price as $XX,XXX", () => {
      render(<GarageCarCard car={buildCar({ price: 32_000 })} />);
      expect(screen.getByTestId("prop-price")).toHaveTextContent("$32,000");
    });

    it("passes odometer as mileage", () => {
      render(<GarageCarCard car={buildCar({ odometer: "18,500 mi" })} />);
      expect(screen.getByTestId("prop-mileage")).toHaveTextContent("18,500 mi");
    });

    it("passes make, model, variant, year", () => {
      render(<GarageCarCard car={buildCar()} />);
      expect(screen.getByTestId("prop-make")).toHaveTextContent("Toyota");
      expect(screen.getByTestId("prop-model")).toHaveTextContent("Camry");
      expect(screen.getByTestId("prop-variant")).toHaveTextContent("XSE");
      expect(screen.getByTestId("prop-year")).toHaveTextContent("2024");
    });

    it("passes exterior and interior color names", () => {
      render(<GarageCarCard car={buildCar()} />);
      expect(screen.getByTestId("prop-exterior-color")).toHaveTextContent("White");
      expect(screen.getByTestId("prop-interior-color")).toHaveTextContent("Black");
    });

    it("formats estimatedPayment from getVehicleEstimation", () => {
      render(<GarageCarCard car={buildCar()} />);
      expect(screen.getByTestId("prop-estimated-payment")).toHaveTextContent("Est. $450/mo");
    });
  });

  describe("dealer info via parseDealerInfo", () => {
    it("splits miles field into dealerName and distance", () => {
      render(<GarageCarCard car={buildCar({ miles: "Toyota of Dallas - 3.5mi" })} />);
      expect(screen.getByTestId("prop-dealer-name")).toHaveTextContent("Toyota of Dallas");
      expect(screen.getByTestId("prop-distance")).toHaveTextContent("3.5mi");
    });

    it("uses full miles string as dealerName when no separator", () => {
      render(<GarageCarCard car={buildCar({ miles: "NearbyDealer" })} />);
      expect(screen.getByTestId("prop-dealer-name")).toHaveTextContent("NearbyDealer");
      expect(screen.getByTestId("prop-distance")).toHaveTextContent("");
    });
  });

  describe("badge resolution", () => {
    it("uses badgeOverride when provided, ignoring car labels", () => {
      const car = buildCar({ labels: ["Excellent Price"] });
      const override = { type: "available" as const, text: "Custom Badge" };
      render(<GarageCarCard badgeOverride={override} car={car} />);
      expect(screen.getByTestId("prop-badge-type")).toHaveTextContent("available");
      expect(screen.getByTestId("prop-badge-text")).toHaveTextContent("Custom Badge");
    });

    it("derives 'excellent' badge from 'Excellent Price' label when no override", () => {
      render(<GarageCarCard car={buildCar({ labels: ["Excellent Price"] })} />);
      expect(screen.getByTestId("prop-badge-type")).toHaveTextContent("excellent");
      expect(screen.getByTestId("prop-badge-text")).toHaveTextContent("Excellent Price");
    });

    it("derives 'priceDrop' badge from 'Price Drop' label when no override", () => {
      render(<GarageCarCard car={buildCar({ labels: ["Price Drop"] })} />);
      expect(screen.getByTestId("prop-badge-type")).toHaveTextContent("priceDrop");
      expect(screen.getByTestId("prop-badge-text")).toHaveTextContent("Price Drop");
    });

    it("derives 'available' badge from any other non-empty label", () => {
      render(<GarageCarCard car={buildCar({ labels: ["Good Deal"] })} />);
      expect(screen.getByTestId("prop-badge-type")).toHaveTextContent("available");
      expect(screen.getByTestId("prop-badge-text")).toHaveTextContent("Good Deal");
    });

    it("renders no badge when car has no labels and no override", () => {
      render(<GarageCarCard car={buildCar({ labels: [] })} />);
      expect(screen.getByTestId("prop-badge-type")).toHaveTextContent("");
      expect(screen.getByTestId("prop-badge-text")).toHaveTextContent("");
    });

    it("renders no badge when label is undefined", () => {
      render(<GarageCarCard car={buildCar({ labels: [undefined] })} />);
      expect(screen.getByTestId("prop-badge-type")).toHaveTextContent("");
    });
  });

  describe("matchPercentage", () => {
    it("passes matchPercentage as string when match > 0", () => {
      render(<GarageCarCard car={buildCar({ match: 85 })} />);
      expect(screen.getByTestId("prop-match")).toHaveTextContent("85");
    });

    it("omits matchPercentage when match is 0", () => {
      render(<GarageCarCard car={buildCar({ match: 0 })} />);
      expect(screen.getByTestId("prop-match")).toHaveTextContent("");
    });
  });

  describe("wasPrice", () => {
    it("formats wasPrice as $XX,XXX when oldPrice is set", () => {
      render(<GarageCarCard car={buildCar({ oldPrice: 35_000 })} />);
      expect(screen.getByTestId("prop-was-price")).toHaveTextContent("$35,000");
    });

    it("omits wasPrice when oldPrice is undefined", () => {
      render(<GarageCarCard car={buildCar({ oldPrice: undefined })} />);
      expect(screen.getByTestId("prop-was-price")).toHaveTextContent("");
    });
  });

  describe("oneOwner feature flag", () => {
    it("sets oneOwner to true when owners === 1", () => {
      render(<GarageCarCard car={buildCar({ owners: 1 })} />);
      expect(screen.getByTestId("prop-one-owner")).toHaveTextContent("true");
    });

    it("sets oneOwner to false when owners > 1", () => {
      render(<GarageCarCard car={buildCar({ owners: 3 })} />);
      expect(screen.getByTestId("prop-one-owner")).toHaveTextContent("false");
    });
  });
});
