"use client";

import { ROUTES } from "@config/routes/constants";
import { GarageInfoCard } from "@features/vehicle-card";
import { CircularProgress } from "@shared/components/circular-progress";
import { CustomBadge } from "@shared/components/custom-badge";
import { Button } from "@tfs-ucmp/ui";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import type { FC, ReactNode } from "react";

import type {
  FinancingCardProps,
  RecentSearchCardProps,
  SavedVehicleCardProps,
  TestDriveCardProps,
  TradeOfferCardProps,
} from "./types";

/** Splits search text into two lines if longer than 8 words. */
function renderSearchText(text: string): ReactNode {
  const words = text.split(" ");
  if (words.length <= 8) {
    return text;
  }
  return (
    <>
      <span className="block">{words.slice(0, 8).join(" ")}</span>
      <span className="block">{words.slice(8).join(" ")}</span>
    </>
  );
}

export const SavedVehicleCard: FC<SavedVehicleCardProps> = ({
  imageUrl,
  title,
  price,
  miles,
  onRemove,
  onClick,
}) => (
  <button
    className="relative flex w-full cursor-pointer items-center gap-3 rounded py-4 text-left"
    onClick={onClick}
    onKeyDown={(e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        onClick?.();
      }
    }}
    type="button"
  >
    <Image
      alt={title}
      className="h-10 w-16 rounded object-cover"
      height={40}
      src={imageUrl}
      width={64}
    />
    <div className="flex flex-1 flex-col">
      <span className="font-semibold text-sm">{title}</span>
      <span className="text-icon-primary text-xs">{price}</span>
      <span className="text-gray-500 text-xs">{miles}</span>
    </div>
    <Button
      aria-label="Remove saved vehicle"
      className="ml-2 h-10 w-10 rounded-full text-black hover:bg-transparent hover:text-icon-primary focus:bg-transparent active:bg-transparent"
      onClick={(e) => {
        e.stopPropagation();
        onRemove?.();
      }}
      size="icon"
      variant="ghost"
    >
      <picture>
        <source srcSet="/images/garage/cross.svg" type="image/svg+xml" />
        <Image
          alt="Remove"
          className="!w-[10px] !h-[10px]"
          height={10}
          src="/images/garage/cross.svg"
          width={10}
        />
      </picture>
    </Button>
  </button>
);

export const RecentSearchCard: FC<RecentSearchCardProps> = ({
  search,
  url,
  highlighted,
  disabled,
  onRemove,
}) => {
  const truncated = search.length > 50 ? `${search.slice(0, 50)}...` : search;
  const isTruncated = search.length > 50;

  return (
    <div
      className={`group relative flex min-h-[44px] items-center justify-between rounded py-2 transition-colors hover:bg-gray-50 ${
        highlighted ? "text-icon-primary" : ""
      } ${disabled ? "pointer-events-none text-gray-400" : ""}`}
    >
      <Link
        className="flex-1 font-medium text-[#0A0A0A] text-sm hover:underline"
        href={url}
        title={isTruncated ? search : undefined}
      >
        {renderSearchText(truncated)}
      </Link>
      {!disabled && (
        <Button
          aria-label="Remove recent search"
          className="ml-2 h-10 w-10 shrink-0 rounded-full text-gray-400 hover:bg-transparent hover:text-gray-700 focus:bg-transparent active:bg-transparent"
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            onRemove?.();
          }}
          size="icon"
          variant="ghost"
        >
          <picture>
            <source srcSet="/images/garage/cross.svg" type="image/svg+xml" />
            <Image
              alt="Remove"
              className="!w-[10px] !h-[10px]"
              height={10}
              src="/images/garage/cross.svg"
              width={10}
            />
          </picture>
        </Button>
      )}
    </div>
  );
};

export const FinancingCard: FC<FinancingCardProps> = ({
  prequalified,
  daysRemaining = 30,
  onBuyOnline,
  onGetPrequalified,
}) => {
  const router = useRouter();
  if (prequalified) {
    return (
      <GarageInfoCard
        badge={<CustomBadge text="Pre-qualified" type="preQualifies" />}
        ctaLabel="Buy Online"
        ctaVariant="primary"
        heading={
          <div className="flex items-center gap-[var(--spacing-sm,8px)]">
            <Image alt="Dollar icon" height={16} src="/images/garage/Dollar-icon.svg" width={16} />
            <span className="font-semibold text-[length:var(--font-size-md,16px)] text-[var(--color-text-primary,#111)] leading-[130%] [font-family:var(--font-family)] [leading-trim:both] [text-edge:cap]">
              Your Financing
            </span>
          </div>
        }
        onCtaClick={() => {
          onBuyOnline?.();
          router.push(ROUTES.TEMP_SAMPLE_VDP);
        }}
      >
        <div className="flex items-center gap-[var(--spacing-md,16px)]">
          <CircularProgress total={30} value={daysRemaining} />
          <div className="flex flex-col">
            <span className="font-semibold text-[length:var(--font-size-md,16px)] text-[var(--color-text-primary,#111)] leading-[130%] [font-family:var(--font-family)] [leading-trim:both] [text-edge:cap]">
              You are pre-qualified
            </span>
            <span className="text-gray-600">See real monthly payments on every vehicle</span>
          </div>
        </div>
      </GarageInfoCard>
    );
  }

  return (
    <GarageInfoCard
      ctaLabel="Get Started"
      ctaVariant="primary"
      heading={
        <>
          <Image alt="Dollar icon" height={16} src="/images/garage/Dollar-icon.svg" width={16} />
          <span className="text-[length:var(--text-body-lg,18px)]">Know Your Buying Power</span>
        </>
      }
      onCtaClick={onGetPrequalified}
    >
      <div className="flex items-center gap-[var(--spacing-md,16px)]">
        <Image alt="Verified" height={40} src="/images/garage/verified-icon.svg" width={40} />
        <span>
          <span className="block">Unlock your buying power with no credit impact</span>
        </span>
      </div>
    </GarageInfoCard>
  );
};

export const TradeOfferCard: FC<TradeOfferCardProps> = ({
  imageUrl,
  title,
  price,
  miles,
  expiresIn,
  hasSubmittedTradeIn,
  onShopWithTradeIn,
  onGetEstimate,
}) => {
  const router = useRouter();

  if (hasSubmittedTradeIn && imageUrl && title && price && miles && expiresIn) {
    return (
      <GarageInfoCard
        badge={<CustomBadge expiresInDays={2} type="ExpiresAt" />}
        ctaLabel="Shop With Your Trade-In"
        ctaVariant="primary"
        heading={
          <div className="flex items-center gap-[var(--spacing-sm,8px)]">
            <Image alt="Car icon" height={16} src="/images/garage/car.svg" width={16} />
            <span className="text-[length:var(--text-body-lg,18px)]">Sell/Trade Offer</span>
          </div>
        }
        onCtaClick={() => {
          onShopWithTradeIn?.();
          router.push(ROUTES.TEMP_SAMPLE_VDP);
        }}
      >
        <div className="flex flex-col gap-[var(--spacing-md,16px)]">
          <div className="flex items-center justify-between gap-[var(--spacing-lg,24px)]">
            <Image
              alt={title}
              className="aspect-[156/61] rounded object-cover"
              height={61}
              src={imageUrl}
              width={156}
            />
            <div className="flex flex-1 flex-col">
              <span className="font-semibold text-[length:var(--font-size-sm,14px)] text-[var(--color-text-primary,#111)] leading-[130%]">
                {title}
              </span>
              <span className="font-semibold text-[length:var(--font-size-sm,14px)] text-[var(--color-card-price)] leading-normal">
                {price}
              </span>
              <span className="font-semibold text-[length:var(--font-size-sm,14px)] text-[var(--color-text-primary,#111)] leading-[130%]">
                {miles}
              </span>
            </div>
            <Image alt="Arrow icon" height={12} src="/images/garage/Union.svg" width={12} />
          </div>
          <div className="h-px w-full bg-black opacity-10" />
        </div>
      </GarageInfoCard>
    );
  }

  return (
    <GarageInfoCard
      ctaLabel="See My Offer"
      ctaVariant="secondary"
      heading={
        <span className="text-[length:var(--text-body-lg,18px)]">What's Your Car Worth?</span>
      }
      onCtaClick={onGetEstimate}
    >
      <div className="flex items-center gap-[var(--spacing-md,16px)]">
        <Image alt="Growth" height={40} src="/images/garage/growth-icon.svg" width={40} />
        <span>
          <span className="block">
            Get a free estimate in minutes and apply it toward your next vehicle.
          </span>
        </span>
      </div>
    </GarageInfoCard>
  );
};

export const TestDriveCard: React.FC<TestDriveCardProps> = ({
  scheduled,
  dealershipName = "Toyota of Fort Worth",
  onBookAppointment,
  onScheduleTestDrive,
}) => {
  if (scheduled) {
    return (
      <GarageInfoCard
        ctaLabel="Schedule a Test Drive"
        ctaVariant="secondary"
        heading={
          <>
            <Image alt="Car" height={16} src="/images/garage/car.svg" width={18} />
            <span className="text-[length:var(--font-size-lg,18px)]">Ready to Drive it?</span>
          </>
        }
        onCtaClick={onScheduleTestDrive}
      >
        <div className="flex items-center gap-[var(--spacing-md,16px)]">
          <Image alt="Toyota" height={40} src="/images/garage/toyota.svg" width={40} />
          <span>
            <span className="block">Experience this vehicle firsthand at {dealershipName}</span>
          </span>
        </div>
      </GarageInfoCard>
    );
  }

  return (
    <GarageInfoCard
      ctaLabel="Book an Appointment"
      ctaVariant="secondary"
      heading={
        <>
          <Image alt="Car" height={16} src="/images/garage/car.svg" width={18} />
          <span className="text-[length:var(--text-body-lg,18px)]">
            Schedule a Test drive today.
          </span>
        </>
      }
      onCtaClick={onBookAppointment}
    >
      <div className="flex items-center gap-[var(--spacing-md,16px)]">
        <Image alt="Toyota" height={40} src="/images/garage/toyota.svg" width={40} />
        <span>
          <span className="block">Test drive today. Schedule a test drive at {dealershipName}</span>
        </span>
      </div>
    </GarageInfoCard>
  );
};
