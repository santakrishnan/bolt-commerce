import { mockVehicles } from "@features/search/lib/mock-vehicles";
import type { Vehicle } from "@shared/types";

/** Fisher-Yates shuffle — returns a new randomly-ordered copy. */
function shuffle<T>(arr: readonly T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = copy[i];
    copy[i] = copy[j] as T;
    copy[j] = tmp as T;
  }
  return copy;
}

/** Returns a shuffled copy of the mock vehicle list for the My Garage page. */
export function fetchGarageCars(): Vehicle[] {
  return shuffle(mockVehicles as Vehicle[]);
}
