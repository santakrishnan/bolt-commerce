import { getVehicleFinancing } from "@features/search/lib/mock-financing-service";
import type { CarCardProps } from "./car-card-types";
import EstimationModal from "./estimation-modal";
import { RefineSearchModal } from "./refine-search-modal";

export function CarCardModals({
  showEstimation,
  setShowEstimation,
  estimation,
  price,
  showRefineSearch,
  setShowRefineSearch,
  activeFilters,
  onApplyRefineFilters,
  onSearch,
  vehicleFeatures,
}: {
  showEstimation: boolean;
  setShowEstimation: (v: boolean) => void;
  estimation: CarCardProps["estimation"];
  price: string;
  showRefineSearch: boolean;
  setShowRefineSearch: (v: boolean) => void;
  activeFilters: CarCardProps["activeFilters"];
  onApplyRefineFilters: CarCardProps["onApplyRefineFilters"];
  onSearch: CarCardProps["onSearch"];
  vehicleFeatures?: string[];
}) {
  return (
    <>
      {showEstimation &&
        (() => {
          const numericPrice = Number.parseInt(price.replace(/[^0-9]/g, ""), 10) || 0;
          const financing = getVehicleFinancing({ price: numericPrice });
          return (
            <EstimationModal
              apr={estimation?.apr ?? financing.apr}
              creditScore={estimation?.creditScore ?? financing.creditScore}
              estimatedMonthlyPayment={
                estimation?.estimatedMonthlyPayment ?? financing.estimatedMonthlyPayment
              }
              isOpen={showEstimation}
              onClose={() => setShowEstimation(false)}
              termLength={estimation?.termLength ?? `${financing.termMonths} months`}
            />
          );
        })()}
      {showRefineSearch && (
        <RefineSearchModal
          activeFilters={activeFilters ?? []}
          isOpen={showRefineSearch}
          onApplyFilters={onApplyRefineFilters}
          onClose={() => setShowRefineSearch(false)}
          onSearch={onSearch ?? (() => undefined)}
          vehicleFeatures={vehicleFeatures}
        />
      )}
    </>
  );
}
