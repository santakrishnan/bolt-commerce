import { buildAllAvailableFilters } from "@features/search/lib/mock-search-service";
import type { Vehicle } from "@shared/vehicle";
import { slugify } from "utils";

export interface FilterOption {
  id: string;
  label: string;
}

/** Number of filters shown per section (Your Filters / Suggested). */
export const FILTERS_PER_SECTION = 6;
/** Build filter lists from available vehicle features. */
export function buildFilterOptions(vehicles: Vehicle[]): {
  yourFilters: FilterOption[];
  suggestedFilters: FilterOption[];
  allFilters: FilterOption[];
} {
  const available = buildAllAvailableFilters(vehicles);

  const yourLabels = [...available.comfortFeatures, ...available.techFeatures];
  const yourFilters: FilterOption[] = yourLabels
    .slice(0, FILTERS_PER_SECTION)
    .map((label) => ({ id: slugify(label), label }));

  const suggestedLabels = [
    ...available.safetyFeatures,
    ...available.exteriorFeatures,
    ...available.performanceFeatures,
  ];
  const suggestedFilters: FilterOption[] = suggestedLabels
    .slice(0, FILTERS_PER_SECTION)
    .map((label) => ({ id: slugify(label), label }));

  return {
    yourFilters,
    suggestedFilters,
    allFilters: [...yourFilters, ...suggestedFilters],
  };
}
