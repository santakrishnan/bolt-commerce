"use client";

import { buildUsedCarsPath } from "@config/routes";
import { VehiclePreviewModal } from "@features/vehicle-preview";
import Link from "next/link";
import { useCallback, useMemo, useState } from "react";
import { CarCardContent } from "./car-card-content";
import { CarCardImageSection } from "./car-card-image-section";
import { CarCardModals } from "./car-card-modals";
import type { CarCardProps } from "./car-card-types";

export type { CarCardProps } from "./car-card-types";

export default function CarCard({
  activeFilters,
  carImage,
  carName,
  condition,
  dealerLocation,
  dealerName,
  distance,
  drivetrain,
  make,
  model,
  mpg,
  stock,
  variant,
  vehicleFeatures,
  year,
  vin,
  price,
  wasPrice,
  mileage,
  estimatedPayment,
  exteriorColor,
  exteriorColorHex,
  exteriorColorGradient,
  interiorColor,
  interiorColorHex,
  matchPercentage,
  badge,
  owners,
  features = { warranty: true, inspected: true, oneOwner: true },
  estimation,
  onApplyRefineFilters,
  onSearch,
  enablePreviewModal = true,
}: CarCardProps) {
  const [showEstimation, setShowEstimation] = useState(false);
  const [showRefineSearch, setShowRefineSearch] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);

  const vehiclePreviewData = useMemo(
    () => ({
      title: carName,
      year,
      make,
      model,
      trim: variant,
      price: Number.parseInt(price.replace(/[^0-9]/g, ""), 10) || 0,
      originalPrice: wasPrice ? Number.parseInt(wasPrice.replace(/[^0-9]/g, ""), 10) : undefined,
      condition,
      warranty: features?.warranty ?? false,
      inspected: features?.inspected ?? false,
      miles: mileage,
      drivetrain,
      mpg,
      stock,
      vin,
      exterior: exteriorColor,
      exteriorColorCode: exteriorColorHex,
      interior: interiorColor,
      interiorColorCode: interiorColorHex,
      dealer: dealerName,
      distance,
      location: dealerLocation,
      features: vehicleFeatures ?? [],
      images: Array.isArray(carImage) ? carImage : [carImage],
    }),
    [
      carName,
      year,
      make,
      model,
      variant,
      price,
      wasPrice,
      condition,
      features,
      mileage,
      drivetrain,
      mpg,
      stock,
      vin,
      exteriorColor,
      exteriorColorHex,
      interiorColor,
      interiorColorHex,
      dealerLocation,
      dealerName,
      distance,
      vehicleFeatures,
      carImage,
    ]
  );

  const vdpUrl = useMemo(
    () =>
      make && model && variant && year && vin
        ? buildUsedCarsPath({ type: "details", make, model, trim: variant, year, vin })
        : "#",
    [make, model, variant, year, vin]
  );

  const handleCardClick = useCallback(
    (e: React.MouseEvent<HTMLAnchorElement>) => {
      if (enablePreviewModal) {
        e.preventDefault();
        setShowPreviewModal(true);
      }
    },
    [enablePreviewModal]
  );

  return (
    <>
      <VehiclePreviewModal
        isOpen={showPreviewModal}
        onClose={() => setShowPreviewModal(false)}
        vdpUrl={vdpUrl}
        vehicle={vehiclePreviewData}
        vin={vin}
      />

      <div className="relative w-full">
        <Link
          className="group flex h-full w-full flex-col overflow-hidden rounded-lg bg-white shadow-sm transition-shadow duration-300 hover:shadow-xl"
          href={vdpUrl}
          onClick={handleCardClick}
        >
          <CarCardImageSection
            badge={badge}
            carImage={carImage}
            carName={carName}
            vdpUrl={vdpUrl}
            vin={vin ?? ""}
          />

          <CarCardContent
            carName={carName}
            dealerName={dealerName}
            distance={distance}
            estimatedPayment={estimatedPayment}
            exteriorColor={exteriorColor}
            exteriorColorGradient={exteriorColorGradient}
            exteriorColorHex={exteriorColorHex}
            features={features}
            interiorColor={interiorColor}
            interiorColorHex={interiorColorHex}
            matchPercentage={matchPercentage}
            mileage={mileage}
            onShowEstimation={() => setShowEstimation(true)}
            onShowRefineSearch={onSearch ? () => setShowRefineSearch(true) : undefined}
            owners={owners}
            price={price}
            wasPrice={wasPrice}
          />
        </Link>

        <CarCardModals
          activeFilters={activeFilters}
          estimation={estimation}
          onApplyRefineFilters={onApplyRefineFilters}
          onSearch={onSearch}
          price={price}
          setShowEstimation={setShowEstimation}
          setShowRefineSearch={setShowRefineSearch}
          showEstimation={showEstimation}
          showRefineSearch={showRefineSearch}
        />
      </div>
    </>
  );
}
