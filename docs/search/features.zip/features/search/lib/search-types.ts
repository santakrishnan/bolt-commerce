/**
 * Search domain types — the API contract for search requests and responses.
 *
 * These types are independent of the mock implementation and will remain
 * unchanged when the real BED API replaces the mock layer. All consumers
 * (context, components, API routes) should import from here, not from
 * mock-faceted-search.ts.
 */

import type {
  AvailableFilters,
  FilterState,
} from "@features/search/components/filter-sidebar/types";
import type { Vehicle } from "@shared/vehicle";

// ── Sort / Refine / Facet Counts ────────────────────────────────────

export type SortOption = "recommended" | "low-high" | "high-low";

export interface RefineFilter {
  id: string;
  label: string;
}

export interface FacetCounts {
  bodyType: Record<string, number>;
  drivetrain: Record<string, number>;
  exteriorColor: Record<string, number>;
  fuelType: Record<string, number>;
  interiorColor: Record<string, number>;
  mileageRange: Record<string, number>;
  priceRange: Record<string, number>;
  transmission: Record<string, number>;
  yearRange: Record<string, number>;
}

// ── Facet Sections ──────────────────────────────────────────────────

export type FacetSection =
  | "Price"
  | "Year"
  | "Mileage"
  | "Body Style"
  | "Exterior Color"
  | "Interior Color"
  | "Make & Model"
  | "Fuel Type"
  | "Features & Technology"
  | "Inspection"
  | "Drivetrain"
  | "Transmission";

export const ALL_FACET_SECTIONS: FacetSection[] = [
  "Price",
  "Year",
  "Mileage",
  "Body Style",
  "Exterior Color",
  "Interior Color",
  "Make & Model",
  "Fuel Type",
  "Features & Technology",
  "Inspection",
  "Drivetrain",
  "Transmission",
];

// ── Facet Patch ─────────────────────────────────────────────────────

export interface FacetPatch {
  availableFiltersPatch: Partial<AvailableFilters>;
  facetCountsPatch: Partial<FacetCounts>;
  updatedSections: FacetSection[];
}

// ── Smart Filters ───────────────────────────────────────────────────

export interface SmartFilterOption {
  count?: number;
  description?: string;
  display_name: string;
  value: string;
}

export interface SmartFilterGroup {
  description?: string;
  display_name: string;
  name: string;
  options?: SmartFilterOption[];
  type: string;
}

// ── Applied Filters ─────────────────────────────────────────────────

export interface AppliedFilter {
  displayText: string;
  field: string;
  value: string;
}

// ── Search Request / Response ───────────────────────────────────────

export interface SearchRequest {
  filterState: FilterState;
  includeFacets?: boolean;
  labelFilter?: string;
  page?: number;
  pageSize?: number;
  refineFilters?: RefineFilter[];
  searchId?: string;
  searchQuery?: string;
  sortOption?: SortOption;
  updatedSections?: FacetSection[];
}

export interface SearchResponse {
  appliedFilters?: AppliedFilter[];
  facets: FacetPatch;
  metadata: {
    queryTimeMs: number;
    version: string;
    latencyMs: number;
    inventorySize: number;
    searchId: string;
  };
  pagination: {
    page: number;
    pageSize: number;
    totalResults: number;
    totalPages: number;
  };
  smartFilters?: SmartFilterGroup[];
  totalCount: number;
  vehicles: Vehicle[];
}

// ── Filter Search Request / Response ────────────────────────────────

export interface FilterSearchRequest {
  filterId?: string;
  filterState: FilterState;
  labelFilter?: string;
  refineFilters?: RefineFilter[];
  searchId?: string;
  searchQuery?: string;
  updatedSections?: FacetSection[];
}

export interface FilterSearchResponse {
  facets: FacetPatch;
  filterId: string;
  metadata: {
    queryTimeMs: number;
    inventorySize: number;
  };
  searchId: string;
}
