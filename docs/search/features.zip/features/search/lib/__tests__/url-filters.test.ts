import { describe, expect, it } from "vitest";
import { parseSearchUrlState, serializeSearchUrlState } from "../url-filters";

describe("parseSearchUrlState - basic parsing and edge cases", () => {
  it("returns undefineds and empty arrays for absent params", () => {
    const params = new URLSearchParams("");
    const parsed = parseSearchUrlState(params);

    expect(parsed.searchQuery).toBeUndefined();
    expect(parsed.page).toBeUndefined();
    expect(parsed.sortOption).toBeUndefined();
    expect(parsed.labelFilter).toBeUndefined();
    expect(parsed.filterState).toBeTruthy();
    expect(parsed.filterState.selectedModels).toEqual([]);
  });

  it("parses CSV parameters, trimming and ignoring empties", () => {
    const params = new URLSearchParams();
    params.set("models", " rav4, corolla ,,  ,camry ");

    const parsed = parseSearchUrlState(params);
    expect(parsed.filterState.selectedModels).toEqual(["rav4", "corolla", "camry"]);
  });

  it("parses positive integer page and rejects zero/negative/non-numeric", () => {
    const pGood = new URLSearchParams({ page: "3" });
    expect(parseSearchUrlState(pGood).page).toBe(3);

    const pZero = new URLSearchParams({ page: "0" });
    expect(parseSearchUrlState(pZero).page).toBeUndefined();

    const pNeg = new URLSearchParams({ page: "-2" });
    expect(parseSearchUrlState(pNeg).page).toBeUndefined();

    const pBad = new URLSearchParams({ page: "abc" });
    expect(parseSearchUrlState(pBad).page).toBeUndefined();
  });

  it("accepts only known sort options and treats unknown as undefined", () => {
    const ok = new URLSearchParams({ sort: "low-high" });
    expect(parseSearchUrlState(ok).sortOption).toBe("low-high");

    const bad = new URLSearchParams({ sort: "fastest" });
    expect(parseSearchUrlState(bad).sortOption).toBeUndefined();
  });

  it("parses inspection flag only when equal to '1'", () => {
    const on = new URLSearchParams({ inspection: "1" });
    expect(parseSearchUrlState(on).filterState.inspection160).toBe(true);

    const off = new URLSearchParams({ inspection: "0" });
    expect(parseSearchUrlState(off).filterState.inspection160).toBe(false);

    const missing = new URLSearchParams();
    expect(parseSearchUrlState(missing).filterState.inspection160).toBe(false);
  });

  it("parses multiple feature lists and preserves order/values", () => {
    const params = new URLSearchParams({ fuelTypes: "Hybrid, Electric", drivetrains: "AWD" });
    const parsed = parseSearchUrlState(params);
    expect(parsed.filterState.selectedFuelTypes).toEqual(["Hybrid", "Electric"]);
    expect(parsed.filterState.selectedDrivetrains).toEqual(["AWD"]);
  });
});

describe("serializeSearchUrlState - behavior and round-trip for q", () => {
  it("serializes only a trimmed `q` when other fields are empty (current implementation)", () => {
    const state: any = {
      searchQuery: "  toyota corolla  ",
      labelFilter: "",
      page: 1,
      sortOption: "recommended",
      filterState: {},
    };

    const out = serializeSearchUrlState(state);
    const parsedQ = new URLSearchParams(out).get("q");
    expect(parsedQ).toBe("toyota corolla");
  });

  it("produces an empty string when `searchQuery` is empty or whitespace", () => {
    const state: any = {
      searchQuery: "   ",
      labelFilter: "",
      page: 1,
      sortOption: "recommended",
      filterState: {},
    };
    expect(serializeSearchUrlState(state)).toBe("");
  });

  it("round-trips the `q` parameter via parseSearchUrlState when present", () => {
    const state: any = {
      searchQuery: "  a & b  ",
      labelFilter: "",
      page: 1,
      sortOption: "recommended",
      filterState: {},
    };
    const serialized = serializeSearchUrlState(state);
    const parsed = parseSearchUrlState(new URLSearchParams(serialized));
    expect(parsed.searchQuery).toBe("a & b");
  });
});
