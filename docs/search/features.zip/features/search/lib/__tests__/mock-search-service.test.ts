import { defaultFilterState } from "@features/search/components/filter-sidebar/types";
import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  buildAllAvailableFilters,
  buildAllFacetCounts,
  computeAvailableFiltersSync,
  MILEAGE_BUCKET_LABELS,
  mockSearchVehicles,
  PRICE_BUCKET_LABELS,
  YEAR_BUCKET_LABELS,
} from "../mock-search-service";
import { mockVehicles } from "../mock-vehicles";

describe("mock-search-service (public contract)", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it("buildAllAvailableFilters returns a shape with expected keys and counts", () => {
    const available = buildAllAvailableFilters(mockVehicles);
    expect(available).toHaveProperty("totalCount");
    expect(available.totalCount).toBe(mockVehicles.length);
    expect(available.bodyStyles.length).toBeGreaterThan(0);
    expect(available.fuelTypes).toEqual(expect.arrayContaining(["Hybrid", "Gasoline"]));
    expect(available.transmissions.length).toBeGreaterThan(0);
  });

  it("buildAllFacetCounts produces non-empty counters for known buckets", () => {
    const facets = buildAllFacetCounts(mockVehicles);
    expect(facets).toHaveProperty("bodyType");
    expect(facets.bodyType.SUV).toBeGreaterThan(0);
    const anyPriceKey = Object.keys(PRICE_BUCKET_LABELS)[0];
    expect(facets.priceRange).toBeTypeOf("object");
    expect(anyPriceKey).toBeDefined();
    expect(PRICE_BUCKET_LABELS).toHaveProperty(anyPriceKey as string);
  });

  it("computeAvailableFiltersSync respects single-dimension filters (fuel type)", () => {
    const s = { ...defaultFilterState, selectedFuelTypes: ["Hybrid"] };
    const { availableFilters } = computeAvailableFiltersSync(mockVehicles, s);
    const expectedHybridCount = mockVehicles.filter((v) => v.fuelType === "Hybrid").length;
    expect(availableFilters.totalCount).toBe(expectedHybridCount);
    expect(Array.isArray(availableFilters.drivetrains)).toBe(true);
  });

  it("mockSearchVehicles applies sorting (low-high / high-low) and pagination", async () => {
    const req = {
      filterState: defaultFilterState,
      sortOption: "low-high" as const,
      page: 1,
      pageSize: 3,
    };
    const res = await mockSearchVehicles(req);
    expect(res.vehicles.length).toBeLessThanOrEqual(3);
    const prices = res.vehicles.map((v) => v.price);
    const sorted = [...prices].sort((a, b) => a - b);
    expect(prices).toEqual(sorted);
    const res2 = await mockSearchVehicles({ ...req, sortOption: "high-low" as const });
    const prices2 = res2.vehicles.map((v) => v.price);
    const sortedDesc = [...prices2].sort((a, b) => b - a);
    expect(prices2).toEqual(sortedDesc);
    expect(res.totalCount).toBeGreaterThanOrEqual(res.vehicles.length);
  });

  it("mockSearchVehicles respects a text shortcut like 'low miles'", async () => {
    const res = await mockSearchVehicles({
      filterState: defaultFilterState,
      searchQuery: "low miles",
    });
    expect(res.vehicles.length).toBeGreaterThan(0);
    for (const v of res.vehicles) {
      expect(v.mileage).toBeLessThanOrEqual(20_000);
    }
  });

  it("when nothing matches, facets fall back to full vehicle set (no-match query)", async () => {
    const unique = "zzzxxyy-__-nope-12345";
    const res = await mockSearchVehicles({ filterState: defaultFilterState, searchQuery: unique });
    expect(res.availableFilters.totalCount).toBe(mockVehicles.length);
    expect(res.totalCount).toBe(0);
  });

  it("refineFilters narrows results by feature labels (case-insensitive and substring)", async () => {
    const refine = [{ id: "1", label: "Hybrid" }];
    const res = await mockSearchVehicles({
      filterState: defaultFilterState,
      refineFilters: refine,
    });
    for (const v of res.vehicles) {
      const inFeatures = [
        ...v.features.safety,
        ...v.features.comfort,
        ...v.features.tech,
        ...v.features.exterior,
        ...v.features.performance,
      ].some((f) => f.toLowerCase().includes("hybrid"));
      expect(inFeatures).toBe(true);
    }
  });

  it("handles empty vehicle list gracefully", async () => {
    const res = await mockSearchVehicles({
      filterState: defaultFilterState,
      vehicles: [],
      page: 1,
      pageSize: 5,
    });
    expect(res.vehicles).toHaveLength(0);
    expect(res.totalCount).toBe(0);
    expect(res.availableFilters.totalCount).toBe(0);
    expect(Object.keys(res.facetCounts).length).toBeGreaterThan(0);
    for (const k of Object.keys(res.facetCounts)) {
      expect(Object.keys((res.facetCounts as any)[k]).length).toBeGreaterThanOrEqual(0);
    }
  });

  it("exports bucket label maps for UI resolution (stable keys)", () => {
    const pkeys = Object.keys(PRICE_BUCKET_LABELS);
    const mkeys = Object.keys(MILEAGE_BUCKET_LABELS);
    const ykeys = Object.keys(YEAR_BUCKET_LABELS);
    expect(pkeys.length).toBeGreaterThan(0);
    expect(PRICE_BUCKET_LABELS[pkeys[0] as string]).toBeTypeOf("string");
    expect(mkeys.length).toBeGreaterThan(0);
    expect(MILEAGE_BUCKET_LABELS[mkeys[0] as string]).toBeTypeOf("string");
    expect(ykeys.length).toBeGreaterThan(0);
    expect(YEAR_BUCKET_LABELS[ykeys[0] as string]).toBeTypeOf("string");
  });
});
