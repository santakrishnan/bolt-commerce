export type CreditTier = "excellent" | "good" | "fair" | "poor";

export interface FinancingRequest {
  creditTier?: CreditTier;
  downPayment?: number;
  termMonths?: number;
  vehiclePrice: number;
}

export interface FinancingResult {
  apr: string;
  aprNumeric: number;
  creditScore: string;
  downPaymentFormatted: string;
  estimatedMonthlyPayment: string;
  monthlyPaymentNumeric: number;
  termMonths: number;
}

interface CreditTierConfig {
  apr: number;
  label: string;
}

const CREDIT_TIERS: Record<CreditTier, CreditTierConfig> = {
  excellent: { apr: 5.49, label: "Excellent (800+) FICO® Score" },
  good: { apr: 6.99, label: "Good (670–799) FICO® Score" },
  fair: { apr: 9.49, label: "Fair (580–669) FICO® Score" },
  poor: { apr: 13.99, label: "Below Average (<580) FICO® Score" },
};

const DEFAULT_DOWN_PAYMENT = 2500;
const DEFAULT_TERM_MONTHS = 60;
const DEFAULT_CREDIT_TIER: CreditTier = "excellent";

/**
 * Standard amortization formula:
 *   M = P × [ r(1+r)^n ] / [ (1+r)^n – 1 ]
 * where P = principal, r = monthly rate, n = term in months.
 */
function calculateMonthlyPayment(
  principal: number,
  annualRate: number,
  termMonths: number
): number {
  if (principal <= 0) {
    return 0;
  }
  if (termMonths <= 0) {
    return 0;
  }
  if (annualRate === 0) {
    return Math.round(principal / termMonths);
  }
  const monthlyRate = annualRate / 100 / 12;
  return Math.round((principal * monthlyRate) / (1 - (1 + monthlyRate) ** -termMonths));
}

/**
 * Synchronously compute financing details for a vehicle.
 * Use for instant UI rendering without waiting for an async call.
 */
export function getFinancingInfoSync(req: FinancingRequest): FinancingResult {
  const {
    vehiclePrice,
    downPayment = DEFAULT_DOWN_PAYMENT,
    termMonths = DEFAULT_TERM_MONTHS,
    creditTier = DEFAULT_CREDIT_TIER,
  } = req;

  const tierConfig = CREDIT_TIERS[creditTier];
  const principal = Math.max(0, vehiclePrice - downPayment);
  const monthly = calculateMonthlyPayment(principal, tierConfig.apr, termMonths);

  return {
    apr: `${tierConfig.apr.toFixed(2)}%`,
    aprNumeric: tierConfig.apr,
    creditScore: tierConfig.label,
    downPaymentFormatted: `$${downPayment.toLocaleString()}`,
    estimatedMonthlyPayment: `$${monthly.toLocaleString()}`,
    monthlyPaymentNumeric: monthly,
    termMonths,
  };
}

/**
 *Get financing info (mock); simulates latency in development and returns FinancingResult.
 */
export async function getFinancingInfo(req: FinancingRequest): Promise<FinancingResult> {
  if (process.env.NODE_ENV === "development") {
    await new Promise<void>((resolve) => setTimeout(resolve, 80 + Math.random() * 70));
  }
  return getFinancingInfoSync(req);
}

/**
 * Return financing for a vehicle by calling the sync calculator with its price.
 */
export function getVehicleFinancing(
  vehicle: { price: number },
  opts?: Omit<FinancingRequest, "vehiclePrice">
): FinancingResult {
  return getFinancingInfoSync({ vehiclePrice: vehicle.price, ...opts });
}
