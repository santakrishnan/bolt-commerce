/**
 * Mock faceted search implementation.
 *
 * This file is the mock backend — it will be replaced by real BED API calls.
 * Domain types are defined in search-types.ts and re-exported here for
 * backward compatibility so existing imports continue to work.
 */

import type {
  AvailableFilters,
  FilterState,
} from "@features/search/components/filter-sidebar/types";
import { defaultFilterState } from "@features/search/components/filter-sidebar/types";
import { SEARCH_PAGE_SIZE } from "@features/search/lib/constants";
import {
  computeAvailableFiltersSync,
  mockSearchVehicles,
} from "@features/search/lib/mock-search-service";
import { mockVehicles, type Vehicle } from "@features/search/lib/mock-vehicles";
import smartFiltersData from "./smart-filters.json";

// Re-export all domain types so existing imports from this file still work.
// New code should import from "@features/search/lib/search-types" directly.
export type {
  AppliedFilter,
  FacetCounts,
  FacetPatch,
  FacetSection,
  FilterSearchRequest,
  FilterSearchResponse,
  RefineFilter,
  SearchRequest,
  SearchResponse,
  SmartFilterGroup,
  SmartFilterOption,
  SortOption,
} from "./search-types";
export { ALL_FACET_SECTIONS } from "./search-types";

import {
  ALL_FACET_SECTIONS,
  type AppliedFilter,
  type FacetCounts,
  type FacetPatch,
  type FacetSection,
  type FilterSearchRequest,
  type FilterSearchResponse,
  type SearchRequest,
  type SearchResponse,
} from "./search-types";

// FilterSearchRequest/Response and SearchRequest/Response are used by the
// function signatures of runMockFacetedSearch and runMockFilterSearch.

const FACET_VERSION = "mock-faceted-search-v1";

const inventoryPool = mockVehicles;
const inventorySize = inventoryPool.length;

/** Expose the generated inventory pool for use by other services (e.g. autosuggest). */
export function getInventoryPool(): Vehicle[] {
  return inventoryPool;
}

/**
 * Convert an optional sections array into a Set, defaulting to all sections.
 */
function sectionSet(sections?: FacetSection[]): Set<FacetSection> {
  if (!sections || sections.length === 0) {
    return new Set(ALL_FACET_SECTIONS);
  }
  return new Set(sections);
}

/**
 * Build patches for available filters and facet counts for the requested sections.
 */
export function buildFacetPatch(
  availableFilters: AvailableFilters,
  facetCounts: FacetCounts,
  updatedSections: FacetSection[]
): FacetPatch {
  const selected = sectionSet(updatedSections);
  const availableFiltersPatch: Partial<AvailableFilters> = {};
  const facetCountsPatch: Partial<FacetCounts> = {};

  if (selected.has("Body Style")) {
    availableFiltersPatch.bodyStyles = availableFilters.bodyStyles;
    facetCountsPatch.bodyType = facetCounts.bodyType;
  }
  if (selected.has("Exterior Color")) {
    availableFiltersPatch.exteriorColors = availableFilters.exteriorColors;
    facetCountsPatch.exteriorColor = facetCounts.exteriorColor;
  }
  if (selected.has("Interior Color")) {
    availableFiltersPatch.interiorColors = availableFilters.interiorColors;
    facetCountsPatch.interiorColor = facetCounts.interiorColor;
  }
  if (selected.has("Fuel Type")) {
    availableFiltersPatch.fuelTypes = availableFilters.fuelTypes;
    facetCountsPatch.fuelType = facetCounts.fuelType;
  }
  if (selected.has("Make & Model")) {
    availableFiltersPatch.models = availableFilters.models;
  }
  if (selected.has("Features & Technology")) {
    availableFiltersPatch.safetyFeatures = availableFilters.safetyFeatures;
    availableFiltersPatch.comfortFeatures = availableFilters.comfortFeatures;
    availableFiltersPatch.techFeatures = availableFilters.techFeatures;
    availableFiltersPatch.exteriorFeatures = availableFilters.exteriorFeatures;
    availableFiltersPatch.performanceFeatures = availableFilters.performanceFeatures;
    availableFiltersPatch.seatingCapacity = availableFilters.seatingCapacity;
  }
  if (selected.has("Inspection")) {
    availableFiltersPatch.hasInspection160 = availableFilters.hasInspection160;
  }
  if (selected.has("Drivetrain")) {
    availableFiltersPatch.drivetrains = availableFilters.drivetrains;
    facetCountsPatch.drivetrain = facetCounts.drivetrain;
  }
  if (selected.has("Transmission")) {
    availableFiltersPatch.transmissions = availableFilters.transmissions;
    facetCountsPatch.transmission = facetCounts.transmission;
  }
  if (selected.has("Price")) {
    facetCountsPatch.priceRange = facetCounts.priceRange;
  }
  if (selected.has("Year")) {
    facetCountsPatch.yearRange = facetCounts.yearRange;
  }
  if (selected.has("Mileage")) {
    facetCountsPatch.mileageRange = facetCounts.mileageRange;
  }

  availableFiltersPatch.totalCount = Math.min(availableFilters.totalCount, inventorySize);

  return {
    availableFiltersPatch,
    facetCountsPatch,
    updatedSections,
  };
}

/** Field mapping: FilterState array keys → AppliedFilter field names. */
const ARRAY_FILTER_FIELDS: Record<string, string> = {
  selectedBodyStyles: "bodyStyle",
  selectedExteriorColors: "exteriorColor",
  selectedInteriorColors: "interiorColor",
  selectedFuelTypes: "fuelType",
  selectedModels: "model",
  selectedDrivetrains: "drivetrain",
  selectedTransmissions: "transmission",
  selectedSafetyFeatures: "safetyFeature",
  selectedComfortFeatures: "comfortFeature",
  selectedTechFeatures: "techFeature",
  selectedExteriorFeatures: "exteriorFeature",
  selectedPerformanceFeatures: "performanceFeature",
  selectedSeatingCapacity: "seatingCapacity",
};

/** Field mapping: FilterState scalar keys → AppliedFilter field names. */
const SCALAR_FILTER_FIELDS: Record<string, string> = {
  selectedPriceQuick: "price",
  selectedYearQuick: "year",
  selectedMileage: "mileage",
};

/**
 * Derive appliedFilters from the current FilterState by comparing against
 * defaults. Only non-default selections produce an AppliedFilter entry.
 * This mimics what the real BED API will return.
 */
function buildAppliedFiltersFromState(filterState: FilterState): AppliedFilter[] {
  const applied: AppliedFilter[] = [];

  for (const [stateKey, field] of Object.entries(ARRAY_FILTER_FIELDS)) {
    const values = filterState[stateKey as keyof FilterState] as string[] | undefined;
    const defaults = defaultFilterState[stateKey as keyof FilterState] as string[];
    if (!values || values.length === 0) {
      continue;
    }
    for (const v of values) {
      if (!defaults.includes(v)) {
        applied.push({ field, value: v, displayText: v });
      }
    }
  }

  for (const [stateKey, field] of Object.entries(SCALAR_FILTER_FIELDS)) {
    const value = filterState[stateKey as keyof FilterState] as string;
    const defaultValue = defaultFilterState[stateKey as keyof FilterState] as string;
    if (value && value !== defaultValue) {
      applied.push({ field, value, displayText: value });
    }
  }

  if (filterState.inspection160 && !defaultFilterState.inspection160) {
    applied.push({ field: "inspection", value: "160", displayText: "160-Point Inspection" });
  }

  return applied;
}

/**
 *  Run a mocked faceted search on the inventory and return results and metadata.
 */
export async function runMockFacetedSearch(req: SearchRequest): Promise<SearchResponse> {
  const startedAt = Date.now();
  const searchId = req.searchId || crypto.randomUUID();

  const page = req.page ?? 1;
  const pageSize = req.pageSize ?? SEARCH_PAGE_SIZE;

  const searchResult = await mockSearchVehicles({
    filterState: req.filterState,
    searchQuery: req.searchQuery ?? "",
    labelFilter: req.labelFilter ?? "",
    refineFilters: req.refineFilters,
    vehicles: inventoryPool,
    sortOption: req.sortOption ?? "recommended",
    page,
    pageSize,
  });

  const includeFacets = req.includeFacets ?? true;
  const updatedSections = includeFacets ? (req.updatedSections ?? ALL_FACET_SECTIONS) : [];

  let facets: FacetPatch = {
    availableFiltersPatch: {},
    facetCountsPatch: {},
    updatedSections: [],
  };

  if (includeFacets) {
    const disjunctive = computeAvailableFiltersSync(inventoryPool, req.filterState, {
      searchQuery: req.searchQuery ?? "",
      labelFilter: req.labelFilter ?? "",
      refineFilters: req.refineFilters,
    });

    facets = buildFacetPatch(
      disjunctive.availableFilters,
      disjunctive.facetCounts,
      updatedSections
    );
  }

  const queryTimeMs = Date.now() - startedAt;
  const boundedTotalCount = Math.min(searchResult.totalCount, inventorySize);
  facets.availableFiltersPatch.totalCount = Math.min(
    facets.availableFiltersPatch.totalCount ?? boundedTotalCount,
    boundedTotalCount
  );

  return {
    vehicles: searchResult.vehicles,
    totalCount: boundedTotalCount,
    pagination: {
      page,
      pageSize,
      totalResults: boundedTotalCount,
      totalPages: Math.ceil(boundedTotalCount / pageSize),
    },
    facets,
    metadata: {
      queryTimeMs,
      version: FACET_VERSION,
      latencyMs: 0,
      inventorySize,
      searchId,
    },
    smartFilters: smartFiltersData,
    appliedFilters: buildAppliedFiltersFromState(req.filterState),
  };
}

export function runMockFilterSearch(req: FilterSearchRequest): FilterSearchResponse {
  const startedAt = Date.now();
  const searchId = req.searchId || crypto.randomUUID();
  const filterId = req.filterId || crypto.randomUUID();

  const updatedSections = req.updatedSections ?? ALL_FACET_SECTIONS;

  const disjunctive = computeAvailableFiltersSync(inventoryPool, req.filterState, {
    searchQuery: req.searchQuery ?? "",
    labelFilter: req.labelFilter ?? "",
    refineFilters: req.refineFilters,
  });

  const facets = buildFacetPatch(
    disjunctive.availableFilters,
    disjunctive.facetCounts,
    updatedSections
  );

  facets.availableFiltersPatch.totalCount = Math.min(
    facets.availableFiltersPatch.totalCount ?? inventorySize,
    inventorySize
  );

  return {
    filterId,
    searchId,
    facets,
    metadata: {
      queryTimeMs: Date.now() - startedAt,
      inventorySize,
    },
  };
}
