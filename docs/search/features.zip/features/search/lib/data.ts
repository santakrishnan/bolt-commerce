import type { Vehicle } from "@shared/vehicle";
import { type FilterSections, filterSections } from "./filter-sections";
import { mockVehicles } from "./mock-vehicles";

export type { Vehicle } from "@shared/vehicle";
export type { FilterSections, MileageFilter, PriceFilter, YearFilter } from "./filter-sections";

export interface SearchPageData {
  filterSections: FilterSections;
  vehicles: Vehicle[];
}

/**
 * Shuffle an array and return a new shuffled copy.
 */
function shuffle<T>(arr: readonly T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = copy[i];
    copy[i] = copy[j] as T;
    copy[j] = tmp as T;
  }
  return copy;
}

/**
 * Fetch server-side search page data (mocked): shuffled vehicles and filters.
 */
export async function getSearchPageData(): Promise<SearchPageData> {
  await Promise.resolve();

  return {
    vehicles: shuffle(mockVehicles),
    filterSections,
  };
}
