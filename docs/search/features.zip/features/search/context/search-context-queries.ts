import type { AvailableFilters } from "@features/search/components/filter-sidebar/types";
import type {
  AppliedFilter,
  FacetCounts,
  FacetSection,
  FilterSearchRequest,
  FilterSearchResponse,
  SearchRequest,
  SearchResponse,
  SmartFilterGroup,
} from "@features/search/lib/search-types";
import type { Vehicle } from "@shared/vehicle";
import { useQuery } from "@tanstack/react-query";
import { useCallback, useRef } from "react";
import { fetchFilters, fetchVehicleSearch } from "./search-context-utils";

// ── Derived types from query data ───────────────────────────────────

export interface SearchQueryResults {
  appliedFilters: AppliedFilter[];
  /** Total platform inventory count (unfiltered). */
  inventorySize: number;
  isInitialLoading: boolean;
  isSearching: boolean;
  searchId: string;
  smartFilters: SmartFilterGroup[];
  totalCount: number;
  /** Total pages from API response — no client-side computation needed. */
  totalPages: number;
  vehiclePool: Vehicle[];
}

export interface FilterQueryResults {
  availableFilters: AvailableFilters;
  facetCounts: FacetCounts;
  filterId: string;
  loadingFacetSections: FacetSection[];
}

interface UseSearchQueriesOptions {
  initialAvailableFilters: AvailableFilters;
  initialFacetCounts: FacetCounts;
  /** Total platform inventory count from server — used as fallback before query resolves. */
  initialInventorySize: number;
  initialTotalCount: number;
  initialVehicles: Vehicle[];
  /** Sections the UI is waiting on — drives the filter query `enabled` flag. */
  pendingFacetSections: FacetSection[];
}

/**
 * Manages vehicle search and filter queries via React Query.
 *
 * Uses `select` to derive data directly from query responses — no useEffect,
 * no setState callbacks, single render pass per query resolution.
 */
export function useSearchQueries(
  debouncedSearchRequest: SearchRequest,
  debouncedFilterRequest: FilterSearchRequest,
  options: UseSearchQueriesOptions,
  hasServerData = false
) {
  const {
    initialVehicles,
    initialTotalCount,
    initialInventorySize,
    initialAvailableFilters,
    initialFacetCounts,
    pendingFacetSections,
  } = options;

  // ── Vehicle search query ────────────────────────────────────────

  const vehicleSearchQuery = useQuery({
    queryKey: ["vehicle-search", debouncedSearchRequest],
    queryFn: () => fetchVehicleSearch(debouncedSearchRequest),
    enabled: true,
    placeholderData: (prev) => prev,
    staleTime: hasServerData ? 30_000 : 20_000,
    refetchOnWindowFocus: false,
    retry: 1,
    structuralSharing: true,
    select: useCallback((data: SearchResponse) => {
      const maxInventory = data.metadata.inventorySize;
      return {
        vehiclePool: data.vehicles,
        totalCount: Math.max(0, Math.min(data.totalCount, maxInventory)),
        totalPages: data.pagination.totalPages,
        inventorySize: maxInventory,
        smartFilters: data.smartFilters ?? [],
        appliedFilters: data.appliedFilters ?? [],
        searchId: data.metadata.searchId ?? "",
      };
    }, []),
  });

  // Progress bar is triggered directly in applyFiltersSearch (event handler),
  // not from query lifecycle — per Vercel rerender-move-effect-to-event pattern.

  // ── Filter/facet query ──────────────────────────────────────────

  // Accumulate filter patches across queries. Each response only contains
  // the sections that changed, so we merge into the running totals.
  const accumulatedFiltersRef = useRef<AvailableFilters>(initialAvailableFilters);
  const accumulatedCountsRef = useRef<FacetCounts>(initialFacetCounts);

  const filtersQuery = useQuery({
    queryKey: ["search-filters", debouncedFilterRequest],
    queryFn: () => fetchFilters(debouncedFilterRequest),
    enabled: pendingFacetSections.length > 0,
    placeholderData: (prev) => prev,
    staleTime: 20_000,
    refetchOnWindowFocus: false,
    retry: 1,
    structuralSharing: true,
    select: useCallback((data: FilterSearchResponse) => {
      if (data.facets.updatedSections.length > 0) {
        accumulatedFiltersRef.current = {
          ...accumulatedFiltersRef.current,
          ...data.facets.availableFiltersPatch,
        };
        accumulatedCountsRef.current = {
          ...accumulatedCountsRef.current,
          ...data.facets.facetCountsPatch,
        };
      }

      return {
        availableFilters: accumulatedFiltersRef.current,
        facetCounts: accumulatedCountsRef.current,
        filterId: data.filterId ?? "",
        resolvedSections: data.facets.updatedSections,
      };
    }, []),
  });

  // ── Derive results ──────────────────────────────────────────────

  const searchData = vehicleSearchQuery.data;
  const filterData = filtersQuery.data;

  // Compute loading sections: pending minus whatever the filter query resolved
  const resolvedSections = filterData?.resolvedSections ?? [];
  const loadingFacetSections = pendingFacetSections.filter((s) => !resolvedSections.includes(s));

  const searchResults: SearchQueryResults = {
    vehiclePool: searchData?.vehiclePool ?? initialVehicles,
    totalCount: searchData?.totalCount ?? initialTotalCount,
    totalPages: searchData?.totalPages ?? Math.ceil(initialTotalCount / (debouncedSearchRequest.pageSize ?? 20)),
    inventorySize: searchData?.inventorySize ?? initialInventorySize,
    smartFilters: searchData?.smartFilters ?? [],
    appliedFilters: searchData?.appliedFilters ?? [],
    searchId: searchData?.searchId ?? "",
    isSearching: vehicleSearchQuery.isFetching || filtersQuery.isFetching,
    isInitialLoading: vehicleSearchQuery.isLoading && !hasServerData,
  };

  const filterResults: FilterQueryResults = {
    availableFilters: filterData?.availableFilters ?? initialAvailableFilters,
    facetCounts: filterData?.facetCounts ?? initialFacetCounts,
    filterId: filterData?.filterId ?? "",
    loadingFacetSections,
  };

  return { searchResults, filterResults };
}
