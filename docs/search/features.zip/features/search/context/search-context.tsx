"use client";

import { SEARCH_PAGE_SIZE } from "@features/search/lib/constants";
import type { FilterSearchRequest, SearchRequest } from "@features/search/lib/search-types";
import { useDebouncedValue } from "@shared/hooks/use-debounced-value";
import { createContext, useCallback, useContext, useMemo, useTransition } from "react";
import { useSearchQueries } from "./search-context-queries";
import { useSearchState } from "./search-context-state";
import type { SearchContextValue, SearchProviderProps } from "./search-context-types";

const SearchContext = createContext<SearchContextValue | undefined>(undefined);

export function useSearchContext() {
  const ctx = useContext(SearchContext);
  if (!ctx) {
    throw new Error("useSearchContext must be used within SearchProvider");
  }
  return ctx;
}

export function SearchProvider({
  children,
  initialAppliedFilters = [],
  initialBodyStyles = [],
  initialDataFetched,
  initialInventorySize,
  initialSearchQuery = "",
  initialUrlFilters,
  defaultFilterState,
  initialVehicles = [],
  initialTotalCount = 0,
}: SearchProviderProps) {
  const [isFilterPending, startFilterTransition] = useTransition();
  const hasServerData = initialDataFetched ?? initialVehicles.length > 0;
  const state = useSearchState({
    defaultFilterState,
    initialAppliedFilters,
    initialBodyStyles,
    initialSearchQuery,
    initialUrlFilters,
    initialVehicles,
    initialTotalCount,
  });

  const {
    filterState,
    searchQuery,
    labelFilter,
    refineSearchFilters,
    sortOption,
    currentPage,
    pendingFacetSections,
    handleSearch,
  } = state;

  const searchRequestPayload = useMemo<SearchRequest>(
    () => ({
      filterState,
      searchQuery,
      labelFilter,
      refineFilters: refineSearchFilters,
      sortOption,
      page: currentPage,
      pageSize: SEARCH_PAGE_SIZE,
      includeFacets: false,
    }),
    [filterState, searchQuery, labelFilter, refineSearchFilters, sortOption, currentPage]
  );

  const filterRequestPayload = useMemo<FilterSearchRequest>(
    () => ({
      filterState,
      searchQuery,
      labelFilter,
      refineFilters: refineSearchFilters,
      updatedSections: pendingFacetSections,
    }),
    [filterState, searchQuery, labelFilter, refineSearchFilters, pendingFacetSections]
  );

  const debouncedSearchRequest = useDebouncedValue(searchRequestPayload, 300);
  const debouncedFilterRequest = useDebouncedValue(filterRequestPayload, 300);

  // Query data flows directly via `select` — no useEffect, no callbacks,
  // single render pass per query resolution.
  const { searchResults, filterResults } = useSearchQueries(
    debouncedSearchRequest,
    debouncedFilterRequest,
    {
      initialVehicles,
      initialTotalCount,
      initialInventorySize: initialInventorySize ?? initialVehicles.length,
      initialAvailableFilters: state.initialAvailableFilters,
      initialFacetCounts: state.initialFacetCounts,
      pendingFacetSections,
      onSearchStart: handleSearch,
    },
    hasServerData
  );

  const setSortOptionTransitioned = useCallback(
    (
      value:
        | "recommended"
        | "low-high"
        | "high-low"
        | ((
            prev: "recommended" | "low-high" | "high-low"
          ) => "recommended" | "low-high" | "high-low")
    ) => {
      startFilterTransition(() => {
        state.setSortOption(value);
      });
    },
    [state.setSortOption]
  );

  const setLabelFilterTransitioned = useCallback(
    (value: string | ((prev: string) => string)) => {
      startFilterTransition(() => {
        state.setLabelFilter(value);
      });
    },
    [state.setLabelFilter]
  );

  const contextValue = useMemo(
    () => ({
      // ── From query results (derived via select, no setState) ──
      vehiclePool: searchResults.vehiclePool,
      totalCount: searchResults.totalCount,
      inventorySize: searchResults.inventorySize,
      smartFilters: searchResults.smartFilters,
      appliedFilters: searchResults.appliedFilters,
      isSearching: searchResults.isSearching,
      isInitialLoading: searchResults.isInitialLoading,

      availableFilters: filterResults.availableFilters,
      facetCounts: filterResults.facetCounts,
      loadingFacetSections: filterResults.loadingFacetSections,

      // ── From state (user interactions) ──
      filterState: state.filterState,
      setFilterState: state.setFilterState,
      searchQuery: state.searchQuery,
      setSearchQuery: state.setSearchQuery,
      searchQueryRef: state.searchQueryRef,
      labelFilter: state.labelFilter,
      setLabelFilter: setLabelFilterTransitioned,
      refineSearchFilters: state.refineSearchFilters,
      setRefineSearchFilters: state.setRefineSearchFilters,
      currentPage: state.currentPage,
      setCurrentPage: state.setCurrentPage,
      sortOption: state.sortOption,
      setSortOption: setSortOptionTransitioned,
      isFilterOpen: state.isFilterOpen,
      setIsFilterOpen: state.setIsFilterOpen,
      progress: state.progress,
      setProgress: state.setProgress,
      isProgressVisible: state.isProgressVisible,
      setIsProgressVisible: state.setIsProgressVisible,
      isFilterPending,

      // ── Actions ──
      applyFiltersSearch: state.applyFiltersSearch,
      handleSearch: state.handleSearch,
    }),
    [
      // Query-derived
      searchResults.vehiclePool,
      searchResults.totalCount,
      searchResults.inventorySize,
      searchResults.smartFilters,
      searchResults.appliedFilters,
      searchResults.isSearching,
      searchResults.isInitialLoading,
      filterResults.availableFilters,
      filterResults.facetCounts,
      filterResults.loadingFacetSections,
      // State
      state.filterState,
      state.setFilterState,
      state.searchQuery,
      state.setSearchQuery,
      state.searchQueryRef,
      state.labelFilter,
      setLabelFilterTransitioned,
      state.refineSearchFilters,
      state.setRefineSearchFilters,
      state.currentPage,
      state.setCurrentPage,
      state.sortOption,
      setSortOptionTransitioned,
      state.isFilterOpen,
      state.setIsFilterOpen,
      state.progress,
      state.setProgress,
      state.isProgressVisible,
      state.setIsProgressVisible,
      isFilterPending,
      // Actions
      state.applyFiltersSearch,
      state.handleSearch,
    ]
  );

  return <SearchContext.Provider value={contextValue}>{children}</SearchContext.Provider>;
}
