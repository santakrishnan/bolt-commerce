import type {
  AvailableFilters,
  FilterState,
} from "@features/search/components/filter-sidebar/types";
import type {
  AppliedFilter,
  FacetCounts,
  FacetSection,
  RefineFilter,
  SmartFilterGroup,
} from "@features/search/lib/search-types";
import type { Vehicle } from "@shared/vehicle";
import type { Dispatch, MutableRefObject, ReactNode, SetStateAction } from "react";

export interface RefineSearchFilter {
  id: string;
  label: string;
}

export interface SearchContextValue {
  // ── Query-derived (read-only, from React Query select) ──
  appliedFilters: AppliedFilter[];

  // ── Actions (stable setters) ──
  applyFiltersSearch: (
    newFilterState: FilterState,
    opts?: {
      searchQuery?: string;
      labelFilter?: string;
      refineFilters?: RefineFilter[];
      preservePage?: boolean;
    }
  ) => void;
  availableFilters: AvailableFilters;

  // ── User interaction state ──
  currentPage: number;
  facetCounts: FacetCounts;
  filterState: FilterState;
  /** Total platform inventory count (unfiltered). */
  inventorySize: number;
  isFilterOpen: boolean;
  isFilterPending: boolean;
  isInitialLoading: boolean;
  isProgressVisible: boolean;
  isSearching: boolean;
  labelFilter: string;
  loadingFacetSections: FacetSection[];
  progress: number;
  refineSearchFilters: RefineSearchFilter[];
  searchQuery: string;
  searchQueryRef: MutableRefObject<string>;
  setCurrentPage: Dispatch<SetStateAction<number>>;
  setFilterState: Dispatch<SetStateAction<FilterState>>;
  setIsFilterOpen: Dispatch<SetStateAction<boolean>>;
  setIsProgressVisible: Dispatch<SetStateAction<boolean>>;
  setLabelFilter: Dispatch<SetStateAction<string>>;
  setProgress: Dispatch<SetStateAction<number>>;
  setRefineSearchFilters: Dispatch<SetStateAction<RefineSearchFilter[]>>;
  setSearchQuery: Dispatch<SetStateAction<string>>;
  setSortOption: Dispatch<SetStateAction<"recommended" | "low-high" | "high-low">>;
  /** Bypass search query debounce — call on explicit submit actions. */
  flushSearchQuery: (immediate?: string) => void;
  smartFilters: SmartFilterGroup[];
  sortOption: "recommended" | "low-high" | "high-low";
  totalCount: number;
  /** Total pages from API response — no client-side pagination math needed. */
  totalPages: number;
  vehiclePool: Vehicle[];
}

export interface SearchProviderProps {
  children: ReactNode;
  defaultFilterState: FilterState;
  initialAppliedFilters?: AppliedFilter[];
  initialBodyStyles?: string[];
  /** True when server-side data fetch was made, regardless of result count. */
  initialDataFetched?: boolean;
  /** Total platform inventory count from server response. */
  initialInventorySize?: number;
  initialSearchQuery?: string;
  initialTotalCount?: number;
  initialUrlFilters?: Partial<FilterState>;
  initialVehicles?: Vehicle[];
}
