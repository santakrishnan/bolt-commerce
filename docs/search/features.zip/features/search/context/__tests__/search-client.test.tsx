import { fireEvent, render, screen } from "@testing-library/react";
import { expect, test, vi } from "vitest";

// Mutable context used by the mock factory so tests can mutate between renders
const mockContext: any = {
  vehiclePool: [],
  filterState: {
    selectedPriceQuick: "",
    selectedYearQuick: "",
    selectedMileage: "",
    selectedBodyStyles: [],
    selectedExteriorColors: [],
    selectedInteriorColors: [],
    selectedFuelTypes: [],
    selectedModels: [],
    selectedSafetyFeatures: [],
    selectedComfortFeatures: [],
    selectedTechFeatures: [],
    selectedExteriorFeatures: [],
    selectedPerformanceFeatures: [],
    selectedSeatingCapacity: [],
    selectedDrivetrains: [],
    selectedTransmissions: [],
    inspection160: false,
  },
  searchQuery: "",
  setSearchQuery: vi.fn(),
  searchQueryRef: { current: "" },
  labelFilter: "",
  setLabelFilter: vi.fn(),
  refineSearchFilters: [],
  setRefineSearchFilters: vi.fn(),
  currentPage: 1,
  setCurrentPage: vi.fn(),
  progress: 0,
  isProgressVisible: true,
  isFilterOpen: false,
  setIsFilterOpen: vi.fn(),
  availableFilters: [],
  totalCount: 0,
  sortOption: "recommended",
  setSortOption: vi.fn(),
  loadingFacetSections: false,
  applyFiltersSearch: vi.fn(),
  appliedFilters: [],
  setAppliedFilters: undefined,
};

// Provide a minimal defaultFilterState used by reset path
const fakeDefaultFilterState = {
  selectedPriceQuick: "",
  selectedYearQuick: "",
  selectedMileage: "",
  selectedBodyStyles: [],
  selectedExteriorColors: [],
  selectedInteriorColors: [],
  selectedFuelTypes: [],
  selectedModels: [],
  selectedSafetyFeatures: [],
  selectedComfortFeatures: [],
  selectedTechFeatures: [],
  selectedExteriorFeatures: [],
  selectedPerformanceFeatures: [],
  selectedSeatingCapacity: [],
  selectedDrivetrains: [],
  selectedTransmissions: [],
  inspection160: false,
};

vi.mock("@features/search/context/search-context", () => ({
  useSearchContext: () => mockContext,
}));

vi.mock("@features/search/lib/url-filters", () => ({
  parseSearchUrlState: () => ({
    filterState: {},
    searchQuery: "",
    page: 1,
    sortOption: "recommended",
    labelFilter: "",
  }),
  serializeSearchUrlState: () => "",
}));

vi.mock("next/navigation", () => ({
  useRouter: () => ({ replace: vi.fn() }),
  usePathname: () => "/search",
  useSearchParams: () => null,
}));

vi.mock("@features/search/components/filter-sidebar", () => {
  const _default = {
    selectedPriceQuick: "",
    selectedYearQuick: "",
    selectedMileage: "",
    selectedBodyStyles: [],
    selectedExteriorColors: [],
    selectedInteriorColors: [],
    selectedFuelTypes: [],
    selectedModels: [],
    selectedSafetyFeatures: [],
    selectedComfortFeatures: [],
    selectedTechFeatures: [],
    selectedExteriorFeatures: [],
    selectedPerformanceFeatures: [],
    selectedSeatingCapacity: [],
    selectedDrivetrains: [],
    selectedTransmissions: [],
    inspection160: false,
  };
  return {
    defaultFilterState: _default,
    FilterSidebar: (props: any) => (
      <div data-testid="filter-sidebar">
        <button
          data-testid="filters-apply"
          onClick={() => props.onApply?.(_default)}
          type="button"
        />
        <button data-testid="filters-reset" onClick={() => props.onReset?.()} type="button" />
      </div>
    ),
  };
});

vi.mock("@features/search/components/search-hero", () => ({
  SearchHero: (props: any) => (
    <div data-testid="search-hero">
      <span data-testid="hero-active-filters">{JSON.stringify(props.activeFilters)}</span>
      <span data-testid="hero-search-query">{String(props.searchQuery)}</span>
      <button
        data-testid="remove-label"
        onClick={() => props.onRemoveFilter?.("label", props.searchQuery || "")}
        type="button"
      />
      <button
        data-testid="remove-price"
        onClick={() => props.onRemoveFilter?.("price", "")}
        type="button"
      />
      <button
        data-testid="remove-year"
        onClick={() => props.onRemoveFilter?.("year", "")}
        type="button"
      />
      <button
        data-testid="remove-mileage"
        onClick={() => props.onRemoveFilter?.("mileage", "")}
        type="button"
      />
      <button
        data-testid="remove-bodyStyle"
        onClick={() => props.onRemoveFilter?.("bodyStyle", "A")}
        type="button"
      />
      <button
        data-testid="remove-applied"
        onClick={() => props.onRemoveFilter?.("applied", "applied-value")}
        type="button"
      />
      <button data-testid="reset" onClick={() => props.onReset?.()} type="button" />
      <button
        data-testid="search-change"
        onClick={() => props.onSearchChange?.("new-query")}
        type="button"
      />
      <button data-testid="open-filter" onClick={() => props.onToggleFilter?.()} type="button" />
    </div>
  ),
}));

vi.mock("@features/search/components/vehicle-results", () => ({
  VehicleResults: (props: any) => (
    <div>
      <button
        data-testid="apply-refine"
        onClick={() =>
          props.onApplyRefineFilters?.([
            { id: "a", label: "A" },
            { id: "a", label: "A" },
            { id: "b", label: "B" },
          ])
        }
        type="button"
      />
      <button
        data-testid="apply-refine-empty"
        onClick={() => props.onApplyRefineFilters?.([])}
        type="button"
      />
    </div>
  ),
}));

import { SearchClient } from "@features/search/context/search-client";

test("progress transition reflects progress values (0, mid, 100)", () => {
  mockContext.progress = 0;
  mockContext.isProgressVisible = true;
  const { rerender } = render(<SearchClient />);

  let bar = document.querySelector("div[aria-hidden]") as HTMLElement | null;
  expect(bar).toBeTruthy();
  expect(bar?.style.transition).toBe("none");

  mockContext.progress = 50;
  rerender(<SearchClient />);
  bar = document.querySelector("div[aria-hidden]") as HTMLElement | null;
  expect(bar?.style.transition).toContain("width 1.5s");

  mockContext.progress = 100;
  rerender(<SearchClient />);
  bar = document.querySelector("div[aria-hidden]") as HTMLElement | null;
  expect(bar?.style.transition).toContain("width 0.25s");
});

test("removeFilter 'label' clears label and calls applyFiltersSearch", () => {
  mockContext.labelFilter = "LABEL";
  mockContext.applyFiltersSearch = vi.fn();
  mockContext.setLabelFilter = vi.fn();

  render(<SearchClient />);
  const btn = screen.getByTestId("remove-label");
  fireEvent.click(btn);

  expect(mockContext.setLabelFilter).toHaveBeenCalledWith("");
  expect(mockContext.applyFiltersSearch).toHaveBeenCalled();
});

test("removeFilter 'bodyStyle' removes item from array and calls applyFiltersSearch", () => {
  mockContext.filterState = { ...mockContext.filterState, selectedBodyStyles: ["A", "B"] };
  mockContext.applyFiltersSearch = vi.fn();

  render(<SearchClient />);

  const removeBody = screen.getByTestId("remove-bodyStyle");
  fireEvent.click(removeBody);

  expect(mockContext.applyFiltersSearch).toHaveBeenCalled();
});

test("removeFilter 'applied' calls setAppliedFilters when available", () => {
  mockContext.appliedFilters = [{ value: "applied-value" }, { value: "keep" }];
  mockContext.setAppliedFilters = vi.fn();
  mockContext.applyFiltersSearch = vi.fn();

  render(<SearchClient />);
  const btn = screen.getByTestId("remove-applied");
  fireEvent.click(btn);

  expect(mockContext.setAppliedFilters).toHaveBeenCalled();
});

test("applyRefineFilters deduplicates, sets refine filters and applies search", () => {
  mockContext.setRefineSearchFilters = vi.fn();
  mockContext.applyFiltersSearch = vi.fn();

  render(<SearchClient />);
  const btn = screen.getByTestId("apply-refine");
  fireEvent.click(btn);

  expect(mockContext.setRefineSearchFilters).toHaveBeenCalled();
  expect(mockContext.applyFiltersSearch).toHaveBeenCalled();
});

test("applyRefineFilters when clearing existing refine filters calls applyFiltersSearch with filtered state", () => {
  // Simulate existing refineSearchFilters in context so clearing triggers the mirror-clear path
  mockContext.refineSearchFilters = [{ id: "x", label: "X" }];
  mockContext.setRefineSearchFilters = vi.fn();
  mockContext.applyFiltersSearch = vi.fn();

  render(<SearchClient />);
  const btn = screen.getByTestId("apply-refine-empty");
  fireEvent.click(btn);

  expect(mockContext.setRefineSearchFilters).toHaveBeenCalled();
  expect(mockContext.applyFiltersSearch).toHaveBeenCalled();
});

test("filter sidebar onApply calls applyFiltersSearch", () => {
  mockContext.applyFiltersSearch = vi.fn();

  render(<SearchClient />);
  const btn = screen.getByTestId("filters-apply");
  fireEvent.click(btn);

  expect(mockContext.applyFiltersSearch).toHaveBeenCalled();
});

test("displaySearchQuery replaces hyphens with spaces", () => {
  mockContext.searchQuery = "foo-bar-baz";
  mockContext.labelFilter = "";
  render(<SearchClient />);
  const querySpan = screen.getByTestId("hero-search-query");
  expect(querySpan.textContent).toBe("foo bar baz");
});

test("resetFilters clears searchQueryRef and applies defaultFilterState", () => {
  mockContext.searchQueryRef = { current: "something" };
  mockContext.applyFiltersSearch = vi.fn();

  render(<SearchClient />);
  const reset = screen.getByTestId("reset");
  fireEvent.click(reset);

  expect(mockContext.searchQueryRef.current).toBe("");
  expect(mockContext.applyFiltersSearch).toHaveBeenCalledWith(
    fakeDefaultFilterState,
    expect.any(Object)
  );
});
