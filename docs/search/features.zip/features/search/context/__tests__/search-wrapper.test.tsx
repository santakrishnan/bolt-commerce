import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

// Mock filterSections to a predictable set.
vi.mock("@features/search/services/srp-initial-data", () => ({
  fetchInitialSrpResults: vi.fn().mockResolvedValue({ vehicles: [], totalCount: 0 }),
}));

vi.mock("@features/search/lib/filter-sections", () => ({
  filterSections: {
    bodyStyle: ["Sedan", "SUV", "Coupe"],
    exteriorColors: ["White", "Black", "Ocean Blue"],
    interiorColors: ["Black", "Beige"],
    drivetrains: ["FWD", "AWD", "RWD"],
    transmissions: ["Automatic", "Manual"],
    fuelTypes: ["Gasoline", "Hybrid", "Electric"],
    models: ["corolla", "camry"],

    comfortFeatures: ["Heated Seats", "Leather Seats", "Climate Control"],
    techFeatures: ["Bluetooth", "Apple CarPlay"],
    safetyFeatures: ["Airbags", "Lane Assist"],
    exteriorFeatures: ["Sunroof", "Tow Package"],

    hasInspection160: [true],
  },
}));

vi.mock("@features/search/context/search-client", () => ({
  SearchClient: () => <div data-testid="mock-client">client</div>,
}));

vi.mock("@features/search/context/search-context", () => {
  let lastProps: any = null;

  function SearchProvider(props: any) {
    const { children, ...rest } = props;
    lastProps = rest;
    return <div data-testid="mock-provider">{children}</div>;
  }

  return {
    SearchProvider,
    __getLastProps: () => lastProps,
  };
});

import { SearchWrapper } from "../search-wrapper";

const getLastProps = async () => {
  const mod = await vi.importMock("@features/search/context/search-context");
  return (mod as any).__getLastProps();
};

describe("SearchWrapper", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("resolves path body type case-insensitively and passes it to SearchProvider", async () => {
    render(await SearchWrapper({ initialBodyType: "sedan" }));

    expect(screen.getByTestId("mock-client")).toBeDefined();

    const props = await getLastProps();
    expect(props).toBeTruthy();
    expect(Array.isArray(props.initialBodyStyles)).toBe(true);
    expect(props.initialBodyStyles).toEqual(["Sedan"]);
  });

  it("merges initialUrlFilters.selectedBodyStyles without duplicates and preserves order", async () => {
    render(
      await SearchWrapper({
        initialBodyType: "sedan",
        initialUrlFilters: { selectedBodyStyles: ["Coupe", "Sedan"] },
      })
    );

    const props = await getLastProps();
    expect(props.initialBodyStyles).toEqual(["Sedan", "Coupe"]);
  });

  it("uses provided initialSearchQuery as resolvedSearchQuery", async () => {
    render(await SearchWrapper({ initialSearchQuery: "find me" }));
    const props = await getLastProps();
    expect(props.initialSearchQuery).toBe("find me");
  });

  it("falls back to url filters when no path body type is provided", async () => {
    render(await SearchWrapper({ initialUrlFilters: { selectedBodyStyles: ["Coupe"] } }));
    const props = await getLastProps();
    expect(props.initialBodyStyles).toEqual(["Coupe"]);
  });
});
