import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

// Mocks for modules used by the provider
vi.mock("@features/search/queries/search-history", () => ({
  searchHistoryQueries: {
    all: () => ({ queryKey: ["search-history"] }),
  },
}));

vi.mock("@features/search/services/search-history-api", () => ({
  addSearchEntry: vi.fn(async () => ({})),
  removeSearchEntry: vi.fn(async () => ({})),
  clearSearchHistory: vi.fn(async () => ({})),
}));

vi.mock("@tanstack/react-query", () => ({
  useQuery: vi.fn(() => ({ data: [], isFetched: true })),
}));

vi.mock("@shared/hooks/use-optimistic-list-mutation", () => {
  const state: { last?: any; captured: any[] } = { last: undefined, captured: [] };

  function useOptimisticListMutation(opts: any) {
    state.captured.push(opts);
    return {
      mutate: async (vars?: any) => {
        await (opts.mutationFn ? opts.mutationFn(vars) : Promise.resolve());
        const prev: any[] = [
          { id: "1", query: "foo", url: "/old", timestamp: "t1", type: "nlp" },
          { id: "2", query: "bar", url: "/b", timestamp: "t2", type: "filter" },
        ];
        const updated = opts.updater ? opts.updater(prev, vars) : prev;
        state.last = updated;
        return updated;
      },
    };
  }

  (useOptimisticListMutation as any).__getState = () => state;

  return { useOptimisticListMutation };
});

import {
  SEARCH_HISTORY_KEY,
  SearchHistoryProvider,
  useSearchHistory,
} from "../search-history-provider";

function Consumer() {
  const { addSearch, removeSearch, clearAll, searches, isLoaded } = useSearchHistory();

  return (
    <div>
      <div data-testid="loaded">{String(isLoaded)}</div>
      <div data-testid="count">{searches.length}</div>
      <button data-testid="add" onClick={() => addSearch("foo", "/new", "nlp")} type="button" />
      <button data-testid="add-short" onClick={() => addSearch("a", "/x", "nlp")} type="button" />
      <button data-testid="remove" onClick={() => removeSearch("1")} type="button" />
      <button data-testid="clear" onClick={() => clearAll()} type="button" />
    </div>
  );
}

describe("SearchHistoryProvider", () => {
  beforeEach(async () => {
    vi.clearAllMocks();

    const mockOpt = (await vi.importMock("@shared/hooks/use-optimistic-list-mutation")) as any;
    const s = mockOpt.useOptimisticListMutation.__getState();
    s.captured.length = 0;
    s.last = undefined;
  });

  it("exposes SEARCH_HISTORY_KEY from query factory", () => {
    expect(SEARCH_HISTORY_KEY).toEqual(["search-history"]);
  });

  it("provides lazy data through useSearchHistory and mutation actions", async () => {
    render(
      <SearchHistoryProvider>
        <Consumer />
      </SearchHistoryProvider>
    );

    expect(screen.getByTestId("loaded").textContent).toBe("true");
    expect(screen.getByTestId("count").textContent).toBe("0");

    const mockOpt = (await vi.importMock("@shared/hooks/use-optimistic-list-mutation")) as any;
    expect(mockOpt.useOptimisticListMutation.__getState().captured.length).toBe(3);

    fireEvent.click(screen.getByTestId("add"));

    const lastAdd = (await vi.importMock("@shared/hooks/use-optimistic-list-mutation")) as any;
    const lastAddState = lastAdd.useOptimisticListMutation.__getState().last;
    expect(Array.isArray(lastAddState)).toBe(true);

    expect(lastAddState[0].query.toLowerCase()).toBe("foo");

    fireEvent.click(screen.getByTestId("add-short"));
    const lastShort = (await vi.importMock("@shared/hooks/use-optimistic-list-mutation")) as any;
    const lastShortState = lastShort.useOptimisticListMutation.__getState().last;

    expect(lastShortState).toBeDefined();
    expect(lastShortState.length).toBeGreaterThanOrEqual(0);

    fireEvent.click(screen.getByTestId("remove"));
    const lastRemove = (await vi.importMock("@shared/hooks/use-optimistic-list-mutation")) as any;
    const lastRemoveState = lastRemove.useOptimisticListMutation.__getState().last;

    expect(lastRemoveState.find((s: any) => s.id === "1")).toBeUndefined();

    fireEvent.click(screen.getByTestId("clear"));
    const lastClear = (await vi.importMock("@shared/hooks/use-optimistic-list-mutation")) as any;
    const lastClearState = lastClear.useOptimisticListMutation.__getState().last;
    expect(Array.isArray(lastClearState)).toBe(true);
    expect(lastClearState.length).toBe(0);
  });
});
