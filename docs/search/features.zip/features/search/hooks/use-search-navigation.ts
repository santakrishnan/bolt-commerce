"use client";

/**
 * Router wrapper for navigating to search pages with optional history recording and scroll control.
 */

import { ROUTES } from "@config/routes/constants";
import { useSearchHistory } from "@features/search/context/search-history-provider";
import { useRouter } from "next/navigation";
import { useCallback } from "react";
import { toSearchUrl } from "utils";

export interface UseSearchNavigationOptions {
  basePath?: string;
  mode?: "push" | "replace";
  recordHistory?: boolean;
  scroll?: boolean;
}

export interface NavigateOptions {
  source?: "nlp" | "filter";
}

export interface UseSearchNavigationReturn {
  buildUrl: (query: string) => string;
  navigate: (query: string, options?: NavigateOptions) => void;
}

export function useSearchNavigation({
  mode = "push",
  scroll = true,
  recordHistory = false,
  basePath = ROUTES.USED_CARS,
}: UseSearchNavigationOptions = {}): UseSearchNavigationReturn {
  const router = useRouter();
  const { addSearch } = useSearchHistory();

  const buildUrl = useCallback((query: string) => toSearchUrl(query, basePath), [basePath]);

  const navigate = useCallback(
    (query: string, { source = "nlp" }: NavigateOptions = {}) => {
      const url = buildUrl(query);

      if (recordHistory && query.trim().length > 1) {
        addSearch(query.trim(), url, source);
      }

      if (mode === "replace") {
        router.replace(url, { scroll });
      } else {
        router.push(url);
      }
    },
    [router, buildUrl, recordHistory, addSearch, mode, scroll]
  );

  return { navigate, buildUrl };
}
