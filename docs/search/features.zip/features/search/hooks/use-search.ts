"use client";

/**
 * Fetches vehicle search results with pagination, filtering, and tracking headers.
 */

import { API_ROUTES } from "@config/routes/constants";
import { SEARCH_PAGE_SIZE } from "@features/search/lib/constants";
import type {
  SearchPagination,
  SearchQuery,
  SearchResult,
  SearchVehicle,
} from "@features/search/services";
import { ARROW_HEADER } from "@features/tracking/constants";
import { useCallback, useRef, useState } from "react";

export interface UseSearchState {
  error: Error | null;
  isLoading: boolean;
  pagination: SearchPagination | null;
  query: SearchQuery;
  vehicles: SearchVehicle[];
}

export interface UseSearchActions {
  reset(): void;
  search(params?: Partial<SearchQuery>): Promise<void>;
  setPage(page: number): Promise<void>;
}

export type UseSearchReturn = UseSearchState & UseSearchActions;

export interface UseSearchOptions {
  endpoint?: string;
  fingerprintId?: string | null;
  initialQuery?: SearchQuery;
  profileId?: string | null;
  sessionId?: string | null;
}

/** Build URLSearchParams from a SearchQuery */
function buildSearchParams(query: SearchQuery): URLSearchParams {
  const params = new URLSearchParams();

  const stringFields: (keyof SearchQuery)[] = ["query", "sortBy", "sortOrder"];
  for (const key of stringFields) {
    const val = query[key];
    if (val) {
      params.set(key, String(val));
    }
  }

  const numericFields: (keyof SearchQuery)[] = [
    "page",
    "pageSize",
    "priceMin",
    "priceMax",
    "yearMin",
    "yearMax",
  ];
  for (const key of numericFields) {
    const val = query[key];
    if (val != null) {
      params.set(key, String(val));
    }
  }

  const arrayFields: (keyof SearchQuery)[] = ["bodyStyles", "makes", "models", "fuelTypes"];
  for (const key of arrayFields) {
    const val = query[key] as string[] | undefined;
    if (val?.length) {
      params.set(key, val.join(","));
    }
  }

  return params;
}

export function useSearch(options: UseSearchOptions = {}): UseSearchReturn {
  const {
    sessionId,
    fingerprintId,
    profileId,
    endpoint = API_ROUTES.SEARCH,
    initialQuery = {},
  } = options;

  const [state, setState] = useState<UseSearchState>({
    vehicles: [],
    pagination: null,
    isLoading: false,
    error: null,
    query: initialQuery,
  });

  const abortRef = useRef<AbortController | null>(null);

  const executeSearch = useCallback(
    async (query: SearchQuery) => {
      abortRef.current?.abort();
      const controller = new AbortController();
      abortRef.current = controller;

      setState((prev) => ({ ...prev, isLoading: true, error: null, query }));

      try {
        const params = buildSearchParams(query);

        const headers: Record<string, string> = {};
        if (sessionId) {
          headers[ARROW_HEADER.SESSION_ID] = sessionId;
        }
        if (fingerprintId) {
          headers[ARROW_HEADER.FP_ID] = fingerprintId;
        }
        if (profileId) {
          headers[ARROW_HEADER.PROFILE_ID] = profileId;
        }

        const url = `${endpoint}?${params.toString()}`;
        const res = await fetch(url, {
          method: "GET",
          headers,
          credentials: "include",
          signal: controller.signal,
        });

        if (!res.ok) {
          throw new Error(`Search failed: ${res.status} ${res.statusText}`);
        }

        const data: SearchResult = await res.json();

        setState((prev) => ({
          ...prev,
          vehicles: data.vehicles,
          pagination: data.pagination,
          isLoading: false,
          error: null,
        }));
      } catch (err) {
        if (controller.signal.aborted) {
          return;
        }
        setState((prev) => ({
          ...prev,
          isLoading: false,
          error: err as Error,
        }));
      }
    },
    [sessionId, fingerprintId, profileId, endpoint]
  );

  const search = useCallback(
    async (params?: Partial<SearchQuery>) => {
      const merged = {
        ...state.query,
        ...params,
        page: params?.page ?? 1,
        pageSize: SEARCH_PAGE_SIZE,
      };
      await executeSearch(merged);
    },
    [state.query, executeSearch]
  );

  const setPage = useCallback(
    async (page: number) => {
      await executeSearch({ ...state.query, page });
    },
    [state.query, executeSearch]
  );

  const reset = useCallback(() => {
    abortRef.current?.abort();
    setState({
      vehicles: [],
      pagination: null,
      isLoading: false,
      error: null,
      query: initialQuery,
    });
  }, [initialQuery]);

  return {
    ...state,
    search,
    setPage,
    reset,
  };
}
