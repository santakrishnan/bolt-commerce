import type React from "react";
import { DropdownSuggestions } from "./dropdown-suggestions";
import { PillsSuggestions } from "./pills-suggestions";
import type { SuggestionDisplayProps } from "./types";

export const SuggestionDisplay: React.FC<SuggestionDisplayProps> = ({
  mode,
  suggestions,
  isAnimating,
  onSelect,
  pillsPlacement = "below",
  quickFilters,
  onQuickFilterSelect,
}) => {
  if (mode === "dropdown") {
    return (
      <DropdownSuggestions
        isAnimating={isAnimating}
        onSelect={onSelect}
        suggestions={suggestions}
      />
    );
  }

  return (
    <PillsSuggestions
      isAnimating={isAnimating}
      onQuickFilterSelect={onQuickFilterSelect}
      onSelect={onSelect}
      pillsPlacement={pillsPlacement}
      quickFilters={quickFilters}
      suggestions={suggestions}
    />
  );
};
