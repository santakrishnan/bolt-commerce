import { Button } from "@tfs-ucmp/ui";
import type React from "react";
import { cn } from "@/lib/utils";
import type { Suggestion } from "./types";

export interface PillsSuggestionsProps {
  activeDescendantId?: string;
  isAnimating: boolean;
  onQuickFilterSelect?: (filter: string) => void;
  onSelect: (suggestion: Suggestion) => void;
  onSuggestionFocus?: (index: number) => void;
  pillsPlacement?: "above" | "below";
  quickFilters?: string[];
  suggestions: Suggestion[];
}

export const PillsSuggestions: React.FC<PillsSuggestionsProps> = ({
  suggestions,
  isAnimating,
  onSelect,
  pillsPlacement = "below",
  activeDescendantId,
  onSuggestionFocus,
  quickFilters,
  onQuickFilterSelect,
}) => {
  if (suggestions.length === 0 && (!quickFilters || quickFilters.length === 0)) {
    return null;
  }

  return (
    <div
      aria-label="Search suggestions"
      className={cn(
        "z-40 w-full",
        pillsPlacement === "above" ? "mb-sm" : "mt-sm",
        "transition-all duration-200 ease-out",
        isAnimating && pillsPlacement === "above" && "translate-y-1 opacity-0",
        isAnimating && pillsPlacement === "below" && "-translate-y-1 opacity-0",
        !isAnimating && "translate-y-0 opacity-100"
      )}
      id="search-suggestions"
      role="listbox"
    >
      <div
        className={cn(
          "scrollbar-hide flex min-w-0 gap-2 overflow-x-auto whitespace-nowrap pl-4",
          "md:flex-wrap md:justify-end md:overflow-x-visible md:whitespace-normal md:pl-0",
          pillsPlacement === "above" ? "mb-4" : "mt-6 md:mt-4"
        )}
        style={{
          WebkitOverflowScrolling: "touch",
          scrollbarWidth: "none",
          msOverflowStyle: "none",
        }}
      >
        {suggestions.map((suggestion, index) => {
          const suggestionId = `suggestion-${index}`;
          const isActive = activeDescendantId === suggestionId;

          return (
            <Button
              aria-selected={isActive}
              className={cn(
                "flex h-[var(--spacing-xl)] items-center gap-[var(--spacing-2xs)] rounded-full bg-white px-[var(--spacing-sm)]",
                "text-(length:--font-size-xs) text-center font-normal text-[var(--color-brand-text-primary)] leading-normal",
                "hover:bg-white hover:text-[var(--color-brand-text-primary)] hover:opacity-100 hover:shadow-none",
                "cursor-pointer whitespace-nowrap",
                isActive && "opacity-80"
              )}
              id={suggestionId}
              key={suggestion.id || `${suggestion.text}-${index}`}
              onClick={() => onSelect(suggestion)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  onSelect(suggestion);
                }
              }}
              onMouseEnter={() => onSuggestionFocus?.(index)}
              role="option"
              tabIndex={-1}
              type="button"
              variant="search"
            >
              {suggestion.text ? (
                <>
                  <span>{suggestion.text}</span>{" "}
                  <span className="font-semibold"> {suggestion.highlight}</span>
                </>
              ) : (
                <span className="font-semibold"> {suggestion.highlight}</span>
              )}
            </Button>
          );
        })}

        {suggestions.length === 0 &&
          quickFilters?.map((filter) => (
            <Button
              className={cn(
                "flex h-[var(--spacing-xl)] items-center gap-[var(--spacing-2xs)] rounded-full bg-white px-[var(--spacing-sm)]",
                "text-(length:--font-size-xs) text-center font-normal text-[var(--color-brand-text-primary)] leading-normal",
                "hover:bg-white hover:text-[var(--color-brand-text-primary)] hover:opacity-100 hover:shadow-none",
                "cursor-pointer whitespace-nowrap"
              )}
              key={filter}
              onClick={() => onQuickFilterSelect?.(filter)}
              role="option"
              tabIndex={-1}
              type="button"
              variant="search"
            >
              {filter}
            </Button>
          ))}
      </div>
    </div>
  );
};
