"use client";

import { lockBodyScroll, unlockBodyScroll } from "@shared/lib/body-scroll-lock";
import type React from "react";
import { useCallback, useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { useSearchHistory } from "./hooks/use-search-history";
import { useSearchSuggestions } from "./hooks/use-search-suggestions";
import { useVoiceRecognition } from "./hooks/use-voice-recognition";
import { SearchBackdrop } from "./search-backdrop";
import { SearchInput } from "./search-input";
import { SuggestionDisplay } from "./suggestion-display";
import { DEFAULT_CONFIG, type SearchBarProps, type Suggestion } from "./types";

export const SearchBar: React.FC<SearchBarProps> = ({
  value,
  onValueChange,
  onSubmit,
  config: userConfig,
  autocompleteService,
  onOpenChange,
  onQuickFilterSelect,
  className,
}) => {
  const config = {
    ...DEFAULT_CONFIG,
    ...userConfig,
  };

  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [activeSuggestionIndex, setActiveSuggestionIndex] = useState<number>(-1);
  const [hasInteracted, setHasInteracted] = useState(true);
  const [voiceErrorDismissed, setVoiceErrorDismissed] = useState(false);
  const [isClosing, setIsClosing] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const { suggestions } = useSearchSuggestions(value, {
    autocompleteService,
    minCharsForSuggestions: config.minCharsForSuggestions,
    maxSuggestions: config.maxSuggestions,
    enabled: hasInteracted,
  });

  const {
    isListening,
    toggleListening,
    transcript,
    error: voiceError,
    isSupported: isVoiceSupported,
  } = useVoiceRecognition();

  const { addSearch, toSuggestions } = useSearchHistory();

  const closeSuggestions = useCallback(() => {
    setIsClosing(true);
    setIsAnimating(true);
    setHasInteracted(false);
    setTimeout(() => {
      setShowSuggestions(false);
      setIsAnimating(false);
      setActiveSuggestionIndex(-1);
      setIsClosing(false);
      onOpenChange?.(false);
    }, 200);
  }, [onOpenChange]);

  const displaySuggestions: Suggestion[] = (() => {
    if (value.length >= (config.minCharsForSuggestions ?? 2)) {
      return suggestions;
    }

    if (config.enableSearchHistory && value.length === 0) {
      return toSuggestions();
    }

    return [];
  })();

  useEffect(() => {
    if (transcript) {
      onValueChange(transcript);
    }
  }, [transcript, onValueChange]);

  useEffect(() => {
    const el = inputRef.current;
    if (!el) {
      return;
    }

    if (value.length === 0 || !hasInteracted) {
      return;
    }

    if (document.activeElement === el) {
      return;
    }

    const timers: number[] = [];
    let attempts = 0;

    const tryFocus = () => {
      try {
        el.focus();
        const len = el.value.length;
        el.setSelectionRange(len, len);
      } catch {
        // noop
      }
      attempts += 1;
      if (document.activeElement !== el && attempts < 4) {
        let delay: number;
        if (attempts === 1) {
          delay = 50;
        } else if (attempts === 2) {
          delay = 150;
        } else {
          delay = 300;
        }
        timers.push(window.setTimeout(tryFocus, delay) as unknown as number);
      }
    };

    timers.push(window.setTimeout(tryFocus, 0) as unknown as number);

    return () => {
      for (const t of timers) {
        try {
          clearTimeout(t);
        } catch {
          // noop
        }
      }
    };
  }, [value, hasInteracted]);

  useEffect(() => {
    if (isClosing) {
      return;
    }

    const hasText = value.length > 0;
    const shouldOpen =
      displaySuggestions.length > 0 && !showSuggestions && (hasInteracted || hasText);
    const shouldClose = displaySuggestions.length === 0 && showSuggestions;

    if (shouldOpen) {
      setShowSuggestions(true);
      setIsAnimating(false);
      onOpenChange?.(true);
    } else if (shouldClose) {
      closeSuggestions();
    }
  }, [
    displaySuggestions.length,
    showSuggestions,
    hasInteracted,
    isClosing,
    closeSuggestions,
    onOpenChange,
    value,
  ]);

  const handleSuggestionSelect = useCallback(
    (suggestion: Suggestion) => {
      const fullText = suggestion.text
        ? `${suggestion.text} ${suggestion.highlight}`.trim()
        : suggestion.highlight;

      setHasInteracted(false);
      onValueChange(fullText);
      closeSuggestions();
    },
    [onValueChange, closeSuggestions]
  );

  const handleSubmit = useCallback(() => {
    if (config.enableSearchHistory && value.trim()) {
      addSearch(value, `/search?q=${encodeURIComponent(value)}`, "nlp");
    }

    closeSuggestions();

    onSubmit();
  }, [value, config.enableSearchHistory, addSearch, closeSuggestions, onSubmit]);

  const handleVoiceClick = useCallback(() => {
    if (isVoiceSupported) {
      toggleListening();
    }
  }, [toggleListening, isVoiceSupported]);

  const handleEscape = useCallback(() => {
    closeSuggestions();
  }, [closeSuggestions]);

  const handleArrowDown = useCallback(() => {
    if (!showSuggestions || displaySuggestions.length === 0) {
      return;
    }

    setActiveSuggestionIndex((prev) => {
      const next = prev + 1;
      return next >= displaySuggestions.length ? 0 : next;
    });
  }, [showSuggestions, displaySuggestions.length]);

  const handleArrowUp = useCallback(() => {
    if (!showSuggestions || displaySuggestions.length === 0) {
      return;
    }

    setActiveSuggestionIndex((prev) => {
      const next = prev - 1;
      return next < 0 ? displaySuggestions.length - 1 : next;
    });
  }, [showSuggestions, displaySuggestions.length]);

  useEffect(() => {
    if (!showSuggestions) {
      return;
    }

    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        closeSuggestions();
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [showSuggestions, closeSuggestions]);

  useEffect(() => {
    if (config.displayMode !== "dropdown") {
      return;
    }

    if (!showSuggestions) {
      return;
    }

    const shouldLockBodyScroll =
      config.lockBodyScrollOnOpen ?? window.matchMedia("(max-width: 1023px)").matches;

    if (!shouldLockBodyScroll) {
      return;
    }

    lockBodyScroll();

    return () => {
      unlockBodyScroll();
    };
  }, [showSuggestions, config.displayMode, config.lockBodyScrollOnOpen]);

  const suggestionsId = "search-suggestions";
  const activeDescendantId =
    activeSuggestionIndex >= 0 ? `suggestion-${activeSuggestionIndex}` : undefined;

  return (
    <div className={cn("relative z-30", className)} ref={containerRef}>
      {config.displayMode === "dropdown" && (
        <SearchBackdrop
          isAnimating={isAnimating}
          isVisible={showSuggestions}
          onClose={closeSuggestions}
          withBlur={config.withBackdropBlur}
        />
      )}

      <div
        className={cn(
          "relative z-50",
          config.displayMode === "pills" && "px-[var(--spacing-md)] md:px-0"
        )}
      >
        <SearchInput
          ariaActiveDescendant={activeDescendantId}
          ariaControls={suggestionsId}
          ariaExpanded={showSuggestions}
          customPlaceholder={config.customPlaceholder}
          enableVoiceRecognition={config.enableVoiceRecognition}
          inputRef={inputRef as React.RefObject<HTMLInputElement>}
          isListening={isListening}
          keepRounded={config.displayMode === "pills"}
          onArrowDown={handleArrowDown}
          onArrowUp={handleArrowUp}
          onChange={(newValue) => {
            setHasInteracted(true);
            onValueChange(newValue);
          }}
          onEscape={handleEscape}
          onSubmit={handleSubmit}
          onVoiceClick={handleVoiceClick}
          placeholder={config.placeholder}
          showSearchButton={config.showSearchButton}
          suggestionsOpen={showSuggestions}
          value={value}
          withBorder={config.withBorder}
        />
      </div>

      {config.displayMode === "pills" && config.pillsPlacement === "above" && showSuggestions && (
        <div className="mb-xs">
          <SuggestionDisplay
            isAnimating={isAnimating}
            mode="pills"
            onSelect={handleSuggestionSelect}
            pillsPlacement="above"
            suggestions={displaySuggestions}
          />
        </div>
      )}

      {config.displayMode === "dropdown" && showSuggestions && (
        <div className="absolute top-1/2 right-0 left-0 z-40">
          <SuggestionDisplay
            isAnimating={isAnimating}
            mode="dropdown"
            onSelect={handleSuggestionSelect}
            suggestions={displaySuggestions}
          />
        </div>
      )}

      {config.displayMode === "pills" &&
        config.pillsPlacement === "below" &&
        (showSuggestions || (config.quickFilters?.length ?? 0) > 0) && (
          <div className="mt-xs min-h-(--spacing-6)">
            <SuggestionDisplay
              isAnimating={isAnimating}
              mode="pills"
              onQuickFilterSelect={onQuickFilterSelect}
              onSelect={handleSuggestionSelect}
              pillsPlacement="below"
              quickFilters={value ? undefined : config.quickFilters}
              suggestions={displaySuggestions}
            />
          </div>
        )}

      {voiceError && !voiceErrorDismissed && (
        <div
          aria-live="polite"
          className={cn(
            "absolute top-full right-0 left-0 z-50 mt-xs flex items-center justify-between gap-sm rounded-lg px-sm py-xs shadow-lg",
            config.lightTheme
              ? "bg-white/10 text-white backdrop-blur-sm"
              : "bg-(--color-feedback-error-background) text-(--color-feedback-error-text)"
          )}
          role="alert"
          style={{ fontSize: "var(--font-size-xs)" }}
        >
          <span>{voiceError.message}</span>
          <button
            aria-label="Dismiss error"
            className={cn(
              "shrink-0 hover:opacity-70",
              config.lightTheme ? "text-white" : "text-(--color-feedback-error-text)"
            )}
            onClick={() => setVoiceErrorDismissed(true)}
            type="button"
          >
            <svg
              aria-hidden="true"
              className="h-4 w-4"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              viewBox="0 0 24 24"
            >
              <path d="M6 18L18 6M6 6l12 12" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>
      )}

      <output aria-atomic="true" aria-live="polite" className="sr-only">
        {showSuggestions && displaySuggestions.length > 0 && (
          <span>{displaySuggestions.length} suggestions available</span>
        )}
      </output>
    </div>
  );
};
