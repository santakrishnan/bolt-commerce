import { AppButton } from "@shared/components/button";
import Image from "next/image";
import type React from "react";
import { cn } from "@/lib/utils";

export interface SearchInputProps {
  ariaActiveDescendant?: string;

  ariaControls?: string;
  ariaExpanded?: boolean;
  className?: string;
  customPlaceholder?: React.ReactNode;
  enableVoiceRecognition?: boolean;
  inputRef?: React.RefObject<HTMLInputElement>;
  isListening?: boolean;
  keepRounded?: boolean;
  onArrowDown?: () => void;
  onArrowUp?: () => void;
  onChange: (value: string) => void;
  onEscape?: () => void;
  onSubmit: () => void;
  onVoiceClick?: () => void;
  placeholder?: string;
  showSearchButton?: boolean;
  suggestionsOpen: boolean;
  value: string;
  withBorder?: boolean;
}

export const SearchInput: React.FC<SearchInputProps> = ({
  value,
  onChange,
  onSubmit,
  onEscape,
  onArrowDown,
  onArrowUp,
  placeholder = "Try: SUV under 35k with heated seats near San Francisco",
  customPlaceholder,
  suggestionsOpen: _suggestionsOpen,
  keepRounded: _keepRounded = false,
  withBorder = false,
  enableVoiceRecognition = true,
  isListening = false,
  onVoiceClick,
  ariaControls,
  ariaExpanded,
  ariaActiveDescendant,
  className,
  inputRef,
  showSearchButton = false,
}) => {
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    switch (e.key) {
      case "Enter":
        e.preventDefault();
        onSubmit();
        break;
      case "Escape":
        if (onEscape) {
          e.preventDefault();
          onEscape();
        }
        break;
      case "ArrowDown":
        if (onArrowDown) {
          e.preventDefault();
          onArrowDown();
        }
        break;
      case "ArrowUp":
        if (onArrowUp) {
          e.preventDefault();
          onArrowUp();
        }
        break;
      default:
        // No action needed for other keys
        break;
    }
  };

  return (
    <div
      className={cn(
        "relative flex items-center",
        "bg-(--color-core-surfaces-card)",
        "pt-[var(--spacing-2xs)] pr-[var(--spacing-2xs)] pb-[var(--spacing-2xs)]",
        "pl-[var(--spacing-md)]",
        withBorder && "border border-(--color-structure-interaction-border)",
        "transition-all duration-500 ease-out",
        "rounded-full",
        className
      )}
    >
      <Image
        alt="Search"
        className="mr-xs h-[19.127px] w-[19.5px] shrink-0"
        height={19.127}
        src="/images/search_star.svg"
        style={{ aspectRatio: "19.50/19.13" }}
        width={19.5}
      />

      <div className="relative flex-1">
        {customPlaceholder && !value && (
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-y-0 left-0 flex items-center font-[var(--font-family)] text-[length:var(--font-size-sm)] text-[var(--color-core-surfaces-foreground-muted)]"
          >
            <span>{customPlaceholder}</span>
          </div>
        )}
        <input
          aria-activedescendant={ariaActiveDescendant}
          aria-autocomplete="list"
          aria-controls={ariaControls}
          aria-expanded={ariaExpanded ?? false}
          aria-label="Search for vehicles"
          autoComplete="off"
          className={cn(
            "w-full bg-transparent outline-none",
            "text-[length:var(--font-size-sm)]",
            "font-[var(--font-family)]",
            "text-[var(--color-core-surfaces-foreground)]",
            !customPlaceholder && "placeholder:text-[var(--color-core-surfaces-foreground-muted)]"
          )}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={handleKeyDown}
          onPaste={() => onChange(value)}
          placeholder={customPlaceholder ? undefined : placeholder}
          ref={inputRef}
          role="combobox"
          type="text"
          value={value}
        />
      </div>

      {enableVoiceRecognition && (
        <button
          aria-label={isListening ? "Stop voice input" : "Start voice input"}
          className={cn(
            "relative flex h-8 w-8 shrink-0 cursor-pointer items-center justify-center rounded-full transition-all duration-300",
            isListening
              ? "bg-[var(--color-brand-red)] shadow-[0_0_0_4px_rgba(235,10,30,0.2)]"
              : "bg-transparent"
          )}
          onClick={onVoiceClick}
          type="button"
        >
          {isListening && (
            <span className="absolute inset-0 animate-ping rounded-full bg-[var(--color-brand-red)] opacity-30" />
          )}
          <Image
            alt="Microphone"
            className={cn(
              "h-[18px] w-[12px] transition-all duration-300",
              isListening ? "brightness-0 invert" : ""
            )}
            height={18}
            src="/images/search_mic.svg"
            width={12}
          />
        </button>
      )}

      {showSearchButton && (
        <>
          <AppButton
            className="hidden h-[var(--spacing-10)] w-[var(--spacing-5xl)] text-[length:var(--font-size-sm)] text-[var(--color-actions-primary-foreground)] transition-colors lg:block"
            onClick={onSubmit}
            size="sm"
            type="button"
            variant="primary"
          >
            Search
          </AppButton>
          <AppButton
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[var(--color-brand-red)] p-xs lg:hidden"
            onClick={onSubmit}
            size="xs"
            type="button"
            variant="primary"
          >
            <Image
              alt="Search"
              className="h-sd w-md max-w-none"
              height={14}
              src="/images/search/vlp_search.svg"
              width={16}
            />
          </AppButton>
        </>
      )}
    </div>
  );
};
