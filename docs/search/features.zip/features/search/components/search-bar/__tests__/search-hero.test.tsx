import * as searchContext from "@features/search/context/search-context";
import { mockVehicles } from "@features/search/lib/mock-vehicles";
import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

const VEHICLES_AVAILABLE_TEXT_REGEX = /\d+ Vehicles Available/;
const WHITESPACE_REGEX = /\s+/g;
const SPLIT_WHITESPACE_REGEX = /\s+/;

vi.mock("@features/search/components/search-bar/services/autocomplete-proxy", () => {
  class AutocompleteProxyService {
    getQuickFilters = vi.fn(() => {
      const p = Promise.resolve(["dyn-a", "dyn-b"]) as any;
      p.status = "fulfilled";
      p.value = ["dyn-a", "dyn-b"];
      return p;
    });
  }
  return { AutocompleteProxyService };
});

vi.mock("@features/search/components/search-bar/search-bar", () => ({
  SearchBar: (props: any) => (
    <div data-testid="mock-searchbar">
      {props.quickFilters && (
        <div data-testid="quick-filters">{JSON.stringify(props.quickFilters)}</div>
      )}
      <button data-testid="searchbar-submit" onClick={() => props.onSubmit?.()} type="button" />
      <button
        data-testid="searchbar-quick-select"
        onClick={() => props.onQuickFilterSelect?.("QUICK_FILTER")}
        type="button"
      />
    </div>
  ),
}));

vi.mock("@features/search/context/search-context", () => ({
  useSearchContext: () => ({
    sortOption: "recommended",
    setSortOption: vi.fn(),
    progress: 0,
    isProgressVisible: true,
  }),
}));

vi.mock("@shared/components/button", () => ({
  AppButton: (props: any) => (
    <button data-testid="mock-app-button" onClick={props.onClick} type="button">
      {props.children}
    </button>
  ),
}));

vi.mock("@shared/components/custom-chips", () => ({
  CustomChips: (props: any) => <div data-testid="mock-chip">{props.label}</div>,
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Heading: (props: any) => <div data-testid="mock-heading">{props.children}</div>,
}));

vi.mock("next/image", () => ({
  __esModule: true,
  // biome-ignore lint/performance/noImgElement: test mock for next/image
  default: (props: any) => <img {...props} alt={props.alt} height={1} width={1} />,
}));

vi.stubGlobal(
  "IntersectionObserver",
  class {
    cb: any;
    constructor(cb: any) {
      this.cb = cb;
    }
    observe() {
      // default: do nothing here; tests call the mocked implementation if needed
    }
    disconnect() {
      /* noop */
    }
  }
);

import { SearchHero } from "../../search-hero";

describe("SearchHero component (unit)", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders title and vehicle count when showTitle is true", () => {
    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
        suggestedPills={["p-x"]}
        vehiclesAvailable={7}
      />
    );

    expect(screen.getByTestId("mock-heading")).toHaveTextContent("FIND YOUR NEXT CAR");
    const countEls = screen.getAllByText((_content, node) => {
      const text = node?.textContent?.replace(WHITESPACE_REGEX, " ")?.trim() || "";
      return VEHICLES_AVAILABLE_TEXT_REGEX.test(text);
    });
    expect(countEls.length).toBeGreaterThan(0);
    const countEl = countEls.find((el) => el.tagName === "P") || countEls[0];
    expect(countEl).toBeTruthy();
    const displayed = Number.parseInt(
      (countEl.textContent || "").trim().split(SPLIT_WHITESPACE_REGEX)[0],
      10
    );
    expect([7, mockVehicles.length, 50]).toContain(displayed);
  });

  it("submit triggers onSearchChange and onSearch", () => {
    const onSearchChange = vi.fn();
    const onSearch = vi.fn();

    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={onSearch}
        onSearchChange={onSearchChange}
        searchQuery="initial-query"
        suggestedPills={["p1"]}
      />
    );

    const submits = screen.getAllByTestId("searchbar-submit");
    fireEvent.click(submits.at(-1) as HTMLElement);

    expect(onSearchChange).toHaveBeenCalledWith("initial-query");
    expect(onSearch).toHaveBeenCalled();
  });

  it("quick filter selection calls onSearchChange and onSearch", () => {
    const onSearchChange = vi.fn();
    const onSearch = vi.fn();

    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={onSearch}
        onSearchChange={onSearchChange}
        searchQuery=""
        suggestedPills={["p1", "p2"]}
      />
    );

    const quicks = screen.getAllByTestId("searchbar-quick-select");
    fireEvent.click(quicks.at(-1) as HTMLElement);

    expect(onSearchChange).toHaveBeenCalledWith("QUICK_FILTER");
    expect(onSearch).toHaveBeenCalled();
  });

  it("renders applied filters and Reset button when activeFilters are present and sticky header is shown", () => {
    vi.stubGlobal(
      "IntersectionObserver",
      class {
        cb: any;
        constructor(cb: any) {
          this.cb = cb;
        }
        observe() {
          this.cb([{ isIntersecting: false }]);
        }
        disconnect() {
          /* noop */
        }
      }
    );

    const onReset = vi.fn();
    const onRemoveFilter = vi.fn();

    render(
      <SearchHero
        activeFilters={[{ type: "type", value: "val", label: "Label", isRefineSearch: false }]}
        onRemoveFilter={onRemoveFilter}
        onReset={onReset}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
        suggestedPills={["p-x"]}
      />
    );

    expect(screen.getByTestId("mock-chip")).toHaveTextContent("Label");
    const appButtons = screen.getAllByTestId("mock-app-button");
    expect(appButtons.some((b) => b.textContent === "Reset")).toBe(true);
  });

  it("progress bar transition changes for 0, mid, and 100 progress values", () => {
    (searchContext as any).useSearchContext = () =>
      ({
        sortOption: "recommended",
        setSortOption: vi.fn(),
        progress: 0,
        isProgressVisible: true,
      }) as any;

    vi.stubGlobal(
      "IntersectionObserver",
      class {
        cb: any;
        constructor(cb: any) {
          this.cb = cb;
        }
        observe() {
          this.cb([{ isIntersecting: false }]);
        }
        disconnect() {
          /* noop */
        }
      }
    );

    const { unmount } = render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
        suggestedPills={["p-x"]}
      />
    );

    let bar = document.querySelector("div[aria-hidden]") as HTMLDivElement | null;
    expect(bar).not.toBeNull();
    expect(bar?.style.transition).toBe("none");

    unmount();

    (searchContext as any).useSearchContext = () =>
      ({
        sortOption: "recommended",
        setSortOption: vi.fn(),
        progress: 42,
        isProgressVisible: true,
      }) as any;

    const { unmount: u2 } = render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
        suggestedPills={["p-x"]}
      />
    );

    bar = document.querySelector("div[aria-hidden]") as HTMLDivElement | null;
    expect(bar).not.toBeNull();
    expect(bar?.style.transition).toContain("cubic-bezier");

    u2();

    (searchContext as any).useSearchContext = () =>
      ({
        sortOption: "recommended",
        setSortOption: vi.fn(),
        progress: 100,
        isProgressVisible: true,
      }) as any;

    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
        suggestedPills={["p-x"]}
      />
    );

    bar = document.querySelector("div[aria-hidden]") as HTMLDivElement | null;
    expect(bar).not.toBeNull();
    expect(bar?.style.transition).toContain("0.25s");
  });
});
