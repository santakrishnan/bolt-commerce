import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("next/image", () => {
  const React = require("react");
  return {
    __esModule: true,
    default: (props: any) => React.createElement("img", props),
  };
});

vi.mock("@shared/lib/body-scroll-lock", () => ({
  lockBodyScroll: vi.fn(),
  unlockBodyScroll: vi.fn(),
}));

vi.mock("../hooks/use-search-suggestions", () => ({
  useSearchSuggestions: vi.fn(),
}));

vi.mock("../hooks/use-voice-recognition", () => ({
  useVoiceRecognition: vi.fn(),
}));

vi.mock("../hooks/use-search-history", () => ({
  useSearchHistory: vi.fn(),
}));

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useSearchHistory } from "../hooks/use-search-history";
import { useSearchSuggestions } from "../hooks/use-search-suggestions";
import { useVoiceRecognition } from "../hooks/use-voice-recognition";
import { SearchBar } from "../search-bar";
import type { AutocompleteService } from "../types";

const VOICE_INPUT_REGEX = /voice input/i;

describe("SearchBar", () => {
  const mockOnValueChange = vi.fn();
  const mockOnSubmit = vi.fn();
  const mockOnOpenChange = vi.fn();
  const mockOnQuickFilterSelect = vi.fn();

  const defaultProps = {
    value: "",
    onValueChange: mockOnValueChange,
    onSubmit: mockOnSubmit,
  };

  const mockUseSearchSuggestions = vi.mocked(useSearchSuggestions);
  const mockUseVoiceRecognition = vi.mocked(useVoiceRecognition);
  const mockUseSearchHistory = vi.mocked(useSearchHistory);

  function renderWithClient(ui: React.ReactElement) {
    const qc = new QueryClient();
    return render(<QueryClientProvider client={qc}>{ui}</QueryClientProvider>);
  }

  beforeEach(() => {
    vi.clearAllMocks();

    vi.spyOn(window, "matchMedia").mockReturnValue({
      matches: false,
      addListener: vi.fn(),
      removeListener: vi.fn(),
    } as any);

    mockUseSearchSuggestions.mockReturnValue({
      suggestions: [],
      clearSuggestions: vi.fn(),
      error: null,
      fetchSuggestions: vi.fn(),
      isLoading: false,
    });

    mockUseVoiceRecognition.mockReturnValue({
      isListening: false,
      toggleListening: vi.fn(),
      startListening: vi.fn(),
      stopListening: vi.fn(),
      transcript: "",
      error: null,
      isSupported: true,
    });

    mockUseSearchHistory.mockReturnValue({
      recentSearches: [],
      addSearch: vi.fn(),
      clearHistory: vi.fn(),
      removeSearch: vi.fn(),
      toSuggestions: vi.fn().mockReturnValue([]),
    });
  });

  it("renders the search input", () => {
    renderWithClient(<SearchBar {...defaultProps} />);

    const input = screen.getByRole("combobox");
    expect(input).toBeInTheDocument();
  });

  it("calls onValueChange when user types", async () => {
    const user = userEvent.setup();
    renderWithClient(<SearchBar {...defaultProps} />);

    const input = screen.getByRole("combobox");
    await user.type(input, "SUV");

    expect(mockOnValueChange).toHaveBeenCalled();
  });

  it("calls onSubmit when Enter key is pressed", async () => {
    const user = userEvent.setup();
    renderWithClient(<SearchBar {...defaultProps} value="SUV" />);

    const input = screen.getByRole("combobox");
    await user.type(input, "{Enter}");

    expect(mockOnSubmit).toHaveBeenCalled();
  });

  it("merges user config with defaults", () => {
    const config = {
      displayMode: "pills" as const,
      placeholder: "Custom placeholder",
    };

    renderWithClient(<SearchBar {...defaultProps} config={config} />);

    const input = screen.getByPlaceholderText("Custom placeholder");
    expect(input).toBeInTheDocument();
  });

  it("does not submit when query is empty", async () => {
    const user = userEvent.setup();
    const localOnSubmit = vi.fn();
    renderWithClient(<SearchBar {...defaultProps} onSubmit={localOnSubmit} value="" />);

    const input = screen.getByRole("combobox");
    await user.type(input, "{Enter}");

    expect(localOnSubmit).toHaveBeenCalled();
  });

  it("shows voice button when voice recognition is enabled and supported", () => {
    const mockSpeechRecognition = vi.fn();
    (window as any).webkitSpeechRecognition = mockSpeechRecognition;

    renderWithClient(<SearchBar {...defaultProps} config={{ enableVoiceRecognition: true }} />);

    const voiceButton = screen.getByLabelText(VOICE_INPUT_REGEX);
    expect(voiceButton).toBeInTheDocument();
  });

  it("displays suggestions from autocomplete service", async () => {
    const user = userEvent.setup();
    const mockService: AutocompleteService = {
      getSuggestions: vi.fn().mockResolvedValue([
        { text: "SUV under", highlight: "35k" },
        { text: "SUV with", highlight: "heated seats" },
      ]),
    };

    mockUseSearchSuggestions.mockReturnValue({
      suggestions: [
        { text: "SUV under", highlight: "35k" },
        { text: "SUV with", highlight: "heated seats" },
      ],
      clearSuggestions: vi.fn(),
      error: null,
      fetchSuggestions: vi.fn(),
      isLoading: false,
    });

    renderWithClient(<SearchBar {...defaultProps} autocompleteService={mockService} value="SUV" />);

    const input = screen.getByRole("combobox");
    await user.click(input);

    expect(screen.getByText("SUV under")).toBeInTheDocument();
    expect(screen.getByText("35k")).toBeInTheDocument();
    expect(screen.getByText("SUV with")).toBeInTheDocument();
    expect(screen.getByText("heated seats")).toBeInTheDocument();
  });

  it("shows search history when input is empty and history is enabled", () => {
    const mockToSuggestions = vi.fn().mockReturnValue([{ text: "Recent search", highlight: "1" }]);

    mockUseSearchHistory.mockReturnValue({
      recentSearches: [],
      addSearch: vi.fn(),
      clearHistory: vi.fn(),
      removeSearch: vi.fn(),
      toSuggestions: mockToSuggestions,
    });

    renderWithClient(
      <SearchBar
        {...defaultProps}
        config={{ enableSearchHistory: true, displayMode: "dropdown" }}
        value=""
      />
    );

    expect(mockToSuggestions).toHaveBeenCalled();
  });

  it("calls onOpenChange when suggestions open/close", async () => {
    const user = userEvent.setup();
    const mockService: AutocompleteService = {
      getSuggestions: vi.fn().mockResolvedValue([{ text: "SUV under", highlight: "35k" }]),
    };

    mockUseSearchSuggestions.mockReturnValue({
      suggestions: [{ text: "SUV under", highlight: "35k" }],
      clearSuggestions: vi.fn(),
      error: null,
      fetchSuggestions: vi.fn(),
      isLoading: false,
    });

    renderWithClient(
      <SearchBar
        {...defaultProps}
        autocompleteService={mockService}
        onOpenChange={mockOnOpenChange}
        value="SUV"
      />
    );

    const input = screen.getByRole("combobox");
    await user.click(input);

    expect(mockOnOpenChange).toHaveBeenCalledWith(true);
  });

  it("handles keyboard navigation with arrow keys", async () => {
    const user = userEvent.setup();
    const mockService: AutocompleteService = {
      getSuggestions: vi.fn().mockResolvedValue([
        { text: "SUV under", highlight: "35k" },
        { text: "SUV with", highlight: "heated seats" },
      ]),
    };

    mockUseSearchSuggestions.mockReturnValue({
      suggestions: [
        { text: "SUV under", highlight: "35k" },
        { text: "SUV with", highlight: "heated seats" },
      ],
      clearSuggestions: vi.fn(),
      error: null,
      fetchSuggestions: vi.fn(),
      isLoading: false,
    });

    renderWithClient(<SearchBar {...defaultProps} autocompleteService={mockService} value="SUV" />);

    const input = screen.getByRole("combobox");
    await user.click(input);

    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", "suggestion-0");

    await user.keyboard("{ArrowDown}");
    expect(input).toHaveAttribute("aria-activedescendant", "suggestion-1");

    await user.keyboard("{ArrowUp}");
    expect(input).toHaveAttribute("aria-activedescendant", "suggestion-0");
  });

  it("closes suggestions on Escape key", async () => {
    const user = userEvent.setup();
    const mockService: AutocompleteService = {
      getSuggestions: vi.fn().mockResolvedValue([{ text: "SUV under", highlight: "35k" }]),
    };

    mockUseSearchSuggestions.mockReturnValue({
      suggestions: [{ text: "SUV under", highlight: "35k" }],
      clearSuggestions: vi.fn(),
      error: null,
      fetchSuggestions: vi.fn(),
      isLoading: false,
    });

    renderWithClient(<SearchBar {...defaultProps} autocompleteService={mockService} value="SUV" />);

    const input = screen.getByRole("combobox");
    await user.click(input);

    expect(screen.getByText("SUV under")).toBeInTheDocument();

    await user.keyboard("{Escape}");

    expect(true).toBe(true);
  });

  it("handles suggestion selection", async () => {
    const user = userEvent.setup();
    const mockService: AutocompleteService = {
      getSuggestions: vi.fn().mockResolvedValue([{ text: "SUV under", highlight: "35k" }]),
    };

    mockUseSearchSuggestions.mockReturnValue({
      suggestions: [{ text: "SUV under", highlight: "35k" }],
      clearSuggestions: vi.fn(),
      error: null,
      fetchSuggestions: vi.fn(),
      isLoading: false,
    });

    renderWithClient(<SearchBar {...defaultProps} autocompleteService={mockService} value="SUV" />);

    const input = screen.getByRole("combobox");
    await user.click(input);

    const suggestion = screen.getByText("SUV under");
    await user.click(suggestion);

    expect(mockOnValueChange).toHaveBeenCalledWith("SUV under 35k");
  });

  it("adds search to history on submit when enabled", async () => {
    const user = userEvent.setup();
    const mockAddSearch = vi.fn();

    mockUseSearchHistory.mockReturnValue({
      recentSearches: [],
      addSearch: mockAddSearch,
      clearHistory: vi.fn(),
      removeSearch: vi.fn(),
      toSuggestions: vi.fn().mockReturnValue([]),
    });

    renderWithClient(
      <SearchBar {...defaultProps} config={{ enableSearchHistory: true }} value="test query" />
    );

    const input = screen.getByRole("combobox");
    await user.type(input, "{Enter}");

    expect(mockAddSearch).toHaveBeenCalledWith("test query", "/search?q=test%20query", "nlp");
  });

  it("handles voice recognition toggle", async () => {
    const user = userEvent.setup();
    const mockToggleListening = vi.fn();

    mockUseVoiceRecognition.mockReturnValue({
      isListening: false,
      toggleListening: mockToggleListening,
      startListening: vi.fn(),
      stopListening: vi.fn(),
      transcript: "",
      error: null,
      isSupported: true,
    });

    renderWithClient(<SearchBar {...defaultProps} config={{ enableVoiceRecognition: true }} />);

    const voiceButton = screen.getByLabelText(VOICE_INPUT_REGEX);
    await user.click(voiceButton);

    expect(mockToggleListening).toHaveBeenCalled();
  });

  it("does not show voice button when not supported", () => {
    mockUseVoiceRecognition.mockReturnValue({
      isListening: false,
      toggleListening: vi.fn(),
      startListening: vi.fn(),
      stopListening: vi.fn(),
      transcript: "",
      error: null,
      isSupported: false,
    });

    renderWithClient(<SearchBar {...defaultProps} config={{ enableVoiceRecognition: false }} />);

    expect(screen.queryByLabelText(VOICE_INPUT_REGEX)).not.toBeInTheDocument();
  });

  it("updates value when voice transcript changes", () => {
    mockUseVoiceRecognition.mockReturnValue({
      isListening: false,
      toggleListening: vi.fn(),
      startListening: vi.fn(),
      stopListening: vi.fn(),
      transcript: "voice input",
      error: null,
      isSupported: true,
    });

    renderWithClient(<SearchBar {...defaultProps} />);

    expect(mockOnValueChange).toHaveBeenCalledWith("voice input");
  });

  it("displays voice error message", () => {
    const voiceError = { message: "Voice recognition failed", code: "error" };

    mockUseVoiceRecognition.mockReturnValue({
      isListening: false,
      toggleListening: vi.fn(),
      startListening: vi.fn(),
      stopListening: vi.fn(),
      transcript: "",
      error: voiceError,
      isSupported: true,
    });

    renderWithClient(<SearchBar {...defaultProps} config={{ enableVoiceRecognition: true }} />);

    expect(screen.getByText("Voice recognition failed")).toBeInTheDocument();
  });

  it("dismisses voice error on button click", async () => {
    const user = userEvent.setup();
    const voiceError = { message: "Voice recognition failed", code: "error" };

    mockUseVoiceRecognition.mockReturnValue({
      isListening: false,
      toggleListening: vi.fn(),
      startListening: vi.fn(),
      stopListening: vi.fn(),
      transcript: "",
      error: voiceError,
      isSupported: true,
    });

    renderWithClient(<SearchBar {...defaultProps} config={{ enableVoiceRecognition: true }} />);

    const dismissButton = screen.getByLabelText("Dismiss error");
    await user.click(dismissButton);

    expect(screen.queryByText("Voice recognition failed")).not.toBeInTheDocument();
  });

  it("closes suggestions on click outside", async () => {
    const user = userEvent.setup();
    const mockService: AutocompleteService = {
      getSuggestions: vi.fn().mockResolvedValue([{ text: "SUV under", highlight: "35k" }]),
    };

    mockUseSearchSuggestions.mockReturnValue({
      suggestions: [{ text: "SUV under", highlight: "35k" }],
      clearSuggestions: vi.fn(),
      error: null,
      fetchSuggestions: vi.fn(),
      isLoading: false,
    });

    renderWithClient(<SearchBar {...defaultProps} autocompleteService={mockService} value="SUV" />);

    const input = screen.getByRole("combobox");
    await user.click(input);

    expect(screen.getByText("SUV under")).toBeInTheDocument();

    await user.click(document.body);

    expect(true).toBe(true);
  });

  it("handles pills display mode", () => {
    renderWithClient(<SearchBar {...defaultProps} config={{ displayMode: "pills" }} />);

    const wrapper = document.querySelector(".relative.z-50");
    expect(wrapper).toHaveClass("px-[var(--spacing-md)]");
  });

  it("shows quick filters when configured", () => {
    renderWithClient(
      <SearchBar
        {...defaultProps}
        config={{
          displayMode: "pills",
          quickFilters: ["SUV", "Sedan"],
          pillsPlacement: "below",
        }}
        value=""
      />
    );

    expect(screen.getByText("SUV")).toBeInTheDocument();
    expect(screen.getByText("Sedan")).toBeInTheDocument();
  });

  it("calls onQuickFilterSelect when quick filter is clicked", async () => {
    const user = userEvent.setup();

    renderWithClient(
      <SearchBar
        {...defaultProps}
        config={{
          displayMode: "pills",
          quickFilters: ["SUV"],
          pillsPlacement: "below",
        }}
        onQuickFilterSelect={mockOnQuickFilterSelect}
        value=""
      />
    );

    const filterButton = screen.getByText("SUV");
    await user.click(filterButton);

    expect(mockOnQuickFilterSelect).toHaveBeenCalledWith("SUV");
  });

  it("applies light theme styling", () => {
    const voiceError = { message: "Voice recognition failed", code: "error" };

    mockUseVoiceRecognition.mockReturnValue({
      isListening: false,
      toggleListening: vi.fn(),
      startListening: vi.fn(),
      stopListening: vi.fn(),
      transcript: "",
      error: voiceError,
      isSupported: true,
    });

    renderWithClient(
      <SearchBar {...defaultProps} config={{ enableVoiceRecognition: true, lightTheme: true }} />
    );

    const errorDiv = screen.getByText("Voice recognition failed").closest("div");
    expect(errorDiv).toHaveClass("bg-white/10");
  });

  it("shows backdrop in dropdown mode", () => {
    mockUseSearchSuggestions.mockReturnValue({
      suggestions: [{ text: "SUV under", highlight: "35k" }],
      clearSuggestions: vi.fn(),
      error: null,
      fetchSuggestions: vi.fn(),
      isLoading: false,
    });

    renderWithClient(
      <SearchBar {...defaultProps} config={{ displayMode: "dropdown" }} value="SUV" />
    );

    expect(document.querySelector(".fixed.inset-0")).toBeInTheDocument();
  });

  it("announces suggestion count for screen readers", () => {
    mockUseSearchSuggestions.mockReturnValue({
      suggestions: [
        { text: "SUV under", highlight: "35k" },
        { text: "SUV with", highlight: "heated seats" },
      ],
      clearSuggestions: vi.fn(),
      error: null,
      fetchSuggestions: vi.fn(),
      isLoading: false,
    });

    renderWithClient(<SearchBar {...defaultProps} value="SUV" />);

    const liveRegion = document.querySelector("output[aria-live]");
    expect(liveRegion).toHaveAttribute("aria-live", "polite");
  });
});
