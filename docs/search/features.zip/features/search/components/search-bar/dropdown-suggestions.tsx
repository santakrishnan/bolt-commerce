import type React from "react";
import { cn } from "@/lib/utils";
import type { Suggestion } from "./types";

export interface DropdownSuggestionsProps {
  activeDescendantId?: string;
  isAnimating: boolean;
  onSelect: (suggestion: Suggestion) => void;
  onSuggestionFocus?: (index: number) => void;
  suggestions: Suggestion[];
}

export const DropdownSuggestions: React.FC<DropdownSuggestionsProps> = ({
  suggestions,
  isAnimating,
  onSelect,
  activeDescendantId,
  onSuggestionFocus,
}) => {
  if (suggestions.length === 0) {
    return null;
  }

  return (
    <div
      className={cn(
        "absolute right-0 left-0 z-10",
        "bg-(--color-core-surfaces-card)",
        "border border-(--color-structure-interaction-border)",
        "border-t-0",
        "rounded-t-none rounded-b-3xl",
        "overflow-hidden",
        "shadow-lg",
        "top-0",
        "origin-top transition-all duration-200 ease-out",
        isAnimating
          ? "-translate-y-1 scale-y-95 opacity-0"
          : "translate-y-0 scale-y-100 opacity-100"
      )}
      id="search-suggestions"
      role="listbox"
    >
      <div className="pt-lg pb-xs">
        {suggestions.map((suggestion, index) => {
          const suggestionId = `suggestion-${index}`;
          const isActive = activeDescendantId === suggestionId;

          return (
            <div
              aria-selected={isActive}
              className={cn(
                "group search-dropdown-item",
                "px-md",
                "py-sm",
                "cursor-pointer",
                "transition-colors duration-150",
                "hover:bg-gray-100",
                isActive && "bg-gray-100",
                "text-(--font-size-sm)",
                "font-(--font-family)"
              )}
              id={suggestionId}
              key={suggestion.id || `${suggestion.text}-${index}`}
              onClick={() => onSelect(suggestion)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  onSelect(suggestion);
                }
              }}
              onMouseEnter={() => onSuggestionFocus?.(index)}
              role="option"
              tabIndex={-1}
            >
              <span className="text-(--color-core-surfaces-foreground-muted) transition-colors group-hover:text-(--color-core-surfaces-foreground)">
                {suggestion.text}
              </span>
              {suggestion.highlight && (
                <>
                  {" "}
                  <span className="font-semibold text-(--color-core-surfaces-foreground) transition-colors group-hover:text-(--color-brand-text-primary)">
                    {suggestion.highlight}
                  </span>
                </>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
