import type React from "react";
import { cn } from "@/lib/utils";

export interface SearchBackdropProps {
  isAnimating?: boolean;
  isVisible: boolean;
  onClose: () => void;
  withBlur?: boolean;
}

export const SearchBackdrop: React.FC<SearchBackdropProps> = ({
  isVisible,
  onClose,
  isAnimating = false,
  withBlur = true,
}) => {
  if (!isVisible) {
    return null;
  }

  return (
    <div
      aria-hidden="true"
      className={cn(
        "fixed inset-0 z-40",
        "bg-black/20",
        withBlur && "backdrop-blur-sm",
        "transition-opacity duration-200 ease-out",
        isAnimating ? "opacity-0" : "opacity-100"
      )}
      onClick={onClose}
      onKeyDown={(e) => {
        if (e.key === "Escape") {
          e.preventDefault();
          onClose();
        }
      }}
      role="presentation"
      tabIndex={-1}
    />
  );
};
