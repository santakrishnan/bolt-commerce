// NLP-aware autocomplete service generating contextual suggestions from `filterSections` without hardcoding.
import { filterSections } from "@features/search/lib/filter-sections";
import type { Vehicle } from "@shared/vehicle";
import type { AutocompleteService, Suggestion } from "../types";

const BODY_TYPES = filterSections.bodyStyle;
const BODY_TYPE_SET = new Set(BODY_TYPES.map((s) => s.toLowerCase()));

const POPULAR_FEATURES = [
  ...filterSections.comfortFeatures.slice(0, 6),
  ...filterSections.techFeatures.slice(0, 4),
  ...filterSections.safetyFeatures.slice(0, 3),
  ...filterSections.exteriorFeatures.slice(0, 3),
];

const PRICE_TIERS = ["20K", "25K", "30K", "35K", "40K", "50K"];

const MILEAGE_DESCRIPTORS = ["Low Miles", "Under 30K Miles", "Under 50K Miles"];

const WHITESPACE_RE = /\s+/;
const PRICE_INTENT_RE = /\b(under|below|less than)\b/;
const MILEAGE_INTENT_RE = /\b(low[\s-]?mile|miles?|mileage)\b/;

interface SuggestionTemplate {
  generate: (query: string, maxResults: number) => Suggestion[];
  match: (query: string) => boolean;
}

// Generates body-type completions like "SUV under 35K with Low Miles".
function bodyTypeCompletions(bodyType: string, maxResults: number): Suggestion[] {
  const label = BODY_TYPES.find((b) => b.toLowerCase() === bodyType.toLowerCase()) ?? bodyType;
  const suggestions: Suggestion[] = [];

  for (const price of PRICE_TIERS) {
    if (suggestions.length >= maxResults) {
      break;
    }
    suggestions.push({
      text: `${label} under ${price} with`,
      highlight: "Low Miles",
      id: `${bodyType}-price-${price}`,
    });
  }

  for (const feature of POPULAR_FEATURES) {
    if (suggestions.length >= maxResults) {
      break;
    }
    suggestions.push({
      text: `${label} under 35K with`,
      highlight: feature,
      id: `${bodyType}-feat-${feature}`,
    });
  }

  return suggestions.slice(0, maxResults);
}

// Generates price-based completions like "Cars under $20,000" or "SUV under 35K".
function priceCompletions(query: string, maxResults: number): Suggestion[] {
  const suggestions: Suggestion[] = [];

  const words = query.split(WHITESPACE_RE);
  const bodyIdx = words.findIndex((w) => BODY_TYPE_SET.has(w));
  const bodyType =
    bodyIdx >= 0
      ? (BODY_TYPES.find((b) => b.toLowerCase() === words[bodyIdx]) ?? words[bodyIdx])
      : null;
  const prefix = bodyType ?? "Cars";

  for (const price of PRICE_TIERS) {
    if (suggestions.length >= maxResults) {
      break;
    }
    suggestions.push({
      text: `${prefix} under ${price} with`,
      highlight: "Low Miles",
      id: `price-${price}`,
    });
  }

  return suggestions;
}

//Generates model completions like "Toyota Camry" from the vehicle inventory.
function modelCompletions(query: string, vehicles: Vehicle[], maxResults: number): Suggestion[] {
  const seen = new Map<string, Suggestion>();

  for (const v of vehicles) {
    if (seen.size >= maxResults) {
      break;
    }

    const make = v.make;
    const model = v.model
      .split("-")
      .map((w) => (w.length <= 3 ? w.toUpperCase() : w[0]?.toUpperCase() + w.slice(1)))
      .join(" ");

    const key = `${make} ${model}`.toLowerCase();
    if (key.includes(query) && !seen.has(key)) {
      seen.set(key, {
        text: make,
        highlight: model,
        id: `model-${v.id}`,
      });
    }
  }

  return Array.from(seen.values());
}

function buildTemplates(vehicles: Vehicle[]): SuggestionTemplate[] {
  return [
    {
      match: (q) => {
        const words = q.split(WHITESPACE_RE);
        return words.some((w) => BODY_TYPE_SET.has(w));
      },
      generate: (q, max) => {
        const words = q.split(WHITESPACE_RE);
        const bt = words.find((w) => BODY_TYPE_SET.has(w)) ?? "";
        return bodyTypeCompletions(bt, max);
      },
    },
    {
      match: (q) => PRICE_INTENT_RE.test(q),
      generate: (q, max) => priceCompletions(q, max),
    },
    {
      match: (q) => MILEAGE_INTENT_RE.test(q),
      generate: (_q, max) => {
        const suggestions: Suggestion[] = [];
        for (const bt of BODY_TYPES.slice(0, 3)) {
          for (const desc of MILEAGE_DESCRIPTORS) {
            if (suggestions.length >= max) {
              break;
            }
            suggestions.push({
              text: `${bt} with`,
              highlight: desc,
              id: `mile-${bt}-${desc}`,
            });
          }
        }
        return suggestions.slice(0, max);
      },
    },
    {
      match: (q) =>
        POPULAR_FEATURES.some((f) => f.toLowerCase().includes(q) || q.includes(f.toLowerCase())),
      generate: (q, max) => {
        const matchedFeature = POPULAR_FEATURES.find(
          (f) => f.toLowerCase().includes(q) || q.includes(f.toLowerCase())
        );
        if (!matchedFeature) {
          return [];
        }
        return BODY_TYPES.slice(0, max).map((bt) => ({
          text: `${bt} with`,
          highlight: matchedFeature,
          id: `feat-${bt}-${matchedFeature}`,
        }));
      },
    },
    {
      match: () => true,
      generate: (q, max) => modelCompletions(q, vehicles, max),
    },
  ];
}

export class NlpAutocompleteService implements AutocompleteService {
  private readonly templates: SuggestionTemplate[];

  constructor(vehicles: Vehicle[] = []) {
    this.templates = buildTemplates(vehicles);
  }

  async getSuggestions(query: string, maxResults: number): Promise<Suggestion[]> {
    await new Promise((resolve) => setTimeout(resolve, 50));

    const normalized = query.trim().toLowerCase().replace(/[-_]+/g, " ");
    if (normalized.length === 0) {
      return [];
    }

    for (const template of this.templates) {
      if (template.match(normalized)) {
        const results = template.generate(normalized, maxResults);
        if (results.length > 0) {
          return results.slice(0, maxResults);
        }
      }
    }

    return [];
  }
}

// Generates quick-filter pill labels dynamically from inventory and filter data.
export function generateQuickFilterPills(vehicles: Vehicle[]): string[] {
  const pills: string[] = [];

  const bodyCount = new Map<string, number>();
  for (const v of vehicles) {
    bodyCount.set(v.bodyType, (bodyCount.get(v.bodyType) ?? 0) + 1);
  }
  const topBodyTypes = [...bodyCount.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 2)
    .map(([bt]) => bt);

  for (const bt of topBodyTypes) {
    pills.push(`${bt} under 35K`);
  }

  pills.push("Low Miles");

  pills.push("Cars under $20,000");

  return pills;
}
