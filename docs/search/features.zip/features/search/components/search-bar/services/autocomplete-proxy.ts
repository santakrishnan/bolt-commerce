import type { AutocompleteResponse } from "~/app/api/search/autocomplete/route";
import type { AutocompleteService, Suggestion } from "../types";

export class AutocompleteProxyService implements AutocompleteService {
  private readonly baseUrl: string;
  private quickFiltersCache: string[] | null = null;

  constructor(baseUrl = "/api/search/autocomplete") {
    this.baseUrl = baseUrl;
  }

  async getSuggestions(query: string, maxResults: number): Promise<Suggestion[]> {
    const trimmed = query.trim();
    if (trimmed.length === 0) {
      return [];
    }

    try {
      const url = `${this.baseUrl}?q=${encodeURIComponent(trimmed)}&max=${maxResults}`;
      const res = await fetch(url);

      if (!res.ok) {
        console.error(`[AutocompleteProxy] ${res.status} ${res.statusText}`);
        return [];
      }

      const data: AutocompleteResponse = await res.json();

      if (data.quickFilters) {
        this.quickFiltersCache = data.quickFilters;
      }

      return data.autoCompletions;
    } catch (err) {
      console.error("[AutocompleteProxy] fetch failed:", err);
      return [];
    }
  }

  //Fetches quick-filter pills with an empty query from the autocomplete endpoint.
  async getQuickFilters(): Promise<string[]> {
    if (this.quickFiltersCache) {
      return this.quickFiltersCache;
    }

    try {
      const res = await fetch(`${this.baseUrl}?q=&max=0`);
      if (!res.ok) {
        return [];
      }

      const data: AutocompleteResponse = await res.json();
      this.quickFiltersCache = data.quickFilters;
      return data.quickFilters;
    } catch {
      return [];
    }
  }
}
