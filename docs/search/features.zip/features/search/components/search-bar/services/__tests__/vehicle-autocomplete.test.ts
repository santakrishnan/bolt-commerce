import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { VehicleAutocompleteService } from "../vehicle-autocomplete";

const TOYOTA_REGEX = /toyota/i;
const CAMRY_REGEX = /camry/i;

describe("VehicleAutocompleteService", () => {
  let svc: VehicleAutocompleteService;
  const vehicles = [
    {
      id: "1",
      title: "Toyota Camry LE",
      make: "Toyota",
      model: "camry",
      variant: "LE",
      year: 2020,
      vin: "vin1",
    },
    {
      id: "2",
      title: "Toyota Camry SE",
      make: "Toyota",
      model: "camry-le",
      variant: "SE",
      year: 2021,
      vin: "vin2",
    },
    {
      id: "3",
      title: "Honda Civic LX",
      make: "Honda",
      model: "civic",
      variant: "LX",
      year: 2019,
      vin: "vin3",
    },
    {
      id: "4",
      title: "Unique Title Example",
      make: "Brand",
      model: "unique",
      variant: "X",
      year: 2018,
      vin: "vin4",
    },
  ];

  beforeEach(() => {
    vi.useFakeTimers();
    svc = new VehicleAutocompleteService(vehicles as any);
  });

  afterEach(() => {
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  it("returns empty array for empty or whitespace-only query", async () => {
    const p = svc.getSuggestions("   ", 5);
    vi.advanceTimersByTime(50);
    const out = await p;
    expect(Array.isArray(out)).toBe(true);
    expect(out.length).toBe(0);
  });

  it("matches by make (case-insensitive) and returns make/model suggestions", async () => {
    const p = svc.getSuggestions("toy", 5);
    vi.advanceTimersByTime(50);
    const out = await p;

    expect(out.length).toBeGreaterThan(0);
    expect(out.some((s) => TOYOTA_REGEX.test(s.text))).toBe(true);
    expect(out.every((s) => typeof s.highlight === "string" && s.highlight.length > 0)).toBe(true);
  });

  it("matches by model and deduplicates make-model pairs", async () => {
    const p = svc.getSuggestions("camry", 10);
    vi.advanceTimersByTime(50);
    const out = await p;

    expect(out.some((s) => CAMRY_REGEX.test(s.highlight))).toBe(true);
    const ids = out.map((s) => s.id);
    const uniqueIds = Array.from(new Set(ids));
    expect(uniqueIds.length).toBe(ids.length);
  });

  it("matches by title and splits text/highlight without coupling to implementation details", async () => {
    const p = svc.getSuggestions("Unique Title", 3);
    vi.advanceTimersByTime(50);
    const out = await p;

    expect(out.length).toBeGreaterThan(0);
    const reconstructed = out.map((s) => `${s.text} ${s.highlight}`.toLowerCase()).join(" ");
    expect(reconstructed).toContain("unique title");
  });

  it("respects maxResults and returns at most that many items", async () => {
    const p2 = svc.getSuggestions("camry", 1);
    vi.advanceTimersByTime(50);
    const out = await p2;
    expect(out.length).toBeLessThanOrEqual(1);
  });

  it("normalizes hyphens/underscores in input and vehicle data before matching", async () => {
    const p = svc.getSuggestions("camry le", 5);
    vi.advanceTimersByTime(50);
    const out = await p;
    expect(out.some((s) => CAMRY_REGEX.test(s.highlight) || CAMRY_REGEX.test(s.text))).toBe(true);
  });

  it("is asynchronous and resolves only after the simulated delay", async () => {
    const p = svc.getSuggestions("civic", 2);
    let resolved = false;
    p.then(() => (resolved = true));

    expect(resolved).toBe(false);
    vi.advanceTimersByTime(50);
    await p;
    expect(resolved).toBe(true);
  });
});
