import type { Vehicle as SharedVehicle } from "@shared/types";
import type { AutocompleteService, Suggestion } from "../types";

export type Vehicle = Pick<
  SharedVehicle,
  | "id"
  | "title"
  | "make"
  | "model"
  | "variant"
  | "year"
  | "vin"
  | "price"
  | "image"
  | "miles"
  | "odometer"
  | "match"
  | "labels"
  | "owners"
  | "extColorName"
  | "extColorCode"
  | "intColorName"
  | "intColorCode"
>;

// Provides vehicle-based autocomplete suggestions filtered by make, model, or title.
export class VehicleAutocompleteService implements AutocompleteService {
  private readonly vehicles: Vehicle[];

  constructor(vehicles: Vehicle[]) {
    this.vehicles = vehicles;
  }

  async getSuggestions(query: string, maxResults: number): Promise<Suggestion[]> {
    await new Promise((resolve) => setTimeout(resolve, 50));

    const normalizedQuery = query.toLowerCase().trim();

    if (normalizedQuery.length === 0) {
      return [];
    }

    const uniqueSuggestions = new Map<string, Suggestion>();

    for (const vehicle of this.vehicles) {
      if (uniqueSuggestions.size >= maxResults) {
        break;
      }

      const make = vehicle.make.toLowerCase();
      const model = vehicle.model.toLowerCase();
      const title = vehicle.title.toLowerCase();

      if (make.includes(normalizedQuery)) {
        const key = `${vehicle.make} ${vehicle.model}`;
        if (!uniqueSuggestions.has(key)) {
          uniqueSuggestions.set(key, {
            text: vehicle.make,
            highlight: vehicle.model,
            id: `make-model-${vehicle.id}`,
          });
        }
      } else if (model.includes(normalizedQuery)) {
        const key = `${vehicle.make} ${vehicle.model}`;
        if (!uniqueSuggestions.has(key)) {
          uniqueSuggestions.set(key, {
            text: vehicle.make,
            highlight: vehicle.model,
            id: `model-${vehicle.id}`,
          });
        }
      } else if (title.includes(normalizedQuery)) {
        const key = vehicle.title;
        if (!uniqueSuggestions.has(key)) {
          const words = vehicle.title.split(" ");
          const midpoint = Math.ceil(words.length / 2);
          uniqueSuggestions.set(key, {
            text: words.slice(0, midpoint).join(" "),
            highlight: words.slice(midpoint).join(" "),
            id: `title-${vehicle.id}`,
          });
        }
      }
    }

    return Array.from(uniqueSuggestions.values()).slice(0, maxResults);
  }
}
