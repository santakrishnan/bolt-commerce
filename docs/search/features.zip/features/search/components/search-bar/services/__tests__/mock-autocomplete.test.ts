import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { MockAutocompleteService } from "../mock-autocomplete";

const SUV_ID_REGEX = /suv-/i;
const TOYOTA_ID_REGEX = /toyota-/i;

describe("MockAutocompleteService", () => {
  let svc: MockAutocompleteService;

  beforeEach(() => {
    svc = new MockAutocompleteService();
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  it("returns matching suggestions for a known keyword (case-insensitive)", async () => {
    const promise = svc.getSuggestions("Best SUv deals near me", 3);

    let resolved = false;
    promise.then(() => (resolved = true));

    expect(resolved).toBe(false);

    vi.advanceTimersByTime(50);

    const suggestions = await promise;

    expect(suggestions.length).toBeGreaterThan(0);
    expect(suggestions.length).toBeLessThanOrEqual(3);

    for (const s of suggestions) {
      expect(typeof s.text).toBe("string");
      expect(s.text.length).toBeGreaterThan(0);
      expect(typeof s.highlight).toBe("string");
      expect(typeof s.id).toBe("string");
      expect(s.id).toMatch(SUV_ID_REGEX);
    }
  });

  it("respects maxResults and returns empty when maxResults is 0", async () => {
    const p = svc.getSuggestions("suv", 0);
    vi.advanceTimersByTime(50);
    const out = await p;
    expect(Array.isArray(out)).toBe(true);
    expect(out.length).toBe(0);
  });

  it("returns default suggestions when no keyword matches and includes the original query text", async () => {
    const query = "bicycle";
    const p = svc.getSuggestions(query, 2);
    vi.advanceTimersByTime(50);
    const out = await p;

    expect(out.length).toBe(2);

    for (const s of out) {
      expect(s.text.toLowerCase()).toContain(query);
      expect(s.highlight).toBeTruthy();
      expect(s.id).toBeTruthy();
    }
  });

  it("trims whitespace and matches keywords after trimming", async () => {
    const p = svc.getSuggestions("  Toyota  ", 4);
    vi.advanceTimersByTime(50);
    const out = await p;

    expect(out.length).toBeGreaterThan(0);
    expect(out[0]?.id).toMatch(TOYOTA_ID_REGEX);
  });

  it("does not return more suggestions than are available when maxResults is large", async () => {
    const p = svc.getSuggestions("suv", 10);
    vi.advanceTimersByTime(50);
    const out = await p;

    expect(out.length).toBeLessThanOrEqual(4);
  });

  it("is asynchronous and resolves only after the simulated delay", async () => {
    const p = svc.getSuggestions("sedan", 2);

    let done = false;
    p.then(() => (done = true));

    expect(done).toBe(false);

    vi.advanceTimersByTime(25);
    expect(done).toBe(false);

    vi.advanceTimersByTime(25);
    await p;
    expect(done).toBe(true);
  });
});
