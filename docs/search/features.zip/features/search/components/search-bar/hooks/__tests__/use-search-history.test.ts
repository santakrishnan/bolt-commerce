import * as searchHistoryApi from "@features/search/services/search-history-api";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { act, renderHook, waitFor } from "@testing-library/react";
import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { useSearchHistory } from "../use-search-history";

function createWrapper() {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: { retry: false, gcTime: 0 },
      mutations: { retry: false },
    },
  });
  return function Wrapper({ children }: { children: React.ReactNode }) {
    return React.createElement(QueryClientProvider, { client: queryClient }, children);
  };
}
function createWrapperWithData(initialData?: any) {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: { retry: false, gcTime: 0 },
      mutations: { retry: false },
    },
  });
  if (initialData !== undefined) {
    queryClient.setQueryData(["search-history"], initialData);
  }
  return function Wrapper({ children }: { children: React.ReactNode }) {
    return React.createElement(QueryClientProvider, { client: queryClient }, children);
  };
}

describe("useSearchHistory", () => {
  const mockSearchEntries = [
    {
      id: "1",
      query: "SUV under 35k",
      url: "/search?q=SUV+under+35k",
      timestamp: "2024-01-01T00:00:00.000Z",
      type: "nlp" as const,
    },
    {
      id: "2",
      query: "sedan with heated seats",
      url: "/search?q=sedan+with+heated+seats",
      timestamp: "2024-01-02T00:00:00.000Z",
      type: "nlp" as const,
    },
    {
      id: "3",
      query: "truck near me",
      url: "/search?q=truck+near+me",
      timestamp: "2024-01-03T00:00:00.000Z",
      type: "filter" as const,
    },
  ];

  beforeEach(() => {
    vi.clearAllMocks();
    vi.spyOn(searchHistoryApi, "getAllSearchHistory").mockResolvedValue([] as any);
    vi.spyOn(searchHistoryApi, "addSearchEntry").mockResolvedValue([] as any);
    vi.spyOn(searchHistoryApi, "removeSearchEntry").mockResolvedValue([] as any);
    vi.spyOn(searchHistoryApi, "clearSearchHistory").mockResolvedValue([] as any);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("returns history from cache when present", () => {
    const { result } = renderHook(() => useSearchHistory(), {
      wrapper: createWrapperWithData(mockSearchEntries),
    });

    expect(result.current.recentSearches).toEqual(mockSearchEntries);
  });

  it("returns empty array when no history exists", () => {
    const { result } = renderHook(() => useSearchHistory(), { wrapper: createWrapperWithData([]) });

    expect(result.current.recentSearches).toEqual([]);
  });

  it("adds a search to history optimistically", async () => {
    const firstEntry = mockSearchEntries[0];
    if (!firstEntry) {
      throw new Error("Mock entry not found");
    }
    vi.spyOn(searchHistoryApi, "addSearchEntry").mockResolvedValue([firstEntry] as any);
    const { result } = renderHook(() => useSearchHistory(), { wrapper: createWrapperWithData([]) });

    act(() => {
      result.current.addSearch("SUV under 35k", "/search?q=SUV+under+35k", "nlp");
    });

    await waitFor(() => {
      expect(result.current.recentSearches[0]?.query).toBe("SUV under 35k");
    });
    await waitFor(() => {
      expect(searchHistoryApi.addSearchEntry).toHaveBeenCalledWith(
        "SUV under 35k",
        "/search?q=SUV+under+35k",
        "nlp"
      );
    });
  });

  it("does not update cache for single-character queries", () => {
    const { result } = renderHook(() => useSearchHistory(), { wrapper: createWrapper() });

    act(() => {
      result.current.addSearch("a", "/search?q=a", "nlp");
    });

    expect(result.current.recentSearches).toEqual([]);
  });

  it("removes a search from history optimistically", async () => {
    const firstEntry = mockSearchEntries[0];
    const thirdEntry = mockSearchEntries[2];
    if (!(firstEntry && thirdEntry)) {
      throw new Error("Mock entries not found");
    }
    vi.spyOn(searchHistoryApi, "getAllSearchHistory").mockResolvedValue(mockSearchEntries as any);
    vi.spyOn(searchHistoryApi, "removeSearchEntry").mockResolvedValue([
      firstEntry,
      thirdEntry,
    ] as any);
    const { result } = renderHook(() => useSearchHistory(), {
      wrapper: createWrapperWithData(mockSearchEntries),
    });

    expect(result.current.recentSearches).toHaveLength(3);

    act(() => {
      result.current.removeSearch("2");
    });

    await waitFor(() => {
      expect(result.current.recentSearches.find((e) => e.id === "2")).toBeUndefined();
    });
    expect(searchHistoryApi.removeSearchEntry).toHaveBeenCalledWith("2");
  });

  it("clears all search history optimistically", async () => {
    vi.spyOn(searchHistoryApi, "getAllSearchHistory").mockResolvedValue(mockSearchEntries as any);
    vi.spyOn(searchHistoryApi, "clearSearchHistory").mockResolvedValue([] as any);
    const { result } = renderHook(() => useSearchHistory(), {
      wrapper: createWrapperWithData(mockSearchEntries),
    });

    expect(result.current.recentSearches).toHaveLength(3);

    act(() => {
      result.current.clearHistory();
    });

    await waitFor(() => {
      expect(result.current.recentSearches).toEqual([]);
    });
    expect(searchHistoryApi.clearSearchHistory).toHaveBeenCalledTimes(1);
  });

  it("converts history entries to suggestions format", () => {
    const { result } = renderHook(() => useSearchHistory(), {
      wrapper: createWrapperWithData(mockSearchEntries),
    });

    expect(result.current.recentSearches).toHaveLength(3);

    expect(result.current.toSuggestions()).toEqual([
      { text: "", highlight: "SUV under 35k", id: "1" },
      { text: "", highlight: "sedan with heated seats", id: "2" },
      { text: "", highlight: "truck near me", id: "3" },
    ]);
  });

  it("returns empty suggestions array when no history exists", () => {
    const { result } = renderHook(() => useSearchHistory(), { wrapper: createWrapperWithData([]) });

    expect(result.current.toSuggestions()).toEqual([]);
  });

  it("defaults to nlp type when type is not specified", async () => {
    const { result } = renderHook(() => useSearchHistory(), { wrapper: createWrapperWithData([]) });

    act(() => {
      result.current.addSearch("test query", "/search?q=test", "nlp");
    });

    await waitFor(() => {
      expect(searchHistoryApi.addSearchEntry).toHaveBeenCalledWith(
        "test query",
        "/search?q=test",
        "nlp"
      );
    });
  });

  it("maintains FIFO queue with 10-entry limit (handled by API layer)", () => {
    const tenEntries = Array.from({ length: 10 }, (_, i) => ({
      id: `${i + 1}`,
      query: `query ${i + 1}`,
      url: `/search?q=query+${i + 1}`,
      timestamp: new Date(2024, 0, i + 1).toISOString(),
      type: "nlp" as const,
    }));
    const { result } = renderHook(() => useSearchHistory(), {
      wrapper: createWrapperWithData(tenEntries),
    });

    expect(result.current.recentSearches).toHaveLength(10);
    expect(result.current.recentSearches).toEqual(tenEntries);
  });
});
