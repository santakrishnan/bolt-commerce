"use client";

import { searchHistoryQueries } from "@features/search/queries/search-history";
import {
  addSearchEntry,
  clearSearchHistory,
  removeSearchEntry,
  type SearchEntry,
} from "@features/search/services/search-history-api";
import { useOptimisticListMutation } from "@shared/hooks/use-optimistic-list-mutation";
import { useQuery } from "@tanstack/react-query";
import { useCallback } from "react";
import type { Suggestion, UseSearchHistoryReturn } from "../types";

const queryOpts = searchHistoryQueries.all();

//Manages search history with TanStack Query, shared cache, and optimistic updates.
export function useSearchHistory(): UseSearchHistoryReturn {
  const { data: recentSearches = [] } = useQuery(queryOpts);

  const { mutate: doAdd } = useOptimisticListMutation<
    SearchEntry,
    { query: string; url: string; type: "nlp" | "filter" }
  >({
    queryKey: queryOpts.queryKey,
    mutationFn: ({ query, url, type }) => addSearchEntry(query, url, type),
    updater: (prev, { query, url, type }) => {
      const trimmed = query.trim();
      if (trimmed.length <= 1) {
        return prev;
      }

      const entries = [...prev];
      const existingIdx = entries.findIndex((e) => e.query.toLowerCase() === trimmed.toLowerCase());

      if (existingIdx === -1) {
        entries.unshift({
          id: Date.now().toString(),
          query: trimmed,
          url,
          timestamp: new Date().toISOString(),
          type,
        });
      } else {
        const existing = entries[existingIdx] as SearchEntry;
        entries.splice(existingIdx, 1);
        entries.unshift({ ...existing, url, timestamp: new Date().toISOString() });
      }

      return entries.slice(0, 10);
    },
  });

  const { mutate: doRemove } = useOptimisticListMutation<SearchEntry, string>({
    queryKey: queryOpts.queryKey,
    mutationFn: (id) => removeSearchEntry(id),
    updater: (prev, id) => prev.filter((e) => e.id !== id),
  });

  const { mutate: doClear } = useOptimisticListMutation<SearchEntry, void>({
    queryKey: queryOpts.queryKey,
    mutationFn: () => clearSearchHistory(),
    updater: () => [],
  });

  const addSearch = useCallback(
    (query: string, url: string, type: "nlp" | "filter" = "nlp") => doAdd({ query, url, type }),
    [doAdd]
  );

  const removeSearch = useCallback((id: string) => doRemove(id), [doRemove]);

  const clearHistory = useCallback(() => doClear(), [doClear]);

  const toSuggestions = useCallback(
    (): Suggestion[] =>
      recentSearches.map((entry) => ({
        text: "",
        highlight: entry.query,
        id: entry.id,
      })),
    [recentSearches]
  );

  return {
    recentSearches,
    addSearch,
    removeSearch,
    clearHistory,
    toSuggestions,
  };
}
