"use client";

import { useCallback, useDeferredValue, useEffect, useRef, useState } from "react";
import type { AutocompleteService, Suggestion } from "../types";

export interface UseSearchSuggestionsReturn {
  clearSuggestions: () => void;

  error: Error | null;

  fetchSuggestions: (query: string) => void;

  isLoading: boolean;
  suggestions: Suggestion[];
}

export interface UseSearchSuggestionsOptions {
  autocompleteService?: AutocompleteService;

  enabled?: boolean;

  maxSuggestions?: number;

  minCharsForSuggestions?: number;
}

// Manages autocomplete suggestions with React 19's `useDeferredValue` for efficient debouncing.
export function useSearchSuggestions(
  query: string,
  options: UseSearchSuggestionsOptions = {}
): UseSearchSuggestionsReturn {
  const {
    autocompleteService,
    minCharsForSuggestions = 2,
    enabled = true,
    maxSuggestions = 4,
  } = options;

  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const deferredQuery = useDeferredValue(query);

  const abortControllerRef = useRef<AbortController | null>(null);

  const fetchSuggestions = useCallback(
    async (searchQuery: string) => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }

      if (!autocompleteService) {
        setSuggestions([]);
        setIsLoading(false);
        return;
      }

      if (searchQuery.length < minCharsForSuggestions) {
        setSuggestions([]);
        setIsLoading(false);
        setError(null);
        return;
      }

      const abortController = new AbortController();
      abortControllerRef.current = abortController;

      setIsLoading(true);
      setError(null);

      try {
        const results = await autocompleteService.getSuggestions(searchQuery, maxSuggestions);

        if (!abortController.signal.aborted) {
          setSuggestions(results);
          setIsLoading(false);
        }
      } catch (err) {
        if (!abortController.signal.aborted) {
          console.error("Autocomplete service error:", err);
          const error = err instanceof Error ? err : new Error("Failed to fetch suggestions");
          setError(error);
          setSuggestions([]);
          setIsLoading(false);
        }
      }
    },
    [autocompleteService, minCharsForSuggestions, maxSuggestions]
  );

  const clearSuggestions = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setSuggestions([]);
    setIsLoading(false);
    setError(null);
  }, []);

  const isFirstRender = useRef(true);

  //Fetches when the deferred query settles using React 19's `useDeferredValue`, batching keystrokes and avoiding manual debouncing.
  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }

    if (!enabled) {
      return;
    }

    if (!deferredQuery || deferredQuery.length < minCharsForSuggestions) {
      clearSuggestions();
      return;
    }

    fetchSuggestions(deferredQuery);
  }, [deferredQuery, enabled, minCharsForSuggestions, fetchSuggestions, clearSuggestions]);

  useEffect(() => {
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  return {
    suggestions,
    isLoading,
    error,
    fetchSuggestions,
    clearSuggestions,
  };
}
