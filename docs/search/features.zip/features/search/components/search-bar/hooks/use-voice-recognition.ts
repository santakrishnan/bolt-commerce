"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { UseVoiceRecognitionReturn, VoiceRecognitionError } from "../types";

interface SpeechRecognitionEvent extends Event {
  resultIndex: number;
  results: SpeechRecognitionResultList;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
  message?: string;
}

interface SpeechRecognition extends EventTarget {
  abort: () => void;
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onend: ((this: SpeechRecognition, ev: Event) => void) | null;
  onerror: ((this: SpeechRecognition, ev: SpeechRecognitionErrorEvent) => void) | null;
  onresult: ((this: SpeechRecognition, ev: SpeechRecognitionEvent) => void) | null;
  onstart: ((this: SpeechRecognition, ev: Event) => void) | null;
  start: () => void;
  stop: () => void;
}

interface SpeechRecognitionConstructor {
  new (): SpeechRecognition;
}

declare global {
  interface Window {
    SpeechRecognition?: SpeechRecognitionConstructor;
    webkitSpeechRecognition?: SpeechRecognitionConstructor;
  }
}

const TRAILING_PUNCT_RE = /[.!?,;]+$/;

function stripTrailingPunctuation(text: string): string {
  return text.trim().replace(TRAILING_PUNCT_RE, "").trim();
}

function getErrorMessage(errorCode: string): string {
  const errorMessages: Record<string, string> = {
    "no-speech": "No speech detected. Please try again.",
    "audio-capture": "Microphone access denied. Please check permissions.",
    "not-allowed": "Microphone access not allowed.",
    network: "Network error. Please check your connection.",
    aborted: "Voice recognition was cancelled.",
    "bad-grammar": "Recognition error. Please try again.",
    "language-not-supported": "Language not supported.",
  };
  return errorMessages[errorCode] || "Voice recognition failed. Please try again.";
}

function isSpeechRecognitionSupported(): boolean {
  return (
    typeof window !== "undefined" &&
    (window.SpeechRecognition != null || window.webkitSpeechRecognition != null)
  );
}

//Custom hook for voice recognition with interim results, auto-restart, and stable callback ref.
export function useVoiceRecognition(
  onTranscriptChange?: (transcript: string) => void
): UseVoiceRecognitionReturn {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [error, setError] = useState<VoiceRecognitionError | null>(null);
  const [isSupported] = useState(isSpeechRecognitionSupported());

  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const onTranscriptChangeRef = useRef(onTranscriptChange);
  useEffect(() => {
    onTranscriptChangeRef.current = onTranscriptChange;
  }, [onTranscriptChange]);

  const shouldBeListeningRef = useRef(false);
  const finalTranscriptRef = useRef("");
  const silenceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!isSupported) {
      return;
    }

    const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognitionAPI) {
      return;
    }

    try {
      const recognition = new SpeechRecognitionAPI();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = "en-US";

      recognition.onstart = () => {
        setIsListening(true);
        setError(null);
      };

      recognition.onresult = (event: SpeechRecognitionEvent) => {
        let interim = "";

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i];
          if (!result?.[0]) {
            continue;
          }

          const text = result[0].transcript;
          if (result.isFinal) {
            finalTranscriptRef.current += `${stripTrailingPunctuation(text)} `;
            if (silenceTimerRef.current) {
              clearTimeout(silenceTimerRef.current);
            }
            silenceTimerRef.current = setTimeout(() => {
              shouldBeListeningRef.current = false;
              try {
                recognition.stop();
              } catch {
                /* ignore */
              }
            }, 3000);
          } else {
            interim = text;
          }
        }

        const display = stripTrailingPunctuation(`${finalTranscriptRef.current}${interim}`.trim());

        setTranscript(display);
        onTranscriptChangeRef.current?.(display);
      };

      recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
        if (event.error === "aborted") {
          return;
        }

        if (silenceTimerRef.current) {
          clearTimeout(silenceTimerRef.current);
          silenceTimerRef.current = null;
        }
        setError({ code: event.error, message: getErrorMessage(event.error) });
        shouldBeListeningRef.current = false;
        setIsListening(false);
      };

      recognition.onend = () => {
        if (shouldBeListeningRef.current) {
          try {
            recognition.start();
          } catch {
            shouldBeListeningRef.current = false;
            setIsListening(false);
          }
        } else {
          setIsListening(false);
        }
      };

      recognitionRef.current = recognition;
    } catch (err) {
      console.error("Failed to initialize speech recognition:", err);
      setError({
        code: "initialization-failed",
        message: "Failed to initialize voice recognition.",
      });
    }

    return () => {
      shouldBeListeningRef.current = false;
      if (silenceTimerRef.current) {
        clearTimeout(silenceTimerRef.current);
        silenceTimerRef.current = null;
      }
      try {
        recognitionRef.current?.abort();
      } catch {
        /* ignore */
      }
    };
  }, [isSupported]);

  const startListening = useCallback(() => {
    if (!(isSupported && recognitionRef.current)) {
      return;
    }
    try {
      if (silenceTimerRef.current) {
        clearTimeout(silenceTimerRef.current);
        silenceTimerRef.current = null;
      }
      finalTranscriptRef.current = "";
      setTranscript("");
      setError(null);
      shouldBeListeningRef.current = true;
      recognitionRef.current.start();
    } catch (err) {
      console.error("Failed to start speech recognition:", err);
      setError({ code: "start-failed", message: "Failed to start voice recognition." });
    }
  }, [isSupported]);

  const stopListening = useCallback(() => {
    if (!(isSupported && recognitionRef.current)) {
      return;
    }
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }
    shouldBeListeningRef.current = false;
    try {
      recognitionRef.current.stop();
    } catch (err) {
      console.error("Failed to stop speech recognition:", err);
    }
  }, [isSupported]);

  const toggleListening = useCallback(() => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  }, [isListening, startListening, stopListening]);

  return {
    isListening,
    startListening,
    stopListening,
    toggleListening,
    transcript,
    error,
    isSupported,
  };
}
