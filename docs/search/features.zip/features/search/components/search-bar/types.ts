import type { ReactNode } from "react";

export interface SearchBarConfig {
  customPlaceholder?: ReactNode;
  displayMode: "dropdown" | "pills";
  enableSearchHistory?: boolean;
  enableVoiceRecognition?: boolean;
  lightTheme?: boolean;
  lockBodyScrollOnOpen?: boolean;
  maxSuggestions?: number;
  minCharsForSuggestions?: number;
  pillsPlacement?: "above" | "below";
  placeholder?: string;
  quickFilters?: string[];
  showSearchButton?: boolean;
  suggestionTimeout?: number;
  withBackdropBlur?: boolean;
  withBorder?: boolean;
}

export interface SearchBarProps {
  autocompleteService?: AutocompleteService;
  className?: string;
  config?: Partial<SearchBarConfig>;
  onOpenChange?: (open: boolean) => void;
  onQuickFilterSelect?: (filter: string) => void;
  onSubmit: () => void;
  onValueChange: (value: string) => void;
  value: string;
}

export interface Suggestion {
  highlight: string;
  id?: string;
  text: string;
}

export interface AutocompleteService {
  getSuggestions(query: string, maxResults: number): Promise<Suggestion[]>;
}

export interface VoiceRecognitionResult {
  confidence: number;
  isFinal: boolean;
  transcript: string;
}
export interface VoiceRecognitionError {
  code: string;
  message: string;
}

export interface UseVoiceRecognitionReturn {
  error: VoiceRecognitionError | null;
  isListening: boolean;
  isSupported: boolean;
  startListening: () => void;
  stopListening: () => void;
  toggleListening: () => void;
  transcript: string;
}

export interface SearchHistoryEntry {
  id: string;
  query: string;
  timestamp: string;
  type: "nlp" | "filter";
  url: string;
}

export interface UseSearchHistoryReturn {
  addSearch: (query: string, url: string, type: "nlp" | "filter") => void;
  clearHistory: () => void;
  recentSearches: SearchHistoryEntry[];
  removeSearch: (id: string) => void;
  toSuggestions: () => Suggestion[];
}

export interface SuggestionDisplayProps {
  isAnimating: boolean;
  mode: "dropdown" | "pills";
  onQuickFilterSelect?: (filter: string) => void;
  onSelect: (suggestion: Suggestion) => void;
  pillsPlacement?: "above" | "below";
  quickFilters?: string[];
  suggestions: Suggestion[];
}

export const DEFAULT_CONFIG: SearchBarConfig = {
  displayMode: "dropdown",
  pillsPlacement: "below",
  maxSuggestions: 4,
  minCharsForSuggestions: 2,
  suggestionTimeout: 500,
  enableVoiceRecognition: true,
  enableSearchHistory: true,
  withBorder: false,
  placeholder: 'Try: "SUV under 35k with heated seats near San Francisco"',
  showSearchButton: false,
  lightTheme: false,
  withBackdropBlur: true,
};
