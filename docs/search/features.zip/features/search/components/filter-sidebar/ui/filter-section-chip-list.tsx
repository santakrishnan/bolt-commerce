import { CustomChips } from "@shared/components/custom-chips";
import type React from "react";
import { chipAvail, resolveChipType } from "../utils";

interface FilterSectionChipListProps {
  availableList?: string[];
  className?: string;
  onToggle: (value: string) => void;
  options: string[];
  selected: string[];
}

export const FilterSectionChipList: React.FC<FilterSectionChipListProps> = ({
  options,
  selected,
  onToggle,
  availableList,
  className = "",
}) => (
  <div className={`flex flex-wrap gap-2 ${className}`}>
    {options.map((label) => (
      <CustomChips
        key={label}
        label={label}
        onClick={() => onToggle(label)}
        type={resolveChipType(selected.includes(label), true, chipAvail(label, availableList))}
      />
    ))}
  </div>
);
