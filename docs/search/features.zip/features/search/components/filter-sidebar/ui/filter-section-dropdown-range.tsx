import type React from "react";

interface FilterSectionDropdownRangeProps {
  className?: string;
  maxLabel?: string;
  maxOptions: string[];
  maxValue?: string;
  minLabel?: string;
  minOptions: string[];
  minValue?: string;
  onMaxChange?: (value: string) => void;
  onMinChange?: (value: string) => void;
}

export const FilterSectionDropdownRange: React.FC<FilterSectionDropdownRangeProps> = ({
  minOptions,
  maxOptions,
  minLabel = "Min",
  maxLabel = "Max",
  minValue = "",
  maxValue = "",
  onMinChange,
  onMaxChange,
  className = "",
}) => (
  <div className={`flex w-[100%] gap-4 lg:w-[70%] ${className}`}>
    <div className="flex flex-1 flex-col">
      <span className="mb-1 block font-normal text-[length:var(--font-size-xs)] text-[var(--color-brand-text-secondary)] leading-normal">
        {minLabel}
      </span>
      <select
        className="h-[48px] w-full appearance-none rounded-lg bg-[length:11.504px_6.504px] bg-[right_12px_center] bg-[url('/images/dropdown-arrow.svg')] bg-[var(--color-brand-surface)] bg-no-repeat px-3 py-2 pr-10 font-normal text-[length:var(--font-size-sm)] text-[var(--color-brand-text-primary)] leading-normal"
        onChange={(e) => onMinChange?.(e.target.value)}
        value={minValue}
      >
        {minOptions.map((v) => (
          <option key={v} value={v}>
            {v}
          </option>
        ))}
      </select>
    </div>
    <div className="flex items-end pb-3 text-gray-400">—</div>
    <div className="flex flex-1 flex-col">
      <span className="mb-1 block font-normal text-[length:var(--font-size-xs)] text-[var(--color-brand-text-secondary)] leading-normal">
        {maxLabel}
      </span>
      <select
        className="h-[48px] w-full appearance-none rounded-lg bg-[length:11.504px_6.504px] bg-[right_12px_center] bg-[url('/images/dropdown-arrow.svg')] bg-[var(--color-brand-surface)] bg-no-repeat px-3 py-2 pr-10 font-normal text-[length:var(--font-size-sm)] text-[var(--color-brand-text-primary)] leading-normal"
        onChange={(e) => onMaxChange?.(e.target.value)}
        value={maxValue}
      >
        {maxOptions.map((v) => (
          <option key={v} value={v}>
            {v}
          </option>
        ))}
      </select>
    </div>
  </div>
);
