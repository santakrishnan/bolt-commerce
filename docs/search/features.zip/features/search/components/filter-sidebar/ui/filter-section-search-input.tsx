import type React from "react";

interface FilterSectionSearchInputProps {
  className?: string;
  onChange: (value: string) => void;
  placeholder?: string;
  value: string;
}

export const FilterSectionSearchInput: React.FC<FilterSectionSearchInputProps> = ({
  value,
  onChange,
  placeholder = "Search...",
  className = "",
}) => (
  <input
    className={`h-[48px] w-full rounded-[var(--spacing-xs)] border border-[var(--color-brand-surface)] bg-[var(--color-brand-surface)] px-3 py-2 font-normal text-[length:var(--text-md)] text-[var(--color-brand-text-primary)] leading-normal ${className}`}
    onChange={(e) => onChange(e.target.value)}
    placeholder={placeholder}
    type="text"
    value={value}
  />
);
