import { colorMap } from "@shared/components/color-swatch";
import type { CustomChipType } from "@shared/components/custom-chips";
import { CustomChips } from "@shared/components/custom-chips";
import type React from "react";

interface FilterSectionColorChipListProps {
  availableList?: string[];
  className?: string;
  onToggle: (value: string) => void;
  options: string[];
  resolveChipType?: (
    isSelected: boolean,
    staticAvailable: boolean,
    dynamicAvailable: boolean | undefined,
    color: string
  ) => CustomChipType;
  selected: string[];
}

export const FilterSectionColorChipList: React.FC<FilterSectionColorChipListProps> = ({
  options,
  selected,
  onToggle,
  resolveChipType,
  availableList,
  className = "",
}) => (
  <div className={`flex flex-wrap gap-2 gap-y-4 ${className}`}>
    {options.map((color) => (
      <CustomChips
        className="pl-(--spacing-2xs)"
        key={color}
        label={color}
        onClick={() => onToggle(color)}
        prefix={
          <span className={`h-5 w-5 shrink-0 rounded-full ${colorMap[color] ?? "bg-gray-400"}`} />
        }
        type={(() => {
          if (resolveChipType) {
            return resolveChipType(
              selected.includes(color),
              true,
              availableList?.includes(color),
              color
            );
          }
          if (selected.includes(color)) {
            return "selected";
          }
          return "unselected";
        })()}
      />
    ))}
  </div>
);
