import type React from "react";

interface FilterSectionToggleProps {
  checked: boolean;
  className?: string;
  description?: string;
  label: string;
  onChange: (checked: boolean) => void;
}

export const FilterSectionToggle: React.FC<FilterSectionToggleProps> = ({
  checked,
  onChange,
  label,
  description,
  className = "",
}) => (
  <div
    className={`flex h-auto max-w-[329px] flex-shrink-0 flex-col items-start gap-[10px] rounded-[10px] border border-[rgba(17,17,17,0.30)] bg-white pt-[var(--spacing-3)] pr-[6px] pb-[var(--spacing-md)] pl-[6px] lg:pt-[var(--spacing-md)] lg:pb-[var(--spacing-5)] ${className}`}
  >
    <div className="flex w-full items-center justify-between px-[10px]">
      <div>
        <div className="font-semibold text-[length:var(--font-size-md)] text-[var(--color-brand-text-primary)] leading-[var(--spacing-lg)]">
          {label}
        </div>
        {description && (
          <div className="font-normal text-[length:var(--font-size-xs)] text-[var(--color-brand-text-primary)] leading-[var(--spacing-md)]">
            {description}
          </div>
        )}
      </div>
      <button
        className={`flex h-6 w-12 items-center rounded-full transition-colors ${checked ? "bg-red-500" : "bg-gray-300"}`}
        onClick={() => onChange(!checked)}
        type="button"
      >
        <span
          className={`block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${checked ? "translate-x-6" : "translate-x-0.5"}`}
        />
      </button>
    </div>
  </div>
);
