import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

// ── Shared mocks ──────────────────────────────────────────────────────────────

vi.mock("@shared/components/custom-chips", () => ({
  CustomChips: ({ label, onClick, type }: any) => (
    <button data-testid={`chip-${label}`} data-type={type} onClick={onClick} type="button">
      {label}
    </button>
  ),
}));

vi.mock("@shared/components/color-swatch", () => ({
  colorMap: {
    Red: "bg-red-500",
    Blue: "bg-blue-500",
    Black: "bg-black",
    White: "bg-white",
    Beige: "bg-beige-500",
  } as Record<string, string>,
}));

vi.mock("../filter-section", () => ({
  FilterSection: ({ title, isLoading, isOpen, children }: any) =>
    isOpen ? (
      <section data-isloading={isLoading ? "true" : "false"} data-testid={`section-${title}`}>
        {children}
      </section>
    ) : (
      <section data-isloading={isLoading ? "true" : "false"} data-testid={`section-${title}`} />
    ),
}));

vi.mock("../ui/filter-section-chip-list", () => ({
  FilterSectionChipList: ({ options, selected, onToggle, availableList }: any) => (
    <div data-testid="chip-list">
      {options.map((label: string) => (
        <button
          data-available={availableList ? String(availableList.includes(label)) : "n/a"}
          data-selected={String(selected.includes(label))}
          data-testid={`chiplist-${label}`}
          key={label}
          onClick={() => onToggle(label)}
          type="button"
        >
          {label}
        </button>
      ))}
    </div>
  ),
}));

vi.mock("../ui/filter-section-color-chip-list", () => ({
  FilterSectionColorChipList: ({ options, selected, onToggle }: any) => (
    <div data-testid="color-chip-list">
      {options.map((color: string) => (
        <button
          data-selected={String(selected.includes(color))}
          data-testid={`color-${color}`}
          key={color}
          onClick={() => onToggle(color)}
          type="button"
        >
          {color}
        </button>
      ))}
    </div>
  ),
}));

// ── Imports ───────────────────────────────────────────────────────────────────

import { FilterSectionBodyStyle } from "../sections/filter-section-body-style";
import { FilterSectionExteriorColor } from "../sections/filter-section-exterior-color";
import { FilterSectionInteriorColor } from "../sections/filter-section-interior-color";

// ── Shared helpers ────────────────────────────────────────────────────────────

const mockFilterSections = {
  bodyStyle: ["Sedan", "SUV", "Truck"],
  exteriorColors: ["Red", "Blue", "White"],
  interiorColors: ["Black", "Beige"],
};

const baseSectionRefs = { current: {} as Record<string, HTMLDivElement | null> };

// ── FilterSectionBodyStyle ────────────────────────────────────────────────────

describe("FilterSectionBodyStyle", () => {
  const renderBodyStyle = (overrides = {}) =>
    render(
      <FilterSectionBodyStyle
        filterSections={mockFilterSections as any}
        isSectionLoading={() => false}
        openSection="Body Style"
        sectionRefs={baseSectionRefs}
        selectedBodyStyles={[]}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
        {...overrides}
      />
    );

  it("renders the Body Style section with chip list", () => {
    renderBodyStyle();

    expect(screen.getByTestId("section-Body Style")).toBeInTheDocument();
    expect(screen.getByText("Select all body styles that match your needs")).toBeInTheDocument();
    expect(screen.getByTestId("chip-list")).toBeInTheDocument();
  });

  it("calls toggleArrayFilter when a body style chip is clicked", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();
    renderBodyStyle({ toggleArrayFilter });

    await user.click(screen.getByTestId("chiplist-Sedan"));
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedBodyStyles", [], "Sedan");
  });

  it("passes availableFilters to chip list", () => {
    renderBodyStyle({ availableFilters: { bodyStyles: ["Sedan"] } });

    expect(screen.getByTestId("chiplist-Sedan").dataset.available).toBe("true");
    expect(screen.getByTestId("chiplist-SUV").dataset.available).toBe("false");
  });
});

// ── FilterSectionExteriorColor ────────────────────────────────────────────────

describe("FilterSectionExteriorColor", () => {
  const renderExteriorColor = (overrides = {}) =>
    render(
      <FilterSectionExteriorColor
        filterSections={{ exteriorColors: ["Red", "Blue", "White"] }}
        isSectionLoading={() => false}
        openSection="Exterior Color"
        sectionRefs={baseSectionRefs}
        selectedExteriorColors={[]}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
        {...overrides}
      />
    );

  it("renders the Exterior Color section with color chip list", () => {
    renderExteriorColor();

    expect(screen.getByTestId("section-Exterior Color")).toBeInTheDocument();
    expect(screen.getByText("Choose your preferred exterior colors")).toBeInTheDocument();
    expect(screen.getByTestId("color-chip-list")).toBeInTheDocument();
  });

  it("calls toggleArrayFilter when color is clicked", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();
    renderExteriorColor({ toggleArrayFilter });

    await user.click(screen.getByTestId("color-Red"));
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedExteriorColors", [], "Red");
  });
});

// ── FilterSectionInteriorColor ────────────────────────────────────────────────

describe("FilterSectionInteriorColor", () => {
  const renderInteriorColor = (overrides = {}) =>
    render(
      <FilterSectionInteriorColor
        filterSections={{ interiorColors: ["Black", "Beige"] }}
        isSectionLoading={() => false}
        openSection="Interior Color"
        sectionRefs={baseSectionRefs}
        selectedInteriorColors={[]}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
        {...overrides}
      />
    );

  it("renders the Interior Color section with color chip list", () => {
    renderInteriorColor();

    expect(screen.getByTestId("section-Interior Color")).toBeInTheDocument();
    expect(screen.getByText("Choose your preferred interior colors")).toBeInTheDocument();
    expect(screen.getByTestId("color-chip-list")).toBeInTheDocument();
  });

  it("calls toggleArrayFilter when color is clicked", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();
    renderInteriorColor({ toggleArrayFilter });

    await user.click(screen.getByTestId("color-Black"));
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedInteriorColors", [], "Black");
  });
});
