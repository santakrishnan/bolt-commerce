import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

// ── Shared mocks ──────────────────────────────────────────────────────────────

vi.mock("@shared/components/custom-chips", () => ({
  CustomChips: ({ label, onClick, type }: any) => (
    <button data-testid={`chip-${label}`} data-type={type} onClick={onClick} type="button">
      {label}
    </button>
  ),
}));

vi.mock("../filter-section", () => ({
  FilterSection: ({ title, isLoading, isOpen, children }: any) =>
    isOpen ? (
      <section data-isloading={isLoading ? "true" : "false"} data-testid={`section-${title}`}>
        {children}
      </section>
    ) : (
      <section data-isloading={isLoading ? "true" : "false"} data-testid={`section-${title}`} />
    ),
}));

vi.mock("../ui/filter-section-chip-list", () => ({
  FilterSectionChipList: ({ options, selected, onToggle, availableList }: any) => (
    <div data-testid="chip-list">
      {options.map((label: string) => (
        <button
          data-available={availableList ? String(availableList.includes(label)) : "n/a"}
          data-selected={String(selected.includes(label))}
          data-testid={`chiplist-${label}`}
          key={label}
          onClick={() => onToggle(label)}
          type="button"
        >
          {label}
        </button>
      ))}
    </div>
  ),
}));

vi.mock("../ui/filter-section-toggle", () => ({
  FilterSectionToggle: ({ label, description, checked, onChange }: any) => (
    <div data-testid="toggle">
      <span>{label}</span>
      {description && <span>{description}</span>}
      <button data-checked={String(checked)} onClick={() => onChange(!checked)} type="button">
        Toggle
      </button>
    </div>
  ),
}));

// ── Imports ───────────────────────────────────────────────────────────────────

import { FilterSectionDrivetrain } from "../sections/filter-section-drivetrain";
import { FilterSectionFeaturesTech } from "../sections/filter-section-features-tech";
import { FilterSectionInspection } from "../sections/filter-section-inspection";
import { FilterSectionTransmission } from "../sections/filter-section-transmission";

// ── Shared helpers ────────────────────────────────────────────────────────────

const mockFilterSections = {
  drivetrains: ["FWD", "AWD", "RWD"],
  transmissions: ["Automatic", "Manual"],
  safetyFeatures: ["Blind Spot Monitor", "Lane Departure"],
  comfortFeatures: ["Heated Seats", "Ventilated Seats"],
  techFeatures: ["Apple CarPlay", "Android Auto"],
  exteriorFeatures: ["Sunroof", "LED Headlights"],
  performanceFeatures: ["Sport Mode", "Paddle Shifters"],
  seatingCapacity: ["5 Seats", "7 Seats"],
};

const baseSectionRefs = { current: {} as Record<string, HTMLDivElement | null> };

// ── FilterSectionFeaturesTech ─────────────────────────────────────────────────

describe("FilterSectionFeaturesTech", () => {
  const renderFeatures = (overrides = {}) =>
    render(
      <FilterSectionFeaturesTech
        filterSections={mockFilterSections as any}
        isSectionLoading={() => false}
        openSection="Features & Technology"
        sectionRefs={baseSectionRefs}
        selectedComfortFeatures={[]}
        selectedExteriorFeatures={[]}
        selectedPerformanceFeatures={[]}
        selectedSafetyFeatures={[]}
        selectedSeatingCapacity={[]}
        selectedTechFeatures={[]}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
        {...overrides}
      />
    );

  it("renders all six feature subsections", () => {
    renderFeatures();

    expect(screen.getByText("Safety & Drive Assist")).toBeInTheDocument();
    expect(screen.getByText("Comfort & Convenience")).toBeInTheDocument();
    expect(screen.getByText("Technology & Entertainment")).toBeInTheDocument();
    expect(screen.getByText("Exterior & Lighting")).toBeInTheDocument();
    expect(screen.getByText("Performance & Capability")).toBeInTheDocument();
    expect(screen.getByText("Seating & Capacity")).toBeInTheDocument();
  });

  it("calls toggleArrayFilter for safety features", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();
    renderFeatures({ toggleArrayFilter });

    await user.click(screen.getByTestId("chip-Blind Spot Monitor"));
    expect(toggleArrayFilter).toHaveBeenCalledWith(
      "selectedSafetyFeatures",
      [],
      "Blind Spot Monitor"
    );
  });

  it("calls toggleArrayFilter for comfort features", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();
    renderFeatures({ toggleArrayFilter });

    await user.click(screen.getByTestId("chip-Heated Seats"));
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedComfortFeatures", [], "Heated Seats");
  });

  it("calls toggleArrayFilter for tech features", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();
    renderFeatures({ toggleArrayFilter });

    await user.click(screen.getByTestId("chip-Apple CarPlay"));
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedTechFeatures", [], "Apple CarPlay");
  });

  it("calls toggleArrayFilter for exterior features", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();
    renderFeatures({ toggleArrayFilter });

    await user.click(screen.getByTestId("chip-Sunroof"));
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedExteriorFeatures", [], "Sunroof");
  });

  it("calls toggleArrayFilter for performance features", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();
    renderFeatures({ toggleArrayFilter });

    await user.click(screen.getByTestId("chip-Sport Mode"));
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedPerformanceFeatures", [], "Sport Mode");
  });

  it("calls toggleArrayFilter for seating capacity", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();
    renderFeatures({ toggleArrayFilter });

    await user.click(screen.getByTestId("chip-5 Seats"));
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedSeatingCapacity", [], "5 Seats");
  });

  it("resolves availability from availableFilters", () => {
    renderFeatures({
      availableFilters: {
        safetyFeatures: ["Blind Spot Monitor"],
        comfortFeatures: [],
        techFeatures: ["Apple CarPlay"],
        exteriorFeatures: [],
        performanceFeatures: [],
        seatingCapacity: [],
      },
    });

    expect(screen.getByTestId("chip-Blind Spot Monitor").dataset.type).toBe("unselected");
    expect(screen.getByTestId("chip-Lane Departure").dataset.type).toBe("unavailable");
  });
});

// ── FilterSectionInspection ───────────────────────────────────────────────────

describe("FilterSectionInspection", () => {
  const renderInspection = (overrides = {}) =>
    render(
      <FilterSectionInspection
        handleDraftChange={vi.fn()}
        inspection160={false}
        isSectionLoading={() => false}
        openSection="Inspection"
        sectionRefs={baseSectionRefs}
        toggleSection={vi.fn()}
        {...overrides}
      />
    );

  it("renders the Inspection section with toggle", () => {
    renderInspection();

    expect(screen.getByTestId("section-Inspection")).toBeInTheDocument();
    expect(screen.getByText("160-Point Inspection")).toBeInTheDocument();
    expect(screen.getByText("Factory-trained technician verified")).toBeInTheDocument();
  });

  it("calls handleDraftChange when toggle is clicked", async () => {
    const user = userEvent.setup();
    const handleDraftChange = vi.fn();
    renderInspection({ handleDraftChange });

    await user.click(screen.getByText("Toggle"));
    expect(handleDraftChange).toHaveBeenCalledWith("inspection160", true);
  });

  it("calls handleDraftChange with false when toggle is on", async () => {
    const user = userEvent.setup();
    const handleDraftChange = vi.fn();
    renderInspection({ handleDraftChange, inspection160: true });

    await user.click(screen.getByText("Toggle"));
    expect(handleDraftChange).toHaveBeenCalledWith("inspection160", false);
  });
});

// ── FilterSectionDrivetrain ───────────────────────────────────────────────────

describe("FilterSectionDrivetrain", () => {
  const renderDrivetrain = (overrides = {}) =>
    render(
      <FilterSectionDrivetrain
        filterSections={mockFilterSections as any}
        isSectionLoading={() => false}
        openSection="Drivetrain"
        sectionRefs={baseSectionRefs}
        selectedDrivetrains={[]}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
        {...overrides}
      />
    );

  it("renders drivetrain chips", () => {
    renderDrivetrain();

    expect(screen.getByTestId("section-Drivetrain")).toBeInTheDocument();
    expect(screen.getByTestId("chip-FWD")).toBeInTheDocument();
    expect(screen.getByTestId("chip-AWD")).toBeInTheDocument();
    expect(screen.getByTestId("chip-RWD")).toBeInTheDocument();
  });

  it("calls toggleArrayFilter when drivetrain chip is clicked", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();
    renderDrivetrain({ toggleArrayFilter });

    await user.click(screen.getByTestId("chip-AWD"));
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedDrivetrains", [], "AWD");
  });

  it("marks unavailable drivetrains from availableFilters", () => {
    renderDrivetrain({
      availableFilters: { drivetrains: ["FWD"] },
    });

    expect(screen.getByTestId("chip-FWD").dataset.type).toBe("unselected");
    expect(screen.getByTestId("chip-AWD").dataset.type).toBe("unavailable");
  });
});

// ── FilterSectionTransmission ─────────────────────────────────────────────────

describe("FilterSectionTransmission", () => {
  const renderTransmission = (overrides = {}) =>
    render(
      <FilterSectionTransmission
        filterSections={mockFilterSections as any}
        isSectionLoading={() => false}
        openSection="Transmission"
        sectionRefs={baseSectionRefs}
        selectedTransmissions={[]}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
        {...overrides}
      />
    );

  it("renders transmission chips", () => {
    renderTransmission();

    expect(screen.getByTestId("section-Transmission")).toBeInTheDocument();
    expect(screen.getByTestId("chip-Automatic")).toBeInTheDocument();
    expect(screen.getByTestId("chip-Manual")).toBeInTheDocument();
  });

  it("calls toggleArrayFilter when transmission chip is clicked", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();
    renderTransmission({ toggleArrayFilter });

    await user.click(screen.getByTestId("chip-Manual"));
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedTransmissions", [], "Manual");
  });

  it("marks unavailable transmissions from availableFilters", () => {
    renderTransmission({
      availableFilters: { transmissions: ["Automatic"] },
    });

    expect(screen.getByTestId("chip-Automatic").dataset.type).toBe("unselected");
    expect(screen.getByTestId("chip-Manual").dataset.type).toBe("unavailable");
  });

  it("marks selected transmission as 'selected'", () => {
    renderTransmission({ selectedTransmissions: ["Manual"] });

    expect(screen.getByTestId("chip-Manual").dataset.type).toBe("selected");
  });
});
