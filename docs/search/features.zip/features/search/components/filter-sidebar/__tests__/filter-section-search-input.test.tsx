import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

import { FilterSectionSearchInput } from "../ui/filter-section-search-input";

describe("FilterSectionSearchInput", () => {
  it("renders an input with the provided placeholder", () => {
    render(<FilterSectionSearchInput onChange={vi.fn()} placeholder="Search models" value="" />);

    expect(screen.getByPlaceholderText("Search models")).toBeInTheDocument();
  });

  it("renders default placeholder when not provided", () => {
    render(<FilterSectionSearchInput onChange={vi.fn()} value="" />);

    expect(screen.getByPlaceholderText("Search...")).toBeInTheDocument();
  });

  it("displays the current value", () => {
    render(<FilterSectionSearchInput onChange={vi.fn()} value="Toyota" />);

    expect(screen.getByDisplayValue("Toyota")).toBeInTheDocument();
  });

  it("calls onChange with input value when user types", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();

    render(<FilterSectionSearchInput onChange={onChange} value="" />);

    const input = screen.getByRole("textbox");
    await user.type(input, "C");
    expect(onChange).toHaveBeenCalledWith("C");
  });

  it("renders input with type text", () => {
    render(<FilterSectionSearchInput onChange={vi.fn()} value="" />);

    expect(screen.getByRole("textbox")).toHaveAttribute("type", "text");
  });

  it("applies custom className", () => {
    render(<FilterSectionSearchInput className="custom-input" onChange={vi.fn()} value="" />);

    expect(screen.getByRole("textbox")).toHaveClass("custom-input");
  });

  it("renders gracefully with empty value", () => {
    render(<FilterSectionSearchInput onChange={vi.fn()} value="" />);

    expect(screen.getByRole("textbox")).toHaveValue("");
  });
});
