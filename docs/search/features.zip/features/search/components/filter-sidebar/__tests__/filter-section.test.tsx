import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import React from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@tfs-ucmp/ui", () => {
  const React = require("react");
  return {
    Button: ({ children, ...props }: any) => React.createElement("button", props, children),
  };
});

import { FilterSection } from "../filter-section";

describe("FilterSection", () => {
  beforeEach(() => {
    (global as any).innerWidth = 1024;
  });

  it("renders title and children when open", () => {
    render(
      <FilterSection isOpen={true} onToggle={vi.fn()} title="Colors">
        <div>child-content</div>
      </FilterSection>
    );

    expect(screen.getByText("Colors")).toBeInTheDocument();
    expect(screen.getByText("child-content")).toBeInTheDocument();
  });

  it("hides children when closed and shows expand/collapse icon correctly", () => {
    const { rerender } = render(
      <FilterSection isOpen={false} onToggle={vi.fn()} title="Sizes">
        <div>size-child</div>
      </FilterSection>
    );

    expect(screen.queryByText("size-child")).toBeNull();
    const btn = screen.getByRole("button");
    expect(btn.innerHTML).toContain("M12 5v14M5 12h14");

    rerender(
      <FilterSection isOpen={true} onToggle={vi.fn()} title="Sizes">
        <div>size-child</div>
      </FilterSection>
    );

    expect(screen.getByText("size-child")).toBeInTheDocument();
    expect(btn.innerHTML).toContain("M5 12h14");
  });

  it("calls onToggle when header button is clicked", async () => {
    const onToggle = vi.fn();
    const user = userEvent.setup();
    render(
      <FilterSection isOpen={false} onToggle={onToggle} title="Toggle">
        <div />
      </FilterSection>
    );

    const button = screen.getByRole("button");
    await user.click(button);
    expect(onToggle).toHaveBeenCalledTimes(1);
  });

  it("forwards sectionRef to outer div and has expected wrapper classes", () => {
    const ref = React.createRef<HTMLDivElement>();
    render(
      <FilterSection isOpen={false} onToggle={vi.fn()} sectionRef={ref} title="RefTest">
        <div />
      </FilterSection>
    );

    expect(ref.current).toBeInstanceOf(HTMLDivElement);
    expect(ref.current?.className).toContain("border-gray-200");
  });

  it("shows loading output when isLoading is true with correct aria attributes and spinner class", () => {
    render(
      <FilterSection isLoading isOpen={false} onToggle={vi.fn()} title="MySection">
        <div />
      </FilterSection>
    );

    const output = screen.getByLabelText("MySection is updating");
    expect(output).toBeInTheDocument();
    expect(output).toHaveAttribute("aria-live", "polite");
    expect(output.className).toContain("animate-spin");
  });

  it("remains interactive across multiple screen sizes and doesn't throw if children are null (edge)", async () => {
    const user = userEvent.setup();
    const onToggle = vi.fn();
    render(
      <FilterSection isOpen={true} onToggle={onToggle} title="Edge">
        {null}
      </FilterSection>
    );

    const sizes = [320, 768, 1366];
    const btn = screen.getByRole("button");

    for (const w of sizes) {
      (global as any).innerWidth = w;
      global.dispatchEvent(new Event("resize"));
      await user.click(btn);
      expect(btn).toBeInTheDocument();
    }
    expect(onToggle).toHaveBeenCalledTimes(sizes.length);
  });
});
