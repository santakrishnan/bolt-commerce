import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

import { FilterSectionDropdownRange } from "../ui/filter-section-dropdown-range";

describe("FilterSectionDropdownRange", () => {
  it("renders min and max dropdowns with labels", () => {
    render(
      <FilterSectionDropdownRange
        maxOptions={["$30,000", "$50,000"]}
        minOptions={["$0", "$10,000"]}
      />
    );

    expect(screen.getByText("Min")).toBeInTheDocument();
    expect(screen.getByText("Max")).toBeInTheDocument();
  });

  it("renders custom labels when provided", () => {
    render(
      <FilterSectionDropdownRange
        maxLabel="To"
        maxOptions={["2024"]}
        minLabel="From"
        minOptions={["2020"]}
      />
    );

    expect(screen.getByText("From")).toBeInTheDocument();
    expect(screen.getByText("To")).toBeInTheDocument();
  });

  it("renders all min and max options", () => {
    render(
      <FilterSectionDropdownRange
        maxOptions={["$30,000", "$50,000"]}
        minOptions={["$0", "$10,000", "$20,000"]}
      />
    );

    expect(screen.getByRole("option", { name: "$0" })).toBeInTheDocument();
    expect(screen.getByRole("option", { name: "$10,000" })).toBeInTheDocument();
    expect(screen.getByRole("option", { name: "$20,000" })).toBeInTheDocument();
    expect(screen.getByRole("option", { name: "$30,000" })).toBeInTheDocument();
    expect(screen.getByRole("option", { name: "$50,000" })).toBeInTheDocument();
  });

  it("calls onMinChange when min dropdown changes", async () => {
    const user = userEvent.setup();
    const onMinChange = vi.fn();

    render(
      <FilterSectionDropdownRange
        maxOptions={["$50,000"]}
        minOptions={["$0", "$10,000"]}
        onMinChange={onMinChange}
      />
    );

    const [minSelect] = screen.getAllByRole("combobox");
    await user.selectOptions(minSelect, "$10,000");
    expect(onMinChange).toHaveBeenCalledWith("$10,000");
  });

  it("calls onMaxChange when max dropdown changes", async () => {
    const user = userEvent.setup();
    const onMaxChange = vi.fn();

    render(
      <FilterSectionDropdownRange
        maxOptions={["$30,000", "$50,000"]}
        minOptions={["$0"]}
        onMaxChange={onMaxChange}
      />
    );

    const [, maxSelect] = screen.getAllByRole("combobox");
    await user.selectOptions(maxSelect, "$50,000");
    expect(onMaxChange).toHaveBeenCalledWith("$50,000");
  });

  it("displays current min and max values", () => {
    render(
      <FilterSectionDropdownRange
        maxOptions={["$30,000", "$50,000"]}
        maxValue="$50,000"
        minOptions={["$0", "$10,000"]}
        minValue="$10,000"
      />
    );

    const selects = screen.getAllByRole("combobox");
    expect(selects[0]).toHaveValue("$10,000");
    expect(selects[1]).toHaveValue("$50,000");
  });

  it("renders the dash separator", () => {
    const { container } = render(
      <FilterSectionDropdownRange maxOptions={["$30,000"]} minOptions={["$0"]} />
    );

    expect(container.textContent).toContain("—");
  });

  it("does not throw when callbacks are not provided", async () => {
    const user = userEvent.setup();

    render(
      <FilterSectionDropdownRange
        maxOptions={["$30,000", "$50,000"]}
        minOptions={["$0", "$10,000"]}
      />
    );

    const [minSelect, maxSelect] = screen.getAllByRole("combobox");
    await user.selectOptions(minSelect, "$10,000");
    await user.selectOptions(maxSelect, "$50,000");

    expect(minSelect).toBeInTheDocument();
  });

  it("applies custom className", () => {
    const { container } = render(
      <FilterSectionDropdownRange
        className="custom-range"
        maxOptions={["$30,000"]}
        minOptions={["$0"]}
      />
    );

    expect(container.firstChild).toHaveClass("custom-range");
  });
});
