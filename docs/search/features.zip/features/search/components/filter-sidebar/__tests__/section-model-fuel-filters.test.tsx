import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

// ── Shared mocks ──────────────────────────────────────────────────────────────

vi.mock("@shared/components/custom-chips", () => ({
  CustomChips: ({ label, onClick, type }: any) => (
    <button data-testid={`chip-${label}`} data-type={type} onClick={onClick} type="button">
      {label}
    </button>
  ),
}));

vi.mock("../filter-section", () => ({
  FilterSection: ({ title, isLoading, isOpen, children }: any) =>
    isOpen ? (
      <section data-isloading={isLoading ? "true" : "false"} data-testid={`section-${title}`}>
        {children}
      </section>
    ) : (
      <section data-isloading={isLoading ? "true" : "false"} data-testid={`section-${title}`} />
    ),
}));

vi.mock("../ui/filter-section-chip-list", () => ({
  FilterSectionChipList: ({ options, selected, onToggle, availableList }: any) => (
    <div data-testid="chip-list">
      {options.map((label: string) => (
        <button
          data-available={availableList ? String(availableList.includes(label)) : "n/a"}
          data-selected={String(selected.includes(label))}
          data-testid={`chiplist-${label}`}
          key={label}
          onClick={() => onToggle(label)}
          type="button"
        >
          {label}
        </button>
      ))}
    </div>
  ),
}));

vi.mock("../ui/filter-section-search-input", () => ({
  FilterSectionSearchInput: ({ placeholder, value, onChange }: any) => (
    <input
      data-testid="search-input"
      onChange={(e: any) => onChange(e.target.value)}
      placeholder={placeholder}
      type="text"
      value={value}
    />
  ),
}));

// ── Imports ───────────────────────────────────────────────────────────────────

import { FilterSectionFuelType } from "../sections/filter-section-fuel-type";
import { FilterSectionMakeModel } from "../sections/filter-section-make-model";

// ── Shared helpers ────────────────────────────────────────────────────────────

const mockFilterSections = {
  fuelTypes: ["Hybrid (Hybrid)", "Gasoline (Gasoline)", "Electric (Electric)"],
  popularModels: ["Corolla", "Camry", "RAV4", "Highlander"],
  makeModelSearchPlaceholder: "Search models",
};

const baseSectionRefs = { current: {} as Record<string, HTMLDivElement | null> };

// ── FilterSectionMakeModel ────────────────────────────────────────────────────

describe("FilterSectionMakeModel", () => {
  const renderMakeModel = (overrides = {}) =>
    render(
      <FilterSectionMakeModel
        filterSections={mockFilterSections as any}
        isSectionLoading={() => false}
        openSection="Make & Model"
        sectionRefs={baseSectionRefs}
        selectedModels={[]}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
        {...overrides}
      />
    );

  it("renders the Make & Model section with search input and model chips", () => {
    renderMakeModel();

    expect(screen.getByTestId("section-Make & Model")).toBeInTheDocument();
    expect(screen.getByTestId("search-input")).toBeInTheDocument();
    expect(screen.getByText("Popular Toyota Models")).toBeInTheDocument();
    expect(screen.getByTestId("chip-Corolla")).toBeInTheDocument();
    expect(screen.getByTestId("chip-Camry")).toBeInTheDocument();
  });

  it("calls toggleArrayFilter when model chip is clicked", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();
    renderMakeModel({ toggleArrayFilter });

    await user.click(screen.getByTestId("chip-Corolla"));
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedModels", [], "Corolla");
  });

  it("marks selected model as 'selected'", () => {
    renderMakeModel({ selectedModels: ["Corolla"] });

    expect(screen.getByTestId("chip-Corolla").dataset.type).toBe("selected");
  });

  it("marks unavailable model when not in availableFilters", () => {
    renderMakeModel({
      availableFilters: { models: ["Toyota Camry"] },
    });

    expect(screen.getByTestId("chip-Camry").dataset.type).toBe("unselected");
    expect(screen.getByTestId("chip-RAV4").dataset.type).toBe("unavailable");
  });

  it("marks model as unselected when no availableFilters provided", () => {
    renderMakeModel();

    expect(screen.getByTestId("chip-Corolla").dataset.type).toBe("unselected");
  });

  it("renders search input with placeholder", () => {
    renderMakeModel();

    expect(screen.getByPlaceholderText("Search models")).toBeInTheDocument();
  });
});

// ── FilterSectionFuelType ─────────────────────────────────────────────────────

describe("FilterSectionFuelType", () => {
  const renderFuelType = (overrides = {}) =>
    render(
      <FilterSectionFuelType
        filterSections={mockFilterSections as any}
        isSectionLoading={() => false}
        openSection="Fuel Type"
        sectionRefs={baseSectionRefs}
        selectedFuelTypes={[]}
        toggleArrayFilter={vi.fn()}
        toggleSection={vi.fn()}
        {...overrides}
      />
    );

  it("renders the Fuel Type section with fuel chips", () => {
    renderFuelType();

    expect(screen.getByTestId("section-Fuel Type")).toBeInTheDocument();
    expect(screen.getByText("Select acceptable fuel types")).toBeInTheDocument();
    expect(screen.getByTestId("chip-Hybrid (Hybrid)")).toBeInTheDocument();
  });

  it("calls toggleArrayFilter when fuel chip is clicked", async () => {
    const user = userEvent.setup();
    const toggleArrayFilter = vi.fn();
    renderFuelType({ toggleArrayFilter });

    await user.click(screen.getByTestId("chip-Hybrid (Hybrid)"));
    expect(toggleArrayFilter).toHaveBeenCalledWith("selectedFuelTypes", [], "Hybrid (Hybrid)");
  });

  it("resolves fuel type availability from availableFilters", () => {
    renderFuelType({
      availableFilters: { fuelTypes: ["Hybrid", "Gasoline"] },
    });

    expect(screen.getByTestId("chip-Hybrid (Hybrid)").dataset.type).toBe("unselected");
    expect(screen.getByTestId("chip-Electric (Electric)").dataset.type).toBe("unavailable");
  });

  it("marks selected fuel type as 'selected'", () => {
    renderFuelType({ selectedFuelTypes: ["Hybrid (Hybrid)"] });

    expect(screen.getByTestId("chip-Hybrid (Hybrid)").dataset.type).toBe("selected");
  });
});
