/**
 * Unit tests for SidebarNav component
 */

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { SidebarNav } from "../sidebar-nav";

vi.mock("@features/search/lib/filter-sections", () => ({
  filterSections: {
    navItems: [
      "Price",
      "Year",
      "Mileage",
      "Body Style",
      "Exterior Color",
      "Interior Color",
      "Make & Model",
      "Fuel Type",
      "Features & Technology",
      "Inspection",
      "Drivetrain",
      "Transmission",
    ],
  },
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({
    children,
    onClick,
    className,
    type,
    variant,
  }: {
    children: React.ReactNode;
    onClick?: () => void;
    className?: string;
    type?: string;
    variant?: string;
  }) => (
    <button
      className={className}
      data-testid={`sidebar-button-${children}`}
      data-variant={variant}
      onClick={onClick}
      type={type as "button" | "submit" | "reset" | undefined}
    >
      {children}
    </button>
  ),
}));

describe("SidebarNav", () => {
  const mockOnToggleSection = vi.fn();

  const defaultProps = {
    onToggleSection: mockOnToggleSection,
    openSection: null,
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Rendering", () => {
    it("renders the sidebar with correct structural attributes", () => {
      const { container } = render(<SidebarNav {...defaultProps} />);

      const aside = container.querySelector("aside");
      expect(aside).toBeInTheDocument();
      expect(aside).toHaveClass("hidden");
      expect(aside).toHaveClass("w-[215px]");
      expect(aside).toHaveClass("md:block");
      expect(aside).toHaveClass("flex-shrink-0");
      expect(aside).toHaveClass("overflow-y-auto");
      expect(aside).toHaveClass("border-gray-200");
      expect(aside).toHaveClass("border-r");
      expect(aside).toHaveClass("bg-white");
      expect(aside).toHaveAttribute("style");
    });

    it("renders all navigation items from filterSections", () => {
      render(<SidebarNav {...defaultProps} />);

      const expectedItems = [
        "Price",
        "Year",
        "Mileage",
        "Body Style",
        "Exterior Color",
        "Interior Color",
        "Make & Model",
        "Fuel Type",
        "Features & Technology",
        "Inspection",
        "Drivetrain",
        "Transmission",
      ];

      for (const item of expectedItems) {
        const button = screen.getByTestId(`sidebar-button-${item}`);
        expect(button).toBeInTheDocument();
        expect(button).toHaveTextContent(item);
      }
    });

    it("renders buttons with correct type attribute", () => {
      render(<SidebarNav {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      for (const button of buttons) {
        expect(button).toHaveAttribute("type", "button");
      }
    });

    it("renders buttons with search variant", () => {
      render(<SidebarNav {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      for (const button of buttons) {
        expect(button).toHaveAttribute("data-variant", "search");
      }
    });

    it("renders correct number of navigation buttons", () => {
      render(<SidebarNav {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      expect(buttons).toHaveLength(12);
    });
  });

  describe("Styling and Classes", () => {
    it("applies inactive styles when no section is open", () => {
      render(<SidebarNav {...defaultProps} openSection={null} />);

      const button = screen.getByTestId("sidebar-button-Price");
      expect(button.className).toContain("text-[var(--color-states-muted-foreground)]");
      expect(button.className).not.toContain("bg-[var(--color-core-surfaces-background)]");
      expect(button.className).not.toContain("text-[var(--color-brand-text-primary)]");
    });

    it("applies active styles to the open section", () => {
      render(<SidebarNav {...defaultProps} openSection="Price" />);

      const activeButton = screen.getByTestId("sidebar-button-Price");
      expect(activeButton.className).toContain("rounded-[var(--radius-md)]");
      expect(activeButton.className).toContain("bg-[var(--color-core-surfaces-background)]");
      expect(activeButton.className).toContain("text-[var(--color-brand-text-primary)]");
      expect(activeButton.className).toContain("hover:bg-[var(--color-core-surfaces-background)]");
      expect(activeButton.className).toContain("hover:text-[var(--color-brand-text-primary)]");
    });

    it("applies inactive styles to non-open sections when one section is active", () => {
      render(<SidebarNav {...defaultProps} openSection="Price" />);

      const inactiveButton = screen.getByTestId("sidebar-button-Year");
      expect(inactiveButton.className).toContain("text-[var(--color-states-muted-foreground)]");
      expect(inactiveButton.className).not.toContain("bg-[var(--color-core-surfaces-background)]");
    });

    it("applies common styles to all buttons", () => {
      render(<SidebarNav {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      for (const button of buttons) {
        expect(button.className).toContain("mb-[var(--spacing-xs)]");
        expect(button.className).toContain("ml-[8.5%]");
        expect(button.className).toContain("w-full");
        expect(button.className).toContain("max-w-[182px]");
        expect(button.className).toContain("justify-start");
        expect(button.className).toContain("py-3");
        expect(button.className).toContain("pr-4");
        expect(button.className).toContain("pl-4");
        expect(button.className).toContain("text-left");
        expect(button.className).toContain("font-normal");
        expect(button.className).toContain("text-[length:var(--text-sm)]");
        expect(button.className).toContain("leading-normal");
        expect(button.className).toContain("transition-colors");
      }
    });

    it("switches active styles correctly when openSection changes", () => {
      const { rerender } = render(<SidebarNav {...defaultProps} openSection="Price" />);

      const priceButton = screen.getByTestId("sidebar-button-Price");
      const yearButton = screen.getByTestId("sidebar-button-Year");

      expect(priceButton.className).toContain("text-[var(--color-brand-text-primary)]");
      expect(yearButton.className).toContain("text-[var(--color-states-muted-foreground)]");

      rerender(<SidebarNav {...defaultProps} openSection="Year" />);

      expect(priceButton.className).toContain("text-[var(--color-states-muted-foreground)]");
      expect(yearButton.className).toContain("text-[var(--color-brand-text-primary)]");
    });
  });

  describe("User Interactions", () => {
    it("calls onToggleSection with correct section name when button is clicked", async () => {
      const user = userEvent.setup();
      render(<SidebarNav {...defaultProps} />);

      const priceButton = screen.getByTestId("sidebar-button-Price");
      await user.click(priceButton);

      expect(mockOnToggleSection).toHaveBeenCalledTimes(1);
      expect(mockOnToggleSection).toHaveBeenCalledWith("Price");
    });

    it("calls onToggleSection for each different button clicked", async () => {
      const user = userEvent.setup();
      render(<SidebarNav {...defaultProps} />);

      const priceButton = screen.getByTestId("sidebar-button-Price");
      const yearButton = screen.getByTestId("sidebar-button-Year");
      const mileageButton = screen.getByTestId("sidebar-button-Mileage");

      await user.click(priceButton);
      await user.click(yearButton);
      await user.click(mileageButton);

      expect(mockOnToggleSection).toHaveBeenCalledTimes(3);
      expect(mockOnToggleSection).toHaveBeenNthCalledWith(1, "Price");
      expect(mockOnToggleSection).toHaveBeenNthCalledWith(2, "Year");
      expect(mockOnToggleSection).toHaveBeenNthCalledWith(3, "Mileage");
    });

    it("calls onToggleSection when the same button is clicked multiple times", async () => {
      const user = userEvent.setup();
      render(<SidebarNav {...defaultProps} />);

      const priceButton = screen.getByTestId("sidebar-button-Price");

      await user.click(priceButton);
      await user.click(priceButton);
      await user.click(priceButton);

      expect(mockOnToggleSection).toHaveBeenCalledTimes(3);
      expect(mockOnToggleSection).toHaveBeenCalledWith("Price");
    });

    it("calls onToggleSection when active section button is clicked", async () => {
      const user = userEvent.setup();
      render(<SidebarNav {...defaultProps} openSection="Price" />);

      const priceButton = screen.getByTestId("sidebar-button-Price");
      await user.click(priceButton);

      expect(mockOnToggleSection).toHaveBeenCalledTimes(1);
      expect(mockOnToggleSection).toHaveBeenCalledWith("Price");
    });

    it("handles rapid successive clicks correctly", async () => {
      const user = userEvent.setup();
      render(<SidebarNav {...defaultProps} />);

      const priceButton = screen.getByTestId("sidebar-button-Price");
      const yearButton = screen.getByTestId("sidebar-button-Year");

      await user.click(priceButton);
      await user.click(yearButton);
      await user.click(priceButton);
      await user.click(yearButton);

      expect(mockOnToggleSection).toHaveBeenCalledTimes(4);
    });

    it("handles keyboard navigation when button receives focus", async () => {
      const user = userEvent.setup();
      render(<SidebarNav {...defaultProps} />);

      const priceButton = screen.getByTestId("sidebar-button-Price");

      // Tab to focus the button
      await user.tab();
      expect(priceButton).toHaveFocus();

      // Press Enter to activate
      await user.keyboard("{Enter}");
      expect(mockOnToggleSection).toHaveBeenCalledWith("Price");
    });

    it("handles spacebar activation on focused button", async () => {
      const user = userEvent.setup();
      render(<SidebarNav {...defaultProps} />);

      const priceButton = screen.getByTestId("sidebar-button-Price");
      priceButton.focus();

      await user.keyboard(" ");
      expect(mockOnToggleSection).toHaveBeenCalledWith("Price");
    });
  });

  describe("Edge Cases", () => {
    it("handles empty openSection string", () => {
      render(<SidebarNav {...defaultProps} openSection="" />);

      const buttons = screen.getAllByRole("button");
      for (const button of buttons) {
        expect(button.className).toContain("text-[var(--color-states-muted-foreground)]");
        expect(button.className).not.toContain("bg-[var(--color-core-surfaces-background)]");
      }
    });

    it("handles non-existent section name in openSection", () => {
      render(<SidebarNav {...defaultProps} openSection="NonExistentSection" />);

      const buttons = screen.getAllByRole("button");
      for (const button of buttons) {
        expect(button.className).toContain("text-[var(--color-states-muted-foreground)]");
      }
    });

    it("handles section names with special characters", () => {
      render(<SidebarNav {...defaultProps} openSection="Features & Technology" />);

      const button = screen.getByTestId("sidebar-button-Features & Technology");
      expect(button.className).toContain("text-[var(--color-brand-text-primary)]");
    });

    it("handles case-sensitive section matching correctly", () => {
      render(<SidebarNav {...defaultProps} openSection="price" />);

      const priceButton = screen.getByTestId("sidebar-button-Price");
      expect(priceButton.className).not.toContain("text-[var(--color-brand-text-primary)]");
      expect(priceButton.className).toContain("text-[var(--color-states-muted-foreground)]");
    });

    it("renders correctly with all sections inactive", () => {
      render(<SidebarNav {...defaultProps} openSection={null} />);

      const buttons = screen.getAllByRole("button");
      const inactiveButtons = buttons.filter((button) =>
        button.className.includes("text-[var(--color-states-muted-foreground)]")
      );

      expect(inactiveButtons.length).toBe(buttons.length);
    });

    it("renders correctly with last section active", () => {
      render(<SidebarNav {...defaultProps} openSection="Transmission" />);

      const transmissionButton = screen.getByTestId("sidebar-button-Transmission");
      expect(transmissionButton.className).toContain("text-[var(--color-brand-text-primary)]");
    });

    it("renders correctly with first section active", () => {
      render(<SidebarNav {...defaultProps} openSection="Price" />);

      const priceButton = screen.getByTestId("sidebar-button-Price");
      expect(priceButton.className).toContain("text-[var(--color-brand-text-primary)]");
    });

    it("renders correctly with middle section active", () => {
      render(<SidebarNav {...defaultProps} openSection="Make & Model" />);

      const makeModelButton = screen.getByTestId("sidebar-button-Make & Model");
      expect(makeModelButton.className).toContain("text-[var(--color-brand-text-primary)]");
    });
  });

  describe("Component Props Validation", () => {
    it("handles onToggleSection being undefined gracefully", () => {
      const propsWithoutHandler = {
        onToggleSection: undefined as unknown as (section: string) => void,
        openSection: null,
      };

      expect(() => {
        render(<SidebarNav {...propsWithoutHandler} />);
      }).not.toThrow();
    });

    it("accepts all valid section names as openSection", () => {
      const sections = [
        "Price",
        "Year",
        "Mileage",
        "Body Style",
        "Exterior Color",
        "Interior Color",
        "Make & Model",
        "Fuel Type",
        "Features & Technology",
        "Inspection",
        "Drivetrain",
        "Transmission",
      ];

      for (const section of sections) {
        const { unmount } = render(<SidebarNav {...defaultProps} openSection={section} />);
        const button = screen.getByTestId(`sidebar-button-${section}`);
        expect(button.className).toContain("text-[var(--color-brand-text-primary)]");
        unmount();
      }
    });

    it("maintains referential equality with same handler function", () => {
      const handler = vi.fn();
      const { rerender } = render(<SidebarNav onToggleSection={handler} openSection={null} />);

      rerender(<SidebarNav onToggleSection={handler} openSection="Price" />);

      const buttons = screen.getAllByRole("button");
      expect(buttons).toHaveLength(12);
    });
  });

  describe("Accessibility", () => {
    it("renders buttons that are keyboard accessible", () => {
      render(<SidebarNav {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      for (const button of buttons) {
        expect(button).toBeEnabled();
      }
    });

    it("renders semantic HTML structure with aside element", () => {
      const { container } = render(<SidebarNav {...defaultProps} />);

      const aside = container.querySelector("aside");
      expect(aside).toBeInTheDocument();
      expect(aside?.tagName).toBe("ASIDE");
    });

    it("provides clear button text for screen readers", () => {
      render(<SidebarNav {...defaultProps} />);

      const priceButton = screen.getByRole("button", { name: "Price" });
      const yearButton = screen.getByRole("button", { name: "Year" });

      expect(priceButton).toBeInTheDocument();
      expect(yearButton).toBeInTheDocument();
    });

    it("maintains focus management for keyboard users", async () => {
      const user = userEvent.setup();
      render(<SidebarNav {...defaultProps} />);

      const buttons = screen.getAllByRole("button");

      await user.tab();
      expect(buttons[0]).toHaveFocus();

      await user.tab();
      expect(buttons[1]).toHaveFocus();
    });
  });

  describe("Performance and Re-rendering", () => {
    it("does not call onToggleSection during initial render", () => {
      render(<SidebarNav {...defaultProps} />);

      expect(mockOnToggleSection).not.toHaveBeenCalled();
    });

    it("renders efficiently with consistent DOM structure", () => {
      const { container } = render(<SidebarNav {...defaultProps} />);

      const aside = container.querySelector("aside");
      const buttons = aside?.querySelectorAll("button");

      expect(buttons?.length).toBe(12);
      expect(aside?.children.length).toBe(12);
    });

    it("handles prop updates without unnecessary side effects", () => {
      const { rerender } = render(<SidebarNav {...defaultProps} openSection={null} />);

      mockOnToggleSection.mockClear();

      rerender(<SidebarNav {...defaultProps} openSection="Price" />);
      rerender(<SidebarNav {...defaultProps} openSection="Year" />);
      rerender(<SidebarNav {...defaultProps} openSection={null} />);

      expect(mockOnToggleSection).not.toHaveBeenCalled();
    });
  });

  describe("Integration with filterSections", () => {
    it("renders the exact navigation items from filterSections.navItems", () => {
      render(<SidebarNav {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      const buttonTexts = buttons.map((button) => button.textContent);

      expect(buttonTexts).toEqual([
        "Price",
        "Year",
        "Mileage",
        "Body Style",
        "Exterior Color",
        "Interior Color",
        "Make & Model",
        "Fuel Type",
        "Features & Technology",
        "Inspection",
        "Drivetrain",
        "Transmission",
      ]);
    });

    it("maintains correct order of navigation items", () => {
      render(<SidebarNav {...defaultProps} />);

      const buttons = screen.getAllByRole("button");

      expect(buttons[0]).toHaveTextContent("Price");
      expect(buttons[1]).toHaveTextContent("Year");
      expect(buttons[2]).toHaveTextContent("Mileage");
      expect(buttons.at(-1)).toHaveTextContent("Transmission");
    });
  });
});
