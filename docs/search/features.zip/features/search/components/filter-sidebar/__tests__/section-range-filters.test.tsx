import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

// ── Shared mocks ──────────────────────────────────────────────────────────────

vi.mock("@shared/components/custom-chips", () => ({
  CustomChips: ({ label, onClick, type }: any) => (
    <button data-testid={`chip-${label}`} data-type={type} onClick={onClick} type="button">
      {label}
    </button>
  ),
}));

vi.mock("../filter-section", () => ({
  FilterSection: ({ title, isLoading, isOpen, children }: any) =>
    isOpen ? (
      <section data-isloading={isLoading ? "true" : "false"} data-testid={`section-${title}`}>
        {children}
      </section>
    ) : (
      <section data-isloading={isLoading ? "true" : "false"} data-testid={`section-${title}`} />
    ),
}));

vi.mock("../ui/filter-section-dropdown-range", () => ({
  FilterSectionDropdownRange: ({
    minLabel,
    maxLabel,
    minOptions,
    maxOptions,
    onMinChange,
    onMaxChange,
  }: any) => (
    <div data-testid="dropdown-range">
      <select data-testid="min-select" onChange={(e: any) => onMinChange?.(e.target.value)}>
        {minOptions.map((v: string) => (
          <option key={v} value={v}>
            {minLabel}: {v}
          </option>
        ))}
      </select>
      <select data-testid="max-select" onChange={(e: any) => onMaxChange?.(e.target.value)}>
        {maxOptions.map((v: string) => (
          <option key={v} value={v}>
            {maxLabel}: {v}
          </option>
        ))}
      </select>
    </div>
  ),
}));

// ── Imports ───────────────────────────────────────────────────────────────────

import { FilterSectionMileage } from "../sections/filter-section-mileage";
import { FilterSectionPrice } from "../sections/filter-section-price";
import { FilterSectionYear } from "../sections/filter-section-year";

// ── Shared helpers ────────────────────────────────────────────────────────────

const mockFilterSections = {
  price: {
    quickRanges: ["$0 - $10k", "$10k - $20k"],
    minDropdown: ["$0", "$5,000"],
    maxDropdown: ["$15,000", "$30,000"],
  },
  mileage: {
    quickFilters: ["Under 30k", "Under 60k"],
    minDropdown: ["0", "10,000"],
    maxDropdown: ["50,000", "100,000"],
  },
  year: {
    fromOptions: ["2020", "2021"],
    toOptions: ["2024", "2025"],
    popularRanges: ["2020-2024"],
  },
};

const baseSectionRefs = { current: {} as Record<string, HTMLDivElement | null> };

const baseDraftState = {
  yearMin: "",
  yearMax: "",
  mileageMin: "",
  mileageMax: "",
  selectedYearQuick: "",
  selectedPriceQuick: "",
  selectedMileage: "",
  selectedBodyStyles: [],
  selectedExteriorColors: [],
  selectedInteriorColors: [],
  selectedFuelTypes: [],
  selectedModels: [],
  selectedSafetyFeatures: [],
  selectedComfortFeatures: [],
  selectedTechFeatures: [],
  selectedExteriorFeatures: [],
  selectedPerformanceFeatures: [],
  selectedSeatingCapacity: [],
  selectedDrivetrains: [],
  selectedTransmissions: [],
  inspection160: false,
  priceMin: "",
  priceMax: "",
};

// ── FilterSectionPrice ────────────────────────────────────────────────────────

describe("FilterSectionPrice", () => {
  const renderPrice = (overrides = {}) =>
    render(
      <FilterSectionPrice
        filterSections={mockFilterSections as any}
        handleDraftChange={vi.fn()}
        isSectionLoading={() => false}
        openSection="Price"
        priceMax=""
        priceMin=""
        sectionRefs={baseSectionRefs}
        selectedPriceQuick=""
        toggleSection={vi.fn()}
        {...overrides}
      />
    );

  it("renders the Price section with dropdown range and quick chips", () => {
    renderPrice();

    expect(screen.getByTestId("section-Price")).toBeInTheDocument();
    expect(screen.getByTestId("dropdown-range")).toBeInTheDocument();
    expect(screen.getByText("Quick Price Ranges")).toBeInTheDocument();
    expect(screen.getByTestId("chip-$0 - $10k")).toBeInTheDocument();
    expect(screen.getByTestId("chip-$10k - $20k")).toBeInTheDocument();
  });

  it("calls handleDraftChange when quick range chip is clicked", async () => {
    const user = userEvent.setup();
    const handleDraftChange = vi.fn();
    renderPrice({ handleDraftChange });

    await user.click(screen.getByTestId("chip-$0 - $10k"));
    expect(handleDraftChange).toHaveBeenCalledWith("selectedPriceQuick", "$0 - $10k");
  });

  it("deselects quick range when same range is clicked again", async () => {
    const user = userEvent.setup();
    const handleDraftChange = vi.fn();
    renderPrice({ handleDraftChange, selectedPriceQuick: "$0 - $10k" });

    await user.click(screen.getByTestId("chip-$0 - $10k"));
    expect(handleDraftChange).toHaveBeenCalledWith("selectedPriceQuick", "");
  });

  it("marks selected quick range chip as 'selected'", () => {
    renderPrice({ selectedPriceQuick: "$0 - $10k" });

    expect(screen.getByTestId("chip-$0 - $10k").dataset.type).toBe("selected");
    expect(screen.getByTestId("chip-$10k - $20k").dataset.type).toBe("unselected");
  });

  it("calls handleDraftChange for min dropdown change", async () => {
    const user = userEvent.setup();
    const handleDraftChange = vi.fn();
    renderPrice({ handleDraftChange });

    await user.selectOptions(screen.getByTestId("min-select"), "$5,000");
    expect(handleDraftChange).toHaveBeenCalledWith("priceMin", "$5,000");
  });

  it("calls handleDraftChange for max dropdown change", async () => {
    const user = userEvent.setup();
    const handleDraftChange = vi.fn();
    renderPrice({ handleDraftChange });

    await user.selectOptions(screen.getByTestId("max-select"), "$30,000");
    expect(handleDraftChange).toHaveBeenCalledWith("priceMax", "$30,000");
  });

  it("does not render children when section is closed", () => {
    renderPrice({ openSection: null });

    expect(screen.getByTestId("section-Price")).toBeInTheDocument();
    expect(screen.queryByTestId("dropdown-range")).not.toBeInTheDocument();
  });
});

// ── FilterSectionYear ─────────────────────────────────────────────────────────

describe("FilterSectionYear", () => {
  const renderYear = (overrides = {}) =>
    render(
      <FilterSectionYear
        draftState={baseDraftState}
        filterSections={mockFilterSections as any}
        handleDraftChange={vi.fn()}
        isSectionLoading={() => false}
        openSection="Year"
        sectionRefs={baseSectionRefs}
        selectedYearQuick=""
        toggleSection={vi.fn()}
        {...overrides}
      />
    );

  it("renders the Year section with dropdown range and popular ranges", () => {
    renderYear();

    expect(screen.getByTestId("section-Year")).toBeInTheDocument();
    expect(screen.getByTestId("dropdown-range")).toBeInTheDocument();
    expect(screen.getByText("Popular Year Ranges")).toBeInTheDocument();
    expect(screen.getByTestId("chip-2020-2024")).toBeInTheDocument();
  });

  it("calls handleDraftChange when year range chip is clicked", async () => {
    const user = userEvent.setup();
    const handleDraftChange = vi.fn();
    renderYear({ handleDraftChange });

    await user.click(screen.getByTestId("chip-2020-2024"));
    expect(handleDraftChange).toHaveBeenCalledWith("selectedYearQuick", "2020-2024");
  });

  it("deselects year range when same chip is clicked again", async () => {
    const user = userEvent.setup();
    const handleDraftChange = vi.fn();
    renderYear({ handleDraftChange, selectedYearQuick: "2020-2024" });

    await user.click(screen.getByTestId("chip-2020-2024"));
    expect(handleDraftChange).toHaveBeenCalledWith("selectedYearQuick", "");
  });

  it("calls handleDraftChange for year dropdowns", async () => {
    const user = userEvent.setup();
    const handleDraftChange = vi.fn();
    renderYear({ handleDraftChange });

    await user.selectOptions(screen.getByTestId("min-select"), "2021");
    expect(handleDraftChange).toHaveBeenCalledWith("yearMin", "2021");
  });
});

// ── FilterSectionMileage ──────────────────────────────────────────────────────

describe("FilterSectionMileage", () => {
  const renderMileage = (overrides = {}) =>
    render(
      <FilterSectionMileage
        draftState={baseDraftState}
        filterSections={mockFilterSections as any}
        handleDraftChange={vi.fn()}
        isSectionLoading={() => false}
        openSection="Mileage"
        sectionRefs={baseSectionRefs}
        selectedMileage=""
        toggleSection={vi.fn()}
        {...overrides}
      />
    );

  it("renders the Mileage section with quick filters", () => {
    renderMileage();

    expect(screen.getByTestId("section-Mileage")).toBeInTheDocument();
    expect(screen.getByText("Quick Mileage Filters")).toBeInTheDocument();
    expect(screen.getByTestId("chip-Under 30k")).toBeInTheDocument();
    expect(screen.getByTestId("chip-Under 60k")).toBeInTheDocument();
  });

  it("calls handleDraftChange when mileage chip is clicked", async () => {
    const user = userEvent.setup();
    const handleDraftChange = vi.fn();
    renderMileage({ handleDraftChange });

    await user.click(screen.getByTestId("chip-Under 30k"));
    expect(handleDraftChange).toHaveBeenCalledWith("selectedMileage", "Under 30k");
  });

  it("deselects mileage when same chip is clicked again", async () => {
    const user = userEvent.setup();
    const handleDraftChange = vi.fn();
    renderMileage({ handleDraftChange, selectedMileage: "Under 30k" });

    await user.click(screen.getByTestId("chip-Under 30k"));
    expect(handleDraftChange).toHaveBeenCalledWith("selectedMileage", "");
  });
});
