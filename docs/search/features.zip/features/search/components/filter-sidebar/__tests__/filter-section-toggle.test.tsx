import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

import { FilterSectionToggle } from "../ui/filter-section-toggle";

describe("FilterSectionToggle", () => {
  it("renders the label text", () => {
    render(<FilterSectionToggle checked={false} label="160-Point Inspection" onChange={vi.fn()} />);

    expect(screen.getByText("160-Point Inspection")).toBeInTheDocument();
  });

  it("renders the description when provided", () => {
    render(
      <FilterSectionToggle
        checked={false}
        description="Factory-trained technician verified"
        label="Inspection"
        onChange={vi.fn()}
      />
    );

    expect(screen.getByText("Factory-trained technician verified")).toBeInTheDocument();
  });

  it("does not render description when not provided", () => {
    render(<FilterSectionToggle checked={false} label="Inspection" onChange={vi.fn()} />);

    expect(screen.getByText("Inspection")).toBeInTheDocument();
    expect(screen.queryByText("Factory-trained technician verified")).not.toBeInTheDocument();
  });

  it("calls onChange with true when toggle is off and clicked", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();

    render(<FilterSectionToggle checked={false} label="Inspection" onChange={onChange} />);

    const button = screen.getByRole("button");
    await user.click(button);
    expect(onChange).toHaveBeenCalledWith(true);
  });

  it("calls onChange with false when toggle is on and clicked", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();

    render(<FilterSectionToggle checked={true} label="Inspection" onChange={onChange} />);

    const button = screen.getByRole("button");
    await user.click(button);
    expect(onChange).toHaveBeenCalledWith(false);
  });

  it("applies checked styling when checked is true", () => {
    render(<FilterSectionToggle checked={true} label="Inspection" onChange={vi.fn()} />);

    const button = screen.getByRole("button");
    expect(button.className).toContain("bg-red-500");
  });

  it("applies unchecked styling when checked is false", () => {
    render(<FilterSectionToggle checked={false} label="Inspection" onChange={vi.fn()} />);

    const button = screen.getByRole("button");
    expect(button.className).toContain("bg-gray-300");
  });

  it("applies custom className", () => {
    const { container } = render(
      <FilterSectionToggle
        checked={false}
        className="custom-toggle"
        label="Inspection"
        onChange={vi.fn()}
      />
    );

    expect(container.firstChild).toHaveClass("custom-toggle");
  });

  it("renders the toggle knob with correct transform when checked", () => {
    render(<FilterSectionToggle checked={true} label="Inspection" onChange={vi.fn()} />);

    const button = screen.getByRole("button");
    const knob = button.firstChild as HTMLElement;
    expect(knob.className).toContain("translate-x-6");
  });

  it("renders the toggle knob with correct transform when unchecked", () => {
    render(<FilterSectionToggle checked={false} label="Inspection" onChange={vi.fn()} />);

    const button = screen.getByRole("button");
    const knob = button.firstChild as HTMLElement;
    expect(knob.className).toContain("translate-x-0.5");
  });
});
