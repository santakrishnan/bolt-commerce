import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

vi.mock("@shared/components/custom-chips", () => ({
  CustomChips: ({ label, onClick, type, prefix, className }: any) => (
    <button
      data-class={className}
      data-prefix={prefix ? "true" : "false"}
      data-testid={`chip-${label}`}
      data-type={type}
      onClick={onClick}
      type="button"
    >
      {label}
    </button>
  ),
}));

vi.mock("@shared/components/color-swatch", () => ({
  colorMap: {
    Red: "bg-red-500",
    Blue: "bg-blue-500",
    Black: "bg-black",
    White: "bg-white",
    Beige: "bg-beige-500",
  } as Record<string, string>,
}));

import { FilterSectionColorChipList } from "../ui/filter-section-color-chip-list";

describe("FilterSectionColorChipList", () => {
  it("renders all color chips", () => {
    render(
      <FilterSectionColorChipList
        onToggle={vi.fn()}
        options={["Red", "Blue", "White"]}
        selected={[]}
      />
    );

    expect(screen.getByTestId("chip-Red")).toBeInTheDocument();
    expect(screen.getByTestId("chip-Blue")).toBeInTheDocument();
    expect(screen.getByTestId("chip-White")).toBeInTheDocument();
  });

  it("passes prefix (color swatch) to each chip", () => {
    render(
      <FilterSectionColorChipList onToggle={vi.fn()} options={["Red", "Blue"]} selected={[]} />
    );

    expect(screen.getByTestId("chip-Red").dataset.prefix).toBe("true");
    expect(screen.getByTestId("chip-Blue").dataset.prefix).toBe("true");
  });

  it("marks selected colors as 'selected' using default logic", () => {
    render(
      <FilterSectionColorChipList onToggle={vi.fn()} options={["Red", "Blue"]} selected={["Red"]} />
    );

    expect(screen.getByTestId("chip-Red").dataset.type).toBe("selected");
    expect(screen.getByTestId("chip-Blue").dataset.type).toBe("unselected");
  });

  it("uses custom resolveChipType when provided", () => {
    const customResolve = vi.fn().mockReturnValue("unavailable");

    render(
      <FilterSectionColorChipList
        onToggle={vi.fn()}
        options={["Red"]}
        resolveChipType={customResolve}
        selected={[]}
      />
    );

    expect(customResolve).toHaveBeenCalledWith(false, true, undefined, "Red");
    expect(screen.getByTestId("chip-Red").dataset.type).toBe("unavailable");
  });

  it("passes availableList to custom resolveChipType", () => {
    const customResolve = vi.fn().mockReturnValue("unselected");

    render(
      <FilterSectionColorChipList
        availableList={["Red"]}
        onToggle={vi.fn()}
        options={["Red", "Blue"]}
        resolveChipType={customResolve}
        selected={[]}
      />
    );

    expect(customResolve).toHaveBeenCalledWith(false, true, true, "Red");
    expect(customResolve).toHaveBeenCalledWith(false, true, false, "Blue");
  });

  it("calls onToggle with the color when chip is clicked", async () => {
    const user = userEvent.setup();
    const onToggle = vi.fn();

    render(<FilterSectionColorChipList onToggle={onToggle} options={["Red"]} selected={[]} />);

    await user.click(screen.getByTestId("chip-Red"));
    expect(onToggle).toHaveBeenCalledWith("Red");
  });

  it("applies custom className", () => {
    const { container } = render(
      <FilterSectionColorChipList
        className="custom-colors"
        onToggle={vi.fn()}
        options={["Red"]}
        selected={[]}
      />
    );

    expect(container.firstChild).toHaveClass("custom-colors");
  });

  it("renders empty when options is empty", () => {
    const { container } = render(
      <FilterSectionColorChipList onToggle={vi.fn()} options={[]} selected={[]} />
    );

    expect(container.querySelector("[data-testid]")).toBeNull();
  });

  it("falls back to default logic when resolveChipType is not provided and color is selected", () => {
    render(
      <FilterSectionColorChipList onToggle={vi.fn()} options={["Black"]} selected={["Black"]} />
    );

    expect(screen.getByTestId("chip-Black").dataset.type).toBe("selected");
  });

  it("applies pl-(--spacing-2xs) class to chips", () => {
    render(<FilterSectionColorChipList onToggle={vi.fn()} options={["Red"]} selected={[]} />);

    expect(screen.getByTestId("chip-Red").dataset.class).toBe("pl-(--spacing-2xs)");
  });
});
