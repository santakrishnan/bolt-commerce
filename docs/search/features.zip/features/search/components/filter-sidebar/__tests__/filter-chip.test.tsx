import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("../../../../../../../packages/ui/src/components/button", () => {
  const React = require("react");
  return {
    Button: ({ children, ...props }: any) => React.createElement("button", props, children),
  };
});

vi.mock("next/image", () => {
  const React = require("react");
  return {
    __esModule: true,
    default: ({ alt, ...props }: any) => React.createElement("img", { alt, ...props }),
  };
});

import { FilterChip } from "../../filter-sidebar/filter-chip";

describe("FilterChip", () => {
  beforeEach(() => {
    (global as any).innerWidth = 1024;
  });

  it("renders label and default (unselected) styles without checkmark", () => {
    render(<FilterChip label="Example" />);

    expect(screen.getByText("Example")).toBeInTheDocument();

    const button = screen.getByRole("button");
    expect(button).toHaveAttribute("type", "button");
    expect(button.className).toContain("bg-[var(--color-core-surfaces-background)]");
    expect(screen.queryByAltText("Selected")).toBeNull();
  });

  it("shows checkmark image and selected styles when selected is true", () => {
    render(<FilterChip label="Selected" onClick={undefined} selected />);

    const img = screen.getByAltText("Selected");
    expect(img).toBeInTheDocument();
    expect(img.getAttribute("width")).toBe("12");
    expect(img.getAttribute("height")).toBe("12");

    const button = screen.getByRole("button");
    expect(button.className).toContain("border-[var(--color-brand-red)]");
  });

  it("forwards props (type & variant) to Button and calls onClick when provided", async () => {
    const handle = vi.fn();
    const user = userEvent.setup();
    render(<FilterChip label="ClickMe" onClick={handle} selected={false} />);

    const button = screen.getByRole("button");
    expect(button).toHaveAttribute("type", "button");

    await user.click(button);
    expect(handle).toHaveBeenCalledTimes(1);
  });

  it("does not throw when onClick is undefined and remains interactive across screen sizes", async () => {
    const user = userEvent.setup();
    render(<FilterChip label="NoHandler" />);

    const sizes = [320, 640, 1024];
    const button = screen.getByRole("button");

    for (const w of sizes) {
      (global as any).innerWidth = w;
      global.dispatchEvent(new Event("resize"));
      await user.click(button);
      expect(button).toBeInTheDocument();
    }
  });

  it("renders gracefully with an empty label (edge case)", () => {
    const { container } = render(<FilterChip label="" />);
    const span = container.querySelector("span");
    expect(span).not.toBeNull();
    expect(span?.textContent).toBe("");
  });
});
