import { describe, expect, it } from "vitest";

import { chipAvail, fuelChipAvailable, resolveChipType } from "../utils";

describe("resolveChipType", () => {
  it("returns 'selected' when isSelected is true and staticAvailable is true", () => {
    expect(resolveChipType(true, true)).toBe("selected");
  });

  it("returns 'unselected' when not selected and staticAvailable is true", () => {
    expect(resolveChipType(false, true)).toBe("unselected");
  });

  it("returns 'unavailable' when staticAvailable is false and no dynamicAvailable", () => {
    expect(resolveChipType(false, false)).toBe("unavailable");
  });

  it("returns 'unavailable' when isSelected but not available", () => {
    expect(resolveChipType(true, false)).toBe("unavailable");
  });

  it("uses dynamicAvailable over staticAvailable when dynamicAvailable is provided", () => {
    expect(resolveChipType(false, true, false)).toBe("unavailable");
    expect(resolveChipType(false, false, true)).toBe("unselected");
  });

  it("returns 'selected' when dynamicAvailable is true and isSelected is true", () => {
    expect(resolveChipType(true, false, true)).toBe("selected");
  });

  it("returns 'unavailable' when dynamicAvailable is explicitly false", () => {
    expect(resolveChipType(true, true, false)).toBe("unavailable");
  });
});

describe("fuelChipAvailable", () => {
  it("returns undefined when availableFuels is undefined", () => {
    expect(fuelChipAvailable("Hybrid (Hybrid)")).toBeUndefined();
  });

  it("returns true when fuel key is in the available list", () => {
    expect(fuelChipAvailable("Hybrid (Hybrid)", ["Hybrid", "Gasoline"])).toBe(true);
  });

  it("returns false when fuel key is not in the available list", () => {
    expect(fuelChipAvailable("Electric (Electric)", ["Hybrid", "Gasoline"])).toBe(false);
  });

  it("extracts the key before parentheses for matching", () => {
    expect(fuelChipAvailable("Gasoline (Gasoline)", ["Gasoline"])).toBe(true);
  });

  it("handles labels without parentheses", () => {
    expect(fuelChipAvailable("Diesel", ["Diesel"])).toBe(true);
  });

  it("returns false for labels without parentheses when not in list", () => {
    expect(fuelChipAvailable("Diesel", ["Hybrid"])).toBe(false);
  });
});

describe("chipAvail", () => {
  it("returns undefined when list is undefined", () => {
    expect(chipAvail("Sedan")).toBeUndefined();
  });

  it("returns true when label matches case-insensitively", () => {
    expect(chipAvail("sedan", ["Sedan", "SUV"])).toBe(true);
  });

  it("returns false when label is not in the list", () => {
    expect(chipAvail("Truck", ["Sedan", "SUV"])).toBe(false);
  });

  it("handles exact case match", () => {
    expect(chipAvail("SUV", ["SUV"])).toBe(true);
  });

  it("handles uppercase label matching lowercase list", () => {
    expect(chipAvail("SEDAN", ["sedan"])).toBe(true);
  });

  it("returns false for empty list", () => {
    expect(chipAvail("Sedan", [])).toBe(false);
  });
});
