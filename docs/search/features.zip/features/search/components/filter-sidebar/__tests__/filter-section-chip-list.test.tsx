import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

vi.mock("@shared/components/custom-chips", () => ({
  CustomChips: ({ label, onClick, type }: any) => (
    <button data-testid={`chip-${label}`} data-type={type} onClick={onClick} type="button">
      {label}
    </button>
  ),
}));

import { FilterSectionChipList } from "../ui/filter-section-chip-list";

describe("FilterSectionChipList", () => {
  it("renders all option chips", () => {
    render(
      <FilterSectionChipList onToggle={vi.fn()} options={["Sedan", "SUV", "Truck"]} selected={[]} />
    );

    expect(screen.getByTestId("chip-Sedan")).toBeInTheDocument();
    expect(screen.getByTestId("chip-SUV")).toBeInTheDocument();
    expect(screen.getByTestId("chip-Truck")).toBeInTheDocument();
  });

  it("marks selected chips as 'selected'", () => {
    render(
      <FilterSectionChipList onToggle={vi.fn()} options={["Sedan", "SUV"]} selected={["Sedan"]} />
    );

    expect(screen.getByTestId("chip-Sedan").dataset.type).toBe("selected");
    expect(screen.getByTestId("chip-SUV").dataset.type).toBe("unselected");
  });

  it("marks chips as 'unavailable' when not in availableList", () => {
    render(
      <FilterSectionChipList
        availableList={["Sedan"]}
        onToggle={vi.fn()}
        options={["Sedan", "SUV", "Truck"]}
        selected={[]}
      />
    );

    expect(screen.getByTestId("chip-Sedan").dataset.type).toBe("unselected");
    expect(screen.getByTestId("chip-SUV").dataset.type).toBe("unavailable");
    expect(screen.getByTestId("chip-Truck").dataset.type).toBe("unavailable");
  });

  it("marks selected chip as 'selected' even when in availableList", () => {
    render(
      <FilterSectionChipList
        availableList={["Sedan"]}
        onToggle={vi.fn()}
        options={["Sedan"]}
        selected={["Sedan"]}
      />
    );

    expect(screen.getByTestId("chip-Sedan").dataset.type).toBe("selected");
  });

  it("calls onToggle with the label when a chip is clicked", async () => {
    const user = userEvent.setup();
    const onToggle = vi.fn();

    render(<FilterSectionChipList onToggle={onToggle} options={["Sedan"]} selected={[]} />);

    await user.click(screen.getByTestId("chip-Sedan"));
    expect(onToggle).toHaveBeenCalledWith("Sedan");
  });

  it("renders with custom className", () => {
    const { container } = render(
      <FilterSectionChipList
        className="custom-chips"
        onToggle={vi.fn()}
        options={["A"]}
        selected={[]}
      />
    );

    expect(container.firstChild).toHaveClass("custom-chips");
  });

  it("renders empty when options array is empty", () => {
    const { container } = render(
      <FilterSectionChipList onToggle={vi.fn()} options={[]} selected={[]} />
    );

    expect(container.querySelector("[data-testid]")).toBeNull();
  });

  it("resolves availability with no availableList (all unselected by default)", () => {
    render(<FilterSectionChipList onToggle={vi.fn()} options={["FWD", "AWD"]} selected={[]} />);

    expect(screen.getByTestId("chip-FWD").dataset.type).toBe("unselected");
    expect(screen.getByTestId("chip-AWD").dataset.type).toBe("unselected");
  });
});
