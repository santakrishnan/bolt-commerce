import { filterSections } from "@features/search/lib/filter-sections";
import type { FacetCounts, FacetSection } from "@features/search/lib/search-types";
import { FilterSectionBodyStyle } from "./sections/filter-section-body-style";
import { FilterSectionDrivetrain } from "./sections/filter-section-drivetrain";
import { FilterSectionExteriorColor } from "./sections/filter-section-exterior-color";
import { FilterSectionFeaturesTech } from "./sections/filter-section-features-tech";
import { FilterSectionFuelType } from "./sections/filter-section-fuel-type";
import { FilterSectionInspection } from "./sections/filter-section-inspection";
import { FilterSectionInteriorColor } from "./sections/filter-section-interior-color";
import { FilterSectionMakeModel } from "./sections/filter-section-make-model";
import { FilterSectionMileage } from "./sections/filter-section-mileage";
import { FilterSectionPrice } from "./sections/filter-section-price";
import { FilterSectionTransmission } from "./sections/filter-section-transmission";
import { FilterSectionYear } from "./sections/filter-section-year";
import type { AvailableFilters, FilterState } from "./types";

interface SidebarFiltersProps {
  availableFilters?: AvailableFilters;
  draftState: FilterState;
  facetCounts?: FacetCounts;
  handleDraftChange: (key: keyof FilterState, value: FilterState[keyof FilterState]) => void;
  handleScroll: () => void;
  loadingFacetSections?: FacetSection[];
  openSection: string | null;
  scrollContainerRef: React.RefObject<HTMLDivElement | null>;
  scrollInfo: { thumbTop: number; thumbHeight: number };
  sectionRefs: React.MutableRefObject<Record<string, HTMLDivElement | null>>;
  toggleArrayFilter: (key: keyof FilterState, arr: string[], value: string) => void;
  toggleSection: (section: string) => void;
}

export type { SidebarFiltersProps };

/**
 * Scrollable right-hand panel containing all filter sections.
 * Includes the custom red scrollbar track.
 */
export function SidebarFilters({
  draftState,
  openSection,
  toggleSection,
  handleDraftChange,
  toggleArrayFilter,
  sectionRefs,
  scrollContainerRef,
  scrollInfo,
  handleScroll,
  availableFilters,
  loadingFacetSections,
  facetCounts: _facetCounts,
}: SidebarFiltersProps) {
  const {
    selectedPriceQuick,
    selectedYearQuick,
    selectedMileage,
    selectedBodyStyles,
    selectedExteriorColors,
    selectedInteriorColors,
    selectedFuelTypes,
    selectedModels,
    selectedSafetyFeatures,
    selectedComfortFeatures,
    selectedTechFeatures,
    selectedExteriorFeatures,
    selectedPerformanceFeatures,
    selectedSeatingCapacity,
    selectedDrivetrains,
    selectedTransmissions,
    inspection160,
    priceMin,
    priceMax,
  } = draftState;

  const isSectionLoading = (name: FacetSection) => Boolean(loadingFacetSections?.includes(name));

  return (
    <div className="relative flex flex-1">
      <div
        className="scrollbar-hide flex-1 overflow-y-auto"
        onScroll={handleScroll}
        ref={scrollContainerRef}
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        <div className="pb-6 lg:pb-12">
          {/* ── Price ─────────────────────────────────────── */}
          <FilterSectionPrice
            filterSections={filterSections}
            handleDraftChange={handleDraftChange}
            isSectionLoading={isSectionLoading}
            openSection={openSection}
            priceMax={priceMax}
            priceMin={priceMin}
            sectionRefs={sectionRefs}
            selectedPriceQuick={selectedPriceQuick}
            toggleSection={toggleSection}
          />

          {/* ── Year ──────────────────────────────────────── */}

          <FilterSectionYear
            draftState={draftState}
            filterSections={filterSections}
            handleDraftChange={handleDraftChange}
            isSectionLoading={isSectionLoading as (section: string) => boolean}
            openSection={openSection}
            sectionRefs={sectionRefs}
            selectedYearQuick={selectedYearQuick}
            toggleSection={toggleSection}
          />

          {/* ── Mileage ───────────────────────────────────── */}
          <FilterSectionMileage
            draftState={draftState}
            filterSections={filterSections}
            handleDraftChange={handleDraftChange}
            isSectionLoading={isSectionLoading as (section: string) => boolean}
            openSection={openSection}
            sectionRefs={sectionRefs}
            selectedMileage={selectedMileage}
            toggleSection={toggleSection}
          />

          {/* ── Body Style ────────────────────────────────── */}
          <FilterSectionBodyStyle
            availableFilters={availableFilters}
            filterSections={filterSections}
            isSectionLoading={isSectionLoading}
            openSection={openSection}
            sectionRefs={sectionRefs}
            selectedBodyStyles={selectedBodyStyles}
            toggleArrayFilter={toggleArrayFilter}
            toggleSection={toggleSection}
          />

          {/* ── Exterior Color ────────────────────────────── */}
          <FilterSectionExteriorColor
            availableFilters={availableFilters}
            filterSections={filterSections}
            isSectionLoading={isSectionLoading as (section: string) => boolean}
            openSection={openSection}
            sectionRefs={sectionRefs}
            selectedExteriorColors={selectedExteriorColors}
            toggleArrayFilter={
              toggleArrayFilter as (key: string, arr: string[], value: string) => void
            }
            toggleSection={toggleSection}
          />

          {/* ── Interior Color ────────────────────────────── */}
          <FilterSectionInteriorColor
            availableFilters={availableFilters}
            filterSections={filterSections}
            isSectionLoading={isSectionLoading as (section: string) => boolean}
            openSection={openSection}
            sectionRefs={sectionRefs}
            selectedInteriorColors={selectedInteriorColors}
            toggleArrayFilter={
              toggleArrayFilter as (key: string, arr: string[], value: string) => void
            }
            toggleSection={toggleSection}
          />

          {/* ── Make & Model ──────────────────────────────── */}
          <FilterSectionMakeModel
            availableFilters={availableFilters}
            filterSections={filterSections}
            isSectionLoading={isSectionLoading}
            openSection={openSection}
            sectionRefs={sectionRefs}
            selectedModels={selectedModels}
            toggleArrayFilter={toggleArrayFilter}
            toggleSection={toggleSection}
          />

          {/* ── Fuel Type ─────────────────────────────────── */}
          <FilterSectionFuelType
            availableFilters={availableFilters}
            filterSections={filterSections}
            isSectionLoading={isSectionLoading}
            openSection={openSection}
            sectionRefs={sectionRefs}
            selectedFuelTypes={selectedFuelTypes}
            toggleArrayFilter={toggleArrayFilter}
            toggleSection={toggleSection}
          />

          {/* ── Features & Technology ─────────────────────── */}
          <FilterSectionFeaturesTech
            availableFilters={availableFilters}
            filterSections={filterSections}
            isSectionLoading={isSectionLoading}
            openSection={openSection}
            sectionRefs={sectionRefs}
            selectedComfortFeatures={selectedComfortFeatures}
            selectedExteriorFeatures={selectedExteriorFeatures}
            selectedPerformanceFeatures={selectedPerformanceFeatures}
            selectedSafetyFeatures={selectedSafetyFeatures}
            selectedSeatingCapacity={selectedSeatingCapacity}
            selectedTechFeatures={selectedTechFeatures}
            toggleArrayFilter={toggleArrayFilter}
            toggleSection={toggleSection}
          />

          {/* ── Inspection ────────────────────────────────── */}
          <FilterSectionInspection
            handleDraftChange={handleDraftChange}
            inspection160={inspection160}
            isSectionLoading={isSectionLoading}
            openSection={openSection}
            sectionRefs={sectionRefs}
            toggleSection={toggleSection}
          />

          {/* ── Drivetrain ────────────────────────────────── */}
          <FilterSectionDrivetrain
            availableFilters={availableFilters}
            filterSections={filterSections}
            isSectionLoading={isSectionLoading}
            openSection={openSection}
            sectionRefs={sectionRefs}
            selectedDrivetrains={selectedDrivetrains}
            toggleArrayFilter={toggleArrayFilter}
            toggleSection={toggleSection}
          />

          {/* ── Transmission ──────────────────────────────── */}
          <FilterSectionTransmission
            availableFilters={availableFilters}
            filterSections={filterSections}
            isSectionLoading={isSectionLoading}
            openSection={openSection}
            sectionRefs={sectionRefs}
            selectedTransmissions={selectedTransmissions}
            toggleArrayFilter={toggleArrayFilter}
            toggleSection={toggleSection}
          />
        </div>
      </div>

      {/* Custom Red Scrollbar */}
      <div className="relative w-1.5 shrink-0 bg-gray-200">
        <div
          className="absolute w-full rounded-full bg-red-500 transition-all duration-150"
          style={{
            top: scrollInfo.thumbTop,
            height: scrollInfo.thumbHeight,
          }}
        />
      </div>
    </div>
  );
}
