import type { CustomChipType } from "@shared/components/custom-chips";

export function resolveChipType(
  isSelected: boolean,
  staticAvailable: boolean,
  dynamicAvailable?: boolean
): CustomChipType {
  const available = dynamicAvailable ?? staticAvailable;
  if (!available) {
    return "unavailable";
  }
  return isSelected ? "selected" : "unselected";
}

/** Derive chip availability for a fuel label (e.g. "Hybrid (Hybrid)") */
export function fuelChipAvailable(label: string, availableFuels?: string[]): boolean | undefined {
  if (!availableFuels) {
    return undefined;
  }
  const key = label.split(" (")[0];
  return key !== undefined && availableFuels.includes(key);
}

/** Generic chip availability helper */
export function chipAvail(label: string, list?: string[]): boolean | undefined {
  if (!list) {
    return undefined;
  }
  return list.some((l) => l.toLowerCase() === label.toLowerCase());
}
