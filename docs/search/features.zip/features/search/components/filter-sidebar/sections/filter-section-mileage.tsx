import { CustomChips } from "@shared/components/custom-chips";
import type React from "react";
import type { FilterSections } from "../../lib/filter-sections";
import { FilterSection } from "../filter-section";

import type { FilterState } from "../types";
import { FilterSectionDropdownRange } from "../ui/filter-section-dropdown-range";

interface FilterSectionMileageProps {
  draftState: FilterState;
  filterSections: FilterSections;
  handleDraftChange: (key: keyof FilterState, value: FilterState[keyof FilterState]) => void;
  isSectionLoading: (section: string) => boolean;
  openSection: string | null;
  sectionRefs: React.MutableRefObject<Record<string, HTMLDivElement | null>>;
  selectedMileage: string;
  toggleSection: (section: string) => void;
}

export const FilterSectionMileage: React.FC<FilterSectionMileageProps> = ({
  isSectionLoading,
  openSection,
  toggleSection,
  sectionRefs,
  filterSections,
  selectedMileage,
  handleDraftChange,
  draftState,
}) => (
  <FilterSection
    isLoading={isSectionLoading("Mileage")}
    isOpen={openSection === "Mileage"}
    onToggle={() => toggleSection("Mileage")}
    sectionRef={(el) => {
      sectionRefs.current.Mileage = el;
    }}
    title="Mileage"
  >
    <div className="space-y-4">
      <FilterSectionDropdownRange
        maxLabel="Max"
        maxOptions={filterSections.mileage.maxDropdown}
        maxValue={draftState.mileageMax}
        minLabel="Min"
        minOptions={filterSections.mileage.minDropdown}
        minValue={draftState.mileageMin}
        onMaxChange={(value) => handleDraftChange("mileageMax", value)}
        onMinChange={(value) => handleDraftChange("mileageMin", value)}
      />
      <div>
        <div className="mb-2 font-normal text-[--color-brand-text-secondary] text-[length:--font-size-xs] leading-normal">
          Quick Mileage Filters
        </div>
        <div className="flex flex-wrap gap-2">
          {filterSections.mileage.quickFilters.map((filter: string) => (
            <CustomChips
              key={filter}
              label={filter}
              onClick={() =>
                handleDraftChange("selectedMileage", filter === selectedMileage ? "" : filter)
              }
              type={selectedMileage === filter ? "selected" : "unselected"}
            />
          ))}
        </div>
      </div>
    </div>
  </FilterSection>
);
