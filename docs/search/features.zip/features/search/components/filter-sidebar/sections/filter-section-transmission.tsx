import { CustomChips } from "@shared/components/custom-chips";
import type React from "react";
import { FilterSection } from "../filter-section";
import type { SidebarFiltersProps } from "../sidebar-filters";
import { chipAvail, resolveChipType } from "../utils";

export const FilterSectionTransmission: React.FC<
  Pick<
    SidebarFiltersProps,
    | "isSectionLoading"
    | "openSection"
    | "toggleSection"
    | "sectionRefs"
    | "filterSections"
    | "selectedTransmissions"
    | "toggleArrayFilter"
    | "availableFilters"
  >
> = ({
  isSectionLoading,
  openSection,
  toggleSection,
  sectionRefs,
  filterSections,
  selectedTransmissions,
  toggleArrayFilter,
  availableFilters,
}) => (
  <FilterSection
    isLoading={isSectionLoading("Transmission")}
    isOpen={openSection === "Transmission"}
    onToggle={() => toggleSection("Transmission")}
    sectionRef={(el) => {
      sectionRefs.current.Transmission = el;
    }}
    title="Transmission"
  >
    <div className="flex flex-wrap gap-2">
      {filterSections.transmissions.map((t) => (
        <CustomChips
          key={t}
          label={t}
          onClick={() => toggleArrayFilter("selectedTransmissions", selectedTransmissions, t)}
          type={resolveChipType(
            selectedTransmissions.includes(t),
            true,
            chipAvail(t, availableFilters?.transmissions)
          )}
        />
      ))}
    </div>
  </FilterSection>
);
