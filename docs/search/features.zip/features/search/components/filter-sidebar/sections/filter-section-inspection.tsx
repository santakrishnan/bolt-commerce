import type React from "react";
import { FilterSection } from "../filter-section";
import type { SidebarFiltersProps } from "../sidebar-filters";
import { FilterSectionToggle } from "../ui/filter-section-toggle";

export const FilterSectionInspection: React.FC<
  Pick<
    SidebarFiltersProps,
    | "isSectionLoading"
    | "openSection"
    | "toggleSection"
    | "sectionRefs"
    | "inspection160"
    | "handleDraftChange"
  >
> = ({
  isSectionLoading,
  openSection,
  toggleSection,
  sectionRefs,
  inspection160,
  handleDraftChange,
}) => (
  <FilterSection
    isLoading={isSectionLoading("Inspection")}
    isOpen={openSection === "Inspection"}
    onToggle={() => toggleSection("Inspection")}
    sectionRef={(el) => {
      sectionRefs.current.Inspection = el;
    }}
    title="Inspection"
  >
    <FilterSectionToggle
      checked={inspection160}
      description="Factory-trained technician verified"
      label="160-Point Inspection"
      onChange={(checked) => handleDraftChange("inspection160", checked)}
    />
  </FilterSection>
);
