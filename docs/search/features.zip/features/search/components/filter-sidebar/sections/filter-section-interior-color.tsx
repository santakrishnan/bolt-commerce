import type React from "react";
import { FilterSection } from "../filter-section";
import { FilterSectionColorChipList } from "../ui/filter-section-color-chip-list";

interface FilterSectionInteriorColorProps {
  availableFilters?: { interiorColors?: string[] };
  filterSections: { interiorColors: string[] };
  isSectionLoading: (section: string) => boolean;
  openSection: string | null;
  sectionRefs: React.MutableRefObject<Record<string, HTMLDivElement | null>>;
  selectedInteriorColors: string[];
  toggleArrayFilter: (key: string, arr: string[], value: string) => void;
  toggleSection: (section: string) => void;
}

import { chipAvail, resolveChipType } from "../utils";

export const FilterSectionInteriorColor: React.FC<FilterSectionInteriorColorProps> = ({
  isSectionLoading,
  openSection,
  toggleSection,
  sectionRefs,
  filterSections,
  selectedInteriorColors,
  toggleArrayFilter,
  availableFilters,
}) => (
  <FilterSection
    isLoading={isSectionLoading("Interior Color")}
    isOpen={openSection === "Interior Color"}
    onToggle={() => toggleSection("Interior Color")}
    sectionRef={(el) => {
      sectionRefs.current["Interior Color"] = el;
    }}
    title="Interior Color"
  >
    <div>
      <div className="mb-2 font-normal text-[length:var(--spacing-sd)] text-[var(--color-brand-text-secondary)] leading-normal">
        Choose your preferred interior colors
      </div>
      <FilterSectionColorChipList
        availableList={availableFilters?.interiorColors}
        onToggle={(color) =>
          toggleArrayFilter("selectedInteriorColors", selectedInteriorColors, color)
        }
        options={filterSections.interiorColors}
        resolveChipType={(isSelected, staticAvailable, _dynamicAvailable, color) =>
          resolveChipType(
            isSelected,
            staticAvailable,
            chipAvail(color, availableFilters?.interiorColors)
          )
        }
        selected={selectedInteriorColors}
      />
    </div>
  </FilterSection>
);
