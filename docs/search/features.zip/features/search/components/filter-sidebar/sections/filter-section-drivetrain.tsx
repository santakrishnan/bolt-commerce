import { CustomChips } from "@shared/components/custom-chips";
import type React from "react";
import { FilterSection } from "../filter-section";
import type { SidebarFiltersProps } from "../sidebar-filters";
import { chipAvail, resolveChipType } from "../utils";

export const FilterSectionDrivetrain: React.FC<
  Pick<
    SidebarFiltersProps,
    | "isSectionLoading"
    | "openSection"
    | "toggleSection"
    | "sectionRefs"
    | "filterSections"
    | "selectedDrivetrains"
    | "toggleArrayFilter"
    | "availableFilters"
  >
> = ({
  isSectionLoading,
  openSection,
  toggleSection,
  sectionRefs,
  filterSections,
  selectedDrivetrains,
  toggleArrayFilter,
  availableFilters,
}) => (
  <FilterSection
    isLoading={isSectionLoading("Drivetrain")}
    isOpen={openSection === "Drivetrain"}
    onToggle={() => toggleSection("Drivetrain")}
    sectionRef={(el) => {
      sectionRefs.current.Drivetrain = el;
    }}
    title="Drivetrain"
  >
    <div className="flex flex-wrap gap-2">
      {filterSections.drivetrains.map((dt) => (
        <CustomChips
          key={dt}
          label={dt}
          onClick={() => toggleArrayFilter("selectedDrivetrains", selectedDrivetrains, dt)}
          type={resolveChipType(
            selectedDrivetrains.includes(dt),
            true,
            chipAvail(dt, availableFilters?.drivetrains)
          )}
        />
      ))}
    </div>
  </FilterSection>
);
