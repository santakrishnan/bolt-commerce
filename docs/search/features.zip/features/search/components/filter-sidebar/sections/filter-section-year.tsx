import { CustomChips } from "@shared/components/custom-chips";
import type React from "react";
import type { FilterSections } from "../../lib/filter-sections";
import { FilterSection } from "../filter-section";

import type { FilterState } from "../types";
import { FilterSectionDropdownRange } from "../ui/filter-section-dropdown-range";

interface FilterSectionYearProps {
  draftState: FilterState;
  filterSections: FilterSections;
  handleDraftChange: (key: keyof FilterState, value: FilterState[keyof FilterState]) => void;
  isSectionLoading: (section: string) => boolean;
  openSection: string | null;
  sectionRefs: React.MutableRefObject<Record<string, HTMLDivElement | null>>;
  selectedYearQuick: string;
  toggleSection: (section: string) => void;
}

export const FilterSectionYear: React.FC<FilterSectionYearProps> = ({
  isSectionLoading,
  openSection,
  toggleSection,
  sectionRefs,
  filterSections,
  selectedYearQuick,
  handleDraftChange,
  draftState,
}) => (
  <FilterSection
    isLoading={isSectionLoading("Year")}
    isOpen={openSection === "Year"}
    onToggle={() => toggleSection("Year")}
    sectionRef={(el) => {
      sectionRefs.current.Year = el;
    }}
    title="Year"
  >
    <div className="space-y-4">
      <FilterSectionDropdownRange
        maxLabel="Max"
        maxOptions={filterSections.year.toOptions.map(String)}
        maxValue={draftState.yearMax}
        minLabel="Min"
        minOptions={filterSections.year.fromOptions.map(String)}
        minValue={draftState.yearMin}
        onMaxChange={(value) => handleDraftChange("yearMax", value)}
        onMinChange={(value) => handleDraftChange("yearMin", value)}
      />
      <div>
        <div className="mb-2 font-normal text-[--color-brand-text-secondary] text-[length:--font-size-xs] leading-normal">
          Popular Year Ranges
        </div>
        <div className="flex flex-wrap gap-2">
          {filterSections.year.popularRanges.map((range: string) => (
            <CustomChips
              key={range}
              label={range}
              onClick={() =>
                handleDraftChange("selectedYearQuick", range === selectedYearQuick ? "" : range)
              }
              type={selectedYearQuick === range ? "selected" : "unselected"}
            />
          ))}
        </div>
      </div>
    </div>
  </FilterSection>
);
