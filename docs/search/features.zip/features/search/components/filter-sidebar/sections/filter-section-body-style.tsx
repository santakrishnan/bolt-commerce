import type React from "react";
import { FilterSection } from "../filter-section";
import type { SidebarFiltersProps } from "../sidebar-filters";
import { FilterSectionChipList } from "../ui/filter-section-chip-list";

export const FilterSectionBodyStyle: React.FC<
  Pick<
    SidebarFiltersProps,
    | "isSectionLoading"
    | "openSection"
    | "toggleSection"
    | "sectionRefs"
    | "filterSections"
    | "selectedBodyStyles"
    | "toggleArrayFilter"
    | "availableFilters"
  >
> = ({
  isSectionLoading,
  openSection,
  toggleSection,
  sectionRefs,
  filterSections,
  selectedBodyStyles,
  toggleArrayFilter,
  availableFilters,
}) => (
  <FilterSection
    isLoading={isSectionLoading("Body Style")}
    isOpen={openSection === "Body Style"}
    onToggle={() => toggleSection("Body Style")}
    sectionRef={(el) => {
      sectionRefs.current["Body Style"] = el;
    }}
    title="Body Style"
  >
    <div>
      <div className="mb-2 font-normal text-[length:var(--spacing-sd)] text-[var(--color-brand-text-secondary)] leading-normal">
        Select all body styles that match your needs
      </div>
      <FilterSectionChipList
        availableList={availableFilters?.bodyStyles}
        onToggle={(label) => toggleArrayFilter("selectedBodyStyles", selectedBodyStyles, label)}
        options={filterSections.bodyStyle}
        selected={selectedBodyStyles}
      />
    </div>
  </FilterSection>
);
