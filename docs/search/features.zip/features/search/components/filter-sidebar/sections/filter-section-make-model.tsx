import type { FilterSections } from "@features/search/lib/filter-sections";
import { CustomChips } from "@shared/components/custom-chips";
import type React from "react";
import { FilterSection } from "../filter-section";
import type { AvailableFilters, FilterState } from "../types";
import { FilterSectionSearchInput } from "../ui/filter-section-search-input";

interface FilterSectionMakeModelProps {
  availableFilters?: AvailableFilters;
  filterSections: FilterSections;
  isSectionLoading: (section: string) => boolean;
  openSection: string | null;
  sectionRefs: React.MutableRefObject<Record<string, HTMLDivElement | null>>;
  selectedModels: FilterState["selectedModels"];
  toggleArrayFilter: (key: keyof FilterState, arr: string[], value: string) => void;
  toggleSection: (section: string) => void;
}

export const FilterSectionMakeModel: React.FC<FilterSectionMakeModelProps> = ({
  isSectionLoading,
  openSection,
  toggleSection,
  sectionRefs,
  filterSections,
  selectedModels,
  toggleArrayFilter,
  availableFilters,
}) => (
  <FilterSection
    isLoading={isSectionLoading("Make & Model")}
    isOpen={openSection === "Make & Model"}
    onToggle={() => toggleSection("Make & Model")}
    sectionRef={(el) => {
      sectionRefs.current["Make & Model"] = el;
    }}
    title="Make & Model"
  >
    <div className="space-y-3">
      <FilterSectionSearchInput
        onChange={() => {
          // intentionally left blank; connect to handler if needed
        }} // TODO: Connect to handler if needed
        placeholder={filterSections.makeModelSearchPlaceholder}
        value={""} // TODO: Connect to search input state if needed
      />
      <div>
        <div className="mb-2 font-normal text-[length:var(--spacing-sd)] text-[var(--color-brand-text-secondary)] leading-normal">
          Popular Toyota Models
        </div>
        <div className="flex flex-wrap gap-2 gap-y-4">
          {filterSections.popularModels.slice(0, 18).map((model) => {
            const modelLower = model.toLowerCase();

            const chipType = (() => {
              if (selectedModels.includes(model)) {
                return "selected";
              }

              if (availableFilters) {
                const matches = availableFilters.models.some((m) => {
                  const mLower = m.toLowerCase();
                  return mLower.includes(modelLower) || modelLower.includes(mLower);
                });
                return matches ? "unselected" : "unavailable";
              }

              return "unselected";
            })();

            return (
              <CustomChips
                key={model}
                label={model}
                onClick={() => toggleArrayFilter("selectedModels", selectedModels, model)}
                type={chipType}
              />
            );
          })}
        </div>
      </div>
    </div>
  </FilterSection>
);
