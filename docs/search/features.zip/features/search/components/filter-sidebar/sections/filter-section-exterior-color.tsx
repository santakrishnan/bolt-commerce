import type React from "react";
import { FilterSection } from "../filter-section";
import { FilterSectionColorChipList } from "../ui/filter-section-color-chip-list";

interface FilterSectionExteriorColorProps {
  availableFilters?: { exteriorColors?: string[] };
  filterSections: { exteriorColors: string[] };
  isSectionLoading: (section: string) => boolean;
  openSection: string | null;
  sectionRefs: React.MutableRefObject<Record<string, HTMLDivElement | null>>;
  selectedExteriorColors: string[];
  toggleArrayFilter: (key: string, arr: string[], value: string) => void;
  toggleSection: (section: string) => void;
}

import { chipAvail, resolveChipType } from "../utils";

export const FilterSectionExteriorColor: React.FC<FilterSectionExteriorColorProps> = ({
  isSectionLoading,
  openSection,
  toggleSection,
  sectionRefs,
  filterSections,
  selectedExteriorColors,
  toggleArrayFilter,
  availableFilters,
}) => (
  <FilterSection
    isLoading={isSectionLoading("Exterior Color")}
    isOpen={openSection === "Exterior Color"}
    onToggle={() => toggleSection("Exterior Color")}
    sectionRef={(el) => {
      sectionRefs.current["Exterior Color"] = el;
    }}
    title="Exterior Color"
  >
    <div>
      <div className="mb-2 font-normal text-[length:var(--spacing-sd)] text-[var(--color-brand-text-secondary)] leading-normal">
        Choose your preferred exterior colors
      </div>
      <FilterSectionColorChipList
        availableList={availableFilters?.exteriorColors}
        onToggle={(color) =>
          toggleArrayFilter("selectedExteriorColors", selectedExteriorColors, color)
        }
        options={filterSections.exteriorColors}
        resolveChipType={(isSelected, staticAvailable, _dynamicAvailable, color) =>
          resolveChipType(
            isSelected,
            staticAvailable,
            chipAvail(color, availableFilters?.exteriorColors)
          )
        }
        selected={selectedExteriorColors}
      />
    </div>
  </FilterSection>
);
