import { CustomChips } from "@shared/components/custom-chips";
import type React from "react";
import { FilterSection } from "../filter-section";
import type { SidebarFiltersProps } from "../sidebar-filters";
import { FilterSectionDropdownRange } from "../ui/filter-section-dropdown-range";

export const FilterSectionPrice: React.FC<
  Pick<
    SidebarFiltersProps,
    | "isSectionLoading"
    | "openSection"
    | "toggleSection"
    | "sectionRefs"
    | "filterSections"
    | "priceMin"
    | "priceMax"
    | "handleDraftChange"
    | "selectedPriceQuick"
  >
> = ({
  isSectionLoading,
  openSection,
  toggleSection,
  sectionRefs,
  filterSections,
  priceMin,
  priceMax,
  handleDraftChange,
  selectedPriceQuick,
}) => (
  <FilterSection
    isLoading={isSectionLoading("Price")}
    isOpen={openSection === "Price"}
    onToggle={() => toggleSection("Price")}
    sectionRef={(el) => {
      sectionRefs.current.Price = el;
    }}
    title="Price"
  >
    <div className="space-y-4">
      <FilterSectionDropdownRange
        maxLabel="Max"
        maxOptions={filterSections.price.maxDropdown}
        maxValue={priceMax}
        minLabel="Min"
        minOptions={filterSections.price.minDropdown}
        minValue={priceMin}
        onMaxChange={(value) => handleDraftChange("priceMax", value)}
        onMinChange={(value) => handleDraftChange("priceMin", value)}
      />
      <div>
        <div className="mb-2 font-normal text-[length:var(--spacing-sd)] text-[var(--color-brand-text-secondary)] leading-normal">
          Quick Price Ranges
        </div>
        <div className="flex flex-wrap gap-2">
          {filterSections.price.quickRanges.map((range) => (
            <CustomChips
              key={range}
              label={range}
              onClick={() =>
                handleDraftChange("selectedPriceQuick", range === selectedPriceQuick ? "" : range)
              }
              type={selectedPriceQuick === range ? "selected" : "unselected"}
            />
          ))}
        </div>
      </div>
    </div>
  </FilterSection>
);
