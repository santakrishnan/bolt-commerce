import { CustomChips } from "@shared/components/custom-chips";
import type React from "react";
import { FilterSection } from "../filter-section";
import type { SidebarFiltersProps } from "../sidebar-filters";
import { fuelChipAvailable, resolveChipType } from "../utils";

export const FilterSectionFuelType: React.FC<
  Pick<
    SidebarFiltersProps,
    | "isSectionLoading"
    | "openSection"
    | "toggleSection"
    | "sectionRefs"
    | "filterSections"
    | "selectedFuelTypes"
    | "toggleArrayFilter"
    | "availableFilters"
  >
> = ({
  isSectionLoading,
  openSection,
  toggleSection,
  sectionRefs,
  filterSections,
  selectedFuelTypes,
  toggleArrayFilter,
  availableFilters,
}) => (
  <FilterSection
    isLoading={isSectionLoading("Fuel Type")}
    isOpen={openSection === "Fuel Type"}
    onToggle={() => toggleSection("Fuel Type")}
    sectionRef={(el) => {
      sectionRefs.current["Fuel Type"] = el;
    }}
    title="Fuel Type"
  >
    <div>
      <div className="mb-2 font-normal text-[length:var(--spacing-sd)] text-[var(--color-brand-text-secondary)] leading-normal">
        Select acceptable fuel types
      </div>
      <div className="flex flex-wrap gap-2 gap-y-4">
        {filterSections.fuelTypes.map((label) => (
          <CustomChips
            key={label}
            label={label}
            onClick={() => toggleArrayFilter("selectedFuelTypes", selectedFuelTypes, label)}
            type={resolveChipType(
              selectedFuelTypes.includes(label),
              true,
              fuelChipAvailable(label, availableFilters?.fuelTypes)
            )}
          />
        ))}
      </div>
    </div>
  </FilterSection>
);
