import { CustomChips } from "@shared/components/custom-chips";
import type React from "react";
import { FilterSection } from "../filter-section";
import type { SidebarFiltersProps } from "../sidebar-filters";
import { chipAvail, resolveChipType } from "../utils";

export const FilterSectionFeaturesTech: React.FC<
  Pick<
    SidebarFiltersProps,
    | "isSectionLoading"
    | "openSection"
    | "toggleSection"
    | "sectionRefs"
    | "filterSections"
    | "selectedSafetyFeatures"
    | "selectedComfortFeatures"
    | "selectedTechFeatures"
    | "selectedExteriorFeatures"
    | "selectedPerformanceFeatures"
    | "selectedSeatingCapacity"
    | "toggleArrayFilter"
    | "availableFilters"
  >
> = ({
  isSectionLoading,
  openSection,
  toggleSection,
  sectionRefs,
  filterSections,
  selectedSafetyFeatures,
  selectedComfortFeatures,
  selectedTechFeatures,
  selectedExteriorFeatures,
  selectedPerformanceFeatures,
  selectedSeatingCapacity,
  toggleArrayFilter,
  availableFilters,
}) => (
  <FilterSection
    isLoading={isSectionLoading("Features & Technology")}
    isOpen={openSection === "Features & Technology"}
    onToggle={() => toggleSection("Features & Technology")}
    sectionRef={(el) => {
      sectionRefs.current["Features & Technology"] = el;
    }}
    title="Features & Technology"
  >
    <div className="space-y-4">
      <div className="mb-2 font-normal text-[length:var(--spacing-sd)] text-[var(--color-brand-text-secondary)] leading-normal">
        Select desired vehicle features and options
      </div>
      <div>
        <div className="mb-2 font-semibold text-[length:var(--font-size-sm)] text-[var(--color-brand-text-primary)] leading-normal">
          Safety & Drive Assist
        </div>
        <div className="flex flex-wrap gap-2 gap-y-4">
          {filterSections.safetyFeatures.map((f) => (
            <CustomChips
              key={f}
              label={f}
              onClick={() => toggleArrayFilter("selectedSafetyFeatures", selectedSafetyFeatures, f)}
              type={resolveChipType(
                selectedSafetyFeatures.includes(f),
                true,
                chipAvail(f, availableFilters?.safetyFeatures)
              )}
            />
          ))}
        </div>
      </div>
      <div>
        <div className="mb-2 font-semibold text-[length:var(--font-size-sm)] text-[var(--color-brand-text-primary)] leading-normal">
          Comfort & Convenience
        </div>
        <div className="flex flex-wrap gap-2 gap-y-4">
          {filterSections.comfortFeatures.map((f) => (
            <CustomChips
              key={f}
              label={f}
              onClick={() =>
                toggleArrayFilter("selectedComfortFeatures", selectedComfortFeatures, f)
              }
              type={resolveChipType(
                selectedComfortFeatures.includes(f),
                true,
                chipAvail(f, availableFilters?.comfortFeatures)
              )}
            />
          ))}
        </div>
      </div>
      <div>
        <div className="mb-2 font-semibold text-[length:var(--font-size-sm)] text-[var(--color-brand-text-primary)] leading-normal">
          Technology & Entertainment
        </div>
        <div className="flex flex-wrap gap-2 gap-y-4">
          {filterSections.techFeatures.map((f) => (
            <CustomChips
              key={f}
              label={f}
              onClick={() => toggleArrayFilter("selectedTechFeatures", selectedTechFeatures, f)}
              type={resolveChipType(
                selectedTechFeatures.includes(f),
                true,
                chipAvail(f, availableFilters?.techFeatures)
              )}
            />
          ))}
        </div>
      </div>
      <div>
        <div className="mb-2 font-semibold text-[length:var(--font-size-sm)] text-[var(--color-brand-text-primary)] leading-normal">
          Exterior & Lighting
        </div>
        <div className="flex flex-wrap gap-2">
          {filterSections.exteriorFeatures.map((f) => (
            <CustomChips
              key={f}
              label={f}
              onClick={() =>
                toggleArrayFilter("selectedExteriorFeatures", selectedExteriorFeatures, f)
              }
              type={resolveChipType(
                selectedExteriorFeatures.includes(f),
                true,
                chipAvail(f, availableFilters?.exteriorFeatures)
              )}
            />
          ))}
        </div>
      </div>
      <div>
        <div className="mb-2 font-semibold text-[length:var(--font-size-sm)] text-[var(--color-brand-text-primary)] leading-normal">
          Performance & Capability
        </div>
        <div className="flex flex-wrap gap-2">
          {filterSections.performanceFeatures.map((f) => (
            <CustomChips
              key={f}
              label={f}
              onClick={() =>
                toggleArrayFilter("selectedPerformanceFeatures", selectedPerformanceFeatures, f)
              }
              type={resolveChipType(
                selectedPerformanceFeatures.includes(f),
                true,
                chipAvail(f, availableFilters?.performanceFeatures)
              )}
            />
          ))}
        </div>
      </div>
      <div>
        <div className="mb-2 font-semibold text-[length:var(--font-size-sm)] text-[var(--color-brand-text-primary)] leading-normal">
          Seating & Capacity
        </div>
        <div className="flex flex-wrap gap-2">
          {filterSections.seatingCapacity.map((f) => (
            <CustomChips
              key={f}
              label={f}
              onClick={() =>
                toggleArrayFilter("selectedSeatingCapacity", selectedSeatingCapacity, f)
              }
              type={resolveChipType(
                selectedSeatingCapacity.includes(f),
                true,
                chipAvail(f, availableFilters?.seatingCapacity)
              )}
            />
          ))}
        </div>
      </div>
    </div>
  </FilterSection>
);
