import { Button } from "@tfs-ucmp/ui";

interface FilterSectionProps {
  children: React.ReactNode;
  isLoading?: boolean;
  isOpen: boolean;
  onToggle: () => void;
  sectionRef?: React.Ref<HTMLDivElement>;
  title: string;
}

export const FilterSection = ({
  title,
  children,
  isOpen,
  onToggle,
  sectionRef,
  isLoading = false,
}: FilterSectionProps) => {
  return (
    <div className="border-gray-200 border-b pt-2 pb-1 pl-1 first:border-t" ref={sectionRef}>
      <Button
        className="flex h-auto w-full items-center justify-between pr-3 pl-4 transition-colors hover:bg-gray-50"
        onClick={onToggle}
        type="button"
        variant="search"
      >
        <span className="flex items-center gap-2 font-semibold text-[length:var(--text-md)] text-[var(--color-brand-text-primary)] leading-normal">
          {title}
          {isLoading && (
            <output
              aria-label={`${title} is updating`}
              aria-live="polite"
              className="inline-block h-3 w-3 animate-spin rounded-full border border-gray-300 border-t-red-500"
            />
          )}
        </span>
        {isOpen ? (
          <svg
            aria-hidden="true"
            className="h-3 w-3"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            viewBox="0 0 24 24"
          >
            <path d="M5 12h14" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        ) : (
          <svg
            aria-hidden="true"
            className="h-3 w-3"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            viewBox="0 0 24 24"
          >
            <path d="M12 5v14M5 12h14" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        )}
      </Button>
      {isOpen && <div className="px-4 pb-4">{children}</div>}
    </div>
  );
};
