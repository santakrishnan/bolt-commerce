/**
 * Shared types and default state for the FilterSidebar feature.
 */

import type { AppliedFilter, FacetCounts, FacetSection } from "@features/search/lib/search-types";
import type { Vehicle } from "@shared/vehicle";

export interface FilterState {
  inspection160: boolean;
  mileageMax: string;
  mileageMin: string;
  priceMax: string;
  priceMin: string;
  selectedBodyStyles: string[];
  selectedComfortFeatures: string[];
  selectedDrivetrains: string[];
  selectedExteriorColors: string[];
  selectedExteriorFeatures: string[];
  selectedFuelTypes: string[];
  selectedInteriorColors: string[];
  selectedMileage: string;
  selectedModels: string[];
  selectedPerformanceFeatures: string[];
  selectedPriceQuick: string;
  selectedSafetyFeatures: string[];
  selectedSeatingCapacity: string[];
  selectedTechFeatures: string[];
  selectedTransmissions: string[];
  selectedYearQuick: string;
  yearMax: string;
  yearMin: string;
}

export const defaultFilterState: FilterState = {
  selectedPriceQuick: "",
  selectedYearQuick: "",
  selectedMileage: "",
  selectedBodyStyles: [],
  selectedExteriorColors: [],
  selectedInteriorColors: [],
  selectedFuelTypes: [],
  selectedModels: [],
  selectedSafetyFeatures: [],
  selectedComfortFeatures: [],
  selectedTechFeatures: [],
  selectedExteriorFeatures: [],
  selectedPerformanceFeatures: [],
  selectedSeatingCapacity: [],
  selectedDrivetrains: [],
  selectedTransmissions: [],
  inspection160: false,
  priceMin: "",
  priceMax: "",
  yearMin: "",
  yearMax: "",
  mileageMin: "",
  mileageMax: "",
};

export interface AvailableFilters {
  bodyStyles: string[];
  comfortFeatures: string[];
  drivetrains: string[];
  exteriorColors: string[];
  exteriorFeatures: string[];
  fuelTypes: string[];
  hasInspection160: boolean;
  interiorColors: string[];
  models: string[];
  performanceFeatures: string[];
  safetyFeatures: string[];
  seatingCapacity: string[];
  techFeatures: string[];
  totalCount: number;
  transmissions: string[];
}

export interface FilterSidebarProps {
  appliedFilters?: AppliedFilter[];
  availableFilters?: AvailableFilters;
  facetCounts?: FacetCounts;
  filterState: FilterState;
  isOpen: boolean;
  labelFilter?: string;
  loadingFacetSections?: FacetSection[];
  onApply: (newState: FilterState) => void;
  onClose: () => void;
  onReset: () => void;
  refineFilters?: { id: string; label: string }[];
  searchQuery?: string;
  vehicleCount: number;
  vehicles?: Vehicle[];
}
