"use client";

import { AppButton } from "@shared/components/button";
import { Button } from "@tfs-ucmp/ui";
import Image from "next/image";
import { useCallback, useEffect, useRef, useState } from "react";
import { SidebarFilters } from "./sidebar-filters";
import { SidebarNav } from "./sidebar-nav";
import { defaultFilterState, type FilterSidebarProps, type FilterState } from "./types";

export type { AvailableFilters, FilterSidebarProps, FilterState } from "./types";
export { defaultFilterState } from "./types";

// Helper to merge refine filters into a FilterState; kept at module scope
// so it is stable and doesn't need to be added to effect dependency lists.
const mergeRefinesIntoState = (
  base: FilterState,
  refines?: { id: string; label: string }[],
  avail?: FilterSidebarProps["availableFilters"]
) => {
  const next = { ...base } as FilterState;
  if (!refines || refines.length === 0 || !avail) {
    return next;
  }

  const normalize = (s: string) => s?.toLowerCase().trim() ?? "";

  for (const r of refines) {
    const label = normalize(r.label);

    const tryAdd = (key: keyof FilterState, list?: string[]) => {
      if (!list || list.length === 0) {
        return;
      }
      const match = list.find((it) => normalize(it) === label);
      if (!match) {
        return;
      }
      const arr = next[key];
      if (Array.isArray(arr) && !arr.includes(match)) {
        // push preserving existing selections
        (next as unknown as Record<string, unknown>)[key] = [...arr, match];
      }
    };

    tryAdd("selectedBodyStyles", avail?.bodyStyles);
    tryAdd("selectedComfortFeatures", avail?.comfortFeatures);
    tryAdd("selectedDrivetrains", avail?.drivetrains);
    tryAdd("selectedExteriorColors", avail?.exteriorColors);
    tryAdd("selectedExteriorFeatures", avail?.exteriorFeatures);
    tryAdd("selectedFuelTypes", avail?.fuelTypes);
    tryAdd("selectedInteriorColors", avail?.interiorColors);
    tryAdd("selectedModels", avail?.models);
    tryAdd("selectedPerformanceFeatures", avail?.performanceFeatures);
    tryAdd("selectedSafetyFeatures", avail?.safetyFeatures);
    tryAdd("selectedSeatingCapacity", avail?.seatingCapacity);
    tryAdd("selectedTechFeatures", avail?.techFeatures);
    tryAdd("selectedTransmissions", avail?.transmissions);
  }

  return next;
};

export function FilterSidebar({
  isOpen,
  onClose,
  filterState,
  onApply,
  onReset,
  availableFilters,
  facetCounts,
  loadingFacetSections,
  // TODO: vehicles, searchQuery, labelFilter will be needed when live
  // preview is restored via debounced server call to /api/search/filters.
  // Keeping them in FilterSidebarProps for forward compatibility.
  vehicles: _vehicles,
  searchQuery: _searchQuery,
  labelFilter: _labelFilter,
  refineFilters,
}: FilterSidebarProps) {
  const [draftState, setDraftState] = useState<FilterState>(filterState);

  useEffect(() => {
    if (!isOpen) {
      return;
    }

    setDraftState((_prev) => mergeRefinesIntoState(filterState, refineFilters, availableFilters));
  }, [isOpen, filterState, refineFilters, availableFilters]);

  const handleDraftChange = useCallback(
    (key: keyof FilterState, value: FilterState[keyof FilterState]) => {
      setDraftState((prev) => ({ ...prev, [key]: value }));
    },
    []
  );

  // TODO: Replace with debounced server call to /api/search/filters when
  // real BED API is available. Client-side computeAvailableFiltersSync was
  // removed to decouple from mock layer and avoid main-thread blocking.
  // For now, chips use the last server response — they won't grey out during
  // draft changes until Apply is clicked.
  const liveAvailableFilters = availableFilters;

  const [openSection, setOpenSection] = useState<string | null>(null);

  const sectionRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [scrollInfo, setScrollInfo] = useState({ thumbTop: 0, thumbHeight: 20 });

  const handleScroll = useCallback(() => {
    const container = scrollContainerRef.current;
    if (!container) {
      return;
    }

    const { scrollTop, scrollHeight, clientHeight } = container;
    const trackHeight = clientHeight;
    const thumbHeight = Math.max((clientHeight / scrollHeight) * trackHeight, 30);
    const scrollableHeight = scrollHeight - clientHeight;
    const thumbTop =
      scrollableHeight > 0 ? (scrollTop / scrollableHeight) * (trackHeight - thumbHeight) : 0;

    setScrollInfo({ thumbTop, thumbHeight });
  }, []);

  useEffect(() => {
    handleScroll();
  }, [handleScroll]);

  const toggleSection = (section: string) => {
    setOpenSection((prev) => (prev === section ? null : section));
  };

  useEffect(() => {
    if (!openSection) {
      return undefined;
    }
    const timer = setTimeout(() => {
      const sectionEl = sectionRefs.current[openSection];
      if (sectionEl && scrollContainerRef.current) {
        const container = scrollContainerRef.current;
        const sectionRect = sectionEl.getBoundingClientRect();
        const containerRect = container.getBoundingClientRect();
        const offsetTop = sectionRect.top - containerRect.top + container.scrollTop;
        container.scrollTo({ top: offsetTop, behavior: "smooth" });
      }
    }, 50);
    return () => clearTimeout(timer);
  }, [openSection]);

  const toggleArrayFilter = (key: keyof FilterState, arr: string[], value: string) => {
    if (arr.includes(value)) {
      handleDraftChange(
        key,
        arr.filter((v) => v !== value)
      );
    } else {
      handleDraftChange(key, [...arr, value]);
    }
  };

  const handleApply = () => {
    onApply(draftState);
    onClose();
  };

  const handleReset = () => {
    setDraftState(defaultFilterState);
    onReset();
  };

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <button
          aria-label="Close filter sidebar"
          className="fixed inset-0 z-[90] border-none bg-black/40 transition-opacity"
          onClick={onClose}
          onKeyDown={(e) => e.key === "Escape" && onClose()}
          type="button"
        />
      )}

      <aside
        className={`fixed top-0 left-0 z-[100] flex h-full w-full max-w-full transform flex-col bg-white transition-transform duration-300 ease-in-out md:max-w-[70%] ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="relative flex items-center justify-between bg-white py-4 pr-4 pl-[15px] md:pl-[35px]">
          <div className="absolute top-0 left-[214px] z-60 hidden h-full w-[1px] bg-gray-200 md:block" />
          <div className="flex items-center gap-[1rem] md:gap-[7.5rem]">
            <div className="flex items-center gap-[var(--spacing-xs)]">
              <Image
                alt="Filter"
                className="h-[var(--spacing-3)] w-[var(--spacing-sd)]"
                height={10}
                src="/images/filter-lines.svg"
                width={14}
              />
              <span className="font-semibold text-[length:var(--font-size-xl)] text-[var(--color-brand-text-primary)] leading-normal md:text-[length:var(--font-size-lg)]">
                Filter
              </span>
            </div>
            <div className="flex flex-row items-center gap-2.5">
              <AppButton onClick={handleApply} size="sm" variant="primary">
                Apply
              </AppButton>
              <AppButton onClick={handleReset} size="sm" variant="secondary">
                Reset
              </AppButton>
            </div>
          </div>
          <Button
            className="rounded-full p-1 transition-colors hover:bg-gray-100"
            onClick={onClose}
            type="button"
            variant="search"
          >
            <Image
              alt="Close"
              className="h-[10px] w-[10px]"
              height={10}
              src="/images/cross.svg"
              width={10}
            />
          </Button>
        </div>

        <div className="flex flex-1 overflow-hidden">
          <SidebarNav onToggleSection={toggleSection} openSection={openSection} />

          <SidebarFilters
            availableFilters={liveAvailableFilters}
            draftState={draftState}
            facetCounts={facetCounts}
            handleDraftChange={handleDraftChange}
            handleScroll={handleScroll}
            loadingFacetSections={loadingFacetSections}
            openSection={openSection}
            scrollContainerRef={scrollContainerRef}
            scrollInfo={scrollInfo}
            sectionRefs={sectionRefs}
            toggleArrayFilter={toggleArrayFilter}
            toggleSection={toggleSection}
          />
        </div>
      </aside>
    </>
  );
}
