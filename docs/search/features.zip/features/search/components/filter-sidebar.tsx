// Re-export everything from the modularised sub-folder.
// Any existing imports such as:
//   import { FilterSidebar, FilterState, defaultFilterState } from "@features/search/components/filter-sidebar"

export type { FilterSidebarProps, FilterState } from "./filter-sidebar/index";
export {
  defaultFilterState,
  FilterSidebar,
} from "./filter-sidebar/index";
