"use client";

import type { FilterState } from "@features/search/components/filter-sidebar/types";
import type { RefineSearchFilter } from "@features/search/context/search-context-types";
import type { SmartFilterGroup, SmartFilterOption } from "@features/search/lib/search-types";
import { CustomChips } from "@shared/components/custom-chips";
import { slugify } from "utils";

const PRICE_REGEX = /Less than \$?(\d+)[kK]/;
const FIRST_CHAR_REGEX = /^./;

interface Props {
  applyFiltersSearch: (next: FilterState, opts?: { preservePage: boolean }) => void;
  computeSmartFilterChange: (
    group: SmartFilterGroup,
    opt: SmartFilterOption,
    currentFilterState: FilterState,
    currentRefines: RefineSearchFilter[] | undefined
  ) =>
    | { handledAsRefine: false; next: FilterState }
    | { handledAsRefine: true; nextRefines: { id: string; label: string }[] };
  filterState: FilterState;
  group: SmartFilterGroup;
  onApplyRefineFilters?: (filters: { id: string; label: string }[]) => void;
  opt: SmartFilterOption;
  prefix?: string;
  refineSearchFilters?: RefineSearchFilter[];
  setFilterState: (next: FilterState) => void;
}

const priceLabelFromOption = (option: SmartFilterOption) => {
  const dn = option.display_name || option.value || "";
  const m = PRICE_REGEX.exec(dn);
  if (m) {
    return `$${m[1]}k or less`;
  }
  return dn;
};

const mileageLabelFromOption = (option: SmartFilterOption) => {
  const mapping: Record<string, string> = {
    essentially_new: "Under 15k mi",
    very_low: "Low Miles",
  };
  if (mapping[option.value]) {
    return mapping[option.value];
  }
  const dn = option.display_name || option.value || "";
  const normalized = dn.trim().length
    ? dn.trim().replace(FIRST_CHAR_REGEX, (c) => c.toUpperCase())
    : dn;
  return normalized;
};

export default function SmartFilterChip({
  group,
  opt,
  prefix = "",
  filterState,
  refineSearchFilters,
  computeSmartFilterChange,
  setFilterState,
  applyFiltersSearch,
  onApplyRefineFilters,
}: Props) {
  const key = `${prefix}${group.name}-${opt.value}`;

  const optSlug = slugify(opt.display_name || opt.value || "");
  const optLabel = (opt.display_name || opt.value || "").toLowerCase();
  const refineMatches = (grpName: string) =>
    !!refineSearchFilters?.some((f) => {
      if (f.id === `${grpName}:${opt.value}`) {
        return true;
      }
      if (f.id === optSlug) {
        return true;
      }
      if ((f.label || "").toLowerCase() === optLabel) {
        return true;
      }
      return false;
    });

  let isApplied = false;
  if (group.name === "body_style") {
    isApplied = filterState.selectedBodyStyles?.includes(opt.value) || refineMatches(group.name);
  } else if (group.name === "price_range") {
    isApplied =
      filterState.selectedPriceQuick === priceLabelFromOption(opt) || refineMatches(group.name);
  } else if (group.name === "mileage_condition") {
    isApplied =
      filterState.selectedMileage === mileageLabelFromOption(opt) || refineMatches(group.name);
  } else if (
    group.name === "Comfort_and_Convenience" ||
    group.name.toLowerCase().includes("comfort")
  ) {
    isApplied =
      filterState.selectedComfortFeatures?.includes(opt.value) || refineMatches(group.name);
  } else if (group.name === "distance_range") {
    isApplied =
      filterState.selectedMileage === mileageLabelFromOption(opt) || refineMatches(group.name);
  } else {
    isApplied = refineMatches(group.name);
  }

  if (isApplied) {
    return null;
  }

  const handleClick = () => {
    const result = computeSmartFilterChange(group, opt, filterState, refineSearchFilters);
    if (result.handledAsRefine) {
      if (onApplyRefineFilters && "nextRefines" in result) {
        onApplyRefineFilters(result.nextRefines);
      }
      return;
    }

    try {
      setFilterState(result.next as FilterState);
    } catch (_e) {
      // ignore
    }

    applyFiltersSearch(result.next as FilterState, { preservePage: false });
  };

  return (
    <CustomChips
      className="border border-[var(--color-states-muted)] bg-white"
      key={key}
      label={opt.display_name}
      onClick={handleClick}
      type={undefined}
    />
  );
}
