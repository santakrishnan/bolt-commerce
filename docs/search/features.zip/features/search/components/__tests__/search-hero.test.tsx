import * as searchContext from "@features/search/context/search-context";
import { mockVehicles } from "@features/search/lib/mock-vehicles";
import { fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const VEHICLES_FOUND_REGEX = /42 vehicles found/;
const VEHICLES_AVAILABLE_TEXT_REGEX = /\d+ Vehicles Available/;
const SPLIT_WHITESPACE_REGEX = /\s+/;

vi.mock("@features/search/components/search-bar/services/suggest-proxy", () => {
  class SuggestProxyService {
    getQuickFilters = vi.fn(() => {
      const p = Promise.resolve(["dyn-a", "dyn-b"]) as any;
      p.status = "fulfilled";
      p.value = ["dyn-a", "dyn-b"];
      return p;
    });
  }
  return { SuggestProxyService };
});

vi.mock("@features/search/components/search-bar/search-bar", () => ({
  SearchBar: (props: any) => {
    const qf = props.config?.quickFilters;
    return (
      <div
        data-quick-filters={qf === undefined ? "undefined" : JSON.stringify(qf)}
        data-testid="mock-searchbar"
      >
        <button data-testid="searchbar-submit" onClick={() => props.onSubmit?.()} type="button" />
        <button
          data-testid="searchbar-quick-select"
          onClick={() => props.onQuickFilterSelect?.("QUICK_FILTER")}
          type="button"
        />
        <button
          data-testid="searchbar-open-change-true"
          onClick={() => props.onOpenChange?.(true)}
          type="button"
        />
        <button
          data-testid="searchbar-open-change-false"
          onClick={() => props.onOpenChange?.(false)}
          type="button"
        />
        <button
          data-testid="searchbar-value-change"
          onClick={() => props.onValueChange?.("typed-text")}
          type="button"
        />
        <span data-testid="searchbar-value">{props.value}</span>
      </div>
    );
  },
}));

const mockSetSortOption = vi.fn();

vi.mock("@features/search/context/search-context", () => ({
  useSearchContext: () => ({
    sortOption: "recommended",
    setSortOption: mockSetSortOption,
    progress: 0,
    isProgressVisible: true,
  }),
}));

vi.mock("@shared/components/button", () => ({
  AppButton: ({ children, onClick, icon, ...rest }: any) => (
    <button data-testid="mock-app-button" onClick={onClick} type="button" {...rest}>
      {icon}
      {children}
    </button>
  ),
}));

vi.mock("@shared/components/custom-chips", () => ({
  CustomChips: (props: any) => (
    <div data-testid="mock-chip">
      <span>{props.label}</span>
      <button data-testid="chip-remove" onClick={props.onRemove} type="button" />
    </div>
  ),
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Heading: (props: any) => <div data-testid="mock-heading">{props.children}</div>,
}));

vi.mock("next/image", () => ({
  __esModule: true,
  // biome-ignore lint/performance/noImgElement: test mock for next/image
  default: (props: any) => <img {...props} alt={props.alt} height={1} width={1} />,
}));

// Stubs IntersectionObserver so the hero section reports as NOT visible (triggers the sticky header).
function stubHeroNotVisible() {
  vi.stubGlobal(
    "IntersectionObserver",
    class {
      cb: any;
      constructor(cb: any) {
        this.cb = cb;
      }
      observe() {
        this.cb([{ isIntersecting: false }]);
      }
      disconnect() {
        /* noop */
      }
    }
  );
}

// Stubs IntersectionObserver so the hero section reports as visible (no sticky header shown).
function stubHeroVisible() {
  vi.stubGlobal(
    "IntersectionObserver",
    class {
      cb: any;
      constructor(cb: any) {
        this.cb = cb;
      }
      observe() {
        this.cb([{ isIntersecting: true }]);
      }
      disconnect() {
        /* noop */
      }
    }
  );
}

// Stubs IntersectionObserver but does NOT call the callback (hero remains visible by default state).
function stubHeroInert() {
  vi.stubGlobal(
    "IntersectionObserver",
    class {
      cb: any;
      constructor(cb: any) {
        this.cb = cb;
      }
      observe() {
        /* noop */
      }
      disconnect() {
        /* noop */
      }
    }
  );
}

function overrideSearchContext(overrides: Record<string, unknown>) {
  (searchContext as any).useSearchContext = () => ({
    sortOption: "recommended",
    setSortOption: mockSetSortOption,
    progress: 0,
    isProgressVisible: true,
    ...overrides,
  });
}

import { SearchHero } from "../search-hero";

describe("SearchHero component (unit)", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    stubHeroInert();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("renders title and vehicle count when showTitle is true", () => {
    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
        suggestedPills={["p-x"]}
        vehiclesAvailable={7}
      />
    );

    expect(screen.getByTestId("mock-heading")).toHaveTextContent("FIND YOUR NEXT CAR");
    // Use getAllByText to handle multiple matches and select the visible vehicle count element
    const countEls = screen.getAllByText((_content, node) => {
      const text = node?.textContent?.replace(/\s+/g, " ")?.trim() || "";
      return VEHICLES_AVAILABLE_TEXT_REGEX.test(text);
    });
    expect(countEls.length).toBeGreaterThan(0);
    // Pick the first element that is a <p> (the visible vehicle count)
    const countEl = countEls.find((el) => el.tagName === "P") || countEls[0];
    expect(countEl).toBeTruthy();
    const displayed = Number.parseInt(
      (countEl.textContent || "").trim().split(SPLIT_WHITESPACE_REGEX)[0],
      10
    );
    expect([7, mockVehicles.length, 50]).toContain(displayed);
  });

  it("hides title when showTitle is false", () => {
    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
        showTitle={false}
      />
    );

    expect(screen.queryByTestId("mock-heading")).toBeNull();
  });

  it("falls back to empty resolvedPills when suggestedPills is undefined", () => {
    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
      />
    );

    const bars = screen.getAllByTestId("mock-searchbar");
    expect((bars[0] as HTMLElement).dataset.quickFilters).toBe("[]");
  });

  it("passes undefined quickFilters when showQuickFilters is false", () => {
    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
        showQuickFilters={false}
        suggestedPills={["a", "b"]}
      />
    );

    const bars = screen.getAllByTestId("mock-searchbar");
    const lastBar = bars.at(-1) as HTMLElement;
    expect(lastBar.dataset.quickFilters).toBe("undefined");
  });

  // Main SearchBar callbacks

  it("submit triggers onSearchChange and onSearch", () => {
    const onSearchChange = vi.fn();
    const onSearch = vi.fn();

    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={onSearch}
        onSearchChange={onSearchChange}
        searchQuery="initial-query"
        suggestedPills={["p1"]}
      />
    );

    const submits = screen.getAllByTestId("searchbar-submit");
    fireEvent.click(submits.at(-1) as HTMLElement);

    expect(onSearchChange).toHaveBeenCalledWith("initial-query");
    expect(onSearch).toHaveBeenCalled();
  });

  it("quick filter selection calls onSearchChange and onSearch", () => {
    const onSearchChange = vi.fn();
    const onSearch = vi.fn();

    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={onSearch}
        onSearchChange={onSearchChange}
        searchQuery=""
        suggestedPills={["p1", "p2"]}
      />
    );

    const quicks = screen.getAllByTestId("searchbar-quick-select");
    fireEvent.click(quicks.at(-1) as HTMLElement);

    expect(onSearchChange).toHaveBeenCalledWith("QUICK_FILTER");
    expect(onSearch).toHaveBeenCalled();
  });

  it("main SearchBar onOpenChange(true) calls onBlurOverlayChange", () => {
    const onBlurOverlayChange = vi.fn();

    render(
      <SearchHero
        activeFilters={[]}
        onBlurOverlayChange={onBlurOverlayChange}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
        suggestedPills={["p1"]}
      />
    );

    const openBtns = screen.getAllByTestId("searchbar-open-change-true");
    fireEvent.click(openBtns.at(-1) as HTMLElement);

    expect(onBlurOverlayChange).toHaveBeenCalledWith(true);
  });

  it("main SearchBar onOpenChange(false) calls onBlurOverlayChange", () => {
    const onBlurOverlayChange = vi.fn();

    render(
      <SearchHero
        activeFilters={[]}
        onBlurOverlayChange={onBlurOverlayChange}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
        suggestedPills={["p1"]}
      />
    );

    const closeBtns = screen.getAllByTestId("searchbar-open-change-false");
    fireEvent.click(closeBtns.at(-1) as HTMLElement);

    expect(onBlurOverlayChange).toHaveBeenCalledWith(false);
  });

  it("main SearchBar onValueChange updates editing state", () => {
    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
        suggestedPills={["p1"]}
      />
    );

    const valBtns = screen.getAllByTestId("searchbar-value-change");
    fireEvent.click(valBtns.at(-1) as HTMLElement);

    const vals = screen.getAllByTestId("searchbar-value");
    expect(vals.at(-1)?.textContent).toBe("typed-text");
  });

  // Sticky header (hero NOT visible, NO active filters)

  it("sticky header shows Filter and Sort button when no active filters and onToggleFilter provided", () => {
    stubHeroNotVisible();
    const onToggleFilter = vi.fn();

    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        onToggleFilter={onToggleFilter}
        searchQuery=""
        suggestedPills={["p1"]}
      />
    );

    const buttons = screen.getAllByTestId("mock-app-button");
    const filterSortBtn = buttons[0];
    expect(filterSortBtn).toBeTruthy();

    fireEvent.click(filterSortBtn as HTMLElement);
    expect(onToggleFilter).toHaveBeenCalled();
  });

  it("sticky header renders SearchBar when no active filters", () => {
    stubHeroNotVisible();

    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
        suggestedPills={["p1"]}
      />
    );

    const bars = screen.getAllByTestId("mock-searchbar");
    expect(bars.length).toBeGreaterThanOrEqual(2);
  });

  it("sticky SearchBar onOpenChange calls onBlurOverlayChange", () => {
    stubHeroNotVisible();
    const onBlurOverlayChange = vi.fn();

    render(
      <SearchHero
        activeFilters={[]}
        onBlurOverlayChange={onBlurOverlayChange}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
        suggestedPills={["p1"]}
      />
    );

    const openBtns = screen.getAllByTestId("searchbar-open-change-true");
    fireEvent.click(openBtns[0] as HTMLElement);
    expect(onBlurOverlayChange).toHaveBeenCalledWith(true);
  });

  it("sticky SearchBar onQuickFilterSelect triggers search flow", () => {
    stubHeroNotVisible();
    const onSearchChange = vi.fn();
    const onSearch = vi.fn();

    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={onSearch}
        onSearchChange={onSearchChange}
        searchQuery=""
        suggestedPills={["p1"]}
      />
    );

    const quicks = screen.getAllByTestId("searchbar-quick-select");
    fireEvent.click(quicks[0] as HTMLElement);

    expect(onSearchChange).toHaveBeenCalledWith("QUICK_FILTER");
    expect(onSearch).toHaveBeenCalled();
  });

  it("sticky SearchBar onValueChange updates localQuery", () => {
    stubHeroNotVisible();

    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
        suggestedPills={["p1"]}
      />
    );

    const valBtns = screen.getAllByTestId("searchbar-value-change");
    fireEvent.click(valBtns[0] as HTMLElement);

    const vals = screen.getAllByTestId("searchbar-value");
    expect((vals[0] as HTMLElement).textContent).toBe("typed-text");
  });

  // Sticky header (hero NOT visible, WITH active filters)

  it("renders applied filters, chips, Reset, and sort select in sticky header", () => {
    stubHeroNotVisible();
    const onReset = vi.fn();
    const onRemoveFilter = vi.fn();
    const onToggleFilter = vi.fn();

    render(
      <SearchHero
        activeFilters={[{ type: "type", value: "val", label: "Label", isRefineSearch: false }]}
        onRemoveFilter={onRemoveFilter}
        onReset={onReset}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        onToggleFilter={onToggleFilter}
        searchQuery=""
        suggestedPills={["p-x"]}
        vehicleCount={42}
      />
    );

    expect(screen.getByTestId("mock-chip")).toHaveTextContent("Label");
    expect(screen.getByText(VEHICLES_FOUND_REGEX)).toBeTruthy();

    const appButtons = screen.getAllByTestId("mock-app-button");
    expect(appButtons.some((b) => b.textContent === "Reset")).toBe(true);
  });

  it("onRemoveFilter fires when chip remove button is clicked in sticky header", () => {
    stubHeroNotVisible();
    const onRemoveFilter = vi.fn();

    render(
      <SearchHero
        activeFilters={[{ type: "color", value: "red", label: "Red", isRefineSearch: false }]}
        onRemoveFilter={onRemoveFilter}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
      />
    );

    const removeBtn = screen.getByTestId("chip-remove");
    fireEvent.click(removeBtn);

    expect(onRemoveFilter).toHaveBeenCalledWith("color", "red");
  });

  it("sort select change calls setSortOption", () => {
    stubHeroNotVisible();

    render(
      <SearchHero
        activeFilters={[{ type: "t", value: "v", label: "L", isRefineSearch: false }]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
      />
    );

    const select = document.querySelector("select") as HTMLSelectElement;
    expect(select).not.toBeNull();

    fireEvent.change(select, { target: { value: "low-high" } });
    expect(mockSetSortOption).toHaveBeenCalledWith("low-high");
  });

  it("sticky filter button with active filters calls onToggleFilter", () => {
    stubHeroNotVisible();
    const onToggleFilter = vi.fn();

    render(
      <SearchHero
        activeFilters={[{ type: "t", value: "v", label: "L", isRefineSearch: false }]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        onToggleFilter={onToggleFilter}
        searchQuery=""
      />
    );

    const buttons = screen.getAllByTestId("mock-app-button");
    fireEvent.click(buttons[0] as HTMLElement);
    expect(onToggleFilter).toHaveBeenCalled();
  });

  // Progress bar transitions

  it("progress bar transition is 'none' when progress is 0", () => {
    stubHeroNotVisible();
    overrideSearchContext({ progress: 0, isProgressVisible: true });

    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
      />
    );

    const bar = document.querySelector("div[aria-hidden]") as HTMLDivElement;
    expect(bar).not.toBeNull();
    expect(bar.style.transition).toBe("none");
  });

  it("progress bar transition uses cubic-bezier for mid values", () => {
    stubHeroNotVisible();
    overrideSearchContext({ progress: 42, isProgressVisible: true });

    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
      />
    );

    const bar = document.querySelector("div[aria-hidden]") as HTMLDivElement;
    expect(bar).not.toBeNull();
    expect(bar.style.transition).toContain("cubic-bezier");
  });

  it("progress bar transition uses fast ease-in for progress=100", () => {
    stubHeroNotVisible();
    overrideSearchContext({ progress: 100, isProgressVisible: true });

    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
      />
    );

    const bar = document.querySelector("div[aria-hidden]") as HTMLDivElement;
    expect(bar).not.toBeNull();
    expect(bar.style.transition).toContain("0.25s");
  });

  it("progress bar has opacity 0 when isProgressVisible is false", () => {
    stubHeroNotVisible();
    overrideSearchContext({ progress: 50, isProgressVisible: false });

    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
      />
    );

    const bar = document.querySelector("div[aria-hidden]") as HTMLDivElement;
    expect(bar).not.toBeNull();
    expect(bar.style.opacity).toBe("0");
  });

  // Sync localQuery with searchQuery prop

  it("syncs localQuery when searchQuery prop changes and not editing", () => {
    const { rerender } = render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery="first"
        suggestedPills={["p1"]}
      />
    );

    rerender(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery="second"
        suggestedPills={["p1"]}
      />
    );

    const vals = screen.getAllByTestId("searchbar-value");
    expect(vals.at(-1)?.textContent).toBe("second");
  });

  // Width measurement effect

  it("width measurement effect renders measure span and select refs", () => {
    stubHeroNotVisible();
    overrideSearchContext({ sortOption: "low-high" });

    render(
      <SearchHero
        activeFilters={[{ type: "t", value: "v", label: "L", isRefineSearch: false }]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
      />
    );

    const measureSpan = document.querySelector("span[aria-hidden]") as HTMLSpanElement;
    const select = document.querySelector("select") as HTMLSelectElement;
    expect(measureSpan).not.toBeNull();
    expect(select).not.toBeNull();
    expect(select.value).toBe("low-high");
  });

  // Hero visible via IntersectionObserver

  it("does not render sticky header when hero IS visible", () => {
    stubHeroVisible();

    render(
      <SearchHero
        activeFilters={[]}
        onRemoveFilter={vi.fn()}
        onSearch={vi.fn()}
        onSearchChange={vi.fn()}
        searchQuery=""
        suggestedPills={["p-x"]}
      />
    );

    const bars = screen.getAllByTestId("mock-searchbar");
    expect(bars.length).toBe(1);
  });
});
