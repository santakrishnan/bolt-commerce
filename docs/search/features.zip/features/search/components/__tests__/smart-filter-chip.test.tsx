import type { FilterState } from "@features/search/components/filter-sidebar/types";
import type { SmartFilterGroup, SmartFilterOption } from "@features/search/lib/mock-faceted-search";
import { fireEvent, render, screen } from "@testing-library/react";
import { expect, it, vi } from "vitest";
import SmartFilterChip from "../smart-filter-chip";

vi.mock("@shared/components/custom-chips", () => ({
  CustomChips: ({ label, onClick }: any) => (
    <button data-testid="chip" onClick={onClick} type="button">
      {label}
    </button>
  ),
}));
describe("SmartFilterChip", () => {
  const baseOpt = (v: string, dn?: string): SmartFilterOption => ({
    value: v,
    display_name: dn ?? v,
  });
  const baseGroup = (name: string): SmartFilterGroup => ({ name, label: name, options: [] });

  it("returns null when body_style is already selected", () => {
    const group = baseGroup("body_style");
    const opt = baseOpt("sedan", "Sedan");
    const filterState = { selectedBodyStyles: ["sedan"] } as unknown as FilterState;

    render(
      <SmartFilterChip
        applyFiltersSearch={() => undefined}
        computeSmartFilterChange={() => ({ handledAsRefine: false, next: filterState })}
        filterState={filterState}
        group={group}
        opt={opt}
        setFilterState={() => undefined}
      />
    );

    expect(screen.queryByTestId("chip")).toBeNull();
  });

  it("returns null when refineMatches by id", () => {
    const group = baseGroup("color");
    const opt = baseOpt("red", "Red");
    const filterState = {} as FilterState;
    const refineSearchFilters = [{ id: "color:red", label: "Red" }];

    render(
      <SmartFilterChip
        applyFiltersSearch={() => undefined}
        computeSmartFilterChange={() => ({ handledAsRefine: false, next: filterState })}
        filterState={filterState}
        group={group}
        opt={opt}
        refineSearchFilters={refineSearchFilters as any}
        setFilterState={() => undefined}
      />
    );

    expect(screen.queryByTestId("chip")).toBeNull();
  });

  it("returns null when price_range matches selectedPriceQuick", () => {
    const group = baseGroup("price_range");
    const opt = baseOpt("10k", "Less than $10k");
    const filterState = { selectedPriceQuick: "$10k or less" } as unknown as FilterState;

    render(
      <SmartFilterChip
        applyFiltersSearch={() => undefined}
        computeSmartFilterChange={() => ({ handledAsRefine: false, next: filterState })}
        filterState={filterState}
        group={group}
        opt={opt}
        setFilterState={() => undefined}
      />
    );

    expect(screen.queryByTestId("chip")).toBeNull();
  });

  it("returns null when mileage_condition matches selectedMileage", () => {
    const group = baseGroup("mileage_condition");
    const opt = baseOpt("essentially_new", "Essentially New");
    const filterState = { selectedMileage: "Under 15k mi" } as unknown as FilterState;

    render(
      <SmartFilterChip
        applyFiltersSearch={() => undefined}
        computeSmartFilterChange={() => ({ handledAsRefine: false, next: filterState })}
        filterState={filterState}
        group={group}
        opt={opt}
        setFilterState={() => undefined}
      />
    );

    expect(screen.queryByTestId("chip")).toBeNull();
  });

  it("returns null when comfort feature already selected", () => {
    const group = baseGroup("Comfort_and_Convenience");
    const opt = baseOpt("heated_seat", "Heated Seat");
    const filterState = { selectedComfortFeatures: ["heated_seat"] } as unknown as FilterState;

    render(
      <SmartFilterChip
        applyFiltersSearch={() => undefined}
        computeSmartFilterChange={() => ({ handledAsRefine: false, next: filterState })}
        filterState={filterState}
        group={group}
        opt={opt}
        setFilterState={() => undefined}
      />
    );

    expect(screen.queryByTestId("chip")).toBeNull();
  });

  it("calls onApplyRefineFilters when computeSmartFilterChange returns handledAsRefine", () => {
    const group = baseGroup("refine_group");
    const opt = baseOpt("opt1", "Option 1");
    const filterState = {} as FilterState;
    const onApplyRefineFilters = vi.fn();

    render(
      <SmartFilterChip
        applyFiltersSearch={() => undefined}
        computeSmartFilterChange={() => ({
          handledAsRefine: true,
          nextRefines: [{ id: "x", label: "X" }],
        })}
        filterState={filterState}
        group={group}
        onApplyRefineFilters={onApplyRefineFilters}
        opt={opt}
        refineSearchFilters={[]}
        setFilterState={() => undefined}
      />
    );

    fireEvent.click(screen.getByTestId("chip"));
    expect(onApplyRefineFilters).toHaveBeenCalledWith([{ id: "x", label: "X" }]);
  });

  it("calls setFilterState and applyFiltersSearch when computeSmartFilterChange returns next state", () => {
    const group = baseGroup("some_group");
    const opt = baseOpt("opt2", "Option 2");
    const nextState = { selectedBodyStyles: ["opt2"] } as unknown as FilterState;
    const setFilterState = vi.fn();
    const applyFiltersSearch = vi.fn();

    render(
      <SmartFilterChip
        applyFiltersSearch={applyFiltersSearch}
        computeSmartFilterChange={() => ({ handledAsRefine: false, next: nextState })}
        filterState={{} as FilterState}
        group={group}
        opt={opt}
        refineSearchFilters={[]}
        setFilterState={setFilterState}
      />
    );

    fireEvent.click(screen.getByTestId("chip"));
    expect(setFilterState).toHaveBeenCalledWith(nextState);
    expect(applyFiltersSearch).toHaveBeenCalledWith(nextState, { preservePage: false });
  });

  it("returns null when refineMatches by slug", () => {
    const group = baseGroup("color");
    const opt = baseOpt("red", "Red");
    const filterState = {} as FilterState;
    const refineSearchFilters = [{ id: "red", label: "Red" }];

    render(
      <SmartFilterChip
        applyFiltersSearch={() => undefined}
        computeSmartFilterChange={() => ({ handledAsRefine: false, next: filterState })}
        filterState={filterState}
        group={group}
        opt={opt}
        refineSearchFilters={refineSearchFilters as any}
        setFilterState={() => undefined}
      />
    );

    expect(screen.queryByTestId("chip")).toBeNull();
  });

  it("returns null when refineMatches by label (case-insensitive)", () => {
    const group = baseGroup("color");
    const opt = baseOpt("blue", "Blue");
    const filterState = {} as FilterState;
    const refineSearchFilters = [{ id: "x", label: "BLUE" }];

    render(
      <SmartFilterChip
        applyFiltersSearch={() => undefined}
        computeSmartFilterChange={() => ({ handledAsRefine: false, next: filterState })}
        filterState={filterState}
        group={group}
        opt={opt}
        refineSearchFilters={refineSearchFilters as any}
        setFilterState={() => undefined}
      />
    );

    expect(screen.queryByTestId("chip")).toBeNull();
  });

  it("returns null for distance_range when selectedMileage matches", () => {
    const group = baseGroup("distance_range");
    const opt = baseOpt("very_low", "Very low");
    const filterState = { selectedMileage: "Low Miles" } as unknown as FilterState;

    render(
      <SmartFilterChip
        applyFiltersSearch={() => undefined}
        computeSmartFilterChange={() => ({ handledAsRefine: false, next: filterState })}
        filterState={filterState}
        group={group}
        opt={opt}
        setFilterState={() => undefined}
      />
    );

    expect(screen.queryByTestId("chip")).toBeNull();
  });

  it("returns null when group name includes 'comfort' (lowercase) and feature selected", () => {
    const group = baseGroup("seat_comfort");
    const opt = baseOpt("heated_seat", "Heated Seat");
    const filterState = { selectedComfortFeatures: ["heated_seat"] } as unknown as FilterState;

    render(
      <SmartFilterChip
        applyFiltersSearch={() => undefined}
        computeSmartFilterChange={() => ({ handledAsRefine: false, next: filterState })}
        filterState={filterState}
        group={group}
        opt={opt}
        setFilterState={() => undefined}
      />
    );

    expect(screen.queryByTestId("chip")).toBeNull();
  });

  it("does not throw when computeSmartFilterChange returns handledAsRefine and no callback provided", () => {
    const group = baseGroup("refine_group");
    const opt = baseOpt("opt3", "Option 3");
    const filterState = {} as FilterState;

    render(
      <SmartFilterChip
        applyFiltersSearch={() => undefined}
        computeSmartFilterChange={() => ({
          handledAsRefine: true,
          nextRefines: [{ id: "y", label: "Y" }],
        })}
        filterState={filterState}
        group={group}
        opt={opt}
        refineSearchFilters={[]}
        setFilterState={() => undefined}
      />
    );

    expect(() => fireEvent.click(screen.getByTestId("chip"))).not.toThrow();
  });

  it("returns null when mileage_label is normalized from display_name and matches selectedMileage", () => {
    const group = baseGroup("mileage_condition");
    const opt = baseOpt("low_label", "low miles");
    const filterState = { selectedMileage: "Low miles" } as unknown as FilterState;

    render(
      <SmartFilterChip
        applyFiltersSearch={() => undefined}
        computeSmartFilterChange={() => ({ handledAsRefine: false, next: filterState })}
        filterState={filterState}
        group={group}
        opt={opt}
        setFilterState={() => undefined}
      />
    );

    expect(screen.queryByTestId("chip")).toBeNull();
  });

  it("handles setFilterState throwing and still calls applyFiltersSearch", () => {
    const group = baseGroup("some_group");
    const opt = baseOpt("opt4", "Option 4");
    const nextState = { foo: "bar" } as unknown as FilterState;
    const setFilterState = () => {
      throw new Error("boom");
    };
    const applyFiltersSearch = vi.fn();

    render(
      <SmartFilterChip
        applyFiltersSearch={applyFiltersSearch}
        computeSmartFilterChange={() => ({ handledAsRefine: false, next: nextState })}
        filterState={{} as FilterState}
        group={group}
        opt={opt}
        refineSearchFilters={[]}
        setFilterState={setFilterState}
      />
    );

    expect(() => fireEvent.click(screen.getByTestId("chip"))).not.toThrow();
    expect(applyFiltersSearch).toHaveBeenCalledWith(nextState, { preservePage: false });
  });
});
