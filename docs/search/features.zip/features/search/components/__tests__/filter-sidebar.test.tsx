import { describe, expect, it } from "vitest";
import type { FilterSidebarProps, FilterState } from "../filter-sidebar";
import { defaultFilterState, FilterSidebar } from "../filter-sidebar";

describe("filter-sidebar barrel re-exports", () => {
  it("exports defaultFilterState as a plain object with expected keys", () => {
    expect(typeof defaultFilterState).toBe("object");
    expect(defaultFilterState).not.toBeNull();
    expect(defaultFilterState).toHaveProperty("selectedPriceQuick");
    expect(defaultFilterState).toHaveProperty("selectedBodyStyles");
    expect(defaultFilterState).toHaveProperty("selectedYearQuick");
  });

  it("exports FilterSidebar as a function component", () => {
    expect(typeof FilterSidebar).toBe("function");
  });

  it("FilterSidebarProps type is usable at compile time", () => {
    const props: Partial<FilterSidebarProps> = { isOpen: true };
    expect(props.isOpen).toBe(true);
  });

  it("FilterState type is usable at compile time", () => {
    const state: Partial<FilterState> = { selectedPriceQuick: "" };
    expect(state.selectedPriceQuick).toBe("");
  });
});
