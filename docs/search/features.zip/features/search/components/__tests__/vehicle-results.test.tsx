import type { Vehicle } from "@shared/types";
import { fireEvent, render, screen } from "@testing-library/react";
import { expect, test, vi } from "vitest";

const RESET_REGEX = /Reset/i;
const MONTHS_REGEX = /months$/;
const PREVIOUS_REGEX = /Previous/i;
const NEXT_REGEX = /Next/i;

const mockContext = { sortOption: "recommended", setSortOption: vi.fn() };

vi.mock("@features/search/context/search-context", () => ({
  useSearchContext: () => mockContext,
}));

vi.mock("@features/vehicle-card", () => ({
  CarCard: (props: any) => <div data-props={JSON.stringify(props)} data-testid="car-card" />,
}));

vi.mock("@shared/components/button", () => ({
  AppButton: ({ children, onClick, ...rest }: any) => (
    <button data-testid="app-button" onClick={onClick} {...rest}>
      {children}
    </button>
  ),
}));

vi.mock("@shared/components/custom-chips", () => ({
  CustomChips: ({ label, onRemove }: any) => (
    <button data-testid={`chip-${label}`} onClick={onRemove} type="button">
      {label}
    </button>
  ),
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({ children, onClick, disabled, ...rest }: any) => (
    <button data-testid="ui-button" disabled={disabled} onClick={onClick} {...rest}>
      {children}
    </button>
  ),
}));

vi.mock("next/image", () => ({
  __esModule: true,
  // biome-ignore lint/performance/noImgElement: test mock for next/image
  default: (props: any) => <img {...props} alt="mock" height={1} width={1} />,
}));

vi.mock("@config/messages/used-cars", () => ({
  getUsedCarsSrpNoResultsMessage: () => ({ title: "No cars", hint: "Try clearing filters" }),
}));

import { VehicleResults } from "@features/search/components/vehicle-results";

const baseProps = {
  onToggleFilter: vi.fn(),
  onRemoveFilter: vi.fn(),
  onReset: vi.fn(),
  onSearch: vi.fn(),
  onApplyRefineFilters: vi.fn(),
  onPageChange: vi.fn(),
  currentPage: 1,
  itemsPerPage: 10,
  activeFilters: [] as any[],
  searchQuery: "",
  totalCount: 0,
  vehicles: [] as any[],
};

function makeVehicle(overrides: Partial<Vehicle> = {}): Vehicle {
  return {
    id: 1,
    title: "2020 Test Car",
    make: "Make",
    model: "Model",
    variant: "X",
    year: 2020,
    vin: "VIN123",
    price: 19_999,
    oldPrice: 20_999,
    odometer: "10,000 mi",
    image: "/img.jpg",
    extColorName: "Blue",
    extColorCode: "#0000ff",
    intColorName: "Black",
    intColorCode: "#000000",
    match: 85,
    owners: 1,
    labels: ["Excellent Price"],
    miles: "Dealer - 5 mi",
    mileage: 10_000,
    bodyType: "Sedan",
    drivetrain: "FWD",
    features: { comfort: [], exterior: [], performance: [], safety: [], tech: ["Heated Seats"] },
    fuelType: "Gasoline",
    transmission: "Automatic",
    seatingCapacity: ["5"],
    inspection160: false,
    warranty: false,
    dealerId: "toyota-plano",
    dealerLocation: "Plano, TX 75001",
    dealerName: "Toyota of Plano",
    mpg: "28-39",
    stock: "STK00001",
    ...overrides,
  };
}

test("shows Filter and Sort when no active filters and triggers onToggleFilter", () => {
  const p = { ...baseProps, totalCount: 5, vehicles: [makeVehicle()] };
  render(<VehicleResults {...p} />);

  const appButton = screen.getByTestId("app-button");
  expect(appButton).toBeTruthy();
  fireEvent.click(appButton);
  expect(p.onToggleFilter).toHaveBeenCalledTimes(1);
});

test("renders active filters, chips and Reset button and triggers callbacks", () => {
  const filter = { label: "Trim: SE", type: "trim", value: "se" };
  const active = [filter];
  const p = { ...baseProps, activeFilters: active, totalCount: 2, vehicles: [makeVehicle()] };
  render(<VehicleResults {...p} />);

  const chip = screen.getByTestId(`chip-${filter.label}`);
  expect(chip).toBeTruthy();
  fireEvent.click(chip);
  expect(p.onRemoveFilter).toHaveBeenCalledWith(filter.type, filter.value);

  const reset = screen.getByText(RESET_REGEX);
  fireEvent.click(reset);
  expect(p.onReset).toHaveBeenCalled();
});

test("maps vehicle to CarCard props (price formatting, wasPrice, estimation and badge)", () => {
  const vehicle = makeVehicle({
    labels: ["Price Drop"],
    price: 12_000,
    oldPrice: undefined,
    match: 0,
  });
  const p = { ...baseProps, vehicles: [vehicle], totalCount: 1 };
  render(<VehicleResults {...p} />);

  const card = screen.getByTestId("car-card");
  expect(card).toBeTruthy();
  const props = JSON.parse(card.getAttribute("data-props") || "{}");

  expect(props.price).toBe(`$${vehicle.price.toLocaleString()}`);
  expect(props.wasPrice).toBeUndefined();
  expect(props.estimation.termLength).toMatch(MONTHS_REGEX);
  expect(props.badge).toEqual({ type: "priceDrop", text: "Price Drop" });
});

test("shows no results message when vehicle count is zero", () => {
  const p = { ...baseProps, vehicles: [], totalCount: 0 };
  render(<VehicleResults {...p} />);

  expect(screen.getByText("No cars")).toBeTruthy();
  expect(screen.getByText("Try clearing filters")).toBeTruthy();
});

test("pagination renders ellipsis and page navigation works", () => {
  const totalCount = 55;
  const onPageChange = vi.fn();
  const p = {
    ...baseProps,
    vehicles: [makeVehicle()],
    totalCount,
    itemsPerPage: 10,
    onPageChange,
    currentPage: 1,
  };
  render(<VehicleResults {...p} />);

  expect(screen.getByText("...")).toBeTruthy();

  const prev = screen.getByText(PREVIOUS_REGEX);
  expect(prev).toBeDisabled();

  const next = screen.getByText(NEXT_REGEX);
  fireEvent.click(next);
  expect(onPageChange).toHaveBeenCalledWith(2);

  const page3 = screen.getByText("3");
  fireEvent.click(page3);
  expect(onPageChange).toHaveBeenCalledWith(3);
});

test("applies pending styles when isPending is true", () => {
  const p = { ...baseProps, vehicles: [makeVehicle()], totalCount: 1, isPending: true };
  const { container } = render(<VehicleResults {...p} />);
  expect(container.querySelector(".opacity-60")).toBeTruthy();
});

test("measures and applies select width when measureRef has positive width", () => {
  const original = Object.getOwnPropertyDescriptor(HTMLSpanElement.prototype, "offsetWidth");
  Object.defineProperty(HTMLSpanElement.prototype, "offsetWidth", {
    get() {
      return 42;
    },
    configurable: true,
  });

  try {
    const p = {
      ...baseProps,
      vehicles: [makeVehicle()],
      totalCount: 1,
      activeFilters: [{ label: "x", type: "t", value: "v" }],
    };
    render(<VehicleResults {...p} />);

    const select = document.querySelector("select") as HTMLSelectElement | null;
    expect(select).toBeTruthy();
    expect(select?.style.width).toBe("42px");
  } finally {
    if (original) {
      Object.defineProperty(HTMLSpanElement.prototype, "offsetWidth", original);
    }
  }
});

test("renders compact pagination when totalPages <= 4 and previous works", () => {
  const totalCount = 30;
  const onPageChange = vi.fn();
  const p = {
    ...baseProps,
    vehicles: [makeVehicle()],
    totalCount,
    itemsPerPage: 10,
    onPageChange,
    currentPage: 2,
  };
  render(<VehicleResults {...p} />);

  expect(screen.queryByText("...")).toBeNull();

  expect(screen.getByText("1")).toBeTruthy();
  expect(screen.getByText("2")).toBeTruthy();
  expect(screen.getByText("3")).toBeTruthy();

  const prev = screen.getByText(PREVIOUS_REGEX);
  expect(prev).not.toBeDisabled();
  fireEvent.click(prev);
  expect(onPageChange).toHaveBeenCalledWith(1);
});

test("calls setSortOption when select value changes", () => {
  mockContext.setSortOption = vi.fn();
  const p = {
    ...baseProps,
    vehicles: [makeVehicle()],
    totalCount: 1,
    activeFilters: [{ label: "x", type: "t", value: "v" }],
  };
  render(<VehicleResults {...p} />);

  const select = document.querySelector("select") as HTMLSelectElement | null;
  expect(select).toBeTruthy();
  fireEvent.change(select as Element, { target: { value: "low-high" } });
  expect(mockContext.setSortOption).toHaveBeenCalledWith("low-high");
});

test("pagination end-case renders correctly and page clicks work near the end", () => {
  const totalCount = 55;
  const onPageChange = vi.fn();
  const p = {
    ...baseProps,
    vehicles: [makeVehicle()],
    totalCount,
    itemsPerPage: 10,
    onPageChange,
    currentPage: 6,
  };
  render(<VehicleResults {...p} />);

  expect(screen.getByText("...")).toBeTruthy();
  const page4 = screen.getByText("4");
  fireEvent.click(page4);
  expect(onPageChange).toHaveBeenCalledWith(4);
});
