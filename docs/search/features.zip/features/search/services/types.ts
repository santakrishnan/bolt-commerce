export interface SearchQuery {
  bodyStyles?: string[];
  fuelTypes?: string[];
  makes?: string[];
  models?: string[];
  page?: number;
  pageSize?: number;
  priceMax?: number;
  priceMin?: number;
  query?: string;
  sortBy?: "price" | "year" | "mileage" | "match" | "relevance";
  sortOrder?: "asc" | "desc";
  yearMax?: number;
  yearMin?: number;
}

export interface SearchVehicle {
  estimation?: {
    creditScore: string;
    apr: string;
    termLength: string;
    estimatedMonthlyPayment: string;
  };
  id: number;
  image: string | string[];
  labels: string[];
  make: string;
  match: number;
  miles: string;
  model: string;
  odometer: string;
  oldPrice?: number;
  owners: number;
  price: number;
  title: string;
  variant: string;
  vin: string;
  year: number;
}

export interface SearchPagination {
  page: number;
  pageSize: number;
  totalPages: number;
  totalResults: number;
}

export interface SearchResult {
  pagination: SearchPagination;
  vehicles: SearchVehicle[];
}
