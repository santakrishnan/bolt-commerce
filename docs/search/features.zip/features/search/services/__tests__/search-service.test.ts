import { SEARCH_PAGE_SIZE } from "@features/search/lib/constants";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// We'll hoist mocks so imports inside the module under test pick them up.
let postMock: any = vi.fn();

const TOYOTA_REGEX = /Toyota/i;

class MockArrowServerError extends Error {}

vi.mock("@features/tracking/lib/server-api", () => {
  return {
    ArrowServerError: MockArrowServerError,
    createArrowServerClient: () => ({ post: (...args: any[]) => postMock(...args) }),
  };
});

vi.mock("@features/search/lib/mock-vehicles", () => {
  return {
    mockVehicles: [
      {
        id: "v1",
        title: "2019 Toyota Camry",
        make: "Toyota",
        model: "Camry",
        price: 15_000,
        year: 2019,
        match: 90,
      },
      {
        id: "v2",
        title: "2020 Honda Civic",
        make: "Honda",
        model: "Civic",
        price: 14_000,
        year: 2020,
        match: 85,
      },
      {
        id: "v3",
        title: "2018 Ford Focus",
        make: "Ford",
        model: "Focus",
        price: 9000,
        year: 2018,
        match: 70,
      },
      {
        id: "v4",
        title: "2021 Toyota Corolla",
        make: "Toyota",
        model: "Corolla",
        price: 16_000,
        year: 2021,
        match: 95,
      },
    ],
  };
});

beforeEach(() => {
  vi.resetModules();
  vi.restoreAllMocks();
  postMock = vi.fn();
  // clear env between tests
  process.env.SEARCH_SERVICE_URL = undefined;
  process.env.USE_MOCK_SEARCH = undefined;
});

afterEach(() => {
  process.env.SEARCH_SERVICE_URL = undefined;
  process.env.USE_MOCK_SEARCH = undefined;
});

describe("search.service - mock mode behavior", () => {
  it("returns filtered, sorted and paginated results in mock mode", async () => {
    process.env.USE_MOCK_SEARCH = "true";

    // Make shuffle deterministic
    vi.spyOn(Math, "random").mockImplementation(() => 0.42);

    const { searchVehicles } = await import("../search.service");

    const query = {
      query: "Toyota",
      page: 1,
      pageSize: 10,
      sortBy: "price",
      sortOrder: "asc",
    } as any;

    const res = await searchVehicles({ query });

    // All returned vehicles should match the 'Toyota' filter
    expect(
      res.vehicles.every((v: any) => TOYOTA_REGEX.test(v.title) || TOYOTA_REGEX.test(v.make))
    ).toBe(true);

    // Sorted ascending by price — compare the numeric sequence to a sorted copy
    const prices = res.vehicles.map((v: any) => v?.price);
    expect(prices).toEqual([...prices].sort((a, b) => a - b));

    expect(res.pagination.page).toBe(1);
    expect(res.pagination.pageSize).toBe(10);
    expect(res.pagination.totalResults).toBeGreaterThanOrEqual(res.vehicles.length);
  });

  it("applies numeric filters and pagination correctly", async () => {
    process.env.USE_MOCK_SEARCH = "true";
    vi.spyOn(Math, "random").mockImplementation(() => 0.1);

    const { searchVehicles } = await import("../search.service");

    const query = {
      query: "",
      priceMin: 10_000,
      priceMax: 15_500,
      yearMin: 2018,
      yearMax: 2020,
      page: 2,
      pageSize: 1,
      sortBy: "match",
      sortOrder: "desc",
    } as any;

    const res = await searchVehicles({ query });

    // Page 2 with pageSize 1 should return exactly 1 vehicle (when results allow)
    expect(res.vehicles.length).toBeLessThanOrEqual(1);
    expect(res.pagination.page).toBe(2);
    expect(typeof res.pagination.totalResults).toBe("number");
  });
});

describe("search.service - upstream (BED) behavior", () => {
  it("forwards query and headers to the server client and returns result", async () => {
    process.env.SEARCH_SERVICE_URL = "https://bed.example";

    const fakeResult = {
      vehicles: [{ id: "u1" }],
      pagination: { page: 1, pageSize: SEARCH_PAGE_SIZE, totalResults: 1, totalPages: 1 },
    };
    postMock = vi.fn().mockResolvedValue(fakeResult);

    const { searchVehicles } = await import("../search.service");

    const q = { query: "x", page: 1 } as any;
    const ids = { visitorId: "v" } as any;
    const headers = { "x-forward": "1" } as any;

    const res = await searchVehicles({ query: q, ids, forwardHeaders: headers });

    expect(res).toEqual(fakeResult);
    expect(postMock).toHaveBeenCalledTimes(1);
    expect(postMock).toHaveBeenCalledWith("/vehicles/search", q, { ids, headers });
  });

  it("returns empty results on ArrowServerError and logs gracefully", async () => {
    process.env.SEARCH_SERVICE_URL = "https://bed.example";
    postMock = vi.fn().mockRejectedValue(new MockArrowServerError("service down"));

    const { searchVehicles } = await import("../search.service");

    const q = {} as any;
    const res = await searchVehicles({ query: q });

    expect(res.vehicles).toEqual([]);
    expect(res.pagination.totalResults).toBe(0);
    expect(res.pagination.page).toBe(1);
  });

  it("returns empty results on unexpected errors", async () => {
    process.env.SEARCH_SERVICE_URL = "https://bed.example";
    postMock = vi.fn().mockRejectedValue(new Error("boom"));

    const { searchVehicles } = await import("../search.service");

    const q = { page: 3, pageSize: 5 } as any;
    const res = await searchVehicles({ query: q });

    expect(res.vehicles).toEqual([]);
    expect(res.pagination.page).toBe(3);
    expect(res.pagination.pageSize).toBe(5);
    expect(res.pagination.totalResults).toBe(0);
  });
});
