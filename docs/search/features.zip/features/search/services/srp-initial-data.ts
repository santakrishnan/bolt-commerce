import { defaultFilterState } from "@features/search/components/filter-sidebar/types";
import { runMockFacetedSearch } from "@features/search/lib/mock-faceted-search";
import type { SearchResponse } from "@features/search/lib/search-types";
import { cacheLife, cacheTag } from "next/cache";

// Fetch initial SRP results
export async function fetchInitialSrpResults(
  bodyType?: string,
  searchQuery?: string
): Promise<SearchResponse> {
  "use cache";
  cacheLife("srp");
  cacheTag("srp", bodyType ? `srp-${bodyType}` : "srp-all");

  const filterState = {
    ...defaultFilterState,
    ...(bodyType ? { selectedBodyStyles: [bodyType] } : {}),
  };

  return await runMockFacetedSearch({
    filterState,
    searchQuery: searchQuery ?? "",
    page: 1,
    pageSize: 20,
    includeFacets: false,
    sortOption: "recommended",
  });
}
