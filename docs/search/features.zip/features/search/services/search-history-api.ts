import { API_ROUTES } from "@config/routes/constants";
import type { SearchEntry } from "@shared/lib/saved-registry/types";

export type { SearchEntry } from "@shared/lib/saved-registry/types";

async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    credentials: "include",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...init?.headers,
    },
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error ?? `Request failed: ${res.status}`);
  }

  const { data } = await res.json();
  return data as T;
}

// Retrieve all search entries
export function getAllSearchHistory(): Promise<SearchEntry[]> {
  return fetchJson<SearchEntry[]>(API_ROUTES.SEARCH_HISTORY);
}

// Add a search entry
export function addSearchEntry(
  query: string,
  url: string,
  type: "nlp" | "filter" = "nlp"
): Promise<SearchEntry[]> {
  return fetchJson<SearchEntry[]>(API_ROUTES.SEARCH_HISTORY, {
    method: "POST",
    body: JSON.stringify({ query, url, type }),
  });
}

// Remove a search entry by id
export function removeSearchEntry(id: string): Promise<SearchEntry[]> {
  return fetchJson<SearchEntry[]>(`${API_ROUTES.SEARCH_HISTORY}/${encodeURIComponent(id)}`, {
    method: "DELETE",
  });
}

// Clear all search history
export function clearSearchHistory(): Promise<SearchEntry[]> {
  return fetchJson<SearchEntry[]>(API_ROUTES.SEARCH_HISTORY, {
    method: "DELETE",
  });
}
