/**
 * Sample user credentials for Phase 0 (development / prototyping only).
 *
 * These credentials are NEVER used in production. In Phase 1, real users will
 * be sourced from a database via Auth0.
 *
 * To add or change dev users, edit this file. The auth module seeds these users
 * into the in-memory store on startup.
 */

export type SampleUser = {
  /** Stable ID used as the user's `id` in the memory store */
  id: string;
  name: string;
  email: string;
  /** Plain-text password — only acceptable because this is a dev-only fixture */
  password: string;
  role: "admin" | "user";
};

export const SAMPLE_USERS: SampleUser[] = [
  {
    id: "usr_alice",
    name: "Alice Demo",
    email: "alice@example.com",
    password: "Demo@1234",
    role: "admin",
  },
  {
    id: "usr_bob",
    name: "Bob Demo",
    email: "bob@example.com",
    password: "Demo@1234",
    role: "user",
  },
];
