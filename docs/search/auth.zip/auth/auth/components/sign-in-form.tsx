"use client";

import { Button, Input } from "@tfs-ucmp/ui";
import { useRouter } from "next/navigation";
import { type FormEvent, useState } from "react";

import { authClient } from "../lib/auth-client";

type FormState = {
  email: string;
  password: string;
};

type SubmitState =
  | { status: "idle" }
  | { status: "loading" }
  | { status: "error"; message: string };

export function SignInForm() {
  const router = useRouter();

  const [form, setForm] = useState<FormState>({ email: "", password: "" });
  const [submit, setSubmit] = useState<SubmitState>({ status: "idle" });

  const isLoading = submit.status === "loading";

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmit({ status: "loading" });

    const { error } = await authClient.signIn.email({
      email: form.email,
      password: form.password,
    });

    if (error) {
      setSubmit({ status: "error", message: error.message ?? "Sign in failed. Please try again." });
      return;
    }

    router.push("/my-garage");
    router.refresh();
  }

  return (
    <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
      <div className="flex flex-col gap-1.5">
        <label className="text-sm font-medium text-foreground" htmlFor="email">
          Email
        </label>
        <Input
          autoComplete="email"
          disabled={isLoading}
          id="email"
          onChange={(e) => setForm((prev) => ({ ...prev, email: e.target.value }))}
          placeholder="you@example.com"
          required
          type="email"
          value={form.email}
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <label className="text-sm font-medium text-foreground" htmlFor="password">
          Password
        </label>
        <Input
          autoComplete="current-password"
          disabled={isLoading}
          id="password"
          onChange={(e) => setForm((prev) => ({ ...prev, password: e.target.value }))}
          placeholder="••••••••"
          required
          type="password"
          value={form.password}
        />
      </div>

      {submit.status === "error" && (
        <p aria-live="polite" className="text-sm text-red-600" role="alert">
          {submit.message}
        </p>
      )}

      <Button className="w-full" disabled={isLoading} type="submit">
        {isLoading ? "Signing in…" : "Sign in"}
      </Button>
    </form>
  );
}
