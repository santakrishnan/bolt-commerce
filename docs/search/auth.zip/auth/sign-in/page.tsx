import { SignInForm } from "@features/auth/components/sign-in-form";

export const metadata = {
  title: "Sign In — Arrow",
};

export default function SignInPage() {
  return (
    <main className="flex flex-1 items-center justify-center px-4 py-16">
      <div className="w-full max-w-sm">
        <h1 className="mb-2 font-semibold text-2xl text-foreground">Welcome back</h1>
        <p className="mb-8 text-muted-foreground text-sm">Sign in to your Arrow account.</p>

        <SignInForm />

        {process.env.NODE_ENV !== "production" && (
          <div className="mt-8 rounded-md border border-amber-200 bg-amber-50 p-4">
            <p className="mb-2 font-medium text-amber-800 text-xs uppercase tracking-wide">
              Dev credentials (Phase 0)
            </p>
            <ul className="space-y-1 text-amber-700 text-xs">
              <li>alice@example.com / Demo@1234</li>
              <li>bob@example.com / Demo@1234</li>
            </ul>
          </div>
        )}
      </div>
    </main>
  );
}
