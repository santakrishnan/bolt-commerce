# Hero Background Images

## Folder Structure

```
heroes/
├── regions/           # Regional background images (shared by multiple states)
│   ├── southwest/
│   │   ├── desktop.png
│   │   └── mobile.png
│   ├── southeast/
│   │   ├── desktop.png
│   │   └── mobile.png
│   └── west/
│       ├── desktop.png
│       └── mobile.png
└── states/            # State-specific background images (future)
    └── TX/            # Example: Texas-specific images
        ├── desktop.png
        └── mobile.png
```

## Current Regional Assignments

### Southwest Region
States: TX, AZ, CO, NM, OK, NV, UT, IA, KS, MN, MO, NE, ND, SD, WI, WY

### Southeast Region
States: FL, AL, AR, CT, DE, GA, IL, IN, KY, LA, ME, MD, MA, MI, MS, NH, NJ, NY, NC, OH, PA, RI, SC, TN, VA, VT, WV, DC

### West Region
States: CA, AK, HI, ID, MT, OR, WA

## Adding State-Specific Images

When you have a state-specific image:

1. Create a folder in `states/` with the state code (e.g., `TX/`)
2. Add `desktop.png` and `mobile.png` to that folder
3. Update `apps/web/src/data/state-hero-config.json`:
   - Add new entry to `backgroundImages`:
     ```json
     "TX": {
       "desktop": "/images/heroes/states/TX/desktop.png",
       "mobile": "/images/heroes/states/TX/mobile.png"
     }
     ```
   - Update the state's `backgroundImageKey` from `"southwest"` to `"TX"`

## Image Specifications

- **Desktop**: 1920x1080 minimum (16:9 aspect ratio)
- **Mobile**: 750x1334 minimum (portrait orientation)
- **Format**: PNG or JPG
- **Size**: Optimized for web (< 500KB recommended)
- **Content**: Good contrast for text overlay
