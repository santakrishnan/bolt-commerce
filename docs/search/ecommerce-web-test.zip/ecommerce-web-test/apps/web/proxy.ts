import { type NextRequest, NextResponse } from "next/server";

export const CSP_POLICY = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "font-src 'self'",
  "connect-src 'self' https://*.fpjs.io https://fpnpmcdn.net",
  "frame-ancestors 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
].join("; ");

export function proxy(_request: NextRequest) {
  // Clone the response
  const response = NextResponse.next();

  // Add security headers
  response.headers.set("Content-Security-Policy", CSP_POLICY);
  response.headers.set("X-DNS-Prefetch-Control", "on");
  response.headers.set("Strict-Transport-Security", "max-age=63072000; includeSubDomains; preload");
  response.headers.set("X-Frame-Options", "SAMEORIGIN");
  response.headers.set("X-Content-Type-Options", "nosniff");
  response.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  response.headers.set(
    "Permissions-Policy",
    "camera=(), microphone=(), geolocation=(), interest-cohort=()"
  );

  // Example: Redirect to HTTPS in production
  // if (process.env.NODE_ENV === 'production' && request.nextUrl.protocol === 'http:') {
  //   return NextResponse.redirect(
  //     `https://${request.nextUrl.hostname}${request.nextUrl.pathname}${request.nextUrl.search}`,
  //     { status: 301 }
  //   )
  // }

  return response;
}
