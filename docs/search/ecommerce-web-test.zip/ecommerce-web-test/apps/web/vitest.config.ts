import path from "node:path";
import nextjsConfig from "@arrow/vitest-config/nextjs";
import { defineConfig, mergeConfig } from "vitest/config";

export default defineConfig(
  mergeConfig(nextjsConfig, {
    test: {
      name: "web",
      environment: "jsdom",
      globals: true,
      coverage: {
        provider: "v8",
        reporter: ["text", "html"],
        exclude: [
          "**/*.d.ts",
          "**/*.types.ts",
          "**/types.ts",
          "**/index.ts",
          "**/*/index.ts",
          "**/constants.ts",
          "**/config/**",
          "**/generated/**",
          "**/__mocks__/**",
          "**/fixtures/**",
          "**/*.stories.tsx",
          "**/setupTests.ts",
          "**/main.ts",
          "**/app/fingerprint-test/**",
          "**/app/tracking-demo/**",
        ],
      },
    },
    server: {
      // Allow Vite to load files from parent directories (monorepo packages)
      fs: {
        allow: ["../.."],
      },
    },
    resolve: {
      alias: [
        // More-specific aliases must come before the catch-all "@" alias
        { find: "@features", replacement: path.resolve(import.meta.dirname, "./src/features") },
        { find: "@shared", replacement: path.resolve(import.meta.dirname, "./src/shared") },
        { find: "@config", replacement: path.resolve(import.meta.dirname, "./src/config") },
        { find: "@layout", replacement: path.resolve(import.meta.dirname, "./src/layout") },
        {
          find: "utils",
          replacement: path.resolve(import.meta.dirname, "../../packages/utils/src"),
        },
        { find: "~", replacement: path.resolve(import.meta.dirname, "./src") },
        // "@" must be last: maps "@/foo" → packages/ui/src/foo (used for shadcn imports)
        {
          find: /^@\/(.*)/,
          replacement: path.resolve(import.meta.dirname, "../../packages/ui/src/$1"),
        },
      ],
    },
  })
);
