import { render, screen, within } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { FooterNavigationMobile } from "../footer-navigation-mobile";

vi.mock("@tfs-ucmp/ui", () => ({
  Accordion: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="accordion">{children}</div>
  ),
  AccordionItem: ({ children, value }: { children: React.ReactNode; value: string }) => (
    <div data-testid="accordion-item" data-value={value}>
      {children}
    </div>
  ),
  AccordionTrigger: ({ children }: { children: React.ReactNode }) => (
    <button data-testid="accordion-trigger" type="button">
      {children}
    </button>
  ),
  AccordionContent: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="accordion-content">{children}</div>
  ),
}));

const STANDARD_SECTIONS = [
  {
    title: "Shop",
    links: [
      { label: "Buy a Car", href: "/buy" },
      { label: "Finance Options", href: "/finance" },
      { label: "Trade-In Value", href: "/trade-in" },
    ],
  },
  {
    title: "Support",
    links: [
      { label: "Contact Us", href: "/contact" },
      { label: "External Help", href: "https://help.example.com", external: true },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy Policy", href: "/privacy" },
      { label: "External Portal", href: "https://legal.example.com", external: true },
    ],
  },
];

const TOTAL_LINKS = STANDARD_SECTIONS.reduce((sum, s) => sum + s.links.length, 0);

function getAt<T>(arr: T[], i: number): T {
  const item = arr[i];
  if (item === undefined) {
    throw new Error(`No element at index ${i}`);
  }
  return item;
}

describe("FooterNavigationMobile", () => {
  describe("accordion structure", () => {
    it("renders a single accordion root element", () => {
      render(<FooterNavigationMobile sections={STANDARD_SECTIONS} />);

      expect(screen.getByTestId("accordion")).toBeInTheDocument();
    });

    it("renders exactly one accordion item per section", () => {
      render(<FooterNavigationMobile sections={STANDARD_SECTIONS} />);

      expect(screen.getAllByTestId("accordion-item")).toHaveLength(STANDARD_SECTIONS.length);
    });

    it("assigns value='section-{index}' to each accordion item", () => {
      render(<FooterNavigationMobile sections={STANDARD_SECTIONS} />);

      const items = screen.getAllByTestId("accordion-item");
      items.forEach((item, index) => {
        expect(item).toHaveAttribute("data-value", `section-${index}`);
      });
    });

    it("renders section titles inside accordion triggers", () => {
      render(<FooterNavigationMobile sections={STANDARD_SECTIONS} />);

      const triggers = screen.getAllByTestId("accordion-trigger");
      expect(triggers).toHaveLength(STANDARD_SECTIONS.length);

      STANDARD_SECTIONS.forEach((section, i) => {
        expect(within(getAt(triggers, i)).getByText(section.title)).toBeInTheDocument();
      });
    });

    it("renders exactly one accordion content block per section", () => {
      render(<FooterNavigationMobile sections={STANDARD_SECTIONS} />);

      expect(screen.getAllByTestId("accordion-content")).toHaveLength(STANDARD_SECTIONS.length);
    });
  });

  describe("section and link rendering", () => {
    it("renders all section titles", () => {
      render(<FooterNavigationMobile sections={STANDARD_SECTIONS} />);

      for (const section of STANDARD_SECTIONS) {
        expect(screen.getByText(section.title)).toBeInTheDocument();
      }
    });

    it("renders all link labels", () => {
      render(<FooterNavigationMobile sections={STANDARD_SECTIONS} />);

      for (const section of STANDARD_SECTIONS) {
        for (const link of section.links) {
          expect(screen.getByText(link.label)).toBeInTheDocument();
        }
      }
    });

    it("renders the correct total number of anchor elements", () => {
      render(<FooterNavigationMobile sections={STANDARD_SECTIONS} />);

      expect(screen.getAllByRole("link")).toHaveLength(TOTAL_LINKS);
    });

    it("scopes each section's links inside its own content block", () => {
      render(<FooterNavigationMobile sections={STANDARD_SECTIONS} />);

      const contentBlocks = screen.getAllByTestId("accordion-content");

      STANDARD_SECTIONS.forEach((section, i) => {
        const block = getAt(contentBlocks, i);
        for (const link of section.links) {
          expect(within(block).getByText(link.label)).toBeInTheDocument();
        }
      });
    });
  });

  describe("link href attributes", () => {
    it("gives every link the correct href from the sections prop", () => {
      render(<FooterNavigationMobile sections={STANDARD_SECTIONS} />);

      for (const section of STANDARD_SECTIONS) {
        for (const link of section.links) {
          const anchor = screen.getByRole("link", { name: link.label });
          expect(anchor).toHaveAttribute("href", link.href);
        }
      }
    });
  });

  describe("external links", () => {
    it("opens external links in a new tab via target='_blank'", () => {
      render(<FooterNavigationMobile sections={STANDARD_SECTIONS} />);

      const externalLinks = STANDARD_SECTIONS.flatMap((s) =>
        s.links.filter((l) => l.external === true)
      );
      expect(externalLinks.length).toBeGreaterThan(0);

      for (const link of externalLinks) {
        expect(screen.getByRole("link", { name: link.label })).toHaveAttribute("target", "_blank");
      }
    });

    it("adds rel='noopener noreferrer' to external links", () => {
      render(<FooterNavigationMobile sections={STANDARD_SECTIONS} />);

      const externalLinks = STANDARD_SECTIONS.flatMap((s) =>
        s.links.filter((l) => l.external === true)
      );

      for (const link of externalLinks) {
        expect(screen.getByRole("link", { name: link.label })).toHaveAttribute(
          "rel",
          "noopener noreferrer"
        );
      }
    });
  });

  describe("internal links", () => {
    it("does not add target attribute to internal links", () => {
      render(<FooterNavigationMobile sections={STANDARD_SECTIONS} />);

      const internalLinks = STANDARD_SECTIONS.flatMap((s) => s.links.filter((l) => !l.external));
      expect(internalLinks.length).toBeGreaterThan(0);

      for (const link of internalLinks) {
        expect(screen.getByRole("link", { name: link.label })).not.toHaveAttribute("target");
      }
    });

    it("does not add rel attribute to internal links", () => {
      render(<FooterNavigationMobile sections={STANDARD_SECTIONS} />);

      const internalLinks = STANDARD_SECTIONS.flatMap((s) => s.links.filter((l) => !l.external));

      for (const link of internalLinks) {
        expect(screen.getByRole("link", { name: link.label })).not.toHaveAttribute("rel");
      }
    });
  });

  describe("edge cases", () => {
    it("renders no items when sections prop is an empty array", () => {
      render(<FooterNavigationMobile sections={[]} />);

      expect(screen.queryAllByTestId("accordion-item")).toHaveLength(0);
      expect(screen.queryAllByRole("link")).toHaveLength(0);
    });

    it("renders a section header without links when the links array is empty", () => {
      render(<FooterNavigationMobile sections={[{ title: "Empty Section", links: [] }]} />);

      expect(screen.getByText("Empty Section")).toBeInTheDocument();
      expect(screen.queryAllByRole("link")).toHaveLength(0);
    });

    it("renders a single section with a single link correctly", () => {
      render(
        <FooterNavigationMobile
          sections={[{ title: "Solo", links: [{ label: "Only Link", href: "/only" }] }]}
        />
      );

      expect(screen.getByText("Solo")).toBeInTheDocument();
      expect(screen.getByRole("link", { name: "Only Link" })).toHaveAttribute("href", "/only");
    });

    it("handles a large number of sections without errors", () => {
      const manySections = Array.from({ length: 20 }, (_, i) => ({
        title: `Section ${i + 1}`,
        links: [{ label: `Link ${i + 1}`, href: `/path-${i + 1}` }],
      }));

      render(<FooterNavigationMobile sections={manySections} />);

      expect(screen.getAllByTestId("accordion-item")).toHaveLength(20);
      expect(screen.getAllByRole("link")).toHaveLength(20);
    });

    it("renders a mix of external and internal links in the same section", () => {
      const sections = [
        {
          title: "Mixed",
          links: [
            { label: "Internal", href: "/internal" },
            { label: "External", href: "https://external.com", external: true },
          ],
        },
      ];

      render(<FooterNavigationMobile sections={sections} />);

      const internal = screen.getByRole("link", { name: "Internal" });
      const external = screen.getByRole("link", { name: "External" });

      expect(internal).not.toHaveAttribute("target");
      expect(internal).not.toHaveAttribute("rel");
      expect(external).toHaveAttribute("target", "_blank");
      expect(external).toHaveAttribute("rel", "noopener noreferrer");
    });

    it("preserves section order from the sections prop", () => {
      const ordered = [
        { title: "First", links: [{ label: "Link A", href: "/a" }] },
        { title: "Second", links: [{ label: "Link B", href: "/b" }] },
        { title: "Third", links: [{ label: "Link C", href: "/c" }] },
      ];

      render(<FooterNavigationMobile sections={ordered} />);

      const triggers = screen.getAllByTestId("accordion-trigger");
      expect(within(getAt(triggers, 0)).getByText("First")).toBeInTheDocument();
      expect(within(getAt(triggers, 1)).getByText("Second")).toBeInTheDocument();
      expect(within(getAt(triggers, 2)).getByText("Third")).toBeInTheDocument();
    });

    it("assigns correct section-index values when sections are re-ordered", () => {
      const sections = [
        { title: "Z Section", links: [] },
        { title: "A Section", links: [] },
      ];

      render(<FooterNavigationMobile sections={sections} />);

      const items = screen.getAllByTestId("accordion-item");
      expect(items[0]).toHaveAttribute("data-value", "section-0");
      expect(items[1]).toHaveAttribute("data-value", "section-1");
    });

    it("a section with only external links has no internal-link side effects", () => {
      const sections = [
        {
          title: "All External",
          links: [
            { label: "Ext A", href: "https://a.com", external: true },
            { label: "Ext B", href: "https://b.com", external: true },
          ],
        },
      ];

      render(<FooterNavigationMobile sections={sections} />);

      const links = screen.getAllByRole("link");
      expect(links).toHaveLength(2);
      for (const link of links) {
        expect(link).toHaveAttribute("target", "_blank");
        expect(link).toHaveAttribute("rel", "noopener noreferrer");
      }
    });

    it("a section with only internal links has no external-link side effects", () => {
      const sections = [
        {
          title: "All Internal",
          links: [
            { label: "Int A", href: "/a" },
            { label: "Int B", href: "/b" },
          ],
        },
      ];

      render(<FooterNavigationMobile sections={sections} />);

      const links = screen.getAllByRole("link");
      expect(links).toHaveLength(2);
      for (const link of links) {
        expect(link).not.toHaveAttribute("target");
        expect(link).not.toHaveAttribute("rel");
      }
    });
  });
});
