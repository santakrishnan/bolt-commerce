"use client";

import { ROUTES } from "@config/routes/constants";
import { authClient } from "@features/auth/lib/auth-client";
import { resetFeatureFlagProfileToDefault } from "@features/auth/lib/feature-flag-profile";
import { Button } from "@tfs-ucmp/ui";
import Image from "next/image";
import Link from "next/link";
import { createPortal } from "react-dom";
import { ACCOUNT_ITEMS } from "./constants";

interface DesktopAccountMenuProps {
  onClose: () => void;
}

export function DesktopAccountMenu({ onClose }: DesktopAccountMenuProps) {
  const handleLogout = async () => {
    try {
      await authClient.signOut();
    } catch {
      // Best-effort sign out for development fixtures.
    } finally {
      resetFeatureFlagProfileToDefault();
      onClose();
      window.location.assign(ROUTES.HOME);
    }
  };

  return (
    <>
      {createPortal(
        <div
          aria-hidden="true"
          className="fixed inset-0 z-34 hidden bg-black/40 lg:block"
          onClick={onClose}
        />,
        document.body
      )}

      <div className="absolute top-full right-0 z-50 mt-[var(--spacing-10)] hidden w-97.5 animate-[menuSlideIn_0.2s_ease-out_forwards] rounded-[var(--radius-md)] border border-[var(--color-divider)] bg-[var(--color-surface)] shadow-[var(--shadow-lg)] lg:block">
        {/* Triangle pointer */}
        <div className="pointer-events-none absolute -top-[var(--spacing-sd)] right-[var(--spacing-lg)]">
          <div className="border-r-[12px] border-r-transparent border-b-[16px] border-b-[var(--color-surface)] border-l-[12px] border-l-transparent" />
        </div>

        <div className="flex flex-col gap-[var(--spacing-xs)] p-[var(--spacing-xs)]">
          {/* Items */}
          <ul className="flex flex-col">
            {ACCOUNT_ITEMS.map((item) => (
              <li key={item.label}>
                {item.action === "logout" ? (
                  <Button
                    className="group flex h-auto w-full flex-row items-center justify-start gap-2 rounded-sm px-[var(--spacing-2xs)] py-[var(--spacing-sm)] hover:bg-[var(--color-background-lighter)]"
                    onClick={handleLogout}
                    variant="ghost"
                  >
                    <Image
                      alt="Logout icon"
                      aria-hidden="true"
                      height={16}
                      src={item.icon}
                      style={{ height: "var(--size-icon-sm)", width: "var(--size-icon-sm)" }}
                      width={16}
                    />
                    <span className="font-normal text-[length:var(--text-sm)] text-[var(--color-muted-foreground)] leading-tight tracking-wider group-hover:font-[var(--font-weight-semibold)] group-hover:text-[var(--color-foreground)]">
                      {item.label}
                    </span>
                  </Button>
                ) : (
                  <Link
                    className="group flex flex-row items-center gap-2 rounded-sm px-[var(--spacing-2xs)] py-[var(--spacing-sm)] hover:bg-[var(--color-background-lighter)]"
                    href={item.href}
                    onClick={onClose}
                  >
                    <Image
                      alt=""
                      aria-hidden="true"
                      height={16}
                      src={item.icon}
                      style={{ height: "var(--size-icon-sm)", width: "var(--size-icon-sm)" }}
                      width={16}
                    />
                    <span className="font-normal text-[length:var(--text-sm)] text-[var(--color-muted-foreground)] leading-tight tracking-wider group-hover:font-[var(--font-weight-semibold)] group-hover:text-[var(--color-foreground)]">
                      {item.label}
                    </span>
                  </Link>
                )}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </>
  );
}
