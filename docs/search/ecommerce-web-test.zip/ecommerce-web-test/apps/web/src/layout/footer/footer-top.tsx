import type { SocialIcon } from "@shared/data/footer/footer-links";
import Image from "next/image";
import Link from "next/link";

const iconMap = {
  facebook: "/images/footer/icon-facebook.svg",
  twitter: "/images/footer/icon-twitter.svg",
  instagram: "/images/footer/icon-instagram.svg",
  youtube: "/images/footer/icon-youtube.svg",
} satisfies Record<SocialIcon, string>;

interface FooterTopSocialLink {
  href: string;
  icon: string;
  label: string;
}

interface FooterTopProps {
  brandName: string;
  socialLinks: readonly FooterTopSocialLink[];
  tagline: string;
}

/**
 * FooterTop - Brand section with social media links
 * Server Component — static brand section with social links
 */
export function FooterTop({ brandName, socialLinks, tagline }: FooterTopProps) {
  return (
    <div>
      <div className="mb-4">
        <h2 className="mb-4 font-bold font-toyota text-[var(--actions-accent)] text-xl leading-6">
          {brandName}
        </h2>
        <p className="font-normal font-toyota text-[var(--color-states-muted)] text-sm leading-5">
          {tagline}
        </p>
      </div>

      <div className="flex items-center justify-around">
        {socialLinks.map((link) => {
          const iconSrc = iconMap[link.icon as keyof typeof iconMap] ?? "";
          return (
            <Link
              aria-label={link.label}
              className="text-[var(--core-surfaces-inverse-foreground)] transition-colors hover:text-[var(--core-surfaces-inverse-foreground)]/80"
              href={link.href}
              key={`${link.href}-${link.icon}`}
              rel="noopener noreferrer"
              target="_blank"
            >
              <Image alt={link.label} height={24} src={iconSrc} width={24} />
            </Link>
          );
        })}
      </div>
    </div>
  );
}
