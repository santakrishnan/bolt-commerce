import { ROUTES } from "@config/routes/constants";
import { Button, UserIcon } from "@tfs-ucmp/ui";
import Link from "next/link";
import { cn } from "@/lib/utils";

export const SignInButton = ({ useSolidStyles }: { useSolidStyles: boolean }) => (
  <Button
    asChild
    className={cn(
      "h-10 gap-[var(--spacing-2xs)] rounded-full border px-4 transition-colors",
      useSolidStyles
        ? "border-border-light bg-white text-[var(--Core-surfaces-card-foreground)] hover:bg-gray-50"
        : "border-white/30 bg-transparent text-inverse-foreground hover:bg-white/10"
    )}
  >
    <Link href={ROUTES.SIGN_IN}>
      <UserIcon
        className={cn(
          "h-4.5 w-4.5 transition-colors",
          useSolidStyles ? "text-actions-primary" : "text-white"
        )}
      />
      <span className="font-semibold text-[length:var(--font-size-sm)]">Sign In</span>
    </Link>
  </Button>
);

interface AvatarButtonProps {
  firstName: string;
  isOpen?: boolean;
  onClick?: () => void;
  useSolidStyles?: boolean;
}

export const AvatarButton = ({
  firstName,
  useSolidStyles = true,
  onClick,
  isOpen,
}: AvatarButtonProps) => {
  const initial = firstName.charAt(0).toUpperCase();
  const displayName = firstName.length > 6 ? `${firstName.slice(0, 6)}...` : firstName;

  const sharedClassName = cn(
    "flex h-10 items-center gap-[var(--spacing-2xs)] rounded-full border px-3 transition-colors lg:h-9",
    useSolidStyles ? "border-border-light hover:bg-gray-50" : "border-white/30 hover:bg-white/10"
  );

  const content = (
    <>
      <div className="flex h-4.5 w-4.5 items-center justify-center rounded-full bg-actions-primary font-semibold text-sm text-white">
        {initial}
      </div>
      <span
        className={cn(
          "hidden text-sm lg:block",
          useSolidStyles ? "text-[var(--Core-surfaces-card-foreground)]" : "text-inverse-foreground"
        )}
      >
        {displayName}
      </span>
    </>
  );

  if (onClick) {
    return (
      <Button
        className={cn(
          sharedClassName,
          isOpen && "bg-gray-50",
          useSolidStyles ? "bg-white" : "bg-transparent"
        )}
        onClick={onClick}
        variant="search"
      >
        {content}
      </Button>
    );
  }

  return (
    <Link className={sharedClassName} href={ROUTES.MY_GARAGE}>
      {content}
    </Link>
  );
};

interface MobileUserButtonProps {
  firstName: string;
  showAvatar: boolean;
  useSolidStyles: boolean;
}

export const MobileUserButton = ({
  showAvatar,
  firstName,
  useSolidStyles,
}: MobileUserButtonProps) => {
  if (showAvatar) {
    return (
      <Link
        aria-label="User profile"
        className={cn(
          "flex h-10 w-10 items-center justify-center rounded-full border transition-colors",
          useSolidStyles
            ? "border-border-light hover:bg-muted"
            : "border-overlay hover:bg-background-overlay-hover"
        )}
        href={ROUTES.MY_GARAGE}
      >
        <div className="flex h-6 w-6 items-center justify-center rounded-full bg-icon-primary font-semibold text-sm text-white leading-[.15] tracking-normal">
          {firstName.charAt(0).toUpperCase()}
        </div>
      </Link>
    );
  }

  return (
    <Button
      asChild
      className={cn(
        "h-10 w-10 rounded-full border transition-colors",
        useSolidStyles
          ? "border-border-light hover:bg-muted"
          : "border-overlay hover:bg-background-overlay-hover"
      )}
      size="icon"
      variant="ghost"
    >
      <Link aria-label="Sign in" href={ROUTES.SIGN_IN}>
        <UserIcon
          className={cn(
            "h-5 w-5 transition-colors",
            useSolidStyles ? "text-icon-primary" : "text-[var(--color-surface)] lg:text-white"
          )}
        />
      </Link>
    </Button>
  );
};
