import { render, screen, within } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { FooterNavMobile } from "../footer-nav-mobile";

const sectionsRef = vi.hoisted(() => ({
  current: [] as Array<{
    title: string;
    links: Array<{ label: string; href: string; external?: boolean }>;
  }>,
}));

vi.mock("@shared/data/footer/footer-links", () => ({
  get footerSections() {
    return sectionsRef.current;
  },
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Accordion: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="accordion">{children}</div>
  ),
  AccordionItem: ({ children, value }: { children: React.ReactNode; value: string }) => (
    <div data-testid="accordion-item" data-value={value}>
      {children}
    </div>
  ),
  AccordionTrigger: ({ children }: { children: React.ReactNode }) => (
    <button data-testid="accordion-trigger" type="button">
      {children}
    </button>
  ),
  AccordionContent: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="accordion-content">{children}</div>
  ),
}));

const STANDARD_SECTIONS = [
  {
    title: "Shop",
    links: [
      { label: "Buy a Car", href: "/buy" },
      { label: "Finance Options", href: "/finance" },
      { label: "Trade-In Value", href: "/trade-in" },
    ],
  },
  {
    title: "Support",
    links: [
      { label: "Contact Us", href: "/contact" },
      { label: "External Help", href: "https://help.example.com", external: true },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy Policy", href: "/privacy" },
      { label: "External Portal", href: "https://legal.example.com", external: true },
    ],
  },
];

const TOTAL_LINKS = STANDARD_SECTIONS.reduce((sum, s) => sum + s.links.length, 0);

function getAt<T>(arr: T[], i: number): T {
  const item = arr[i];
  if (item === undefined) {
    throw new Error(`No element at index ${i}`);
  }
  return item;
}

describe("FooterNavMobile", () => {
  beforeEach(() => {
    sectionsRef.current = STANDARD_SECTIONS;
  });

  describe("accordion structure", () => {
    it("renders a single accordion root element", () => {
      render(<FooterNavMobile />);

      expect(screen.getByTestId("accordion")).toBeInTheDocument();
    });

    it("renders exactly one accordion item per section", () => {
      render(<FooterNavMobile />);

      const items = screen.getAllByTestId("accordion-item");
      expect(items).toHaveLength(STANDARD_SECTIONS.length);
    });

    it("assigns value='section-{index}' to each accordion item", () => {
      render(<FooterNavMobile />);

      const items = screen.getAllByTestId("accordion-item");
      items.forEach((item, index) => {
        expect(item).toHaveAttribute("data-value", `section-${index}`);
      });
    });

    it("renders section titles inside accordion triggers", () => {
      render(<FooterNavMobile />);

      const triggers = screen.getAllByTestId("accordion-trigger");
      expect(triggers).toHaveLength(STANDARD_SECTIONS.length);

      STANDARD_SECTIONS.forEach((section, i) => {
        expect(within(getAt(triggers, i)).getByText(section.title)).toBeInTheDocument();
      });
    });

    it("renders one accordion content block per section", () => {
      render(<FooterNavMobile />);

      expect(screen.getAllByTestId("accordion-content")).toHaveLength(STANDARD_SECTIONS.length);
    });
  });

  describe("section and link rendering", () => {
    it("renders all section titles", () => {
      render(<FooterNavMobile />);

      for (const section of STANDARD_SECTIONS) {
        expect(screen.getByText(section.title)).toBeInTheDocument();
      }
    });

    it("renders all link labels", () => {
      render(<FooterNavMobile />);

      for (const section of STANDARD_SECTIONS) {
        for (const link of section.links) {
          expect(screen.getByText(link.label)).toBeInTheDocument();
        }
      }
    });

    it("renders the correct total number of anchor elements", () => {
      render(<FooterNavMobile />);

      expect(screen.getAllByRole("link")).toHaveLength(TOTAL_LINKS);
    });

    it("scopes each section's links inside its own content block", () => {
      render(<FooterNavMobile />);

      const contentBlocks = screen.getAllByTestId("accordion-content");

      STANDARD_SECTIONS.forEach((section, i) => {
        const block = getAt(contentBlocks, i);
        for (const link of section.links) {
          expect(within(block).getByText(link.label)).toBeInTheDocument();
        }
      });
    });
  });

  describe("link href attributes", () => {
    it("gives every link the correct href from the data source", () => {
      render(<FooterNavMobile />);

      for (const section of STANDARD_SECTIONS) {
        for (const link of section.links) {
          const anchor = screen.getByRole("link", { name: link.label });
          expect(anchor).toHaveAttribute("href", link.href);
        }
      }
    });
  });

  describe("external links", () => {
    it("opens external links in a new tab via target='_blank'", () => {
      render(<FooterNavMobile />);

      const externalLinks = STANDARD_SECTIONS.flatMap((s) =>
        s.links.filter((l) => l.external === true)
      );
      expect(externalLinks.length).toBeGreaterThan(0);

      for (const link of externalLinks) {
        const anchor = screen.getByRole("link", { name: link.label });
        expect(anchor).toHaveAttribute("target", "_blank");
      }
    });

    it("adds rel='noopener noreferrer' to external links", () => {
      render(<FooterNavMobile />);

      const externalLinks = STANDARD_SECTIONS.flatMap((s) =>
        s.links.filter((l) => l.external === true)
      );

      for (const link of externalLinks) {
        const anchor = screen.getByRole("link", { name: link.label });
        expect(anchor).toHaveAttribute("rel", "noopener noreferrer");
      }
    });
  });

  describe("internal links", () => {
    it("does not add target attribute to internal links", () => {
      render(<FooterNavMobile />);

      const internalLinks = STANDARD_SECTIONS.flatMap((s) => s.links.filter((l) => !l.external));
      expect(internalLinks.length).toBeGreaterThan(0);

      for (const link of internalLinks) {
        const anchor = screen.getByRole("link", { name: link.label });
        expect(anchor).not.toHaveAttribute("target");
      }
    });

    it("does not add rel attribute to internal links", () => {
      render(<FooterNavMobile />);

      const internalLinks = STANDARD_SECTIONS.flatMap((s) => s.links.filter((l) => !l.external));

      for (const link of internalLinks) {
        const anchor = screen.getByRole("link", { name: link.label });
        expect(anchor).not.toHaveAttribute("rel");
      }
    });
  });

  describe("edge cases", () => {
    it("renders no items when footerSections is empty", () => {
      sectionsRef.current = [];
      render(<FooterNavMobile />);

      expect(screen.queryAllByTestId("accordion-item")).toHaveLength(0);
      expect(screen.queryAllByRole("link")).toHaveLength(0);
    });

    it("renders a section header without links when the links array is empty", () => {
      sectionsRef.current = [{ title: "Empty Section", links: [] }];
      render(<FooterNavMobile />);

      expect(screen.getByText("Empty Section")).toBeInTheDocument();
      expect(screen.queryAllByRole("link")).toHaveLength(0);
    });

    it("renders a single section with a single link correctly", () => {
      sectionsRef.current = [{ title: "Solo", links: [{ label: "Only Link", href: "/only" }] }];
      render(<FooterNavMobile />);

      expect(screen.getByText("Solo")).toBeInTheDocument();
      expect(screen.getByRole("link", { name: "Only Link" })).toHaveAttribute("href", "/only");
    });

    it("handles a large number of sections without errors", () => {
      const manySections = Array.from({ length: 20 }, (_, i) => ({
        title: `Section ${i + 1}`,
        links: [{ label: `Link ${i + 1}`, href: `/path-${i + 1}` }],
      }));
      sectionsRef.current = manySections;
      render(<FooterNavMobile />);

      expect(screen.getAllByTestId("accordion-item")).toHaveLength(20);
      expect(screen.getAllByRole("link")).toHaveLength(20);
    });

    it("renders a mix of external and internal links in the same section", () => {
      sectionsRef.current = [
        {
          title: "Mixed",
          links: [
            { label: "Internal", href: "/internal" },
            { label: "External", href: "https://external.com", external: true },
          ],
        },
      ];
      render(<FooterNavMobile />);

      const internal = screen.getByRole("link", { name: "Internal" });
      const external = screen.getByRole("link", { name: "External" });

      expect(internal).not.toHaveAttribute("target");
      expect(internal).not.toHaveAttribute("rel");

      expect(external).toHaveAttribute("target", "_blank");
      expect(external).toHaveAttribute("rel", "noopener noreferrer");
    });

    it("preserves section order from the data source", () => {
      const ordered = [
        { title: "First", links: [{ label: "Link A", href: "/a" }] },
        { title: "Second", links: [{ label: "Link B", href: "/b" }] },
        { title: "Third", links: [{ label: "Link C", href: "/c" }] },
      ];
      sectionsRef.current = ordered;
      render(<FooterNavMobile />);

      const triggers = screen.getAllByTestId("accordion-trigger");
      expect(within(getAt(triggers, 0)).getByText("First")).toBeInTheDocument();
      expect(within(getAt(triggers, 1)).getByText("Second")).toBeInTheDocument();
      expect(within(getAt(triggers, 2)).getByText("Third")).toBeInTheDocument();
    });
  });
});
