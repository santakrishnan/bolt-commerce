"use client";

import { ROUTES } from "@config/routes/constants";
import { Button } from "@tfs-ucmp/ui";
import Image from "next/image";
import Link from "next/link";

interface HamburgerMenuProps {
  animFromLeft?: boolean;
  onClose: () => void;
  onMyAccountClick: () => void;
}

const MenuDivider = () => (
  <div className="h-[var(--border-width-1)] w-full shrink-0 bg-[var(--color-divider)]" />
);

const NAV_ITEMS = [
  { label: "Search", href: ROUTES.USED_CARS },
  { label: "Buy", href: ROUTES.USED_CARS },
  { label: "Finance", href: ROUTES.FINANCE },
  { label: "Why Arrow", href: ROUTES.ABOUT },
  { label: "My Account", href: ROUTES.MY_GARAGE },
] as const;

export function HamburgerMenu({
  onClose,
  onMyAccountClick,
  animFromLeft = false,
}: HamburgerMenuProps) {
  const animation = animFromLeft
    ? "menuSlideInFromLeft_0.2s_ease-out_forwards"
    : "menuSlideIn_0.2s_ease-out_forwards";

  return (
    <div className={`absolute top-full right-0 left-0 w-full animate-[${animation}] lg:hidden`}>
      <div className="rounded-br-[var(--radius-md)] rounded-bl-[var(--radius-md)] border-[var(--color-divider)] border-t bg-[var(--color-surface)] px-[var(--spacing-md)] py-[var(--spacing-lg)]">
        <ul className="flex flex-col gap-[var(--spacing-lg)]">
          {NAV_ITEMS.map((item, index) => (
            <li className="flex flex-col gap-[var(--spacing-lg)]" key={item.label}>
              {item.label === "My Account" ? (
                <Button
                  className="flex flex-row items-center justify-between p-0"
                  onClick={onMyAccountClick}
                  variant="search"
                >
                  <span className="font-[var(--font-weight-semibold)] text-[length:var(--text-md)] leading-[115%]">
                    {item.label}
                  </span>
                  <Image
                    alt=""
                    aria-hidden="true"
                    height={24}
                    src="/images/header/chevron_right_red.svg"
                    width={24}
                  />
                </Button>
              ) : (
                <Link
                  className="flex flex-row items-center justify-between"
                  href={item.href}
                  onClick={onClose}
                >
                  <span className="font-[var(--font-weight-semibold)] text-[length:var(--text-md)] leading-[115%]">
                    {item.label}
                  </span>
                  <Image
                    alt=""
                    aria-hidden="true"
                    height={24}
                    src="/images/header/chevron_right_red.svg"
                    width={24}
                  />
                </Link>
              )}
              {index < NAV_ITEMS.length - 1 && <MenuDivider />}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
