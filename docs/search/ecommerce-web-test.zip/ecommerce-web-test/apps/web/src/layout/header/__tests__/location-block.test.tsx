import { fireEvent, render, screen, within } from "@arrow/vitest-config/test-utils";
import type { ReactNode } from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";

const ZIP_90210_RE = /90210/;
const VALID_ZIP_ERROR_RE = /valid 5-digit zip/i;

import { LocationBlock } from "../location-block";

vi.mock("next/image", () => ({
  default: ({
    src,
    alt,
    width,
    height,
    className,
  }: {
    src: string;
    alt: string;
    width?: number;
    height?: number;
    className?: string;
  }) => (
    // biome-ignore lint/performance/noImgElement: test stub — Next/Image internals not needed
    <img
      alt={alt}
      className={className}
      data-testid={src}
      height={height}
      src={src}
      width={width}
    />
  ),
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({
    children,
    className,
    onClick,
    variant,
  }: {
    children: ReactNode;
    className?: string;
    onClick?: () => void;
    variant?: string;
  }) => (
    <button className={className} data-variant={variant} onClick={onClick} type="button">
      {children}
    </button>
  ),
  MapPinIcon: ({ className }: { className?: string }) => (
    <svg aria-hidden="true" className={className} data-testid="map-pin-icon" />
  ),
}));

vi.mock("@config/routes/constants", () => ({
  // biome-ignore lint/performance/useTopLevelRegex: vi.mock factory is hoisted by Vitest and executed once — no repeated-call concern
  ZIP_RE: /^\d{5}$/,
  ROUTES: { FAVORITES: "/favorites" },
}));

const mockSetZip = vi.fn();
const mockClearManualZip = vi.fn();
const mockUseLocation = vi.fn();

vi.mock("@shared/providers/location-provider", () => ({
  useLocation: () => mockUseLocation(),
}));

interface LocationOverrides {
  description?: string;
  displayCity?: string;
  displayState?: string;
  displayZip?: string;
  isManualZip?: boolean;
  isResolved?: boolean;
}

function setupLocation(overrides: LocationOverrides = {}) {
  mockUseLocation.mockReturnValue({
    state: {
      displayZip: "90210",
      displayCity: "",
      displayState: "",
      isManualZip: false,
      description: undefined,
      isResolved: true,
      ...overrides,
    },
    actions: { setZip: mockSetZip, clearManualZip: mockClearManualZip },
  });
}

function getZipInput() {
  return screen.getByPlaceholderText("Enter zip code");
}

beforeEach(() => {
  vi.clearAllMocks();
});

describe("LocationBlock", () => {
  describe("when isResolved=false", () => {
    it("renders nothing (returns null)", () => {
      setupLocation({ isResolved: false });
      const { container } = render(<LocationBlock useSolidStyles={false} />);

      expect(container).toBeEmptyDOMElement();
    });
  });

  describe("trigger label", () => {
    it("shows displayZip when no city/state and not a manual zip with description", () => {
      setupLocation({ displayZip: "75001" });
      render(<LocationBlock useSolidStyles={false} />);

      expect(screen.getByText("75001")).toBeInTheDocument();
    });

    it("shows description when isManualZip=true and description is provided", () => {
      setupLocation({
        isManualZip: true,
        description: "Miami, FL 33101",
        displayZip: "33101",
      });
      render(<LocationBlock useSolidStyles={false} />);

      expect(screen.getByText("Miami, FL 33101")).toBeInTheDocument();
    });

    it("shows 'city, state zip' when both displayCity and displayState are present", () => {
      setupLocation({
        displayCity: "Buffalo",
        displayState: "NY",
        displayZip: "14201",
      });
      render(<LocationBlock useSolidStyles={false} />);

      expect(screen.getByText("Buffalo, NY 14201")).toBeInTheDocument();
    });

    it("shows 'city zip' when only displayCity is present", () => {
      setupLocation({ displayCity: "Austin", displayZip: "73301" });
      render(<LocationBlock useSolidStyles={false} />);

      expect(screen.getByText("Austin 73301")).toBeInTheDocument();
    });

    it("shows 'state zip' when only displayState is present", () => {
      setupLocation({ displayState: "TX", displayZip: "73301" });
      render(<LocationBlock useSolidStyles={false} />);

      expect(screen.getByText("TX 73301")).toBeInTheDocument();
    });
  });

  describe("modal open/close toggle", () => {
    it("dialog is NOT shown on initial render", () => {
      setupLocation();
      render(<LocationBlock useSolidStyles={false} />);

      expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    });

    it("opens the dialog when the trigger button is clicked", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));

      expect(screen.getByRole("dialog")).toBeInTheDocument();
    });

    it("closes the dialog when the trigger button is clicked again", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      const trigger = screen.getByRole("button");
      fireEvent.click(trigger);
      fireEvent.click(trigger);

      expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    });

    it("trigger button has aria-expanded=false when dialog is closed", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      expect(screen.getByRole("button")).toHaveAttribute("aria-expanded", "false");
    });

    it("trigger button has aria-expanded=true when dialog is open", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));

      expect(screen.getByRole("button", { name: ZIP_90210_RE })).toHaveAttribute(
        "aria-expanded",
        "true"
      );
    });
  });

  describe("onModalOpenChange callback", () => {
    it("called with true when modal opens", () => {
      setupLocation({ displayZip: "90210" });
      const onModalOpenChange = vi.fn();
      render(<LocationBlock onModalOpenChange={onModalOpenChange} useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));

      expect(onModalOpenChange).toHaveBeenCalledWith(true);
    });

    it("called with false when modal closes via Escape", () => {
      setupLocation({ displayZip: "90210" });
      const onModalOpenChange = vi.fn();
      render(<LocationBlock onModalOpenChange={onModalOpenChange} useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));
      fireEvent.keyDown(document, { key: "Escape" });

      expect(onModalOpenChange).toHaveBeenLastCalledWith(false);
    });

    it("renders without error when onModalOpenChange is not provided", () => {
      setupLocation();
      expect(() => render(<LocationBlock useSolidStyles={false} />)).not.toThrow();
    });
  });

  describe("keyboard interactions", () => {
    it("Escape key closes the dialog", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));
      expect(screen.getByRole("dialog")).toBeInTheDocument();

      fireEvent.keyDown(document, { key: "Escape" });

      expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    });

    it("non-Escape keys do not close the dialog", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));
      fireEvent.keyDown(document, { key: "Tab" });
      fireEvent.keyDown(document, { key: "Enter" });

      expect(screen.getByRole("dialog")).toBeInTheDocument();
    });

    it("Escape key has no effect when dialog is already closed", () => {
      setupLocation();
      render(<LocationBlock useSolidStyles={false} />);

      expect(() => fireEvent.keyDown(document, { key: "Escape" })).not.toThrow();
      expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    });
  });

  describe("outside click", () => {
    it("mousedown outside the container closes the dialog", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));
      expect(screen.getByRole("dialog")).toBeInTheDocument();

      fireEvent.mouseDown(document.body);

      expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    });
  });

  describe("dialog content when open", () => {
    it("shows the 'Update Your Location' heading", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));

      expect(
        within(screen.getByRole("dialog")).getByText("Update Your Location")
      ).toBeInTheDocument();
    });

    it("shows the zip code input", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));

      expect(getZipInput()).toBeInTheDocument();
    });

    it("shows the Update button", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));

      expect(
        within(screen.getByRole("dialog")).getByRole("button", { name: "Update" })
      ).toBeInTheDocument();
    });

    it("does NOT show 'Use Device Location' when isManualZip=false", () => {
      setupLocation({ isManualZip: false });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));

      expect(screen.queryByRole("button", { name: "Use Device Location" })).not.toBeInTheDocument();
    });
  });

  describe("zip input", () => {
    it("strips non-digit characters from input value", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));
      fireEvent.change(getZipInput(), { target: { value: "ab1c2d3" } });

      expect(getZipInput()).toHaveValue("123");
    });

    it("accepts pure digit input unchanged", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));
      fireEvent.change(getZipInput(), { target: { value: "90210" } });

      expect(getZipInput()).toHaveValue("90210");
    });

    it("clears the zip error when the user types into the input", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));
      fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "Update" }));
      expect(screen.getByText(VALID_ZIP_ERROR_RE)).toBeInTheDocument();

      fireEvent.change(getZipInput(), { target: { value: "9" } });
      expect(screen.queryByText(VALID_ZIP_ERROR_RE)).not.toBeInTheDocument();
    });
  });

  describe("handleUpdate", () => {
    it("shows validation error when zip is empty", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));
      fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "Update" }));

      expect(screen.getByText("Please enter a valid 5-digit zip code.")).toBeInTheDocument();
    });

    it("shows validation error when zip has fewer than 5 digits", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));
      fireEvent.change(getZipInput(), { target: { value: "1234" } });
      fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "Update" }));

      expect(screen.getByText("Please enter a valid 5-digit zip code.")).toBeInTheDocument();
      expect(mockSetZip).not.toHaveBeenCalled();
    });

    it("shows validation error when zip has more than 5 digits (after strip)", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));
      fireEvent.change(getZipInput(), { target: { value: "123456" } });
      fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "Update" }));

      expect(screen.getByText("Please enter a valid 5-digit zip code.")).toBeInTheDocument();
    });

    it("shows validation error for whitespace-only input", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));
      fireEvent.change(getZipInput(), { target: { value: "   " } });
      fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "Update" }));

      expect(screen.getByText("Please enter a valid 5-digit zip code.")).toBeInTheDocument();
    });

    it("calls setZip with trimmed value on valid zip and closes dialog", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));
      fireEvent.change(getZipInput(), { target: { value: "10001" } });
      fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "Update" }));

      expect(mockSetZip).toHaveBeenCalledWith("10001");
      expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    });

    it("Enter key on the zip input triggers update with valid zip", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));
      fireEvent.change(getZipInput(), { target: { value: "10001" } });
      fireEvent.keyDown(getZipInput(), { key: "Enter" });

      expect(mockSetZip).toHaveBeenCalledWith("10001");
      expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    });

    it("Enter key with invalid zip shows error and does NOT call setZip", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));
      fireEvent.keyDown(getZipInput(), { key: "Enter" });

      expect(screen.getByText("Please enter a valid 5-digit zip code.")).toBeInTheDocument();
      expect(mockSetZip).not.toHaveBeenCalled();
    });

    it("non-Enter keydown on the input does not trigger update", () => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button"));
      fireEvent.keyDown(getZipInput(), { key: "Tab" });

      expect(mockSetZip).not.toHaveBeenCalled();
      expect(screen.getByRole("dialog")).toBeInTheDocument();
    });
  });

  describe("Use Device Location button", () => {
    it("is shown when isManualZip=true", () => {
      setupLocation({ isManualZip: true });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button", { name: ZIP_90210_RE }));

      expect(screen.getByRole("button", { name: "Use Device Location" })).toBeInTheDocument();
    });

    it("calls clearManualZip and closes dialog when clicked", () => {
      setupLocation({ isManualZip: true });
      render(<LocationBlock useSolidStyles={false} />);

      fireEvent.click(screen.getByRole("button", { name: ZIP_90210_RE }));
      fireEvent.click(screen.getByRole("button", { name: "Use Device Location" }));

      expect(mockClearManualZip).toHaveBeenCalledTimes(1);
      expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    });
  });

  describe("invariant structure", () => {
    it("always renders the MapPinIcon", () => {
      setupLocation();
      render(<LocationBlock useSolidStyles={false} />);

      expect(screen.getByTestId("map-pin-icon")).toBeInTheDocument();
    });
  });

  describe("useSolidStyles prop", () => {
    it.each([true, false])("renders without error when useSolidStyles=%s", (useSolidStyles) => {
      setupLocation();
      expect(() => render(<LocationBlock useSolidStyles={useSolidStyles} />)).not.toThrow();
    });

    it.each([true, false])("dialog is accessible when useSolidStyles=%s", (useSolidStyles) => {
      setupLocation({ displayZip: "90210" });
      render(<LocationBlock useSolidStyles={useSolidStyles} />);

      fireEvent.click(screen.getByRole("button"));

      expect(screen.getByRole("dialog")).toBeInTheDocument();
    });
  });
});
