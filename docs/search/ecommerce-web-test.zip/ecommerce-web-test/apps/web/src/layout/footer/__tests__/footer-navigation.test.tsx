import { render, screen, within } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { FooterNavigation } from "../footer-navigation";

const sectionsRef = vi.hoisted(() => ({
  current: [] as Array<{
    title: string;
    links: Array<{ label: string; href: string; external?: boolean }>;
  }>,
}));

vi.mock("@shared/data/footer/footer-links", () => ({
  get footerSections() {
    return sectionsRef.current;
  },
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Heading: ({
    children,
    level = 2,
  }: {
    children: React.ReactNode;
    level?: number;
    [key: string]: unknown;
  }) => {
    const Tag = `h${level}` as "h1" | "h2" | "h3" | "h4" | "h5" | "h6";
    return <Tag data-testid="section-heading">{children}</Tag>;
  },
}));

vi.mock("../footer-nav-mobile", () => ({
  FooterNavMobile: () => <div data-testid="footer-nav-mobile-stub" />,
}));

const STANDARD_SECTIONS = [
  {
    title: "Shop",
    links: [
      { label: "Buy a Car", href: "/buy" },
      { label: "Finance Options", href: "/finance" },
      { label: "Trade-In Value", href: "/trade-in" },
    ],
  },
  {
    title: "Support",
    links: [
      { label: "Contact Us", href: "/contact" },
      { label: "External Help", href: "https://help.example.com", external: true },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy Policy", href: "/privacy" },
      { label: "External Portal", href: "https://legal.example.com", external: true },
    ],
  },
];

const TOTAL_LINKS = STANDARD_SECTIONS.reduce((sum, s) => sum + s.links.length, 0);

function getAt<T>(arr: T[], i: number): T {
  const item = arr[i];
  if (item === undefined) {
    throw new Error(`No element at index ${i}`);
  }
  return item;
}

describe("FooterNavigation", () => {
  beforeEach(() => {
    sectionsRef.current = STANDARD_SECTIONS;
  });

  describe("desktop grid — headings", () => {
    it("renders exactly one heading per section", () => {
      render(<FooterNavigation />);

      expect(screen.getAllByTestId("section-heading")).toHaveLength(STANDARD_SECTIONS.length);
    });

    it("renders every section title as an h3 heading", () => {
      render(<FooterNavigation />);

      for (const section of STANDARD_SECTIONS) {
        expect(screen.getByRole("heading", { level: 3, name: section.title })).toBeInTheDocument();
      }
    });

    it("preserves section heading order from the data source", () => {
      render(<FooterNavigation />);

      const headings = screen.getAllByTestId("section-heading");
      STANDARD_SECTIONS.forEach((section, i) => {
        expect(headings[i]).toHaveTextContent(section.title);
      });
    });
  });

  describe("desktop grid — links", () => {
    it("renders all link labels", () => {
      render(<FooterNavigation />);

      for (const section of STANDARD_SECTIONS) {
        for (const link of section.links) {
          expect(screen.getByRole("link", { name: link.label })).toBeInTheDocument();
        }
      }
    });

    it("renders the correct total number of links", () => {
      render(<FooterNavigation />);

      expect(screen.getAllByRole("link")).toHaveLength(TOTAL_LINKS);
    });

    it("gives every link the correct href from the data source", () => {
      render(<FooterNavigation />);

      for (const section of STANDARD_SECTIONS) {
        for (const link of section.links) {
          expect(screen.getByRole("link", { name: link.label })).toHaveAttribute("href", link.href);
        }
      }
    });

    it("scopes each section's links inside its own heading container", () => {
      render(<FooterNavigation />);

      const headings = screen.getAllByTestId("section-heading");

      STANDARD_SECTIONS.forEach((section, i) => {
        const container = getAt(headings, i).closest("div");
        if (!container) {
          throw new Error(`No wrapping div found for section ${i}`);
        }
        for (const link of section.links) {
          expect(within(container).getByRole("link", { name: link.label })).toBeInTheDocument();
        }
      });
    });
  });

  describe("external links", () => {
    it("opens external links in a new tab via target='_blank'", () => {
      render(<FooterNavigation />);

      const externalLinks = STANDARD_SECTIONS.flatMap((s) =>
        s.links.filter((l) => l.external === true)
      );
      expect(externalLinks.length).toBeGreaterThan(0);

      for (const link of externalLinks) {
        expect(screen.getByRole("link", { name: link.label })).toHaveAttribute("target", "_blank");
      }
    });

    it("adds rel='noopener noreferrer' to external links", () => {
      render(<FooterNavigation />);

      const externalLinks = STANDARD_SECTIONS.flatMap((s) =>
        s.links.filter((l) => l.external === true)
      );

      for (const link of externalLinks) {
        expect(screen.getByRole("link", { name: link.label })).toHaveAttribute(
          "rel",
          "noopener noreferrer"
        );
      }
    });
  });

  describe("internal links", () => {
    it("does not add target attribute to internal links", () => {
      render(<FooterNavigation />);

      const internalLinks = STANDARD_SECTIONS.flatMap((s) => s.links.filter((l) => !l.external));
      expect(internalLinks.length).toBeGreaterThan(0);

      for (const link of internalLinks) {
        expect(screen.getByRole("link", { name: link.label })).not.toHaveAttribute("target");
      }
    });

    it("does not add rel attribute to internal links", () => {
      render(<FooterNavigation />);

      const internalLinks = STANDARD_SECTIONS.flatMap((s) => s.links.filter((l) => !l.external));

      for (const link of internalLinks) {
        expect(screen.getByRole("link", { name: link.label })).not.toHaveAttribute("rel");
      }
    });
  });

  describe("mobile delegation", () => {
    it("renders the FooterNavMobile component exactly once", () => {
      render(<FooterNavigation />);

      expect(screen.getByTestId("footer-nav-mobile-stub")).toBeInTheDocument();
      expect(screen.getAllByTestId("footer-nav-mobile-stub")).toHaveLength(1);
    });

    it("renders FooterNavMobile alongside the desktop grid", () => {
      render(<FooterNavigation />);

      expect(screen.getByTestId("footer-nav-mobile-stub")).toBeInTheDocument();
      expect(screen.getAllByTestId("section-heading").length).toBeGreaterThan(0);
    });
  });

  describe("edge cases", () => {
    it("renders no headings and no links when footerSections is empty", () => {
      sectionsRef.current = [];
      render(<FooterNavigation />);

      expect(screen.queryAllByTestId("section-heading")).toHaveLength(0);
      expect(screen.queryAllByRole("link")).toHaveLength(0);
    });

    it("still renders FooterNavMobile when footerSections is empty", () => {
      sectionsRef.current = [];
      render(<FooterNavigation />);

      expect(screen.getByTestId("footer-nav-mobile-stub")).toBeInTheDocument();
    });

    it("renders a heading without links when the links array is empty", () => {
      sectionsRef.current = [{ title: "Empty Section", links: [] }];
      render(<FooterNavigation />);

      expect(screen.getByRole("heading", { level: 3, name: "Empty Section" })).toBeInTheDocument();
      expect(screen.queryAllByRole("link")).toHaveLength(0);
    });

    it("renders a single section with a single link correctly", () => {
      sectionsRef.current = [{ title: "Solo", links: [{ label: "Only Link", href: "/only" }] }];
      render(<FooterNavigation />);

      expect(screen.getByRole("heading", { level: 3, name: "Solo" })).toBeInTheDocument();
      expect(screen.getByRole("link", { name: "Only Link" })).toHaveAttribute("href", "/only");
    });

    it("handles a large number of sections without errors", () => {
      const manySections = Array.from({ length: 20 }, (_, i) => ({
        title: `Section ${i + 1}`,
        links: [{ label: `Link ${i + 1}`, href: `/path-${i + 1}` }],
      }));
      sectionsRef.current = manySections;
      render(<FooterNavigation />);

      expect(screen.getAllByTestId("section-heading")).toHaveLength(20);
      expect(screen.getAllByRole("link")).toHaveLength(20);
    });

    it("renders a mix of external and internal links in the same section", () => {
      sectionsRef.current = [
        {
          title: "Mixed",
          links: [
            { label: "Internal", href: "/internal" },
            { label: "External", href: "https://external.com", external: true },
          ],
        },
      ];
      render(<FooterNavigation />);

      const internal = screen.getByRole("link", { name: "Internal" });
      const external = screen.getByRole("link", { name: "External" });

      expect(internal).not.toHaveAttribute("target");
      expect(internal).not.toHaveAttribute("rel");
      expect(external).toHaveAttribute("target", "_blank");
      expect(external).toHaveAttribute("rel", "noopener noreferrer");
    });

    it("preserves section order from the data source", () => {
      const ordered = [
        { title: "First", links: [{ label: "Link A", href: "/a" }] },
        { title: "Second", links: [{ label: "Link B", href: "/b" }] },
        { title: "Third", links: [{ label: "Link C", href: "/c" }] },
      ];
      sectionsRef.current = ordered;
      render(<FooterNavigation />);

      const headings = screen.getAllByTestId("section-heading");
      expect(headings[0]).toHaveTextContent("First");
      expect(headings[1]).toHaveTextContent("Second");
      expect(headings[2]).toHaveTextContent("Third");
    });

    it("a section with only external links applies target and rel to all", () => {
      sectionsRef.current = [
        {
          title: "All External",
          links: [
            { label: "Ext A", href: "https://a.com", external: true },
            { label: "Ext B", href: "https://b.com", external: true },
          ],
        },
      ];
      render(<FooterNavigation />);

      const links = screen.getAllByRole("link");
      expect(links).toHaveLength(2);
      for (const link of links) {
        expect(link).toHaveAttribute("target", "_blank");
        expect(link).toHaveAttribute("rel", "noopener noreferrer");
      }
    });

    it("a section with only internal links applies no target or rel", () => {
      sectionsRef.current = [
        {
          title: "All Internal",
          links: [
            { label: "Int A", href: "/a" },
            { label: "Int B", href: "/b" },
          ],
        },
      ];
      render(<FooterNavigation />);

      const links = screen.getAllByRole("link");
      expect(links).toHaveLength(2);
      for (const link of links) {
        expect(link).not.toHaveAttribute("target");
        expect(link).not.toHaveAttribute("rel");
      }
    });
  });
});
