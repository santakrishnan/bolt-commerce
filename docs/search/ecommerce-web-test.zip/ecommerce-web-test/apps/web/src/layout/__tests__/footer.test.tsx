import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { Footer } from "../footer";

const FOOTER_BOTTOM_STUB_REGEX = /^footer-bottom-(contact|copyright)-stub$/;

vi.mock("../footer/footer-top", () => ({
  FooterTop: () => <div data-testid="footer-top-stub" />,
}));

vi.mock("../footer/footer-navigation", () => ({
  FooterNavigation: () => <div data-testid="footer-navigation-stub" />,
}));

vi.mock("../footer/footer-bottom", () => ({
  FooterBottom: ({ section }: { section: string }) => (
    <div data-testid={`footer-bottom-${section}-stub`} />
  ),
}));

describe("Footer", () => {
  describe("semantic structure", () => {
    it("renders a <footer> landmark element", () => {
      render(<Footer />);
      expect(screen.getByRole("contentinfo")).toBeInTheDocument();
    });
  });

  describe("child composition", () => {
    it("renders FooterTop exactly once", () => {
      render(<Footer />);

      expect(screen.getByTestId("footer-top-stub")).toBeInTheDocument();
      expect(screen.getAllByTestId("footer-top-stub")).toHaveLength(1);
    });

    it("renders FooterNavigation exactly once", () => {
      render(<Footer />);

      expect(screen.getByTestId("footer-navigation-stub")).toBeInTheDocument();
      expect(screen.getAllByTestId("footer-navigation-stub")).toHaveLength(1);
    });

    it("renders FooterBottom with section='contact' exactly once", () => {
      render(<Footer />);

      expect(screen.getByTestId("footer-bottom-contact-stub")).toBeInTheDocument();
      expect(screen.getAllByTestId("footer-bottom-contact-stub")).toHaveLength(1);
    });

    it("renders FooterBottom with section='copyright' exactly once", () => {
      render(<Footer />);

      expect(screen.getByTestId("footer-bottom-copyright-stub")).toBeInTheDocument();
      expect(screen.getAllByTestId("footer-bottom-copyright-stub")).toHaveLength(1);
    });

    it("renders FooterBottom exactly twice in total", () => {
      render(<Footer />);
      expect(screen.getByTestId("footer-bottom-contact-stub")).toBeInTheDocument();
      expect(screen.getByTestId("footer-bottom-copyright-stub")).toBeInTheDocument();
      expect(screen.queryAllByTestId(FOOTER_BOTTOM_STUB_REGEX)).toHaveLength(2);
    });

    it("renders all four sections together in a single render", () => {
      render(<Footer />);

      expect(screen.getByTestId("footer-top-stub")).toBeInTheDocument();
      expect(screen.getByTestId("footer-navigation-stub")).toBeInTheDocument();
      expect(screen.getByTestId("footer-bottom-contact-stub")).toBeInTheDocument();
      expect(screen.getByTestId("footer-bottom-copyright-stub")).toBeInTheDocument();
    });
  });

  describe("section ordering", () => {
    it("renders the contact section before the copyright section in the DOM", () => {
      render(<Footer />);

      const allNodes = Array.from(document.querySelectorAll("[data-testid]"));
      const contactIdx = allNodes.indexOf(screen.getByTestId("footer-bottom-contact-stub"));
      const copyrightIdx = allNodes.indexOf(screen.getByTestId("footer-bottom-copyright-stub"));

      expect(contactIdx).toBeLessThan(copyrightIdx);
    });

    it("renders FooterTop before FooterNavigation in the DOM", () => {
      render(<Footer />);

      const allNodes = Array.from(document.querySelectorAll("[data-testid]"));
      const topIdx = allNodes.indexOf(screen.getByTestId("footer-top-stub"));
      const navIdx = allNodes.indexOf(screen.getByTestId("footer-navigation-stub"));

      expect(topIdx).toBeLessThan(navIdx);
    });
  });
});
