import type { SocialIcon, SocialLink } from "@shared/data/footer/footer-links";
import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { FooterTop } from "../footer-top";

const socialLinksRef = vi.hoisted(() => ({
  current: [] as SocialLink[],
}));

vi.mock("@shared/data/footer/footer-links", () => ({
  get socialLinks() {
    return socialLinksRef.current;
  },
}));

/**
 * Override the global next/image stub (which returns bare props) with one
 * that renders a real <img> so alt and src assertions work.
 */
vi.mock("next/image", () => ({
  default: ({
    src,
    alt,
    width,
    height,
  }: {
    src: string;
    alt: string;
    width: number;
    height: number;
    // biome-ignore lint/performance/noImgElement: native <img> is required in this test mock to enable getByAltText queries
  }) => <img alt={alt} height={height} src={src} width={width} />,
}));

const DEFAULT_SOCIAL_LINKS: SocialLink[] = [
  { label: "Facebook", href: "https://facebook.com", icon: "facebook" as const },
  { label: "Twitter", href: "https://twitter.com", icon: "twitter" as const },
  { label: "Instagram", href: "https://instagram.com", icon: "instagram" as const },
  { label: "YouTube", href: "https://youtube.com", icon: "youtube" as const },
];

const DEFAULT_BRAND_NAME = "Arrow";
const DEFAULT_TAGLINE = "Your trusted partner for quality pre-owned vehicles";

const EXPECTED_ICON_SRC: Record<SocialIcon, string> = {
  facebook: "/images/footer/icon-facebook.svg",
  twitter: "/images/footer/icon-twitter.svg",
  instagram: "/images/footer/icon-instagram.svg",
  youtube: "/images/footer/icon-youtube.svg",
};

function renderFooterTop({
  brandName = DEFAULT_BRAND_NAME,
  socialLinks = DEFAULT_SOCIAL_LINKS,
  tagline = DEFAULT_TAGLINE,
}: {
  brandName?: string;
  socialLinks?: SocialLink[];
  tagline?: string;
} = {}) {
  return render(<FooterTop brandName={brandName} socialLinks={socialLinks} tagline={tagline} />);
}

describe("FooterTop", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  describe("brand section", () => {
    it("renders 'Arrow' as an h2 heading", () => {
      renderFooterTop();

      expect(screen.getByRole("heading", { level: 2, name: "Arrow" })).toBeInTheDocument();
    });

    it("renders the brand tagline text", () => {
      renderFooterTop();

      expect(
        screen.getByText("Your trusted partner for quality pre-owned vehicles")
      ).toBeInTheDocument();
    });

    it("renders the brand section even when socialLinks is empty", () => {
      renderFooterTop({ socialLinks: [] });

      expect(screen.getByRole("heading", { level: 2, name: "Arrow" })).toBeInTheDocument();
      expect(
        screen.getByText("Your trusted partner for quality pre-owned vehicles")
      ).toBeInTheDocument();
    });
  });

  describe("social links — count and structure", () => {
    it("renders exactly one link per social entry", () => {
      renderFooterTop();

      expect(screen.getAllByRole("link")).toHaveLength(DEFAULT_SOCIAL_LINKS.length);
    });

    it("renders exactly one image per social entry", () => {
      renderFooterTop();

      expect(screen.getAllByRole("img")).toHaveLength(DEFAULT_SOCIAL_LINKS.length);
    });

    it("renders no links when socialLinks is empty", () => {
      renderFooterTop({ socialLinks: [] });

      expect(screen.queryAllByRole("link")).toHaveLength(0);
    });

    it("renders no images when socialLinks is empty", () => {
      renderFooterTop({ socialLinks: [] });

      expect(screen.queryAllByRole("img")).toHaveLength(0);
    });
  });

  describe("social links — hrefs", () => {
    it("gives every social link the correct href", () => {
      renderFooterTop();

      for (const social of DEFAULT_SOCIAL_LINKS) {
        expect(screen.getByRole("link", { name: social.label })).toHaveAttribute(
          "href",
          social.href
        );
      }
    });
  });

  describe("social links — aria-labels", () => {
    it("gives every link an aria-label matching its social network name", () => {
      renderFooterTop();

      for (const social of DEFAULT_SOCIAL_LINKS) {
        expect(screen.getByRole("link", { name: social.label })).toBeInTheDocument();
      }
    });
  });

  describe("social links — external link attributes", () => {
    it("opens every social link in a new tab via target='_blank'", () => {
      renderFooterTop();

      for (const social of DEFAULT_SOCIAL_LINKS) {
        expect(screen.getByRole("link", { name: social.label })).toHaveAttribute(
          "target",
          "_blank"
        );
      }
    });

    it("adds rel='noopener noreferrer' to every social link", () => {
      renderFooterTop();

      for (const social of DEFAULT_SOCIAL_LINKS) {
        expect(screen.getByRole("link", { name: social.label })).toHaveAttribute(
          "rel",
          "noopener noreferrer"
        );
      }
    });
  });

  describe("social icons — alt text", () => {
    it("gives each icon image an alt attribute matching the link label", () => {
      renderFooterTop();

      for (const social of DEFAULT_SOCIAL_LINKS) {
        expect(screen.getByAltText(social.label)).toBeInTheDocument();
      }
    });
  });

  describe("social icons — src resolution", () => {
    it("resolves the correct icon src for each known social network", () => {
      renderFooterTop();

      for (const social of DEFAULT_SOCIAL_LINKS) {
        const img = screen.getByAltText(social.label);
        expect(img).toHaveAttribute("src", EXPECTED_ICON_SRC[social.icon]);
      }
    });

    it("facebook icon uses the facebook svg path", () => {
      renderFooterTop({
        socialLinks: [{ label: "Facebook", href: "https://facebook.com", icon: "facebook" }],
      });

      expect(screen.getByAltText("Facebook")).toHaveAttribute(
        "src",
        "/images/footer/icon-facebook.svg"
      );
    });

    it("twitter icon uses the twitter svg path", () => {
      renderFooterTop({
        socialLinks: [{ label: "Twitter", href: "https://twitter.com", icon: "twitter" }],
      });

      expect(screen.getByAltText("Twitter")).toHaveAttribute(
        "src",
        "/images/footer/icon-twitter.svg"
      );
    });

    it("instagram icon uses the instagram svg path", () => {
      renderFooterTop({
        socialLinks: [{ label: "Instagram", href: "https://instagram.com", icon: "instagram" }],
      });

      expect(screen.getByAltText("Instagram")).toHaveAttribute(
        "src",
        "/images/footer/icon-instagram.svg"
      );
    });

    it("youtube icon uses the youtube svg path", () => {
      renderFooterTop({
        socialLinks: [{ label: "YouTube", href: "https://youtube.com", icon: "youtube" }],
      });

      expect(screen.getByAltText("YouTube")).toHaveAttribute(
        "src",
        "/images/footer/icon-youtube.svg"
      );
    });
  });

  describe("edge cases", () => {
    it("renders a single social link correctly", () => {
      renderFooterTop({
        socialLinks: [{ label: "Facebook", href: "https://facebook.com", icon: "facebook" }],
      });

      expect(screen.getAllByRole("link")).toHaveLength(1);
      expect(screen.getByRole("link", { name: "Facebook" })).toHaveAttribute(
        "href",
        "https://facebook.com"
      );
      expect(screen.getByRole("link", { name: "Facebook" })).toHaveAttribute("target", "_blank");
      expect(screen.getByRole("link", { name: "Facebook" })).toHaveAttribute(
        "rel",
        "noopener noreferrer"
      );
      expect(screen.getByAltText("Facebook")).toHaveAttribute(
        "src",
        "/images/footer/icon-facebook.svg"
      );
    });

    it("renders custom href and label from socialLinks data", () => {
      renderFooterTop({
        socialLinks: [
          { label: "Custom Network", href: "https://custom.example.com", icon: "twitter" },
        ],
      });

      const link = screen.getByRole("link", { name: "Custom Network" });
      expect(link).toHaveAttribute("href", "https://custom.example.com");
      expect(screen.getByAltText("Custom Network")).toBeInTheDocument();
    });

    it("handles a large number of social links without errors", () => {
      const manyLinks = Array.from({ length: 20 }, (_, i) => ({
        label: `Network ${i + 1}`,
        href: `https://network${i + 1}.com`,
        icon: "facebook" as const,
      }));
      renderFooterTop({ socialLinks: manyLinks });

      expect(screen.getAllByRole("link")).toHaveLength(20);
      expect(screen.getAllByRole("img")).toHaveLength(20);
    });

    it("preserves social link order from the data source", () => {
      const ordered = [
        { label: "First", href: "https://first.com", icon: "facebook" as const },
        { label: "Second", href: "https://second.com", icon: "twitter" as const },
        { label: "Third", href: "https://third.com", icon: "instagram" as const },
      ];
      renderFooterTop({ socialLinks: ordered });

      const links = screen.getAllByRole("link");
      expect(links[0]).toHaveAttribute("aria-label", "First");
      expect(links[1]).toHaveAttribute("aria-label", "Second");
      expect(links[2]).toHaveAttribute("aria-label", "Third");
    });

    it("does not emit duplicate key warnings when labels repeat", () => {
      const consoleErrorSpy = vi.spyOn(console, "error").mockImplementation(() => undefined);

      renderFooterTop({
        socialLinks: [
          { label: "Arrow", href: "https://facebook.com/arrow", icon: "facebook" },
          { label: "Arrow", href: "https://instagram.com/arrow", icon: "instagram" },
        ],
      });

      expect(screen.getAllByRole("link")).toHaveLength(2);
      expect(consoleErrorSpy).not.toHaveBeenCalledWith(
        expect.stringContaining("Encountered two children with the same key")
      );
    });
  });
});
