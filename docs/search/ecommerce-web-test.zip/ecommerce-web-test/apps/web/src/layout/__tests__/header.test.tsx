import { act, fireEvent, render, screen } from "@arrow/vitest-config/test-utils";
import type { ReactNode } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const LOGO_LINK_RE = /ARROW/i;

import { HeaderClient } from "../header/header-client";

const mockUsePathname = vi.fn(() => "/");
const mockUseRouter = vi.fn(() => ({
  push: vi.fn(),
}));

vi.mock("next/navigation", () => ({
  usePathname: () => mockUsePathname(),
  useRouter: () => mockUseRouter(),
}));

const mockGetCurrentUserSync = vi.fn(() => ({ firstName: "Guest", isAuthenticated: false }));
vi.mock("@config/flags/client", () => ({
  getCurrentUserSync: () => mockGetCurrentUserSync(),
}));

vi.mock("@config/routes/constants", () => ({
  ROUTES: { HOME: "/", MY_GARAGE: "/my-garage" },
}));

const mockUseLocation = vi.fn();
vi.mock("@shared/providers/location-provider", () => ({
  useLocation: () => mockUseLocation(),
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({
    children,
    onClick,
    "aria-label": ariaLabel,
  }: {
    children: ReactNode;
    onClick?: () => void;
    "aria-label"?: string;
  }) => (
    <button aria-label={ariaLabel} onClick={onClick} type="button">
      {children}
    </button>
  ),
  MenuIcon: () => <svg aria-hidden="true" data-testid="menu-icon" />,
  ArrowLogo: () => <span>ARROW</span>,
}));

vi.mock("next/link", () => ({
  default: ({
    href,
    children,
    className,
  }: {
    href: string;
    children: ReactNode;
    className?: string;
  }) => (
    <a className={className} href={href}>
      {children}
    </a>
  ),
}));

vi.mock("next/image", () => ({
  default: ({
    src,
    alt,
    width,
    height,
    className,
  }: {
    src: string;
    alt: string;
    width?: number;
    height?: number;
    className?: string;
  }) => (
    // biome-ignore lint/performance/noImgElement: test stub
    <img alt={alt} className={className} height={height} src={src} width={width} />
  ),
}));

vi.mock("../header/header-nav", () => ({
  HeaderNav: ({ useSolidStyles }: { useSolidStyles: boolean }) => (
    <nav aria-label="main-nav" data-solid={String(useSolidStyles)} data-testid="header-nav" />
  ),
}));

vi.mock("../header/favorites-button", () => ({
  FavoritesButton: ({ useSolidStyles }: { useSolidStyles: boolean }) => (
    <div data-solid={String(useSolidStyles)} data-testid="favorites-button" />
  ),
}));

vi.mock("../header/location-block", () => ({
  LocationBlock: ({ useSolidStyles }: { useSolidStyles: boolean }) => (
    <div data-solid={String(useSolidStyles)} data-testid="location-block" />
  ),
}));

vi.mock("../header/auth-buttons", () => ({
  AvatarButton: ({
    firstName,
    useSolidStyles,
    isOpen,
    onClick,
  }: {
    firstName: string;
    useSolidStyles: boolean;
    isOpen?: boolean;
    onClick?: () => void;
  }) => (
    <button
      data-first-name={firstName}
      data-open={String(isOpen ?? false)}
      data-solid={String(useSolidStyles)}
      data-testid="avatar-button"
      onClick={onClick}
      type="button"
    />
  ),
  SignInButton: ({ useSolidStyles }: { useSolidStyles: boolean }) => (
    <div data-solid={String(useSolidStyles)} data-testid="sign-in-button" />
  ),
}));

let triggerMobileMenuClose: (() => void) | undefined;
vi.mock("../header/hamburger-menu", () => ({
  HamburgerMenu: ({ onClose, animFromLeft }: { onClose: () => void; animFromLeft?: boolean }) => {
    triggerMobileMenuClose = onClose;
    return <div data-anim-from-left={String(animFromLeft ?? false)} data-testid="mobile-menu" />;
  },
}));

vi.mock("../header/desktop-account-menu", () => ({
  DesktopAccountMenu: ({ onClose }: { onClose: () => void }) => (
    <button data-testid="desktop-account-menu" onClick={onClose} type="button" />
  ),
}));

vi.mock("../header/my-account-menu", () => ({
  MyAccountMenu: () => <div data-testid="my-account-menu" />,
}));

function setupLocation(isResolved = true) {
  mockUseLocation.mockReturnValue({
    state: { isResolved },
    actions: {},
  });
}

function setScrollY(y: number) {
  Object.defineProperty(window, "scrollY", {
    get: () => y,
    configurable: true,
  });
}

function clickHamburger() {
  const btn =
    screen.queryByRole("button", { name: "Open menu" }) ??
    screen.getByRole("button", { name: "Close menu" });
  fireEvent.click(btn);
}

function renderHeader() {
  const user = mockGetCurrentUserSync();

  return render(
    <HeaderClient
      initialFirstName={user.firstName}
      initialShowPersonalized={user.isAuthenticated === true}
    />
  );
}

beforeEach(() => {
  vi.clearAllMocks();
  triggerMobileMenuClose = undefined;
  mockGetCurrentUserSync.mockReturnValue({ firstName: "Guest", isAuthenticated: false });
  mockUsePathname.mockReturnValue("/");
  setScrollY(0);
  document.documentElement.classList.remove("bg-white", "bg-black");
  setupLocation();
});

afterEach(() => {
  setScrollY(0);
  document.documentElement.classList.remove("bg-white", "bg-black");
});

describe("Header", () => {
  describe("invariant structure", () => {
    it("renders the ARROW logo link pointing to '/'", () => {
      setupLocation();
      renderHeader();

      const logo = screen.getByRole("link", { name: LOGO_LINK_RE });
      expect(logo).toBeInTheDocument();
      expect(logo).toHaveAttribute("href", "/");
    });

    it("renders HeaderNav", () => {
      setupLocation();
      renderHeader();

      expect(screen.getByTestId("header-nav")).toBeInTheDocument();
    });

    it("renders LocationBlock (desktop cluster)", () => {
      setupLocation();
      renderHeader();

      expect(screen.getByTestId("location-block")).toBeInTheDocument();
    });

    // it("renders MobileUserButton", () => {
    //   setupLocation();
    //   renderHeader();

    //   expect(screen.getByTestId("mobile-user-button")).toBeInTheDocument();
    // });

    it("renders the hamburger button with initial aria-label 'Open menu'", () => {
      setupLocation();
      renderHeader();

      expect(screen.getByRole("button", { name: "Open menu" })).toBeInTheDocument();
    });
  });

  describe("useSolidStyles", () => {
    it("is false on the home page when not scrolled", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      renderHeader();

      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "false");
    });

    it("is false on the my-garage page when not scrolled", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/my-garage");
      renderHeader();

      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "false");
    });

    it("is true on any other page (e.g. /used-cars)", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/used-cars");
      renderHeader();

      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "true");
    });

    it("is true on the home page once the user scrolls past 150px", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      setScrollY(151);
      renderHeader();

      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "true");
    });

    it("remains false on the home page when scrollY is exactly 150px", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      setScrollY(150);
      renderHeader();

      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "false");
    });

    it("becomes true on the home page after a scroll event pushes scrollY above 150", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      renderHeader();
      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "false");

      setScrollY(200);
      fireEvent.scroll(window);

      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "true");
    });

    it("remains false on the home page when the location modal is open", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      renderHeader();

      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "false");
    });

    it("remains false on the home page regardless of location modal state", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      renderHeader();

      // header stays transparent — opening the zip dropdown must not switch it to white
      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "false");
    });

    it("propagates useSolidStyles=true to LocationBlock", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/used-cars");
      renderHeader();

      expect(screen.getByTestId("location-block")).toHaveAttribute("data-solid", "true");
    });

    it("propagates useSolidStyles=false to HeaderNav on home page", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      renderHeader();

      expect(screen.getByTestId("header-nav")).toHaveAttribute("data-solid", "false");
    });
  });
  describe("spacer div (layout padding for fixed header)", () => {
    it("is rendered when useSolidStyles=true", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/used-cars");
      const { container } = renderHeader();

      expect(container.querySelector('header + div[aria-hidden="true"]')).toBeInTheDocument();
    });

    it("is NOT rendered when useSolidStyles=false", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      const { container } = renderHeader();

      expect(container.querySelector('header + div[aria-hidden="true"]')).not.toBeInTheDocument();
    });
  });

  describe("html element class synchronisation", () => {
    it("adds bg-white to <html> when useSolidStyles=true", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/used-cars");
      renderHeader();

      expect(document.documentElement.classList.contains("bg-white")).toBe(true);
    });

    it("adds bg-black to <html> when useSolidStyles=false", () => {
      setupLocation();
      mockUsePathname.mockReturnValue("/");
      renderHeader();

      expect(document.documentElement.classList.contains("bg-black")).toBe(true);
    });
  });

  describe("FavoritesButton conditional rendering", () => {
    it("renders FavoritesButton in both clusters when isResolved=true", () => {
      setupLocation(true);
      renderHeader();

      expect(screen.getAllByTestId("favorites-button")).toHaveLength(2);
    });

    it("renders FavoritesButton when isResolved=false", () => {
      setupLocation(false);
      renderHeader();

      expect(screen.getAllByTestId("favorites-button")).toHaveLength(2);
    });
  });

  describe("auth state from isAuthenticated", () => {
    it("renders SignInButton when isAuthenticated=false", () => {
      setupLocation();
      mockGetCurrentUserSync.mockReturnValue({ firstName: "Guest", isAuthenticated: false });
      renderHeader();

      expect(screen.getAllByTestId("sign-in-button")).toHaveLength(2);
      expect(screen.queryAllByTestId("avatar-button")).toHaveLength(0);
    });

    it("renders AvatarButton when isAuthenticated=true", () => {
      setupLocation();
      mockGetCurrentUserSync.mockReturnValue({ firstName: "Sarah", isAuthenticated: true });
      renderHeader();

      expect(screen.getAllByTestId("avatar-button")).toHaveLength(2);
      expect(screen.queryAllByTestId("sign-in-button")).toHaveLength(0);
    });

    it("passes firstName from getCurrentUserSync to AvatarButton", () => {
      setupLocation();
      mockGetCurrentUserSync.mockReturnValue({ firstName: "Alice", isAuthenticated: true });
      renderHeader();

      const avatarButtons = screen.getAllByTestId("avatar-button");
      expect(avatarButtons).toHaveLength(2);
      for (const button of avatarButtons) {
        expect(button).toHaveAttribute("data-first-name", "Alice");
      }
    });

    // it("passes firstName from getCurrentUserSync to MobileUserButton", () => {
    //   setupLocation();
    //   mockGetCurrentUserSync.mockReturnValue({ firstName: "Bob", isAuthenticated: false });
    //   renderHeader();

    //   expect(screen.getByTestId("mobile-user-button")).toHaveAttribute("data-first-name", "Bob");
    // });

    // it("passes showAvatar=false to MobileUserButton when not authenticated", () => {
    //   setupLocation();
    //   mockGetCurrentUserSync.mockReturnValue({ firstName: "Guest", isAuthenticated: false });
    //   renderHeader();

    //   expect(screen.getByTestId("mobile-user-button")).toHaveAttribute("data-show-avatar", "false");
    // });

    // it("passes showAvatar=true to MobileUserButton when authenticated", () => {
    //   setupLocation();
    //   mockGetCurrentUserSync.mockReturnValue({ firstName: "Sarah", isAuthenticated: true });
    //   renderHeader();

    //   expect(screen.getByTestId("mobile-user-button")).toHaveAttribute("data-show-avatar", "true");
    // });
  });

  describe("mobile menu toggle", () => {
    it("MobileMenu is NOT rendered initially", () => {
      setupLocation();
      renderHeader();

      expect(screen.queryByTestId("mobile-menu")).not.toBeInTheDocument();
    });

    it("MobileMenu is rendered after clicking the hamburger", () => {
      setupLocation();
      renderHeader();

      clickHamburger();

      expect(screen.getByTestId("mobile-menu")).toBeInTheDocument();
    });

    it("hamburger aria-label is 'Close menu' when menu is open", () => {
      setupLocation();
      renderHeader();

      clickHamburger();

      expect(screen.getByRole("button", { name: "Close menu" })).toBeInTheDocument();
    });

    it("hamburger aria-label returns to 'Open menu' after closing", () => {
      setupLocation();
      renderHeader();

      clickHamburger();
      clickHamburger();

      expect(screen.getByRole("button", { name: "Open menu" })).toBeInTheDocument();
      expect(screen.queryByTestId("mobile-menu")).not.toBeInTheDocument();
    });
  });

  describe("MobileMenu onClose prop", () => {
    it("closes the mobile menu when onClose is invoked", () => {
      setupLocation();
      renderHeader();

      clickHamburger();
      expect(screen.getByTestId("mobile-menu")).toBeInTheDocument();

      expect(triggerMobileMenuClose).toBeDefined();
      act(() => {
        triggerMobileMenuClose?.();
      });

      expect(screen.queryByTestId("mobile-menu")).not.toBeInTheDocument();
    });
  });
});
