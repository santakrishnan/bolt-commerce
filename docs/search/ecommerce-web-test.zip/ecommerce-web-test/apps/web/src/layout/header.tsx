import { DEFAULT_USER, FLAG_COOKIE_NAME, mockUsers } from "@config/flags/config";
import { cookies } from "next/headers";
import { HeaderClient } from "./header/header-client";

/**
 * Read personalization cookie and
 * render HeaderClient to avoid client-side flicker.
 */
export async function Header() {
  const cookieStore = await cookies();
  const userCookie = cookieStore.get(FLAG_COOKIE_NAME);
  const user = (userCookie?.value ? mockUsers[userCookie.value] : undefined) ?? DEFAULT_USER;

  return (
    <HeaderClient
      initialFirstName={user.firstName}
      initialShowPersonalized={user.isAuthenticated === true}
    />
  );
}
