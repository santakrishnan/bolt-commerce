"use client";

import { ROUTES } from "@config/routes/constants";
import { useFavorites } from "@features/favorites";
import { Button, HeartIcon } from "@tfs-ucmp/ui";
import Link from "next/link";
import { cn } from "@/lib/utils";

/**
 * Heart button with badge — links to My Garage.
 * Only this component re-renders on favorites change.
 */
export const FavoritesButton = ({ useSolidStyles }: { useSolidStyles: boolean }) => {
  const { savedCount, isLoaded } = useFavorites();
  const isActive = isLoaded && savedCount > 0;

  let heartIconClass = cn("h-3.5 w-3.5 transition-colors");
  if (isActive) {
    heartIconClass = cn(heartIconClass, "fill-icon-primary text-icon-primary");
  } else if (useSolidStyles) {
    heartIconClass = cn(heartIconClass, "text-icon-primary");
  } else {
    heartIconClass = cn(heartIconClass, "text-[var(--color-surface)] lg:text-icon-primary");
  }

  return (
    <Button
      asChild
      className={cn(
        "relative h-10 w-10 rounded-full border transition-colors",
        useSolidStyles
          ? "border-border-light hover:bg-muted"
          : "border-overlay hover:bg-background-overlay-hover",
        isActive && "border-icon-primary"
      )}
      size="icon"
      variant="ghost"
    >
      <Link aria-label={`My Garage (${savedCount} saved)`} href={ROUTES.MY_GARAGE}>
        <HeartIcon className={heartIconClass} />
        {isActive && (
          <span className="absolute -top-1 -right-1 flex h-4.5 min-w-4.5 items-center justify-center rounded-full bg-icon-primary px-1 font-bold text-2xs text-white leading-none">
            {savedCount > 99 ? "99+" : savedCount}
          </span>
        )}
      </Link>
    </Button>
  );
};
