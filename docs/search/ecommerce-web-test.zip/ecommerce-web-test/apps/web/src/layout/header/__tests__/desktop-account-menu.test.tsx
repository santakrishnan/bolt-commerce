import { fireEvent, render, screen } from "@arrow/vitest-config/test-utils";
import type { ReactNode } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// Mock createPortal to render inline during tests
vi.mock("react-dom", async (importOriginal) => {
  const actual = await importOriginal<typeof import("react-dom")>();
  return {
    ...actual,
    createPortal: (children: ReactNode) => children,
  };
});

vi.mock("next/image", () => ({
  // Render a non-img element to avoid image-specific lint rules in tests
  default: (props: { src: string; alt: string }) => <span data-testid="mock-image" {...props} />,
}));

vi.mock("next/link", () => ({
  default: ({
    href,
    children,
    className,
    onClick,
  }: {
    href: string;
    children: ReactNode;
    className?: string;
    onClick?: () => void;
  }) => (
    <a className={className} href={href} onClick={onClick}>
      {children}
    </a>
  ),
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({
    children,
    className,
    onClick,
    variant,
  }: {
    children: ReactNode;
    className?: string;
    onClick?: () => void;
    variant?: string;
  }) => (
    <button
      className={className}
      data-testid="shadcn-button"
      data-variant={variant}
      onClick={onClick}
      type="button"
    >
      {children}
    </button>
  ),
}));

const mockSignOut = vi.fn();
vi.mock("@features/auth/lib/auth-client", () => ({
  authClient: {
    signOut: () => mockSignOut(),
  },
}));

const mockResetFeatureFlagProfileToDefault = vi.fn();
vi.mock("@features/auth/lib/feature-flag-profile", () => ({
  resetFeatureFlagProfileToDefault: () => mockResetFeatureFlagProfileToDefault(),
}));

vi.mock("@config/routes/constants", () => ({
  ROUTES: { HOME: "/" },
}));

vi.mock("../constants", () => ({
  ACCOUNT_ITEMS: [
    { label: "My Details", href: "/my-account/my-details", icon: "/icon-user.svg" },
    { label: "My Garage", href: "/my-garage", icon: "/icon-heart.svg" },
    {
      label: "Log out",
      href: "/",
      icon: "/icon-logout.svg",
      action: "logout",
    },
  ] as const,
}));

import { DesktopAccountMenu } from "../desktop-account-menu";

describe("DesktopAccountMenu", () => {
  const onClose = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
    Object.defineProperty(window, "location", {
      value: { assign: vi.fn() },
      writable: true,
    });
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("renders all account items", () => {
    render(<DesktopAccountMenu onClose={onClose} />);

    expect(screen.getByText("My Details")).toBeInTheDocument();
    expect(screen.getByText("My Garage")).toBeInTheDocument();
    expect(screen.getByText("Log out")).toBeInTheDocument();
  });

  it("renders the logout item as a shadcn Button", () => {
    render(<DesktopAccountMenu onClose={onClose} />);

    const logoutButton = screen.getByTestId("shadcn-button");
    expect(logoutButton).toBeInTheDocument();
    expect(logoutButton).toHaveAttribute("data-variant", "ghost");
  });

  it("renders non-logout items as links", () => {
    render(<DesktopAccountMenu onClose={onClose} />);

    expect(screen.getByText("My Details").closest("a")).toHaveAttribute(
      "href",
      "/my-account/my-details"
    );
    expect(screen.getByText("My Garage").closest("a")).toHaveAttribute("href", "/my-garage");
  });

  it("calls onClose when clicking the overlay", () => {
    render(<DesktopAccountMenu onClose={onClose} />);

    const overlay = document.querySelector("[aria-hidden='true']");
    expect(overlay).toBeTruthy();
    fireEvent.click(overlay as Element);

    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it("calls onClose when clicking a navigation link", () => {
    render(<DesktopAccountMenu onClose={onClose} />);

    fireEvent.click(screen.getByText("My Details").closest("a") as Element);

    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it("calls signOut, resetFeatureFlagProfileToDefault, onClose, and redirects on logout", async () => {
    mockSignOut.mockResolvedValue(undefined);

    render(<DesktopAccountMenu onClose={onClose} />);

    fireEvent.click(screen.getByTestId("shadcn-button"));

    await vi.waitFor(() => {
      expect(mockSignOut).toHaveBeenCalledTimes(1);
      expect(mockResetFeatureFlagProfileToDefault).toHaveBeenCalledTimes(1);
      expect(onClose).toHaveBeenCalledTimes(1);
      expect(window.location.assign).toHaveBeenCalledWith("/");
    });
  });

  it("still completes logout cleanup when signOut throws", async () => {
    mockSignOut.mockRejectedValue(new Error("network error"));

    render(<DesktopAccountMenu onClose={onClose} />);

    fireEvent.click(screen.getByTestId("shadcn-button"));

    await vi.waitFor(() => {
      expect(mockResetFeatureFlagProfileToDefault).toHaveBeenCalledTimes(1);
      expect(onClose).toHaveBeenCalledTimes(1);
      expect(window.location.assign).toHaveBeenCalledWith("/");
    });
  });
});
