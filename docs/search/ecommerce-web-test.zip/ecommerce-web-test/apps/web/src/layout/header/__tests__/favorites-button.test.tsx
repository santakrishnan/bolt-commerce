import { render, screen } from "@arrow/vitest-config/test-utils";
import { cloneElement, isValidElement, type ReactElement, type ReactNode } from "react";
import { describe, expect, it, vi } from "vitest";

import { FavoritesButton } from "../favorites-button";

vi.mock("next/link", () => ({
  default: ({
    href,
    className,
    children,
    "aria-label": ariaLabel,
  }: {
    href: string;
    className?: string;
    children: ReactNode;
    "aria-label"?: string;
  }) => (
    <a aria-label={ariaLabel} className={className} href={href}>
      {children}
    </a>
  ),
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({
    asChild,
    children,
    className,
    size,
    variant,
  }: {
    asChild?: boolean;
    children: ReactNode;
    className?: string;
    size?: string;
    variant?: string;
  }) => {
    if (asChild && isValidElement(children)) {
      return cloneElement(
        children as ReactElement<{
          className?: string;
          "data-size"?: string;
          "data-variant"?: string;
        }>,
        {
          className,
          "data-size": size,
          "data-variant": variant,
        }
      );
    }

    return (
      <div className={className} data-testid="mock-button">
        {children}
      </div>
    );
  },
  HeartIcon: ({ className }: { className?: string }) => (
    <svg aria-hidden="true" className={className} data-testid="heart-icon" />
  ),
}));

vi.mock("@config/routes/constants", () => ({
  ROUTES: {
    MY_GARAGE: "/my-garage",
  },
}));

const mockUseFavorites = vi.fn();
vi.mock("@features/favorites", () => ({
  useFavorites: () => mockUseFavorites(),
}));

function setup(savedCount: number, isLoaded: boolean) {
  mockUseFavorites.mockReturnValue({ savedCount, isLoaded });
}

describe("FavoritesButton", () => {
  describe("invariant structure", () => {
    it("always renders the heart icon", () => {
      setup(0, false);
      render(<FavoritesButton useSolidStyles={false} />);

      expect(screen.getByTestId("heart-icon")).toBeInTheDocument();
    });

    it("always renders a link", () => {
      setup(0, false);
      render(<FavoritesButton useSolidStyles={false} />);

      expect(screen.getByRole("link")).toBeInTheDocument();
    });

    it("link always points to /my-garage", () => {
      setup(5, true);
      render(<FavoritesButton useSolidStyles={false} />);

      expect(screen.getByRole("link")).toHaveAttribute("href", "/my-garage");
    });

    it("does not render a nested button element", () => {
      setup(5, true);
      render(<FavoritesButton useSolidStyles={false} />);

      expect(screen.queryByRole("button")).not.toBeInTheDocument();
    });
  });

  describe("aria-label", () => {
    it("reflects 0 saved items when not loaded", () => {
      setup(0, false);
      render(<FavoritesButton useSolidStyles={false} />);

      expect(screen.getByRole("link")).toHaveAttribute("aria-label", "My Garage (0 saved)");
    });

    it("reflects 0 saved items when loaded with empty list", () => {
      setup(0, true);
      render(<FavoritesButton useSolidStyles={false} />);

      expect(screen.getByRole("link")).toHaveAttribute("aria-label", "My Garage (0 saved)");
    });

    it("reflects the actual count when items are saved", () => {
      setup(3, true);
      render(<FavoritesButton useSolidStyles={false} />);

      expect(screen.getByRole("link")).toHaveAttribute("aria-label", "My Garage (3 saved)");
    });

    it("reflects count even when isLoaded=false (hook not yet resolved)", () => {
      setup(7, false);
      render(<FavoritesButton useSolidStyles={false} />);

      expect(screen.getByRole("link")).toHaveAttribute("aria-label", "My Garage (7 saved)");
    });
  });

  describe("badge (count chip)", () => {
    it("is NOT shown when isLoaded=false and savedCount=0", () => {
      setup(0, false);
      render(<FavoritesButton useSolidStyles={false} />);

      expect(screen.queryByText("0")).not.toBeInTheDocument();
    });

    it("is NOT shown when isLoaded=true and savedCount=0 (empty list)", () => {
      setup(0, true);
      render(<FavoritesButton useSolidStyles={false} />);

      expect(screen.queryByText("0")).not.toBeInTheDocument();
    });

    it("is NOT shown when isLoaded=false even if savedCount > 0 (data not ready)", () => {
      setup(5, false);
      render(<FavoritesButton useSolidStyles={false} />);

      expect(screen.queryByText("5")).not.toBeInTheDocument();
    });

    it("shows count=1 when isLoaded=true and savedCount=1", () => {
      setup(1, true);
      render(<FavoritesButton useSolidStyles={false} />);

      expect(screen.getByText("1")).toBeInTheDocument();
    });

    it("shows count=99 when savedCount is exactly 99", () => {
      setup(99, true);
      render(<FavoritesButton useSolidStyles={false} />);

      expect(screen.getByText("99")).toBeInTheDocument();
    });

    it("shows '99+' when savedCount is 100 (overflow boundary)", () => {
      setup(100, true);
      render(<FavoritesButton useSolidStyles={false} />);

      expect(screen.getByText("99+")).toBeInTheDocument();
    });

    it("shows '99+' when savedCount greatly exceeds 99", () => {
      setup(999, true);
      render(<FavoritesButton useSolidStyles={false} />);

      expect(screen.getByText("99+")).toBeInTheDocument();
    });
  });

  describe("useSolidStyles prop", () => {
    it.each([true, false])("renders without throwing when useSolidStyles=%s", (useSolidStyles) => {
      setup(0, false);
      expect(() => render(<FavoritesButton useSolidStyles={useSolidStyles} />)).not.toThrow();
    });

    it.each([
      true,
      false,
    ])("renders correctly with an active badge when useSolidStyles=%s", (useSolidStyles) => {
      setup(3, true);
      render(<FavoritesButton useSolidStyles={useSolidStyles} />);

      expect(screen.getByText("3")).toBeInTheDocument();
    });
  });
});
