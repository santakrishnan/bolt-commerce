/**
 * Centralized route path constants.
 *
 * All navigation paths used throughout the application should be imported
 * from here rather than hardcoded as string literals. This ensures
 * consistency, prevents typos, and makes refactoring easier.
 */

// ── Page Routes ──────────────────────────────────────────────────────

export const ROUTES = {
  HOME: "/",
  USED_CARS: "/used-cars",
  FINANCE: "/finance",
  ABOUT: "/about",
  USED_CARS_DETAILS: "/used-cars/details",
  FAVORITES: "/favorites",
  MY_GARAGE: "/my-garage",
  SIGN_IN: "/sign-in",
  DEALER_NOTES: "/dealer-notes",
  MY_DETAILS: "/my-account/my-details",
  PASSWORD: "/my-account/password",
  PRE_QUALIFICATION: "/my-account/pre-qualification",
  TRADE_IN_HISTORY: "/my-account/trade-in-history",
  NOTIFICATION_PREFERENCES: "/my-account/notifications",
  CREATE_ACCOUNT: "/create-account",

  /**
   * Temporary sample VDP path used as a placeholder in nav links
   * until real navigation routes are implemented.
   * TODO: Remove once actual nav routes are wired up.
   */
  TEMP_SAMPLE_VDP: "/used-cars/toyota/camry/se/2024/1G1AF1F57A7192174",
} as const;

// ── API Routes ───────────────────────────────────────────────────────

export const API_ROUTES = {
  SESSION: "/api/session",
  PROFILE: "/api/profile",
  EVENTS: "/api/events",
  EVENTS_TRACK: "/api/events/track",
  SEARCH: "/api/search",
  SEARCH_FILTERS: "/api/search/filters",
  SEARCH_BATCH_COUNTS: "/api/search/batch-counts",
  SEARCH_VEHICLE: (id: string) => `/api/search/vehicle/${id}` as const,
  SEARCH_DEALER: (vin: string) => `/api/search/dealer/${vin}` as const,
  VISITOR_PROFILE: "/api/visitor-profile",

  // ── Saved Registry (proxy → BED) ───────────────────────────────
  SAVED_VEHICLES: "/api/saved-registry/vehicles",
  SEARCH_HISTORY: "/api/saved-registry/search-history",

  // ── My Garage ──────────────────────────────────────────────────
  GARAGE_PROFILE: "/api/garage/profile",
  SIGN_UP: "/api/signup",
} as const;

/** Cookie name for the user's manual zip override (set in LocationProvider, read in layout) */
export const MANUAL_ZIP_COOKIE = "arrow_manual_zip";

/** Validates a 5-digit US zip code */
export const ZIP_RE = /^\d{5}$/;
