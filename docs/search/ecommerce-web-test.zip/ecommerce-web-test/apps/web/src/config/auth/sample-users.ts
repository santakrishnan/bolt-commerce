import type { MockUserKey } from "@config/flags/config";

/**
 * Sample user credentials for Phase 0 (development / prototyping only).
 *
 * These credentials are NEVER used in production. In Phase 1, real users will
 * be sourced from a database via Auth0.
 *
 * To add or change dev users, edit this file. The auth module seeds these users
 * into the in-memory store on startup.
 */

export interface SampleUser {
  email: string;
  featureFlagProfile: MockUserKey;
  /** Stable ID used as the user's `id` in the memory store */
  id: string;
  name: string;
  /** Plain-text password — only acceptable because this is a dev-only fixture */
  password: string;
  role: "admin" | "user";
}

export const SAMPLE_USERS: SampleUser[] = [
  {
    id: "usr_alice",
    name: "Alice Demo",
    email: "alice@example.com",
    featureFlagProfile: "authenticatedPrequalified",
    password: "Demo@1234",
    role: "admin",
  },
  {
    id: "usr_bob",
    name: "Sarah Johnson",
    email: "bob@example.com",
    featureFlagProfile: "authenticatedNotPrequalified",
    password: "Demo@1234",
    role: "user",
  },
];

export const SAMPLE_USER_FEATURE_FLAG_PROFILE_BY_EMAIL: Readonly<Record<string, MockUserKey>> =
  Object.freeze(
    Object.fromEntries(
      SAMPLE_USERS.map((user) => [user.email.toLowerCase(), user.featureFlagProfile])
    )
  );
