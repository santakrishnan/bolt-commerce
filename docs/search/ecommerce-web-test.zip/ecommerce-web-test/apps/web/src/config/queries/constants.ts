/**
 * Shared query configuration constants for saved-registry queries.
 *
 * Centralised here so saved-vehicles and search-history factories
 * (and any future saved-registry queries) stay in sync.
 */

/**
 * How long optimistically-updated saved-registry data stays fresh.
 * Mutations apply instant local updates, so a longer window avoids
 * redundant background refetches on every navigation / mount.
 */
export const SAVED_REGISTRY_STALE_TIME = 5 * 60 * 1000; // 5 minutes
