/**
 * (main) layout — includes header and footer for all non-auth pages.
 * Header and Footer have access to LocationProvider from the root layout's LocationInit.
 */
import { Footer } from "@layout/footer";
import { Header } from "@layout/header";

export default function MainLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Header />
      {children}
      <Footer />
    </>
  );
}
