import {
  customerPreQualified,
  getUserInfo,
  redirectToMyGarage,
  showPersonalizedHeroBanner,
} from "@config/flags/flags";
import {
  ArrowInspectedSectionWrapper,
  ArrowInspectedSkeleton,
  BuyingProcess,
  CustomerJourneyCarouselSection,
  CustomerJourneySkeleton,
  HomeHero,
  VehicleFinderQuickLinks,
  VehicleFinderSkeleton,
  VehicleTypeSelectorSkeleton,
  VehicleTypeSelectorWrapper,
} from "@features/landing";
import { fetchKnownUserDefaults } from "@features/landing/services/landing.service";
import { MyGarageWrapper } from "@features/my-garage";
import { resolveHeroDeviceTypeFromUserAgent } from "@shared/lib/device-type";
import dynamic from "next/dynamic";
import { headers } from "next/headers";
import { Suspense } from "react";

const AnimatedSection = dynamic(() =>
  import("@shared/components/animated-section").then((mod) => ({
    default: mod.AnimatedSection,
  }))
);

export default function HomePage() {
  return (
    <Suspense fallback={null}>
      <HomePageGateCheck />
    </Suspense>
  );
}

export async function HomePageGateCheck() {
  const headerStore = await headers();
  const deviceType = resolveHeroDeviceTypeFromUserAgent(headerStore.get("user-agent") ?? "");
  const [shouldRedirect, userInfo] = await Promise.all([redirectToMyGarage(), getUserInfo()]);

  if (shouldRedirect) {
    return (
      <MyGarageWrapper
        knownUserOverrides={{ showCards: false }}
        showUserName={userInfo.isAuthenticated}
      />
    );
  }

  return (
    <div className="bg-(--color-core-surfaces-background)">
      <Suspense
        fallback={
          <HomeHero
            deviceType={deviceType}
            showSearch={true}
            showStats={true}
            showSubtitle={true}
          />
        }
      >
        <HomeHeroPersonalized deviceType={deviceType} />
      </Suspense>

      <Suspense fallback={null}>
        <HomeBelowFoldSections />
      </Suspense>
    </div>
  );
}

async function HomeHeroPersonalized({
  deviceType,
}: {
  deviceType: "desktop" | "tablet" | "mobile";
}) {
  const [userInfo, showPersonalizedBanner, knownUserDefaults] = await Promise.all([
    getUserInfo(),
    showPersonalizedHeroBanner(),
    fetchKnownUserDefaults(),
  ]);

  const knownUserOverrides = showPersonalizedBanner
    ? {
        ...knownUserDefaults,
        userName: userInfo.firstName,
        showCards: true,
        showContinueShopping: true,
      }
    : undefined;

  return (
    <HomeHero
      deviceType={deviceType}
      knownUser={knownUserOverrides}
      showSearch={!showPersonalizedBanner}
      showStats={true}
      showSubtitle={true}
    />
  );
}

// Hidden entirely for authenticated + prequalified users.
async function HomeBelowFoldSections() {
  const [isPreQualified, userInfo] = await Promise.all([customerPreQualified(), getUserInfo()]);

  if (userInfo.isAuthenticated && isPreQualified) {
    return null;
  }

  return (
    <>
      <Suspense fallback={<VehicleTypeSelectorSkeleton />}>
        <AnimatedSection delay={0.1} staggerChildren>
          <VehicleTypeSelectorWrapper />
        </AnimatedSection>
      </Suspense>
      <BuyingProcess />
      <Suspense fallback={<VehicleFinderSkeleton />}>
        <AnimatedSection delay={0.2}>
          <VehicleFinderQuickLinks />
        </AnimatedSection>
      </Suspense>
      <Suspense fallback={<CustomerJourneySkeleton />}>
        <AnimatedSection delay={0.3} staggerChildren>
          <CustomerJourneyCarouselSection isPreQualified={isPreQualified} />
        </AnimatedSection>
      </Suspense>
      <Suspense fallback={<ArrowInspectedSkeleton />}>
        <AnimatedSection delay={0.4}>
          <ArrowInspectedSectionWrapper />
        </AnimatedSection>
      </Suspense>
    </>
  );
}
