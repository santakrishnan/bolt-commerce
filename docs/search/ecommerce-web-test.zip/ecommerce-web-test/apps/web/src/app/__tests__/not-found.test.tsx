import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import NotFound from "../not-found";

const notExistRegex = /doesn't exist/;
const returnHomeRegex = /return home/i;

vi.mock("next/link", () => ({
  __esModule: true,
  default: ({ href, children }: any) => <a href={href}>{children}</a>,
}));

describe("NotFound", () => {
  it("renders 404 and message", () => {
    render(<NotFound />);
    expect(screen.getByText("404")).toBeInTheDocument();
    expect(screen.getByText("Page Not Found")).toBeInTheDocument();
    expect(screen.getByText(notExistRegex)).toBeInTheDocument();
  });

  it("renders return home link", () => {
    render(<NotFound />);
    const link = screen.getByRole("link", { name: returnHomeRegex });
    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute("href");
  });
});
