import type { VisitorProfile } from "@features/tracking/services/visitor-profile-types";
import { NextRequest } from "next/server";
import { describe, expect, it } from "vitest";
import { createGET, POST } from "../visitor-profile/route";

// Top-level regexes for performance
const missingVisitorIdRegex = /visitorId/;
const notFoundRegex = /not found/i;
const missingFingerprintIdRegex = /fingerprintId/;

function mockRequest(url: string, opts: any = {}) {
  return Object.assign(new NextRequest(url), opts);
}

describe("/api/visitor-profile", () => {
  it("returns 400 if visitorId is missing on GET", async () => {
    const GET = createGET({ getCachedVisitorProfile: async () => null });
    const req = mockRequest("https://test/api/visitor-profile");
    const res = await GET(req);
    expect(res.status).toBe(400);
    const json = await res.json();
    expect(json.error).toMatch(missingVisitorIdRegex);
  });

  it("returns 404 if profile not found", async () => {
    const GET = createGET({ getCachedVisitorProfile: async () => null });
    const req = mockRequest("https://test/api/visitor-profile?visitorId=abc");
    const res = await GET(req);
    expect(res.status).toBe(404);
    const json = await res.json();
    expect(json.error).toMatch(notFoundRegex);
  });

  it("returns profile if found", async () => {
    const validProfile: VisitorProfile = {
      visitorId: "abc",
      profileId: "prof_123",
      firstSeen: "2024-01-01T00:00:00.000Z",
      lastSeen: "2024-01-02T00:00:00.000Z",
      visitCount: 2,
      device: undefined,
      location: undefined,
      metadata: undefined,
      tags: undefined,
      trust: undefined,
      userFlags: undefined,
    };
    const GET = createGET({ getCachedVisitorProfile: async () => validProfile });
    const req = mockRequest("https://test/api/visitor-profile?visitorId=abc");
    const res = await GET(req);
    expect(res.status).toBe(200);
    const json = await res.json();
    expect(json.profile).toBeDefined();
    expect(json.profile.visitorId).toBe("abc");
  });

  it("POST returns 400 for missing ids", async () => {
    const req = mockRequest("https://test/api/visitor-profile", {
      json: () => Promise.resolve({}),
    });
    const res = await POST(req);
    expect(res.status).toBe(400);
    const json = await res.json();
    expect(json.error).toMatch(missingFingerprintIdRegex);
  });
});
