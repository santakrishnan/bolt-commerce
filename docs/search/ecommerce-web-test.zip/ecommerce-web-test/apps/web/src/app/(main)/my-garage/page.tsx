import { getUserInfo } from "@config/flags/flags";
import { MyGarageWrapper } from "@features/my-garage";

export default async function MyGaragePage() {
  const { isAuthenticated } = await getUserInfo();

  return <MyGarageWrapper bannerHeightClass="h-[422px] lg:h-87.5" showUserName={isAuthenticated} />;
}
