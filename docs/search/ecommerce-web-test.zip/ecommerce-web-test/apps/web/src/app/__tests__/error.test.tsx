import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import ErrorBoundary from "../error";

const tryAgainRegex = /try again/i;
const errorIdRegex = /Error ID: 1234/;

describe("ErrorBoundary", () => {
  it("renders error message and reset button", () => {
    const error = new Error("Test error");
    const reset = vi.fn();
    render(<ErrorBoundary error={error} reset={reset} />);
    expect(screen.getByText("Something went wrong!")).toBeInTheDocument();
    expect(screen.getByText("Test error")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: tryAgainRegex })).toBeInTheDocument();
  });

  it("calls reset when button is clicked", () => {
    const error = new Error("Test error");
    const reset = vi.fn();
    render(<ErrorBoundary error={error} reset={reset} />);
    fireEvent.click(screen.getByRole("button", { name: tryAgainRegex }));
    expect(reset).toHaveBeenCalled();
  });

  it("shows error digest if present", () => {
    const error = Object.assign(new Error("Test error"), { digest: "1234" });
    const reset = vi.fn();
    render(<ErrorBoundary error={error} reset={reset} />);
    expect(screen.getByText(errorIdRegex)).toBeInTheDocument();
  });
});
