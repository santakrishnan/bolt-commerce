/**
 * Search API Route
 *
 * GET /api/search — Vehicle search proxy
 *
 * Query params are mapped to `SearchQuery` and forwarded to the
 * Search Service. Supports pagination, filtering, and sorting.
 *
 * Examples:
 *   GET /api/search?query=toyota&page=1&pageSize=20
 *   GET /api/search?priceMin=10000&priceMax=30000&sortBy=price&sortOrder=asc
 */

import { defaultFilterState } from "@features/search/components/filter-sidebar/types";
import { SEARCH_PAGE_SIZE } from "@features/search/lib/constants";
import { runMockFacetedSearch } from "@features/search/lib/mock-faceted-search";
import {
  ALL_FACET_SECTIONS,
  type FacetSection,
  type SearchRequest,
} from "@features/search/lib/search-types";
import { type SearchQuery, searchVehicles } from "@features/search/services";
import { ARROW_HEADER } from "@features/tracking/constants";
import { extractForwardHeaders } from "@features/tracking/lib/server-api";
import { type NextRequest, NextResponse } from "next/server";

const isDev = process.env.NODE_ENV === "development";
function noop() {
  /* no-op */
}
const log = isDev ? console.log.bind(console, "[SearchAPI]") : noop;
const logError = console.error.bind(console, "[SearchAPI]");

function parseCsvParam(value: string | null): string[] {
  if (!value) {
    return [];
  }
  return value
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

function parseFacetSections(value: string | null): FacetSection[] {
  const allowed = new Set<string>(ALL_FACET_SECTIONS);
  return parseCsvParam(value).filter((section): section is FacetSection => allowed.has(section));
}

function parseMockRequestFromQuery(params: URLSearchParams): SearchRequest {
  const page = Number.parseInt(params.get("page") ?? "1", 10);
  const pageSize = Number.parseInt(params.get("pageSize") ?? String(SEARCH_PAGE_SIZE), 10);

  const sortParam = params.get("sortOption") ?? "recommended";
  const sortOption =
    sortParam === "low-high" || sortParam === "high-low" || sortParam === "recommended"
      ? sortParam
      : "recommended";

  const filterState = {
    ...defaultFilterState,
    selectedPriceQuick: params.get("priceQuick") ?? "",
    selectedYearQuick: params.get("yearQuick") ?? "",
    selectedMileage: params.get("mileageQuick") ?? "",
    selectedBodyStyles: parseCsvParam(params.get("bodyStyles")),
    selectedExteriorColors: parseCsvParam(params.get("exteriorColors")),
    selectedInteriorColors: parseCsvParam(params.get("interiorColors")),
    selectedFuelTypes: parseCsvParam(params.get("fuelTypes")),
    selectedModels: parseCsvParam(params.get("models")),
    selectedSafetyFeatures: parseCsvParam(params.get("safetyFeatures")),
    selectedComfortFeatures: parseCsvParam(params.get("comfortFeatures")),
    selectedTechFeatures: parseCsvParam(params.get("techFeatures")),
    selectedExteriorFeatures: parseCsvParam(params.get("exteriorFeatures")),
    selectedPerformanceFeatures: parseCsvParam(params.get("performanceFeatures")),
    selectedSeatingCapacity: parseCsvParam(params.get("seatingCapacity")),
    selectedDrivetrains: parseCsvParam(params.get("drivetrains")),
    selectedTransmissions: parseCsvParam(params.get("transmissions")),
    inspection160: params.get("inspection") === "1",
  };

  const includeFacets = params.get("includeFacets");

  return {
    filterState,
    searchQuery: params.get("q") ?? params.get("query") ?? "",
    labelFilter: params.get("label") ?? "",
    sortOption,
    page: Number.isFinite(page) && page > 0 ? page : 1,
    pageSize: Number.isFinite(pageSize) && pageSize > 0 ? pageSize : SEARCH_PAGE_SIZE,
    includeFacets: includeFacets === null ? true : includeFacets === "1",
    updatedSections: parseFacetSections(params.get("updatedSections")),
  };
}

/**
 * Parse query parameters into a `SearchQuery` object.
 */
function parseSearchParams(params: URLSearchParams): SearchQuery {
  const query: SearchQuery = {};

  const q = params.get("query") ?? params.get("q");
  if (q) {
    query.query = q;
  }

  const page = params.get("page");
  if (page) {
    query.page = Number.parseInt(page, 10) || 1;
  }

  const pageSize = params.get("pageSize");
  if (pageSize) {
    query.pageSize = Number.parseInt(pageSize, 10) || SEARCH_PAGE_SIZE;
  }

  const sortBy = params.get("sortBy");
  if (sortBy && ["price", "year", "mileage", "match", "relevance"].includes(sortBy)) {
    query.sortBy = sortBy as SearchQuery["sortBy"];
  }

  const sortOrder = params.get("sortOrder");
  if (sortOrder === "asc" || sortOrder === "desc") {
    query.sortOrder = sortOrder;
  }

  const priceMin = params.get("priceMin");
  if (priceMin) {
    query.priceMin = Number.parseInt(priceMin, 10);
  }

  const priceMax = params.get("priceMax");
  if (priceMax) {
    query.priceMax = Number.parseInt(priceMax, 10);
  }

  const yearMin = params.get("yearMin");
  if (yearMin) {
    query.yearMin = Number.parseInt(yearMin, 10);
  }

  const yearMax = params.get("yearMax");
  if (yearMax) {
    query.yearMax = Number.parseInt(yearMax, 10);
  }

  const bodyStyles = params.get("bodyStyles");
  if (bodyStyles) {
    query.bodyStyles = bodyStyles.split(",").filter(Boolean);
  }

  const makes = params.get("makes");
  if (makes) {
    query.makes = makes.split(",").filter(Boolean);
  }

  const models = params.get("models");
  if (models) {
    query.models = models.split(",").filter(Boolean);
  }

  const fuelTypes = params.get("fuelTypes");
  if (fuelTypes) {
    query.fuelTypes = fuelTypes.split(",").filter(Boolean);
  }

  return query;
}

// ─── GET /api/search ────────────────────────────────────────────────────────

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const query = parseSearchParams(searchParams);

    log("Search query:", query);

    const forwardHeaders = extractForwardHeaders(request);
    const ids = {
      sessionId: request.headers.get(ARROW_HEADER.SESSION_ID) ?? null,
      fingerprintId: request.headers.get(ARROW_HEADER.FP_ID) ?? null,
      profileId: request.headers.get(ARROW_HEADER.PROFILE_ID) ?? null,
    };

    const result = await searchVehicles({
      query,
      ids,
      forwardHeaders,
    });

    return NextResponse.json(result);
  } catch (error) {
    logError("GET error:", error);
    return NextResponse.json(
      { error: "Internal server error", code: "INTERNAL_ERROR" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);

    let body: Partial<SearchRequest> = {};
    try {
      body = (await request.json()) as Partial<SearchRequest>;
    } catch {
      body = {};
    }

    const fromQuery = parseMockRequestFromQuery(searchParams);

    const querySections = fromQuery.updatedSections ?? [];
    const bodySections = body.updatedSections ?? [];

    const mergedRequest: SearchRequest = {
      ...fromQuery,
      ...body,
      filterState: {
        ...fromQuery.filterState,
        ...(body.filterState ?? {}),
      },
      updatedSections: bodySections.length > 0 ? bodySections : querySections,
    };

    const latencyMs = 200;
    await new Promise((resolve) => setTimeout(resolve, latencyMs));

    const result = await runMockFacetedSearch(mergedRequest);

    return NextResponse.json({
      ...result,
      metadata: {
        ...result.metadata,
        latencyMs,
      },
    });
  } catch (error) {
    logError("POST error:", error);
    return NextResponse.json(
      { error: "Internal server error", code: "INTERNAL_ERROR" },
      { status: 500 }
    );
  }
}
