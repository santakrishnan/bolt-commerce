import { SignIn } from "~/features/sign-in/components/signin";

export default function SignInPage() {
  return <SignIn />;
}
