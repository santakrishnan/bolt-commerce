import { CreateAccount } from "~/features/create-account/components/create-account";

export default function SignupPage() {
  return <CreateAccount />;
}
