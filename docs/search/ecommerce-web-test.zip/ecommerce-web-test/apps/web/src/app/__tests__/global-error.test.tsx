import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import GlobalError from "../global-error";

const tryAgainRegex = /try again/i;
const errorIdRegex = /Error ID: 5678/;

describe("GlobalError", () => {
  it("renders global error message and try again button", () => {
    const error = new Error("Global error");
    const reset = vi.fn();
    render(<GlobalError error={error} reset={reset} />);
    expect(screen.getByText("Application Error")).toBeInTheDocument();
    expect(
      screen.getByText("A critical error occurred. Please refresh the page.")
    ).toBeInTheDocument();
    expect(screen.getByRole("button", { name: tryAgainRegex })).toBeInTheDocument();
  });

  it("calls reset when button is clicked", () => {
    const error = new Error("Global error");
    const reset = vi.fn();
    render(<GlobalError error={error} reset={reset} />);
    fireEvent.click(screen.getByRole("button", { name: tryAgainRegex }));
    expect(reset).toHaveBeenCalled();
  });

  it("shows error digest if present", () => {
    const error = Object.assign(new Error("Global error"), { digest: "5678" });
    const reset = vi.fn();
    render(<GlobalError error={error} reset={reset} />);
    expect(screen.getByText(errorIdRegex)).toBeInTheDocument();
  });
});
