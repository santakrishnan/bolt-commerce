import { render, screen } from "@arrow/vitest-config/test-utils";
import { describe, expect, it, vi } from "vitest";

vi.mock("@layout/header", () => ({
  Header: () => <header data-testid="header">Header</header>,
}));

vi.mock("@layout/footer", () => ({
  Footer: () => <footer data-testid="footer">Footer</footer>,
}));

import MainLayout from "../layout";

describe("MainLayout", () => {
  it("renders Header, children, and Footer", () => {
    render(
      <MainLayout>
        <main data-testid="content">Page content</main>
      </MainLayout>
    );

    expect(screen.getByTestId("header")).toBeInTheDocument();
    expect(screen.getByTestId("content")).toBeInTheDocument();
    expect(screen.getByTestId("footer")).toBeInTheDocument();
  });

  it("renders Header before children and Footer after", () => {
    const { container } = render(
      <MainLayout>
        <main data-testid="content">Page content</main>
      </MainLayout>
    );

    const elements = container.querySelectorAll("[data-testid]");
    expect(elements[0]).toHaveAttribute("data-testid", "header");
    expect(elements[1]).toHaveAttribute("data-testid", "content");
    expect(elements[2]).toHaveAttribute("data-testid", "footer");
  });
});
