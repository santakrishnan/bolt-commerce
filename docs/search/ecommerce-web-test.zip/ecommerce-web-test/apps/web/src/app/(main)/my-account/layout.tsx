import { getUserInfo } from "@config/flags/flags";
import { ROUTES } from "@config/routes";
import { redirect } from "next/navigation";
import { Heading } from "@/components";
import MyAccountSidebar from "~/features/my-account/components/my-account-sidebar";

export default async function MyAccountLayout({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = await getUserInfo();

  if (!isAuthenticated) {
    redirect(ROUTES.HOME);
  }

  return (
    <div className="min-h-screen w-full bg-[var(--color-core-surfaces-background)]">
      <section className="container mx-auto max-w-[var(--container-2xl)] px-[var(--spacing-lg)] py-[var(--spacing-2xl)] lg:px-[var(--spacing-4xl)]">
        <div className="flex flex-col items-center justify-center gap-y-[var(--spacing-2xl)]">
          <div className="flex flex-col items-center justify-center gap-y-[var(--spacing-md)] lg:gap-y-[var(--spacing-lg)]">
            <Heading
              className="text-[color:var(--color-core-surfaces-foreground)] text-[length:var(--font-size-2xl)] leading-[1.15] tracking-normal lg:text-[length:var(--font-size-4xl)]"
              level={1}
              weight="semibold"
            >
              My Account
            </Heading>
            <p className="text-center text-[color:var(--color-states-muted-foreground)] text-[length:var(--font-size-sm)] leading-[1.25] tracking-[-0.01em] lg:text-[length:var(--font-size-md)]">
              Manage your profile, preferences, and activity.
            </p>
          </div>
          <div className="flex w-full flex-col lg:flex-row lg:gap-x-[var(--spacing-md)]">
            <aside className="lg:w-77">
              <MyAccountSidebar />
            </aside>
            <main className="flex-1">{children}</main>
          </div>
        </div>
      </section>
    </div>
  );
}
