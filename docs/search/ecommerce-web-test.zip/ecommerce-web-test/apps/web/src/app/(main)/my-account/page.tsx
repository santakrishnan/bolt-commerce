import { getUserInfo } from "@config/flags/flags";
import { ROUTES } from "@config/routes";
import { redirect } from "next/navigation";

export default async function MyAccountPage() {
  const { isAuthenticated } = await getUserInfo();

  if (!isAuthenticated) {
    redirect(ROUTES.HOME);
  }

  redirect(ROUTES.MY_DETAILS);
}
