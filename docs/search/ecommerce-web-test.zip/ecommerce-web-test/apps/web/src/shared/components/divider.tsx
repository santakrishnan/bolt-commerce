export function Divider({ className }: { className?: string }) {
  return <div className={`h-px w-full bg-[#E5E5E5] ${className}`} />;
}
