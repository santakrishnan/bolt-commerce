"use client";

import { createContext, use, useCallback, useMemo, useState } from "react";

interface ThemeContextValue {
  actions: {
    setTheme: (theme: "light" | "dark" | "system") => void;
  };
  meta: {
    isLoading: boolean;
  };
  state: {
    theme: "light" | "dark" | "system";
  };
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

/** Manages theme state and applies it to the document root. */
export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<"light" | "dark" | "system">("system");
  const [isLoading, setIsLoading] = useState(false);

  const setTheme = useCallback((newTheme: "light" | "dark" | "system") => {
    setIsLoading(true);
    setThemeState(newTheme);

    const root = window.document.documentElement;
    root.classList.remove("light", "dark");

    if (newTheme === "system") {
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches
        ? "dark"
        : "light";
      root.classList.add(systemTheme);
    } else {
      root.classList.add(newTheme);
    }

    setIsLoading(false);
  }, []);

  const value = useMemo<ThemeContextValue>(
    () => ({
      state: { theme },
      actions: { setTheme },
      meta: { isLoading },
    }),
    [theme, setTheme, isLoading]
  );

  return <ThemeContext value={value}>{children}</ThemeContext>;
}

/** Returns theme state and actions from the nearest ThemeProvider. */
export function useTheme() {
  const context = use(ThemeContext);
  if (!context) {
    throw new Error("useTheme must be used within ThemeProvider");
  }
  return context;
}
