import type { Vehicle, VehicleEstimation } from "./types";

/**
 * Compute a default estimation summary from the vehicle price.
 * Returns the existing estimation if already present on the vehicle.
 */
// Fallback values used only when the API does not return an estimation object.
const DEFAULT_APR = 5.49;
const DEFAULT_TERM_MONTHS = 60;
const DEFAULT_DOWN_PAYMENT = 2500;

export function getVehicleEstimation(vehicle: Vehicle): VehicleEstimation {
  if (vehicle.estimation) {
    return vehicle.estimation;
  }
  const apr = DEFAULT_APR;
  const termMonths = DEFAULT_TERM_MONTHS;
  const downPayment = DEFAULT_DOWN_PAYMENT;
  const principal = vehicle.price - downPayment;
  const monthlyRate = apr / 100 / 12;
  const monthly = Math.round((principal * monthlyRate) / (1 - (1 + monthlyRate) ** -termMonths));
  return {
    creditScore: "Excellent (800+) FICO® Score",
    apr: `${apr}%`,
    termLength: `$${downPayment.toLocaleString()}`,
    estimatedMonthlyPayment: `$${monthly}`,
  };
}
