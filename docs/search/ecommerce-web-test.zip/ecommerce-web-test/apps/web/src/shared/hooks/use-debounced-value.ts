import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Debounce a value — delays updates by `delayMs` to avoid excessive
 * re-renders during rapid changes (e.g. typing).
 *
 * Returns `[debouncedValue, flushNow]`:
 * - `debouncedValue` — the debounced value
 * - `flushNow` — call to bypass debounce and update immediately
 *   (e.g. on explicit form submit / button click)
 */
export function useDebouncedValue<T>(value: T, delayMs = 300): [T, (immediate?: T) => void] {
  const [debounced, setDebounced] = useState(value);
  const timer = useRef<number | null>(null);

  useEffect(() => {
    if (timer.current) {
      window.clearTimeout(timer.current);
    }
    timer.current = window.setTimeout(() => setDebounced(value), delayMs) as unknown as number;
    return () => {
      if (timer.current) {
        window.clearTimeout(timer.current);
      }
    };
  }, [value, delayMs]);

  // Flush immediately — cancels pending debounce and updates now.
  // Optionally accepts a value to set directly (useful when the caller
  // has a newer value than what's in state, e.g. from a ref).
  const flushNow = useCallback(
    (immediate?: T) => {
      if (timer.current) {
        window.clearTimeout(timer.current);
        timer.current = null;
      }
      setDebounced(immediate === undefined ? value : immediate);
    },
    [value]
  );

  return [debounced, flushNow];
}
