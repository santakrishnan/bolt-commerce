export type HeroDeviceType = "desktop" | "tablet" | "mobile";

const TABLET_UA_REGEX = /(ipad|tablet)/i;
const MOBILE_UA_REGEX = /(mobile|iphone|android)/i;

export function resolveHeroDeviceTypeFromUserAgent(userAgent: string): HeroDeviceType {
  const ua = userAgent.toLowerCase();

  // Tablet check before mobile because many tablet UAs include the word "mobile".
  if (TABLET_UA_REGEX.test(ua)) {
    return "tablet";
  }

  if (MOBILE_UA_REGEX.test(ua)) {
    return "mobile";
  }

  return "desktop";
}
