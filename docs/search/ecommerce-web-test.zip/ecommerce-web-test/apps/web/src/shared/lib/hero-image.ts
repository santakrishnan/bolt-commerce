export interface HeroFocalPoint {
  gravity?: string;
  x?: number;
  y?: number;
}

interface TitleSafeFocalOptions {
  desktopMinX?: number;
  mobileMaxY?: number;
}

interface FocalImageStyle {
  appliedZoom: number;
  objectPosition: string;
  targetX: number;
  targetY: number;
  transform: string;
  transformOrigin: string;
}

interface FocalCompositionOptions {
  desktopTargetX?: number;
  desktopTargetY?: number;
  mobileTargetX?: number;
  mobileTargetY?: number;
}

function clampPercentage(value: number): number {
  return Math.max(0, Math.min(100, value));
}

function clampZoom(value: number): number {
  return Math.max(1, Math.min(2, value));
}

function normalizeNumber(value: number): number {
  return Number(value.toFixed(3));
}

function resolveFocalTranslate(
  x: number,
  y: number,
  targetX: number,
  targetY: number,
  zoom: number
): string {
  const maxShift = (zoom - 1) * 50;
  const tx = Number(Math.max(-maxShift, Math.min(maxShift, targetX - x)).toFixed(3));
  const ty = Number(Math.max(-maxShift, Math.min(maxShift, targetY - y)).toFixed(3));

  return `translate(${tx}%, ${ty}%)`;
}

function resolveAdaptiveZoom(
  x: number,
  y: number,
  targetX: number,
  targetY: number,
  zoom?: number
): number {
  const baseZoom = resolveFocalZoom(zoom);
  const requiredShift = Math.max(Math.abs(targetX - x), Math.abs(targetY - y));
  const minZoomForShift = 1 + requiredShift / 50;

  return normalizeNumber(clampZoom(Math.max(baseZoom, minZoomForShift)));
}

export function resolveFocalObjectPosition(focalPoint?: HeroFocalPoint): string {
  if (!focalPoint) {
    return "50% 50%";
  }

  if (typeof focalPoint.x === "number" && typeof focalPoint.y === "number") {
    return `${clampPercentage(focalPoint.x)}% ${clampPercentage(focalPoint.y)}%`;
  }

  return "50% 50%";
}

function resolveFocalZoom(zoom?: number): number {
  if (typeof zoom !== "number" || Number.isNaN(zoom)) {
    return 1;
  }

  return clampZoom(zoom);
}

export function resolveTitleSafeFocalPoint(
  focalPoint: HeroFocalPoint | undefined,
  isMobile: boolean,
  options: TitleSafeFocalOptions = {}
): HeroFocalPoint | undefined {
  if (!focalPoint) {
    return undefined;
  }

  const x = clampPercentage(focalPoint.x ?? 50);
  const y = clampPercentage(focalPoint.y ?? 50);
  const desktopMinX = clampPercentage(options.desktopMinX ?? 58);
  const mobileMaxY = clampPercentage(options.mobileMaxY ?? 38);

  if (isMobile) {
    return { ...focalPoint, x, y: Math.min(y, mobileMaxY) };
  }

  return { ...focalPoint, x: Math.max(x, desktopMinX), y };
}

export function resolveFocalImageStyle(
  focalPoint: HeroFocalPoint | undefined,
  isMobile: boolean,
  zoom?: number,
  options: FocalCompositionOptions = {}
): FocalImageStyle {
  if (!focalPoint) {
    return {
      appliedZoom: 1,
      objectPosition: "50% 50%",
      targetX: 50,
      targetY: 50,
      transform: "translate(0%, 0%) scale(1)",
      transformOrigin: "50% 50%",
    };
  }

  const objectPosition = resolveFocalObjectPosition(focalPoint);
  const x = clampPercentage(focalPoint?.x ?? 50);
  const y = clampPercentage(focalPoint?.y ?? 50);
  const targetX = clampPercentage(
    isMobile ? (options.mobileTargetX ?? 50) : (options.desktopTargetX ?? 72)
  );
  const targetY = clampPercentage(
    isMobile ? (options.mobileTargetY ?? 24) : (options.desktopTargetY ?? 42)
  );
  const appliedZoom = resolveAdaptiveZoom(x, y, targetX, targetY, zoom);
  const translate = resolveFocalTranslate(x, y, targetX, targetY, appliedZoom);

  return {
    appliedZoom,
    objectPosition,
    targetX,
    targetY,
    transform: `${translate} scale(${appliedZoom})`,
    transformOrigin: objectPosition,
  };
}
