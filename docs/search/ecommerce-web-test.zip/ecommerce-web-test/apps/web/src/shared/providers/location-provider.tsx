"use client";

import { API_ROUTES, MANUAL_ZIP_COOKIE, ZIP_RE } from "@config/routes/constants";
import { useArrow } from "@features/tracking";
import { useArrowClient } from "@features/tracking/lib/client-api";
import stateConfig from "@shared/data/state-hero-config.json";
import { createContext, use, useCallback, useMemo, useState } from "react";

type StateKey = keyof typeof stateConfig.states;
type BackgroundImageKey = keyof typeof stateConfig.backgroundImages;
interface HeroFocalPoint {
  gravity?: string;
  x?: number;
  y?: number;
}

/** Persists the manual zip override to a cookie with a 30-day expiry. */
function saveManualZipToCookie(zip: string) {
  if (typeof document === "undefined") {
    return;
  }
  const expires = new Date();
  expires.setDate(expires.getDate() + 30);
  const cookieValue = `${MANUAL_ZIP_COOKIE}=${encodeURIComponent(zip)}; expires=${expires.toUTCString()}; path=/; SameSite=Lax`;
  (document as { cookie: string }).cookie = cookieValue;
}

function clearManualZipCookie() {
  if (typeof document === "undefined") {
    return;
  }
  const cookieValue = `${MANUAL_ZIP_COOKIE}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; SameSite=Lax`;
  (document as { cookie: string }).cookie = cookieValue;
}

/** Returns the hero state for a given zip using zipPrefix ranges; falls back to the config default. */
function resolveHeroState(zip: string): StateKey {
  const prefix = Number.parseInt(zip.slice(0, 3), 10);
  if (!Number.isNaN(prefix)) {
    for (const [state, range] of Object.entries(stateConfig.zipPrefixes) as [
      StateKey,
      { min: number; max: number },
    ][]) {
      if (prefix >= range.min && prefix <= range.max) {
        return state;
      }
    }
  }
  return stateConfig.defaultState as StateKey;
}

function resolveBackgroundImageKey(state: StateKey): BackgroundImageKey {
  const stateEntry = stateConfig.states[state];
  const key = stateEntry?.backgroundImageKey as BackgroundImageKey | undefined;
  if (key && key in stateConfig.backgroundImages) {
    return key;
  }
  // Fallback to the first available key in backgroundImages (always exists)
  const keys = Object.keys(stateConfig.backgroundImages) as BackgroundImageKey[];
  return keys[0] ?? ("west" as BackgroundImageKey);
}

function resolveBackgroundImages(imageKey: BackgroundImageKey) {
  return stateConfig.backgroundImages[imageKey];
}

export interface LocationContextValue {
  actions: {
    /**
     * Manually override the displayed zip and save to cookie.
     * This takes precedence over fingerprint data.
     */
    setZip: (zip: string) => void;
    /**
     * Clear manual zip override and revert to fingerprint data.
     */
    clearManualZip: () => void;
  };
  state: {
    /** Fingerprint-detected or user-entered zip code */
    displayZip: string;
    /** City from fingerprint geo */
    displayCity: string;
    /** State abbreviation from fingerprint geo */
    displayState: string;
    /** Hero state resolved from zip — drives background image */
    heroState: StateKey;
    /** Key used to look up background images in the config */
    backgroundImageKey: BackgroundImageKey;
    backgroundImage: string;
    mobileBackgroundImage: string;
    backgroundFocalPoint?: HeroFocalPoint;
    mobileBackgroundFocalPoint?: HeroFocalPoint;
    backgroundZoom?: number;
    mobileBackgroundZoom?: number;
    /** True if using manual zip override from cookie */
    isManualZip: boolean;
    /** Description from state config (e.g., "Miami, FL 33101") - shown for manual zip */
    description?: string;
    /** Whether location has been resolved from cookie or fingerprint (not just the default) */
    isResolved: boolean;
  };
}

const LocationContext = createContext<LocationContextValue | null>(null);

/**
 * Provides location data derived from Arrow fingerprint context.
 * Manual zip overrides (stored in a cookie) take precedence over fingerprint data.
 */
export function LocationProvider({
  children,
  initialZip = null,
}: {
  children: React.ReactNode;
  /** Server-read cookie value — passed from layout.tsx so the first HTML paint is correct. */
  initialZip?: string | null;
}) {
  const defaultState = stateConfig.defaultState as StateKey;
  const defaultZip = stateConfig.states[defaultState].zipCode;

  const { fingerprintData, isReady: arrowReady } = useArrow();
  const api = useArrowClient();

  // Server-read cookie value passed as a prop to avoid flash of default zip on first paint.
  const [manualZip, setManualZip] = useState<string | null>(initialZip);

  const geo = fingerprintData?.geo;
  const fpZip = geo?.postalCode ?? "";
  const fpCity = geo?.city ?? "";
  const fpState = geo?.stateCode ?? "";

  const isManualZip = manualZip !== null;
  const displayZip = manualZip ?? (ZIP_RE.test(fpZip) ? fpZip : defaultZip);
  const displayCity = manualZip ? "" : fpCity; // clear city when user overrides
  const displayState = manualZip ? "" : fpState;

  // Resolved once a manual zip exists or Arrow has initialized — prevents flash of default zip.
  const isResolved = manualZip !== null || arrowReady;

  /** Overrides zip, saves to cookie, and fires a tracking event. */
  const setZip = useCallback(
    (zip: string) => {
      const clean = zip.trim();
      if (!(clean && ZIP_RE.test(clean))) {
        return;
      }
      const previousZip = manualZip ?? fpZip;
      const heroState = resolveHeroState(clean);

      setManualZip(clean);
      saveManualZipToCookie(clean);

      api
        .post(API_ROUTES.EVENTS_TRACK, {
          event: "location_zip_changed",
          properties: {
            previousZip,
            newZip: clean,
            heroState,
            isManualOverride: true,
          },
          timestamp: Date.now(),
        })
        .catch((error: unknown) => {
          console.error("[LocationProvider] Failed to track zip change event:", error);
        });
    },
    [manualZip, fpZip, api]
  );

  /** Clears the manual zip, reverts to fingerprint data, and fires a tracking event. */
  const clearManualZip = useCallback(() => {
    const previousZip = manualZip;
    const revertedZip = ZIP_RE.test(fpZip) ? fpZip : defaultZip;
    const heroState = resolveHeroState(revertedZip);

    setManualZip(null);
    clearManualZipCookie();

    if (previousZip) {
      api
        .post(API_ROUTES.EVENTS_TRACK, {
          event: "location_zip_cleared",
          properties: {
            previousZip,
            revertedZip,
            heroState,
            revertedToFingerprint: ZIP_RE.test(fpZip),
          },
          timestamp: Date.now(),
        })
        .catch((error: unknown) => {
          console.error("[LocationProvider] Failed to track zip clear event:", error);
        });
    }
  }, [manualZip, fpZip, defaultZip, api]);

  const heroState = resolveHeroState(displayZip);
  const heroData = stateConfig.states[heroState];

  const description = isManualZip ? heroData?.description : undefined;
  const imageKey = resolveBackgroundImageKey(heroState);
  const imageSet = resolveBackgroundImages(imageKey);

  const value: LocationContextValue = useMemo(
    () => ({
      state: {
        displayZip,
        displayCity,
        displayState,
        heroState,
        backgroundImageKey: imageKey,
        backgroundImage: imageSet?.desktop ?? "",
        mobileBackgroundImage: imageSet?.mobile ?? "",
        backgroundFocalPoint: imageSet?.focalPoint?.desktop,
        mobileBackgroundFocalPoint: imageSet?.focalPoint?.mobile,
        backgroundZoom: imageSet?.zoom?.desktop,
        mobileBackgroundZoom: imageSet?.zoom?.mobile,
        isManualZip,
        description,
        isResolved,
      },
      actions: { setZip, clearManualZip },
    }),
    [
      displayZip,
      displayCity,
      displayState,
      heroState,
      imageKey,
      imageSet,
      isManualZip,
      description,
      isResolved,
      setZip,
      clearManualZip,
    ]
  );

  return <LocationContext.Provider value={value}>{children}</LocationContext.Provider>;
}

/** Returns location state and actions from the nearest LocationProvider. */
export function useLocation() {
  const context = use(LocationContext);
  if (!context) {
    throw new Error("useLocation must be used within LocationProvider");
  }
  return context;
}
