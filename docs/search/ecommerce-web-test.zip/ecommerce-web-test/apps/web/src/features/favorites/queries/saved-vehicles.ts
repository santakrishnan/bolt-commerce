import { SAVED_REGISTRY_STALE_TIME } from "@config/queries/constants";
import { getAllSavedVehicles } from "@features/favorites/services/saved-vehicles-api";
import { queryOptions, skipToken } from "@tanstack/react-query";

/**
 * Returns react-query options for fetching saved vehicle VINs.
 * Provides placeholderData and staleTime to control caching and avoid SSR fetches.
 */
export const savedVehicleQueries = {
  all: () =>
    queryOptions({
      queryKey: ["saved-vehicles"] as const,
      queryFn: typeof window === "undefined" ? skipToken : getAllSavedVehicles,
      placeholderData: [] as string[],
      staleTime: SAVED_REGISTRY_STALE_TIME,
    }),
} as const;
