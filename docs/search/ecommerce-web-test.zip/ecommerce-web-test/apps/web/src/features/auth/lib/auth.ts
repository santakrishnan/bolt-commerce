import { SAMPLE_USERS } from "@config/auth/sample-users";
import { betterAuth } from "better-auth";
import type { MemoryDB } from "better-auth/adapters/memory";
import { memoryAdapter } from "better-auth/adapters/memory";

/**
 * Module-level in-memory store.
 *
 * Persists for the lifetime of the Node.js process (survives per-request
 * re-execution, but resets on server restart). Acceptable for Phase 0.
 */
const db: MemoryDB = {
  user: [],
  session: [],
  account: [],
  verification: [],
};

export const auth = betterAuth({
  secret: process.env.BETTER_AUTH_SECRET ?? "dev-secret-change-in-production",
  baseURL: process.env.BETTER_AUTH_URL ?? "http://localhost:3000",
  database: memoryAdapter(db),
  emailAndPassword: {
    enabled: true,
    requireEmailVerification: false,
  },
});

// ── Phase 0 sample-user seeding ──────────────────────────────────────────────
// Seeds SAMPLE_USERS into the memory store at module-init time.
// - Exported so tests can await completion before asserting sign-in behaviour.
// - Guarded by NODE_ENV so it never runs in production.
// - Safe to call multiple times (sign-up errors on duplicate email are swallowed).

async function seedSampleUsers(): Promise<void> {
  for (const user of SAMPLE_USERS) {
    try {
      await auth.api.signUpEmail({
        body: { email: user.email, password: user.password, name: user.name },
      });
    } catch {
      // Duplicate e-mail (e.g. HMR re-import) — ignore.
    }
  }
}

export const seedReady: Promise<void> =
  process.env.NODE_ENV === "production" ? Promise.resolve() : seedSampleUsers();
