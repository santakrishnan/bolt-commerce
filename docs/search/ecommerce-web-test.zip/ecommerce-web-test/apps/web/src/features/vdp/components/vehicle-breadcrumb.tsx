import type { VdpParams } from "@config/routes";
import { ROUTES } from "@config/routes/constants";
import { capitalize } from "@shared/lib/formatters";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@tfs-ucmp/ui";
import Image from "next/image";
import Link from "next/link";
import type React from "react";

export interface VehicleBreadcrumbListProps {
  slugParams: VdpParams;
}

export const VehicleBreadcrumbList: React.FC<VehicleBreadcrumbListProps> = ({ slugParams }) => {
  return (
    <Breadcrumb>
      <BreadcrumbList className="hidden gap-[var(--spacing-sm)] text-[var(--font-size-sm)] md:flex">
        <BreadcrumbItem>
          <BreadcrumbPage className="font-[var(--font-weight-normal)] text-[var(--color-states-disabled-foreground)]">
            {slugParams.year}
          </BreadcrumbPage>
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Image
            alt="Breadcrumb separator"
            aria-hidden="true"
            className="mt-[calc(var(--spacing-2xs)/2)] h-[12px] w-[12px]"
            height={12}
            src="/images/vdp/vdp_arrow_right_gray.svg"
            width={12}
          />
        </BreadcrumbSeparator>
        <BreadcrumbItem>
          <BreadcrumbLink
            asChild
            className="font-[var(--font-weight-normal)] text-[var(--color-states-disabled-foreground)]"
          >
            <Link href={`${ROUTES.USED_CARS}/${slugParams.make}`}>
              {capitalize(slugParams.make)}
            </Link>
          </BreadcrumbLink>
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Image
            alt="Breadcrumb separator"
            aria-hidden="true"
            className="mt-[calc(var(--spacing-2xs)/2)] h-[12px] w-[12px]"
            height={12}
            src="/images/vdp/vdp_arrow_right_gray.svg"
            width={12}
          />
        </BreadcrumbSeparator>
        <BreadcrumbItem>
          <BreadcrumbLink
            asChild
            className="font-[var(--font-weight-normal)] text-[var(--color-states-disabled-foreground)]"
          >
            <Link href={`${ROUTES.USED_CARS}?make=${slugParams.make}&model=${slugParams.model}`}>
              {capitalize(slugParams.model)}
            </Link>
          </BreadcrumbLink>
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Image
            alt="Breadcrumb separator"
            aria-hidden="true"
            className="mt-[calc(var(--spacing-2xs)/2)] h-[12px] w-[12px]"
            height={12}
            src="/images/vdp/vdp_arrow_right_gray.svg"
            width={12}
          />
        </BreadcrumbSeparator>
        <BreadcrumbItem>
          <BreadcrumbPage className="font-[var(--font-weight-normal)] text-[var(--color-states-disabled-foreground)]">
            {slugParams.trimSlug ? slugParams.trimSlug.toUpperCase() : ""}
          </BreadcrumbPage>
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Image
            alt="Breadcrumb separator"
            aria-hidden="true"
            className="mt-[calc(var(--spacing-2xs)/2)] h-[12px] w-[12px]"
            height={12}
            src="/images/vdp/vdp_arrow_right_gray.svg"
            width={12}
          />
        </BreadcrumbSeparator>
        <BreadcrumbItem>
          <BreadcrumbPage className="font-[var(--font-weight-semibold)] text-[var(--color-core-surfaces-foreground)]">
            {slugParams.vin}
          </BreadcrumbPage>
        </BreadcrumbItem>
      </BreadcrumbList>
    </Breadcrumb>
  );
};
