// ── Public API for the vehicle-preview feature ───────────────────────
export {
  VehiclePreviewModal,
  type VehiclePreviewModalProps,
} from "./components/vehicle-preview-modal";
