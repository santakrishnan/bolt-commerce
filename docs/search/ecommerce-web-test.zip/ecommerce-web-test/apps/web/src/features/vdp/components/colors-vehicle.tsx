import type React from "react";

function isLightColor(color?: string): boolean {
  if (!color) {
    return false;
  }
  const hex = color.replace("#", "");
  if (hex.length !== 6) {
    return false;
  }
  const r = Number.parseInt(hex.slice(0, 2), 16);
  const g = Number.parseInt(hex.slice(2, 4), 16);
  const b = Number.parseInt(hex.slice(4, 6), 16);
  const brightness = (r * 299 + g * 587 + b * 114) / 1000;
  return brightness > 128;
}

export interface VehicleColorsProps {
  className?: string;
  exteriorColorCode?: string;
  exteriorName: string;
  interiorColorCode?: string;
  interiorName: string;
}

export const VehicleColors: React.FC<VehicleColorsProps> = ({
  exteriorName,
  interiorName,
  exteriorColorCode,
  interiorColorCode,
  className = "flex gap-lg lg:gap-10",
}) => {
  return (
    <div className={className}>
      <div className="flex items-center gap-[var(--spacing-sm)]">
        <div
          className={`h-[var(--size-avatar-sm)] w-[var(--size-avatar-sm)] shrink-0 rounded-[var(--radius-full)] lg:h-[var(--size-swatch)] lg:w-[var(--size-swatch)] ${isLightColor(exteriorColorCode) ? "border border-[var(--color-states-muted)]" : ""}`}
          style={{ backgroundColor: exteriorColorCode }}
        />
        <div className="flex flex-col">
          <p className="font-[var(--font-weight-semibold)] text-[length:var(--font-size-xs)] text-[var(--color-states-muted-foreground)] capitalize">
            Exterior
          </p>
          <span className="font-[var(--font-weight-semibold)] text-[length:var(--font-size-sm)] text-[var(--color-core-surfaces-foreground)] leading-normal">
            {exteriorName}
          </span>
        </div>
      </div>
      <div className="flex items-center gap-[var(--spacing-sm)]">
        <div
          className={`h-[var(--size-avatar-sm)] w-[var(--size-avatar-sm)] shrink-0 rounded-[var(--radius-full)] lg:h-[var(--size-swatch)] lg:w-[var(--size-swatch)] ${isLightColor(interiorColorCode) ? "border border-[var(--color-states-muted)]" : ""}`}
          style={{ backgroundColor: interiorColorCode }}
        />
        <div className="flex flex-col">
          <p className="font-[var(--font-weight-semibold)] text-[length:var(--font-size-xs)] text-[var(--color-states-muted-foreground)] capitalize">
            Interior
          </p>
          <span className="font-[var(--font-weight-semibold)] text-[length:var(--font-size-sm)] text-[var(--color-core-surfaces-foreground)] leading-normal">
            {interiorName}
          </span>
        </div>
      </div>
    </div>
  );
};
