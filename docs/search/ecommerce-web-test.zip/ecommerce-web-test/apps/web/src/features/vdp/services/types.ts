/** VDP service types — re-exported from canonical data types. */

export type {
  FeatureCategory,
  HistoryData,
  PriceHistoryEntry,
  PricingData,
  RatingData,
  RatingDistribution,
  VehicleDetail,
  VehicleSpecData,
  VehicleStatusData,
  VinData,
} from "../data/types";
