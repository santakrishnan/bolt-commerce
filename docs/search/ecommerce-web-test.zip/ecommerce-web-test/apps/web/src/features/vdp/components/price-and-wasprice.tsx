import type React from "react";

export interface VehiclePriceProps {
  className?: string;
  originalPrice?: number | null;
  price: number;
  priceClassName?: string;
}

export const VehiclePrice: React.FC<VehiclePriceProps> = ({
  price,
  originalPrice,
  className = "mt-2xs flex items-baseline gap-xs",
  priceClassName = "font-bold text-[length:var(--font-size-2xl)] text-[var(--color-actions-accent)] leading-[115%]",
}) => {
  return (
    <div className={className}>
      <span className={priceClassName}>${(price ?? 0).toLocaleString()}</span>
      {originalPrice != null && originalPrice > (price ?? 0) && (
        <>
          <span className="text-[length:var(--font-size-sm)] text-[var(--color-states-muted-foreground)]">
            was
          </span>
          <span className="text-[length:var(--font-size-sm)] text-[var(--color-states-muted-foreground)] line-through">
            ${originalPrice.toLocaleString()}
          </span>
        </>
      )}
    </div>
  );
};
