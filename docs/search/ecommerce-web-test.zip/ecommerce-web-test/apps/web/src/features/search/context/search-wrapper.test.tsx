import { act, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { FilterState } from "../components/filter-sidebar/types";
import { defaultFilterState } from "../components/filter-sidebar/types";
import { SearchWrapper } from "./search-wrapper";

// ---------------------------------------------------------------------------
// Mock async dependencies so SearchWrapper resolves synchronously in tests
// ---------------------------------------------------------------------------

vi.mock("@features/search/services/srp-initial-data", () => ({
  fetchInitialSrpResults: vi.fn(async () => ({
    vehicles: [],
    totalCount: 0,
    appliedFilters: [],
    metadata: {
      inventorySize: 100,
      searchId: "test-search-id",
      queryTimeMs: 10,
      version: "mock-v1",
      latencyMs: 0,
    },
  })),
  fetchQuickFilterPills: vi.fn(() => []),
}));

vi.mock("next/cache", () => ({
  cacheLife: () => undefined,
  cacheTag: () => undefined,
}));

// ---------------------------------------------------------------------------
// Mock child components
// ---------------------------------------------------------------------------

vi.mock("./search-client", () => ({
  SearchClient: ({ initialQuickFilters }: any) => (
    <div data-filters={JSON.stringify(initialQuickFilters)} data-testid="search-client">
      Search Client
    </div>
  ),
}));

let capturedProviderProps: any = null;

vi.mock("./search-context", () => ({
  SearchProvider: ({ children, ...props }: any) => {
    capturedProviderProps = props;
    return <div data-testid="search-provider">{children}</div>;
  },
}));

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

async function renderSearchWrapper(props?: {
  initialBodyType?: string;
  initialSearchQuery?: string;
  initialUrlFilters?: Partial<FilterState>;
}) {
  let result: ReturnType<typeof render> | undefined;
  await act(async () => {
    const jsx = await SearchWrapper(props ?? {});
    result = render(jsx as React.ReactElement);
  });
  if (!result) {
    throw new Error("SearchWrapper render returned undefined");
  }
  return result;
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("SearchWrapper", () => {
  beforeEach(() => {
    capturedProviderProps = null;
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  describe("Component rendering", () => {
    it("should render SearchProvider and SearchClient", async () => {
      await renderSearchWrapper();
      expect(screen.getByTestId("search-provider")).toBeInTheDocument();
      expect(screen.getByTestId("search-client")).toBeInTheDocument();
    });

    it("should wrap SearchClient in Suspense", async () => {
      await renderSearchWrapper();
      expect(screen.getByTestId("search-client")).toBeInTheDocument();
    });
  });

  describe("Default initialization", () => {
    it("should initialize with default values when no props provided", async () => {
      await renderSearchWrapper();
      expect(capturedProviderProps.defaultFilterState).toEqual(defaultFilterState);
      expect(capturedProviderProps.initialBodyStyles).toEqual([]);
      expect(capturedProviderProps.initialSearchQuery).toBe("");
      expect(capturedProviderProps.initialUrlFilters).toBeUndefined();
    });

    it("should pass defaultFilterState to SearchProvider", async () => {
      await renderSearchWrapper();
      expect(capturedProviderProps.defaultFilterState).toBe(defaultFilterState);
    });
  });

  describe("Body type initialization", () => {
    it("should resolve body type slug to proper label", async () => {
      await renderSearchWrapper({ initialBodyType: "sedan" });
      expect(capturedProviderProps.initialBodyStyles).toEqual(["Sedan"]);
    });

    it("should handle uppercase body type slug", async () => {
      await renderSearchWrapper({ initialBodyType: "SUV" });
      expect(capturedProviderProps.initialBodyStyles).toEqual(["SUV"]);
    });

    it("should handle mixed case body type slug", async () => {
      await renderSearchWrapper({ initialBodyType: "TrUcK" });
      expect(capturedProviderProps.initialBodyStyles).toEqual(["Truck"]);
    });

    it("should handle all valid body types", async () => {
      const bodyTypes = [
        "sedan",
        "suv",
        "truck",
        "coupe",
        "hatchback",
        "wagon",
        "van",
        "convertible",
      ];
      for (const bodyType of bodyTypes) {
        capturedProviderProps = null;
        await renderSearchWrapper({ initialBodyType: bodyType });
        expect(capturedProviderProps.initialBodyStyles).toHaveLength(1);
      }
    });

    it("should ignore invalid body type slug", async () => {
      await renderSearchWrapper({ initialBodyType: "invalid-type" });
      expect(capturedProviderProps.initialBodyStyles).toEqual([]);
    });

    it("should handle empty body type", async () => {
      await renderSearchWrapper({ initialBodyType: "" });
      expect(capturedProviderProps.initialBodyStyles).toEqual([]);
    });
  });

  describe("Search query initialization", () => {
    it("should pass search query to SearchProvider", async () => {
      await renderSearchWrapper({ initialSearchQuery: "Toyota Camry" });
      expect(capturedProviderProps.initialSearchQuery).toBe("Toyota Camry");
    });

    it("should handle empty search query", async () => {
      await renderSearchWrapper({ initialSearchQuery: "" });
      expect(capturedProviderProps.initialSearchQuery).toBe("");
    });

    it("should handle undefined search query", async () => {
      await renderSearchWrapper({ initialSearchQuery: undefined });
      expect(capturedProviderProps.initialSearchQuery).toBe("");
    });

    it("should handle long search query", async () => {
      const longQuery = "Toyota Camry 2022 with leather seats and navigation system";
      await renderSearchWrapper({ initialSearchQuery: longQuery });
      expect(capturedProviderProps.initialSearchQuery).toBe(longQuery);
    });
  });

  describe("URL filters initialization", () => {
    it("should pass URL filters to SearchProvider", async () => {
      const urlFilters: Partial<FilterState> = {
        selectedPriceQuick: "10000-20000",
        selectedYearQuick: "2020-2023",
      };
      await renderSearchWrapper({ initialUrlFilters: urlFilters });
      expect(capturedProviderProps.initialUrlFilters).toEqual(urlFilters);
    });

    it("should merge URL filter body styles with path-based body type", async () => {
      await renderSearchWrapper({
        initialBodyType: "sedan",
        initialUrlFilters: { selectedBodyStyles: ["SUV", "Truck"] },
      });
      expect(capturedProviderProps.initialBodyStyles).toEqual(["Sedan", "SUV", "Truck"]);
    });

    it("should deduplicate body styles when merging", async () => {
      await renderSearchWrapper({
        initialBodyType: "sedan",
        initialUrlFilters: { selectedBodyStyles: ["Sedan", "SUV"] },
      });
      expect(capturedProviderProps.initialBodyStyles).toEqual(["Sedan", "SUV"]);
    });

    it("should handle URL filters without body styles", async () => {
      await renderSearchWrapper({
        initialBodyType: "sedan",
        initialUrlFilters: { selectedPriceQuick: "10000-20000" },
      });
      expect(capturedProviderProps.initialBodyStyles).toEqual(["Sedan"]);
    });

    it("should handle empty URL filters", async () => {
      await renderSearchWrapper({ initialUrlFilters: {} });
      expect(capturedProviderProps.initialUrlFilters).toEqual({});
    });

    it("should handle all filter types", async () => {
      const urlFilters: Partial<FilterState> = {
        selectedPriceQuick: "10000-20000",
        selectedYearQuick: "2020-2023",
        selectedMileage: "0-50000",
        selectedBodyStyles: ["Sedan"],
        selectedExteriorColors: ["Blue"],
        selectedInteriorColors: ["Black"],
        selectedFuelTypes: ["Gasoline"],
        selectedModels: ["Camry"],
        selectedSafetyFeatures: ["ABS"],
        selectedComfortFeatures: ["Heated Seats"],
        selectedTechFeatures: ["Bluetooth"],
        selectedExteriorFeatures: ["Sunroof"],
        selectedPerformanceFeatures: ["Turbo"],
        selectedSeatingCapacity: ["5"],
        selectedDrivetrains: ["AWD"],
        selectedTransmissions: ["Automatic"],
        inspection160: true,
      };
      await renderSearchWrapper({ initialUrlFilters: urlFilters });
      expect(capturedProviderProps.initialUrlFilters).toEqual(urlFilters);
    });
  });

  describe("Component key generation", () => {
    it("should generate unique key based on props", async () => {
      const { container } = await renderSearchWrapper({
        initialBodyType: "sedan",
        initialSearchQuery: "Toyota",
      });
      // key is passed as a React prop, not a DOM attribute — verify via capturedProviderProps
      expect(capturedProviderProps).not.toBeNull();
      expect(container.querySelector('[data-testid="search-client"]')).toBeInTheDocument();
    });

    it("should generate different keys for different body types", async () => {
      // key is a React internal prop — verify the component re-renders with different state
      capturedProviderProps = null;
      await renderSearchWrapper({ initialBodyType: "sedan" });
      const styles1 = capturedProviderProps.initialBodyStyles;

      capturedProviderProps = null;
      await renderSearchWrapper({ initialBodyType: "suv" });
      const styles2 = capturedProviderProps.initialBodyStyles;

      expect(styles1).not.toEqual(styles2);
    });

    it("should generate different keys for different search queries", async () => {
      capturedProviderProps = null;
      await renderSearchWrapper({ initialSearchQuery: "Toyota" });
      const q1 = capturedProviderProps.initialSearchQuery;

      capturedProviderProps = null;
      await renderSearchWrapper({ initialSearchQuery: "Honda" });
      const q2 = capturedProviderProps.initialSearchQuery;

      expect(q1).not.toBe(q2);
    });

    it("should generate different keys for different URL filters", async () => {
      capturedProviderProps = null;
      await renderSearchWrapper({ initialUrlFilters: { selectedPriceQuick: "10000-20000" } });
      const f1 = capturedProviderProps.initialUrlFilters;

      capturedProviderProps = null;
      await renderSearchWrapper({ initialUrlFilters: { selectedPriceQuick: "20000-30000" } });
      const f2 = capturedProviderProps.initialUrlFilters;

      expect(f1).not.toEqual(f2);
    });

    it("should generate same key for same props", async () => {
      const props = {
        initialBodyType: "sedan",
        initialSearchQuery: "Toyota",
        initialUrlFilters: { selectedPriceQuick: "10000-20000" },
      };

      capturedProviderProps = null;
      await renderSearchWrapper(props);
      const styles1 = capturedProviderProps.initialBodyStyles;
      const q1 = capturedProviderProps.initialSearchQuery;

      capturedProviderProps = null;
      await renderSearchWrapper(props);
      const styles2 = capturedProviderProps.initialBodyStyles;
      const q2 = capturedProviderProps.initialSearchQuery;

      expect(styles1).toEqual(styles2);
      expect(q1).toBe(q2);
    });
  });

  describe("Complex scenarios", () => {
    it("should handle all props together", async () => {
      await renderSearchWrapper({
        initialBodyType: "sedan",
        initialSearchQuery: "Toyota Camry",
        initialUrlFilters: {
          selectedPriceQuick: "10000-20000",
          selectedYearQuick: "2020-2023",
          selectedBodyStyles: ["SUV"],
        },
      });
      expect(capturedProviderProps.initialBodyStyles).toEqual(["Sedan", "SUV"]);
      expect(capturedProviderProps.initialSearchQuery).toBe("Toyota Camry");
      expect(capturedProviderProps.initialUrlFilters.selectedPriceQuick).toBe("10000-20000");
    });

    it("should handle body type with multiple URL filter body styles", async () => {
      await renderSearchWrapper({
        initialBodyType: "sedan",
        initialUrlFilters: { selectedBodyStyles: ["SUV", "Truck", "Coupe"] },
      });
      expect(capturedProviderProps.initialBodyStyles).toEqual(["Sedan", "SUV", "Truck", "Coupe"]);
    });

    it("should preserve order when merging body styles", async () => {
      await renderSearchWrapper({
        initialBodyType: "truck",
        initialUrlFilters: { selectedBodyStyles: ["Sedan", "SUV"] },
      });
      expect(capturedProviderProps.initialBodyStyles).toEqual(["Truck", "Sedan", "SUV"]);
    });
  });

  describe("Edge cases", () => {
    it("should handle null props", async () => {
      await renderSearchWrapper({
        initialBodyType: undefined,
        initialSearchQuery: undefined,
        initialUrlFilters: undefined,
      });
      expect(capturedProviderProps.initialBodyStyles).toEqual([]);
      expect(capturedProviderProps.initialSearchQuery).toBe("");
      expect(capturedProviderProps.initialUrlFilters).toBeUndefined();
    });

    it("should handle whitespace in body type", async () => {
      await renderSearchWrapper({ initialBodyType: "  sedan  " });
      expect(capturedProviderProps.initialBodyStyles).toEqual([]);
    });

    it("should handle body type with special characters", async () => {
      await renderSearchWrapper({ initialBodyType: "sedan-special" });
      expect(capturedProviderProps.initialBodyStyles).toEqual([]);
    });

    it("should handle empty array in URL filter body styles", async () => {
      await renderSearchWrapper({
        initialBodyType: "sedan",
        initialUrlFilters: { selectedBodyStyles: [] },
      });
      expect(capturedProviderProps.initialBodyStyles).toEqual(["Sedan"]);
    });

    it("should handle very long URL filter object", async () => {
      const urlFilters: Partial<FilterState> = {
        selectedBodyStyles: Array.from({ length: 100 }, (_, i) => `Style${i}`),
        selectedModels: Array.from({ length: 100 }, (_, i) => `Model${i}`),
      };
      await renderSearchWrapper({ initialUrlFilters: urlFilters });
      expect(capturedProviderProps.initialUrlFilters).toEqual(urlFilters);
    });
  });

  describe("Remounting behavior", () => {
    it("should remount SearchClient when key changes", async () => {
      capturedProviderProps = null;
      await renderSearchWrapper({ initialBodyType: "sedan" });
      const styles1 = [...capturedProviderProps.initialBodyStyles];

      capturedProviderProps = null;
      await renderSearchWrapper({ initialBodyType: "suv" });
      const styles2 = [...capturedProviderProps.initialBodyStyles];

      expect(styles1).not.toEqual(styles2);
    });

    it("should not remount SearchClient when props are the same", async () => {
      const props = { initialBodyType: "sedan" };

      capturedProviderProps = null;
      await renderSearchWrapper(props);
      const styles1 = [...capturedProviderProps.initialBodyStyles];

      capturedProviderProps = null;
      await renderSearchWrapper(props);
      const styles2 = [...capturedProviderProps.initialBodyStyles];

      expect(styles1).toEqual(styles2);
    });
  });

  describe("Case sensitivity", () => {
    it("should handle lowercase body type", async () => {
      await renderSearchWrapper({ initialBodyType: "sedan" });
      expect(capturedProviderProps.initialBodyStyles).toEqual(["Sedan"]);
    });

    it("should handle uppercase body type", async () => {
      await renderSearchWrapper({ initialBodyType: "SEDAN" });
      expect(capturedProviderProps.initialBodyStyles).toEqual(["Sedan"]);
    });

    it("should handle mixed case body type", async () => {
      await renderSearchWrapper({ initialBodyType: "SeDaN" });
      expect(capturedProviderProps.initialBodyStyles).toEqual(["Sedan"]);
    });

    it("should handle all body types case insensitively", async () => {
      const testCases = [
        { input: "sedan", expected: "Sedan" },
        { input: "suv", expected: "SUV" },
        { input: "truck", expected: "Truck" },
        { input: "coupe", expected: "Coupe" },
        { input: "hatchback", expected: "Hatchback" },
        { input: "wagon", expected: "Wagon" },
        { input: "van", expected: "Van" },
        { input: "convertible", expected: "Convertible" },
      ];

      for (const { input, expected } of testCases) {
        capturedProviderProps = null;
        await renderSearchWrapper({ initialBodyType: input });
        expect(capturedProviderProps.initialBodyStyles).toEqual([expected]);
      }
    });
  });
});
