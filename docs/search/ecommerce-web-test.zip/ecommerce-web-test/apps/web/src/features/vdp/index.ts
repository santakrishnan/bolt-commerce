// ── Public API for the VDP feature ───────────────────────────────────

// Main page component
export { VehiclePDP } from "./components/vehicle-pdp";
export type { VehicleDetail } from "./data/types";
// Types (client-safe)
export type { PricingData, VinData } from "./services/types";

// Client-safe services
export {
  getDealerDetailsFromApi,
  getVehicleBundleFromApi,
} from "./services/vdp-api";

// Server-only services and flags must be imported directly:
//   @features/vdp/services/vdp.service  (uses cacheTag/cacheLife)
//   @features/vdp/flags/vdp-flags       (uses cookies())
