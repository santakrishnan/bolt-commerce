import type { DealerNotes } from "@shared/data/dealer/dealer-data";
import { Card, cn, Heading } from "@tfs-ucmp/ui";
import Image from "next/image";

interface DealerNotesSectionProps {
  data?: DealerNotes;
}

export function DealerNotesSection({ data }: DealerNotesSectionProps) {
  return (
    <section className="w-full lg:mt-[var(--spacing-2xl)]">
      <Card
        className={cn(
          "w-full rounded-md border-0 bg-[var(--color-core-surfaces-card)] shadow-none lg:h-[320px]"
        )}
      >
        <div className="flex h-full flex-col gap-[var(--spacing-lg)] px-[var(--spacing-md)] pt-[var(--spacing-lg)] pb-[var(--spacing-md)] lg:flex-row lg:items-center lg:gap-[var(--spacing-3xl)] lg:p-[var(--spacing-xl)]">
          <div className="flex-1">
            <Heading
              className="mb-[var(--spacing-lg)] text-[length:var(--font-size-xl)] text-[var(--color-core-surfaces-foreground)] lg:mb-[var(--spacing-xl)] lg:text-[length:var(--font-size-lg)]"
              level={3}
              weight="semibold"
            >
              Dealer Notes
            </Heading>
            {data?.vehicleDescription && (
              <p className="font-[var(--font-weight-normal)] text-[length:var(--font-size-sm)] text-[var(--color-states-muted-foreground)] leading-relaxed lg:text-[length:var(--font-size-md)]">
                {data.vehicleDescription}
              </p>
            )}
          </div>

          {data?.vehicleImage && (
            <div className="flex-shrink-0 lg:w-64">
              <div className="relative aspect-[16/9] w-full overflow-hidden rounded-md lg:aspect-[4/3]">
                <div className="absolute inset-0 z-0 flex items-center justify-center">
                  <svg
                    aria-hidden="true"
                    className="h-[var(--spacing-3xl)] w-[var(--spacing-3xl)]"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                    />
                  </svg>
                </div>
                <Image
                  alt="Vehicle"
                  className="relative z-10 object-contain"
                  fill
                  sizes="(max-width: 1024px) 100vw, 256px"
                  src={data.vehicleImage}
                />
              </div>
            </div>
          )}
        </div>
      </Card>
    </section>
  );
}
