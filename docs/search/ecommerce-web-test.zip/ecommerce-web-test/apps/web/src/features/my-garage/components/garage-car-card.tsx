import { getBadgeType, parseDealerInfo } from "@features/my-garage/lib/helpers";
import { CarCard } from "@features/vehicle-card";
import type { Vehicle } from "@shared/vehicle";
import { getVehicleEstimation } from "@shared/vehicle";

interface GarageCarCardProps {
  badgeOverride?: { type: "excellent" | "available" | "priceDrop"; text: string };
  car: Vehicle;
}

/** Renders a CarCard for a single vehicle, resolving badge and dealer info from vehicle data. */
export function GarageCarCard({ car, badgeOverride }: GarageCarCardProps) {
  const { distance } = parseDealerInfo(car.miles);
  const estimation = getVehicleEstimation(car);
  const firstLabel = car.labels[0];
  const badgeType = getBadgeType(firstLabel);
  const badge =
    badgeOverride ?? (badgeType && firstLabel ? { type: badgeType, text: firstLabel } : undefined);
  const vehicleFeatures = [
    ...car.features.safety,
    ...car.features.comfort,
    ...car.features.tech,
    ...car.features.exterior,
    ...car.features.performance,
  ];

  return (
    <CarCard
      badge={badge}
      carImage={car.image}
      carName={car.title}
      condition={firstLabel}
      dealerLocation={car.dealerLocation}
      dealerName={car.dealerName}
      distance={distance}
      drivetrain={car.drivetrain}
      estimatedPayment={`Est. ${estimation.estimatedMonthlyPayment}/mo`}
      estimation={estimation}
      exteriorColor={car.extColorName}
      exteriorColorHex={car.extColorCode}
      features={{
        warranty: car.warranty,
        inspected: car.inspection160,
        oneOwner: car.owners === 1,
      }}
      interiorColor={car.intColorName}
      interiorColorHex={car.intColorCode}
      make={car.make}
      matchPercentage={car.match > 0 ? String(car.match) : undefined}
      mileage={car.odometer}
      model={car.model}
      mpg={car.mpg}
      owners={car.owners}
      price={`$${car.price.toLocaleString()}`}
      stock={car.stock}
      variant={car.variant}
      vehicleFeatures={vehicleFeatures}
      vin={car.vin}
      wasPrice={car.oldPrice ? `$${car.oldPrice.toLocaleString()}` : undefined}
      year={car.year}
    />
  );
}
