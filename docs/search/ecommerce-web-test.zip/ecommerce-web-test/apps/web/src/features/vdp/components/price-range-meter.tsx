"use client";

import { getPriceCategory } from "@shared/lib/formatters";
import { cn } from "@tfs-ucmp/ui";
import Image from "next/image";
import { useLayoutEffect, useRef } from "react";
import {
  cssVarPx,
  PRICE_HIGH_MULTIPLIER,
  PRICE_LOW_MULTIPLIER,
} from "./price-range-meter.constants";

interface PriceRangeMeterProps {
  avgPrice: number;
  currentPrice: number;
}

export function PriceRangeMeter({ currentPrice, avgPrice }: PriceRangeMeterProps) {
  const minPrice = avgPrice * PRICE_LOW_MULTIPLIER;
  const maxPrice = avgPrice * PRICE_HIGH_MULTIPLIER;
  const currentPercentage = Math.min(
    100,
    Math.max(0, ((currentPrice - minPrice) / (maxPrice - minPrice)) * 100)
  );

  const avgPercentage = 50;
  const { color: categoryColor } = getPriceCategory(currentPercentage);

  const badgeRef = useRef<HTMLDivElement | null>(null);
  const leftPartRef = useRef<HTMLSpanElement | null>(null);
  const avgLeftRef = useRef<HTMLSpanElement | null>(null);
  const barRef = useRef<HTMLDivElement | null>(null);

  const formatted = currentPrice.toLocaleString();
  const commaIndex = formatted.indexOf(",");
  const leftPart = commaIndex >= 0 ? formatted.slice(0, commaIndex + 1) : formatted;
  const rightPart = formatted.slice(leftPart.length);

  useLayoutEffect(() => {
    const compute = () => {
      const barEl = barRef.current;
      if (!barEl) {
        return;
      }

      const leftSpan = leftPartRef.current;
      const badgeEl = badgeRef.current;
      const avgLeftSpan = avgLeftRef.current;

      const nudgePx = cssVarPx("--spacing-sm", "12px");
      const dotHalf = cssVarPx("--size-icon-sm", "16px") / 2;
      const barRect = barEl.getBoundingClientRect();

      if (leftSpan && badgeEl) {
        const leftSpanRect = leftSpan.getBoundingClientRect();
        const desiredLeft = leftSpanRect.right - barRect.left + nudgePx;
        const clamped = Math.max(0, Math.min(barRect.width, desiredLeft - dotHalf));
        barEl.style.setProperty("--dot-left", `${clamped}px`);
      } else {
        barEl.style.setProperty(
          "--dot-left",
          `calc(${currentPercentage}% - (var(--size-icon-sm) / 2))`
        );
      }

      if (avgLeftSpan) {
        const avgLeftRect = avgLeftSpan.getBoundingClientRect();
        const desiredAvgLeft = avgLeftRect.right - barRect.left + nudgePx / 2;
        const avgClamped = Math.max(0, Math.min(barRect.width, desiredAvgLeft - dotHalf));
        barEl.style.setProperty("--avg-dot-left", `${avgClamped}px`);
      } else {
        barEl.style.setProperty(
          "--avg-dot-left",
          `calc(${avgPercentage}% - (var(--size-icon-sm) / 2))`
        );
      }
    };

    compute();
    window.addEventListener("resize", compute);
    return () => window.removeEventListener("resize", compute);
  });

  return (
    <div className="w-full">
      <div className="mb-[var(--spacing-xs)] flex items-start justify-start">
        <div
          className="ml-[var(--spacing-xs)] flex min-w-[var(--size-thumbnail)] flex-col items-center"
          ref={badgeRef}
        >
          <div
            className={cn(
              "mb-[var(--spacing-2xs)] whitespace-nowrap rounded-[var(--radius-full)] px-[var(--spacing-md)] py-[var(--spacing-xs)] text-center font-semibold text-[length:var(--font-size-sm)] text-[var(--color-core-surfaces-foreground)] leading-[1.25] lg:font-semibold lg:text-[length:var(--font-size-md)] lg:leading-[1.25]",
              categoryColor
            )}
          >
            ${""}
            <span ref={leftPartRef}>{leftPart}</span>
            <span>{rightPart}</span>
          </div>
        </div>
        <div className="flex flex-1 justify-start lg:justify-center">
          <div className="text-left">
            <div className="pb-[var(--spacing-xs)] text-center font-semibold text-[length:var(--font-size-sm)] leading-[1.25] lg:font-semibold lg:text-[length:var(--font-size-md)] lg:leading-[1.25]">
              ${""}
              {(() => {
                const formattedAvg = avgPrice.toLocaleString();
                const commaIdx = formattedAvg.indexOf(",");
                const leftAvg = commaIdx >= 0 ? formattedAvg.slice(0, commaIdx + 1) : formattedAvg;
                const rightAvg = formattedAvg.slice(leftAvg.length);
                return (
                  <>
                    <span ref={avgLeftRef}>{leftAvg}</span>
                    <span>{rightAvg}</span>
                  </>
                );
              })()}
            </div>
            <div className="text-right font-normal text-[length:var(--font-size-xs)] text-[var(--color-core-surfaces-foreground)] leading-[1.125] lg:font-normal lg:text-[length:var(--font-size-sm)] lg:leading-[1.125]">
              Avg. market price (IMV)
            </div>
          </div>
        </div>
      </div>
      <div
        className="relative mb-[var(--spacing-xs)] flex h-[var(--spacing-xl)] w-full items-center"
        ref={barRef}
      >
        <div className="absolute top-1/2 left-0 z-0 flex h-[calc(var(--spacing-xs)/2)] w-full -translate-y-1/2 gap-[calc(var(--spacing-sm)/2)]">
          <div className="h-[calc(var(--spacing-xs)/2)] flex-[92] rounded-[var(--radius-full)] bg-green-500" />
          <div className="h-[calc(var(--spacing-xs)/2)] flex-[92] rounded-[var(--radius-full)] bg-green-700" />
          <div className="h-[calc(var(--spacing-xs)/2)] flex-[200] rounded-[var(--radius-full)] bg-gray-700" />
          <div className="h-[calc(var(--spacing-xs)/2)] flex-[200] rounded-[var(--radius-full)] bg-orange-500" />
        </div>
        <div className="absolute top-1/2 left-[var(--dot-left)] z-10 -translate-y-1/2 overflow-hidden rounded-[var(--radius-md)]">
          <Image
            alt="Current price marker"
            height={16}
            src="/images/vdp/Ellipse-Light.svg"
            width={16}
          />
        </div>
        <div className="absolute top-1/2 left-[var(--avg-dot-left)] z-10 -translate-y-1/2 overflow-hidden rounded-[var(--radius-md)]">
          <Image
            alt="Average price marker"
            height={16}
            src="/images/vdp/Ellipse-Dark.svg"
            width={16}
          />
        </div>
      </div>
      <div className="flex w-full">
        <div className="flex-[92] text-center font-normal text-[length:var(--text-2xs)] text-body leading-tight sm:text-[length:var(--text-xs)] lg:text-[length:var(--font-size-sm)] lg:leading-normal">
          Excellent
        </div>
        <div className="flex-[92] text-center font-normal text-[length:var(--text-2xs)] text-body leading-tight sm:text-[length:var(--text-xs)] lg:text-[length:var(--font-size-sm)] lg:leading-normal">
          Good
        </div>
        <div className="flex-[200] text-center font-normal text-[length:var(--text-2xs)] text-body leading-tight sm:text-[length:var(--text-xs)] lg:text-[length:var(--font-size-sm)] lg:leading-normal">
          Fair
        </div>
        <div className="flex-[200] text-center font-normal text-[length:var(--text-2xs)] text-body leading-tight sm:text-[length:var(--text-xs)] lg:text-[length:var(--font-size-sm)] lg:leading-normal">
          High
        </div>
      </div>
    </div>
  );
}
