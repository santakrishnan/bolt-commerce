import { API_ROUTES } from "@config/routes/constants";

/** Fetches JSON from the given URL, throws on non-OK response, and returns the response data. */
async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    credentials: "include",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...init?.headers,
    },
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error ?? `Request failed: ${res.status}`);
  }

  const { data } = await res.json();
  return data as T;
}

/** Fetches saved vehicle VINs from the API. */
export function getAllSavedVehicles(): Promise<string[]> {
  return fetchJson<string[]>(API_ROUTES.SAVED_VEHICLES);
}

/** Saves the given VIN and returns the updated saved VINs list. */
export function saveVehicle(vin: string): Promise<string[]> {
  return fetchJson<string[]>(API_ROUTES.SAVED_VEHICLES, {
    method: "POST",
    body: JSON.stringify({ vin }),
  });
}

/** Removes the given VIN and returns the updated saved VINs list. */
export function unsaveVehicle(vin: string): Promise<string[]> {
  return fetchJson<string[]>(`${API_ROUTES.SAVED_VEHICLES}/${encodeURIComponent(vin)}`, {
    method: "DELETE",
  });
}

/** Clears all saved vehicles and returns the updated (empty) VINs list. */
export function clearAllSavedVehicles(): Promise<string[]> {
  return fetchJson<string[]>(API_ROUTES.SAVED_VEHICLES, {
    method: "DELETE",
  });
}
