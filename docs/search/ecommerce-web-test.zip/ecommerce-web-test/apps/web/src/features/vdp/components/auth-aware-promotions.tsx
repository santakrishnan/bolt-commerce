// Checks auth state and renders the appropriate promotion cards.

import { cookies } from "next/headers";
import { VdpPromotionCards } from "./vdp-promotion-cards";

interface AuthAwarePromotionsProps {
  variant: "prequal" | "test-drive";
}

export async function AuthAwarePromotions({ variant }: AuthAwarePromotionsProps) {
  const cookieStore = await cookies();
  const session = cookieStore.get("session")?.value;

  if (session) {
    // When origination API is ready, replace this block:
    // const origData = await fetchOriginationData(session, vin);
    // return <OriginationCards data={origData} variant={variant} />;
  }

  // pre-origination fallback
  if (variant === "test-drive") {
    return (
      <VdpPromotionCards
        showPrequal={false}
        showTradeIn={false}
        testDriveButtonText="Schedule Test Drive"
      />
    );
  }

  return (
    <div className="flex flex-col gap-[var(--spacing-md)]">
      <VdpPromotionCards showTestDrive={false} />
    </div>
  );
}
