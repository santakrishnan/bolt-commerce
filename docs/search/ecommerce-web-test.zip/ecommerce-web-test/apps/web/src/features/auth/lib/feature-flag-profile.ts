import { SAMPLE_USER_FEATURE_FLAG_PROFILE_BY_EMAIL } from "@config/auth/sample-users";
import { DEFAULT_USER_TYPE, FLAG_COOKIE_NAME, type MockUserKey } from "@config/flags/config";
import { idbDel } from "@shared/lib/indexeddb";

const QUERY_PERSIST_KEY = "tanstack-query-cache";

/** Removes the persisted TanStack Query IDB cache so the next render fetches fresh data. */
function clearQueryCache(): void {
  idbDel(QUERY_PERSIST_KEY).catch(() => {
    // best-effort
  });
}

/**
 * Resets the server-side saved vehicles and recent searches back to the seed state.
 * Called on sign-in so the demo data is restored for the new session.
 */
function seedSavedRegistry(profile: string): void {
  fetch(`/api/saved-registry/reset?profile=${encodeURIComponent(profile)}`, {
    method: "DELETE",
    credentials: "include",
  }).catch(() => {
    // best-effort
  });
}

/**
 * Clears the server-side saved vehicles and search history to an empty state.
 * Called on sign-out so the logged-out visitor sees no data.
 */
function clearSavedRegistry(): void {
  fetch("/api/saved-registry/vehicles", { method: "DELETE", credentials: "include" }).catch(() => {
    // best-effort
  });
  fetch("/api/saved-registry/search-history", { method: "DELETE", credentials: "include" }).catch(
    () => {
      // best-effort
    }
  );
}

function persistFeatureFlagProfile(profileKey: MockUserKey): void {
  if (typeof window === "undefined") {
    return;
  }

  if ("cookieStore" in window) {
    (
      window as {
        cookieStore: {
          set: (options: { name: string; value: string; path: string; expires: number }) => void;
        };
      }
    ).cookieStore.set({
      name: FLAG_COOKIE_NAME,
      value: profileKey,
      path: "/",
      expires: Date.now() + 86_400 * 1000,
    });
  } else {
    const cookieValue = `${FLAG_COOKIE_NAME}=${profileKey}; path=/; max-age=86400`;
    // biome-ignore lint/suspicious/noDocumentCookie: Fallback for browsers without Cookie Store API
    document.cookie = cookieValue;
  }

  localStorage.setItem(FLAG_COOKIE_NAME, profileKey);
}

export function setFeatureFlagProfileForSampleUser(email: string): void {
  const profileKey = SAMPLE_USER_FEATURE_FLAG_PROFILE_BY_EMAIL[email.trim().toLowerCase()];
  if (!profileKey) {
    return;
  }

  persistFeatureFlagProfile(profileKey);
  clearQueryCache();
  seedSavedRegistry(profileKey);
}

export function resetFeatureFlagProfileToDefault(): void {
  persistFeatureFlagProfile(DEFAULT_USER_TYPE);
  clearQueryCache();
  clearSavedRegistry();
}
