import { SAVED_REGISTRY_STALE_TIME } from "@config/queries/constants";
import {
  getAllSearchHistory,
  type SearchEntry,
} from "@features/search/services/search-history-api";
import { queryOptions } from "@tanstack/react-query";

// Query key factory for search history, centralizing cache for consumers and calling saved-registry proxy
export const searchHistoryQueries = {
  all: () =>
    queryOptions({
      queryKey: ["search-history"] as const,
      queryFn: getAllSearchHistory,
      // Show empty list while the first fetch runs
      placeholderData: [] as SearchEntry[],
      staleTime: SAVED_REGISTRY_STALE_TIME,
    }),
} as const;
