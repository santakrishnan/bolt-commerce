import { API_ROUTES } from "@config/routes/constants";

export interface ServerConfig {
  fingerprintApiKey: string;
  fingerprintServiceUrl: string;
}

export interface ClientConfig {
  eventServiceUrl: string;
  profileServiceUrl: string;
}

export interface TrackingConfig {
  client: ClientConfig;
  server: ServerConfig;
}

export class ConfigValidationError extends Error {
  readonly missingVars: string[];
  readonly invalidVars: string[];

  constructor(missingVars: string[], invalidVars: string[]) {
    const messages: string[] = [];

    if (missingVars.length > 0) {
      messages.push(`Missing required environment variables: ${missingVars.join(", ")}`);
    }

    if (invalidVars.length > 0) {
      messages.push(`Invalid environment variables: ${invalidVars.join(", ")}`);
    }

    super(messages.join("; "));
    this.name = "ConfigValidationError";
    this.missingVars = missingVars;
    this.invalidVars = invalidVars;
  }
}

function isValidString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

function isValidUrl(value: unknown): boolean {
  if (!isValidString(value)) {
    return false;
  }

  try {
    new URL(value);
    return true;
  } catch {
    return false;
  }
}

export function validateServerConfig(): ServerConfig {
  const missingVars: string[] = [];
  const invalidVars: string[] = [];

  const fingerprintServiceUrl = process.env.FINGERPRINT_SERVICE_URL;
  const fingerprintApiKey = process.env.FINGERPRINT_API_KEY;

  if (!fingerprintServiceUrl) {
    missingVars.push("FINGERPRINT_SERVICE_URL");
  }
  if (!fingerprintApiKey) {
    missingVars.push("FINGERPRINT_API_KEY");
  }

  if (fingerprintServiceUrl && !isValidUrl(fingerprintServiceUrl)) {
    invalidVars.push("FINGERPRINT_SERVICE_URL (must be a valid URL)");
  }
  if (fingerprintApiKey && !isValidString(fingerprintApiKey)) {
    invalidVars.push("FINGERPRINT_API_KEY (must be a non-empty string)");
  }

  if (missingVars.length > 0 || invalidVars.length > 0) {
    throw new ConfigValidationError(missingVars, invalidVars);
  }

  return {
    fingerprintServiceUrl: fingerprintServiceUrl as string,
    fingerprintApiKey: fingerprintApiKey as string,
  };
}

export function validateClientConfig(): ClientConfig {
  const invalidVars: string[] = [];

  const profileServiceUrl = process.env.NEXT_PUBLIC_PROFILE_SERVICE_URL;
  const eventServiceUrl = process.env.NEXT_PUBLIC_EVENT_SERVICE_URL;

  if (profileServiceUrl && !isValidUrl(profileServiceUrl)) {
    invalidVars.push("NEXT_PUBLIC_PROFILE_SERVICE_URL (must be a valid URL)");
  }
  if (eventServiceUrl && !isValidUrl(eventServiceUrl)) {
    invalidVars.push("NEXT_PUBLIC_EVENT_SERVICE_URL (must be a valid URL)");
  }

  if (invalidVars.length > 0) {
    throw new ConfigValidationError([], invalidVars);
  }

  return {
    profileServiceUrl: profileServiceUrl || API_ROUTES.PROFILE,
    eventServiceUrl: eventServiceUrl || API_ROUTES.EVENTS,
  };
}

export function getTrackingConfig(): TrackingConfig {
  return {
    server: validateServerConfig(),
    client: validateClientConfig(),
  };
}

export function getClientConfig(): ClientConfig {
  return validateClientConfig();
}

export function isServerConfigValid(): boolean {
  try {
    validateServerConfig();
    return true;
  } catch {
    return false;
  }
}

export function isClientConfigValid(): boolean {
  try {
    validateClientConfig();
    return true;
  } catch {
    return false;
  }
}
