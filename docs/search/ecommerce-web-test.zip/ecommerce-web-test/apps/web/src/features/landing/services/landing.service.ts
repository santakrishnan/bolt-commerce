import { type SearchQuery, searchVehicles } from "@features/search/services";
import { ArrowServerError, createArrowServerClient } from "@features/tracking/lib/server-api";
import { cacheLife, cacheTag } from "next/cache";
import type { HomeHeroKnownUserContentProps } from "../components/home-hero/types";
import { DEFAULT_HERO_STATS, DEFAULT_VEHICLE_FINDER_OPTIONS } from "./landing.defaults";
import type {
  HeroStat,
  RawHeroStat,
  RawHeroStatsResponse,
  RawVehicleFinderCountsResponse,
  VehicleFinderCounts,
  VehicleFinderOptionStatic,
} from "./types";

let _client: ReturnType<typeof createArrowServerClient> | null = null;

function getLandingClient() {
  if (!_client) {
    _client = createArrowServerClient({
      baseUrl: process.env.LANDING_SERVICE_URL ?? "",
      authToken: process.env.LANDING_API_KEY,
      serviceName: "LandingService",
      timeout: 10_000,
      retries: 1,
    });
  }
  return _client;
}

function isMockMode(): boolean {
  return !process.env.LANDING_SERVICE_URL || process.env.USE_MOCK_LANDING === "true";
}

export function transformRawHeroStat(raw: RawHeroStat): HeroStat {
  return {
    id: raw.id ?? raw.key ?? "",
    value: String(raw.value ?? raw.metric_value ?? ""),
    label: raw.label ?? raw.display_name ?? "",
    icon: raw.icon ?? raw.icon_url ?? "",
  };
}

export function transformHeroStats(raw: RawHeroStatsResponse): HeroStat[] {
  const items = raw.features ?? raw.stats ?? raw.metrics ?? raw.data ?? [];
  return items.map(transformRawHeroStat);
}

export function transformVehicleFinderCounts(
  raw: RawVehicleFinderCountsResponse
): VehicleFinderCounts {
  const counts = raw.counts ?? raw.data ?? raw;
  return {
    "under-20k": Number(counts["under-20k"] ?? 0),
    "excellent-deals": Number(counts["excellent-deals"] ?? 0),
    "price-drop": Number(counts["price-drop"] ?? 0),
    "low-miles": Number(counts["low-miles"] ?? 0),
  };
}

export async function fetchHeroStats(): Promise<HeroStat[]> {
  "use cache";
  cacheLife("landing");
  cacheTag("hero-stats");

  // Fetch live vehicle count via the search service (mock or real).
  let vehicleCount: number | null = null;
  try {
    const result = await searchVehicles({ query: { pageSize: 1 } });
    vehicleCount = result.pagination.totalResults;
  } catch {
    // non-fatal — fall back to whatever the stats source provides
  }

  const applyVehicleCount = (stats: HeroStat[]): HeroStat[] =>
    vehicleCount === null
      ? stats
      : stats.map((stat) =>
          stat.id === "vehicles" ? { ...stat, value: vehicleCount.toLocaleString() } : stat
        );

  if (isMockMode()) {
    return applyVehicleCount(DEFAULT_HERO_STATS);
  }

  try {
    const raw = await getLandingClient().get<RawHeroStatsResponse>("/landing/hero-stats");
    return applyVehicleCount(transformHeroStats(raw));
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[LandingService] Upstream error (hero-stats):", error.message);
    } else {
      console.error("[LandingService] Unexpected error (hero-stats):", error);
    }
    return applyVehicleCount(DEFAULT_HERO_STATS);
  }
}

export async function fetchVehicleFinderOptions(): Promise<VehicleFinderOptionStatic[]> {
  "use cache";
  cacheLife("landing");
  cacheTag("vehicle-finder-options");

  if (isMockMode()) {
    console.log("[LandingService] Mock mode — returning local finder options");
    return DEFAULT_VEHICLE_FINDER_OPTIONS;
  }

  try {
    const raw = await getLandingClient().get<{ options: VehicleFinderOptionStatic[] }>(
      "/landing/vehicle-finder/options"
    );
    return raw.options ?? DEFAULT_VEHICLE_FINDER_OPTIONS;
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[LandingService] Upstream error (finder-options):", error.message);
    } else {
      console.error("[LandingService] Unexpected error (finder-options):", error);
    }
    return DEFAULT_VEHICLE_FINDER_OPTIONS;
  }
}

export async function fetchVehicleFinderCounts(): Promise<VehicleFinderCounts> {
  "use cache";
  cacheLife("landing");
  cacheTag("vehicle-finder-counts");

  try {
    const queries: Array<{ id: keyof VehicleFinderCounts; query: SearchQuery }> = [
      { id: "under-20k", query: { query: "cars-under-$20,000", pageSize: 1 } },
      { id: "excellent-deals", query: { query: "shop-excellent-deals", pageSize: 1 } },
      { id: "price-drop", query: { query: "price-drop", pageSize: 1 } },
      { id: "low-miles", query: { query: "low-miles", pageSize: 1 } },
    ];

    const results = await Promise.all(
      queries.map(({ id, query }) =>
        searchVehicles({ query }).then((r) => ({ id, count: r.pagination.totalResults }))
      )
    );

    const counts = Object.fromEntries(
      results.map(({ id, count }) => [id, count])
    ) as unknown as VehicleFinderCounts;

    console.log("[LandingService] Fetched finder counts:", counts);
    return counts;
  } catch (error) {
    console.error("[LandingService] Unexpected error (finder-counts):", error);
    return { "under-20k": 0, "excellent-deals": 0, "price-drop": 0, "low-miles": 0 };
  }
}

export async function fetchKnownUserDefaults(): Promise<HomeHeroKnownUserContentProps> {
  if (isMockMode()) {
    const data = await import("@shared/data/known-user.json");
    return data.default as unknown as HomeHeroKnownUserContentProps;
  }

  try {
    const raw = await getLandingClient().get<HomeHeroKnownUserContentProps>(
      "/landing/known-user-defaults"
    );
    return raw;
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[LandingService] Upstream error (known-user-defaults):", error.message);
    } else {
      console.error("[LandingService] Unexpected error (known-user-defaults):", error);
    }
    const data = await import("@shared/data/known-user.json");
    return data.default as unknown as HomeHeroKnownUserContentProps;
  }
}
