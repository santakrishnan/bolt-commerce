import "@testing-library/jest-dom";
import { fireEvent, render, screen } from "@testing-library/react";
import { act } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const RE_HEART_BUTTON = /heart-button/;
const RE_EXTRA_CLASS = /extra-class/;
const RE_ANIMATE = /animate/;
const RE_H9 = /h-9/;
const RE_W9 = /w-9/;

let isVehicleSavedMock = (_vin: string) => false;
const toggleVehicleMock = vi.fn();

vi.mock("@features/favorites/context/favorites-provider", () => ({
  useFavorites: () => ({
    isVehicleSaved: (vin: string) => isVehicleSavedMock(vin),
    toggleVehicle: toggleVehicleMock,
  }),
}));

vi.mock("@tfs-ucmp/ui", () => ({
  Button: ({ children, ...props }: any) => (
    <button data-testid="fav-button" {...props}>
      {children}
    </button>
  ),
}));

vi.mock("next/image", () => ({
  __esModule: true,
  default: ({ src, alt, ...rest }: any) => (
    // biome-ignore lint/performance/noImgElement: intentional test mock for next/image
    <img
      alt={alt as string}
      data-testid="fav-image"
      height={1}
      src={src as string}
      width={1}
      {...rest}
    />
  ),
}));

import { FavoriteButton } from "./favorite-button";

describe("FavoriteButton — functionality tests", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    isVehicleSavedMock = () => false;
  });

  const cleanupTimers = () => {
    vi.useRealTimers();
  };

  afterEach(cleanupTimers);

  it("renders in unliked state with correct aria-label, classes and image", () => {
    render(<FavoriteButton className="extra-class" vin="VIN123" />);

    const btn = screen.getByTestId("fav-button");
    expect(btn).toBeInTheDocument();
    expect(btn).toHaveAttribute("aria-label", "Add to favorites");
    expect(btn.className).toMatch(RE_HEART_BUTTON);
    expect(btn.className).toMatch(RE_EXTRA_CLASS);

    const img = screen.getByTestId("fav-image");
    expect(img).toBeInTheDocument();
    expect(img).toHaveAttribute("alt", "Favorite");
    expect(img.getAttribute("src") ?? "").toContain("heart.svg");
    expect(img.getAttribute("src") ?? "").not.toContain("-filled");
  });

  it("renders in liked state (filled heart) and correct aria-label", () => {
    isVehicleSavedMock = () => true;
    render(<FavoriteButton vin="VIN123" />);

    const btn = screen.getByTestId("fav-button");
    expect(btn).toHaveAttribute("aria-label", "Remove from favorites");

    const img = screen.getByTestId("fav-image");
    expect(img.getAttribute("src") ?? "").toContain("heart-filled.svg");
  });

  it("calls toggleVehicle with vin, stops propagation and applies animation class for 500ms", () => {
    vi.useFakeTimers();

    const parentClick = vi.fn();

    const { unmount } = render(
      // biome-ignore lint/a11y/useSemanticElements: test wrapper — nesting <button> inside <button> is invalid HTML
      <div
        data-testid="parent"
        onClick={parentClick}
        onKeyUp={parentClick}
        role="button"
        tabIndex={0}
      >
        <FavoriteButton vin="VIN-CLICK" />
      </div>
    );

    const btn = screen.getByTestId("fav-button");

    act(() => {
      fireEvent.click(btn);
    });

    expect(toggleVehicleMock).toHaveBeenCalledWith("VIN-CLICK");

    expect(parentClick).not.toHaveBeenCalled();

    expect(btn.className).toMatch(RE_ANIMATE);

    act(() => {
      vi.advanceTimersByTime(500);
    });

    expect(btn.className).not.toMatch(RE_ANIMATE);

    unmount();
  });

  it("cleans up the timeout when unmounted while animating", () => {
    vi.useFakeTimers();

    const { unmount } = render(<FavoriteButton vin="VIN-UNMOUNT" />);
    const btn = screen.getByTestId("fav-button");

    act(() => {
      fireEvent.click(btn);
    });

    expect(() => unmount()).not.toThrow();

    act(() => vi.advanceTimersByTime(1000));
  });

  it("click when already liked still toggles and animates (filled heart)", () => {
    vi.useFakeTimers();
    isVehicleSavedMock = () => true;

    render(<FavoriteButton vin="VIN-LIKED" />);

    const btn = screen.getByTestId("fav-button");
    const img = screen.getByTestId("fav-image");

    expect(img.getAttribute("src") ?? "").toContain("heart-filled.svg");

    act(() => {
      fireEvent.click(btn);
    });

    expect(toggleVehicleMock).toHaveBeenCalledWith("VIN-LIKED");
    expect(btn.className).toMatch(RE_ANIMATE);

    act(() => {
      vi.advanceTimersByTime(500);
    });

    expect(btn.className).not.toMatch(RE_ANIMATE);
  });

  it("accepts an explicit empty className and forwards native button props", () => {
    render(<FavoriteButton className="" vin="VIN-EMPTY" />);

    const btn = screen.getByTestId("fav-button");
    expect(btn.className).toMatch(RE_HEART_BUTTON);

    expect(btn).toHaveAttribute("type", "button");
    expect(btn.className).toMatch(RE_H9);
    expect(btn.className).toMatch(RE_W9);
  });

  it("handles multiple quick clicks without throwing and toggles each time", () => {
    vi.useFakeTimers();

    const { unmount } = render(<FavoriteButton vin="VIN-DOUBLE" />);
    const btn = screen.getByTestId("fav-button");

    act(() => {
      fireEvent.click(btn);
      fireEvent.click(btn);
    });
    expect(toggleVehicleMock).toHaveBeenCalledWith("VIN-DOUBLE");
    expect(toggleVehicleMock).toHaveBeenCalledTimes(2);

    expect(btn.className).toMatch(RE_ANIMATE);
    act(() => vi.advanceTimersByTime(500));
    expect(btn.className).not.toMatch(RE_ANIMATE);

    unmount();
    vi.useRealTimers();
  });

  it("does not schedule a timer when not animating, schedules after click", () => {
    vi.useFakeTimers();

    render(<FavoriteButton vin="VIN-TIMER" />);

    try {
      expect(vi.getTimerCount()).toBe(0);
    } catch (e) {
      console.warn("Timer count assertion skipped:", e);
    }

    const btn = screen.getByTestId("fav-button");

    act(() => {
      fireEvent.click(btn);
    });

    try {
      expect(vi.getTimerCount()).toBeGreaterThan(0);
    } catch (e) {
      console.warn("Timer count assertion skipped:", e);
    }

    act(() => vi.advanceTimersByTime(500));
    expect(btn.className).not.toMatch(RE_ANIMATE);

    vi.useRealTimers();
  });

  it("preserves handleClick identity across re-renders when deps unchanged", () => {
    const { rerender } = render(<FavoriteButton vin="VIN-MEMO" />);

    const firstBtn = screen.getByTestId("fav-button") as HTMLButtonElement;
    const first = (firstBtn as any).onclick;
    rerender(<FavoriteButton vin="VIN-MEMO" />);

    const secondBtn = screen.getByTestId("fav-button") as HTMLButtonElement;
    const second = (secondBtn as any).onclick;

    expect(first).toBe(second);
  });
});
