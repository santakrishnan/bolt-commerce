import { afterEach, describe, expect, it, vi } from "vitest";
import {
  clearAllSavedVehicles,
  getAllSavedVehicles,
  saveVehicle,
  unsaveVehicle,
} from "./saved-vehicles-api";

const SAVED_VEHICLES_URL = "/api/saved-registry/vehicles";

function mockFetch(data: unknown, ok = true, status = 200) {
  const jsonFn = vi.fn().mockResolvedValue(ok ? { data } : { error: "Server error" });
  return vi.spyOn(globalThis, "fetch").mockResolvedValue({
    ok,
    status,
    json: jsonFn,
  } as unknown as Response);
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe("getAllSavedVehicles", () => {
  it("calls GET on the correct URL with credentials", async () => {
    const spy = mockFetch(["VIN1", "VIN2"]);
    await getAllSavedVehicles();

    expect(spy).toHaveBeenCalledWith(
      SAVED_VEHICLES_URL,
      expect.objectContaining({
        credentials: "include",
        headers: expect.objectContaining({ "Content-Type": "application/json" }),
      })
    );
  });

  it("returns the data array from the response", async () => {
    mockFetch(["VIN1", "VIN2"]);
    const result = await getAllSavedVehicles();
    expect(result).toEqual(["VIN1", "VIN2"]);
  });

  it("throws when the response is not ok (with server error message)", async () => {
    mockFetch(null, false, 500);
    await expect(getAllSavedVehicles()).rejects.toThrow("Server error");
  });

  it("throws a generic message when error body has no error field", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValue({
      ok: false,
      status: 503,
      json: vi.fn().mockResolvedValue({}),
    } as unknown as Response);
    await expect(getAllSavedVehicles()).rejects.toThrow("Request failed: 503");
  });

  it("throws a generic message when json() rejects", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValue({
      ok: false,
      status: 500,
      json: vi.fn().mockRejectedValue(new Error("invalid json")),
    } as unknown as Response);
    await expect(getAllSavedVehicles()).rejects.toThrow("Request failed: 500");
  });
});

describe("saveVehicle", () => {
  it("calls POST with the VIN in the body", async () => {
    const spy = mockFetch(["VIN1"]);
    await saveVehicle("VIN1");

    expect(spy).toHaveBeenCalledWith(
      SAVED_VEHICLES_URL,
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({ vin: "VIN1" }),
        credentials: "include",
      })
    );
  });

  it("returns the updated list", async () => {
    mockFetch(["VIN1", "VIN2"]);
    const result = await saveVehicle("VIN2");
    expect(result).toEqual(["VIN1", "VIN2"]);
  });

  it("throws on non-ok response", async () => {
    mockFetch(null, false, 400);
    await expect(saveVehicle("VIN1")).rejects.toThrow("Server error");
  });
});

describe("unsaveVehicle", () => {
  it("calls DELETE on the VIN-specific URL", async () => {
    const spy = mockFetch(["VIN2"]);
    await unsaveVehicle("VIN1");

    expect(spy).toHaveBeenCalledWith(
      `${SAVED_VEHICLES_URL}/VIN1`,
      expect.objectContaining({
        method: "DELETE",
        credentials: "include",
      })
    );
  });

  it("percent-encodes VINs that contain special characters", async () => {
    const spy = mockFetch([]);
    await unsaveVehicle("VIN/SPECIAL");

    expect(spy).toHaveBeenCalledWith(`${SAVED_VEHICLES_URL}/VIN%2FSPECIAL`, expect.anything());
  });

  it("returns the updated list", async () => {
    mockFetch(["VIN2"]);
    const result = await unsaveVehicle("VIN1");
    expect(result).toEqual(["VIN2"]);
  });

  it("throws on non-ok response", async () => {
    mockFetch(null, false, 404);
    await expect(unsaveVehicle("VIN1")).rejects.toThrow("Server error");
  });
});

describe("clearAllSavedVehicles", () => {
  it("calls DELETE on the base URL", async () => {
    const spy = mockFetch([]);
    await clearAllSavedVehicles();

    expect(spy).toHaveBeenCalledWith(
      SAVED_VEHICLES_URL,
      expect.objectContaining({
        method: "DELETE",
        credentials: "include",
      })
    );
  });

  it("returns an empty array", async () => {
    mockFetch([]);
    const result = await clearAllSavedVehicles();
    expect(result).toEqual([]);
  });

  it("throws on non-ok response", async () => {
    mockFetch(null, false, 500);
    await expect(clearAllSavedVehicles()).rejects.toThrow("Server error");
  });
});
