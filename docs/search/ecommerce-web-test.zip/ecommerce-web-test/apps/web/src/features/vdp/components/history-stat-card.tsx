import { Heading } from "@tfs-ucmp/ui";
import type { ReactNode } from "react";

interface HistoryStatCardProps {
  icon: ReactNode;
  label: string;
  value: string;
}

/*
HistoryStatCard - Reusable card for displaying a single vehicle history stat.
Used in the History tab grid (e.g. "No Damage", "Previous Owners", etc.).
*/
export function HistoryStatCard({ icon, label, value }: HistoryStatCardProps) {
  return (
    <div className="flex items-center gap-[var(--spacing-md)]">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-[var(--radius-md)] border border-[color:var(--color-structure-interaction-subtle-border)] px-0 py-[var(--spacing-xs)]">
        {icon}
      </div>
      <div>
        <Heading
          className="pb-[var(--spacing-2xs)] font-[var(--font-weight-normal)] text-[length:var(--font-size-sm)] text-[var(--color-states-muted-foreground)] leading-5 md:text-[length:var(--font-size-sm)] lg:text-[length:var(--font-size-sm]"
          level={4}
        >
          {label}
        </Heading>
        <p className="--color-core-surfaces-foreground)] font-[var(--font-weight-semibold)] text-[length:var(--font-size-md)] text-[var( leading-5">
          {value}
        </p>
      </div>
    </div>
  );
}
