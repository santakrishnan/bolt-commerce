export interface FingerprintMetadata {
  confidence?: number;
  requestId?: string;
  visitorFound?: boolean;
}

export interface FedLocationData {
  city?: string;
  country?: string;
  countryCode?: string;
  postalCode?: string;
  state?: string;
  stateCode?: string;
  timezone?: string;
}

export interface FedFingerprintData {
  incognito?: boolean;
  location?: FedLocationData;
  visitorId: string;
}

export interface ProfileContextState {
  error: Error | null;
  fingerprintDetails?: FedFingerprintData;
  fingerprintId: string | null;
  fingerprintMetadata?: FingerprintMetadata;
  isInitialized: boolean;
  isLoading: boolean;
  profileId: string | null;
  sessionId: string | null;
}

export interface ProfileContextValue extends ProfileContextState {
  getTrackingIds(): {
    sessionId: string | null;
    fingerprintId: string | null;
    profileId: string | null;
  };
  refreshIds(): Promise<void>;
}

export interface EventTrackerRequest {
  eventName: string;
  fingerprintId: string | null;
  profileId: string | null;
  properties?: Record<string, unknown>;
  sessionId: string;
  timestamp: number;
}
