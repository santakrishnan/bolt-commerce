"use client";

import { ROUTES } from "@config/routes/constants";
import Image from "next/image";
import { useRouter } from "next/navigation";
import type React from "react";

export const BackToSearch: React.FC = () => {
  const router = useRouter();

  const handleBack = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (e.defaultPrevented) {
      return;
    }
    // Allow modifier keys and non-left clicks to open in new tab/window
    if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) {
      return;
    }

    e.preventDefault();
    if (typeof window !== "undefined" && window.history.length > 1) {
      router.back();
    } else {
      router.push(ROUTES.USED_CARS);
    }
  };

  return (
    <a
      aria-label="Back to search"
      className="flex cursor-pointer items-center gap-[var(--spacing-sm)] text-[var(--color-core-surfaces-foreground)] text-[var(--font-size-sm)] hover:text-[var(--color-states-muted-foreground)]"
      href={ROUTES.USED_CARS}
      onClick={handleBack}
    >
      <Image
        alt="Back to search results"
        aria-hidden="true"
        className="mt-[calc(var(--spacing-2xs))] h-[var(--spacing-sm,12px)] w-[calc(var(--spacing-xs,8px)_+_2px)]"
        height={12}
        src="/images/vdp/chevron-left.svg"
        width={10}
      />
      <span className="font-normal text-[var(--color-core-surfaces-foreground)] text-[var(--font-size-md)] hover:text-[var(--color-states-muted-foreground)]">
        Back
      </span>
    </a>
  );
};
