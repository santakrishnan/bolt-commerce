import type { VehicleSpecData } from "@features/vdp/data";
import { AppButton } from "@shared/components/button";
import {
  BatteryIcon,
  ColorsIcon,
  cn,
  EngineIcon,
  FuelTypeIcon,
  Heading,
  MarkerPinIcon,
  MileageIcon,
  MPGIcon,
  TransmissionIcon,
} from "@tfs-ucmp/ui";
import type { ReactNode } from "react";

interface OverviewTabProps {
  specs: VehicleSpecData[];
}

const specIconMap: Record<string, ReactNode> = {
  engine: <EngineIcon className="text-muted" />,
  "interior-color": <ColorsIcon className="text-muted" />,
  "exterior-color": <ColorsIcon className="text-muted" />,
  mpg: <MPGIcon className="text-muted" />,
  mileage: <MileageIcon className="text-muted" />,
  location: <MarkerPinIcon className="text-muted" />,
  "fuel-type": <FuelTypeIcon className="text-muted" />,
  drivetrain: <BatteryIcon className="text-muted" />,
  transmission: <TransmissionIcon className="text-muted" />,
};

const specIconMapDesktop: Record<string, ReactNode> = {
  engine: <EngineIcon className="text-[var(--color-states-muted-foreground)]" />,
  "interior-color": <ColorsIcon className="text-[var(--color-states-muted-foreground)]" />,
  "exterior-color": <ColorsIcon className="text-[var(--color-states-muted-foreground)]" />,
  mpg: <MPGIcon className="text-[var(--color-states-muted-foreground)]" />,
  mileage: <MileageIcon className="text-[var(--color-states-muted-foreground)]" />,
  location: <MarkerPinIcon className="text-[var(--color-states-muted-foreground)]" />,
  "fuel-type": <FuelTypeIcon className="text-[var(--color-states-muted-foreground)]" />,
  drivetrain: <BatteryIcon className="text-[var(--color-states-muted-foreground)]" />,
  transmission: <TransmissionIcon className="text-[var(--color-states-muted-foreground)]" />,
};

export function OverviewTab({ specs }: OverviewTabProps) {
  return (
    <div className="rounded-[var(--radius-md)]">
      <div className="mb-[var(--spacing-lg)] flex items-center justify-between md:pr-[var(--spacing-xl)] lg:mb-[var(--spacing-2xl)]">
        <Heading
          className="font-semibold text-[length:var(--font-size-xl)] text-[var(--color-core-surface-foreground)] leading-heading md:px-[var(--spacing-xl)] md:text-[length:var(--font-size-xl)] lg:font-semibold lg:text-[length:var(--font-size-lg)] lg:text-heading"
          level={3}
          weight="semibold"
        >
          Overview
        </Heading>
        <AppButton
          className="rounded-[var(--radius-large)] py-[var(--spacing-3)] md:rounded-[var(--radius-full)] md:py-0"
          size="md"
          variant="tertiary"
        >
          View All Specs
        </AppButton>
      </div>

      <div className="rounded-[var(--radius-md)] bg-[var(--color-core-surfaces-card)] shadow-sm">
        {/* Mobile layout */}
        <div className="block md:hidden">
          {specs.map((spec, _index) => (
            <div
              className="flex items-center justify-between self-stretch border-b-[1px] border-b-[var(--color-structure-interaction-subtle-border)] px-[var(--spacing-md)] py-[var(--spacing-lg)]"
              key={spec.key}
            >
              <div className="flex flex-1 items-center gap-[var(--spacing-xs)]">
                <span className="mt-0.5">{specIconMap[spec.key]}</span>
                <span className="text-center font-normal text-[length:var(--font-size-sm)] text-[var(--color-states-muted-foreground)] leading-6">
                  {spec.label}
                </span>
              </div>
              <span className="text-center font-semibold text-[length:var(--font-size-sm)] text-[var(--color-core-surfaces-foreground)] leading-6">
                {spec.value}
              </span>
            </div>
          ))}
        </div>

        {/* Desktop layout */}
        <div className="hidden grid-cols-1 md:grid md:grid-cols-2 md:gap-x-[var(--spacing-3xl)] md:p-[var(--spacing-xl)] lg:grid-cols-3">
          {specs.map((spec, index) => {
            const mdCols = 2;
            const lgCols = 3;
            const mdLastRowStart = Math.floor((specs.length - 1) / mdCols) * mdCols;
            const lgLastRowStart = Math.floor((specs.length - 1) / lgCols) * lgCols;
            const isFirstRowMd = index < mdCols;
            const isFirstRowLg = index < lgCols;
            const isLastRowMd = index >= mdLastRowStart;
            const isLastRowLg = index >= lgLastRowStart;

            return (
              <div
                className={cn(
                  "flex items-center gap-[var(--spacing-sm)] border-b-[1px] border-b-[var(--color-structure-interaction-subtle-border)]",
                  !isLastRowMd && "md:pb-[var(--spacing-lg)]",
                  !isFirstRowMd && "md:pt-[var(--spacing-lg)]",
                  isFirstRowLg && "lg:pt-0",
                  isLastRowMd && "md:border-b-0",
                  !isLastRowLg && "lg:pb-[var(--spacing-lg)]",
                  !isFirstRowLg && "lg:pt-[var(--spacing-lg)]",
                  isLastRowLg && "lg:border-b-0"
                )}
                key={spec.key}
              >
                <div className="mt-0.5">{specIconMapDesktop[spec.key]}</div>
                <div className="flex flex-col gap-[var(--spacing-3)]">
                  <span className="text-[length:var(--font-size-sm)] text-[var(--color-states-muted-foreground)] lg:font-normal lg:text-[length:var(--font-size-sm)] lg:text-[var(--color-states-muted-foreground)]">
                    {spec.label}
                  </span>
                  <span className="font-medium text-[length:var(--font-size-md)] text-[var(--color-core-surfaces-foreground)] lg:font-semibold lg:text-[length:var(--font-size-sm)] lg:text-heading">
                    {spec.value}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
