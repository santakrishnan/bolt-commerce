"use client";

import {
  defaultFilterState,
  FilterSidebar,
  type FilterState,
} from "@features/search/components/filter-sidebar";
import { SearchHero } from "@features/search/components/search-hero";
import { SearchProgressBar } from "@features/search/components/search-progress-bar";
import { VehicleResults } from "@features/search/components/vehicle-results";
import { useSearchContext } from "@features/search/context/search-context";
import { serializeSearchUrlState } from "@features/search/lib/url-filters";
import { useDebouncedValue } from "@shared/hooks/use-debounced-value";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Suspense, useCallback, useDeferredValue, useEffect, useMemo, useRef } from "react";
import { slugify } from "utils";

// Helper functions for building active filters list
function addSingleFilter(
  filters: { label: string; type: string; value: string }[],
  value: string,
  type: string
) {
  if (value) {
    filters.push({ label: value, type, value });
  }
}

function addArrayFilters(
  filters: { label: string; type: string; value: string }[],
  arr: string[],
  type: string
) {
  for (const value of arr) {
    filters.push({ label: value, type, value });
  }
}

function buildActiveFilters(
  filterState: FilterState,
  labelFilter: string,
  refineSearchFilters: { id: string; label: string }[],
  appliedFilters: { field?: string; value: string; displayText?: string }[]
) {
  const filters: { label: string; type: string; value: string; isRefineSearch?: boolean }[] = [];
  addSingleFilter(filters, filterState.selectedPriceQuick, "price");
  addSingleFilter(filters, filterState.selectedYearQuick, "year");
  addSingleFilter(filters, filterState.selectedMileage, "mileage");
  addArrayFilters(filters, filterState.selectedBodyStyles, "bodyStyle");
  addArrayFilters(filters, filterState.selectedExteriorColors, "exteriorColor");
  addArrayFilters(filters, filterState.selectedInteriorColors, "interiorColor");
  addArrayFilters(filters, filterState.selectedFuelTypes, "fuelType");
  addArrayFilters(filters, filterState.selectedModels, "model");
  addArrayFilters(filters, filterState.selectedSafetyFeatures, "safetyFeature");
  addArrayFilters(filters, filterState.selectedComfortFeatures, "comfortFeature");
  addArrayFilters(filters, filterState.selectedTechFeatures, "techFeature");
  addArrayFilters(filters, filterState.selectedExteriorFeatures, "exteriorFeature");
  addArrayFilters(filters, filterState.selectedPerformanceFeatures, "performanceFeature");
  addArrayFilters(filters, filterState.selectedSeatingCapacity, "seatingCapacity");
  addArrayFilters(filters, filterState.selectedDrivetrains, "drivetrain");
  addArrayFilters(filters, filterState.selectedTransmissions, "transmission");

  if (filterState.inspection160) {
    filters.push({ label: "160-Point Inspection", type: "inspection", value: "160" });
  }
  if (labelFilter) {
    filters.push({ label: labelFilter, type: "label", value: labelFilter });
  }
  for (const refineFilter of refineSearchFilters) {
    filters.push({ label: refineFilter.label, type: "refineSearch", value: refineFilter.id });
  }

  for (const af of appliedFilters) {
    const label = af.displayText ?? af.value;
    filters.push({ label, type: "applied", value: af.value });
  }

  const unique: { label: string; type: string; value: string; isRefineSearch?: boolean }[] = [];
  const seen = new Set<string>();
  for (const f of filters) {
    const slugLabel = slugify(f.label || "");
    const slugValue = slugify(f.value || "");
    const keys = [`label:${slugLabel}`, `value:${slugValue}`, `type:${f.type}:${slugValue}`];

    const isDuplicate = keys.some((k) => seen.has(k));
    if (isDuplicate) {
      continue;
    }

    unique.push(f);
    for (const k of keys) {
      seen.add(k);
    }
  }

  return unique;
}

export interface SearchClientProps {
  initialQuickFilters?: string[];
}

export function SearchClient({ initialQuickFilters }: SearchClientProps) {
  const {
    vehiclePool,
    filterState,
    searchQuery,
    setSearchQuery,
    searchQueryRef,
    labelFilter,
    setLabelFilter,
    refineSearchFilters,
    setRefineSearchFilters,
    currentPage,
    setCurrentPage,
    isSearching,
    isFilterOpen,
    setIsFilterOpen,
    availableFilters,
    totalCount,
    totalPages,
    loadingFacetSections,
    applyFiltersSearch,
    isFilterPending,
    isInitialLoading,
    appliedFilters,
    flushSearchQuery,
  } = useSearchContext();

  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const prevPageRef = useRef(currentPage);

  // Scroll to top when page changes (Story 1.1 — added [currentPage] dep)
  useEffect(() => {
    if (prevPageRef.current === currentPage) {
      return;
    }
    prevPageRef.current = currentPage;
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [currentPage]);

  // ── URL sync ──────────────────────────────────────────────────────
  const [debouncedUrlQuery] = useDebouncedValue(searchQuery, 250);
  const lastWrittenQ = useRef(searchParams.get("q") ?? "");

  useEffect(() => {
    const trimmed = debouncedUrlQuery.trim();
    if (trimmed === lastWrittenQ.current) {
      return;
    }
    lastWrittenQ.current = trimmed;
    const serialized = serializeSearchUrlState(debouncedUrlQuery);
    const nextUrl = serialized ? `${pathname}?${serialized}` : pathname;
    router.replace(nextUrl, { scroll: false });
  }, [debouncedUrlQuery, pathname, router]);

  const handleApplyFilters = useCallback(
    (newState: FilterState) => {
      applyFiltersSearch(newState, {
        searchQuery,
        labelFilter,
        refineFilters: refineSearchFilters,
      });
    },
    [applyFiltersSearch, searchQuery, labelFilter, refineSearchFilters]
  );

  const activeFilters = useMemo(
    () => buildActiveFilters(filterState, labelFilter, refineSearchFilters, appliedFilters),
    [filterState, labelFilter, refineSearchFilters, appliedFilters]
  );

  const displaySearchQuery = searchQuery?.includes("-")
    ? searchQuery.replace(/-/g, " ")
    : searchQuery;

  const deferredVehicles = useDeferredValue(vehiclePool);
  const deferredTotalCount = useDeferredValue(totalCount);
  const isPending = deferredVehicles !== vehiclePool || isFilterPending;

  const removeFilter = (type: string, value: string) => {
    let nextState: FilterState = filterState;
    let nextLabelFilter = labelFilter;
    let nextRefine = refineSearchFilters;

    switch (type) {
      case "price":
        nextState = { ...filterState, selectedPriceQuick: "" };
        break;
      case "year":
        nextState = { ...filterState, selectedYearQuick: "" };
        break;
      case "mileage":
        nextState = { ...filterState, selectedMileage: "" };
        break;
      case "bodyStyle":
        nextState = {
          ...filterState,
          selectedBodyStyles: filterState.selectedBodyStyles.filter((v) => v !== value),
        };
        break;
      case "exteriorColor":
        nextState = {
          ...filterState,
          selectedExteriorColors: filterState.selectedExteriorColors.filter((v) => v !== value),
        };
        break;
      case "interiorColor":
        nextState = {
          ...filterState,
          selectedInteriorColors: filterState.selectedInteriorColors.filter((v) => v !== value),
        };
        break;
      case "fuelType":
        nextState = {
          ...filterState,
          selectedFuelTypes: filterState.selectedFuelTypes.filter((v) => v !== value),
        };
        break;
      case "model":
        nextState = {
          ...filterState,
          selectedModels: filterState.selectedModels.filter((v) => v !== value),
        };
        break;
      case "safetyFeature":
        nextState = {
          ...filterState,
          selectedSafetyFeatures: filterState.selectedSafetyFeatures.filter((v) => v !== value),
        };
        break;
      case "comfortFeature":
        nextState = {
          ...filterState,
          selectedComfortFeatures: filterState.selectedComfortFeatures.filter((v) => v !== value),
        };
        break;
      case "techFeature":
        nextState = {
          ...filterState,
          selectedTechFeatures: filterState.selectedTechFeatures.filter((v) => v !== value),
        };
        break;
      case "exteriorFeature":
        nextState = {
          ...filterState,
          selectedExteriorFeatures: filterState.selectedExteriorFeatures.filter((v) => v !== value),
        };
        break;
      case "performanceFeature":
        nextState = {
          ...filterState,
          selectedPerformanceFeatures: filterState.selectedPerformanceFeatures.filter(
            (v) => v !== value
          ),
        };
        break;
      case "seatingCapacity":
        nextState = {
          ...filterState,
          selectedSeatingCapacity: filterState.selectedSeatingCapacity.filter((v) => v !== value),
        };
        break;
      case "drivetrain":
        nextState = {
          ...filterState,
          selectedDrivetrains: filterState.selectedDrivetrains.filter((v) => v !== value),
        };
        break;
      case "transmission":
        nextState = {
          ...filterState,
          selectedTransmissions: filterState.selectedTransmissions.filter((v) => v !== value),
        };
        break;
      case "inspection":
        nextState = { ...filterState, inspection160: false };
        break;
      case "label":
        nextLabelFilter = "";
        setLabelFilter("");
        break;
      case "refineSearch":
        nextRefine = refineSearchFilters.filter((f) => f.id !== value);
        setRefineSearchFilters(nextRefine);
        break;
      default:
        break;
    }

    applyFiltersSearch(nextState, {
      searchQuery,
      labelFilter: nextLabelFilter,
      refineFilters: nextRefine,
    });
  };

  const resetFilters = () => {
    searchQueryRef.current = "";
    applyFiltersSearch(defaultFilterState, {
      searchQuery: "",
      labelFilter: "",
      refineFilters: [],
    });
  };

  // TODO: Revisit allModalFilterMeta — builds an index of all modal filter
  // options from mockVehicles to distinguish modal-originated filters from
  // sidebar filters during refine updates. Commented out pending review of
  // the full refine search UX and scalability (Story 1.3).
  //
  // const allModalFilterMeta = useMemo(() => {
  //   const { allFilters } = buildFilterOptions(mockVehicles);
  //   const ids = new Set<string>();
  //   const labelLower = new Set<string>();
  //   for (const f of allFilters) {
  //     ids.add(f.id);
  //     ids.add(slugify(f.label));
  //     labelLower.add(f.label.toLowerCase());
  //   }
  //   return { ids, labelLower };
  // }, []);

  const applyRefineFilters = (filters: { id: string; label: string }[]) => {
    const unique: { id: string; label: string }[] = [];
    for (const f of filters) {
      if (!unique.some((u) => u.id === f.id)) {
        unique.push(f);
      }
    }
    setRefineSearchFilters(unique);

    applyFiltersSearch(filterState, {
      searchQuery,
      labelFilter,
      refineFilters: unique,
    });
  };

  return (
    <div className="flex min-h-screen flex-col bg-gray-50 lg:px-0">
      <FilterSidebar
        availableFilters={availableFilters}
        filterState={filterState}
        isOpen={isFilterOpen}
        loadingFacetSections={loadingFacetSections}
        onApply={handleApplyFilters}
        onClose={() => setIsFilterOpen(false)}
        onReset={resetFilters}
        refineFilters={refineSearchFilters}
        vehicleCount={totalCount}
      />

      <main className="relative flex-1 bg-gray-100">
        <Suspense fallback={null}>
          <SearchHero
            activeFilters={activeFilters}
            onRemoveFilter={removeFilter}
            onReset={resetFilters}
            onSearch={() => {
              // Explicit submit — flush debounce so query fires immediately,
              // then update search query state + reset page.
              const query = searchQueryRef.current;
              setSearchQuery(query);
              flushSearchQuery(query);
              setCurrentPage(1);
            }}
            onSearchChange={(query) => {
              searchQueryRef.current = query;
            }}
            onToggleFilter={() => setIsFilterOpen(true)}
            searchQuery={displaySearchQuery}
            suggestedPills={initialQuickFilters}
            vehicleCount={totalCount}
          />
        </Suspense>

        <SearchProgressBar isSearching={isSearching} />

        <VehicleResults
          activeFilters={activeFilters}
          currentPage={currentPage}
          isInitialLoading={isInitialLoading}
          isPending={isPending}
          onApplyRefineFilters={applyRefineFilters}
          onPageChange={setCurrentPage}
          onRemoveFilter={removeFilter}
          onReset={resetFilters}
          onSearch={() => {
            const query = searchQueryRef.current;
            setSearchQuery(query);
            flushSearchQuery(query);
            setCurrentPage(1);
          }}
          onToggleFilter={() => setIsFilterOpen(true)}
          searchQuery={searchQuery}
          totalCount={deferredTotalCount}
          totalPages={totalPages}
          vehicles={deferredVehicles}
        />
      </main>
    </div>
  );
}
