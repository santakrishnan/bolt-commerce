import { SAVED_REGISTRY_STALE_TIME } from "@config/queries/constants";
import { getAllSavedVehicles } from "@features/favorites/services/saved-vehicles-api";
import { describe, expect, it } from "vitest";
import { savedVehicleQueries } from "./saved-vehicles";

describe("savedVehicleQueries — unit", () => {
  it("returns query options with correct key, fn, placeholder and staleTime", () => {
    const opts = savedVehicleQueries.all();

    expect(opts.queryKey).toEqual(["saved-vehicles"]);

    expect(opts.queryFn).toBe(getAllSavedVehicles);

    expect(opts.placeholderData).toEqual([]);

    expect(opts.staleTime).toBe(SAVED_REGISTRY_STALE_TIME);
  });
});
