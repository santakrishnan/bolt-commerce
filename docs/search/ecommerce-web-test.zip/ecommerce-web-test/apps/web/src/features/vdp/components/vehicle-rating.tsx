import { AppButton } from "@shared/components/button";
import { StarIcon } from "@tfs-ucmp/ui";

interface RatingDistribution {
  count: number;
  id: string;
  stars: number;
}

interface VehicleRatingProps {
  distribution: RatingDistribution[];
  rating: number;
  reviewCount: number;
  title: string;
}

export function VehicleRating({ title, rating, reviewCount, distribution }: VehicleRatingProps) {
  const totalRatings = distribution.reduce((sum, d) => sum + (d.count ?? 0), 0) || 1;
  const clampedRating = Math.min(Math.max(rating, 0), 5);
  const filledStarWidth = `calc(${clampedRating} * var(--spacing-5) + ${Math.max(
    0,
    Math.ceil(clampedRating) - 1
  )} * var(--spacing-xs))`;
  return (
    <div className="flex w-full flex-col gap-[var(--spacing-xl)] py-[var(--spacing-xl)] lg:flex-row lg:items-center lg:gap-[var(--spacing-xs)] lg:p-[var(--spacing-xl)]">
      <div className="flex flex-col items-center gap-[var(--spacing-5)] md:min-w-[421px] lg:items-start">
        <div className="font-[var(--font-weight-semibold)] text-[length:var(--font-size-md)] text-[var(--color-core-surfaces-foreground)]">
          {title}
        </div>
        <div className="flex items-center gap-[var(--spacing-md)]">
          <span className="font-[var(--font-weight-semibold)] text-[length:var(--text-2xl)] text-[var(--color-core-surfaces-foreground)] leading-[115%] lg:text-[length:var(--text-4xl)]">
            {rating.toFixed(1)}
          </span>
          <div
            aria-label={`${rating.toFixed(1)} out of 5 stars`}
            className="relative ml-[var(--spacing-xs)] flex gap-[var(--spacing-xs)]"
            role="img"
          >
            {/* Empty stars — base layer */}
            {[1, 2, 3, 4, 5].map((i) => (
              <StarIcon
                className="h-[var(--spacing-5)] w-[var(--spacing-5)] text-[var(--color-border)]"
                fill="none"
                key={i}
                size={20}
              />
            ))}
            {/* Filled stars — clipped overlay layer */}
            <div
              className="absolute inset-0 flex gap-[var(--spacing-xs)] overflow-hidden"
              style={{ width: filledStarWidth }}
            >
              {[1, 2, 3, 4, 5].map((i) => (
                <StarIcon
                  className="h-[var(--spacing-5)] w-[var(--spacing-5)] shrink-0 text-foreground"
                  fill="currentColor"
                  key={i}
                  size={20}
                  stroke="none"
                  strokeWidth={0}
                />
              ))}
            </div>
          </div>
        </div>
        <AppButton size="md" variant="tertiary">
          View More ({reviewCount} Reviews)
        </AppButton>
      </div>

      <div className="w-full flex-1">
        <div className="flex flex-col gap-[var(--spacing-xs)]">
          {distribution.map((d, _idx) => {
            const count = d.count ?? 0;
            const pct = (count / totalRatings) * 100;
            return (
              <div className="flex items-center gap-[var(--spacing-md)]" key={d.stars}>
                <span
                  className="w-[var(--spacing-2xl)] text-right font-[var(--font-weight-normal)] text-[length:var(--text-xs)] lg:text-[length:var(--text-sm)]"
                  id={`rating-bar-${d.stars}`}
                >
                  {d.stars} {d.stars === 1 ? "star" : "stars"}
                </span>
                <div
                  aria-labelledby={`rating-bar-${d.stars}`}
                  aria-valuemax={totalRatings}
                  aria-valuemin={0}
                  aria-valuenow={count}
                  className="h-[var(--spacing-xs)] flex-1 overflow-hidden rounded-[var(--radius-md)] bg-[var(--color-background-grey)]"
                  role="progressbar"
                >
                  <div
                    className="h-full bg-[var(--color-actions-primary)]"
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <span className="w-[var(--spacing-10)] text-left font-[var(--font-weight-normal)] text-[length:var(--text-xs)] text-[var(--color-core-surfaces-foreground)] lg:text-[length:var(--text-sm)]">
                  {count}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
