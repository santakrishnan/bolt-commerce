"use client";

import { cn, Tabs, TabsList, TabsTrigger } from "@tfs-ucmp/ui";
import { useState } from "react";

interface TabDef {
  content: React.ReactNode;
  contentClassName?: string;
  id: string;
  label: string;
}

interface VehicleDetailsTabsClientProps {
  className?: string;
  tabDefs: TabDef[];
}

const tabTriggerClassName =
  "shrink-0 whitespace-nowrap rounded-none border-transparent border-b-3 bg-transparent px-[var(--spacing-md)] pb-[var(--spacing-sd)] pt-[var(--spacing-5)] lg:px-[var(--spacing-lg)] lg:pb-[var(--spacing-sm)] lg:pt-0 font-normal text-[var(--color-core-surfaces-foreground)] text-[length:var(--font-size-md)] leading-normal data-[state=active]:border-[var(--color-actions-accent)] data-[state=active]:bg-transparent data-[state=active]:font-semibold data-[state=active]:text-[var(--color-core-surfaces-foreground)] data-[state=active]:shadow-none";

export function VehicleDetailsTabsClient({ className, tabDefs }: VehicleDetailsTabsClientProps) {
  const [activeId, setActiveId] = useState(tabDefs[0]?.id ?? "overview");
  const activeIndex = tabDefs.findIndex((tab) => tab.id === activeId);

  return (
    <div className={cn("w-full", className)}>
      <Tabs className="w-full" onValueChange={(id) => setActiveId(id)} value={activeId}>
        <div className="relative mb-[var(--spacing-lg)] w-full border-border border-b lg:mb-[var(--spacing-2xl)]">
          <div className="scrollbar-hide overflow-x-auto md:overflow-x-visible [&::-webkit-scrollbar]:hidden">
            <TabsList className="flex h-auto w-max flex-nowrap rounded-none border-0 bg-transparent p-0 md:w-full lg:gap-[var(--spacing-10)]">
              {tabDefs.map((tab) => (
                <TabsTrigger className={cn(tabTriggerClassName)} key={tab.id} value={tab.id}>
                  {tab.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>
        </div>
      </Tabs>

      <div className="relative overflow-hidden">
        <div className={tabDefs[activeIndex]?.contentClassName ?? ""} key={activeIndex}>
          {tabDefs[activeIndex]?.content ?? null}
        </div>
      </div>
    </div>
  );
}
