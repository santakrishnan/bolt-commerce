import { AppButton } from "@shared/components/button";

interface TestDriveCardProps {
  buttonText?: string;
}

export const TestDriveCard = ({ buttonText = "Book an Appointment" }: TestDriveCardProps) => {
  return (
    <AppButton className="w-full rounded-[var(--radius-full)]" size="md" variant="tertiary">
      {buttonText}
    </AppButton>
  );
};
