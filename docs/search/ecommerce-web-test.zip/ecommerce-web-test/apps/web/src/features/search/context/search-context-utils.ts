import { API_ROUTES } from "@config/routes/constants";
import type {
  FilterSearchRequest,
  FilterSearchResponse,
  SearchRequest,
  SearchResponse,
} from "@features/search/lib/search-types";
export async function fetchVehicleSearch(request: SearchRequest): Promise<SearchResponse> {
  const res = await fetch(API_ROUTES.SEARCH, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify({ ...request, includeFacets: false }),
  });

  if (!res.ok) {
    throw new Error(`Vehicle search failed: ${res.status}`);
  }

  return (await res.json()) as SearchResponse;
}

export async function fetchFilters(request: FilterSearchRequest): Promise<FilterSearchResponse> {
  const res = await fetch(API_ROUTES.SEARCH_FILTERS, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify(request),
  });

  if (!res.ok) {
    throw new Error(`Filters search failed: ${res.status}`);
  }

  return (await res.json()) as FilterSearchResponse;
}
