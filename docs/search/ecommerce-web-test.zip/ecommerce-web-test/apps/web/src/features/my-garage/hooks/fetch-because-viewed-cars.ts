import { getMyGarageData } from "@features/my-garage/services/my-garage.service";
import type { Vehicle } from "@shared/types";

/**
 * @deprecated Use `getMyGarageData()` from the service layer directly.
 * This wrapper is kept only for backward compatibility during the transition.
 */
export async function fetchBecauseYouViewedCars(): Promise<Vehicle[]> {
  const data = await getMyGarageData();
  return data.becauseYouViewed;
}
