export const ARROW_COOKIE = {
  SESSION_ID: "_arrow_session_id",
  FP_ID: "_arrow_fp_id",
  PROFILE_ID: "_arrow_profile_id",
  FP_EID: "_arrow_fp_eid",
} as const;

export const ARROW_HEADER = {
  SESSION_ID: "X-Arrow-Session-Id",
  FP_ID: "X-Arrow-Fp-Id",
  PROFILE_ID: "X-Arrow-Profile-Id",
  FP_EID: "X-Arrow-Fp-Eid",
} as const;

export const ARROW_TTL = {
  SESSION: 90 * 24 * 60 * 60,
  FINGERPRINT: 24 * 60 * 60,
  PROFILE: 24 * 60 * 60,
  EVENT: 24 * 60 * 60,
} as const;

export type ArrowCookieName = (typeof ARROW_COOKIE)[keyof typeof ARROW_COOKIE];
export type ArrowHeaderName = (typeof ARROW_HEADER)[keyof typeof ARROW_HEADER];
