import { API_ROUTES } from "@config/routes/constants";

export interface BatchCountQuery {
  id: string;
  searchQuery: string;
}

export interface BatchCountResponse {
  counts: Record<string, number>;
}

export async function fetchBatchCounts(
  queries: BatchCountQuery[]
): Promise<Record<string, number>> {
  const response = await fetch(API_ROUTES.SEARCH_BATCH_COUNTS, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify({ queries }),
  });

  if (!response.ok) {
    throw new Error(`Batch counts API failed: ${response.status}`);
  }

  const data = (await response.json()) as BatchCountResponse;
  return data.counts;
}

export const VEHICLE_FINDER_QUERIES: BatchCountQuery[] = [
  { id: "under-20k", searchQuery: "cars-under-$20,000" },
  { id: "excellent-deals", searchQuery: "shop-excellent-deals" },
  { id: "price-drop", searchQuery: "price-drop" },
  { id: "low-miles", searchQuery: "low-miles" },
];

export function fetchVehicleFinderBatchCounts(): Promise<Record<string, number>> {
  return fetchBatchCounts(VEHICLE_FINDER_QUERIES);
}
