import { CustomBadge } from "@shared/components/custom-badge";
import type React from "react";
export interface VehicleBadgesProps {
  className?: string;
  inspected: boolean;
  warranty: boolean;
}

export const VehicleBadges: React.FC<VehicleBadgesProps> = ({
  warranty,
  inspected,
  className = "grid grid-cols-3 gap-[var(--spacing-xs)]",
}) => {
  return (
    <div className={className}>
      <CustomBadge
        className="text-[length:var(--text-2xs)]"
        text="Excellent Price"
        type="excellentPrice"
      />
      {warranty && (
        <CustomBadge
          className="font-normal text-[length:var(--font-size-xs)] text-[var(--color-states-muted-foreground)]"
          text="Warranty"
          type="warranty"
        />
      )}
      {inspected && (
        <CustomBadge
          className="font-normal text-[length:var(--font-size-xs)] text-[var(--color-states-muted-foreground)]"
          text="Inspected"
          type="Inspected"
        />
      )}
    </div>
  );
};
