import { createAuthClient } from "better-auth/react";

/**
 * Client-side better-auth instance.
 *
 * Used in `"use client"` components to sign in, sign out, and read session
 * state via `authClient.useSession()`.
 *
 * The baseURL defaults to the current origin when NEXT_PUBLIC_BETTER_AUTH_URL
 * is not set, which is correct for same-origin Next.js deployments.
 */
export const authClient: ReturnType<typeof createAuthClient> = createAuthClient({
  baseURL: process.env.NEXT_PUBLIC_BETTER_AUTH_URL,
});
