"use client";

import { searchHistoryQueries } from "@features/search/queries/search-history";
import {
  addSearchEntry,
  clearSearchHistory,
  removeSearchEntry,
  type SearchEntry,
} from "@features/search/services/search-history-api";
import { useOptimisticListMutation } from "@shared/hooks/use-optimistic-list-mutation";
import { useQuery } from "@tanstack/react-query";
import { createContext, use, useCallback, useMemo } from "react";

export const SEARCH_HISTORY_KEY = searchHistoryQueries.all().queryKey;

interface SearchHistoryMutations {
  addSearch: (query: string, url: string, type?: "nlp" | "filter") => void;

  clearAll: () => void;

  removeSearch: (id: string) => void;
}

export interface SearchHistoryContextValue extends SearchHistoryMutations {
  isLoaded: boolean;
  searches: SearchEntry[];
}

const SearchHistoryContext = createContext<SearchHistoryMutations | null>(null);

// Mutation variable types

interface AddVars {
  query: string;
  type: "nlp" | "filter";
  url: string;
}

// Derived constants from query factory

const queryOpts = searchHistoryQueries.all();

// Provider

export function SearchHistoryProvider({ children }: { children: React.ReactNode }) {
  // Mutations using shared optimistic hook

  const { mutate: doAdd } = useOptimisticListMutation<SearchEntry, AddVars>({
    queryKey: queryOpts.queryKey,
    mutationFn: ({ query, url, type }) => addSearchEntry(query, url, type),
    updater: (prev, { query, url, type }) => {
      const trimmed = query.trim();
      if (trimmed.length <= 1) {
        return prev;
      }

      const entries = [...prev];
      const existingIdx = entries.findIndex((e) => e.query.toLowerCase() === trimmed.toLowerCase());

      if (existingIdx === -1) {
        entries.unshift({
          id: Date.now().toString(),
          query: trimmed,
          url,
          timestamp: new Date().toISOString(),
          type,
        });
      } else {
        const existing = entries[existingIdx] as SearchEntry;
        entries.splice(existingIdx, 1);
        entries.unshift({ ...existing, url, timestamp: new Date().toISOString() });
      }

      return entries.slice(0, 10);
    },
  });

  const { mutate: doRemove } = useOptimisticListMutation<SearchEntry, string>({
    queryKey: queryOpts.queryKey,
    mutationFn: (id) => removeSearchEntry(id),
    updater: (prev, id) => prev.filter((e) => e.id !== id),
  });

  const { mutate: doClear } = useOptimisticListMutation<SearchEntry, void>({
    queryKey: queryOpts.queryKey,
    mutationFn: () => clearSearchHistory(),
    updater: () => [],
  });

  // Stable action handlers

  const handleAdd = useCallback(
    (query: string, url: string, type: "nlp" | "filter" = "nlp") => doAdd({ query, url, type }),
    [doAdd]
  );

  const handleRemove = useCallback((id: string) => doRemove(id), [doRemove]);

  const handleClearAll = useCallback(() => doClear(), [doClear]);

  // Context value (mutations only)

  const value = useMemo<SearchHistoryMutations>(
    () => ({
      addSearch: handleAdd,
      removeSearch: handleRemove,
      clearAll: handleClearAll,
    }),
    [handleAdd, handleRemove, handleClearAll]
  );

  return <SearchHistoryContext value={value}>{children}</SearchHistoryContext>;
}

export function useSearchHistory(): SearchHistoryContextValue {
  const ctx = use(SearchHistoryContext);
  if (!ctx) {
    throw new Error("useSearchHistory must be used within a <SearchHistoryProvider>");
  }

  const { data: searches = [], isFetched } = useQuery(queryOpts);

  return {
    ...ctx,
    searches,
    isLoaded: isFetched,
  };
}
