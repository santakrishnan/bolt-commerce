"use client";

import { Collapsible, CollapsibleContent, CollapsibleTrigger, Heading } from "@tfs-ucmp/ui";
import Image from "next/image";
import { useEffect, useRef, useState } from "react";

export interface VehicleKeyFeaturesProps {
  className?: string;
  collapsible?: boolean;
  features: string[];
  gridClassName?: string;
  headingClassName?: string;
  iconClassName?: string;
  iconSrc?: string;
  itemClassName?: string;
  ref?: React.Ref<HTMLDivElement>;
  textClassName?: string;
}

export function VehicleKeyFeatures({
  features,
  className,
  collapsible = true,
  headingClassName = "mb-[var(--spacing-md)] text-[var(--color-core-surfaces-foreground)] text-[length:var(--font-size-xl)] lg:text-[length:var(--font-size-lg)] md:text-[length:var(--font-size-lg)] lg:mb-[var(--spacing-lg)]",
  gridClassName = "grid grid-cols-1 lg:grid-cols-2 lg:gap-(--spacing-3xl) lg:gap-y-(--spacing-md)",
  itemClassName = "flex items-center gap-[var(--spacing-md)] lg:gap-[var(--spacing-4)] lg:py-[var(--spacing-1)]",
  iconSrc = "/images/vdp/Vector_5.svg",
  iconClassName = "size-(--size-icon-md) shrink-0 lg:size-(--size-icon-md) text-[var(--color-core-surfaces-foreground)]",
  textClassName = "py-[var(--spacing-sm)] font-[var(--font-weight-normal)] text-[length:var(--font-size-sm)] text-[var(--color-core-surfaces-foreground)] lg:py-0",
  ref,
}: VehicleKeyFeaturesProps) {
  const [featuresExpanded, setFeaturesExpanded] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!contentRef.current) {
      return;
    }
    const el = contentRef.current;
    const scrollIntoViewNow = () => el.scrollIntoView({ behavior: "smooth", block: "start" });

    if (featuresExpanded) {
      // Wait for the expand transition to finish so the trigger
      // aligns consistently (matches subsequent clicks).
      const onTransitionEnd = () => {
        scrollIntoViewNow();
      };

      el.addEventListener("transitionend", onTransitionEnd);
      const t = setTimeout(scrollIntoViewNow, 350);

      return () => {
        el.removeEventListener("transitionend", onTransitionEnd);
        clearTimeout(t);
      };
    }
    return undefined;
  }, [featuresExpanded]);

  if (!collapsible) {
    return (
      <div className={className} ref={ref}>
        <Heading
          className={`${headingClassName} md:text-[length:var(--font-size-lg)] lg:text-[length:var(--font-size-lg)]`}
          level={2}
          weight="semibold"
        >
          Key Highlights
        </Heading>
        <div className={gridClassName}>
          {features.map((feature) => (
            <div className={itemClassName} key={feature}>
              <Image
                alt="Checkmark"
                aria-hidden="true"
                className={iconClassName}
                height={20}
                src={iconSrc}
                width={20}
              />
              <span className={textClassName}>{feature}</span>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const visibleFeatures = features.slice(0, 10);
  const hiddenFeatures = features.slice(10);

  return (
    <Collapsible
      className={className ?? ""}
      onOpenChange={setFeaturesExpanded}
      open={featuresExpanded}
    >
      <div
        className={`${featuresExpanded ? "mb-[var(--spacing-sm)]" : "mb-[var(--spacing-xs)]"} flex items-center justify-between`}
      >
        <Heading
          className="text-[length:var(--font-size-md)] text-[var(--color-core-surfaces-foreground)] leading-5.5"
          level={5}
          weight="semibold"
        >
          <span className="lg:hidden">Key Highlights</span>
          <span className="hidden lg:inline">Key Features</span>
        </Heading>
        <CollapsibleTrigger asChild>
          <button
            className="flex items-center gap-[var(--spacing-2xs)] font-semibold text-[length:var(--font-size-xs)] text-heading leading-sd hover:text-body"
            type="button"
          >
            {featuresExpanded ? "Collapse" : "Expand All"}
            <Image
              alt="Toggle features"
              className={`h-3 w-3 transition-transform duration-200 ${featuresExpanded ? "rotate-180" : ""}`}
              height={14}
              src="/images/vdp/chevron-down.svg"
              width={14}
            />
          </button>
        </CollapsibleTrigger>
      </div>

      {/* Mobile: Single column list with tick icons */}
      <div className="flex flex-col gap-sm lg:hidden">
        {visibleFeatures.map((feature) => (
          <div className="flex items-center gap-sm" key={feature}>
            <Image
              alt="Included"
              className="h-(--size-icon-md) w-(--size-icon-md) shrink-0 text-[var(--color-core-surfaces-foreground)]"
              height={20}
              src="/images/vdp/Tick.svg"
              width={20}
            />
            <span className="text-body text-sm-alt">{feature}</span>
          </div>
        ))}
      </div>
      {/* Desktop: Two column grid */}
      <div className="hidden grid-cols-2 gap-x-lg lg:grid">
        {visibleFeatures.map((feature) => (
          <div className="flex items-center gap-[var(--spacing-sm)] py-2" key={feature}>
            <Image
              alt="Included"
              className="h-3.5 w-3.5 shrink-0 text-[var(--color-core-surfaces-foreground)]"
              height={14}
              src="/images/vdp/Keyfeature.svg"
              width={14}
            />
            <span className="font-normal text-[length:var(--font-size-xs)]">{feature}</span>
          </div>
        ))}
      </div>

      {/* Collapsible extra features with animation */}
      {hiddenFeatures.length > 0 && (
        <div
          className={`grid transition-[grid-template-rows] duration-300 ease-in-out ${
            featuresExpanded ? "grid-rows-[1fr]" : "grid-rows-[0fr]"
          }`}
          ref={contentRef}
        >
          <div className="overflow-hidden">
            <CollapsibleContent forceMount>
              {/* Mobile */}
              <div className="mt-sm flex flex-col gap-sm pb-2xs lg:hidden">
                {hiddenFeatures.map((feature) => (
                  <div className="flex items-center gap-sm" key={feature}>
                    <Image
                      alt="Included"
                      className="h-(--size-icon-md) w-(--size-icon-md) shrink-0 text-[var(--color-core-surfaces-foreground)]"
                      height={20}
                      src="/images/vdp/Tick.svg"
                      width={20}
                    />
                    <span className="text-body text-sm-alt">{feature}</span>
                  </div>
                ))}
              </div>
              {/* Desktop */}
              <div className="hidden grid-cols-2 gap-x-lg lg:grid">
                {hiddenFeatures.map((feature) => (
                  <div className="flex items-center gap-[var(--spacing-sm)] py-2" key={feature}>
                    <Image
                      alt="Included"
                      className="h-3.5 w-3.5 shrink-0 text-[var(--color-core-surfaces-foreground)]"
                      height={14}
                      src="/images/vdp/Keyfeature.svg"
                      width={14}
                    />
                    <span className="font-normal text-[length:var(--font-size-xs)]">{feature}</span>
                  </div>
                ))}
              </div>
            </CollapsibleContent>
          </div>
        </div>
      )}
    </Collapsible>
  );
}
