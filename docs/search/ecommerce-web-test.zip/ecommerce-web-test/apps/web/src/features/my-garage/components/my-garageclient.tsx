"use client";

import { buildUsedCarsPath } from "@config/routes";
import { API_ROUTES } from "@config/routes/constants";
import { useFavorites } from "@features/favorites";
import { GarageCarCard } from "@features/my-garage/components/garage-car-card";
import { MyGarageCards } from "@features/my-garage/components/my-garage-cards";
import { TestDriveBanner } from "@features/my-garage/components/test-drive-banner";
import { parseDealerInfo } from "@features/my-garage/lib/helpers";
import type {
  MyGarageApiResponse,
  MyGarageData,
} from "@features/my-garage/services/my-garage-types";
import { useSearchHistory } from "@features/search";
import { VehiclePreviewModal } from "@features/vehicle-preview";
import type { Vehicle } from "@shared/types";
import { useQuery } from "@tanstack/react-query";
import { Heading } from "@tfs-ucmp/ui";
import { type ReactNode, useCallback, useMemo, useState } from "react";

interface MyGarageClientProps {
  children?: ReactNode;
  daysRemaining?: number;
  hasTradeInSubmitted?: boolean;
  initialData?: MyGarageData;
  isFirstTimeVisitor?: boolean;
  isPreQualified?: boolean;
}

export function MyGarageClient({
  children,
  isPreQualified = false,
  hasTradeInSubmitted = false,
  initialData,
  isFirstTimeVisitor = false,
  daysRemaining = 27,
}: MyGarageClientProps) {
  const { data, isLoading } = useQuery({
    queryKey: ["garage-profile"],
    queryFn: async () => {
      const res = await fetch(API_ROUTES.GARAGE_PROFILE);
      if (!res.ok) {
        throw new Error(`Garage API error: ${res.status}`);
      }
      return (await res.json()) as MyGarageApiResponse;
    },
    staleTime: 30_000,
    refetchOnWindowFocus: false,
  });

  // Use server-fetched initialData as fallback until the client query resolves
  const garageData = data?.data ?? initialData;

  const cars = garageData?.bestMatches ?? [];
  const becauseViewedCars = garageData?.becauseYouViewed ?? [];
  const becauseViewedLabel = garageData?.becauseYouViewedLabel ?? "Toyota Camry";
  const priceDrop = garageData?.recentPriceDrop ?? [];
  const [previewVin, setPreviewVin] = useState<string | null>(null);
  const { savedVins, removeVehicle } = useFavorites();
  const { searches, removeSearch, clearAll: clearAllSearches } = useSearchHistory();

  const recentSearchCards = useMemo(
    () => searches.map((entry) => ({ id: entry.id, search: entry.query, url: entry.url })),
    [searches]
  );

  const savedVehicles = useMemo(
    () =>
      savedVins
        .map((vin) => cars.find((c) => c.vin === vin))
        .filter((car): car is Vehicle => car !== undefined)
        .map((car) => ({
          id: car.vin,
          imageUrl: Array.isArray(car.image) ? (car.image[0] ?? "") : car.image,
          title: car.title,
          price: `$${car.price.toLocaleString()}`,
          miles: car.odometer,
        })),
    [savedVins, cars]
  );

  const handleRemoveSavedVehicle = useCallback(
    (id: number | string) => {
      removeVehicle(String(id));
    },
    [removeVehicle]
  );

  const selectedVehicle = previewVin ? cars.find((c) => c.vin === previewVin) : undefined;

  // Only show spinner when there's no server-provided initial data and the query is still in flight
  if (isLoading && !initialData) {
    return (
      <div className="relative min-h-screen bg-[var(--color-core-surfaces-background)]">
        <div className="flex items-center justify-center py-20">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-[var(--color-core-surfaces-foreground)] border-t-transparent" />
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen bg-[var(--color-core-surfaces-background)]">
      <div className="absolute inset-0 top-[400px] z-0 bg-[length:100%_auto] bg-[url('/images/garage/background.svg')] bg-position-[center_top] bg-no-repeat" />

      <div className="relative z-0 pt-xl">
        <div className="mx-auto w-full max-w-(--container-2xl) px-6 lg:px-20">
          {!isFirstTimeVisitor && (
            <Heading
              className="mb-[var(--spacing-md)] text-left text-lg md:mb-8 md:text-lg"
              level={2}
              weight="semibold"
            >
              My Garage
            </Heading>
          )}

          <div className="mb-10 w-full md:mb-[var(--spacing-3xl)]">
            {" "}
            <MyGarageCards
              financing={{ prequalified: isPreQualified, daysRemaining }}
              onClearAllSearches={clearAllSearches}
              onRemoveSavedVehicle={handleRemoveSavedVehicle}
              onRemoveSearch={removeSearch}
              onSavedVehicleClick={(id) => setPreviewVin(String(id))}
              recentSearches={recentSearchCards}
              savedVehicles={savedVehicles}
              tradeOffer={{
                imageUrl: hasTradeInSubmitted ? "/images/vehicles/offer.png" : undefined,
                title: hasTradeInSubmitted ? "2019 Audi A7" : undefined,
                price: hasTradeInSubmitted ? "$15,500" : undefined,
                miles: hasTradeInSubmitted ? "68,150 miles" : undefined,
                expiresIn: hasTradeInSubmitted ? "2 days" : undefined,
                hasSubmittedTradeIn: hasTradeInSubmitted,
              }}
            />
            {selectedVehicle &&
              (() => {
                const { distance } = parseDealerInfo(selectedVehicle.miles);
                const vdpUrl =
                  selectedVehicle.make &&
                  selectedVehicle.model &&
                  selectedVehicle.variant &&
                  selectedVehicle.year &&
                  selectedVehicle.vin
                    ? buildUsedCarsPath({
                        type: "details",
                        make: selectedVehicle.make,
                        model: selectedVehicle.model,
                        trim: selectedVehicle.variant,
                        year: selectedVehicle.year,
                        vin: selectedVehicle.vin,
                      })
                    : "#";
                return (
                  <VehiclePreviewModal
                    isOpen={!!previewVin}
                    onClose={() => setPreviewVin(null)}
                    vdpUrl={vdpUrl}
                    vehicle={{
                      year: selectedVehicle.year,
                      make: selectedVehicle.make,
                      model: selectedVehicle.model,
                      trim: selectedVehicle.variant,
                      price: selectedVehicle.price,
                      originalPrice: selectedVehicle.oldPrice ?? 0,
                      condition: selectedVehicle.labels[0] ?? "",
                      warranty: selectedVehicle.warranty,
                      inspected: selectedVehicle.inspection160,
                      miles: selectedVehicle.odometer,
                      drivetrain: selectedVehicle.drivetrain,
                      mpg: selectedVehicle.mpg,
                      stock: selectedVehicle.stock,
                      vin: selectedVehicle.vin,
                      exterior: selectedVehicle.extColorName,
                      exteriorColorCode: selectedVehicle.extColorCode,
                      interior: selectedVehicle.intColorName,
                      interiorColorCode: selectedVehicle.intColorCode,
                      dealer: selectedVehicle.dealerName,
                      location: selectedVehicle.dealerLocation,
                      distance,
                      images: Array.isArray(selectedVehicle.image)
                        ? selectedVehicle.image
                        : [selectedVehicle.image],
                      features: [
                        ...selectedVehicle.features.safety,
                        ...selectedVehicle.features.comfort,
                        ...selectedVehicle.features.tech,
                        ...selectedVehicle.features.exterior,
                        ...selectedVehicle.features.performance,
                      ],
                    }}
                    vin={selectedVehicle.vin}
                  />
                );
              })()}
          </div>

          <Heading
            className="mb-[var(--spacing-xl,32px)] text-left text-[length:var(--text-xl,20px)] text-[var(--color-core-surfaces-foreground,#0A0A0A)] md:text-[length:var(--text-lg,24px)]"
            level={2}
            weight="semibold"
          >
            Best Matches for you
          </Heading>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {cars.slice(0, 8).map((car, index) => (
              <div className={index >= 6 ? "lg:hidden xl:block" : undefined} key={car.id}>
                <GarageCarCard car={car} />
              </div>
            ))}
          </div>

          {children}
        </div>

        <div className="mb-10 w-full md:mb-[var(--spacing-4xl,80px)]">
          <TestDriveBanner />
        </div>

        <div className="mx-auto w-full max-w-(--container-2xl) px-6 lg:px-20">
          <Heading
            className="mb-4 text-left text-[length:var(--text-xl,20px)] text-[var(--color-core-surfaces-foreground,#0A0A0A)] md:mb-8 md:text-[length:var(--text-lg,24px)]"
            level={2}
            weight="semibold"
          >
            Because You Viewed {becauseViewedLabel}
          </Heading>
          <div className="mb-[var(--spacing-md,16px)] grid grid-cols-1 gap-4 sm:grid-cols-2 md:mb-[var(--spacing-3xl,64px)] lg:grid-cols-3 xl:grid-cols-4">
            {becauseViewedCars.slice(0, 4).map((car, index) => (
              <div className={index >= 3 ? "lg:hidden xl:block" : undefined} key={car.id}>
                <GarageCarCard car={car} />
              </div>
            ))}
          </div>

          <Heading
            className="mt-[var(--spacing-10,40px)] mb-8 text-left text-[length:var(--text-xl,20px)] text-[var(--color-core-surfaces-foreground,#0A0A0A)] md:mt-0 md:text-[length:var(--text-lg,24px)]"
            level={2}
            weight="semibold"
          >
            Recent Price Drop
          </Heading>
          <div className="mb-[var(--spacing-10,40px)] grid grid-cols-1 gap-4 pb-[var(--spacing-md,16px)] sm:grid-cols-2 md:mb-0 md:pb-[var(--spacing-4xl,80px)] lg:grid-cols-3 xl:grid-cols-4">
            {priceDrop.slice(0, 4).map((car, index) => (
              <div className={index >= 3 ? "lg:hidden xl:block" : undefined} key={car.id}>
                <GarageCarCard
                  badgeOverride={{ type: "priceDrop", text: "Price Drop" }}
                  car={car}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
