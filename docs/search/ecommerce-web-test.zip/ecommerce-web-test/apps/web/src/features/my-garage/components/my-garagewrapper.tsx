import {
  customerPreQualified,
  customerTradeInSubmitted,
  getUserInfo,
  showDefaultLandingHero,
} from "@config/flags/flags";
import { HomeHero } from "@features/landing";
import { VehicleQuickLinksGrid } from "@features/landing/components/vehicle-quick-links";
import { MyGarageClient } from "@features/my-garage/components/my-garageclient";
import { fetchBecauseYouViewedCars } from "@features/my-garage/hooks/fetch-because-viewed-cars";
import { fetchGarageCars } from "@features/my-garage/hooks/fetch-garage-cars";
import { resolveHeroDeviceTypeFromUserAgent } from "@shared/lib/device-type";
import { Heading } from "@tfs-ucmp/ui";
import { headers } from "next/headers";

export async function MyGarageWrapper({
  showUserName = false,
  knownUserOverrides,
  bannerHeightClass,
}: {
  showUserName?: boolean;
  knownUserOverrides?: { showCards?: boolean };
  bannerHeightClass?: string;
} = {}) {
  const headerStore = await headers();
  const deviceType = resolveHeroDeviceTypeFromUserAgent(headerStore.get("user-agent") ?? "");
  const [cars, becauseYouViewed, userInfo, isPreQualified, hasTradeInSubmitted, isNewUser] =
    await Promise.all([
      fetchGarageCars(),
      fetchBecauseYouViewedCars(),
      getUserInfo(),
      customerPreQualified(),
      customerTradeInSubmitted(),
      showDefaultLandingHero(),
    ]);
  const userName = userInfo.firstName.toUpperCase();
  const daysRemaining = userInfo.daysRemaining ?? 27;

  const knownUser: Parameters<typeof HomeHero>[0]["knownUser"] = {
    ...(isNewUser && { bannerTitle: "MY GARAGE" }),
    userName: showUserName ? userName : "",
    showCards: false,
    showSubtitle: false,
    ...knownUserOverrides,
  };

  return (
    <>
      <HomeHero
        bannerHeightClass={bannerHeightClass ?? "h-[422px] lg:h-90"}
        deviceType={deviceType}
        heightClassName={bannerHeightClass ?? "h-[422px] lg:h-90"}
        knownUser={knownUser}
        showSearch={true}
        showStats={false}
        showSubtitle={false}
        useLocationBackground={true}
      />
      <MyGarageClient
        becauseViewedCars={becauseYouViewed}
        cars={cars}
        daysRemaining={daysRemaining}
        hasTradeInSubmitted={hasTradeInSubmitted}
        isFirstTimeVisitor={isNewUser}
        isPreQualified={isPreQualified}
      >
        <section className="w-full bg-transparent pt-[var(--spacing-10)] pb-[var(--spacing-10)] sm:pb-[var(--spacing-10)] md:pt-[var(--spacing-3xl,64px)] lg:pb-[var(--spacing-4xl)]">
          <div>
            <Heading
              className="mb-[var(--spacing-xl,32px)] text-center font-semibold text-[length:var(--text-lg,24px)] text-[var(--color-core-surfaces-foreground,#0A0A0A)] sm:mb-[var(--spacing-10)] lg:text-[length:var(--text-2xl)]"
              level={2}
              weight="semibold"
            >
              Find your vehicle
            </Heading>
            <VehicleQuickLinksGrid cardBackgroundColor="bg-white" />
          </div>
        </section>
      </MyGarageClient>
    </>
  );
}
