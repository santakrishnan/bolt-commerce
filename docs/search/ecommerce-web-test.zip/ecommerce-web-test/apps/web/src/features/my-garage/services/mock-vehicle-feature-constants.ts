/**
 * Shared feature constant arrays used by both mock datasets
 * (mock-vehicles.ts in search and mock-because-viewed.ts in my-garage).
 *
 * These are mock-only — the real API returns feature arrays per vehicle.
 */

export const BASE_SAFETY = ["PCS", "LDA", "Backup Camera", "FCW"];
export const FULL_SAFETY = [...BASE_SAFETY, "BSM", "ACC", "RCTA", "LTA", "RSA", "Auto High Beams"];

export const BASE_TECH = ["Apple CarPlay", "Android Auto", "Bluetooth", "USB-C"];
export const MID_TECH = [...BASE_TECH, "Wireless Charging", "Navigation", "Digital Cluster"];

export const BASE_COMFORT = ["Keyless", "Push Start", "Dual Climate"];
export const MID_COMFORT = [...BASE_COMFORT, "Heated Seats", "Power Liftgate", "Heated Wheel"];

export const BASE_EXT = ["LED Headlights", "LED Taillights"];
export const FULL_EXT = [...BASE_EXT, "LED Fog", "Folding Mirrors", "Adaptive Lights"];
