/** Cache-optimized VDP data functions for direct page-level use. Composes VIN-only cached service functions, sharing entries across all users. */

import { cacheLife, cacheTag } from "next/cache";
import { fetchDealerByVinCached } from "./dealer.service";
import { fetchVinDataCached } from "./vdp.service";
import type { VehicleBundle } from "./vdp-api";

/** Cached per VIN — fetches product data + dealer info in parallel. */
export async function getVehicleBundleCached(vin: string): Promise<VehicleBundle> {
  "use cache";
  cacheLife("vdp");
  cacheTag("vdp", `bundle-${vin}`);

  const [vinData, dealerInfo] = await Promise.all([
    fetchVinDataCached(vin),
    fetchDealerByVinCached(vin),
  ]);
  return { vinData, dealerInfo };
}
