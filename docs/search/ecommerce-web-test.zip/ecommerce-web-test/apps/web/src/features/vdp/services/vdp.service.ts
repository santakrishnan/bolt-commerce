import {
  ArrowServerError,
  type ArrowServerIds,
  createArrowServerClient,
} from "@features/tracking/lib/server-api";
import { cacheLife, cacheTag } from "next/cache";
import type { VinData } from "./types";
import { fetchMockVinData } from "./vdp.mocks";

export interface VdpFetchOptions {
  forwardHeaders?: Record<string, string>;
  ids?: ArrowServerIds;
}

let _client: ReturnType<typeof createArrowServerClient> | null = null;

function getVdpClient() {
  if (!_client) {
    _client = createArrowServerClient({
      baseUrl: process.env.VDP_SERVICE_URL ?? "",
      authToken: process.env.VDP_API_KEY,
      serviceName: "VDPService",
      timeout: 10_000,
      retries: 1,
    });
  }
  return _client;
}

function isMockMode(): boolean {
  return !process.env.VDP_SERVICE_URL || process.env.USE_MOCK_VDP === "true";
}

/**
 * Uncached VIN data fetch — used by API route handlers that forward
 * per-user Arrow tracking headers. Do NOT add "use cache" here
 */
export async function fetchVinData(vin: string, options: VdpFetchOptions = {}): Promise<VinData> {
  if (isMockMode()) {
    return await fetchMockVinData(vin);
  }

  try {
    return await getVdpClient().get<VinData>(`/vdp/vehicles/${vin}`, {
      ids: options.ids,
      headers: options.forwardHeaders,
    });
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[VDPService] Upstream error (vin-data):", error.message);
    } else {
      console.error("[VDPService] Unexpected error (vin-data):", error);
    }
    return await fetchMockVinData(vin);
  }
}

/**
 * Cached VIN data fetch — called directly from server components.
 * Uses "use cache" + cacheLife/cacheTag for ISR-style per-VIN caching.
 * Calls the backend API directly (no proxy hop through API routes).
 *
 * API routes (/api/search/vehicle/[id]) exist for client-side consumers only.
 */
export async function fetchVinDataCached(vin: string): Promise<VinData> {
  "use cache";
  cacheLife("vdp");
  cacheTag("vdp", `vin-${vin}`);

  if (isMockMode()) {
    return await fetchMockVinData(vin);
  }

  try {
    return await getVdpClient().get<VinData>(`/vdp/vehicles/${vin}`);
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[VDPService] Upstream error (vin-data-cached):", error.message);
    } else {
      console.error("[VDPService] Unexpected error (vin-data-cached):", error);
    }
    return await fetchMockVinData(vin);
  }
}
