import type { HeroStat, VehicleFinderOptionStatic } from "./types";

export const DEFAULT_HERO_STATS: HeroStat[] = [
  {
    id: "vehicles",
    value: "0",
    label: "Vehicles Available",
    icon: "/images/heroes/vehicle-availability.svg",
  },
  { id: "vin", value: "100%", label: "Verified VIN", icon: "/images/heroes/vehicle-vin.svg" },
  { id: "money-back", value: "7-Day", label: "Money Back", icon: "/images/heroes/money-back.svg" },
  {
    id: "rating",
    value: "4.93",
    label: "Customer Rating",
    icon: "/images/heroes/customer-rating.svg",
  },
];

export const DEFAULT_VEHICLE_FINDER_OPTIONS: VehicleFinderOptionStatic[] = [
  { id: "under-20k", title: "Cars Under $20,000", icon: "price-tag" },
  { id: "excellent-deals", title: "Shop Excellent Deals", icon: "badge" },
  { id: "price-drop", title: "Price Drop", icon: "arrow-down" },
  { id: "low-miles", title: "Low Miles", icon: "speedometer" },
];
