import { createLocalStorageMock, render, screen, waitFor } from "@arrow/vitest-config/test-utils";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { SignInForm } from "../components/sign-in-form";

vi.stubGlobal("localStorage", createLocalStorageMock());

// ── Mocks ────────────────────────────────────────────────────────────────────

// vi.mock is hoisted — use vi.hoisted() so variables are available at hoist time.
const { mockPush, mockRefresh, mockSignInEmail } = vi.hoisted(() => ({
  mockPush: vi.fn(),
  mockRefresh: vi.fn(),
  mockSignInEmail: vi.fn(),
}));

vi.mock("next/navigation", () => ({
  useRouter: () => ({ push: mockPush, refresh: mockRefresh }),
}));

vi.mock("../lib/auth-client", () => ({
  authClient: {
    signIn: {
      email: mockSignInEmail,
    },
  },
}));

const SIGN_IN_REGEX = /sign in/i;
const SIGNING_IN_REGEX = /signing in/i;

function setup() {
  const user = userEvent.setup();
  render(<SignInForm />);

  return {
    user,
    emailInput: () => screen.getByLabelText("Email"),
    passwordInput: () => screen.getByLabelText("Password"),
    submitButton: () => screen.getByRole("button", { name: SIGN_IN_REGEX }),
  };
}

describe("SignInForm", () => {
  beforeEach(() => {
    mockPush.mockReset();
    mockRefresh.mockReset();
    mockSignInEmail.mockReset();
    localStorage.clear();
    // biome-ignore lint/suspicious/noDocumentCookie: test setup intentionally resets cookie state
    document.cookie = "feature-flags-user=; path=/; max-age=0";
  });
  describe("initial render", () => {
    it("renders the email input", () => {
      setup();
      expect(screen.getByLabelText("Email")).toBeInTheDocument();
    });

    it("renders the password input", () => {
      setup();
      expect(screen.getByLabelText("Password")).toBeInTheDocument();
    });

    it("renders the submit button", () => {
      setup();
      expect(screen.getByRole("button", { name: SIGN_IN_REGEX })).toBeInTheDocument();
    });

    it("does not show an error message initially", () => {
      setup();
      expect(screen.queryByRole("alert")).not.toBeInTheDocument();
    });
  });

  describe("successful sign-in", () => {
    it("calls authClient.signIn.email with typed credentials", async () => {
      mockSignInEmail.mockResolvedValueOnce({
        data: { user: { email: "alice@example.com" } },
        error: null,
      });
      const { user, emailInput, passwordInput, submitButton } = setup();

      await user.type(emailInput(), "alice@example.com");
      await user.type(passwordInput(), "Demo@1234");
      await user.click(submitButton());

      expect(mockSignInEmail).toHaveBeenCalledWith({
        email: "alice@example.com",
        password: "Demo@1234",
      });
    });

    it("redirects to /my-garage on success", async () => {
      mockSignInEmail.mockResolvedValueOnce({ data: {}, error: null });
      const { user, emailInput, passwordInput, submitButton } = setup();

      await user.type(emailInput(), "alice@example.com");
      await user.type(passwordInput(), "Demo@1234");
      await user.click(submitButton());

      await waitFor(() => {
        expect(mockPush).toHaveBeenCalledWith("/my-garage");
      });
    });

    it("calls router.refresh() after successful sign-in", async () => {
      mockSignInEmail.mockResolvedValueOnce({ data: {}, error: null });
      const { user, emailInput, passwordInput, submitButton } = setup();

      await user.type(emailInput(), "alice@example.com");
      await user.type(passwordInput(), "Demo@1234");
      await user.click(submitButton());

      await waitFor(() => {
        expect(mockRefresh).toHaveBeenCalled();
      });
    });

    it("syncs sample-user feature-flag profile to localStorage", async () => {
      mockSignInEmail.mockResolvedValueOnce({ data: {}, error: null });
      const { user, emailInput, passwordInput, submitButton } = setup();

      await user.type(emailInput(), "alice@example.com");
      await user.type(passwordInput(), "Demo@1234");
      await user.click(submitButton());

      await waitFor(() => {
        expect(localStorage.getItem("feature-flags-user")).toBe("authenticatedPrequalified");
      });
    });
  });

  describe("failed sign-in", () => {
    it("shows the error message returned from the auth client", async () => {
      mockSignInEmail.mockResolvedValueOnce({
        data: null,
        error: { message: "Invalid credentials" },
      });
      const { user, emailInput, passwordInput, submitButton } = setup();

      await user.type(emailInput(), "wrong@example.com");
      await user.type(passwordInput(), "WrongPassword");
      await user.click(submitButton());

      await waitFor(() => {
        expect(screen.getByRole("alert")).toHaveTextContent("Invalid credentials");
      });
    });

    it("shows a fallback message when the error has no message", async () => {
      mockSignInEmail.mockResolvedValueOnce({ data: null, error: {} });
      const { user, emailInput, passwordInput, submitButton } = setup();

      await user.type(emailInput(), "wrong@example.com");
      await user.type(passwordInput(), "WrongPassword");
      await user.click(submitButton());

      await waitFor(() => {
        expect(screen.getByRole("alert")).toHaveTextContent("Sign in failed");
      });
    });

    it("does not redirect on failure", async () => {
      mockSignInEmail.mockResolvedValueOnce({
        data: null,
        error: { message: "Invalid credentials" },
      });
      const { user, emailInput, passwordInput, submitButton } = setup();

      await user.type(emailInput(), "wrong@example.com");
      await user.type(passwordInput(), "WrongPassword");
      await user.click(submitButton());

      await waitFor(() => {
        expect(screen.getByRole("alert")).toBeInTheDocument();
      });

      expect(mockPush).not.toHaveBeenCalled();
    });
  });

  describe("loading state", () => {
    it("shows 'Signing in…' while the request is in flight", async () => {
      let resolve!: () => void;
      mockSignInEmail.mockReturnValueOnce(
        new Promise((res) => {
          resolve = () => res({ data: {}, error: null });
        })
      );

      const { user, emailInput, passwordInput, submitButton } = setup();
      await user.type(emailInput(), "alice@example.com");
      await user.type(passwordInput(), "Demo@1234");

      // Capture button before clicking — text changes to "Signing in…" after click
      const btn = submitButton();
      await user.click(btn);

      expect(screen.getByRole("button", { name: SIGNING_IN_REGEX })).toBeInTheDocument();

      resolve();
    });

    it("disables the submit button while loading", async () => {
      let resolve!: () => void;
      mockSignInEmail.mockReturnValueOnce(
        new Promise((res) => {
          resolve = () => res({ data: {}, error: null });
        })
      );

      const { user, emailInput, passwordInput, submitButton } = setup();
      await user.type(emailInput(), "alice@example.com");
      await user.type(passwordInput(), "Demo@1234");

      const btn = submitButton();
      await user.click(btn);

      expect(btn).toBeDisabled();

      resolve();
    });
  });
});
