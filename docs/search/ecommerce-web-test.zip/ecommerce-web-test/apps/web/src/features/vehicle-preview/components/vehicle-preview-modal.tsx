"use client";
import { VehicleBadges } from "@features/vdp/components/badges-vehicle";
import { VehicleColors } from "@features/vdp/components/colors-vehicle";
import { VehicleDealerInfo } from "@features/vdp/components/dealer-info";
import { ImageCarousel } from "@features/vdp/components/image-thumbnail-carousal";
import { VehicleKeyFeatures } from "@features/vdp/components/key-features";
import { VehiclePrice } from "@features/vdp/components/price-and-wasprice";
import { VehicleSpecsGrid } from "@features/vdp/components/specs";
import { VehicleTitle } from "@features/vdp/components/title";
import { VehicleActionIcons } from "@features/vdp/components/vehicle-action-icons";
import { AppButton } from "@shared/components/button";
import { demoVehiclePreview, type VehiclePreviewData } from "@shared/data/vehicle-preview";
import { Button, Dialog, DialogContent } from "@tfs-ucmp/ui";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type React from "react";
import { useCallback, useEffect, useRef, useState } from "react";

const PrevDivider: React.FC = () => (
  <div className="h-[var(--border-width-1,1px)] w-full shrink-0 bg-[var(--structure-interaction-overlay-border,rgba(212,212,212,0.50))]" />
);

export interface VehiclePreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  vdpUrl?: string;
  vehicle?: Partial<VehiclePreviewData>;
  vin?: string;
}

export const VehiclePreviewModal: React.FC<VehiclePreviewModalProps> = ({
  isOpen,
  onClose,
  vehicle: vehicleProp,
  vdpUrl,
  vin,
}) => {
  // Merge provided vehicle data with demo defaults so partial data always renders safely
  const vehicle = { ...demoVehiclePreview, ...vehicleProp };
  const pathname = usePathname();
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  // Close modal when route changes (e.g. "Full Details" link navigates to VDP).
  // This clears the cached React state so router.back() returns to a clean SRP.
  // biome-ignore lint/correctness/useExhaustiveDependencies: intentionally fires only on pathname change
  useEffect(() => {
    onCloseRef.current();
  }, [pathname]);
  const [_isScrolling, setIsScrolling] = useState(false);
  const [canScrollUp, setCanScrollUp] = useState(false);
  const [canScrollDown, setCanScrollDown] = useState(false);
  const scrollTimeoutRef = useRef<ReturnType<typeof setTimeout>>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Sets `canScrollUp` / `canScrollDown` flags based on current scroll position
  const updateScrollIndicators = useCallback(() => {
    const container = scrollContainerRef.current;
    if (container) {
      const { scrollTop, scrollHeight, clientHeight } = container;
      setCanScrollUp(scrollTop > 0);
      setCanScrollDown(scrollTop + clientHeight < scrollHeight - 1);
    }
  }, []);
  // Enter scrolling state, update indicators, and debounce end-of-scroll
  const handleScroll = useCallback(() => {
    setIsScrolling(true);
    updateScrollIndicators();
    if (scrollTimeoutRef.current) {
      clearTimeout(scrollTimeoutRef.current);
    }
    scrollTimeoutRef.current = setTimeout(() => {
      setIsScrolling(false);
    }, 400);
  }, [updateScrollIndicators]);

  // Check scroll indicators when modal opens
  useEffect(() => {
    if (isOpen) {
      setTimeout(updateScrollIndicators, 100);
    }
  }, [isOpen, updateScrollIndicators]);

  return (
    <Dialog onOpenChange={(open) => !open && onClose()} open={isOpen}>
      <DialogContent
        className="top-15! left-1/2! h-[calc(100%-60px)] w-full max-w-350 -translate-x-1/2! translate-y-0! rounded-t-[var(--radius-2xl)]! p-0! lg:top-15.5! lg:h-[calc(100vh-129px)] lg:w-[calc(100vw-var(--spacing-10)*2)] lg:rounded-[var(--radius-xl)]! [&>button]:hidden"
        overlayClassName="inset-0! top-0! bg-[var(--color-core-surfaces-foreground)]/70"
      >
        <div className="flex h-full flex-col overflow-hidden rounded-t-[var(--radius-2xl)] bg-surface lg:rounded-[var(--radius-lg)]">
          {/* Header */}
          <div className="flex items-center justify-between border-surface border-b px-md py-sm lg:px-10 lg:py-lg">
            <Button
              className="flex items-center gap-xs font-medium text-heading text-sm hover:opacity-70 lg:hidden"
              onClick={onClose}
              type="button"
              variant="search"
            >
              <Image
                alt="Back to search"
                className="h-(--size-icon-md) w-(--size-icon-md)"
                height={20}
                src="/images/vdp/chevron-left.svg"
                width={20}
              />
              <span>Back to Search</span>
            </Button>
            <span className="hidden font-normal text-foreground text-md leading-5 lg:block">
              Vehicle Preview
            </span>
            <div className="flex items-center gap-lg">
              <VehicleActionIcons
                showFav={true}
                showPrint={true}
                showShare={true}
                vdpUrl={vdpUrl}
                vehicle={vehicle}
                vin={vin}
              />
              <Button
                className="cursor-pointer pl-xs hover:opacity-70"
                onClick={onClose}
                type="button"
                variant="search"
              >
                <Image
                  alt="Close dialog"
                  className="h-6 w-6"
                  height={24}
                  src="/images/vdp/x-close.svg"
                  width={24}
                />
              </Button>
            </div>
          </div>

          {/* Main Content - Image and Details */}
          <div
            className="scrollbar-hide flex min-h-0 flex-1 flex-col overflow-y-auto lg:flex-row lg:overflow-hidden lg:pb-[var(--spacing-xl)]"
            onScroll={handleScroll}
          >
            {/* Left Side - Image Section (65% on desktop) */}
            <div className="flex shrink-0 flex-col gap-(--spacing-sm) lg:min-h-0 lg:w-[65%] lg:shrink lg:gap-[var(--spacing-5)] lg:pt-0 lg:pr-11.25 lg:pl-(--spacing-10)">
              <ImageCarousel
                alt={vehicle.title ?? "Vehicle preview image"}
                images={vehicle.images}
              />
            </div>
            {/* Right Side - Details (35% on desktop) */}
            <div className="relative flex flex-col justify-between bg-surface px-lg lg:min-h-0 lg:w-[35%] lg:overflow-hidden lg:px-0 lg:pt-0 lg:pr-(--spacing-10)">
              {/* Top gradient - shows when can scroll up */}
              {canScrollUp && (
                <div className="pointer-events-none absolute top-0 right-0 left-0 z-10 h-8 bg-gradient-to-b from-white to-white/0 lg:right-(--spacing-10)" />
              )}
              {/* Scrollable Content Area */}
              <div
                className="scrollbar-hide vehicle-preview-scroll flex min-h-0 flex-1 flex-col gap-[var(--spacing-lg)] overflow-y-auto lg:pb-0 [&::-webkit-scrollbar]:hidden"
                onScroll={handleScroll}
                ref={scrollContainerRef}
              >
                <div className="pt-lg lg:pt-0">
                  <VehicleTitle title={vehicle.title} />
                  <VehiclePrice originalPrice={vehicle.originalPrice} price={vehicle.price} />
                </div>
                <VehicleBadges inspected={vehicle.inspected} warranty={vehicle.warranty} />
                <PrevDivider />
                <VehicleSpecsGrid
                  drivetrain={vehicle.drivetrain}
                  miles={vehicle.miles}
                  mpg={vehicle.mpg}
                  stock={vehicle.stock}
                  vin={vehicle.vin}
                />
                <PrevDivider />
                <VehicleColors
                  exteriorColorCode={vehicle.exteriorColorCode}
                  exteriorName={vehicle.exterior}
                  interiorColorCode={vehicle.interiorColorCode}
                  interiorName={vehicle.interior}
                />
                <PrevDivider />
                <VehicleDealerInfo
                  dealerLocation={vehicle.location}
                  dealerName={vehicle.dealer}
                  distance={vehicle.distance}
                />
                <div className="flex flex-col gap-[var(--spacing-lg)] lg:gap-[16px]">
                  <PrevDivider />
                  <VehicleKeyFeatures className="pb-[20px]" features={vehicle.features} />
                </div>
              </div>
              {/* Bottom gradient - shows when can scroll down */}
              {canScrollDown && (
                <div className="pointer-events-none absolute right-0 bottom-14 left-0 z-10 h-8 bg-gradient-to-b from-white/0 to-white lg:right-(--spacing-10) lg:bottom-10" />
              )}
              {/* Desktop Full Details Button - Fixed at bottom, hides on scroll */}
              <div className="shrink-0 bg-surface pb-(--spacing-5) lg:block lg:pb-0">
                <AppButton asChild={!!vdpUrl} className="w-full" size="md" variant="primary">
                  {vdpUrl ? <Link href={vdpUrl}>Full Details</Link> : "Full Details"}
                </AppButton>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
