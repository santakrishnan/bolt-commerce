export interface HeroStat {
  icon: string;
  id: string;
  label: string;
  value: string;
}

export interface VehicleFinderOption {
  icon: "price-tag" | "badge" | "arrow-down" | "speedometer";
  id: string;
  title: string;
  vehicleCount: number;
}

export interface VehicleFinderOptionStatic {
  icon: "price-tag" | "badge" | "arrow-down" | "speedometer";
  id: string;
  title: string;
}

export interface VehicleFinderCounts {
  "excellent-deals": number;
  "low-miles": number;
  "price-drop": number;
  "under-20k": number;
}

export interface VehicleFinderData {
  counts: VehicleFinderCounts;
  options: VehicleFinderOptionStatic[];
}

export interface RawHeroStat {
  display_name?: string;
  icon?: string;
  icon_url?: string;
  id?: string;
  key?: string;
  label?: string;
  metric_value?: string | number;
  value?: string | number;
}

export interface RawHeroStatsResponse {
  data?: RawHeroStat[];
  features?: RawHeroStat[];
  metrics?: RawHeroStat[];
  stats?: RawHeroStat[];
}

export interface RawVehicleFinderCountsResponse {
  counts?: Record<string, number>;
  data?: Record<string, number>;
  [key: string]: unknown;
}
