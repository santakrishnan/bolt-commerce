"use client";

import { savedVehicleQueries } from "@features/favorites/queries/saved-vehicles";
import {
  clearAllSavedVehicles,
  saveVehicle,
  unsaveVehicle,
} from "@features/favorites/services/saved-vehicles-api";
import { useOptimisticListMutation } from "@shared/hooks/use-optimistic-list-mutation";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createContext, use, useCallback, useMemo } from "react";

const queryOpts = savedVehicleQueries.all();

interface FavoritesContextValue {
  addVehicle: (vin: string) => void;
  clearAll: () => void;
  isLoaded: boolean;
  isVehicleSaved: (vin: string) => boolean;
  removeVehicle: (vin: string) => void;
  savedCount: number;
  savedVins: string[];
  toggleVehicle: (vin: string) => void;
}

const FavoritesContext = createContext<FavoritesContextValue | null>(null);

/**
 * Provides favorites context: loads saved VINs and exposes helpers to add/remove/toggle and clear favorites.
 * Uses optimistic mutations and react-query cache for fast UI updates.
 */
export function FavoritesProvider({ children }: { children: React.ReactNode }) {
  const queryClient = useQueryClient();
  const { data: savedVins = [], isFetched } = useQuery(queryOpts);
  const { mutate: doSave } = useOptimisticListMutation<string, string>({
    queryKey: queryOpts.queryKey,
    mutationFn: (vin) => saveVehicle(vin),
    updater: (prev, vin) => (prev.includes(vin) ? prev : [...prev, vin]),
  });

  const { mutate: doUnsave } = useOptimisticListMutation<string, string>({
    queryKey: queryOpts.queryKey,
    mutationFn: (vin) => unsaveVehicle(vin),
    updater: (prev, vin) => prev.filter((v) => v !== vin),
  });

  const { mutate: doClear } = useOptimisticListMutation<string, void>({
    queryKey: queryOpts.queryKey,
    mutationFn: () => clearAllSavedVehicles(),
    updater: () => [],
  });
  const handleAdd = useCallback((vin: string) => doSave(vin), [doSave]);
  const handleRemove = useCallback((vin: string) => doUnsave(vin), [doUnsave]);
  const handleToggle = useCallback(
    (vin: string) => {
      const current = queryClient.getQueryData<string[]>(queryOpts.queryKey) ?? [];
      if (current.includes(vin)) {
        doUnsave(vin);
      } else {
        doSave(vin);
      }
    },
    [queryClient, doSave, doUnsave]
  );

  const handleIsVehicleSaved = useCallback((vin: string) => savedVins.includes(vin), [savedVins]);

  const handleClearAll = useCallback(() => doClear(), [doClear]);

  const value = useMemo<FavoritesContextValue>(
    () => ({
      savedVins,
      isLoaded: isFetched,
      addVehicle: handleAdd,
      removeVehicle: handleRemove,
      toggleVehicle: handleToggle,
      isVehicleSaved: handleIsVehicleSaved,
      savedCount: savedVins.length,
      clearAll: handleClearAll,
    }),
    [
      savedVins,
      isFetched,
      handleAdd,
      handleRemove,
      handleToggle,
      handleIsVehicleSaved,
      handleClearAll,
    ]
  );

  return <FavoritesContext value={value}>{children}</FavoritesContext>;
}

/**
 * Returns favorites context helpers and state (add/remove/toggle, savedVins, savedCount).
 * Throws if called outside a <FavoritesProvider>.
 */
export function useFavorites(): FavoritesContextValue {
  const ctx = use(FavoritesContext);
  if (!ctx) {
    throw new Error("useFavorites must be used within a <FavoritesProvider>");
  }
  return ctx;
}
