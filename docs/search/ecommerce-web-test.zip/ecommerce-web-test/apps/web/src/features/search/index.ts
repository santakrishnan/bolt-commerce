// ── Public API for the search feature ────────────────────────────────

export type { ActiveFilter } from "./components/vehicle-results";
export { SearchHistoryProvider, useSearchHistory } from "./context/search-history-provider";
