"use client";

import { buildVdpPath } from "@config/routes";
import { toPreviewData } from "@features/vdp/data/to-preview-data";
import type { VehicleStickyBannerProps } from "@features/vdp/data/types";
import { AppButton } from "@shared/components/button";
import { Heading } from "@tfs-ucmp/ui";
import type React from "react";

import { VehicleActionIcons } from "./vehicle-action-icons";

export const VehicleStickyBanner: React.FC<VehicleStickyBannerProps> = ({
  vehicle,
  slugParams,
  ref,
}) => {
  const shouldShowOriginalPrice =
    vehicle.originalPrice != null && vehicle.originalPrice > (vehicle.price ?? 0);

  return (
    <div
      className="fixed top-0 right-0 left-0 z-50 hidden bg-[var(--color-core-surfaces-card)] py-[var(--spacing-md)] shadow-[var(--shadow-sm)] transition-[opacity,transform] duration-200"
      ref={ref}
    >
      <div className="mx-auto h-full max-w-[var(--container-2xl)] px-[var(--spacing-md)] sm:px-[var(--spacing-lg)] lg:px-[var(--spacing-4xl)]">
        <div className="flex flex-col gap-[var(--spacing-xs)] md:hidden">
          <Heading
            className="text-[length:var(--font-size-xl)] text-[var(--color-core-surfaces-foreground)] leading-normal"
            level={1}
            weight="bold"
          >
            {vehicle.title}
          </Heading>
          <div className="flex items-center justify-between gap-[var(--spacing-md)]">
            <div className="flex items-baseline gap-[var(--spacing-xs)]">
              <span className="font-bold text-[length:var(--font-size-lg)] text-[var(--color-actions-accent)] leading-normal">
                ${vehicle.price.toLocaleString()}
              </span>
              {shouldShowOriginalPrice && (
                <div className="flex items-baseline gap-[var(--spacing-2xs)]">
                  <span className="font-normal text-[var(--color-core-surfaces-foreground)] text-[var(--font-size-xs)] leading-normal">
                    was
                  </span>
                  <span className="font-normal text-[var(--color-core-surfaces-foreground)] text-[var(--font-size-xs)] leading-normal line-through">
                    ${vehicle.originalPrice?.toLocaleString()}
                  </span>
                </div>
              )}
            </div>
            <VehicleActionIcons
              showFav={true}
              showPrint={true}
              showShare={true}
              vdpUrl={buildVdpPath(slugParams)}
              vehicle={toPreviewData(vehicle)}
              vin={vehicle.vin}
            />
          </div>
          <div className="flex flex-row items-center justify-between">
            <div className="flex flex-row gap-[var(--spacing-2xs)]">
              <p className="font-semibold text-[var(--color-core-surfaces-foreground)] text-[var(--font-size-sm)]">
                Miles:
              </p>
              <p className="font-semibold text-[var(--color-core-surfaces-foreground)] text-[var(--font-size-sm)]">
                {vehicle.miles.toLocaleString()}
              </p>
            </div>
            <div className="flex flex-row gap-[var(--spacing-2xs)]">
              <p className="font-semibold text-[var(--color-core-surfaces-foreground)] text-[var(--font-size-sm)]">
                VIN:
              </p>
              <p className="font-semibold text-[var(--color-core-surfaces-foreground)] text-[var(--font-size-sm)]">
                {vehicle.vin}
              </p>
            </div>
          </div>
          <AppButton className="w-full" size="md" variant="primary">
            Get Pre-Qualified
          </AppButton>
        </div>
        <div className="hidden md:flex md:items-center md:justify-between md:gap-[var(--spacing-lg)]">
          <div className="flex min-w-0 flex-col gap-[var(--spacing-xs)]">
            <div className="flex flex-wrap items-baseline gap-x-[var(--spacing-md)] gap-y-[var(--spacing-2xs)]">
              <Heading
                className="text-[var(--color-core-surfaces-foreground)] leading-[115%] md:text-[length:var(--font-size-lg)] lg:text-[length:var(--font-size-lg)]"
                level={1}
                weight="bold"
              >
                {vehicle.title}
              </Heading>
              <div className="flex items-baseline gap-[var(--spacing-xs)]">
                <span className="font-bold text-[length:var(--font-size-lg)] text-[var(--color-actions-accent)] leading-[115%]">
                  ${vehicle.price.toLocaleString()}
                </span>
                {shouldShowOriginalPrice && (
                  <div className="flex items-baseline gap-[var(--spacing-2xs)]">
                    <span className="font-normal text-[length:var(--font-size-xs)] text-[var(--color-states-muted-foreground)] leading-normal tracking-[-0.14px]">
                      was
                    </span>
                    <span className="text-[length:var(--font-size-sm)] text-[var(--color-states-muted-foreground)] leading-[125%] line-through">
                      ${vehicle.originalPrice?.toLocaleString()}
                    </span>
                  </div>
                )}
              </div>
            </div>
            <div className="flex flex-row items-center gap-[var(--spacing-xl)]">
              <div className="flex flex-row gap-[var(--spacing-2xs)]">
                <p className="font-semibold text-[length:var(--font-size-md)] text-[var(--color-core-surfaces-foreground)] tracking-[-0.16px]">
                  Miles:
                </p>
                <p className="font-semibold text-[length:var(--font-size-md)] text-[var(--color-core-surfaces-foreground)] tracking-[-0.16px]">
                  {vehicle.miles.toLocaleString()}
                </p>
              </div>
              <div className="flex flex-row gap-[var(--spacing-2xs)]">
                <p className="font-semibold text-[length:var(--font-size-md)] text-[var(--color-core-surfaces-foreground)] tracking-[-0.16px]">
                  VIN:
                </p>
                <p className="font-semibold text-[length:var(--font-size-md)] text-[var(--color-core-surfaces-foreground)] tracking-[-0.16px]">
                  {vehicle.vin}
                </p>
              </div>
            </div>
          </div>

          <div className="flex shrink-0 items-center gap-[var(--spacing-2xl)]">
            <VehicleActionIcons
              showFav={true}
              showPrint={true}
              showShare={true}
              vdpUrl={buildVdpPath(slugParams)}
              vehicle={toPreviewData(vehicle)}
              vin={vehicle.vin}
            />
            <div>
              <AppButton size="md" variant="primary">
                Get Pre-Qualified
              </AppButton>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
