/**
 * Fetches personalized vehicle data for the My Garage page.
 *
 * Mock mode (default): active when PROFILE_SERVICE_URL is unset or USE_MOCK_PROFILE=true.
 * Production mode: set PROFILE_SERVICE_URL to call GET {PROFILE_SERVICE_URL}/profile/garage.
 * Auth: optional Bearer {PROFILE_API_KEY}. Falls back to mock on failure.
 */

import type { Vehicle } from "@shared/types";
import type { MyGarageData } from "./my-garage-types";

/** Returns true when mock mode is active (no PROFILE_SERVICE_URL or USE_MOCK_PROFILE=true). */
function isMockMode(): boolean {
  return !process.env.PROFILE_SERVICE_URL || process.env.USE_MOCK_PROFILE === "true";
}

const BECAUSE_YOU_VIEWED_LABELS = ["Toyota Camry", "Toyota Tundra", "Toyota RAV4"];

/** Builds My Garage data from local mock sources. */
async function getMockGarageData(): Promise<MyGarageData> {
  // Lazy imports keep mock data out of the production bundle
  const [{ mockVehicles }, { becauseViewedVehicles }] = await Promise.all([
    import("@features/search/lib/mock-vehicles"),
    import("@features/my-garage/services/mock-because-viewed"),
  ]);

  const shuffled = shuffle(mockVehicles as Vehicle[]);
  const label =
    BECAUSE_YOU_VIEWED_LABELS[Math.floor(Math.random() * BECAUSE_YOU_VIEWED_LABELS.length)] ??
    "Toyota Camry";

  return {
    bestMatches: shuffled,
    becauseYouViewed: shuffle(becauseViewedVehicles as Vehicle[]),
    becauseYouViewedLabel: label,
    recentPriceDrop: shuffled.filter((v) => v.oldPrice != null),
  };
}

/** Fisher-Yates shuffle — returns a new randomly-ordered copy. */
function shuffle<T>(arr: readonly T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = copy[i];
    copy[i] = copy[j] as T;
    copy[j] = tmp as T;
  }
  return copy;
}

/** Fetches My Garage data from the real profile service endpoint. */
async function fetchFromProfileService(): Promise<MyGarageData> {
  const baseUrl = process.env.PROFILE_SERVICE_URL;
  if (!baseUrl) {
    throw new Error("[MyGarageService] PROFILE_SERVICE_URL is not configured");
  }
  const res = await fetch(`${baseUrl}/profile/garage`, {
    headers: {
      ...(process.env.PROFILE_API_KEY && {
        Authorization: `Bearer ${process.env.PROFILE_API_KEY}`,
      }),
    },
    next: { revalidate: 60 },
  });

  if (!res.ok) {
    throw new Error(`[MyGarageService] Profile service error: ${res.status} ${res.statusText}`);
  }

  const json = (await res.json()) as { data: MyGarageData };
  return json.data;
}

/** Fetches My Garage data; falls back to mock data if the profile service is unavailable. */
export async function getMyGarageData(): Promise<MyGarageData> {
  if (isMockMode()) {
    console.log("[MyGarageService] Using mock data");
    return getMockGarageData();
  }

  try {
    return await fetchFromProfileService();
  } catch (error) {
    console.error("[MyGarageService] Falling back to mock data due to error:", error);
    return getMockGarageData();
  }
}
