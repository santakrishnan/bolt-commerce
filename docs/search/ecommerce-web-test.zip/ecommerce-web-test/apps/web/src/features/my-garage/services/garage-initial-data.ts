import { getMyGarageData } from "@features/my-garage/services/my-garage.service";
import type { MyGarageData } from "@features/my-garage/services/my-garage-types";
import { cacheLife, cacheTag } from "next/cache";

// Fetch initial My Garage data server-side with caching (mirrors srp-initial-data.ts pattern)
export async function fetchInitialGarageData(): Promise<MyGarageData> {
  "use cache";
  // Vitest does not run with Next cacheComponents enabled.
  if (process.env.NODE_ENV !== "test") {
    cacheLife("garage");
    cacheTag("garage");
  }

  return await getMyGarageData();
}
