export const ENABLE_FLAG_OVERRIDES = true;

export const CARD_TEST_FLAG_VALUE = "cardTestPrequalTradeInOffer";

export type PromotionCardId = "prequalify" | "tradeIn" | "testDrive";

export interface PromotionContext {
  isAuthenticated: boolean;
  isCardTestEnabled: boolean;
}

export interface CardTestOverrides {
  buttonText: string;
  description: string;
  title: string;
}

export interface PromotionCardEntry {
  cardTestOverrides?: CardTestOverrides;
  defaultButtonText: string;
  guard?: (ctx: PromotionContext) => boolean;
  id: PromotionCardId;
  priority: number;
}

// Registry

export const PROMOTION_CARDS: readonly PromotionCardEntry[] = [
  {
    id: "prequalify",
    priority: 10,
    defaultButtonText: "Get Pre-Qualified",
    cardTestOverrides: {
      buttonText: "Apply My Trade-In",
      title: "You're Pre Qualified",
      description: "Up to $45k in financing available",
    },
  },
  {
    id: "tradeIn",
    priority: 20,
    defaultButtonText: "Get My Trade-In Offer",
    cardTestOverrides: {
      buttonText: "Accept My Trade-In Offer",
      title: "Your Trade-In Offer is Ready",
      description: "Don't miss out, your guaranteed price is waiting",
    },
  },
  {
    id: "testDrive",
    priority: 30,
    defaultButtonText: "Book an Appointment",
    guard: (ctx) => ctx.isCardTestEnabled,
  },
];
