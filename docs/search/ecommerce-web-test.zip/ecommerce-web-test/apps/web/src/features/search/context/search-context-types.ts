import type {
  AvailableFilters,
  FilterState,
} from "@features/search/components/filter-sidebar/types";
import type {
  AppliedFilter,
  FacetCounts,
  FacetSection,
  RefineFilter,
  SmartFilterGroup,
} from "@features/search/lib/search-types";
import type { Vehicle } from "@shared/vehicle";
import type { Dispatch, ReactNode, RefObject, SetStateAction } from "react";

export interface RefineSearchFilter {
  id: string;
  label: string;
}

export interface SearchContextValue {
  appliedFilters: AppliedFilter[];

  applyFiltersSearch: (
    newFilterState: FilterState,
    opts?: {
      searchQuery?: string;
      labelFilter?: string;
      refineFilters?: RefineFilter[];
      preservePage?: boolean;
    }
  ) => void;
  availableFilters: AvailableFilters;

  // ── User interaction state ──
  currentPage: number;
  facetCounts: FacetCounts;
  filterState: FilterState;
  flushSearchQuery: (immediate?: string) => void;
  inventorySize: number;
  isFilterOpen: boolean;
  isFilterPending: boolean;
  isInitialLoading: boolean;
  isSearching: boolean;
  labelFilter: string;
  loadingFacetSections: FacetSection[];
  refineSearchFilters: RefineSearchFilter[];
  searchQuery: string;
  searchQueryRef: RefObject<string>;
  setCurrentPage: Dispatch<SetStateAction<number>>;
  setFilterState: Dispatch<SetStateAction<FilterState>>;
  setIsFilterOpen: Dispatch<SetStateAction<boolean>>;
  setLabelFilter: Dispatch<SetStateAction<string>>;
  setRefineSearchFilters: Dispatch<SetStateAction<RefineSearchFilter[]>>;
  setSearchQuery: Dispatch<SetStateAction<string>>;
  setSortOption: Dispatch<SetStateAction<"recommended" | "low-high" | "high-low">>;
  smartFilters: SmartFilterGroup[];
  sortOption: "recommended" | "low-high" | "high-low";
  totalCount: number;
  totalPages: number;
  vehiclePool: Vehicle[];
}

export interface SearchProviderProps {
  children: ReactNode;
  defaultFilterState: FilterState;
  initialAppliedFilters?: AppliedFilter[];
  initialBodyStyles?: string[];
  initialDataFetched?: boolean;
  initialInventorySize?: number;
  initialSearchQuery?: string;
  initialTotalCount?: number;
  initialUrlFilters?: Partial<FilterState>;
  initialVehicles?: Vehicle[];
}
