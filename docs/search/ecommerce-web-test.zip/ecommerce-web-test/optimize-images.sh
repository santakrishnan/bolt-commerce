#!/usr/bin/env bash
# Optimize large PNGs in-place using pngquant (lossy, much better compression for photos)
set -e

PNGQUANT="/Users/santhana.vijayaraghavan/.nvm/versions/node/v22.22.0/lib/node_modules/pngquant-bin/vendor/pngquant"
BASE="apps/web/public/images"

files=(
  "heroes/regions/southeast/desktop.png"
  "heroes/regions/southwest/mobile.png"
  "heroes/regions/southwest/desktop.png"
  "qualities/no-hidden-damage.png"
  "heroes/regions/west/desktop.png"
  "hero-know-user-content/know-user-images/car-image-temporary.png"
  "buying-process/buying-process-bg.png"
  "vehicle-toyota/car6.png"
  "buying-process/buying_process_mobile.png"
  "prequalify-banner/carousel-image-1.png"
  "prequalify-banner/carousel-image-2.png"
  "qualities/verified-vin.png"
  "qualities/7-day-return.png"
  "prequalify-banner/carousel-image-3.png"
)

for rel in "${files[@]}"; do
  src="$BASE/$rel"
  before=$(du -sh "$src" | cut -f1)

  # --force overwrites, --ext replaces extension in-place, --strip removes metadata
  "$PNGQUANT" --quality=65-85 --speed 1 --force --ext ".png" --strip -- "$src"

  after=$(du -sh "$src" | cut -f1)
  echo "$before -> $after  $rel"
done

echo ""
echo "Done."
