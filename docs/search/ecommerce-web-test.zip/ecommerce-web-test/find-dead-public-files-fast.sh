#!/usr/bin/env bash
# Fast approach: dump all source file contents into one big string, then check each public file against it

PUBLIC_DIR="apps/web/public"
DELETE_MODE="${1:-dry-run}"  # pass "delete" as first arg to actually delete

# Concatenate all source code into a temp file
echo "Building source index..."
grep -r --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.json" --include="*.css" --include="*.md" \
  "" . \
  --exclude-dir=node_modules --exclude-dir=.git --exclude-dir=public \
  -h 2>/dev/null > /tmp/source_dump.txt

echo "Source dump size: $(wc -c < /tmp/source_dump.txt) bytes"
echo ""

dead_count=0
alive_count=0

# Get all public files (exclude .DS_Store)
while IFS= read -r -d '' file; do
  rel_path="${file#$PUBLIC_DIR}"
  filename=$(basename "$file")

  # Check if rel_path appears in source dump
  if grep -qF "$rel_path" /tmp/source_dump.txt 2>/dev/null; then
    alive_count=$((alive_count + 1))
    continue
  fi

  # Fallback: filename alone
  if grep -qF "$filename" /tmp/source_dump.txt 2>/dev/null; then
    alive_count=$((alive_count + 1))
  else
    dead_count=$((dead_count + 1))
    if [[ "$DELETE_MODE" == "delete" ]]; then
      rm -- "$file" && echo "DELETED: $file"
    else
      echo "DEAD: $file"
    fi
  fi

done < <(find "$PUBLIC_DIR" -type f ! -name ".DS_Store" -print0 | sort -z)

echo ""
echo "Dead: $dead_count  |  Alive: $alive_count"
if [[ "$DELETE_MODE" != "delete" ]]; then
  echo "(Dry run — pass 'delete' as first argument to actually delete)"
fi
