const { execSync } = require('child_process');
const path = require('path');

const publicDir = 'apps/web/public';

// Get all public files
const allFiles = execSync('find ' + publicDir + ' -type f').toString().trim().split('\n');

const dead = [];
const alive = [];

for (const file of allFiles) {
  // Get the path relative to public (e.g. /images/logo.svg)
  const relPath = file.replace(publicDir, '');
  const filename = path.basename(file);

  // Search by relative URL path
  const result = execSync(
    'grep -r --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.json" --include="*.css" --include="*.md" -l ' +
    JSON.stringify(relPath) +
    ' . --exclude-dir=node_modules --exclude-dir=.git --exclude-dir=public 2>/dev/null || true'
  ).toString().trim();

  if (result) {
    alive.push(file);
    continue;
  }

  // Fallback: search by just the filename
  const result2 = execSync(
    'grep -r --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.json" --include="*.css" --include="*.md" -l ' +
    JSON.stringify(filename) +
    ' . --exclude-dir=node_modules --exclude-dir=.git --exclude-dir=public 2>/dev/null || true'
  ).toString().trim();

  if (result2) {
    alive.push(file);
  } else {
    dead.push(file);
  }
}

console.log('=== DEAD FILES (' + dead.length + ') ===');
dead.forEach(f => console.log(f));
console.log('\n=== ALIVE FILES (' + alive.length + ') ===');
alive.forEach(f => console.log(f));
