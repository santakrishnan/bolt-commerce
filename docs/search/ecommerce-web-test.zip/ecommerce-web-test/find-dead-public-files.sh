#!/usr/bin/env bash
set -e

PUBLIC_DIR="apps/web/public"
DEAD=()
ALIVE=()

# Get all public files (exclude .DS_Store)
while IFS= read -r file; do
  # Get path relative to public dir (e.g., /images/logo.svg)
  rel_path="${file#$PUBLIC_DIR}"
  filename=$(basename "$file")

  # Search by relative URL path in source files
  found=$(grep -r --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.json" --include="*.css" --include="*.md" -l "$rel_path" . --exclude-dir=node_modules --exclude-dir=.git --exclude-dir=public 2>/dev/null || true)

  if [[ -n "$found" ]]; then
    ALIVE+=("$file")
    continue
  fi

  # Fallback: search by filename alone
  found2=$(grep -r --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.json" --include="*.css" --include="*.md" -l "$filename" . --exclude-dir=node_modules --exclude-dir=.git --exclude-dir=public 2>/dev/null || true)

  if [[ -n "$found2" ]]; then
    ALIVE+=("$file")
  else
    DEAD+=("$file")
  fi

done < <(find "$PUBLIC_DIR" -type f ! -name ".DS_Store" | sort)

echo "=== DEAD FILES (${#DEAD[@]}) ==="
for f in "${DEAD[@]}"; do
  echo "$f"
done

echo ""
echo "=== ALIVE FILES (${#ALIVE[@]}) ==="
for f in "${ALIVE[@]}"; do
  echo "$f"
done
