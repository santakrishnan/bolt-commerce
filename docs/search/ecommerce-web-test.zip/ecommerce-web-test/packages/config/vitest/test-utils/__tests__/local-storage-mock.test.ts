import { describe, expect, it } from "vitest";
import { createLocalStorageMock } from "../local-storage-mock";

describe("createLocalStorageMock", () => {
  it("returns null for missing keys", () => {
    const ls = createLocalStorageMock();
    expect(ls.getItem("missing")).toBeNull();
  });

  it("stores and retrieves values", () => {
    const ls = createLocalStorageMock();
    ls.setItem("key", "value");
    expect(ls.getItem("key")).toBe("value");
  });

  it("coerces values to strings", () => {
    const ls = createLocalStorageMock();
    ls.setItem("num", 42 as unknown as string);
    expect(ls.getItem("num")).toBe("42");
  });

  it("removes a key", () => {
    const ls = createLocalStorageMock();
    ls.setItem("key", "value");
    ls.removeItem("key");
    expect(ls.getItem("key")).toBeNull();
  });

  it("clears all keys", () => {
    const ls = createLocalStorageMock();
    ls.setItem("a", "1");
    ls.setItem("b", "2");
    ls.clear();
    expect(ls.length).toBe(0);
    expect(ls.getItem("a")).toBeNull();
    expect(ls.getItem("b")).toBeNull();
  });

  it("tracks length correctly", () => {
    const ls = createLocalStorageMock();
    expect(ls.length).toBe(0);
    ls.setItem("a", "1");
    expect(ls.length).toBe(1);
    ls.setItem("b", "2");
    expect(ls.length).toBe(2);
    ls.removeItem("a");
    expect(ls.length).toBe(1);
  });

  it("returns key by index", () => {
    const ls = createLocalStorageMock();
    ls.setItem("first", "1");
    ls.setItem("second", "2");
    expect(ls.key(0)).toBe("first");
    expect(ls.key(1)).toBe("second");
  });

  it("returns null for out-of-range key index", () => {
    const ls = createLocalStorageMock();
    expect(ls.key(0)).toBeNull();
    ls.setItem("a", "1");
    expect(ls.key(5)).toBeNull();
  });

  it("creates independent instances", () => {
    const ls1 = createLocalStorageMock();
    const ls2 = createLocalStorageMock();
    ls1.setItem("key", "from-ls1");
    expect(ls2.getItem("key")).toBeNull();
  });
});
