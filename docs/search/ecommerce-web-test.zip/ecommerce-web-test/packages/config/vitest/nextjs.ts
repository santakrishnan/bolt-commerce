import path from "node:path";
import { fileURLToPath } from "node:url";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vitest/config";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// Use absolute path to ensure it works regardless of where vitest is executed from
const setupPath = path.resolve(__dirname, "./test-utils/nextjs-setup.ts");

export default defineConfig({
  plugins: [
    react({
      // Ensure React plugin can handle the setup file
      include: "**/*.{jsx,tsx,ts,js}",
    }),
  ],
  test: {
    globals: true,
    environment: "jsdom",
    setupFiles: [setupPath],
    include: ["**/*.{test,spec}.{ts,tsx}"],
    coverage: {
      provider: "v8",
      reporter: ["text", "json", "html", "lcov"],
      exclude: [
        "node_modules/",
        "src/test/",
        "**/*.config.*",
        "**/*.d.ts",
        ".next/",
        "dist/",
        "build/",
      ],
    },
  },
});
