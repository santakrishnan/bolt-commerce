import Image from "next/image";

// Icons intentionally render at their SVG native sizes; only `className` is accepted.

export function BatteryIcon({ className = "" }: { className?: string }) {
  return (
    <Image src="/images/vdp/Battery-icon.svg" alt="Battery" width={32} height={32} className={className} />
  );
}

export function EngineIcon({ className = "" }: { className?: string }) {
  return <Image src="/images/vdp/Engine-icon.svg" alt="Engine" width={32} height={32} className={className} />;
}

export function MPGIcon({ className = "" }: { className?: string }) {
  return <Image src="/images/vdp/Mpg-icon.svg" alt="MPG" width={32} height={32} className={className} />;
}

export function FuelTypeIcon({ className = "" }: { className?: string }) {
  return <Image src="/images/vdp/FuelType-icon.svg" alt="Fuel Type" width={32} height={32} className={className} />;
}

export function TransmissionIcon({ className = "" }: { className?: string }) {
  return <Image src="/images/vdp/Transmission-icon.svg" alt="Transmission" width={32} height={32} className={className} />;
}

export function OdometerIcon({ className = "" }: { className?: string }) {
  return <Image src="/images/vdp/Odometer-icon.svg" alt="Odometer" width={23} height={23} className={className} />;
}

export function DamageRepairIcon({ className = "" }: { className?: string }) {
  return <Image src="/images/vdp/Damage-repair-icon.svg" alt="Damage Repair" width={24} height={24} className={className} />;
}

export function PreviousOwnersIcon({ className = "" }: { className?: string }) {
  return <Image src="/images/vdp/Previous-owner-icon.svg" alt="Previous Owners" width={27} height={25} className={className} />;
}

export function ServiceHistoryIcon({ className = "" }: { className?: string }) {
  return <Image src="/images/vdp/Service-history-icon.svg" alt="Service History" width={18} height={23} className={className} />;
}

export function MileageIcon({ className = "" }: { className?: string }) {
  return <Image src="/images/vdp/Mileage-icon.svg" alt="Mileage" width={32} height={32} className={className} />;
}

export function ColorsIcon({ className = "" }: { className?: string }) {
  return <Image src="/images/vdp/Colors-icon.svg" alt="Colors" width={32} height={32} className={className} />;
}


export function MarkerPinIcon({ className = "" }: { className?: string }) {
  return <Image src="/images/vdp/MarkerPin-icon.svg" alt="Location" width={32} height={32} className={className} />;
}

export function TypeOwnersIcon({ className = "" }: { className?: string }) {
  return (
    <span className={`inline-flex items-center justify-center py-[var(--spacing-xs)] rounded-[var(--radius-md)] ${className}`}>
      <Image src="/images/vdp/Owner-type-icon.svg" alt="Owner Type" width={16} height={26} />
    </span>
  );
}

export function VectorRightOutlineIcon({ className = "" }: { className?: string }) {
  return <Image src="/images/vdp/Tickmark-icon.svg" alt="Tick" width={20} height={20} className={className} />;
}

export function NoDamageIcon({ className = "" }: { className?: string }) {
  return <Image src="/images/vdp/No-damage-icon.svg" alt="No Damage" width={21} height={24} className={className} />;
}
