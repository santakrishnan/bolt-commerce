# Landing Page — Architecture & Component Reference

> Complete documentation of the Arrow E-commerce landing page setup, component hierarchy, data flow, caching strategy, and feature flag system.

---

## Table of Contents

1. [Overview](#overview)
2. [Architecture Diagram](#architecture-diagram)
3. [Page Entry Point](#page-entry-point)
4. [Root Layout & Provider Stack](#root-layout--provider-stack)
5. [Feature Flags](#feature-flags)
6. [Landing Page Sections](#landing-page-sections)
   - [Home Hero](#1-home-hero)
   - [Vehicle Type Selector](#2-vehicle-type-selector)
   - [Buying Process](#3-buying-process)
   - [Vehicle Quick Links (Find Your Vehicle)](#4-vehicle-quick-links-find-your-vehicle)
   - [Customer Journey Carousel](#5-customer-journey-carousel)
   - [Arrow Inspected](#6-arrow-inspected)
7. [Shared Components](#shared-components)
8. [Data Layer & Services](#data-layer--services)
9. [Caching Strategy](#caching-strategy)
10. [Suspense & Skeleton Fallbacks](#suspense--skeleton-fallbacks)
11. [Performance Optimizations](#performance-optimizations)
12. [Error Handling](#error-handling)
13. [File Map](#file-map)

---

## Overview

The landing page is an **async Server Component** (`apps/web/src/app/page.tsx`) that orchestrates 6 major sections. It uses:

- **Next.js 16 App Router** with `"use cache"` directives
- **React 19 Server Components** for zero-JS data fetching
- **Suspense boundaries** with custom skeleton fallbacks for streaming
- **Vercel Flags SDK** for cookie-based feature flags
- **Framer Motion** (lazy-loaded) for scroll-triggered animations
- **`cacheLife("landing")`** — 15-min stale / 15-min revalidate / 1-hour expire

### Rendering Modes

| User State | Rendering |
|---|---|
| First-time visitor | Full landing page with default hero |
| Authenticated + personalized flag | "Welcome Back" hero with saved vehicle cards |
| Authenticated + prequalified | Garage-only redirect (sections hidden) |
| `redirectToMyGarage` flag active | Full My Garage page rendered at `/` |

---

## Architecture Diagram

```
page.tsx (Server Component — async)
│
├── Feature Flags (parallel evaluation)
│   ├── redirectToMyGarage()
│   ├── getUserInfo()
│   └── showPersonalizedHeroBanner()
│   └── customerPreQualified()
│
├── [Conditional] MyGarageWrapper (if garage redirect)
│
├── HomeHero (Server)
│   ├── HomeHeroStatic (Client — background images)
│   ├── HomeHeroTitle (Server)
│   ├── HomeHeroSearch (Client — shared SearchBar)
│   ├── Suspense → HomeHeroStatsAsync (Server — fetchHeroStats)
│   │   └── HomeHeroStats (Server — stat cards)
│   └── [Conditional] HomeHeroKnownUserContent (Client — personalized cards)
│
├── Suspense → VehicleTypeSelectorWrapper (Server — getVehicleTypes)
│   └── VehicleTypeSelector (Client — interactive grid)
│       └── VehicleTypeCard (Client — selectable card)
│
├── BuyingProcess (Server — JSON config)
│   ├── BuyingProcessCard (Server — desktop grid)
│   └── BuyingProcessCarousel (Client — mobile swipe)
│
├── Suspense → VehicleFinderQuickLinks (Server — parallel fetch)
│   └── VehicleQuickLinkCard (Server — link cards)
│
├── Suspense → CustomerJourneyCarouselSection (Server)
│   └── CustomerJourneyCarousel (Client — auto-rotating)
│
└── Suspense → ArrowInspectedSectionWrapper (Server — getInspectionFeatures)
    └── ArrowInspectedSection (Server)
        ├── ArrowInspectedCarousel (Client — mobile)
        └── InspectionFeatureCard (Server — desktop grid)
```

---

## Page Entry Point

**File:** `apps/web/src/app/page.tsx`
**Type:** Async Server Component

### What it does

1. **Evaluates feature flags** — first 3 in parallel via `Promise.all()`, then sequential for dependent flags
2. **Decides rendering path** — garage redirect vs. personalized hero vs. default landing
3. **Renders 6 sections** — each wrapped in `<AnimatedSection>` with Suspense boundaries
4. **Lazy-loads heavy modules** — `AnimatedSection` and `CustomerJourneyCarousel` via `next/dynamic`

### Key Code Pattern

```tsx
export default async function HomePage() {
  const [shouldShowGarage, userInfo, showPersonalizedBanner] = await Promise.all([
    redirectToMyGarage(),
    getUserInfo(),
    showPersonalizedHeroBanner(),
  ]);

  if (shouldShowGarage) {
    return <MyGarageWrapper ... />;
  }

  const isPreQualified = await customerPreQualified();
  const shouldHideSections = userInfo.isAuthenticated && isPreQualified;

  return (
    <div>
      <HomeHero knownUser={knownUserOverrides} ... />
      {!shouldHideSections && (
        <>
          <Suspense fallback={<VehicleTypeSelectorSkeleton />}>
            <VehicleTypeSelectorWrapper />
          </Suspense>
          <BuyingProcess />
          <Suspense fallback={<VehicleFinderSkeleton />}>
            <VehicleFinderQuickLinks />
          </Suspense>
          <Suspense fallback={<CustomerJourneySkeleton />}>
            <CustomerJourneyCarouselSection />
          </Suspense>
          <Suspense fallback={<ArrowInspectedSkeleton />}>
            <ArrowInspectedSectionWrapper />
          </Suspense>
        </>
      )}
    </div>
  );
}
```

---

## Root Layout & Provider Stack

**File:** `apps/web/src/app/layout.tsx`
**Type:** Server Component

### Provider Composition (outermost → innermost)

```
ThemeProvider → ArrowProvider → LocationProvider → QueryProvider → FavoritesProvider → SearchHistoryProvider → CartProvider
```

Composed via `composeProviders()` utility in `~/lib/compose-providers.tsx`:

```tsx
const Providers = composeProviders(
  ThemeProvider, ArrowProvider, LocationProvider,
  QueryProvider, FavoritesProvider, SearchHistoryProvider, CartProvider,
);
```

### Provider Details

| Provider | Source | Purpose |
|---|---|---|
| **ThemeProvider** | Custom | CSS variables, theme context |
| **ArrowProvider** | Custom | Event tracking, client API bindings |
| **LocationProvider** | `~/components/providers/location-provider` | Geolocation, zip code, state-based hero backgrounds. Cookie: `arrow_manual_zip` (30-day) |
| **QueryProvider** | `~/components/providers/query-provider` | TanStack React Query + IndexedDB persistence for `saved-vehicles` and `search-history` |
| **FavoritesProvider** | Custom | Saved/favorite vehicles context |
| **SearchHistoryProvider** | Custom | Search history persistence |
| **CartProvider** | `~/components/providers/cart-provider` | Shopping cart state (items, total, add/remove/clear) |

### Layout Structure

```
<html>
  <body>
    <Header />           ← Server Component (outside providers)
    <Providers>
      <Suspense>
        {children}       ← Page content
      </Suspense>
    </Providers>
    <Footer />           ← Server Component (outside providers)
    <FeatureFlagDebug /> ← Dev-only
  </body>
</html>
```

---

## Feature Flags

**File:** `apps/web/src/lib/flags/flags.ts`
**SDK:** Vercel Flags (`@vercel/flags/next`)

All flags are cookie-based, evaluated per-request from `FLAG_COOKIE_NAME`.

| Flag | Type | Purpose | Landing Page Impact |
|---|---|---|---|
| `redirectToMyGarage` | `boolean` | Redirect `/` to garage experience | Renders `MyGarageWrapper` instead of landing |
| `showPersonalizedHeroBanner` | `boolean` | Show "Welcome Back" hero | Toggles known-user hero variant |
| `customerPreQualified` | `boolean` | User is prequalified | Hides vehicle selector, buying process, etc. |
| `customerTestDriveScheduled` | `boolean` | User has scheduled test drive | Controls carousel slide visibility |
| `customerTradeInSubmitted` | `boolean` | User submitted trade-in | Controls carousel slide visibility |

### Helper

```tsx
getUserInfo(): Promise<{ firstName: string; lastName: string; isAuthenticated: boolean }>
```

---

## Landing Page Sections

### 1. Home Hero

**Directory:** `apps/web/src/components/features/landing/home-hero/`

| File | Type | Purpose |
|---|---|---|
| `home-hero.tsx` | Server | Root hero component — two rendering paths (default vs. known-user) |
| `home-hero-static.tsx` | Client | Background images with location-based variants & gradient overlays |
| `home-hero-title.tsx` | Server | "FIND YOUR NEXT VEHICLE" heading + subtitle |
| `home-hero-search.tsx` | Client | Unified SearchBar integration — navigates to `/used-cars?q=` |
| `home-hero-stats.tsx` | Server | 4-stat grid (Vehicles, VIN Verified, Money Back, Rating) |
| `home-hero-carousel.tsx` | Client | Auto-rotating background image carousel (10s interval) |
| `home-hero-known-user-content.tsx` | Client | Personalized cards — saved vehicle, prequalified vehicle, trade-in offer |

#### Data Flow

```
HomeHero (Server)
  └─ fetchHeroStats() → cacheLife("landing") → ArrowServerClient or mock
     Returns: [{ id, value, label, icon }] × 4
```

#### Props

```typescript
interface HomeHeroProps {
  title?: string;                    // Default: "FIND YOUR\nNEXT VEHICLE"
  subtitle?: string;                 // Default: "With Transparent Pricing..."
  showSubtitle?: boolean;
  showStats?: boolean;
  showSearch?: boolean;
  heightClassName?: string;
  knownUser?: HomeHeroKnownUserContentProps;
  useLocationBackground?: boolean;
}
```

#### Known-User Cards

When `knownUser` prop is provided, the hero renders personalized action cards:

| Card | Content | CTA |
|---|---|---|
| Saved Vehicle | Pre-qualified badge, vehicle image, VIN, miles, price, $468/mo @ 5.49% APR | "Buy Online" |
| Prequalified Vehicle | "Ready when you are" badge, vehicle details | "Schedule Test Drive" |
| Trade-in Offer | Current evaluation with countdown timer | "Accept Offer" |

---

### 2. Vehicle Type Selector

**Directory:** `apps/web/src/components/features/landing/vehicle-type-selector/`

| File | Type | Purpose |
|---|---|---|
| `vehicle-type-selector-wrapper.tsx` | Server | Fetches vehicle types, passes to client |
| `vehicle-type-selector.tsx` | Client | Interactive 4-column grid with selection state |
| `vehicle-type-card.tsx` | Client | Selectable card with hover/scale effects |

#### Data Flow

```
VehicleTypeSelectorWrapper (Server)
  └─ getVehicleTypes() → cacheLife("landing") → dynamic import from ~/data/vehicles/vehicle-types
     Returns: VehicleType[] (image, name, description per type)
```

#### Interaction

- Click/keyboard (Enter/Space) selects a vehicle type
- Tracks selection event via `useEventTracking()`
- Navigates to `/used-cars?q={vehicleId}`
- Includes `aria-pressed`, `role="button"`, `aria-label` for accessibility

---

### 3. Buying Process

**Directory:** `apps/web/src/components/features/landing/buying-process/`

| File | Type | Purpose |
|---|---|---|
| `buying-process.tsx` | Server | Loads JSON config, responsive switch (carousel vs. grid) |
| `buying-process-card.tsx` | Server | Desktop 4-column static grid |
| `buying-process-carousel.tsx` | Client | Mobile touch-swipeable carousel (Framer Motion) |
| `buying-process-config.json` | Data | 4 process steps + icon paths + carousel config |
| `carousel-transform.ts` | Utility | Calculates center-aligned scroll offset |

#### Process Steps

| Step | Icon | Description |
|---|---|---|
| Fast & Simple Process | refresh | From browsing to booking... |
| Transparent Pricing | search | Know the full cost upfront... |
| Arrow Inspected® | shield | Every vehicle is backed... |
| Buy with Confidence | clipboard | Delivery or pickup... |

#### Responsive Behavior

- **Mobile (`< sm`):** Swipeable carousel with indicator dots, 50px min swipe distance, 90% card width
- **Desktop (`sm+`):** Static 4-column grid with hover effects

---

### 4. Vehicle Quick Links (Find Your Vehicle)

**Directory:** `apps/web/src/components/features/landing/vehicle-quick-links/`

| File | Type | Purpose |
|---|---|---|
| `vehicle-quick-links-grid.tsx` | Server | Parallel fetch of options + counts, renders grid |
| `vehicle-quick-link-card.tsx` | Server | Link card with icon, title, and vehicle count |
| `data.ts` | Types | `VehicleFinderOption` interface |

#### Data Flow

```
VehicleFinderQuickLinks (Server)
  └─ Promise.all([
       fetchVehicleFinderOptions(),  → cacheLife("landing")
       fetchVehicleFinderCounts(),   → cacheLife("landing")
     ])
     Returns: options[] + counts{}
```

#### Quick Link Options

| Option | Icon | Link |
|---|---|---|
| Cars Under $20,000 | price-tag | `/used-cars?q=Cars-Under-$20,000` |
| Shop Excellent Deals | badge | `/used-cars?q=Shop-Excellent-Deals` |
| Price Drop | arrow-down | `/used-cars?q=Price-Drop` |
| Low Miles | speedometer | `/used-cars?q=Low-Miles` |

---

### 5. Customer Journey Carousel

**Directory:** `apps/web/src/components/features/landing/customer-journey-carousel/`

| File | Type | Purpose |
|---|---|---|
| `customer-journey-carousel.tsx` | Client | Auto-rotating promotional banner (5s interval) |
| `carousel-data.ts` | Data | 3 promotional slides |

#### Feature-Flag-Driven Slides

| Slide | Flag Gate | CTA | Link |
|---|---|---|---|
| Prequalify | `showPrequalifyBanner` | "Get PreQualified" | `/prequalify` |
| Trade-in | `showTradeInBanner` | "Get trade-in value" | `/trade-in` |
| Test Drive | `showTestDriveBanner` | "TEST DRIVE YOUR NEXT CAR" | `/test-drive` |

#### Animation System

- **Dual-container (A/B) pattern** — flicker-free transitions
- **Exit:** 600ms — scale(1.1), blur(4px), translateY(-40px), opacity → 0
- **Enter:** 600ms — scale(1.15) → none, blur(8px) → none, translateY(50px) → none, opacity → 1
- **Interval:** 5000ms between slides
- Renders nothing if zero flags are active

---

### 6. Arrow Inspected

**Directory:** `apps/web/src/components/features/landing/arrow-inspected/`

| File | Type | Purpose |
|---|---|---|
| `arrow-inspected-section-wrapper.tsx` | Server | Fetches inspection features, passes to section |
| `arrow-inspected-section.tsx` | Server | Title + description + responsive layout |
| `inspection-feature-card.tsx` | Server | Card with image, icon, title, description |
| `arrow-inspected-carousel.tsx` | Client | Mobile Embla carousel (3s autoplay, loop) |

#### Data Flow

```
ArrowInspectedSectionWrapper (Server)
  └─ getInspectionFeatures() → cacheLife("landing") → dynamic import from ~/data/inspection/features
     Returns: InspectionFeature[] (image, icon, title, description)
```

#### Icon Mapping

`arrow-circle` · `certified-document` · `verified-badge` · `guarantee`

#### Responsive Behavior

- **Mobile/Tablet (`< md`):** Embla carousel, 70% card width, autoplay loop
- **Desktop (`md+`):** 4-column static grid

---

## Shared Components

### AnimatedSection

**File:** `apps/web/src/components/shared/animated-section.tsx`
**Type:** Client Component (Framer Motion)
**Load:** `next/dynamic` (lazy-loaded to avoid bundling framer-motion eagerly)

```typescript
interface AnimatedSectionProps {
  children: ReactNode;
  delay?: number;           // Default: 0
  className?: string;
  staggerChildren?: boolean; // Adds delay for child animations
  duration?: number;         // Default: 1.2s
}
```

Scroll-triggered `whileInView` opacity/translate animation.

### SearchBar (Unified)

**File:** `apps/web/src/components/shared/search-bar/search-bar.tsx`
**Type:** Client Component

Full-featured search component used in the hero:

| Feature | Detail |
|---|---|
| Autocomplete | Debounced suggestions via `AutocompleteService` |
| Voice Recognition | Web Speech API integration |
| Search History | Persistent via TanStack Query + IndexedDB |
| Display Modes | Dropdown or Pills |
| Keyboard Navigation | Full arrow-key, Enter, Escape support |
| Body Scroll Lock | On mobile when dropdown is open |

Used in `HomeHeroSearch` with:
- Placeholder: "SUV under 35K with low miles."
- On home: pushes to `/used-cars?q=`
- On `/used-cars`: replaces URL (no scroll)

---

## Data Layer & Services

### Landing Service

**File:** `apps/web/src/services/landing/landing.service.ts`

| Function | Cache Tag | Returns | Fallback |
|---|---|---|---|
| `fetchHeroStats()` | `hero-stats` | `HeroStat[]` (4 items) | Mock data |
| `fetchVehicleFinderOptions()` | `vehicle-finder-options` | `VehicleFinderOptionStatic[]` | Mock data |
| `fetchVehicleFinderCounts()` | `vehicle-finder-counts` | `VehicleFinderCounts` | Mock data |

All functions:
- Decorated with `"use cache"` + `cacheLife("landing")` + `cacheTag()`
- Use `ArrowServerClient` for upstream API calls
- Fall back to mock data on error (never throw)
- Apply transform layer to normalize API response shapes

**Types:** `apps/web/src/services/landing/types.ts`
**Mocks:** `apps/web/src/services/landing/landing.mocks.ts`

### Data Utilities

**File:** `apps/web/src/lib/data/index.ts`

| Function | Cache Tag | Source |
|---|---|---|
| `getVehicleTypes()` | `vehicle-types` | Dynamic import from `~/data/vehicles/vehicle-types` |
| `getInspectionFeatures()` | `inspection-features` | Dynamic import from `~/data/inspection/features` |
| `getVehicleCount()` | `vehicle-count` | Hardcoded 20,847 (TODO: API) |

All decorated with `"use cache"` + `cacheLife("landing")` + `cacheTag()`.

---

## Caching Strategy

**Config:** `apps/web/next.config.ts`

```typescript
experimental: {
  cacheComponents: true,
  cacheLife: {
    landing: { stale: 900, revalidate: 900, expire: 3600 },
    profile: { stale: 300, revalidate: 600, expire: 3600 },
  },
}
```

### Landing Cache Profile

| Parameter | Value | Meaning |
|---|---|---|
| `stale` | 900s (15 min) | Serve stale data for this window |
| `revalidate` | 900s (15 min) | Background revalidation interval |
| `expire` | 3600s (1 hour) | Hard expiry — forces fresh fetch |

### Cache Tags (for targeted invalidation)

| Tag | Function |
|---|---|
| `hero-stats` | `fetchHeroStats()` |
| `vehicle-finder-options` | `fetchVehicleFinderOptions()` |
| `vehicle-finder-counts` | `fetchVehicleFinderCounts()` |
| `vehicle-types` | `getVehicleTypes()` |
| `inspection-features` | `getInspectionFeatures()` |
| `vehicle-count` | `getVehicleCount()` |

---

## Suspense & Skeleton Fallbacks

The landing page uses **5 Suspense boundaries** with custom skeleton components:

| Boundary | Skeleton | Layout |
|---|---|---|
| Vehicle Type Selector | `VehicleTypeSelectorSkeleton` | 2×2 animated pulse grid |
| Vehicle Finder Quick Links | `VehicleFinderSkeleton` | 2×2 mobile / 4-col desktop pulse grid |
| Customer Journey Carousel | `CustomerJourneySkeleton` | Full-width strip placeholder |
| Arrow Inspected | `ArrowInspectedSkeleton` | 1-col / 2-col / 3-col responsive grid |
| Hero Stats (nested) | `HomeHeroStatsLoading` | 4-stat inline skeleton |

Each skeleton matches the exact dimensions of its real component to prevent **Cumulative Layout Shift (CLS)**.

---

## Performance Optimizations

| Optimization | Implementation |
|---|---|
| **Code Splitting** | `AnimatedSection` and `CustomerJourneyCarousel` loaded via `next/dynamic` to avoid bundling Framer Motion eagerly |
| **Parallel Data Fetching** | Feature flags fetched with `Promise.all()`, vehicle finder options + counts fetched in parallel |
| **Image Optimization** | AVIF + WebP formats, responsive `srcSet`, `priority` hints for hero LCP image |
| **RSC Caching** | `"use cache"` + `cacheLife("landing")` on all data functions — zero client JS for data fetching |
| **Selective Hydration** | Most components are Server Components — only interactive elements (search, carousel, cards) are Client Components |
| **IndexedDB Persistence** | TanStack Query persists only `saved-vehicles` and `search-history` keys |
| **Skeleton Streaming** | Suspense boundaries enable HTML streaming — first paint shows above-fold content immediately |
| **Mock Fallback** | All service functions degrade to mock data on error — page never breaks |

---

## Error Handling

| File | Type | Behavior |
|---|---|---|
| `apps/web/src/app/error.tsx` | Client Component | Root error boundary — logs error, shows "Try again" button with `reset()` callback |
| `apps/web/src/app/loading.tsx` | Server Component | Centered spinner + "Loading..." text (full viewport) |
| `apps/web/src/app/not-found.tsx` | Server Component | 404 page with "Return Home" link to `ROUTES.HOME` |

Service-level errors are caught silently — all landing service functions return mock data on failure and log `ArrowServerError`.

---

## File Map

### Page & Layout

```
apps/web/src/app/
├── page.tsx                 # Landing page entry (async Server Component)
├── layout.tsx               # Root layout + provider composition
├── loading.tsx              # Global loading fallback
├── error.tsx                # Global error boundary (Client)
├── not-found.tsx            # 404 page
└── globals.css              # Global styles
```

### Landing Components

```
apps/web/src/components/features/landing/
├── index.ts                                         # Barrel exports
├── home-hero/
│   ├── home-hero.tsx                                # Main hero (Server)
│   ├── home-hero-static.tsx                         # Background images (Client)
│   ├── home-hero-title.tsx                          # Title + subtitle (Server)
│   ├── home-hero-search.tsx                         # Search integration (Client)
│   ├── home-hero-stats.tsx                          # Stats grid (Server)
│   ├── home-hero-carousel.tsx                       # Background carousel (Client)
│   └── home-hero-known-user-content.tsx             # Personalized cards (Client)
├── vehicle-type-selector/
│   ├── vehicle-type-selector-wrapper.tsx             # Data fetcher (Server)
│   ├── vehicle-type-selector.tsx                     # Interactive grid (Client)
│   └── vehicle-type-card.tsx                         # Selectable card (Client)
├── buying-process/
│   ├── buying-process.tsx                            # Main section (Server)
│   ├── buying-process-card.tsx                       # Desktop grid (Server)
│   ├── buying-process-carousel.tsx                   # Mobile carousel (Client)
│   ├── buying-process-config.json                    # Step definitions
│   └── carousel-transform.ts                         # Scroll math utility
├── vehicle-quick-links/
│   ├── vehicle-quick-links-grid.tsx                  # Parallel data fetch (Server)
│   ├── vehicle-quick-link-card.tsx                   # Link card (Server)
│   └── data.ts                                       # Types
├── customer-journey-carousel/
│   ├── customer-journey-carousel.tsx                 # Auto-rotating banner (Client)
│   └── carousel-data.ts                              # 3 promotional slides
├── arrow-inspected/
│   ├── arrow-inspected-section-wrapper.tsx            # Data fetcher (Server)
│   ├── arrow-inspected-section.tsx                    # Layout + responsiveness (Server)
│   ├── inspection-feature-card.tsx                    # Feature card (Server)
│   └── arrow-inspected-carousel.tsx                   # Mobile carousel (Client)
├── product-card/
│   ├── product-card.tsx                               # Product display (Server)
│   └── product-card-actions.tsx                       # Cart/favorite buttons (Client)
├── search-bar/
│   └── search-bar.tsx                                 # Legacy placeholder (Client)
├── cart-drawer/
│   └── cart-drawer.tsx                                # Cart drawer (Client)
└── checkout-form/
    └── checkout-form.tsx                              # Checkout form (Client)
```

### Services & Data

```
apps/web/src/services/landing/
├── landing.service.ts       # 3 cached fetch functions + transform layer
├── landing.mocks.ts         # Mock data for all endpoints
└── types.ts                 # Canonical + Raw upstream types

apps/web/src/lib/data/
└── index.ts                 # getVehicleTypes, getInspectionFeatures, getVehicleCount
```

### Shared

```
apps/web/src/components/shared/
├── animated-section.tsx                # Framer Motion scroll animation wrapper
└── search-bar/
    ├── search-bar.tsx                  # Unified search component
    ├── search-input.tsx                # Input field
    ├── search-backdrop.tsx             # Overlay backdrop
    ├── suggestion-display.tsx          # Suggestion renderer
    ├── dropdown-suggestions.tsx        # Dropdown mode
    ├── pills-suggestions.tsx           # Pills mode
    ├── types.ts                        # All interfaces + defaults
    ├── index.ts                        # Barrel exports
    └── hooks/
        ├── use-search-history.ts       # History persistence
        ├── use-search-suggestions.ts   # Debounced autocomplete
        └── use-voice-recognition.ts    # Web Speech API

apps/web/src/lib/
├── flags/flags.ts           # 6 feature flags (Vercel Flags SDK)
├── compose-providers.tsx    # Provider composition utility
└── arrow/server-api.ts      # ArrowServerClient (upstream HTTP)
```

### Configuration

```
apps/web/next.config.ts      # cacheLife profiles, cacheComponents, image formats
```

---

## Component Classification Summary

### Server Components (no client JS shipped)

| Component | Data Fetching |
|---|---|
| `page.tsx` (HomePage) | Feature flags (parallel) |
| `HomeHero` | — |
| `HomeHeroTitle` | — |
| `HomeHeroStats` | `fetchHeroStats()` |
| `VehicleTypeSelectorWrapper` | `getVehicleTypes()` |
| `BuyingProcess` | JSON config import |
| `BuyingProcessCard` | — |
| `VehicleFinderQuickLinks` | `fetchVehicleFinderOptions()` + `fetchVehicleFinderCounts()` |
| `VehicleQuickLinkCard` | — |
| `ArrowInspectedSectionWrapper` | `getInspectionFeatures()` |
| `ArrowInspectedSection` | — |
| `InspectionFeatureCard` | — |
| `ProductCard` | — |

### Client Components (`"use client"`)

| Component | Interactivity |
|---|---|
| `HomeHeroStatic` | Location-based background images |
| `HomeHeroSearch` | Search input, navigation, autocomplete |
| `HomeHeroCarousel` | Auto-advance image carousel |
| `HomeHeroKnownUserContent` | Personalized cards, CTAs |
| `VehicleTypeSelector` | Selection state, event tracking, navigation |
| `VehicleTypeCard` | Hover/press states, keyboard handlers |
| `BuyingProcessCarousel` | Touch swipe, dot navigation |
| `CustomerJourneyCarousel` | Auto-rotating A/B container animation |
| `ArrowInspectedCarousel` | Embla autoplay carousel |
| `ProductCardActions` | Add to cart, favorite toggle |
| `CartDrawer` | Cart dialog UI |
| `CheckoutForm` | Form submission |
| `AnimatedSection` | Framer Motion whileInView |
| `SearchBar` | Full search UX (autocomplete, voice, history) |
