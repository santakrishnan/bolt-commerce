# Arrow E-commerce Application Documentation

Last updated: 2026-04-06
Scope: Entire monorepo with implementation detail focus on apps/web

---

## 1) Purpose and Scope

This document describes the full application architecture, including:

- Monorepo structure and package ownership
- Web app runtime architecture (Next.js App Router)
- Route-by-route feature and data source mapping
- API route contracts and upstream/mock behavior
- State management and provider composition
- Caching and performance strategy
- Security model
- Environment variables and operational workflows
- Known implementation gaps and migration notes

This document is implementation-derived from the current codebase, not aspirational design.

---

## 2) Monorepo Overview

Root workspace uses PNPM workspaces + Turborepo.

### 2.1 Workspace packages

- apps/web: customer-facing Next.js app
- packages/ui: shared React components (primitives + composed components)
- packages/ui-theme: CSS-only design tokens/themes
- packages/shared: shared providers/hooks/services/utilities/types
- packages/utils: low-level utility functions (cn, formatters, slugify, validators)
- packages/config/typescript: shared TypeScript configurations
- packages/config/vitest: shared Vitest configurations + test utilities

### 2.2 Root orchestration

- Package manager: pnpm@10
- Build orchestration: turbo
- Formatting/linting: biome via ultracite wrapper
- Testing: vitest

Root scripts:

- pnpm dev: turbo dev
- pnpm build: turbo build
- pnpm test: turbo test
- pnpm type-check: turbo type-check
- pnpm check: ultracite check
- pnpm fix: ultracite fix

---

## 3) Web App Runtime Stack (apps/web)

### 3.1 Core framework

- Next.js 16 App Router
- React 19
- Turbopack in development
- Tailwind CSS v4

### 3.2 Important runtime config

From next.config.ts:

- cacheComponents: true
- Custom cacheLife profiles:
  - landing: stale 900s / revalidate 900s / expire 3600s
  - profile: stale 300s / revalidate 600s / expire 3600s
  - vdp: stale 300s / revalidate 300s / expire 3600s
  - srp: stale 300s / revalidate 300s / expire 3600s
- output: standalone
- optimizePackageImports: lucide-react
- transpilePackages: @tfs-ucmp/ui, @tfs-ucmp/ui-theme

### 3.3 Security middleware/proxy

Proxy runs on most routes (excluding static/image/favicon-like assets) and sets:

- Content-Security-Policy
- Strict-Transport-Security
- X-Frame-Options
- X-Content-Type-Options
- Referrer-Policy
- Permissions-Policy

File references:

- middleware.ts delegates to proxy.ts
- proxy.ts defines headers and CSP

---

## 4) Source Layout (apps/web/src)

- app: Next App Router pages/layouts/error boundaries/API routes
- config: flags, routes, messages, fonts, query keys/constants
- features: domain feature modules
- layout: header/footer/nav/sidebar composition
- shared: app-shared components, data fixtures, hooks, providers, libs, types
- test: test utilities and support

Feature modules under features:

- landing
- search
- vdp
- my-garage
- favorites
- my-account
- tracking
- sign-in
- create-account
- vehicle-card
- vehicle-preview

---

## 5) Provider and State Architecture

## 5.1 Root provider stack

In app/layout.tsx, providers are composed via composeProviders in this order:

1. ThemeProvider
2. ArrowProvider
3. QueryProvider
4. SearchHistoryProvider
5. FavoritesProvider

LocationProvider is applied via async LocationInit component inside Suspense so server can read manual zip cookie before first paint.

Footer is rendered outside provider tree. Dev-only FeatureFlagDebug is conditionally rendered when NODE_ENV != production.

## 5.2 Provider responsibilities

- ThemeProvider: visual theme context
- ArrowProvider: tracking IDs, fingerprint-derived FED-safe data, profile lifecycle, event hooks
- QueryProvider: TanStack Query with IndexedDB persistence
  - Persisted query prefixes: saved-vehicles, search-history
- SearchHistoryProvider: optimistic CRUD over /api/saved-registry/search-history
- FavoritesProvider: optimistic CRUD over /api/saved-registry/vehicles
- LocationProvider:
  - Resolves display location from manual zip cookie or Arrow fingerprint geo
  - Stores manual zip override in cookie arrow_manual_zip
  - Tracks location_zip_changed and location_zip_cleared events via events API

## 5.3 State strategy by type

- Server state: TanStack Query + route handlers/services
- Client UI state: context + React state
- Cross-request persistence:
  - IndexedDB: selected Query cache slices
  - Cookies: session/profile/fingerprint identifiers and manual zip

---

## 6) Feature-by-Feature Route Map with Data Sources

## 6.1 Page routes

### /

Feature: Landing page + personalization gate

Data sources:

- Flags/user context from config/flags/flags.ts
  - redirectToMyGarage
  - getUserInfo
  - showPersonalizedHeroBanner
  - customerPreQualified
- Landing hero stats/options/counts from landing services
- Known-user fixture from shared/data/known-user.json

Behavior:

- If redirectToMyGarage = true, renders MyGarageWrapper at root
- Otherwise renders hero and optional below-the-fold sections
- Hides below-the-fold sections for authenticated + prequalified users

### /used-cars and /used-cars/:make/:model/:trim/:year/:vin

Feature: SRP + VDP through one catch-all route

Data sources:

- Route parsing/canonicalization from config/routes/used-cars
- SRP path:
  - SearchWrapper server component prepares initial data
  - Search client fetches from:
    - /api/search (results)
    - /api/search/filters (facet counts)
- VDP path:
  - getVehicleBundleCached(vin) from features/vdp/services/vdp-cached.ts
  - Composes:
    - fetchVinDataCached(vin)
    - fetchDealerByVinCached(vin)

Behavior:

- Enforces canonical URL casing by redirecting when mismatched
- Uses Suspense fallback skeletons for VDP

### /my-garage

Feature: Personalized garage dashboard

Data sources:

- User auth state from getUserInfo()
- Garage data loaded through /api/garage/profile, backed by my-garage.service

Behavior:

- showUserName toggled by isAuthenticated

### /favorites

Feature: Saved vehicles management view

Data sources:

- Saved VIN list from FavoritesProvider (saved-registry API)
- Vehicle display details hydrated from local mock inventory (search/lib/mock-vehicles)

Behavior:

- Pure client page
- Supports remove and clear-all

### /my-account

Feature: Account entry gate

Data sources:

- getUserInfo() for auth check

Behavior:

- Redirects unauthenticated users to /
- Redirects authenticated users to /my-account/my-details

### /my-account/my-details

Feature: User details

Data sources:

- shared/data/profile/profile-data via wrapper component

### /my-account/notifications

Feature: Notification settings

Data sources:

- shared/data/notifications/notifications-data via wrapper component

### /my-account/password

Feature: Password and active sessions UI

Data sources:

- Mock user/session data from config/flags/config (cookie-selected mock user)
- Location context for device/location labels

Behavior:

- Client-side validation and success flow only; no server mutation endpoint

### /my-account/pre-qualification

Feature: Prequalification details page

Data sources:

- Local JSON fixtures in route folder

### /my-account/trade-in-history

Feature: Trade-in history page

Data sources:

- Local JSON fixture in route folder

### /sign-in

Feature: Sign-in form shell

Data sources:

- None currently (UI-only)

### /create-account

Feature: Create account form shell

Data sources:

- Attempts POST to /api/signup

Important note:

- No app/api/signup/route.ts exists currently. This call path is not implemented in this repo state.

## 6.2 Error/loading/not-found boundaries

- app/error.tsx: root error boundary
- app/not-found.tsx: root 404
- app/used-cars/error.tsx + app/used-cars/not-found.tsx: used-cars scoped boundaries
- app/my-garage/loading.tsx: my-garage loading state

---

## 7) API Layer Documentation (apps/web/src/app/api)

## 7.1 Search domain

### /api/search

Methods:

- GET: standard search query forwarding
- POST: mock faceted search endpoint for SRP state engine

Data source chain:

- searchVehicles() in features/search/services/search.service.ts
  - Production mode: SEARCH_SERVICE_URL upstream /vehicles/search
  - Mock mode: local mock vehicle filter/sort/pagination

Also forwards Arrow headers/IDs when present.

### /api/search/filters

Methods:

- POST only

Data source chain:

- runMockFilterSearch from mock-faceted-search

Purpose:

- Fetch facet/filter data in parallel to vehicle results

### /api/search/autocomplete

Methods:

- GET only

Data source chain:

- NlpAutocompleteService over inventory pool from mock-faceted-search

Purpose:

- Search box typeahead and quick filter pills

### /api/search/batch-counts

Methods:

- POST only

Data source chain:

- Executes multiple mock faceted searches in parallel and returns count map

Purpose:

- Landing page quick-link count hydration

### /api/search/vehicle/[id]

Methods:

- GET only

Data source chain:

- fetchVinData(id) from VDP service (id treated as VIN)
- Arrow IDs and forwarded headers passed through

### /api/search/dealer/[vin]

Methods:

- GET only

Data source chain:

- fetchVinData(vin) + fetchDealerByVin(vin) in parallel

## 7.2 Garage/profile domain

### /api/garage/profile

Methods:

- GET only

Data source chain:

- getMyGarageData()
  - Production mode: PROFILE_SERVICE_URL/profile/garage
  - Mock mode: local mock vehicles + because-viewed dataset

### /api/visitor-profile

Methods:

- GET: fetch cached visitor profile by visitorId
- POST: resolve profile action

Data source chain:

- tracking/services/visitor-profile.service
  - Production mode: PROFILE_SERVICE_URL upstream
  - Mock mode fallback supported

## 7.3 Tracking/session domain

### /api/session

Methods:

- GET: bootstrap check from session cookies
- POST:
  - mode bootstrap: reuse existing IDs/FED cookie data
  - mode initialize: resolve fingerprint, create session/profile, set cookies

Key behavior:

- Supports sealed result + fallback resolution
- Returns FED-safe fingerprint details only to client
- Persists separate session/fed cookies

### /api/events/track

Methods:

- POST only

Data source chain:

- trackEvent in tracking/services/events.service.ts
  - Production mode: EVENT_TRACKING_URL upstream
  - Mock/log path when service URL unavailable

Additional behavior:

- Supports encrypted payload decryption
- Revalidates visitor-profile cache tag on successful event

## 7.4 Saved registry domain

### /api/saved-registry/vehicles and /api/saved-registry/vehicles/[vin]

Methods:

- GET list
- POST add
- DELETE clear
- DELETE by vin

Data source chain:

- shared/lib/saved-registry/vehicles.service

Identity resolution:

- Fingerprint ID from Arrow headers/cookies (fallback anonymous)

Migration notes:

- Files include BED migration comments for future proxy replacement

### /api/saved-registry/search-history and /api/saved-registry/search-history/[id]

Methods:

- GET list
- POST add
- DELETE clear
- DELETE by id

Data source chain:

- shared/lib/saved-registry/search-history.service

## 7.5 Platform/system

### /api/revalidate

Methods:

- POST with tag + secret

Behavior:

- Validates REVALIDATION_SECRET
- Calls revalidateTag(tag, "max")

### /api/health

Methods:

- GET only

Behavior:

- Returns status + ISO timestamp
- Uses connection() to opt into dynamic behavior

### /.well-known/vercel/flags

Methods:

- GET discovery endpoint

Behavior:

- Exposes landing + VDP flag metadata to Vercel Flags Explorer

---

## 8) Feature Module Deep Dive

## 8.1 Landing feature

Responsibilities:

- Home hero, vehicle type selector, buying process, quick links, customer journey, inspected section

Primary data sources:

- fetchHeroStats()
- fetchVehicleFinderOptions()
- fetchVehicleFinderCounts() via /api/search/batch-counts

Caching:

- use cache + cacheLife("landing") + cache tags for landing datasets

Fallback strategy:

- Local mocks when LANDING_SERVICE_URL is unset or USE_MOCK_LANDING=true

## 8.2 Search feature

Responsibilities:

- SRP shell, query/filter state, search bar/autocomplete, filter sidebar, results list

Primary data sources:

- /api/search (results)
- /api/search/filters (facets)
- /api/search/autocomplete (suggestions)
- search history persistence APIs

Fallback strategy:

- Service-level mock mode with local inventory when SEARCH_SERVICE_URL missing or USE_MOCK_SEARCH=true

## 8.3 VDP feature

Responsibilities:

- Product detail presentation, specs/history/features/rating/dealer/promotions

Primary data sources:

- Cached server fetches from VDP services
- API routes for client-side consumers

Caching:

- VIN-level cache tags
- Bundle-level cache tags

Fallback strategy:

- Mock VIN/dealer data when VDP service unavailable or USE_MOCK_VDP=true

## 8.4 My Garage feature

Responsibilities:

- Personalized hero/cards/recommendations and garage intelligence

Primary data sources:

- /api/garage/profile -> my-garage.service
- Secondary client fetches may call /api/search/vehicle/[id]

Fallback strategy:

- Mock datasets from search inventory + because-viewed mock set

## 8.5 Favorites feature

Responsibilities:

- Save/unsave/list VINs and favorites UX

Primary data sources:

- saved-vehicles-api -> /api/saved-registry/vehicles

State model:

- TanStack Query + optimistic updates

Persistence:

- API-backed store + IndexedDB query persistence

## 8.6 My Account feature

Responsibilities:

- Profile, notifications, password, prequalification, trade-in history pages

Primary data sources:

- Mostly local fixtures currently
- Auth gate via feature-flag user model

## 8.7 Tracking feature

Responsibilities:

- Fingerprint SDK integration
- Session bootstrap/initialize
- Profile resolution and visitor profile cache
- Event tracking and optional payload encryption

Key architecture:

- FingerprintClientProvider -> ProfileProvider -> VisitorProfileProvider -> ArrowContext bridge
- Exposes useArrow and useEventTracking
- Keeps sensitive fingerprint data server-side; returns FED-safe subset to client

---

## 9) Caching, Revalidation, and Data Freshness

## 9.1 Server cache components

Used with Next.js cache components and tagged revalidation:

- Landing datasets: cacheLife("landing")
- Visitor profile service: cacheLife("profile")
- VDP services: cacheLife("vdp") with VIN and bundle tags

## 9.2 Client cache

TanStack Query defaults in QueryProvider:

- staleTime: 30 seconds
- gcTime: 24 hours
- retry: 1

Persisted queries:

- saved-vehicles
- search-history

Storage:

- IndexedDB best-effort persister

## 9.3 On-demand revalidation

- /api/revalidate invalidates arbitrary tag when authorized
- /api/events/track revalidates visitor-profile-{fingerprintId} tag after event

---

## 10) Security Model

## 10.1 HTTP response headers

Set in proxy.ts:

- CSP
- HSTS
- Frame/content/referrer/permissions controls

## 10.2 Tracking data minimization

- Full fingerprint event data remains server-side
- Client gets FED-safe shape only: visitorId, incognito, location

## 10.3 Identity transport

- Arrow IDs resolved from headers first, cookie fallback
- Session/profile cookies are httpOnly

## 10.4 Optional encrypted telemetry

- Events endpoint supports encrypted payloads and server-side decrypt

---

## 11) Environment Variable Reference

Variables detected in apps/web/src production code:

### 11.1 Core/runtime

- NODE_ENV
- NEXT_PUBLIC_APP_URL
- REVALIDATION_SECRET

### 11.2 Landing service

- LANDING_SERVICE_URL
- LANDING_API_KEY
- USE_MOCK_LANDING

### 11.3 Search service

- SEARCH_SERVICE_URL
- SEARCH_API_KEY
- USE_MOCK_SEARCH

### 11.4 VDP service

- VDP_SERVICE_URL
- VDP_API_KEY
- USE_MOCK_VDP

### 11.5 Profile/My Garage service

- PROFILE_SERVICE_URL
- PROFILE_API_KEY
- USE_MOCK_PROFILE
- NEXT_PUBLIC_PROFILE_SERVICE_URL

### 11.6 Tracking/events/fingerprint

- EVENT_TRACKING_URL
- EVENT_API_KEY
- NEXT_PUBLIC_EVENT_SERVICE_URL
- FINGERPRINT_SECRET_API_KEY
- FINGERPRINT_SEALED_KEY
- FINGERPRINT_API_BASE_URL
- FINGERPRINT_SERVICE_URL
- FINGERPRINT_API_KEY
- NEXT_PUBLIC_FINGERPRINT_API_KEY
- NEXT_PUBLIC_FINGERPRINT_REGION
- NEXT_PUBLIC_FINGERPRINT_ENDPOINT
- NEXT_PUBLIC_USE_FPJS_PROXY

### 11.7 Saved registry migration placeholders

- BED_SAVED_REGISTRY_URL
- BED_API_KEY

Note:

- Some BED variables are referenced in commented migration scaffolding.

---

## 12) Operational Workflows

## 12.1 Local development

From repo root:

- pnpm install
- pnpm dev

Useful task scripts:

- pnpm build
- pnpm test
- pnpm type-check
- pnpm check

## 12.2 Quality gates

- Biome/Ultracite checks
- Vitest test runs
- Type checking with TypeScript
- Husky + lint-staged on commit

## 12.3 Build output

- Next.js standalone output for deployment-friendly packaging

---

## 13) Known Gaps and Current TODO-Style Findings

1. Signup API mismatch

- Signup form posts to /api/signup, but no app/api/signup/route.ts exists.
- Result: signup form submits to a missing endpoint in current code state.

2. Placeholder routes in route constants

- ROUTES includes temporary sample VDP path and placeholder nav intent.
- Should be reviewed before release hardening.

3. My Account currently fixture-heavy

- User details/notifications/prequalification/trade-in are local data-driven.
- Production integration paths are not fully wired in these sections yet.

4. Saved registry currently local-service-backed

- API handlers include clear migration notes to BED endpoints, but current implementation resolves via shared local services.

---

## 14) Quick Ownership Index

When editing, use this ownership map:

- Route shells and API handlers: src/app
- Business features: src/features/*
- Cross-feature shared app logic: src/shared/*
- Navigation/layout shell: src/layout/*
- App-level config and route constants: src/config/*
- Shared package UI primitives/components: packages/ui
- Design tokens/themes: packages/ui-theme

---

## 15) Related Documentation in Repository

- docs/COMPONENT_ARCHITECTURE.md
- docs/FEATURE_FLAGS.md
- docs/LANDING_PAGE.md
- docs/USER_STORY_GARAGE_CARDS.md
- docs/vdp-implementation-flow.md

These are feature-specific deep dives; this file is the system-level master reference.

---

## 16) Architecture Diagrams

The diagrams below visualize the primary runtime architecture from three complementary angles:

- End-to-end request/data flow
- Provider and state composition flow
- Service fallback and cache decision flow

### 16.1 Request Flow (Page -> Feature -> API -> Service -> Data)

```mermaid
flowchart TD
    User["Browser User"]
    App["Next.js App Router<br/>apps/web/src/app"]

    subgraph Pages[Page Entry Points]
      Home["Route: /"]
      UsedCars["Route: /used-cars and /used-cars catch-all"]
      Garage["Route: /my-garage"]
      Favorites["Route: /favorites"]
      Account["Route: /my-account/*"]
    end

    subgraph Features[Feature Modules]
      Landing["features/landing"]
      Search["features/search"]
      VDP["features/vdp"]
      MyGarage["features/my-garage"]
      FavFeature["features/favorites"]
      Tracking["features/tracking"]
      MyAccount["features/my-account"]
    end

    subgraph APIs[Route Handlers]
      ApiSearch["/api/search"]
      ApiFilters["/api/search/filters"]
      ApiAutocomplete["/api/search/autocomplete"]
      ApiBatch["/api/search/batch-counts"]
      ApiVehicle["/api/search/vehicle/:id"]
      ApiDealer["/api/search/dealer/:vin"]
      ApiGarage["/api/garage/profile"]
      ApiSaved["/api/saved-registry/vehicles"]
      ApiHistory["/api/saved-registry/search-history"]
      ApiSession["/api/session"]
      ApiVisitor["/api/visitor-profile"]
      ApiEvents["/api/events/track"]
    end

    subgraph Services[Service Layer]
      LandingSvc["landing.service"]
      SearchSvc["search.service"]
      VDPSvc["vdp.service + dealer.service"]
      GarageSvc["my-garage.service"]
      VisitorSvc["visitor-profile.service"]
      EventSvc["events.service"]
      SavedSvc["shared/saved-registry services"]
    end

    subgraph Data[Data Sources]
      Upstream[("Upstream BED/3P Services")]
      MockData[("Local mocks + fixtures")]
      Cookies[("httpOnly/session cookies")]
      IDB[("IndexedDB query cache")]
    end

    User --> App
    App --> Home
    App --> UsedCars
    App --> Garage
    App --> Favorites
    App --> Account

    Home --> Landing
    UsedCars --> Search
    UsedCars --> VDP
    Garage --> MyGarage
    Favorites --> FavFeature
    Account --> MyAccount

    Landing --> LandingSvc
    LandingSvc --> ApiBatch
    Search --> ApiSearch
    Search --> ApiFilters
    Search --> ApiAutocomplete
    VDP --> VDPSvc
    VDP --> ApiVehicle
    VDP --> ApiDealer
    MyGarage --> ApiGarage
    FavFeature --> ApiSaved
    Search --> ApiHistory
    Tracking --> ApiSession
    Tracking --> ApiVisitor
    Tracking --> ApiEvents

    ApiSearch --> SearchSvc
    ApiFilters --> SearchSvc
    ApiAutocomplete --> SearchSvc
    ApiBatch --> SearchSvc
    ApiVehicle --> VDPSvc
    ApiDealer --> VDPSvc
    ApiGarage --> GarageSvc
    ApiSaved --> SavedSvc
    ApiHistory --> SavedSvc
    ApiVisitor --> VisitorSvc
    ApiEvents --> EventSvc

    LandingSvc --> Upstream
    SearchSvc --> Upstream
    VDPSvc --> Upstream
    GarageSvc --> Upstream
    VisitorSvc --> Upstream
    EventSvc --> Upstream

    LandingSvc --> MockData
    SearchSvc --> MockData
    VDPSvc --> MockData
    GarageSvc --> MockData
    VisitorSvc --> MockData
    EventSvc --> MockData

    ApiSession --> Cookies
    ApiVisitor --> Cookies
    ApiSaved --> Cookies
    ApiHistory --> Cookies

    FavFeature --> IDB
    Search --> IDB
```

### 16.2 Provider Composition Flow (Layout Runtime)

```mermaid
flowchart TD
    Root["RootLayout app/layout.tsx"]

    Root --> Theme["ThemeProvider"]
    Theme --> Arrow["ArrowProvider"]
    Arrow --> Query["QueryProvider"]
    Query --> SearchHistory["SearchHistoryProvider"]
    SearchHistory --> Favorites["FavoritesProvider"]

    Favorites --> SuspenseLoc["Suspense wrapper for LocationInit"]
    SuspenseLoc --> Location["LocationProvider"]
    Location --> Header["Header"]
    Location --> Children["Route Children"]

    Root --> Footer["Footer outside provider stack"]
    Root --> FlagDebug["FeatureFlagDebug dev only"]

    subgraph ArrowInternals[ArrowProvider Internals]
      FPClient["FingerprintClientProvider"]
      ProfileCtx["ProfileProvider"]
      VisitorCtx["VisitorProfileProvider"]
      ArrowBridge["Arrow Context Bridge"]
      FPClient --> ProfileCtx --> VisitorCtx --> ArrowBridge
    end

    Arrow -.composes.-> ArrowInternals

    subgraph PersistentState[Persistence Boundaries]
      QCache[("IndexedDB persisted queries")]
      ManualZip[("Cookie arrow_manual_zip")]
      ArrowCookies[("Cookies session/fingerprint/profile/fed")]
    end

    Query --> QCache
    Location --> ManualZip
    Arrow --> ArrowCookies
```

### 16.3 Service Fallback and Cache Flow

```mermaid
flowchart TD
  Caller["Server Component or API Route"] --> Service{"Service Called"}

  Service --> LandingSvc["Landing Service"]
  Service --> SearchSvc["Search Service"]
  Service --> VDPSvc["VDP Dealer Service"]
  Service --> GarageSvc["MyGarage Service"]
  Service --> VisitorSvc["Visitor Profile Service"]
  Service --> EventSvc["Events Service"]

  LandingSvc --> LandingCache{"use cache and cacheLife landing"}
  LandingCache -->|yes| LandingTag["cacheTag and cached return"]
  LandingCache -->|no| LandingMode{"LANDING_SERVICE_URL set and USE_MOCK_LANDING not true"}
  LandingMode -->|yes| LandingUp["Call upstream landing API"]
  LandingMode -->|no| LandingMock["Return landing mocks"]
  LandingUp --> LandingOk{"Success"}
    LandingOk -->|yes| LandingTag
    LandingOk -->|no| LandingMock

  SearchSvc --> SearchMode{"SEARCH_SERVICE_URL set and USE_MOCK_SEARCH not true"}
  SearchMode -->|yes| SearchUp["POST upstream vehicles search"]
  SearchMode -->|no| SearchMock["Mock filter sort paginate inventory"]
  SearchUp --> SearchOk{"Success"}
  SearchOk -->|yes| SearchOut["Return search result"]
  SearchOk -->|no| SearchEmpty["Return empty safe fallback"]
    SearchMock --> SearchOut

  VDPSvc --> VDPCache{"Cached path fetchVinDataCached or getVehicleBundleCached"}
  VDPCache -->|yes| VDPTag["cacheLife vdp and cacheTag vin bundle"]
  VDPCache -->|no| VDPMode{"VDP_SERVICE_URL set and USE_MOCK_VDP not true"}
  VDPMode -->|yes| VDPUp["Call upstream VDP dealer APIs"]
  VDPMode -->|no| VDPMock["Return mock VIN dealer data"]
  VDPUp --> VDPOk{"Success"}
  VDPOk -->|yes| VDPOut["Return VDP payload"]
    VDPOk -->|no| VDPMock
    VDPMock --> VDPOut
    VDPTag --> VDPOut

  GarageSvc --> GarageMode{"PROFILE_SERVICE_URL set and USE_MOCK_PROFILE not true"}
  GarageMode -->|yes| GarageUp["GET upstream profile garage"]
  GarageMode -->|no| GarageMock["Assemble garage data from local datasets"]
  GarageUp --> GarageOk{"Success"}
  GarageOk -->|yes| GarageOut["Return garage payload"]
    GarageOk -->|no| GarageMock
    GarageMock --> GarageOut

  VisitorSvc --> ProfileCache{"cacheLife profile path used"}
  ProfileCache -->|yes| ProfileTag["Tag based cache for visitor profile"]
  ProfileCache -->|no| ProfileMode{"PROFILE_SERVICE_URL set and USE_MOCK_PROFILE not true"}
  ProfileMode -->|yes| ProfileUp["Call upstream profile endpoints"]
  ProfileMode -->|no| ProfileMock["Use mock profile behavior"]
  ProfileUp --> ProfileOk{"Success"}
  ProfileOk -->|yes| ProfileOut["Return profile data"]
    ProfileOk -->|no| ProfileMock
    ProfileMock --> ProfileOut
    ProfileTag --> ProfileOut

  EventSvc --> EventMode{"EVENT_TRACKING_URL set"}
  EventMode -->|yes| EventUp["POST upstream event service with timeout"]
  EventMode -->|no| EventMock["Local mock tracking behavior"]
  EventUp --> EventOut["Return eventId and success"]
    EventMock --> EventOut

  EventOut --> Revalidate["revalidateTag visitor-profile fingerprintId"]
```

### 16.4 Deployment and Runtime Topology

```mermaid
flowchart LR
    subgraph Client[Client Runtime]
      Browser[User Browser]
      IDB[(IndexedDB\nTanStack persisted queries)]
      ClientCookies[(Browser Cookies\nmanual zip + httpOnly session/profile/fed)]
    end

    subgraph Edge[Edge/Middleware Layer]
      Middleware[middleware.ts -> proxy.ts\nSecurity headers + CSP]
    end

    subgraph AppServer[Next.js Server Runtime apps/web]
      AppRouter[App Router\nServer Components + Route Handlers]
      ProviderTree[Provider Composition\nTheme/Arrow/Query/SearchHistory/Favorites/Location]
      ApiRoutes[API Routes\n/api/* + /.well-known/vercel/flags]
      ServerCache[(Next Cache Components\ncacheLife/cacheTag/revalidateTag)]
    end

    subgraph InternalData[Local App Data Paths]
      Mocks[Local mocks + fixtures\nsearch/landing/vdp/my-account]
      SavedRegistry[shared/lib/saved-registry/*\nvehicles + search history]
    end

    subgraph ExternalServices[External/Upstream Services]
      LandingAPI[Landing Service\nLANDING_SERVICE_URL]
      SearchAPI[Search Service\nSEARCH_SERVICE_URL]
      VDPAPI[VDP Service\nVDP_SERVICE_URL]
      ProfileAPI[Profile Service\nPROFILE_SERVICE_URL]
      EventAPI[Event Service\nEVENT_TRACKING_URL]
      FingerprintSDK[Fingerprint Pro JS SDK]
      FingerprintServer[Fingerprint Server API]
    end

    Browser --> Middleware --> AppRouter
    AppRouter --> ProviderTree
    AppRouter --> ApiRoutes
    AppRouter <--> ServerCache

    ProviderTree <--> IDB
    Browser <--> ClientCookies
    ApiRoutes <--> ClientCookies

    ApiRoutes --> SavedRegistry
    AppRouter --> Mocks
    ApiRoutes --> Mocks

    AppRouter --> LandingAPI
    ApiRoutes --> SearchAPI
    AppRouter --> VDPAPI
    ApiRoutes --> VDPAPI
    AppRouter --> ProfileAPI
    ApiRoutes --> ProfileAPI
    ApiRoutes --> EventAPI

    Browser --> FingerprintSDK
    ApiRoutes --> FingerprintServer
```
