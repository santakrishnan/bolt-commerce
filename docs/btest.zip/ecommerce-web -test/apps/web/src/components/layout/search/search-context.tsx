"use client";

import { useQuery } from "@tanstack/react-query";
import type { Dispatch, MutableRefObject, ReactNode, SetStateAction } from "react";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  useTransition,
} from "react";
import type {
  AvailableFilters,
  FilterState,
} from "~/components/features/search/filter-sidebar/types";
import { API_ROUTES } from "~/lib/routes/constants";
import {
  ALL_FACET_SECTIONS,
  type FacetSection,
  type MockFacetedSearchRequest,
  type MockFacetedSearchResponse,
  type MockFilterSearchRequest,
  type MockFilterSearchResponse,
} from "~/lib/search/mock-faceted-search";
import type { FacetCounts, RefineFilter } from "~/lib/search/mock-search-service";
import type { Vehicle } from "~/lib/search/mock-vehicles";

export type { AvailableFilters } from "~/components/features/search/filter-sidebar/types";
export type { FacetCounts, RefineFilter } from "~/lib/search/mock-search-service";

interface RefineSearchFilter {
  id: string;
  label: string;
}

interface SearchContextValue {
  applyFiltersSearch: (
    newFilterState: FilterState,
    opts?: {
      searchQuery?: string;
      labelFilter?: string;
      refineFilters?: RefineFilter[];
      preservePage?: boolean;
    }
  ) => Promise<void>;
  availableFilters: AvailableFilters;
  currentPage: number;
  facetCounts: FacetCounts;
  filterState: FilterState;
  handleSearch: () => void;
  isFilterOpen: boolean;
  isProgressVisible: boolean;
  isSearching: boolean;
  labelFilter: string;
  loadingFacetSections: FacetSection[];
  progress: number;
  refineSearchFilters: RefineSearchFilter[];
  searchQuery: string;
  searchQueryRef: MutableRefObject<string>;
  setCurrentPage: Dispatch<SetStateAction<number>>;
  setFilterState: Dispatch<SetStateAction<FilterState>>;
  setIsFilterOpen: Dispatch<SetStateAction<boolean>>;
  setIsProgressVisible: Dispatch<SetStateAction<boolean>>;
  setLabelFilter: Dispatch<SetStateAction<string>>;
  setProgress: Dispatch<SetStateAction<number>>;
  setRefineSearchFilters: Dispatch<SetStateAction<RefineSearchFilter[]>>;
  setSearchQuery: Dispatch<SetStateAction<string>>;
  setSortOption: Dispatch<SetStateAction<"recommended" | "low-high" | "high-low">>;
  setVehiclePool: Dispatch<SetStateAction<Vehicle[]>>;
  sortOption: "recommended" | "low-high" | "high-low";
  totalCount: number;
  vehiclePool: Vehicle[];
}

const SearchContext = createContext<SearchContextValue | undefined>(undefined);

function listEqual(a: string[], b: string[]): boolean {
  if (a.length !== b.length) {
    return false;
  }
  const aa = [...a].sort();
  const bb = [...b].sort();
  return aa.every((item, idx) => item === bb[idx]);
}

function mergeUniqueSections(current: FacetSection[], next: FacetSection[]): FacetSection[] {
  return [...new Set([...current, ...next])];
}

function changedFacetSections(
  prev: FilterState,
  next: FilterState,
  opts?: { queryChanged?: boolean; labelChanged?: boolean; refineChanged?: boolean }
): FacetSection[] {
  const changed: FacetSection[] = [];

  if (prev.selectedPriceQuick !== next.selectedPriceQuick) {
    changed.push("Price");
  }
  if (prev.selectedYearQuick !== next.selectedYearQuick) {
    changed.push("Year");
  }
  if (prev.selectedMileage !== next.selectedMileage) {
    changed.push("Mileage");
  }
  if (!listEqual(prev.selectedBodyStyles, next.selectedBodyStyles)) {
    changed.push("Body Style");
  }
  if (!listEqual(prev.selectedExteriorColors, next.selectedExteriorColors)) {
    changed.push("Exterior Color");
  }
  if (!listEqual(prev.selectedInteriorColors, next.selectedInteriorColors)) {
    changed.push("Interior Color");
  }
  if (!listEqual(prev.selectedModels, next.selectedModels)) {
    changed.push("Make & Model");
  }
  if (!listEqual(prev.selectedFuelTypes, next.selectedFuelTypes)) {
    changed.push("Fuel Type");
  }
  if (
    !(
      listEqual(prev.selectedSafetyFeatures, next.selectedSafetyFeatures) &&
      listEqual(prev.selectedComfortFeatures, next.selectedComfortFeatures) &&
      listEqual(prev.selectedTechFeatures, next.selectedTechFeatures) &&
      listEqual(prev.selectedExteriorFeatures, next.selectedExteriorFeatures) &&
      listEqual(prev.selectedPerformanceFeatures, next.selectedPerformanceFeatures) &&
      listEqual(prev.selectedSeatingCapacity, next.selectedSeatingCapacity)
    )
  ) {
    changed.push("Features & Technology");
  }
  if (prev.inspection160 !== next.inspection160) {
    changed.push("Inspection");
  }
  if (!listEqual(prev.selectedDrivetrains, next.selectedDrivetrains)) {
    changed.push("Drivetrain");
  }
  if (!listEqual(prev.selectedTransmissions, next.selectedTransmissions)) {
    changed.push("Transmission");
  }

  if (opts?.queryChanged || opts?.labelChanged || opts?.refineChanged) {
    return ALL_FACET_SECTIONS;
  }

  return [...new Set(changed)];
}

function useDebouncedValue<T>(value: T, delayMs: number): T {
  const [debounced, setDebounced] = useState(value);

  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(value), delayMs);
    return () => window.clearTimeout(timer);
  }, [value, delayMs]);

  return debounced;
}

// ── Fetch functions (two independent endpoints) ───────────────────────

async function fetchVehicleSearch(
  request: MockFacetedSearchRequest
): Promise<MockFacetedSearchResponse> {
  const res = await fetch(API_ROUTES.SEARCH, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify({ ...request, includeFacets: false }),
  });

  if (!res.ok) {
    throw new Error(`Vehicle search failed: ${res.status}`);
  }

  return (await res.json()) as MockFacetedSearchResponse;
}

async function fetchFilters(
  request: MockFilterSearchRequest
): Promise<MockFilterSearchResponse> {
  const res = await fetch(API_ROUTES.SEARCH_FILTERS, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify(request),
  });

  if (!res.ok) {
    throw new Error(`Filters search failed: ${res.status}`);
  }

  return (await res.json()) as MockFilterSearchResponse;
}

// ── Context hook ──────────────────────────────────────────────────────

export function useSearchContext() {
  const ctx = useContext(SearchContext);
  if (!ctx) {
    throw new Error("useSearchContext must be used within SearchProvider");
  }
  return ctx;
}

// ── Provider ──────────────────────────────────────────────────────────

interface SearchProviderProps {
  children: ReactNode;
  defaultFilterState: FilterState;
  initialBodyStyles?: string[];
  initialSearchQuery?: string;
  initialUrlFilters?: Partial<FilterState>;
}

export function SearchProvider({
  children,
  initialBodyStyles = [],
  initialSearchQuery = "",
  initialUrlFilters,
  defaultFilterState,
}: SearchProviderProps) {
  const [sortOption, setSortOption] = useState<"recommended" | "low-high" | "high-low">(
    "recommended"
  );
  const [vehiclePool, setVehiclePool] = useState<Vehicle[]>([]);
  const [filterState, setFilterState] = useState<FilterState>({
    ...defaultFilterState,
    ...initialUrlFilters,
    ...(initialBodyStyles.length > 0 ? { selectedBodyStyles: initialBodyStyles } : {}),
  });
  const [searchQuery, setSearchQuery] = useState(initialSearchQuery);
  const searchQueryRef = useRef(initialSearchQuery);
  const [labelFilter, setLabelFilter] = useState("");
  const [refineSearchFilters, setRefineSearchFilters] = useState<RefineSearchFilter[]>([]);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [progress, setProgress] = useState(0);
  const [isProgressVisible, setIsProgressVisible] = useState(false);
  const progressTimers = useRef<number[]>([]);
  const [availableFilters, setAvailableFilters] = useState<AvailableFilters>({
    bodyStyles: [],
    exteriorColors: [],
    interiorColors: [],
    fuelTypes: [],
    models: [],
    safetyFeatures: [],
    comfortFeatures: [],
    techFeatures: [],
    exteriorFeatures: [],
    performanceFeatures: [],
    seatingCapacity: [],
    hasInspection160: false,
    drivetrains: [],
    transmissions: [],
    totalCount: 0,
  });
  const [facetCounts, setFacetCounts] = useState<FacetCounts>({
    bodyType: {},
    exteriorColor: {},
    interiorColor: {},
    fuelType: {},
    drivetrain: {},
    transmission: {},
    priceRange: { min: 0, max: 0 },
    yearRange: { min: 0, max: 0 },
    mileageRange: { min: 0, max: 0 },
  });
  const [totalCount, setTotalCount] = useState<number>(0);
  const [pendingFacetSections, setPendingFacetSections] =
    useState<FacetSection[]>(ALL_FACET_SECTIONS);
  const [loadingFacetSections, setLoadingFacetSections] =
    useState<FacetSection[]>(ALL_FACET_SECTIONS);

  // Correlation IDs for request tracking
  const [searchId, setSearchId] = useState("");
  const [filterId, setFilterId] = useState("");

  // React 19 useTransition — keeps vehicle grid interactive during filter updates
  const [, startFilterTransition] = useTransition();

  // ── Query 1: Vehicle search payload ─────────────────────────────────
  const searchRequestPayload = useMemo<MockFacetedSearchRequest>(
    () => ({
      filterState,
      searchQuery,
      labelFilter,
      refineFilters: refineSearchFilters,
      sortOption,
      page: currentPage,
      pageSize: 20,
      includeFacets: false,
      searchId: searchId || undefined,
    }),
    [filterState, searchQuery, labelFilter, refineSearchFilters, sortOption, currentPage, searchId]
  );

  // ── Query 2: Filters payload ────────────────────────────────────────
  const filterRequestPayload = useMemo<MockFilterSearchRequest>(
    () => ({
      filterState,
      searchQuery,
      labelFilter,
      refineFilters: refineSearchFilters,
      updatedSections: pendingFacetSections,
      searchId: searchId || undefined,
      filterId: filterId || undefined,
    }),
    [filterState, searchQuery, labelFilter, refineSearchFilters, pendingFacetSections, searchId, filterId]
  );

  const handleSearch = useCallback(() => {
    for (const timer of progressTimers.current) {
      clearTimeout(timer);
    }
    progressTimers.current = [];

    setIsProgressVisible(false);
    setProgress(0);

    progressTimers.current.push(
      window.setTimeout(() => {
        setIsProgressVisible(true);
        setProgress(0);
      }, 16) as unknown as number,
      window.setTimeout(() => setProgress(78), 20) as unknown as number,
      window.setTimeout(() => setProgress(100), 850) as unknown as number,
      window.setTimeout(() => {
        setIsProgressVisible(false);
      }, 1200) as unknown as number
    );
  }, []);

  const debouncedSearchRequest = useDebouncedValue(searchRequestPayload, 300);
  const debouncedFilterRequest = useDebouncedValue(filterRequestPayload, 300);

  // ── Query 1: Vehicle search (fires independently) ───────────────────
  const vehicleSearchQuery = useQuery({
    queryKey: ["vehicle-search", debouncedSearchRequest],
    queryFn: () => fetchVehicleSearch(debouncedSearchRequest),
    enabled: true,
    placeholderData: (prev) => prev,
    staleTime: 20_000,
    refetchOnWindowFocus: false,
    retry: 1,
    structuralSharing: true,
  });

  // ── Query 2: Filters/facets (fires independently, non-blocking) ────
  const filtersQuery = useQuery({
    queryKey: ["search-filters", debouncedFilterRequest],
    queryFn: () => fetchFilters(debouncedFilterRequest),
    enabled: debouncedFilterRequest.updatedSections
      ? debouncedFilterRequest.updatedSections.length > 0
      : false,
    placeholderData: (prev) => prev,
    staleTime: 20_000,
    refetchOnWindowFocus: false,
    retry: 1,
    structuralSharing: true,
  });

  // ── Process vehicle search results ──────────────────────────────────
  useEffect(() => {
    const data = vehicleSearchQuery.data;
    if (!data) {
      return;
    }

    const maxInventory = data.metadata.inventorySize;
    const boundedTotalCount = Math.max(0, Math.min(data.totalCount, maxInventory));

    setVehiclePool(data.vehicles);
    setTotalCount(boundedTotalCount);

    // Update searchId from response (reused or newly generated)
    if (data.metadata.searchId) {
      setSearchId(data.metadata.searchId);
    }
  }, [vehicleSearchQuery.data]);

  // ── Process filters results ─────────────────────────────────────────
  useEffect(() => {
    const data = filtersQuery.data;
    if (!data) {
      return;
    }

    if (data.facets.updatedSections.length > 0) {
      setAvailableFilters((prev) => ({
        ...prev,
        ...data.facets.availableFiltersPatch,
      }));
      setFacetCounts((prev) => ({
        ...prev,
        ...data.facets.facetCountsPatch,
      }));

      // Clear pending sections
      setPendingFacetSections((prev) => {
        if (prev.length === 0) {
          return prev;
        }
        return [];
      });
    }

    // Update filterId from response
    if (data.filterId) {
      setFilterId(data.filterId);
    }

    setLoadingFacetSections((prev) =>
      prev.filter((section) => !data.facets.updatedSections.includes(section))
    );
  }, [filtersQuery.data]);

  // Trigger progress bar when vehicle search starts
  useEffect(() => {
    if (vehicleSearchQuery.isFetching) {
      handleSearch();
    }
  }, [vehicleSearchQuery.isFetching, handleSearch]);

  const applyFiltersSearch = useCallback(
    (
      newFilterState: FilterState,
      opts?: {
        searchQuery?: string;
        labelFilter?: string;
        refineFilters?: RefineFilter[];
        preservePage?: boolean;
      }
    ) => {
      const nextSearchQuery = opts?.searchQuery ?? searchQueryRef.current;
      const nextLabelFilter = opts?.labelFilter ?? labelFilter;
      let nextRefineFilters: RefineFilter[];
      if (opts?.refineFilters !== undefined) {
        const uniq: RefineFilter[] = [];
        for (const f of opts.refineFilters) {
          if (!uniq.some((u) => u.id === f.id)) {
            uniq.push(f);
          }
        }
        nextRefineFilters = uniq;
      } else {
        nextRefineFilters = refineSearchFilters;
      }

      const sections = changedFacetSections(filterState, newFilterState, {
        queryChanged: nextSearchQuery !== searchQuery,
        labelChanged: nextLabelFilter !== labelFilter,
        refineChanged:
          opts?.refineFilters !== undefined ||
          !listEqual(
            refineSearchFilters.map((f) => f.id),
            nextRefineFilters.map((f) => f.id)
          ),
      });

      const changedSections = sections.length > 0 ? sections : [];

      // New search query = new correlation IDs
      if (nextSearchQuery !== searchQuery) {
        setSearchId("");
        setFilterId("");
      }

      // Use React 19 useTransition to keep UI responsive during filter updates
      startFilterTransition(() => {
        setFilterState(newFilterState);
        setSearchQuery(nextSearchQuery);
        searchQueryRef.current = nextSearchQuery;
        setLabelFilter(nextLabelFilter);
        setRefineSearchFilters(nextRefineFilters);
        if (!opts?.preservePage) {
          setCurrentPage(1);
        }

        setPendingFacetSections((prev) => mergeUniqueSections(prev, changedSections));
        setLoadingFacetSections((prev) => mergeUniqueSections(prev, changedSections));
      });

      return Promise.resolve();
    },
    [filterState, searchQuery, labelFilter, refineSearchFilters]
  );

  const isSearching = vehicleSearchQuery.isFetching || filtersQuery.isFetching;

  const contextValue = useMemo(
    () => ({
      vehiclePool,
      setVehiclePool,
      filterState,
      setFilterState,
      searchQuery,
      setSearchQuery,
      searchQueryRef,
      labelFilter,
      setLabelFilter,
      refineSearchFilters,
      setRefineSearchFilters,
      currentPage,
      setCurrentPage,
      progress,
      setProgress,
      isProgressVisible,
      setIsProgressVisible,
      isFilterOpen,
      setIsFilterOpen,
      sortOption,
      setSortOption,
      availableFilters,
      facetCounts,
      totalCount,
      isSearching,
      loadingFacetSections,
      applyFiltersSearch,
      handleSearch,
    }),
    [
      vehiclePool,
      filterState,
      searchQuery,
      labelFilter,
      refineSearchFilters,
      currentPage,
      progress,
      isProgressVisible,
      isFilterOpen,
      sortOption,
      availableFilters,
      facetCounts,
      totalCount,
      isSearching,
      loadingFacetSections,
      applyFiltersSearch,
      handleSearch,
    ]
  );

  return <SearchContext.Provider value={contextValue}>{children}</SearchContext.Provider>;
}
