import type { ReactNode } from "react";
import type {
  FeatureCategory,
  HistoryData,
  PriceHistoryEntry,
  PricingData,
  VehicleDetail,
  VehicleSpecData,
  VehicleStatusData,
} from "~/lib/data/vehicle";
import { FeaturesTab } from "./features-tab";
import { HistoryTab } from "./history-tab";
import { OverviewTab } from "./overview-tab";
import { PricingTab } from "./pricing-tab";
import { VehicleDetailsTabsClient } from "./vehicle-details-tabs-client";
import type { VehicleMetaBarChipComponents } from "./vehicle-meta-bar";

interface VehicleDetailsTabsProps {
  className?: string;
  features: FeatureCategory[];
  featuresInitialCount: number;
  featuresTableView?: boolean;
  historyData: HistoryData;
  metaBarChipComponents?: VehicleMetaBarChipComponents;
  priceHistory: PriceHistoryEntry[];
  pricingData: PricingData;
  showInspectionSection?: boolean;
  specs: VehicleSpecData[];
  vehicle: VehicleDetail;
  vehicleStatus: VehicleStatusData;
}

export function VehicleDetailsTabs({
  className,
  specs,
  features,
  featuresInitialCount,
  pricingData,
  priceHistory,
  historyData,
  featuresTableView: _featuresTableView = false,
}: VehicleDetailsTabsProps) {
  const tabDefs: Array<{
    content: ReactNode;
    contentClassName?: string;
    id: string;
    label: string;
  }> = [
    {
      id: "overview",
      label: "Overview",
      content: <OverviewTab specs={specs} />,
      contentClassName: "mt-0 md:px-[var(--spacing-md)] lg:px-0",
    },
    {
      id: "features",
      label: "Features & Details",
      content: <FeaturesTab features={features} initialCount={featuresInitialCount} />,
      contentClassName: "mt-0",
    },
    {
      id: "pricing",
      label: "Pricing",
      content: <PricingTab priceHistory={priceHistory} pricingData={pricingData} />,
      contentClassName: "mt-0",
    },
    {
      id: "history",
      label: "History",
      content: <HistoryTab historyData={historyData} />,
      contentClassName: "mt-0",
    },
  ];

  return <VehicleDetailsTabsClient className={className} tabDefs={tabDefs} />;
}
