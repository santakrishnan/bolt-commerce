import { redirect } from "next/navigation";
import { MyGarageWrapper } from "~/components/layout/my-garage";
import { getUserInfo, showPersonalizedHeroBanner } from "~/lib/flags/flags";
import { ROUTES } from "~/lib/routes/constants";

export default async function MyGaragePage() {
  // Only authenticated users can access this page
  const [{ isAuthenticated }, showPersonalizedBanner] = await Promise.all([
    getUserInfo(),
    showPersonalizedHeroBanner(),
  ]);

  if (!isAuthenticated) {
    redirect(ROUTES.HOME);
  }

  // Pass bannerHeightClass so the HomeHeroStatic banner can be full viewport on this page
  return (
    <MyGarageWrapper
      bannerHeightClass={"h-[422px] lg:h-87.5"}
      showUserName={showPersonalizedBanner}
    />
  );
  // return <MyGarageWrapper showUserName={showPersonalizedBanner} />;
}
