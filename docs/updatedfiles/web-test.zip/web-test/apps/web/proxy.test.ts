import { NextResponse } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { proxy } from "./proxy";

// Mock NextResponse.next()
vi.mock("next/server", async () => {
  const actual = await vi.importActual("next/server");
  return {
    ...actual,
    NextResponse: {
      next: vi.fn(() => {
        // Simulate a real Response object with headers
        return {
          headers: new Map(),
          // allow chaining
          clone() {
            return this;
          },
        };
      }),
    },
  };
});

describe("proxy middleware", () => {
  let response: any;

  beforeEach(() => {
    vi.clearAllMocks();
    response = proxy({} as any);
  });

  it("returns a NextResponse object", () => {
    expect(response).toBeDefined();
    expect(typeof response).toBe("object");
    expect(response.headers).toBeInstanceOf(Map);
  });

  it("sets all required security headers", () => {
    const expectedHeaders = [
      ["X-DNS-Prefetch-Control", "on"],
      ["Strict-Transport-Security", "max-age=63072000; includeSubDomains; preload"],
      ["X-Frame-Options", "SAMEORIGIN"],
      ["X-Content-Type-Options", "nosniff"],
      ["X-XSS-Protection", "1; mode=block"],
      ["Referrer-Policy", "strict-origin-when-cross-origin"],
      ["Permissions-Policy", "camera=(), microphone=(), geolocation=(), interest-cohort=()"],
    ];
    for (const [key, value] of expectedHeaders) {
      expect(response.headers.get(key)).toBe(value);
    }
  });

  it("does not redirect to HTTPS in development", () => {
    // The commented-out redirect logic should not run
    expect(response.status).toBeUndefined();
  });

  it("is idempotent and does not mutate input", () => {
    const req = {};
    const res1 = proxy(req as any);
    const res2 = proxy(req as any);
    expect(res1).not.toBe(res2); // Should return a new object each time
  });

  it("does not throw on minimal input", () => {
    expect(() => proxy({} as any)).not.toThrow();
  });

  // Edge case: ensure headers can be overwritten
  it("overwrites existing security headers", () => {
    const customResponse = {
      headers: new Map([["X-Frame-Options", "DENY"]]),
      clone() {
        return this;
      },
    };
    (NextResponse.next as any).mockReturnValueOnce(customResponse);
    const res = proxy({} as any);
    expect(res.headers.get("X-Frame-Options")).toBe("SAMEORIGIN");
  });
});
