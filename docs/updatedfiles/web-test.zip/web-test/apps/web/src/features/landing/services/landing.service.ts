import { ArrowServerError, createArrowServerClient } from "@features/tracking/lib/server-api";
import { cacheLife, cacheTag } from "next/cache";
import { MOCK_HERO_STATS, MOCK_VEHICLE_FINDER_OPTIONS } from "./landing.mocks";
import type {
  HeroStat,
  RawHeroStat,
  RawHeroStatsResponse,
  RawVehicleFinderCountsResponse,
  VehicleFinderCounts,
  VehicleFinderOptionStatic,
} from "./types";

let _client: ReturnType<typeof createArrowServerClient> | null = null;

function getLandingClient() {
  if (!_client) {
    _client = createArrowServerClient({
      baseUrl: process.env.LANDING_SERVICE_URL ?? "",
      authToken: process.env.LANDING_API_KEY,
      serviceName: "LandingService",
      timeout: 10_000,
      retries: 1,
    });
  }
  return _client;
}

function isMockMode(): boolean {
  return !process.env.LANDING_SERVICE_URL || process.env.USE_MOCK_LANDING === "true";
}

export function transformRawHeroStat(raw: RawHeroStat): HeroStat {
  return {
    id: raw.id ?? raw.key ?? "",
    value: String(raw.value ?? raw.metric_value ?? ""),
    label: raw.label ?? raw.display_name ?? "",
    icon: raw.icon ?? raw.icon_url ?? "",
  };
}

export function transformHeroStats(raw: RawHeroStatsResponse): HeroStat[] {
  const items = raw.features ?? raw.stats ?? raw.metrics ?? raw.data ?? [];
  return items.map(transformRawHeroStat);
}

export function transformVehicleFinderCounts(
  raw: RawVehicleFinderCountsResponse
): VehicleFinderCounts {
  const counts = raw.counts ?? raw.data ?? raw;
  return {
    "under-20k": Number(counts["under-20k"] ?? 0),
    "excellent-deals": Number(counts["excellent-deals"] ?? 0),
    "price-drop": Number(counts["price-drop"] ?? 0),
    "low-miles": Number(counts["low-miles"] ?? 0),
  };
}

export async function fetchHeroStats(): Promise<HeroStat[]> {
  "use cache";
  cacheLife("landing");
  cacheTag("hero-stats");

  if (isMockMode()) {
    console.log("[LandingService] Mock mode — returning local hero stats");
    return MOCK_HERO_STATS;
  }

  try {
    const raw = await getLandingClient().get<RawHeroStatsResponse>("/landing/hero-stats");
    return transformHeroStats(raw);
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[LandingService] Upstream error (hero-stats):", error.message);
    } else {
      console.error("[LandingService] Unexpected error (hero-stats):", error);
    }
    return MOCK_HERO_STATS;
  }
}

export async function fetchVehicleFinderOptions(): Promise<VehicleFinderOptionStatic[]> {
  "use cache";
  cacheLife("landing");
  cacheTag("vehicle-finder-options");

  if (isMockMode()) {
    console.log("[LandingService] Mock mode — returning local finder options");
    return MOCK_VEHICLE_FINDER_OPTIONS;
  }

  try {
    const raw = await getLandingClient().get<{ options: VehicleFinderOptionStatic[] }>(
      "/landing/vehicle-finder/options"
    );
    return raw.options ?? MOCK_VEHICLE_FINDER_OPTIONS;
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[LandingService] Upstream error (finder-options):", error.message);
    } else {
      console.error("[LandingService] Unexpected error (finder-options):", error);
    }
    return MOCK_VEHICLE_FINDER_OPTIONS;
  }
}

export async function fetchVehicleFinderCounts(): Promise<VehicleFinderCounts> {
  "use cache";
  cacheLife("landing");
  cacheTag("vehicle-finder-counts");

  try {
    // Call the batch API directly (server-side)
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
    const response = await fetch(`${baseUrl}/api/search/batch-counts`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        queries: [
          { id: "under-20k", searchQuery: "cars-under-$20,000" },
          { id: "excellent-deals", searchQuery: "shop-excellent-deals" },
          { id: "price-drop", searchQuery: "price-drop" },
          { id: "low-miles", searchQuery: "low-miles" },
        ],
      }),
    });

    if (!response.ok) {
      throw new Error(`Batch counts API failed: ${response.status}`);
    }

    const data = (await response.json()) as { counts: VehicleFinderCounts };
    console.log("[LandingService] Fetched counts via batch API:", data.counts);
    return data.counts;
  } catch (error) {
    if (error instanceof ArrowServerError) {
      console.error("[LandingService] Upstream error (finder-counts):", error.message);
    } else {
      console.error("[LandingService] Unexpected error (finder-counts):", error);
    }
    return { "under-20k": 0, "excellent-deals": 0, "price-drop": 0, "low-miles": 0 };
  }
}
