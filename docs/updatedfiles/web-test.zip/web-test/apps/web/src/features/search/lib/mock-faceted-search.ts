import type {
  AvailableFilters,
  FilterState,
} from "@features/search/components/filter-sidebar/types";
import { SEARCH_PAGE_SIZE } from "@features/search/lib/constants";
import {
  computeAvailableFiltersSync,
  type FacetCounts,
  mockSearchVehicles,
  type RefineFilter,
  type SortOption,
} from "@features/search/lib/mock-search-service";
import { mockVehicles, type Vehicle } from "@features/search/lib/mock-vehicles";
import smartFiltersData from "./smart-filters.json";

export type FacetSection =
  | "Price"
  | "Year"
  | "Mileage"
  | "Body Style"
  | "Exterior Color"
  | "Interior Color"
  | "Make & Model"
  | "Fuel Type"
  | "Features & Technology"
  | "Inspection"
  | "Drivetrain"
  | "Transmission";

export const ALL_FACET_SECTIONS: FacetSection[] = [
  "Price",
  "Year",
  "Mileage",
  "Body Style",
  "Exterior Color",
  "Interior Color",
  "Make & Model",
  "Fuel Type",
  "Features & Technology",
  "Inspection",
  "Drivetrain",
  "Transmission",
];

const FACET_VERSION = "mock-faceted-search-v1";

const inventoryPool = mockVehicles;
const inventorySize = inventoryPool.length;

export interface FacetPatch {
  availableFiltersPatch: Partial<AvailableFilters>;
  facetCountsPatch: Partial<FacetCounts>;
  updatedSections: FacetSection[];
}

export interface MockFacetedSearchRequest {
  filterState: FilterState;
  includeFacets?: boolean;
  labelFilter?: string;
  page?: number;
  pageSize?: number;
  refineFilters?: RefineFilter[];
  searchId?: string;
  searchQuery?: string;
  sortOption?: SortOption;
  updatedSections?: FacetSection[];
}

export interface MockFacetedSearchResponse {
  appliedFilters?: AppliedFilter[];
  facets: FacetPatch;
  metadata: {
    queryTimeMs: number;
    version: string;
    latencyMs: number;
    inventorySize: number;
    searchId: string;
  };
  pagination: {
    page: number;
    pageSize: number;
    totalResults: number;
    totalPages: number;
  };
  // Optional additional fields returned by the mock service
  smartFilters?: SmartFilterGroup[];
  totalCount: number;
  vehicles: Vehicle[];
}

export interface SmartFilterOption {
  count?: number;
  description?: string;
  display_name: string;
  value: string;
}

export interface SmartFilterGroup {
  description?: string;
  display_name: string;
  name: string;
  options?: SmartFilterOption[];
  type: string;
}

export interface AppliedFilter {
  displayText: string;
  field: string;
  value: string;
}

export interface MockFilterSearchRequest {
  filterId?: string;
  filterState: FilterState;
  labelFilter?: string;
  refineFilters?: RefineFilter[];
  searchId?: string;
  searchQuery?: string;
  updatedSections?: FacetSection[];
}

export interface MockFilterSearchResponse {
  facets: FacetPatch;
  filterId: string;
  metadata: {
    queryTimeMs: number;
    inventorySize: number;
  };
  searchId: string;
}

/** Expose the generated inventory pool for use by other services (e.g. autosuggest). */
export function getInventoryPool(): Vehicle[] {
  return inventoryPool;
}

/**
 * Convert an optional sections array into a Set, defaulting to all sections.
 */
function sectionSet(sections?: FacetSection[]): Set<FacetSection> {
  if (!sections || sections.length === 0) {
    return new Set(ALL_FACET_SECTIONS);
  }
  return new Set(sections);
}

/**
 * Build patches for available filters and facet counts for the requested sections.
 */
export function buildFacetPatch(
  availableFilters: AvailableFilters,
  facetCounts: FacetCounts,
  updatedSections: FacetSection[]
): FacetPatch {
  const selected = sectionSet(updatedSections);
  const availableFiltersPatch: Partial<AvailableFilters> = {};
  const facetCountsPatch: Partial<FacetCounts> = {};

  if (selected.has("Body Style")) {
    availableFiltersPatch.bodyStyles = availableFilters.bodyStyles;
    facetCountsPatch.bodyType = facetCounts.bodyType;
  }
  if (selected.has("Exterior Color")) {
    availableFiltersPatch.exteriorColors = availableFilters.exteriorColors;
    facetCountsPatch.exteriorColor = facetCounts.exteriorColor;
  }
  if (selected.has("Interior Color")) {
    availableFiltersPatch.interiorColors = availableFilters.interiorColors;
    facetCountsPatch.interiorColor = facetCounts.interiorColor;
  }
  if (selected.has("Fuel Type")) {
    availableFiltersPatch.fuelTypes = availableFilters.fuelTypes;
    facetCountsPatch.fuelType = facetCounts.fuelType;
  }
  if (selected.has("Make & Model")) {
    availableFiltersPatch.models = availableFilters.models;
  }
  if (selected.has("Features & Technology")) {
    availableFiltersPatch.safetyFeatures = availableFilters.safetyFeatures;
    availableFiltersPatch.comfortFeatures = availableFilters.comfortFeatures;
    availableFiltersPatch.techFeatures = availableFilters.techFeatures;
    availableFiltersPatch.exteriorFeatures = availableFilters.exteriorFeatures;
    availableFiltersPatch.performanceFeatures = availableFilters.performanceFeatures;
    availableFiltersPatch.seatingCapacity = availableFilters.seatingCapacity;
  }
  if (selected.has("Inspection")) {
    availableFiltersPatch.hasInspection160 = availableFilters.hasInspection160;
  }
  if (selected.has("Drivetrain")) {
    availableFiltersPatch.drivetrains = availableFilters.drivetrains;
    facetCountsPatch.drivetrain = facetCounts.drivetrain;
  }
  if (selected.has("Transmission")) {
    availableFiltersPatch.transmissions = availableFilters.transmissions;
    facetCountsPatch.transmission = facetCounts.transmission;
  }
  if (selected.has("Price")) {
    facetCountsPatch.priceRange = facetCounts.priceRange;
  }
  if (selected.has("Year")) {
    facetCountsPatch.yearRange = facetCounts.yearRange;
  }
  if (selected.has("Mileage")) {
    facetCountsPatch.mileageRange = facetCounts.mileageRange;
  }

  availableFiltersPatch.totalCount = Math.min(availableFilters.totalCount, inventorySize);

  return {
    availableFiltersPatch,
    facetCountsPatch,
    updatedSections,
  };
}

/**
 *  Run a mocked faceted search on the inventory and return results and metadata.
 */
export async function runMockFacetedSearch(
  req: MockFacetedSearchRequest
): Promise<MockFacetedSearchResponse> {
  const startedAt = Date.now();
  const searchId = req.searchId || crypto.randomUUID();

  const page = req.page ?? 1;
  const pageSize = req.pageSize ?? SEARCH_PAGE_SIZE;

  const searchResult = await mockSearchVehicles({
    filterState: req.filterState,
    searchQuery: req.searchQuery ?? "",
    labelFilter: req.labelFilter ?? "",
    refineFilters: req.refineFilters,
    vehicles: inventoryPool,
    sortOption: req.sortOption ?? "recommended",
    page,
    pageSize,
  });

  const includeFacets = req.includeFacets ?? true;
  const updatedSections = includeFacets ? (req.updatedSections ?? ALL_FACET_SECTIONS) : [];

  let facets: FacetPatch = {
    availableFiltersPatch: {},
    facetCountsPatch: {},
    updatedSections: [],
  };

  if (includeFacets) {
    const disjunctive = computeAvailableFiltersSync(inventoryPool, req.filterState, {
      searchQuery: req.searchQuery ?? "",
      labelFilter: req.labelFilter ?? "",
      refineFilters: req.refineFilters,
    });

    facets = buildFacetPatch(
      disjunctive.availableFilters,
      disjunctive.facetCounts,
      updatedSections
    );
  }

  const queryTimeMs = Date.now() - startedAt;
  const boundedTotalCount = Math.min(searchResult.totalCount, inventorySize);
  facets.availableFiltersPatch.totalCount = Math.min(
    facets.availableFiltersPatch.totalCount ?? boundedTotalCount,
    boundedTotalCount
  );

  return {
    vehicles: searchResult.vehicles,
    totalCount: boundedTotalCount,
    pagination: {
      page,
      pageSize,
      totalResults: boundedTotalCount,
      totalPages: Math.ceil(boundedTotalCount / pageSize),
    },
    facets,
    metadata: {
      queryTimeMs,
      version: FACET_VERSION,
      latencyMs: 0,
      inventorySize,
      searchId,
    },
    smartFilters: smartFiltersData,
    appliedFilters: [
      { field: "bodyStyle", value: "SUV", displayText: "SUV" },
      { field: "distance", value: "100", displayText: "Under 100k mi" },
    ],
  };
}

export function runMockFilterSearch(req: MockFilterSearchRequest): MockFilterSearchResponse {
  const startedAt = Date.now();
  const searchId = req.searchId || crypto.randomUUID();
  const filterId = req.filterId || crypto.randomUUID();

  const updatedSections = req.updatedSections ?? ALL_FACET_SECTIONS;

  const disjunctive = computeAvailableFiltersSync(inventoryPool, req.filterState, {
    searchQuery: req.searchQuery ?? "",
    labelFilter: req.labelFilter ?? "",
    refineFilters: req.refineFilters,
  });

  const facets = buildFacetPatch(
    disjunctive.availableFilters,
    disjunctive.facetCounts,
    updatedSections
  );

  facets.availableFiltersPatch.totalCount = Math.min(
    facets.availableFiltersPatch.totalCount ?? inventorySize,
    inventorySize
  );

  return {
    filterId,
    searchId,
    facets,
    metadata: {
      queryTimeMs: Date.now() - startedAt,
      inventorySize,
    },
  };
}
