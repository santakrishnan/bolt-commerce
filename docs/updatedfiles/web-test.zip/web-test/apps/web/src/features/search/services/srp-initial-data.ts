import { defaultFilterState } from "@features/search/components/filter-sidebar/types";
import {
  type MockFacetedSearchResponse,
  runMockFacetedSearch,
} from "@features/search/lib/mock-faceted-search";
import { cacheLife, cacheTag } from "next/cache";

// Fetch initial SRP results
export async function fetchInitialSrpResults(
  bodyType?: string,
  searchQuery?: string
): Promise<MockFacetedSearchResponse> {
  "use cache";
  cacheLife("srp");
  cacheTag("srp", bodyType ? `srp-${bodyType}` : "srp-all");

  const filterState = {
    ...defaultFilterState,
    ...(bodyType ? { selectedBodyStyles: [bodyType] } : {}),
  };

  return await runMockFacetedSearch({
    filterState,
    searchQuery: searchQuery ?? "",
    page: 1,
    pageSize: 20,
    includeFacets: false,
    sortOption: "recommended",
  });
}
