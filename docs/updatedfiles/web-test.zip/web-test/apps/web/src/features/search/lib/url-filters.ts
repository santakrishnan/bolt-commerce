import type { FilterState } from "@features/search/components/filter-sidebar/types";

export type SearchSortOption = "recommended" | "low-high" | "high-low";

interface SearchUrlState {
  filterState: FilterState;
  labelFilter: string;
  page: number;
  searchQuery: string;
  sortOption: SearchSortOption;
}

export interface ParsedSearchUrlState {
  filterState: Partial<FilterState>;
  labelFilter?: string;
  page?: number;
  searchQuery?: string;
  sortOption?: SearchSortOption;
}

/**
 * Parse a comma-separated string into a trimmed string array.
 */
function parseCsv(value: string | null): string[] {
  if (!value) {
    return [];
  }
  return value
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

/**
 * Parse a positive integer string, returning undefined if invalid.
 */
function parsePositiveInt(value: string | null): number | undefined {
  if (!value) {
    return undefined;
  }
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n : undefined;
}

/**
 * Set a URLSearchParams key to value only when the value is non-empty.
 */
function setIfValue(params: URLSearchParams, key: string, value: string) {
  if (value) {
    params.set(key, value);
  }
}

/**
 * Parse URLSearchParams into a ParsedSearchUrlState object.
 */
export function parseSearchUrlState(searchParams: URLSearchParams): ParsedSearchUrlState {
  const sort = searchParams.get("sort");
  const sortOption =
    sort === "recommended" || sort === "low-high" || sort === "high-low" ? sort : undefined;

  return {
    searchQuery: searchParams.get("q") ?? undefined,
    page: parsePositiveInt(searchParams.get("page")),
    sortOption,
    labelFilter: searchParams.get("label") ?? undefined,
    filterState: {
      selectedPriceQuick: searchParams.get("priceQuick") ?? undefined,
      selectedYearQuick: searchParams.get("yearQuick") ?? undefined,
      selectedMileage: searchParams.get("mileageQuick") ?? undefined,
      selectedBodyStyles: parseCsv(searchParams.get("bodyStyles")),
      selectedExteriorColors: parseCsv(searchParams.get("exteriorColors")),
      selectedInteriorColors: parseCsv(searchParams.get("interiorColors")),
      selectedFuelTypes: parseCsv(searchParams.get("fuelTypes")),
      selectedModels: parseCsv(searchParams.get("models")),
      selectedSafetyFeatures: parseCsv(searchParams.get("safetyFeatures")),
      selectedComfortFeatures: parseCsv(searchParams.get("comfortFeatures")),
      selectedTechFeatures: parseCsv(searchParams.get("techFeatures")),
      selectedExteriorFeatures: parseCsv(searchParams.get("exteriorFeatures")),
      selectedPerformanceFeatures: parseCsv(searchParams.get("performanceFeatures")),
      selectedSeatingCapacity: parseCsv(searchParams.get("seatingCapacity")),
      selectedDrivetrains: parseCsv(searchParams.get("drivetrains")),
      selectedTransmissions: parseCsv(searchParams.get("transmissions")),
      inspection160: searchParams.get("inspection") === "1",
    },
  };
}

/**
 * Serialize a SearchUrlState to a URL query string.
 */
export function serializeSearchUrlState(state: SearchUrlState): string {
  const params = new URLSearchParams();

  setIfValue(params, "q", state.searchQuery.trim());
  return params.toString();
}
