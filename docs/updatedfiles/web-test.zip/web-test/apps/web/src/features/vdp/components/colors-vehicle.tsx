import type React from "react";

export interface VehicleColorsProps {
  className?: string;
  exteriorName: string;
  exteriorSwatchStyle?: React.CSSProperties;
  interiorName: string;
  interiorSwatchStyle?: React.CSSProperties;
}

export const VehicleColors: React.FC<VehicleColorsProps> = ({
  exteriorName,
  interiorName,
  exteriorSwatchStyle,
  interiorSwatchStyle,
  className = "flex gap-lg lg:gap-17.5",
}) => {
  return (
    <div className={className}>
      <div className="flex items-center gap-[var(--spacing-xs)]">
        <div
          className="h-6 w-6 rounded-[var(--radius-full)] lg:h-[var(--size-swatch)] lg:w-[var(--size-swatch)]"
          style={exteriorSwatchStyle}
        />
        <div className="flex flex-col">
          <p className="font-[var(--font-weight-semibold)] text-[var(--color-states-muted-foreground)] text-[var(--font-size-2xs)] capitalize opacity-[var(--opacity-50)] lg:text-[var(--font-size-xs)]">
            Exterior
          </p>
          <span className="font-[var(--font-weight-semibold)] text-[var(--color-core-surfaces-foreground)] text-[var(--font-size-xs)] leading-normal lg:text-[var(--font-size-sm)]">
            {exteriorName}
          </span>
        </div>
      </div>
      <div className="flex items-center gap-[var(--spacing-xs)]">
        <div
          className="h-6 w-6 rounded-[var(--radius-full)] lg:h-[var(--size-swatch)] lg:w-[var(--size-swatch)]"
          style={interiorSwatchStyle}
        />
        <div className="flex flex-col">
          <p className="font-[var(--font-weight-semibold)] text-[var(--color-states-muted-foreground)] text-[var(--font-size-2xs)] capitalize opacity-[var(--opacity-50)] lg:text-[var(--font-size-xs)]">
            Interior
          </p>
          <span className="font-[var(--font-weight-semibold)] text-[var(--color-core-surfaces-foreground)] text-[var(--font-size-xs)] leading-normal lg:text-[var(--font-size-sm)]">
            {interiorName}
          </span>
        </div>
      </div>
    </div>
  );
};
