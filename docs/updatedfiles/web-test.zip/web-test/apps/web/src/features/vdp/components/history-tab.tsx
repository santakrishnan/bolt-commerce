import { ArrowInspectedSection } from "@features/landing/components/arrow-inspected";
import type { HistoryData } from "@features/vdp/data";
import { inspectionFeatures } from "@shared/data/inspection/features";
import {
  Button,
  cn,
  DamageReportIcon,
  Heading,
  NoDamageIcon,
  OdometerIcon,
  PreviousOwnersIcon,
  ServiceHistoryIcon,
  TypeOwnersIcon,
} from "@tfs-ucmp/ui";
import { HistoryStatCard } from "./history-stat-card";

const carName = "2023 Toyota HIghLander XLE 4";

interface HistoryTabProps {
  historyData: HistoryData;
}

export function HistoryTab({ historyData }: HistoryTabProps) {
  return (
    <div className="rounded-[var(--radius-lg)] pt-0">
      <div className="mb-[var(--spacing-xl)] flex flex-col justify-between gap-[var(--spacing-lg)] md:flex-row md:px-[var(--spacing-md)] lg:mb-[var(--spacing-2xl)] lg:items-stretch lg:gap-0 lg:border-b-0 lg:px-[var(--spacing-xl)] lg:pb-0">
        <div className="flex shrink-0 flex-col justify-center md:pr-[var(--spacing-lg)]">
          <Heading
            className="mb-[var(--spacing-2xs)] font-[var(--font-weight-semibold)] text-[length:var(--font-size-lg)] text-[var(--color-core-surface-foreground)] leading-heading lg:font-semibold lg:text-[length:var(--font-size-lg)] lg:leading-heading"
            level={3}
          >
            Vehicle History
          </Heading>
          <p className="font-[var(--font-weight-normal)] text-[length:var(--font-size-sm)] text-[var(--color-states-muted-foreground)] capitalize leading-normal">
            VIN:{" "}
            <span className="font-[var(--font-weight-normal)] text-[length:var(--font-size-sm)] text-[var(--color-core-surface-foreground)] leading-normal">
              {historyData.vin}
            </span>
          </p>
        </div>
        <div className="mx-[var(--spacing-sm)] hidden w-px self-stretch bg-divider lg:block" />
        <div className="flex items-center font-semibold text-[length:var(--font-size-sm)] text-body leading-normal">
          <span className="flex gap-[var(--spacing-xs)] font-[var(--font-weight-semibold)] text-[length:var(--font-size-sm)] text-[var(--color-core-surfaces-foreground)] leading-normal">
            {carName}
            <span className="font-[var(--font-weight-normal)] text-[length:var(--font-size-sm)] text-[var(--color-core-surfaces-foreground)] leading-normal">
              {historyData.vehicleDescription}
            </span>
          </span>
        </div>
        <div className="mx-[var(--spacing-sm)] hidden w-px self-stretch bg-divider lg:block" />
        <div className="flex shrink-0 items-center">
          <Button
            className={cn(
              "flex items-center justify-center gap-2.5 rounded-full border border-[var(--color-actions-tertiary-border)] bg-[var(--color-core-surfaces-background)] px-[var(--spacing-md)] py-0 text-center font-semibold text-[length:var(--font-size-sm)] text-[var(--color-core-surface-foreground)] hover:bg-transparent hover:text-inherit focus:bg-transparent active:bg-transparent lg:px-[var(--spacing-xl)]"
            )}
            variant="outline"
          >
            View Full Report
          </Button>
        </div>
      </div>
      <div className="md:px-[var(--spacing-md)] lg:px-0">
        <div className="mb-[var(--spacing-xl)] rounded-[var(--radius-xl)] bg-[var(--color-core-surfaces-card)] p-[var(--spacing-xl)] lg:mb-[var(--spacing-4xl)]">
          <div className="grid grid-cols-1 gap-x-[var(--spacing-4xl)] gap-y-[var(--spacing-xl)] md:grid-cols-2 lg:grid-cols-3">
            <HistoryStatCard
              icon={
                <span aria-label="No Damage" role="img">
                  <NoDamageIcon className="text-brand" size={24} />
                  <title>No Damage</title>
                </span>
              }
              label="No Damage"
              value={`${historyData.damageReported} Damage Reported`}
            />
            <HistoryStatCard
              icon={
                <span aria-label="Previous Owners" role="img">
                  <PreviousOwnersIcon className="text-brand" size={24} />
                  <title>Previous Owners</title>
                </span>
              }
              label="Previous Owners"
              value={`${historyData.previousOwners} Owners`}
            />
            <HistoryStatCard
              icon={
                <span aria-label="Service History" role="img">
                  <ServiceHistoryIcon className="text-brand" size={24} />
                  <title>Service History</title>
                </span>
              }
              label="Service History"
              value={`${historyData.servicesOnRecord} Services on Record`}
            />
            <HistoryStatCard
              icon={
                <span aria-label="Damage Reports" role="img">
                  <DamageReportIcon className="text-brand" size={24} />
                  <title>Damage Reports</title>
                </span>
              }
              label="Damage Reports"
              value={`${historyData.repairsReported} Repairs Reported`}
            />
            <HistoryStatCard
              icon={
                <span aria-label="Type of Owner" role="img">
                  <TypeOwnersIcon className="text-brand" size={24} />
                  <title>Type of Owner</title>
                </span>
              }
              label="Type of Owner"
              value={historyData.ownerTypes.join(", ")}
            />
            <HistoryStatCard
              icon={
                <span aria-label="Last Odometer Reading" role="img">
                  <OdometerIcon className="text-brand" size={24} />
                  <title>Last Odometer Reading</title>
                </span>
              }
              label="Last Odometer Reading"
              value={`${historyData.lastOdometerReading.toLocaleString()} Miles`}
            />
          </div>
        </div>
      </div>
      <ArrowInspectedSection
        containerClassName="md:px-[var(--spacing-md)] lg:px-0"
        inspectionFeatures={inspectionFeatures}
        titleClassName="font-[var(--font-weight-semibold)] text-[length:var(--text-xl)] text-[var(--color-core-surface-foreground)] leading-heading lg:font-semibold lg:text-[length:var(--font-size-lg)] lg:leading-heading"
      />
    </div>
  );
}
