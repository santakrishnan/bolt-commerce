import { AppButton } from "@shared/components/button";
import { StarIcon } from "@tfs-ucmp/ui";

interface RatingDistribution {
  count: number;
  id: string;
  stars: number;
}

interface VehicleRatingProps {
  distribution: RatingDistribution[];
  rating: number;
  reviewCount: number;
  title: string;
}

export function VehicleRating({ title, rating, reviewCount, distribution }: VehicleRatingProps) {
  const maxCount = 500;
  return (
    <div className="flex w-full flex-col gap-[var(--spacing-10)] p-[var(--spacing-lg)] lg:flex-row lg:items-center lg:gap-[var(--spacing-xs)]">
      <div className="flex flex-col items-center md:min-w-[421px] lg:items-start">
        <div className="mb-[var(--spacing-sm)] font-[var(--font-weight-semibold)] text-[length:var(--font-size-md)]">
          {title}
        </div>
        <div className="mb-[var(--spacing-sm)] flex items-center gap-[var(--spacing-md)]">
          <span className="font-[var(--font-weight-semibold)] text-[length:var(--text-4xl)]">
            {rating.toFixed(1)}
          </span>
          <div
            aria-label={`${rating.toFixed(1)} out of 5 stars`}
            className="ml-[var(--spacing-xs)] flex gap-[var(--spacing-xs)]"
            role="img"
          >
            {[1, 2, 3, 4, 5].map((i) => (
              <StarIcon
                className={`h-[var(--spacing-5)] w-[var(--spacing-5)] ${i <= Math.round(rating) ? "text-foreground" : "text-[var(--color-border)]"}`}
                fill={i <= Math.round(rating) ? "currentColor" : "none"}
                key={i}
                size={20}
              />
            ))}
          </div>
        </div>
        <AppButton size="md" variant="tertiary">
          View More ({reviewCount} Reviews)
        </AppButton>
      </div>
      <div className="w-full flex-1">
        <div className="flex flex-col gap-[var(--spacing-xs)]">
          {distribution.map((d, _idx) => (
            <div className="flex items-center gap-[var(--spacing-md)]" key={d.stars}>
              <span
                className="w-[var(--spacing-2xl)] text-right font-[var(--font-weight-normal)] text-[length:var(--text-xs)] lg:text-[length:var(--text-sm)]"
                id={`rating-bar-${d.stars}`}
              >
                {d.stars} stars
              </span>
              <progress
                aria-labelledby={`rating-bar-${d.stars}`}
                className="h-[var(--spacing-xs)] flex-1 appearance-none rounded-[var(--radius-md)] [&::-moz-progress-bar]:rounded-[var(--radius-md)] [&::-moz-progress-bar]:bg-[var(--color-actions-primary)] [&::-webkit-progress-bar]:rounded-[var(--radius-md)] [&::-webkit-progress-bar]:bg-[var(--color-background-grey)] [&::-webkit-progress-value]:rounded-[var(--radius-md)] [&::-webkit-progress-value]:bg-[var(--color-actions-primary)]"
                max={maxCount}
                value={d.count ?? 0}
              />
              <span className="w-[var(--spacing-10)] text-left font-[var(--font-weight-normal)] text-[length:var(--text-xs)] text-body-muted lg:text-[length:var(--text-sm)]">
                {d.count}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
