import type {
  AvailableFilters,
  FilterState,
} from "@features/search/components/filter-sidebar/types";
import {
  changedFacetSections,
  listEqual,
  mergeUniqueSections,
} from "@features/search/lib/facet-utils";
import type { AppliedFilter, SmartFilterGroup } from "@features/search/lib/mock-faceted-search";
import { ALL_FACET_SECTIONS, type FacetSection } from "@features/search/lib/mock-faceted-search";
import type { FacetCounts, RefineFilter } from "@features/search/lib/mock-search-service";
import type { Vehicle } from "@features/search/lib/mock-vehicles";
import { useCallback, useEffect, useRef, useState, useTransition } from "react";
import type { RefineSearchFilter, SearchProviderProps } from "./search-context-types";

const ARRAY_APPLIED_FILTER_FIELDS = {
  bodyStyle: "selectedBodyStyles",
  comfortFeature: "selectedComfortFeatures",
  drivetrain: "selectedDrivetrains",
  exteriorColor: "selectedExteriorColors",
  exteriorFeature: "selectedExteriorFeatures",
  fuelType: "selectedFuelTypes",
  interiorColor: "selectedInteriorColors",
  model: "selectedModels",
  performanceFeature: "selectedPerformanceFeatures",
  safetyFeature: "selectedSafetyFeatures",
  seatingCapacity: "selectedSeatingCapacity",
  techFeature: "selectedTechFeatures",
  transmission: "selectedTransmissions",
} as const;

const SCALAR_APPLIED_FILTER_FIELDS = {
  distance: "selectedMileage",
  mileage_condition: "selectedMileage",
  price: "selectedPriceQuick",
  year: "selectedYearQuick",
} as const;

function appendUnique(values: string[] | undefined, value: string): string[] {
  return Array.from(new Set([...(values ?? []), value]));
}

function mergeAppliedIntoFilterState(base: FilterState, applied: AppliedFilter[]): FilterState {
  let next: FilterState = { ...base };

  for (const a of applied) {
    const arrayKey =
      ARRAY_APPLIED_FILTER_FIELDS[a.field as keyof typeof ARRAY_APPLIED_FILTER_FIELDS];
    if (arrayKey) {
      next = {
        ...next,
        [arrayKey]: appendUnique(next[arrayKey], a.value),
      } as FilterState;
      continue;
    }

    const scalarKey =
      SCALAR_APPLIED_FILTER_FIELDS[a.field as keyof typeof SCALAR_APPLIED_FILTER_FIELDS];
    if (scalarKey) {
      next = {
        ...next,
        [scalarKey]: a.displayText ?? a.value,
      } as FilterState;
      continue;
    }

    if (a.field === "inspection160") {
      next = {
        ...next,
        inspection160: a.value === "true" || a.value === "1" || a.displayText === "true",
      };
    }
  }

  return next;
}

/** Build the signature string used to deduplicate applied-filter merges. */
function appliedFilterSignature(applied: AppliedFilter[]): string {
  return applied
    .map((a) => `${a.field}:${a.value}`)
    .sort()
    .join("|");
}

export function useSearchState({
  defaultFilterState,
  initialAppliedFilters = [],
  initialBodyStyles = [],
  initialSearchQuery = "",
  initialUrlFilters,
  initialVehicles = [],
  initialTotalCount = 0,
}: Omit<SearchProviderProps, "children">) {
  const [sortOption, setSortOption] = useState<"recommended" | "low-high" | "high-low">(
    "recommended"
  );
  const [vehiclePool, setVehiclePool] = useState<Vehicle[]>(initialVehicles);

  const [filterState, setFilterState] = useState<FilterState>(() => {
    const base: FilterState = {
      ...defaultFilterState,
      ...initialUrlFilters,
      ...(initialBodyStyles.length > 0 ? { selectedBodyStyles: initialBodyStyles } : {}),
    };
    return initialAppliedFilters.length > 0
      ? mergeAppliedIntoFilterState(base, initialAppliedFilters)
      : base;
  });
  const [searchQuery, setSearchQuery] = useState(initialSearchQuery);
  const searchQueryRef = useRef(initialSearchQuery);
  const [labelFilter, setLabelFilter] = useState("");
  const [refineSearchFilters, setRefineSearchFilters] = useState<RefineSearchFilter[]>([]);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [progress, setProgress] = useState(0);
  const [isProgressVisible, setIsProgressVisible] = useState(false);
  const progressTimers = useRef<number[]>([]);
  const [availableFilters, setAvailableFilters] = useState<AvailableFilters>({
    bodyStyles: [],
    exteriorColors: [],
    interiorColors: [],
    fuelTypes: [],
    models: [],
    safetyFeatures: [],
    comfortFeatures: [],
    techFeatures: [],
    exteriorFeatures: [],
    performanceFeatures: [],
    seatingCapacity: [],
    hasInspection160: false,
    drivetrains: [],
    transmissions: [],
    totalCount: 0,
  });
  const [facetCounts, setFacetCounts] = useState<FacetCounts>({
    bodyType: {},
    exteriorColor: {},
    interiorColor: {},
    fuelType: {},
    drivetrain: {},
    transmission: {},
    priceRange: { min: 0, max: 0 },
    yearRange: { min: 0, max: 0 },
    mileageRange: { min: 0, max: 0 },
  });
  const [totalCount, setTotalCount] = useState<number>(initialTotalCount);
  const [pendingFacetSections, setPendingFacetSections] =
    useState<FacetSection[]>(ALL_FACET_SECTIONS);
  const [loadingFacetSections, setLoadingFacetSections] =
    useState<FacetSection[]>(ALL_FACET_SECTIONS);
  const [smartFilters, setSmartFilters] = useState<SmartFilterGroup[]>([]);
  const [appliedFilters, setAppliedFilters] = useState<AppliedFilter[]>([]);
  const [searchId, setSearchId] = useState("");
  const [filterId, setFilterId] = useState("");

  const [, startFilterTransition] = useTransition();

  const applyFiltersSearch = useCallback(
    (
      newFilterState: FilterState,
      opts?: {
        searchQuery?: string;
        labelFilter?: string;
        refineFilters?: RefineFilter[];
        preservePage?: boolean;
      }
    ) => {
      const nextSearchQuery = opts?.searchQuery ?? searchQueryRef.current;
      const nextLabelFilter = opts?.labelFilter ?? labelFilter;
      let nextRefineFilters: RefineFilter[];
      if (opts?.refineFilters === undefined) {
        nextRefineFilters = refineSearchFilters;
      } else {
        const uniq: RefineFilter[] = [];
        for (const f of opts.refineFilters) {
          if (!uniq.some((u) => u.id === f.id)) {
            uniq.push(f);
          }
        }
        nextRefineFilters = uniq;
      }

      const sections = changedFacetSections(filterState, newFilterState, {
        queryChanged: nextSearchQuery !== searchQuery,
        labelChanged: nextLabelFilter !== labelFilter,
        refineChanged:
          opts?.refineFilters !== undefined ||
          !listEqual(
            refineSearchFilters.map((f) => f.id),
            nextRefineFilters.map((f) => f.id)
          ),
      });

      const changedSections = sections.length > 0 ? sections : [];

      if (nextSearchQuery !== searchQuery) {
        setSearchId("");
        setFilterId("");
      }

      startFilterTransition(() => {
        setFilterState(newFilterState);
        setSearchQuery(nextSearchQuery);
        searchQueryRef.current = nextSearchQuery;
        setLabelFilter(nextLabelFilter);
        setRefineSearchFilters(nextRefineFilters);
        if (!opts?.preservePage) {
          setCurrentPage(1);
        }

        setPendingFacetSections((prev) => mergeUniqueSections(prev, changedSections));
        setLoadingFacetSections((prev) => mergeUniqueSections(prev, changedSections));
      });

      return Promise.resolve();
    },
    [filterState, searchQuery, labelFilter, refineSearchFilters]
  );

  const appliedMergedRef = useRef<string>(
    initialAppliedFilters.length > 0 ? appliedFilterSignature(initialAppliedFilters) : ""
  );
  useEffect(() => {
    if (!appliedFilters || appliedFilters.length === 0) {
      appliedMergedRef.current = "";
      return;
    }

    const signature = appliedFilterSignature(appliedFilters);
    if (signature === appliedMergedRef.current) {
      return;
    }
    appliedMergedRef.current = signature;

    const nextState = mergeAppliedIntoFilterState(filterState, appliedFilters);

    // Apply merged filters into the active search state (preserve other refinements)
    // eslint-disable-next-line @typescript-eslint/no-floating-promises
    applyFiltersSearch(nextState, { refineFilters: refineSearchFilters });
  }, [appliedFilters, applyFiltersSearch, filterState, refineSearchFilters]);

  const handleSearch = useCallback(() => {
    for (const timer of progressTimers.current) {
      clearTimeout(timer);
    }
    progressTimers.current = [];

    setIsProgressVisible(false);
    setProgress(0);

    progressTimers.current.push(
      window.setTimeout(() => {
        setIsProgressVisible(true);
        setProgress(0);
      }, 16) as unknown as number,
      window.setTimeout(() => setProgress(78), 20) as unknown as number,
      window.setTimeout(() => setProgress(100), 850) as unknown as number,
      window.setTimeout(() => {
        setIsProgressVisible(false);
      }, 1200) as unknown as number
    );
  }, []);

  return {
    sortOption,
    setSortOption,
    vehiclePool,
    setVehiclePool,
    filterState,
    setFilterState,
    searchQuery,
    setSearchQuery,
    searchQueryRef,
    labelFilter,
    setLabelFilter,
    refineSearchFilters,
    setRefineSearchFilters,
    isFilterOpen,
    setIsFilterOpen,
    currentPage,
    setCurrentPage,
    progress,
    setProgress,
    isProgressVisible,
    setIsProgressVisible,
    availableFilters,
    setAvailableFilters,
    facetCounts,
    setFacetCounts,
    totalCount,
    setTotalCount,
    pendingFacetSections,
    setPendingFacetSections,
    loadingFacetSections,
    setLoadingFacetSections,
    smartFilters,
    setSmartFilters,
    appliedFilters,
    setAppliedFilters,
    searchId,
    setSearchId,
    filterId,
    setFilterId,
    handleSearch,
    applyFiltersSearch,
  } as const;
}
