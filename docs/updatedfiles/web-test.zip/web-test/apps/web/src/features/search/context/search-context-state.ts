import type {
  AvailableFilters,
  FilterState,
} from "@features/search/components/filter-sidebar/types";
import {
  changedFacetSections,
  listEqual,
  mergeUniqueSections,
} from "@features/search/lib/facet-utils";
import type { AppliedFilter, SmartFilterGroup } from "@features/search/lib/mock-faceted-search";
import { ALL_FACET_SECTIONS, type FacetSection } from "@features/search/lib/mock-faceted-search";
import type { FacetCounts, RefineFilter } from "@features/search/lib/mock-search-service";
import type { Vehicle } from "@features/search/lib/mock-vehicles";
import { useCallback, useEffect, useRef, useState, useTransition } from "react";
import type { RefineSearchFilter, SearchProviderProps } from "./search-context-types";

export function useSearchState({
  defaultFilterState,
  initialBodyStyles = [],
  initialSearchQuery = "",
  initialUrlFilters,
  initialVehicles = [],
  initialTotalCount = 0,
}: Omit<SearchProviderProps, "children">) {
  const [sortOption, setSortOption] = useState<"recommended" | "low-high" | "high-low">(
    "recommended"
  );
  const [vehiclePool, setVehiclePool] = useState<Vehicle[]>(initialVehicles);
  const [filterState, setFilterState] = useState<FilterState>({
    ...defaultFilterState,
    ...initialUrlFilters,
    ...(initialBodyStyles.length > 0 ? { selectedBodyStyles: initialBodyStyles } : {}),
  });
  const [searchQuery, setSearchQuery] = useState(initialSearchQuery);
  const searchQueryRef = useRef(initialSearchQuery);
  const [labelFilter, setLabelFilter] = useState("");
  const [refineSearchFilters, setRefineSearchFilters] = useState<RefineSearchFilter[]>([]);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [progress, setProgress] = useState(0);
  const [isProgressVisible, setIsProgressVisible] = useState(false);
  const progressTimers = useRef<number[]>([]);
  const [availableFilters, setAvailableFilters] = useState<AvailableFilters>({
    bodyStyles: [],
    exteriorColors: [],
    interiorColors: [],
    fuelTypes: [],
    models: [],
    safetyFeatures: [],
    comfortFeatures: [],
    techFeatures: [],
    exteriorFeatures: [],
    performanceFeatures: [],
    seatingCapacity: [],
    hasInspection160: false,
    drivetrains: [],
    transmissions: [],
    totalCount: 0,
  });
  const [facetCounts, setFacetCounts] = useState<FacetCounts>({
    bodyType: {},
    exteriorColor: {},
    interiorColor: {},
    fuelType: {},
    drivetrain: {},
    transmission: {},
    priceRange: { min: 0, max: 0 },
    yearRange: { min: 0, max: 0 },
    mileageRange: { min: 0, max: 0 },
  });
  const [totalCount, setTotalCount] = useState<number>(initialTotalCount);
  const [pendingFacetSections, setPendingFacetSections] =
    useState<FacetSection[]>(ALL_FACET_SECTIONS);
  const [loadingFacetSections, setLoadingFacetSections] =
    useState<FacetSection[]>(ALL_FACET_SECTIONS);
  const [smartFilters, setSmartFilters] = useState<SmartFilterGroup[]>([]);
  const [appliedFilters, setAppliedFilters] = useState<AppliedFilter[]>([]);
  const [searchId, setSearchId] = useState("");
  const [filterId, setFilterId] = useState("");

  const [, startFilterTransition] = useTransition();

  const applyFiltersSearch = useCallback(
    (
      newFilterState: FilterState,
      opts?: {
        searchQuery?: string;
        labelFilter?: string;
        refineFilters?: RefineFilter[];
        preservePage?: boolean;
      }
    ) => {
      const nextSearchQuery = opts?.searchQuery ?? searchQueryRef.current;
      const nextLabelFilter = opts?.labelFilter ?? labelFilter;
      let nextRefineFilters: RefineFilter[];
      if (opts?.refineFilters === undefined) {
        nextRefineFilters = refineSearchFilters;
      } else {
        const uniq: RefineFilter[] = [];
        for (const f of opts.refineFilters) {
          if (!uniq.some((u) => u.id === f.id)) {
            uniq.push(f);
          }
        }
        nextRefineFilters = uniq;
      }

      const sections = changedFacetSections(filterState, newFilterState, {
        queryChanged: nextSearchQuery !== searchQuery,
        labelChanged: nextLabelFilter !== labelFilter,
        refineChanged:
          opts?.refineFilters !== undefined ||
          !listEqual(
            refineSearchFilters.map((f) => f.id),
            nextRefineFilters.map((f) => f.id)
          ),
      });

      const changedSections = sections.length > 0 ? sections : [];

      if (nextSearchQuery !== searchQuery) {
        setSearchId("");
        setFilterId("");
      }

      startFilterTransition(() => {
        setFilterState(newFilterState);
        setSearchQuery(nextSearchQuery);
        searchQueryRef.current = nextSearchQuery;
        setLabelFilter(nextLabelFilter);
        setRefineSearchFilters(nextRefineFilters);
        if (!opts?.preservePage) {
          setCurrentPage(1);
        }

        setPendingFacetSections((prev) => mergeUniqueSections(prev, changedSections));
        setLoadingFacetSections((prev) => mergeUniqueSections(prev, changedSections));
      });

      return Promise.resolve();
    },
    [filterState, searchQuery, labelFilter, refineSearchFilters]
  );

  // When the server provides appliedFilters, merge them into the active filter state
  // so they behave like selected smart filters by default.
  const appliedMergedRef = useRef<string>("");
  useEffect(() => {
    if (!appliedFilters || appliedFilters.length === 0) {
      appliedMergedRef.current = "";
      return;
    }

    const signature = appliedFilters
      .map((a) => `${a.field}:${a.value}`)
      .sort()
      .join("|");
    if (signature === appliedMergedRef.current) {
      return;
    }
    appliedMergedRef.current = signature;

    let nextState: FilterState = { ...filterState };

    for (const a of appliedFilters) {
      switch (a.field) {
        case "model": {
          const nextModels = Array.from(new Set([...(nextState.selectedModels || []), a.value]));
          nextState = { ...nextState, selectedModels: nextModels };
          break;
        }
        case "bodyStyle": {
          const nextBodyStyles = Array.from(
            new Set([...(nextState.selectedBodyStyles || []), a.value])
          );
          nextState = { ...nextState, selectedBodyStyles: nextBodyStyles };
          break;
        }
        case "distance": {
          // distance is represented as a quick mileage selection in the UI
          // prefer displayText if available (matches MILEAGE labels), fall back to value
          nextState = { ...nextState, selectedMileage: a.displayText ?? a.value };
          break;
        }
        case "mileage_condition": {
          nextState = { ...nextState, selectedMileage: a.displayText ?? a.value };
          break;
        }
        default:
          break;
      }
    }

    // Apply merged filters into the active search state (preserve other refinements)
    // eslint-disable-next-line @typescript-eslint/no-floating-promises
    applyFiltersSearch(nextState, { refineFilters: refineSearchFilters });
  }, [appliedFilters, applyFiltersSearch, filterState, refineSearchFilters]);

  const handleSearch = useCallback(() => {
    for (const timer of progressTimers.current) {
      clearTimeout(timer);
    }
    progressTimers.current = [];

    setIsProgressVisible(false);
    setProgress(0);

    progressTimers.current.push(
      window.setTimeout(() => {
        setIsProgressVisible(true);
        setProgress(0);
      }, 16) as unknown as number,
      window.setTimeout(() => setProgress(78), 20) as unknown as number,
      window.setTimeout(() => setProgress(100), 850) as unknown as number,
      window.setTimeout(() => {
        setIsProgressVisible(false);
      }, 1200) as unknown as number
    );
  }, []);

  return {
    sortOption,
    setSortOption,
    vehiclePool,
    setVehiclePool,
    filterState,
    setFilterState,
    searchQuery,
    setSearchQuery,
    searchQueryRef,
    labelFilter,
    setLabelFilter,
    refineSearchFilters,
    setRefineSearchFilters,
    isFilterOpen,
    setIsFilterOpen,
    currentPage,
    setCurrentPage,
    progress,
    setProgress,
    isProgressVisible,
    setIsProgressVisible,
    availableFilters,
    setAvailableFilters,
    facetCounts,
    setFacetCounts,
    totalCount,
    setTotalCount,
    pendingFacetSections,
    setPendingFacetSections,
    loadingFacetSections,
    setLoadingFacetSections,
    smartFilters,
    setSmartFilters,
    appliedFilters,
    setAppliedFilters,
    searchId,
    setSearchId,
    filterId,
    setFilterId,
    handleSearch,
    applyFiltersSearch,
  } as const;
}
