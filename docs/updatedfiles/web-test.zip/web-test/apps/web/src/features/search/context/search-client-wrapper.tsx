"use client";

import type { SearchClientProps } from "./search-client";
import { SearchClient } from "./search-client";

export default function SearchClientWrapper(props: SearchClientProps) {
  return <SearchClient {...props} />;
}
