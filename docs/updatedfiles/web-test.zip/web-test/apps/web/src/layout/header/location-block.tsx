"use client";

import { ZIP_RE } from "@config/routes/constants";
import { useBodyScrollLock } from "@shared/hooks/use-body-scroll-lock";
import { useEscapeKey } from "@shared/hooks/use-escape-key";
import { useOutsideClick } from "@shared/hooks/use-outside-click";
import { useLocation } from "@shared/providers/location-provider";
import { Button, MapPinIcon } from "@tfs-ucmp/ui";
import Image from "next/image";
import { type JSX, useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { cn } from "@/lib/utils";

/**
 * Location picker that shows current location.
 * A modal to update zip.
 */
export function LocationBlock({
  useSolidStyles,
  onModalOpenChange,
}: {
  useSolidStyles: boolean;
  onModalOpenChange?: (open: boolean) => void;
}): JSX.Element | null {
  const { state: locationState, actions } = useLocation();
  const [modalOpen, setModalOpen] = useState(false);
  const [zipInput, setZipInput] = useState("");
  const [zipError, setZipError] = useState("");
  const inputRef = useRef<HTMLInputElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const { displayZip, displayCity, displayState, isManualZip, description, isResolved } =
    locationState;

  useEffect(() => {
    onModalOpenChange?.(modalOpen);
  }, [modalOpen, onModalOpenChange]);

  useEffect(() => {
    if (modalOpen) {
      setZipInput("");
      setZipError("");
      requestAnimationFrame(() => {
        inputRef.current?.focus();
      });
    }
  }, [modalOpen]);

  useEscapeKey(() => {
    if (modalOpen) {
      setModalOpen(false);
    }
  });
  useOutsideClick(containerRef, () => {
    if (modalOpen) {
      setModalOpen(false);
    }
  });
  useBodyScrollLock(modalOpen);

  const handleToggle = useCallback(() => setModalOpen((s) => !s), []);

  const handleUpdate = useCallback(() => {
    const clean = zipInput.trim();
    if (!ZIP_RE.test(clean)) {
      setZipError("Please enter a valid 5-digit zip code.");
      return;
    }
    setZipError("");
    actions.setZip(clean);
    setModalOpen(false);
  }, [zipInput, actions]);

  const handleUseDeviceLocation = useCallback(() => {
    actions.clearManualZip();
    setModalOpen(false);
  }, [actions]);

  if (!isResolved) {
    return null;
  }

  let triggerLabel = displayZip;

  if (isManualZip && description) {
    triggerLabel = description;
  } else if (displayCity && displayState) {
    triggerLabel = `${displayCity}, ${displayState} ${displayZip}`;
  } else if (displayCity) {
    triggerLabel = `${displayCity} ${displayZip}`;
  } else if (displayState) {
    triggerLabel = `${displayState} ${displayZip}`;
  }

  return (
    <div className="flex items-center gap-1 text-sm">
      <MapPinIcon
        className={cn("h-4.5 w-4.5 text-[var(--color-actions-primary)] transition-colors")}
      />
      <div className="relative inline-block" ref={containerRef}>
        {modalOpen &&
          createPortal(
            <div aria-hidden="true" className="fixed inset-0 z-[34] bg-black/40" />,
            document.body
          )}
        <button
          aria-expanded={modalOpen}
          aria-haspopup="dialog"
          className={`inline-flex cursor-pointer items-center gap-1.5 border-none bg-transparent font-normal text-sm leading-none outline-none hover:underline hover:underline-offset-4 ${
            useSolidStyles ? "text-text-dark" : "text-white"
          }`}
          onClick={handleToggle}
          type="button"
        >
          <span aria-live="polite">{triggerLabel}</span>
          <Image
            alt=""
            className={`transition-transform ${modalOpen ? "rotate-180" : ""} ${useSolidStyles ? "[filter:brightness(0)]" : ""}`}
            height={6}
            src="/images/caret-location.svg"
            width={10}
          />
        </button>

        {modalOpen && (
          <div
            aria-labelledby="location-dialog-title"
            aria-modal="true"
            className="absolute top-full left-0 z-50 mt-10 w-[min(96vw,20rem)] rounded bg-white px-4 py-4 lg:left-1/2 lg:w-104 lg:-translate-x-1/2"
            role="dialog"
          >
            <div className="pointer-events-none absolute -top-2 left-1/2 -translate-x-1/2">
              <Image alt="" height={16} src="/images/triangle.svg" width={24} />
            </div>

            <div className="px-4 pt-4">
              <h3
                className="font-normal text-[length:var(--Font-Size-Scale---font-size-sm,14px)] text-[var(--color-states-muted-foreground,#525252)] leading-[125%] tracking-[-0.14px] [font-family:var(--font-family)] [leading-trim:both] [text-edge:cap]"
                id="location-dialog-title"
              >
                Update Your Location
              </h3>
            </div>

            <div className="px-4 py-2">
              <label className="sr-only" htmlFor="location-zip">
                Enter zip code
              </label>
              <input
                autoComplete="postal-code"
                className="flex h-[var(--spacing-2xl,48px)] w-full items-center gap-[var(--spacing-xs,8px)] self-stretch rounded bg-core-surfaces-background px-[var(--spacing-md,16px)] text-[length:var(--Font-Size-Scale---font-size-sm,14px)] outline-none [font-family:var(--font-family)]"
                id="location-zip"
                inputMode="numeric"
                maxLength={5}
                onChange={(e) => {
                  setZipInput(e.target.value.replace(/\D/g, ""));
                  setZipError("");
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleUpdate();
                  }
                }}
                pattern="[0-9]{5}"
                placeholder="Enter zip code"
                ref={inputRef}
                type="text"
                value={zipInput}
              />
              {zipError && <p className="mt-1 text-red-500 text-xs">{zipError}</p>}

              <Button className="mt-4 w-full rounded-full bg-primary" onClick={handleUpdate}>
                Update
              </Button>

              {isManualZip && (
                <Button
                  className="mt-2 w-full rounded-full border border-gray-300 bg-white text-gray-700 hover:bg-gray-50 hover:text-gray-900"
                  onClick={handleUseDeviceLocation}
                  variant="outline"
                >
                  Use Device Location
                </Button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
