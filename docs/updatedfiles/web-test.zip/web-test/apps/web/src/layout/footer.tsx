import { socialLinks } from "@shared/data/footer/footer-links";
import { FooterBottom } from "./footer/footer-bottom";
import { FooterNavigation } from "./footer/footer-navigation";
import { FooterTop } from "./footer/footer-top";

const FOOTER_BRAND_NAME = "Arrow";
const FOOTER_BRAND_TAGLINE = "Your trusted partner for quality pre-owned vehicles";

/**
 * Footer - Main footer component
 * Combines all footer sections with dark theme
 */
export function Footer() {
  return (
    <div className="w-full bg-[var(--core-surfaces-foreground)]">
      <div className="mx-auto max-w-[var(--container-2xl)] px-4 sm:px-6 lg:px-20">
        <footer className="font-toyota text-[var(--states-inverse-muted-foreground)]">
          <div className="flex w-full flex-col py-12">
            <div className="grid w-full grid-cols-1 gap-[32px] border-[var(--structure-interaction-inverse-border)] border-b pb-[40px] md:grid-cols-5">
              <div className="min-w-0">
                <FooterTop
                  brandName={FOOTER_BRAND_NAME}
                  socialLinks={socialLinks}
                  tagline={FOOTER_BRAND_TAGLINE}
                />
              </div>
              <FooterNavigation />
            </div>

            <div className="flex w-full flex-row gap-[32px] border-[var(--structure-interaction-inverse-border)] border-b py-[32px] md:grid md:grid-cols-3">
              <FooterBottom section="contact" />
            </div>

            <div className="w-full pt-[24px]">
              <FooterBottom section="copyright" />
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
