import { render, screen } from "@arrow/vitest-config/test-utils";
import type { ReactNode } from "react";
import { describe, expect, it, vi } from "vitest";

import { HeaderNav } from "../header-nav";

vi.mock("next/link", () => ({
  default: ({
    href,
    className,
    children,
  }: {
    href: string;
    className?: string;
    children: ReactNode;
  }) => (
    <a className={className} href={href}>
      {children}
    </a>
  ),
}));

const NAV_LINKS = ["Buy", "Finance", "Why Arrow"] as const;
const NAV_HREFS: Record<(typeof NAV_LINKS)[number], string> = {
  Buy: "/used-cars",
  Finance: "/finance",
  "Why Arrow": "/about",
};

describe("HeaderNav", () => {
  describe("rendered structure", () => {
    it("renders a <nav> landmark", () => {
      render(<HeaderNav useSolidStyles={false} />);

      expect(screen.getByRole("navigation")).toBeInTheDocument();
    });

    it("renders exactly three navigation links", () => {
      render(<HeaderNav useSolidStyles={false} />);

      expect(screen.getAllByRole("link")).toHaveLength(3);
    });

    it.each(NAV_LINKS)('renders "%s" link', (name) => {
      render(<HeaderNav useSolidStyles={false} />);

      expect(screen.getByRole("link", { name })).toBeInTheDocument();
    });

    it.each(NAV_LINKS)('"%s" link points to the expected route', (name) => {
      render(<HeaderNav useSolidStyles={false} />);

      expect(screen.getByRole("link", { name })).toHaveAttribute("href", NAV_HREFS[name]);
    });
  });

  describe("when useSolidStyles is true (solid / dark header)", () => {
    it("applies text-text-dark to every link", () => {
      render(<HeaderNav useSolidStyles={true} />);

      for (const link of screen.getAllByRole("link")) {
        expect(link).toHaveClass("text-text-dark");
      }
    });

    it("does NOT apply text-white to any link", () => {
      render(<HeaderNav useSolidStyles={true} />);

      for (const link of screen.getAllByRole("link")) {
        expect(link).not.toHaveClass("text-white");
      }
    });
  });

  describe("when useSolidStyles is false (transparent / light header)", () => {
    it("applies text-white to every link", () => {
      render(<HeaderNav useSolidStyles={false} />);

      for (const link of screen.getAllByRole("link")) {
        expect(link).toHaveClass("text-white");
      }
    });

    it("does NOT apply text-text-dark to any link", () => {
      render(<HeaderNav useSolidStyles={false} />);

      for (const link of screen.getAllByRole("link")) {
        expect(link).not.toHaveClass("text-text-dark");
      }
    });
  });

  describe("static Tailwind classes applied regardless of useSolidStyles", () => {
    it.each([
      true,
      false,
    ])("links carry base typography classes when useSolidStyles=%s", (useSolidStyles) => {
      render(<HeaderNav useSolidStyles={useSolidStyles} />);

        for (const link of screen.getAllByRole("link")) {
        expect(link).toHaveClass("font-normal");
        expect(link).toHaveClass("text-sm");
        expect(link).toHaveClass("leading-[125%]");
      }
    });
  });

  describe("shared font-family class", () => {
    it.each([
      true,
      false,
    ])("links include the toyota-type class when useSolidStyles=%s", (useSolidStyles) => {
      render(<HeaderNav useSolidStyles={useSolidStyles} />);

      for (const link of screen.getAllByRole("link")) {
        expect(link).toHaveClass("[font-family:var(--font-toyota-type)]");
      }
    });
  });
});
