import type { Metadata } from "next";
import { cookies } from "next/headers";
import { Suspense } from "react";
import "./globals.css";
import { toyotaType } from "@config/fonts";
import { MANUAL_ZIP_COOKIE, ZIP_RE } from "@config/routes/constants";
import { FavoritesProvider } from "@features/favorites";
import { SearchHistoryProvider } from "@features/search";
import { ArrowProvider } from "@features/tracking";
import { Footer } from "@layout/footer";
import { Header } from "@layout/header";
import { FeatureFlagDebug } from "@shared/components/feature-flag-debug";
import { composeProviders } from "@shared/providers/compose-providers";
import { LocationProvider } from "@shared/providers/location-provider";
import { QueryProvider } from "@shared/providers/query-provider";
import { ThemeProvider } from "@tfs-ucmp/shared/providers";

export const metadata: Metadata = {
  title: "Arrow - Modern E-commerce",
  description: "Arrow - Modern E-commerce",
};

const SyncProviders = composeProviders(
  ThemeProvider,
  ArrowProvider,
  QueryProvider,
  SearchHistoryProvider,
  FavoritesProvider
);

// Reads the manual zip cookie and passes it to LocationProvider so the first
// paint uses the correct location without a client-side flash.
async function LocationInit({ children }: { children: React.ReactNode }) {
  const cookieStore = await cookies();
  const savedZip = cookieStore.get(MANUAL_ZIP_COOKIE)?.value;
  const initialZip = savedZip && ZIP_RE.test(savedZip) ? savedZip : null;

  return (
    <LocationProvider initialZip={initialZip}>
      <Header />
      {children}
    </LocationProvider>
  );
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html className={toyotaType.variable} lang="en" suppressHydrationWarning>
      {/* flex flex-col + min-h-screen spacer fallback keeps Footer below the fold
          while LocationInit resolves, preventing it from flashing at the top. */}
      <body className="flex min-h-screen flex-col">
        <SyncProviders>
          <Suspense fallback={<div className="min-h-screen" />}>
            <LocationInit>{children}</LocationInit>
          </Suspense>
        </SyncProviders>
        <Footer />
        {process.env.NODE_ENV !== "production" && (
          <Suspense fallback={null}>
            <FeatureFlagDebug />
          </Suspense>
        )}
      </body>
    </html>
  );
}
