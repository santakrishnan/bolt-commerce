/**
 * @vitest-environment jsdom
 */
import { fireEvent, render, screen } from "@arrow/vitest-config/test-utils";
import { describe, expect, it, vi } from "vitest";
import UsedCarsError from "../error";

// Mock the usedCarsMessages.segmentError to match the actual UI
vi.mock("@config/messages/used-cars", () => ({
  usedCarsMessages: {
    segmentError: {
      title: "Something went wrong",
      description: "We couldn't load the vehicle information. Please try again.",
      retryCta: "Try again",
    },
  },
}));

describe("UsedCarsError", () => {
  it("renders error title, description, and retry button", () => {
    const reset = vi.fn();
    render(<UsedCarsError error={new Error("fail")} reset={reset} />);
    expect(screen.getByText("Something went wrong")).toBeInTheDocument();
    expect(
      screen.getByText("We couldn't load the vehicle information. Please try again.")
    ).toBeInTheDocument();
    expect(screen.getByText("Try again")).toBeInTheDocument();
    fireEvent.click(screen.getByText("Try again"));
    expect(reset).toHaveBeenCalled();
  });
});
