import { customerPreQualified, getUserInfo, showPersonalizedHeroBanner } from "@config/flags/flags";
import {
  ArrowInspectedSectionWrapper,
  ArrowInspectedSkeleton,
  BuyingProcess,
  CustomerJourneyCarouselSection,
  CustomerJourneySkeleton,
  HomeHero,
  VehicleFinderQuickLinks,
  VehicleFinderSkeleton,
  VehicleTypeSelectorSkeleton,
  VehicleTypeSelectorWrapper,
} from "@features/landing";
import knownUserData from "@shared/data/known-user.json";
import dynamic from "next/dynamic";
import { Suspense } from "react";

const AnimatedSection = dynamic(() =>
  import("@shared/components/animated-section").then((mod) => ({
    default: mod.AnimatedSection,
  }))
);

export default function HomePage() {
  return (
    <Suspense fallback={null}>
      <HomePageGateCheck />
    </Suspense>
  );
}

export async function HomePageGateCheck() {
  return (
    <div className="bg-(--color-core-surfaces-background)">
      <Suspense fallback={<HomeHero showSearch={true} showStats={true} showSubtitle={true} />}>
        <HomeHeroPersonalized />
      </Suspense>

      <Suspense fallback={null}>
        <HomeBelowFoldSections />
      </Suspense>
    </div>
  );
}

async function HomeHeroPersonalized() {
  const [userInfo, showPersonalizedBanner] = await Promise.all([
    getUserInfo(),
    showPersonalizedHeroBanner(),
  ]);

  const knownUserOverrides = showPersonalizedBanner
    ? {
        ...knownUserData,
        userName: userInfo.firstName,
        showCards: true,
        showContinueShopping: true,
      }
    : undefined;

  return (
    <HomeHero
      knownUser={knownUserOverrides}
      showSearch={!showPersonalizedBanner}
      showStats={true}
      showSubtitle={true}
    />
  );
}

// Hidden entirely for authenticated + prequalified users.
async function HomeBelowFoldSections() {
  const [isPreQualified, userInfo] = await Promise.all([customerPreQualified(), getUserInfo()]);

  if (userInfo.isAuthenticated && isPreQualified) {
    return null;
  }

  return (
    <>
      <Suspense fallback={<VehicleTypeSelectorSkeleton />}>
        <AnimatedSection delay={0.1} staggerChildren>
          <VehicleTypeSelectorWrapper />
        </AnimatedSection>
      </Suspense>
      <BuyingProcess />
      <Suspense fallback={<VehicleFinderSkeleton />}>
        <AnimatedSection delay={0.2}>
          <VehicleFinderQuickLinks />
        </AnimatedSection>
      </Suspense>
      <Suspense fallback={<CustomerJourneySkeleton />}>
        <AnimatedSection delay={0.3} staggerChildren>
          <CustomerJourneyCarouselSection isPreQualified={isPreQualified} />
        </AnimatedSection>
      </Suspense>
      <Suspense fallback={<ArrowInspectedSkeleton />}>
        <AnimatedSection delay={0.4}>
          <ArrowInspectedSectionWrapper />
        </AnimatedSection>
      </Suspense>
    </>
  );
}
