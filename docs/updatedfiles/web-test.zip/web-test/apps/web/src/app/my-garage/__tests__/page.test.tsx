import { render, screen } from "@arrow/vitest-config/test-utils";
import { beforeEach, describe, expect, it, vi } from "vitest";
import MyGaragePage from "../page";

vi.mock("@config/flags/flags", () => ({
  getUserInfo: vi.fn(),
  showPersonalizedHeroBanner: vi.fn(),
}));

vi.mock("@config/routes/constants", () => ({
  ROUTES: { HOME: "/" },
}));

vi.mock("@features/my-garage", () => ({
  MyGarageWrapper: vi.fn(() => <div>MyGarageWrapper</div>),
}));

vi.mock("next/navigation", () => ({
  redirect: vi.fn(() => {
    throw new Error("Redirect");
  }),
}));

import { getUserInfo, showPersonalizedHeroBanner } from "@config/flags/flags";
import { ROUTES } from "@config/routes/constants";
import { MyGarageWrapper } from "@features/my-garage";
import { redirect } from "next/navigation";

describe("MyGaragePage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("redirects to home if not authenticated", async () => {
    (getUserInfo as any).mockResolvedValue({ isAuthenticated: false });
    (showPersonalizedHeroBanner as any).mockResolvedValue(false);

    await expect(MyGaragePage()).rejects.toThrow("Redirect");
    expect(redirect).toHaveBeenCalledWith(ROUTES.HOME);
    expect(getUserInfo).toHaveBeenCalled();
    expect(showPersonalizedHeroBanner).toHaveBeenCalled();
  });

  it("renders MyGarageWrapper if authenticated", async () => {
    (getUserInfo as any).mockResolvedValue({ isAuthenticated: true });
    (showPersonalizedHeroBanner as any).mockResolvedValue(true);

    const component = await MyGaragePage();
    render(component);

    expect(MyGarageWrapper).toHaveBeenCalledWith(
      {
        bannerHeightClass: "h-[422px] lg:h-87.5",
        showUserName: true,
      },
      undefined
    );
    expect(screen.getByText("MyGarageWrapper")).toBeInTheDocument();
    expect(getUserInfo).toHaveBeenCalled();
    expect(showPersonalizedHeroBanner).toHaveBeenCalled();
  });

  it("renders MyGarageWrapper with showUserName false when banner is disabled", async () => {
    (getUserInfo as any).mockResolvedValue({ isAuthenticated: true });
    (showPersonalizedHeroBanner as any).mockResolvedValue(false);

    const component = await MyGaragePage();
    render(component);

    expect(MyGarageWrapper).toHaveBeenCalledWith(
      {
        bannerHeightClass: "h-[422px] lg:h-87.5",
        showUserName: false,
      },
      undefined
    );
  });
});
