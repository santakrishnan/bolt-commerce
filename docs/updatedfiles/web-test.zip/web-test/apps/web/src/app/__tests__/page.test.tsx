import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@config/flags/flags", () => ({
  getUserInfo: vi.fn(() => Promise.resolve({ isAuthenticated: false, firstName: "" })),
  showPersonalizedHeroBanner: vi.fn(() => Promise.resolve(false)),
  customerPreQualified: vi.fn(() => Promise.resolve(false)),
}));
vi.mock("@features/landing", () => ({
  HomeHero: () => <div>HomeHero</div>,
  BuyingProcess: () => <div>BuyingProcess</div>,
  ArrowInspectedSectionWrapper: () => <div>ArrowInspectedSection</div>,
  ArrowInspectedSkeleton: () => <div>ArrowInspectedSkeleton</div>,
  CustomerJourneyCarouselSection: () => <div>CustomerJourneyCarouselSection</div>,
  CustomerJourneySkeleton: () => <div>CustomerJourneySkeleton</div>,
  VehicleFinderQuickLinks: () => <div>VehicleFinderQuickLinks</div>,
  VehicleFinderSkeleton: () => <div>VehicleFinderSkeleton</div>,
  VehicleTypeSelectorSkeleton: () => <div>VehicleTypeSelectorSkeleton</div>,
  VehicleTypeSelectorWrapper: () => <div>VehicleTypeSelectorWrapper</div>,
}));
vi.mock("next/dynamic", () => ({
  default: (fn: () => Promise<{ default: React.ComponentType }>) => {
    let Component: React.ComponentType | null = null;
    fn().then((mod) => {
      Component = mod.default;
    });
    return (props: Record<string, unknown>) => (Component ? <Component {...props} /> : null);
  },
}));

type MockFn = ReturnType<typeof vi.fn>;

describe("HomePageGateCheck", () => {
  beforeEach(() => {
    vi.resetModules();
  });

  it("always renders HomeHero for all users", async () => {
    const flags = await import("@config/flags/flags");
    (flags.getUserInfo as unknown as MockFn).mockResolvedValue({
      isAuthenticated: false,
      firstName: "",
    });
    (flags.showPersonalizedHeroBanner as unknown as MockFn).mockResolvedValue(false);

    const { HomePageGateCheck } = await import("../page");
    render(await HomePageGateCheck());

    expect(await screen.findByText("HomeHero")).toBeInTheDocument();
  }, 15_000);

  it("renders HomeHero for returning users (no redirect)", async () => {
    const flags = await import("@config/flags/flags");
    (flags.getUserInfo as unknown as MockFn).mockResolvedValue({
      isAuthenticated: false,
      firstName: "Emily",
    });
    (flags.showPersonalizedHeroBanner as unknown as MockFn).mockResolvedValue(false);

    const { HomePageGateCheck } = await import("../page");
    render(await HomePageGateCheck());

    expect(await screen.findByText("HomeHero")).toBeInTheDocument();
  }, 15_000);
});
