import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

const garageRegex = /Garage/;

vi.mock("@config/flags/flags", () => ({
  redirectToMyGarage: vi.fn(() => Promise.resolve(false)),
  getUserInfo: vi.fn(() => Promise.resolve({ isAuthenticated: false, firstName: "" })),
  showPersonalizedHeroBanner: vi.fn(() => Promise.resolve(false)),
  customerPreQualified: vi.fn(() => Promise.resolve(false)),
}));
vi.mock("@features/my-garage", () => ({
  MyGarageWrapper: ({ showUserName }: { showUserName: boolean }) => (
    <div>Garage {showUserName ? "User" : ""}</div>
  ),
}));
vi.mock("@features/landing", () => ({
  HomeHero: () => <div>HomeHero</div>,
  BuyingProcess: () => <div>BuyingProcess</div>,
  ArrowInspectedSectionWrapper: () => <div>ArrowInspectedSection</div>,
  ArrowInspectedSkeleton: () => <div>ArrowInspectedSkeleton</div>,
  CustomerJourneyCarouselSection: () => <div>CustomerJourneyCarouselSection</div>,
  CustomerJourneySkeleton: () => <div>CustomerJourneySkeleton</div>,
  VehicleFinderQuickLinks: () => <div>VehicleFinderQuickLinks</div>,
  VehicleFinderSkeleton: () => <div>VehicleFinderSkeleton</div>,
  VehicleTypeSelectorSkeleton: () => <div>VehicleTypeSelectorSkeleton</div>,
  VehicleTypeSelectorWrapper: () => <div>VehicleTypeSelectorWrapper</div>,
}));
vi.mock("next/dynamic", () => ({
  default: (fn: () => Promise<{ default: React.ComponentType }>) => {
    let Component: React.ComponentType | null = null;
    fn().then((mod) => {
      Component = mod.default;
    });
    return (props: Record<string, unknown>) => (Component ? <Component {...props} /> : null);
  },
}));

// Flags are typed as Flag<boolean> from the SDK — cast via unknown to access vi.fn() methods.
type MockFn = ReturnType<typeof vi.fn>;

describe("HomePageGateCheck", () => {
  beforeEach(() => {
    vi.resetModules();
  });

  it("renders MyGarageWrapper when redirectToMyGarage is true", async () => {
    const flags = await import("@config/flags/flags");
    (flags.redirectToMyGarage as unknown as MockFn).mockResolvedValue(true);
    (flags.getUserInfo as unknown as MockFn).mockResolvedValue({
      isAuthenticated: true,
      firstName: "Emily",
    });

    const { HomePageGateCheck } = await import("../page");
    render(await HomePageGateCheck());

    expect(await screen.findByText(garageRegex)).toBeInTheDocument();
    expect(screen.queryByText("HomeHero")).not.toBeInTheDocument();
  }, 15_000);

  it("renders HomeHero for anonymous users", async () => {
    const flags = await import("@config/flags/flags");
    (flags.redirectToMyGarage as unknown as MockFn).mockResolvedValue(false);
    (flags.getUserInfo as unknown as MockFn).mockResolvedValue({
      isAuthenticated: false,
      firstName: "",
    });
    (flags.showPersonalizedHeroBanner as unknown as MockFn).mockResolvedValue(false);

    const { HomePageGateCheck } = await import("../page");
    render(await HomePageGateCheck());

    expect(await screen.findByText("HomeHero")).toBeInTheDocument();
    expect(screen.queryByText(garageRegex)).not.toBeInTheDocument();
  }, 15_000);
});
