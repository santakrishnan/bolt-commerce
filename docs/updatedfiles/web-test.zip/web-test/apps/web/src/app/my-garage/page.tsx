import { getUserInfo, showPersonalizedHeroBanner } from "@config/flags/flags";
import { ROUTES } from "@config/routes/constants";
import { MyGarageWrapper } from "@features/my-garage";
import { redirect } from "next/navigation";

/**
 * My Garage Page — /my-garage
 *
 * SSR-only. Redirects unauthenticated users to home.
 *
 * ─── DATA SOURCES (all mocked until env vars are set) ───────────────────────
 *
 * Auth / user state
 *   Source:  src/config/flags/config.ts (mock users)
 *   Switch:  Cookie "feature-flags-user" — use the 🚩 debug panel to change
 *   Users:   Emily (returning), Sarah (auth, not prequalified),
 *            James (auth, prequalified), Marcus (card test)
 *
 * Vehicle sections (bestMatches, becauseYouViewed, recentPriceDrop)
 *   Source:  GET /api/garage/profile → my-garage.service.ts (mock)
 *   Switch:  Set PROFILE_SERVICE_URL env var to point at real Profile Service
 *
 * Pre-qualification days remaining
 *   Source:  MockUser.daysRemaining in config.ts (James=12, default=30)
 *   Switch:  Will come from Profile Service response in production
 *
 * Saved vehicles
 *   Source:  GET /api/saved-registry/vehicles (BED mock)
 *   Switch:  Configure BED saved-registry service
 *
 * Recent searches
 *   Source:  GET /api/saved-registry/search-history (BED mock)
 *   Switch:  Configure BED saved-registry service
 *
 * Trade-in offer
 *   Source:  customerTradeInSubmitted flag in config.ts
 *   Switch:  Will come from Profile Service / trade-in service in production
 */

export default async function MyGaragePage() {
  // Only authenticated users can access this page
  const [{ isAuthenticated }, showPersonalizedBanner] = await Promise.all([
    getUserInfo(),
    showPersonalizedHeroBanner(),
  ]);

  if (!isAuthenticated) {
    redirect(ROUTES.HOME);
  }

  return (
    <MyGarageWrapper
      bannerHeightClass={"h-[422px] lg:h-87.5"}
      showUserName={showPersonalizedBanner}
    />
  );
}
