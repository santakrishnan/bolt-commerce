/**
 * @vitest-environment jsdom
 */
import { render, screen } from "@arrow/vitest-config/test-utils";
import { describe, expect, it, vi } from "vitest";
import UsedCarsNotFound from "../not-found";

vi.mock("@config/messages/used-cars", () => ({
  usedCarsMessages: {
    vdp: {
      notFoundTitle: "Not Found Title",
      notFoundDescription: "Not Found Description",
      searchCta: "Search CTA",
      homeCta: "Home CTA",
    },
  },
}));

vi.mock("@config/routes/constants", () => ({
  ROUTES: { USED_CARS: "/used-cars", HOME: "/" },
}));

describe("UsedCarsNotFound", () => {
  it("renders not found title, description, and CTAs", () => {
    render(<UsedCarsNotFound />);
    expect(screen.getByText("Not Found Title")).toBeInTheDocument();
    expect(screen.getByText("Not Found Description")).toBeInTheDocument();
    expect(screen.getByText("Search CTA")).toBeInTheDocument();
    expect(screen.getByText("Home CTA")).toBeInTheDocument();
  });
});
