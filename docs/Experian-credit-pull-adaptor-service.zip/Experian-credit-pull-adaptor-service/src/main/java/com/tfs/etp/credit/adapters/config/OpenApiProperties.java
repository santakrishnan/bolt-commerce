package com.tfs.etp.credit.adapters.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

/**
 * Configuration properties for OpenAPI documentation.
 * Mapped from application.yml under 'openapi'.
 */
@Data
@Configuration
@Validated
@ConfigurationProperties(prefix = "openapi")
public class OpenApiProperties {

	private Info info = new Info();
	private Servers servers = new Servers();

	@Data
	public static class Info {
		/**
		 * API title.
		 */
		private String title;

		/**
		 * API description.
		 */
		private String description;

		/**
		 * API version.
		 */
		private String version;

		/**
		 * Contact information.
		 */
		private Contact contact = new Contact();

		/**
		 * License information.
		 */
		private License license = new License();
	}

	@Data
	public static class Contact {
		/**
		 * Contact name.
		 */
		private String name;

		/**
		 * Contact email.
		 */
		private String email;
	}

	@Data
	public static class License {
		/**
		 * License name.
		 */
		private String name;

		/**
		 * License URL.
		 */
		private String url;
	}

	@Data
	public static class Servers {
		/**
		 * Local development server URL.
		 */
		private String local;

		/**
		 * Production server URL.
		 */
		private String production;
	}
}
