package com.tfs.etp.credit.adapters.exception;

import lombok.Getter;

/**
 * Simplified exception for all credit bureau related errors.
 *
 * This is a message-driven exception that uses an {@link ErrorType} to categorize
 * errors and an optional {@link ErrorContext} to capture vendor-specific details.
 * All credit bureau errors should use this single exception type with appropriate
 * error type and context.
 *
 * Usage Examples:
 * <pre>
 * // Simple error
 * throw new CreditBureauException(ErrorType.VALIDATION_ERROR, "Invalid SSN format");
 *
 * // Vendor error with context
 * throw new CreditBureauException(
 *     ErrorType.VENDOR_SERVER_ERROR,
 *     "Experian API returned 500",
 *     ErrorContext.forVendor("EXPERIAN")
 * );
 *
 * // With cause exception
 * throw new CreditBureauException(
 *     ErrorType.VENDOR_UNAVAILABLE,
 *     "Failed to connect to vendor",
 *     ErrorContext.forVendor("EXPERIAN"),
 *     cause
 * );
 * </pre>
 */
@Getter
public class CreditBureauException extends RuntimeException {

	private final ErrorType errorType;
	private final ErrorContext errorContext;

	/**
	 * Creates a credit bureau exception with an error type and message.
	 *
	 * @param errorType the category of error
	 * @param message the error message
	 */
	public CreditBureauException(ErrorType errorType, String message) {
		super(message);
		this.errorType = errorType;
		this.errorContext = null;
	}

	/**
	 * Creates a credit bureau exception with an error type, message, and context.
	 *
	 * @param errorType the category of error
	 * @param message the error message
	 * @param errorContext additional context about the error
	 */
	public CreditBureauException(ErrorType errorType, String message, ErrorContext errorContext) {
		super(message);
		this.errorType = errorType;
		this.errorContext = errorContext;
	}

	/**
	 * Creates a credit bureau exception with an error type, message, and cause.
	 *
	 * @param errorType the category of error
	 * @param message the error message
	 * @param cause the underlying cause
	 */
	public CreditBureauException(ErrorType errorType, String message, Throwable cause) {
		super(message, cause);
		this.errorType = errorType;
		this.errorContext = null;
	}

	/**
	 * Creates a credit bureau exception with complete details.
	 *
	 * @param errorType the category of error
	 * @param message the error message
	 * @param errorContext additional context about the error
	 * @param cause the underlying cause
	 */
	public CreditBureauException(ErrorType errorType, String message, ErrorContext errorContext, Throwable cause) {
		super(message, cause);
		this.errorType = errorType;
		this.errorContext = errorContext;
	}

	// Convenience getters for common context fields

	public String getVendorName() {
		return errorContext != null ? errorContext.getVendorName() : null;
	}

	public Integer getHttpStatusCode() {
		return errorContext != null ? errorContext.getHttpStatusCode() : null;
	}

	public String getVendorErrorCode() {
		return errorContext != null ? errorContext.getVendorErrorCode() : null;
	}

	public String getVendorErrorMessage() {
		return errorContext != null ? errorContext.getVendorErrorMessage() : null;
	}
}
