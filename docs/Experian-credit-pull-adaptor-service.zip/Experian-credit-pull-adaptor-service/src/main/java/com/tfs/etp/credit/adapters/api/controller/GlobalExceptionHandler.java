package com.tfs.etp.credit.adapters.api.controller;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.tfs.etp.credit.adapters.api.generated.model.ApiErrorResponse;
import com.tfs.etp.credit.adapters.api.generated.model.ErrorDetail;
import com.tfs.etp.credit.adapters.api.generated.model.FieldError;
import com.tfs.etp.credit.adapters.common.constants.LogMessageConstants;
import com.tfs.etp.credit.adapters.exception.CreditBureauException;
import com.tfs.etp.credit.adapters.exception.ErrorContext;
import jakarta.servlet.http.HttpServletRequest;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;
import lombok.CustomLog;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

/**
 * Global exception handler for the Credit Bureau API.
 *
 * Normalizes all exceptions into standardized {@link ApiErrorResponse} objects
 * with consistent structure across all vendor adapters and error types.
 *
 * Error Normalization:
 * - All vendor-specific errors are normalized into a consistent format
 * - HTTP status codes are determined by the {@link ErrorType}
 * - Vendor details are preserved in the error detail field when available
 * - Field validation errors are mapped to the fieldErrors array
 */
@CustomLog
@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class GlobalExceptionHandler {

	// ========================
	// Spring Validation Errors
	// ========================

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ApiErrorResponse> handleValidationErrors(
			MethodArgumentNotValidException ex, HttpServletRequest request) {

		List<FieldError> fieldErrors = ex.getBindingResult().getFieldErrors().stream()
				.map(error -> new FieldError().field(error.getField()).message(error.getDefaultMessage()))
				.toList();

		ApiErrorResponse response = new ApiErrorResponse().success(false).message("Request validation failed");

		ErrorDetail errorDetail = new ErrorDetail()
				.errorCode("VALIDATION_ERROR")
				.detail(String.format("%d validation error(s)", fieldErrors.size()))
				.status(HttpStatus.BAD_REQUEST.value())
				.path(request.getRequestURI())
				.timestamp(OffsetDateTime.now())
				.fieldErrors(fieldErrors);

		response.setError(errorDetail);

		log.warn(LogMessageConstants.VALIDATION_ERROR, request.getRequestURI(), fieldErrors.size());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<ApiErrorResponse> handleHttpMessageNotReadable(
			HttpMessageNotReadableException ex, HttpServletRequest request) {

		String detail = "Invalid request content";
		List<FieldError> fieldErrors = Collections.emptyList();

		// Try to extract specific field error information
		Throwable cause = ex.getCause();
		if (cause instanceof InvalidFormatException ife) {
			String fieldName = ife.getPath().stream()
					.map(ref -> ref.getFieldName())
					.filter(name -> name != null)
					.findFirst()
					.orElse("unknown");

			String message = String.format("Invalid value for field '%s': %s", fieldName, ife.getValue());
			detail = message;

			fieldErrors = List.of(new FieldError().field(fieldName).message("Invalid format or type"));
		}

		ApiErrorResponse response = new ApiErrorResponse().success(false).message("Invalid request format");

		ErrorDetail errorDetail = new ErrorDetail()
				.errorCode("VALIDATION_ERROR")
				.detail(detail)
				.status(HttpStatus.BAD_REQUEST.value())
				.path(request.getRequestURI())
				.timestamp(OffsetDateTime.now())
				.fieldErrors(fieldErrors);

		response.setError(errorDetail);

		log.warn("Invalid request format at {}: {}", request.getRequestURI(), ex.getMessage());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
	}

	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<ApiErrorResponse> handleTypeMismatch(
			MethodArgumentTypeMismatchException ex, HttpServletRequest request) {

		String fieldName = ex.getName();
		String detail = String.format("Invalid value for parameter '%s': %s", fieldName, ex.getValue());

		List<FieldError> fieldErrors = List.of(new FieldError().field(fieldName).message("Type mismatch"));

		ApiErrorResponse response = new ApiErrorResponse().success(false).message("Invalid parameter type");

		ErrorDetail errorDetail = new ErrorDetail()
				.errorCode("VALIDATION_ERROR")
				.detail(detail)
				.status(HttpStatus.BAD_REQUEST.value())
				.path(request.getRequestURI())
				.timestamp(OffsetDateTime.now())
				.fieldErrors(fieldErrors);

		response.setError(errorDetail);

		log.warn("Type mismatch at {}: {}", request.getRequestURI(), ex.getMessage());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
	}

	// ========================
	// Credit Bureau Exception (Unified Handler)
	// ========================

	@ExceptionHandler(CreditBureauException.class)
	public ResponseEntity<ApiErrorResponse> handleCreditBureauException(
			CreditBureauException ex, HttpServletRequest request) {

		ErrorContext context = ex.getErrorContext();
		HttpStatus httpStatus = ex.getErrorType().getHttpStatus();

		// Build normalized error response
		ApiErrorResponse response = new ApiErrorResponse().success(false).message(ex.getMessage());

		ErrorDetail errorDetail = new ErrorDetail()
				.errorCode(ex.getErrorType().getErrorCode())
				.status(httpStatus.value())
				.path(request.getRequestURI())
				.timestamp(OffsetDateTime.now());

		// Add vendor-specific details if available
		if (context != null) {
			String detail = buildErrorDetail(context);
			if (detail != null) {
				errorDetail.detail(detail);
			}

			// Add field errors if present
			if (!context.getFieldErrors().isEmpty()) {
				List<FieldError> fieldErrors = context.getFieldErrors().entrySet().stream()
						.map(entry -> new FieldError().field(entry.getKey()).message(entry.getValue()))
						.toList();
				errorDetail.fieldErrors(fieldErrors);
			}
		}

		response.setError(errorDetail);

		// Log based on error type
		logException(ex);

		return ResponseEntity.status(httpStatus).body(response);
	}

	// ========================
	// Generic Errors
	// ========================

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ApiErrorResponse> handleUnexpectedException(Exception ex, HttpServletRequest request) {

		ApiErrorResponse response = new ApiErrorResponse().success(false).message("An unexpected error occurred");

		ErrorDetail errorDetail = new ErrorDetail()
				.errorCode("INTERNAL_ERROR")
				.detail("Please contact support with the trace ID")
				.status(HttpStatus.INTERNAL_SERVER_ERROR.value())
				.path(request.getRequestURI())
				.timestamp(OffsetDateTime.now());

		response.setError(errorDetail);

		log.error(LogMessageConstants.UNEXPECTED_ERROR, request.getRequestURI(), ex.getMessage(), ex);
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
	}

	// ========================
	// Helper Methods
	// ========================

	/**
	 * Builds a normalized error detail string from the error context.
	 * Captures vendor-specific information in a consistent format.
	 */
	private String buildErrorDetail(ErrorContext context) {
		StringBuilder detail = new StringBuilder();

		if (context.getVendorName() != null) {
			detail.append("Vendor: ").append(context.getVendorName());
		}

		if (context.getHttpStatusCode() != null) {
			if (detail.length() > 0) {
				detail.append(", ");
			}
			detail.append("Status: ").append(context.getHttpStatusCode());
		}

		if (context.getVendorErrorCode() != null) {
			if (detail.length() > 0) {
				detail.append(", ");
			}
			detail.append("Code: ").append(context.getVendorErrorCode());
		}

		if (context.getVendorErrorMessage() != null) {
			if (detail.length() > 0) {
				detail.append(", ");
			}
			detail.append("Message: ").append(context.getVendorErrorMessage());
		}

		// Add metadata if present
		if (!context.getMetadata().isEmpty()) {
			context.getMetadata().forEach((key, value) -> {
				if (detail.length() > 0) {
					detail.append(", ");
				}
				detail.append(key).append(": ").append(value);
			});
		}

		return detail.length() > 0 ? detail.toString() : null;
	}

	/**
	 * Logs exception based on error type severity.
	 */
	private void logException(CreditBureauException ex) {
		switch (ex.getErrorType()) {
			case VALIDATION_ERROR:
				log.warn(LogMessageConstants.CUSTOM_VALIDATION_ERROR, ex.getMessage());
				break;

			case AUTHENTICATION_ERROR:
				log.error(
						LogMessageConstants.VENDOR_AUTHENTICATION_ERROR,
						ex.getVendorName() != null ? ex.getVendorName() : "UNKNOWN");
				break;

			case VENDOR_UNAVAILABLE:
				log.error(
						LogMessageConstants.VENDOR_UNAVAILABLE,
						ex.getVendorName() != null ? ex.getVendorName() : "UNKNOWN");
				break;

			case VENDOR_CLIENT_ERROR:
			case VENDOR_SERVER_ERROR:
			case VENDOR_RATE_LIMITED:
			case VENDOR_TIMEOUT:
				log.error(
						LogMessageConstants.VENDOR_API_ERROR,
						ex.getVendorName() != null ? ex.getVendorName() : "UNKNOWN",
						ex.getHttpStatusCode() != null ? ex.getHttpStatusCode() : 0,
						ex.getVendorErrorMessage() != null ? ex.getVendorErrorMessage() : "No message");
				break;

			case INTERNAL_ERROR:
			case CONFIGURATION_ERROR:
			case BUSINESS_RULE_VIOLATION:
			default:
				log.error(
						LogMessageConstants.CREDIT_BUREAU_ERROR,
						ex.getErrorType().getErrorCode(),
						ex.getMessage(),
						ex);
				break;
		}
	}
}
