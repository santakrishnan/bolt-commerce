package com.tfs.etp.credit.adapters.api.controller;

import com.tfs.etp.credit.adapters.api.generated.CreditBureauApi;
import com.tfs.etp.credit.adapters.api.generated.model.CreditCheckApiRequest;
import com.tfs.etp.credit.adapters.api.generated.model.CreditCheckApiResponse;
import com.tfs.etp.credit.adapters.api.mapper.ApiRequestMapper;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckResponse;
import com.tfs.etp.credit.adapters.domain.service.CreditBureauService;
import io.micrometer.core.annotation.Timed;
import jakarta.validation.Valid;
import lombok.CustomLog;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST API controller for credit bureau operations.
 *
 * Provides endpoints for:
 * - Credit check requests
 * - Vendor health status
 */
@CustomLog
@RestController
@RequiredArgsConstructor
public class CreditBureauController implements CreditBureauApi {

	private final CreditBureauService creditBureauService;
	private final ApiRequestMapper apiMapper;

	/**
	 * Execute a credit check for a customer.
	 *
	 * @param apiRequest the credit check request
	 * @return credit check response with score and report details
	 */
	@Override
	@Timed(value = "credit.bureau.api.check", description = "Time taken to process credit check API request")
	public ResponseEntity<CreditCheckApiResponse> checkCredit(@Valid @RequestBody CreditCheckApiRequest apiRequest) {

		long startTime = System.currentTimeMillis();

		log.info(
				"Received credit check request: requestId={}, vendor={}, applicantCount={}",
				apiRequest.getRequestId(),
				apiRequest.getVendor(),
				apiRequest.getApplicant() != null ? apiRequest.getApplicant().size() : 0);

		// Map API to Domain model for PII masking
		CreditCheckRequest domainRequest = apiMapper.toDomainRequest(apiRequest);

		// Execute credit check
		CreditCheckResponse domainResponse = creditBureauService.checkCredit(domainRequest);

		// Map Domain model → API DTO
		CreditCheckApiResponse apiResponse = apiMapper.toApiResponse(domainResponse);

		long processingTime = System.currentTimeMillis() - startTime;
		log.info(
				"Credit check completed successfully: requestId={}, vendor={}, success={}, processingTime={}ms",
				apiRequest.getRequestId(),
				apiRequest.getVendor(),
				apiResponse.getSuccess(),
				processingTime);

		return ResponseEntity.ok(apiResponse);
	}
}
