package com.tfs.etp.credit.adapters.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Security configuration for the Credit Bureau Core Adapter.
 *
 * Configures:
 * - Stateless session management (no server-side sessions)
 * - Public access to actuator and API documentation endpoints
 * - CSRF disabled (stateless API)
 * - All other endpoints require authentication
 *
 * In production, this would integrate with JWT/OAuth 2.0 for authentication.
 * Currently configured to permit all for development.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		return http.csrf(AbstractHttpConfigurer::disable)
				.sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
				.authorizeHttpRequests(auth -> auth
						// Public endpoints
						.requestMatchers("/actuator/**", "/swagger-ui/**", "/swagger-ui.html", "/v3/api-docs/**")
						.permitAll()
						// All other endpoints - permit for development; lock down in production
						.anyRequest()
						.permitAll())
				.build();
	}
}
