package com.tfs.etp.credit.adapters.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * OpenAPI documentation configuration.
 */
@Configuration
@RequiredArgsConstructor
public class OpenApiConfig {

	private final OpenApiProperties properties;

	@Value("${server.port:8080}")
	private int serverPort;

	@Value("${server.servlet.context-path:/}")
	private String contextPath;

	@Bean
	public OpenAPI creditBureauOpenAPI() {
		// Normalize context path (remove trailing slash if present)
		String normalizedContextPath = contextPath.endsWith("/") && contextPath.length() > 1
				? contextPath.substring(0, contextPath.length() - 1)
				: contextPath;

		// Build server URLs
		String localUrl = properties.getServers().getLocal() != null
				? properties.getServers().getLocal() + normalizedContextPath
				: "http://localhost:" + serverPort + normalizedContextPath;

		String prodUrl = properties.getServers().getProduction() + normalizedContextPath;

		return new OpenAPI()
				.info(new Info()
						.title(properties.getInfo().getTitle())
						.description(properties.getInfo().getDescription())
						.version(properties.getInfo().getVersion())
						.contact(new Contact()
								.name(properties.getInfo().getContact().getName())
								.email(properties.getInfo().getContact().getEmail()))
						.license(new License()
								.name(properties.getInfo().getLicense().getName())
								.url(properties.getInfo().getLicense().getUrl())))
				.servers(List.of(
						new Server().url(localUrl).description("Local Development"),
						new Server().url(prodUrl).description("Production")));
	}
}
