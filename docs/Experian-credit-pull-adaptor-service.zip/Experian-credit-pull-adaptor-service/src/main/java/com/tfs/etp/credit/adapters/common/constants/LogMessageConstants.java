package com.tfs.etp.credit.adapters.common.constants;

public final class LogMessageConstants {

	private LogMessageConstants() {}

	public static final String RECEIVED_CREDIT_CHECK_REQUEST = "Received credit check request";

	public static final String VALIDATION_ERROR = "Validation error on {}: {} errors";
	public static final String CUSTOM_VALIDATION_ERROR = "Custom validation error: {}";
	public static final String VENDOR_API_ERROR = "Vendor API error: vendor={}, httpStatus={}, vendorError={}";
	public static final String VENDOR_UNAVAILABLE = "Vendor unavailable: vendor={}";
	public static final String VENDOR_AUTHENTICATION_ERROR = "Vendor authentication error: vendor={}";
	public static final String CREDIT_BUREAU_ERROR = "Credit bureau error: errorCode={}, message={}";
	public static final String UNEXPECTED_ERROR = "Unexpected error on {}: {}";

	public static final String INITIALIZED_CREDIT_BUREAU_CORE_SERVICE =
			"Initialized CreditBureauCoreService with vendors: {}";
	public static final String PROCESSING_CREDIT_CHECK_REQUEST = "Processing credit check request: requestId={}";
	public static final String SELECTED_VENDOR_FOR_REQUEST = "Selected vendor: {} for requestId={}";
	public static final String CREDIT_CHECK_COMPLETED =
			"Credit check completed: requestId={}, vendor={}, score={}, processingTime={}ms";
	public static final String CREDIT_CHECK_FAILED =
			"Credit check failed: requestId={}, vendor={}, errorCode={}, message={}";
	public static final String PREFERRED_VENDOR_UNAVAILABLE =
			"Preferred vendor {} is unavailable, falling back to selection strategy";

	public static final String ROUND_ROBIN_SELECTED_VENDOR = "Round-robin selected vendor: {}";
	public static final String DEFAULT_VENDOR_FAILOVER = "Default vendor {} unavailable, failing over to {}";

	public static final String CACHE_HIT_FOR_KEY = "Cache hit for key: {}";
	public static final String CACHE_DESERIALIZE_FAILED = "Failed to deserialize cached response for key: {}";
	public static final String CACHE_READ_ERROR = "Cache read error for key: {}";
	public static final String CACHED_RESPONSE_FOR_KEY = "Cached response for key: {}";
	public static final String CACHE_SERIALIZE_FAILED = "Failed to serialize response for caching, key: {}";
	public static final String CACHE_WRITE_ERROR = "Cache write error for key: {}";
	public static final String EVICTED_CACHE_FOR_KEY = "Evicted cache for key: {}";
	public static final String CACHE_EVICT_ERROR = "Cache evict error for key: {}";
	public static final String CACHE_EXISTS_CHECK_ERROR = "Cache exists check error for key: {}";

	public static final String HTTP_REQUEST_LOG = ">> {} {}";
	public static final String HTTP_RESPONSE_LOG = "<< {} {} [status={}, duration={}ms]";

	public static final String EXPERIAN_CACHE_HIT = "Cache HIT for requestId={}";
	public static final String EXPERIAN_MAPPING_REQUEST = "Mapping canonical request to Experian format: requestId={}";
	public static final String EXPERIAN_CALLING_API = "Calling Experian API: requestId={}";
	public static final String EXPERIAN_CACHED_CREDIT_RESPONSE = "Cached credit response: requestId={}";

	public static final String EXPERIAN_UNABLE_PARSE_DATE = "Unable to parse Experian date: {}";

	public static final String EXPERIAN_UNEXPECTED_API_ERROR = "Unexpected error calling Experian API endpoint={}";
	public static final String EXPERIAN_PREQUAL_API_CALL =
			"Calling Experian Prequal API: endpoint={}, clientReferenceId={}";
	public static final String EXPERIAN_TRANSACTION_ID = "Experian transaction ID: {}";
	public static final String EXPERIAN_API_401_TOKEN_REFRESH = "Experian API returned 401, attempting token refresh";
	public static final String EXPERIAN_RETRY_AFTER_TOKEN_REFRESH_FAILED = "Retry after token refresh also failed";
	public static final String EXPERIAN_API_RATE_LIMIT = "Experian API rate limit exceeded";
	public static final String EXPERIAN_API_CLIENT_ERROR = "Experian API client error: status={}, body={}";
	public static final String EXPERIAN_API_SERVER_ERROR = "Experian API server error: status={}";

	public static final String USING_CACHED_EXPERIAN_OAUTH_TOKEN = "Using cached Experian OAuth token";
	public static final String REQUESTING_NEW_EXPERIAN_OAUTH_TOKEN =
			"Requesting new Experian OAuth token (password grant)";
	public static final String OBTAINED_EXPERIAN_OAUTH_TOKEN =
			"Successfully obtained and cached Experian OAuth token, expires in {}s";
	public static final String INVALIDATING_CACHED_EXPERIAN_OAUTH_TOKEN = "Invalidating cached Experian OAuth token";
	public static final String FAILED_TO_INVALIDATE_CACHED_TOKEN = "Failed to invalidate cached token";
	public static final String FAILED_TO_RETRIEVE_CACHED_TOKEN =
			"Failed to retrieve cached token, will request new token";
	public static final String EXPERIAN_OAUTH_TOKEN_REQUEST_FAILED =
			"Experian OAuth token request failed: status={}, body={}";
	public static final String EXPERIAN_OAUTH_TOKEN_REQUEST_ERROR = "Experian OAuth token request error";
	public static final String FAILED_TO_CACHE_TOKEN =
			"Failed to cache token, token will still be used for this request";
}
