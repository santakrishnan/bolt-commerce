package com.tfs.etp.credit.adapters.domain.port;

import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckResponse;

/**
 * Port interface for credit bureau vendor adapters.
 *
 * Each supported credit bureau vendor must implement this interface.
 * This follows the Hexagonal Architecture pattern, providing a clean boundary between
 * the core domain and external vendor-specific logic.
 *
 * Implementations must handle:
 * - Vendor-specific authentication
 * - Request format transformation (canonical → vendor)
 * - API call execution
 * - Response format transformation (vendor → canonical)
 * - Vendor-specific error handling
 */
public interface CreditBureauVendorAdapter {

	/**
	 * Execute a credit check against the vendor's API.
	 *
	 * @param request the canonical credit check request
	 * @return the canonical credit check response
	 * @throws com.tfs.etp.credit.adapters.exception.VendorApiException if the vendor API returns an error
	 * @throws com.tfs.etp.credit.adapters.exception.AuthenticationException if authentication with the vendor fails
	 * @throws com.tfs.etp.credit.adapters.exception.VendorUnavailableException if the vendor is unavailable
	 */
	CreditCheckResponse checkCredit(CreditCheckRequest request);

	/**
	 * Returns the vendor type this adapter supports.
	 *
	 * @return the vendor type
	 */
	CreditCheckRequest.VendorType getVendorType();

	/**
	 * Check if the vendor adapter is currently healthy and available.
	 *
	 * @return true if the vendor is available, false otherwise
	 */
	boolean isAvailable();

	/**
	 * Get the display name for this vendor.
	 *
	 * @return vendor display name
	 */
	default String getVendorName() {
		return getVendorType().name();
	}
}
