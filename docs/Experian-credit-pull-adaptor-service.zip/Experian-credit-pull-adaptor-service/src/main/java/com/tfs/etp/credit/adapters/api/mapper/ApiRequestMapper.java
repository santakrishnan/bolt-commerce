package com.tfs.etp.credit.adapters.api.mapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tfs.etp.credit.adapters.api.generated.model.Address;
import com.tfs.etp.credit.adapters.api.generated.model.Applicant;
import com.tfs.etp.credit.adapters.api.generated.model.ApplicantAddress;
import com.tfs.etp.credit.adapters.api.generated.model.ApplicantEmployment;
import com.tfs.etp.credit.adapters.api.generated.model.CreditCheckApiRequest;
import com.tfs.etp.credit.adapters.api.generated.model.CreditCheckApiResponse;
import com.tfs.etp.credit.adapters.api.generated.model.DriverLicense;
import com.tfs.etp.credit.adapters.api.generated.model.Employment;
import com.tfs.etp.credit.adapters.api.generated.model.FreezeOverride;
import com.tfs.etp.credit.adapters.api.generated.model.InquiryPurpose;
import com.tfs.etp.credit.adapters.api.generated.model.Phone;
import com.tfs.etp.credit.adapters.api.generated.model.SecondaryApplicant;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckResponse;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.CustomLog;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Maps between API DTOs and domain models.
 *
 * Provides clean separation between the API layer and domain layer,
 * ensuring that API concerns (validation annotations, Swagger docs)
 * don't leak into the domain.
 */
@CustomLog
@Component
@RequiredArgsConstructor
public class ApiRequestMapper {

	private final ObjectMapper objectMapper;

	/**
	 * Map API request DTO to canonical domain model.
	 * Supports both new applicant array format and legacy format.
	 *
	 * @param apiRequest the API request
	 * @return canonical credit check request
	 */
	public CreditCheckRequest toDomainRequest(CreditCheckApiRequest apiRequest) {
		log.debug(
				"Mapping API request to domain model: requestId={}, vendor={}",
				apiRequest.getRequestId(),
				apiRequest.getVendor());

		// Map from applicant array format
		if (apiRequest.getApplicant() != null && !apiRequest.getApplicant().isEmpty()) {
			CreditCheckRequest domainRequest = toDomainRequestFromApplicantArray(apiRequest);
			log.debug("Successfully mapped API request to domain model: requestId={}", apiRequest.getRequestId());
			return domainRequest;
		}

		// No applicants provided - return minimal request
		return CreditCheckRequest.builder()
				.requestId(
						apiRequest.getRequestId() != null
								? apiRequest.getRequestId()
								: UUID.randomUUID().toString())
				.vendor(apiRequest.getVendor() != null ? apiRequest.getVendor().toString() : null)
				.inquiryPurpose(mapInquiryPurpose(apiRequest.getInquiryPurpose()))
				.freezeOverride(null)
				.requestTimestamp(LocalDateTime.now())
				.build();
	}

	/**
	 * Map from new applicant array format to domain model.
	 */
	private CreditCheckRequest toDomainRequestFromApplicantArray(CreditCheckApiRequest apiRequest) {
		List<CreditCheckRequest.Applicant> applicants =
				apiRequest.getApplicant().stream().map(this::mapApplicant).collect(Collectors.toList());

		return CreditCheckRequest.builder()
				.requestId(
						apiRequest.getRequestId() != null
								? apiRequest.getRequestId()
								: UUID.randomUUID().toString())
				.vendor(apiRequest.getVendor() != null ? apiRequest.getVendor().toString() : null)
				.applicant(applicants)
				.inquiryPurpose(mapInquiryPurpose(apiRequest.getInquiryPurpose()))
				.freezeOverride(null)
				.requestTimestamp(LocalDateTime.now())
				.build();
	}

	/**
	 * Map individual applicant from API to domain model.
	 */
	private CreditCheckRequest.Applicant mapApplicant(Applicant apiApplicant) {

		CreditCheckRequest.ApplicantType applicantType = null;
		if (apiApplicant.getApplicantType() != null) {
			applicantType = Applicant.ApplicantTypeEnum.CO_APPLICANT.equals(apiApplicant.getApplicantType())
					? CreditCheckRequest.ApplicantType.CO_APPLICANT
					: CreditCheckRequest.ApplicantType.PRIMARY;
		}

		return CreditCheckRequest.Applicant.builder()
				.applicantType(applicantType)
				.firstName(apiApplicant.getFirstName())
				.lastName(apiApplicant.getLastName())
				.middleName(apiApplicant.getMiddleName())
				.suffix(apiApplicant.getSuffix())
				.dateOfBirth(apiApplicant.getDateOfBirth())
				.ssn(apiApplicant.getSsn())
				.currentAddress(mapApplicantAddress(apiApplicant.getCurrentAddress()))
				.previousAddresses(mapApplicantAddresses(apiApplicant.getPreviousAddresses()))
				.phones(mapPhones(apiApplicant.getPhones()))
				.driversLicense(mapDriverLicense(apiApplicant.getDriversLicense()))
				.employment(mapApplicantEmployment(apiApplicant.getEmployment()))
				.build();
	}

	/**
	 * Map applicant address from API to domain model.
	 */
	private CreditCheckRequest.Address mapApplicantAddress(ApplicantAddress apiAddress) {
		if (apiAddress == null) return null;

		return CreditCheckRequest.Address.builder()
				.street(apiAddress.getAddressLine1())
				.street2(apiAddress.getAddressLine2())
				.city(apiAddress.getCity())
				.state(apiAddress.getState())
				.zipCode(apiAddress.getZipCode())
				.build();
	}

	/**
	 * Map list of applicant addresses.
	 */
	private List<CreditCheckRequest.Address> mapApplicantAddresses(List<ApplicantAddress> apiAddresses) {
		if (apiAddresses == null || apiAddresses.isEmpty()) return null;

		return apiAddresses.stream().map(this::mapApplicantAddress).collect(Collectors.toList());
	}

	/**
	 * Map applicant employment from API to domain model.
	 */
	private CreditCheckRequest.Employment mapApplicantEmployment(ApplicantEmployment apiEmployment) {
		if (apiEmployment == null) return null;

		return CreditCheckRequest.Employment.builder()
				.employerName(apiEmployment.getEmployerName())
				.employerAddress(mapApplicantAddress(apiEmployment.getEmployerAddress()))
				.build();
	}

	/**
	 * Map inquiry purpose from API to domain model.
	 */
	private CreditCheckRequest.InquiryPurpose mapInquiryPurpose(InquiryPurpose apiInquiryPurpose) {
		if (apiInquiryPurpose == null) return null;

		return CreditCheckRequest.InquiryPurpose.builder()
				.purposeType(apiInquiryPurpose.getPurposeType())
				.terms(apiInquiryPurpose.getTerms())
				.amount(apiInquiryPurpose.getAmount())
				.build();
	}

	private CreditCheckRequest.DriverLicense mapDriverLicense(DriverLicense apiDriverLicense) {
		if (apiDriverLicense == null) return null;

		return CreditCheckRequest.DriverLicense.builder()
				.number(apiDriverLicense.getNumber())
				.state(apiDriverLicense.getState())
				.build();
	}

	private List<CreditCheckRequest.Phone> mapPhones(List<Phone> apiPhones) {
		if (apiPhones == null || apiPhones.isEmpty()) return null;

		return apiPhones.stream()
				.map(phone -> CreditCheckRequest.Phone.builder()
						.number(phone.getNumber())
						.type(
								phone.getType() != null
										? CreditCheckRequest.PhoneType.valueOf(
												phone.getType().toString())
										: null)
						.build())
				.collect(Collectors.toList());
	}

	private CreditCheckRequest.Address mapAddress(Address apiAddress, CreditCheckRequest.AddressType type) {
		if (apiAddress == null) return null;

		return CreditCheckRequest.Address.builder()
				.street(apiAddress.getStreet())
				.street2(apiAddress.getStreet2())
				.city(apiAddress.getCity())
				.state(apiAddress.getState())
				.zipCode(apiAddress.getZipCode())
				.country(apiAddress.getCountry())
				.type(type)
				.build();
	}

	private List<CreditCheckRequest.Address> mapPreviousAddresses(List<Address> apiAddresses) {
		if (apiAddresses == null || apiAddresses.isEmpty()) return null;

		return apiAddresses.stream()
				.map(addr -> mapAddress(addr, CreditCheckRequest.AddressType.PREVIOUS))
				.collect(Collectors.toList());
	}

	private CreditCheckRequest.EmploymentInfo mapEmployment(Employment apiEmployment) {
		if (apiEmployment == null) return null;

		return CreditCheckRequest.EmploymentInfo.builder()
				.employerName(apiEmployment.getEmployerName())
				.employerAddress(
						apiEmployment.getEmployerAddress() != null
								? mapAddress(apiEmployment.getEmployerAddress(), null)
								: null)
				.jobTitle(apiEmployment.getJobTitle())
				.annualIncome(apiEmployment.getAnnualIncome())
				.yearsEmployed(apiEmployment.getYearsEmployed())
				.build();
	}

	private CreditCheckRequest.SecondaryApplicant mapSecondaryApplicant(SecondaryApplicant apiSecondary) {
		if (apiSecondary == null) return null;

		return CreditCheckRequest.SecondaryApplicant.builder()
				.prefix(apiSecondary.getPrefix())
				.firstName(apiSecondary.getFirstName())
				.middleName(apiSecondary.getMiddleName())
				.lastName(apiSecondary.getLastName())
				.generationCode(
						apiSecondary.getGenerationCode() != null
								? apiSecondary.getGenerationCode().toString()
								: null)
				.dateOfBirth(apiSecondary.getDateOfBirth())
				.ssn(apiSecondary.getSsn())
				.driverLicense(mapDriverLicense(apiSecondary.getDriverLicense()))
				.phones(mapPhones(apiSecondary.getPhones()))
				.email(apiSecondary.getEmail())
				.employmentInfo(mapEmployment(apiSecondary.getEmployment()))
				.build();
	}

	private CreditCheckRequest.FreezeOverride mapFreezeOverride(FreezeOverride apiFreezeOverride) {
		if (apiFreezeOverride == null) return null;

		return CreditCheckRequest.FreezeOverride.builder()
				.primaryApplicantCode(apiFreezeOverride.getPrimaryApplicantCode())
				.secondaryApplicantCode(apiFreezeOverride.getSecondaryApplicantCode())
				.build();
	}

	/**
	 * Map domain response to API response DTO.
	 *
	 * Uses ObjectMapper to convert between domain and API models since they share
	 * the same structure (creditProfile, arf, tty).
	 *
	 * @param domainResponse the canonical credit check response
	 * @return API response DTO
	 */
	public CreditCheckApiResponse toApiResponse(CreditCheckResponse domainResponse) {
		log.debug("Mapping domain response to API response: success={}", domainResponse.getSuccess());

		// Use ObjectMapper to convert between matching structures
		CreditCheckApiResponse apiResponse = objectMapper.convertValue(domainResponse, CreditCheckApiResponse.class);

		log.debug("Successfully mapped domain response to API response");
		return apiResponse;
	}
}
