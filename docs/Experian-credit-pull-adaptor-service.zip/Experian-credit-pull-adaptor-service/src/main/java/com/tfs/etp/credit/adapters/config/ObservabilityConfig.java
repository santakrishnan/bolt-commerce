package com.tfs.etp.credit.adapters.config;

import io.micrometer.core.aop.TimedAspect;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Observability configuration for metrics and tracing.
 *
 * Enables:
 * - @Timed annotation support for method-level metrics
 * - Prometheus metrics export
 * - Distributed tracing correlation
 */
@Configuration
public class ObservabilityConfig {

	/**
	 * Enable @Timed aspect for method-level metrics collection.
	 */
	@Bean
	public TimedAspect timedAspect(MeterRegistry registry) {
		return new TimedAspect(registry);
	}
}
