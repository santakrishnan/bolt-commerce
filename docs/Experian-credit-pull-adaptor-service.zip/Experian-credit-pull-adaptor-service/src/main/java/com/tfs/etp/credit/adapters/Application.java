package com.tfs.etp.credit.adapters;

import lombok.CustomLog;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SuppressWarnings("PMD")
@SpringBootApplication
@EnableAsync
@CustomLog
public class Application {
	public static void main(final String[] args) {
		SpringApplication.run(Application.class, args);
		log.info("Credit Bureau Core Adapter Service started");
	}
}
