package com.tfs.etp.credit.adapters.domain.service;

import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest.VendorType;
import java.util.List;

/**
 * Strategy interface for vendor selection.
 *
 * Implementations can provide different strategies:
 * - COST_OPTIMIZED - select vendor based on cost per query
 * - ROUND_ROBIN - distribute requests evenly across vendors
 * - FAILOVER - use primary vendor, failover to secondary on error
 */
public interface VendorSelectionStrategy {

	/**
	 * Select a vendor from the list of available vendors.
	 *
	 * @param availableVendors list of vendors that are currently available
	 * @param request the credit check request (may influence selection)
	 * @return the selected vendor
	 */
	VendorType selectVendor(List<VendorType> availableVendors, CreditCheckRequest request);
}
