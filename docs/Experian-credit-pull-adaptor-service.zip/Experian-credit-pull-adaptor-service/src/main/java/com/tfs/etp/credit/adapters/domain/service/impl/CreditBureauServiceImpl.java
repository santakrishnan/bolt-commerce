package com.tfs.etp.credit.adapters.domain.service.impl;

import com.tfs.etp.credit.adapters.common.constants.LogMessageConstants;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest.VendorType;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckResponse;
import com.tfs.etp.credit.adapters.domain.port.CreditBureauVendorAdapter;
import com.tfs.etp.credit.adapters.domain.service.CreditBureauService;
import com.tfs.etp.credit.adapters.domain.service.VendorSelectionStrategy;
import com.tfs.etp.credit.adapters.exception.CreditBureauException;
import com.tfs.etp.credit.adapters.exception.ErrorContext;
import com.tfs.etp.credit.adapters.exception.ErrorType;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.CustomLog;
import org.springframework.stereotype.Service;

/**
 * Core orchestrator service implementation for credit bureau operations.
 *
 * This service acts as the main entry point for credit check requests.
 * It handles:
 * - Vendor selection based on strategy (preference, failover, cost-optimized)
 * - Request routing to the appropriate vendor adapter
 * - Response aggregation and normalization
 * - Metrics collection
 *
 * Caching logic is handled at the adapter level.
 */
@CustomLog
@Service
public class CreditBureauServiceImpl implements CreditBureauService {

	private final Map<VendorType, CreditBureauVendorAdapter> vendorAdapters;
	private final VendorSelectionStrategy vendorSelectionStrategy;
	private final MeterRegistry meterRegistry;

	public CreditBureauServiceImpl(
			List<CreditBureauVendorAdapter> adapters,
			VendorSelectionStrategy vendorSelectionStrategy,
			MeterRegistry meterRegistry) {
		this.vendorAdapters = adapters.stream()
				.collect(Collectors.toMap(CreditBureauVendorAdapter::getVendorType, Function.identity()));
		this.vendorSelectionStrategy = vendorSelectionStrategy;
		this.meterRegistry = meterRegistry;
		log.info(LogMessageConstants.INITIALIZED_CREDIT_BUREAU_CORE_SERVICE, vendorAdapters.keySet());
	}

	/**
	 * Execute a credit check request.
	 *
	 * The vendor is selected based on:
	 * 1. Customer preference (if specified)
	 * 2. Vendor availability (circuit breaker status)
	 * 3. Cost optimization strategy
	 *
	 * @param request the credit check request
	 * @return the credit check response
	 * @throws CreditBureauException if no vendor is available or the credit check fails
	 */
	@Override
	public CreditCheckResponse checkCredit(CreditCheckRequest request) {
		log.info(LogMessageConstants.PROCESSING_CREDIT_CHECK_REQUEST, request.getRequestId());

		VendorType selectedVendor = selectVendor(request);
		log.info(LogMessageConstants.SELECTED_VENDOR_FOR_REQUEST, selectedVendor, request.getRequestId());

		Timer.Sample timerSample = Timer.start(meterRegistry);

		try {
			CreditBureauVendorAdapter adapter = vendorAdapters.get(selectedVendor);
			if (adapter == null) {
				throw new CreditBureauException(
						ErrorType.VENDOR_UNAVAILABLE,
						"Selected vendor is not configured",
						ErrorContext.forVendor(selectedVendor.name()));
			}

			CreditCheckResponse response = adapter.checkCredit(request);

			timerSample.stop(Timer.builder("credit.check.duration")
					.tag("vendor", selectedVendor.name())
					.tag("status", "success")
					.register(meterRegistry));

			meterRegistry
					.counter("credit.check.requests", "vendor", selectedVendor.name(), "status", "success")
					.increment();

			// Extract score for logging (if available)
			String scoreValue = "N/A";
			if (response.getData() != null
					&& response.getData().getCreditProfile() != null
					&& !response.getData().getCreditProfile().isEmpty()) {
				var profile = response.getData().getCreditProfile().get(0);
				if (profile.getRiskModel() != null && !profile.getRiskModel().isEmpty()) {
					scoreValue = profile.getRiskModel().get(0).getScore();
				}
			}

			log.info(
					LogMessageConstants.CREDIT_CHECK_COMPLETED,
					request.getRequestId(),
					selectedVendor,
					scoreValue,
					"N/A");

			return response;

		} catch (CreditBureauException e) {
			timerSample.stop(Timer.builder("credit.check.duration")
					.tag("vendor", selectedVendor.name())
					.tag("status", "error")
					.register(meterRegistry));

			meterRegistry
					.counter(
							"credit.check.requests",
							"vendor",
							selectedVendor.name(),
							"status",
							"error",
							"error_code",
							e.getErrorType().getErrorCode())
					.increment();

			log.error(
					LogMessageConstants.CREDIT_CHECK_FAILED,
					request.getRequestId(),
					selectedVendor,
					e.getErrorType().getErrorCode(),
					e.getMessage());
			throw e;
		}
	}

	/**
	 * Select the appropriate vendor for the credit check.
	 */
	private VendorType selectVendor(CreditCheckRequest request) {
		// Priority 1: Customer preference
		if (request.getPreferredVendor() != null) {
			VendorType preferred = request.getPreferredVendor();
			CreditBureauVendorAdapter adapter = vendorAdapters.get(preferred);
			if (adapter != null && adapter.isAvailable()) {
				return preferred;
			}
			log.warn(LogMessageConstants.PREFERRED_VENDOR_UNAVAILABLE, preferred);
		}

		// Priority 2: Use vendor selection strategy
		List<VendorType> availableVendors = vendorAdapters.entrySet().stream()
				.filter(entry -> entry.getValue().isAvailable())
				.map(Map.Entry::getKey)
				.toList();

		if (availableVendors.isEmpty()) {
			throw new CreditBureauException(
					ErrorType.VENDOR_UNAVAILABLE,
					"No credit bureau vendors are currently available",
					ErrorContext.forVendor("ALL_VENDORS"));
		}

		return vendorSelectionStrategy.selectVendor(availableVendors, request);
	}

	/**
	 * Get the health status of all registered vendor adapters.
	 *
	 * @return map of vendor type to availability status
	 */
	@Override
	public Map<VendorType, Boolean> getVendorHealthStatus() {
		return vendorAdapters.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue()
				.isAvailable()));
	}
}
