package com.tfs.etp.credit.adapters.exception;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

/**
 * Enumeration of error types for the credit bureau adapter.
 *
 * Provides a standardized categorization of errors with associated HTTP status codes
 * and error codes for consistent error responses across all adapters.
 */
@Getter
@RequiredArgsConstructor
public enum ErrorType {

	// Validation Errors
	VALIDATION_ERROR(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR"),

	// Authentication/Authorization Errors
	AUTHENTICATION_ERROR(HttpStatus.BAD_GATEWAY, "AUTHENTICATION_ERROR"),

	// Vendor Errors
	VENDOR_UNAVAILABLE(HttpStatus.SERVICE_UNAVAILABLE, "VENDOR_UNAVAILABLE"),
	VENDOR_CLIENT_ERROR(HttpStatus.UNPROCESSABLE_ENTITY, "VENDOR_CLIENT_ERROR"),
	VENDOR_SERVER_ERROR(HttpStatus.BAD_GATEWAY, "VENDOR_SERVER_ERROR"),
	VENDOR_RATE_LIMITED(HttpStatus.TOO_MANY_REQUESTS, "VENDOR_RATE_LIMITED"),
	VENDOR_TIMEOUT(HttpStatus.GATEWAY_TIMEOUT, "VENDOR_TIMEOUT"),

	// Business Logic Errors
	BUSINESS_RULE_VIOLATION(HttpStatus.UNPROCESSABLE_ENTITY, "BUSINESS_RULE_VIOLATION"),

	// System Errors
	INTERNAL_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL_ERROR"),
	CONFIGURATION_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "CONFIGURATION_ERROR");

	private final HttpStatus httpStatus;
	private final String errorCode;

	public int getStatusCode() {
		return httpStatus.value();
	}
}
