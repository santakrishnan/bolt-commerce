package com.tfs.etp.credit.adapters.domain.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.tfs.enterpriseplatform.buildingblocks.logging.masking.annotations.MaskDOB;
import com.tfs.enterpriseplatform.buildingblocks.logging.masking.annotations.MaskEmail;
import com.tfs.enterpriseplatform.buildingblocks.logging.masking.annotations.MaskGeneric;
import com.tfs.enterpriseplatform.buildingblocks.logging.masking.annotations.MaskPhoneNumber;
import com.tfs.enterpriseplatform.buildingblocks.logging.masking.annotations.MaskSSN;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Canonical credit check request model.
 *
 * This is the normalized format used internally across all credit bureau vendors.
 * Each vendor adapter maps this canonical format to their specific API format.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreditCheckRequest {

	/**
	 * Unique identifier for the credit check request.
	 */
	private String requestId;

	/**
	 * Vendor identifier (EXPERIAN, etc.).
	 */
	private String vendor;

	/**
	 * Array of applicants (PRIMARY and CO-APPLICANT).
	 * This is the preferred format for multi-applicant requests.
	 */
	private List<Applicant> applicant;

	/**
	 * Inquiry purpose details (type, terms, amount).
	 */
	private InquiryPurpose inquiryPurpose;

	/**
	 * Personal information.
	 * @deprecated Use {@link #applicant} array instead
	 */
	@Deprecated
	private PersonalInfo personalInfo;

	/**
	 * Current address information.
	 * @deprecated Use {@link #applicant} array instead
	 */
	@Deprecated
	private Address currentAddress;

	/**
	 * Previous addresses (for better credit matching).
	 * @deprecated Use {@link #applicant} array instead
	 */
	@Deprecated
	private List<Address> previousAddresses;

	/**
	 * Legacy address field (deprecated - use currentAddress).
	 */
	@Deprecated
	private Address address;

	/**
	 * Employment information (optional).
	 * @deprecated Use {@link #applicant} array instead
	 */
	@Deprecated
	private EmploymentInfo employmentInfo;

	/**
	 * Secondary applicant (co-borrower) for joint applications.
	 * @deprecated Use {@link #applicant} array instead
	 */
	@Deprecated
	private SecondaryApplicant secondaryApplicant;

	/**
	 * Credit freeze override codes.
	 */
	private FreezeOverride freezeOverride;

	/**
	 * Preferred credit bureau vendor.
	 * @deprecated Use {@link #vendor} instead
	 */
	@Deprecated
	private VendorType preferredVendor;

	/**
	 * Request metadata.
	 */
	private RequestMetadata metadata;

	/**
	 * Timestamp when the request was created.
	 */
	private LocalDateTime requestTimestamp;

	// ═══════════════════════════════════════════
	// New Applicant-based Structure
	// ═══════════════════════════════════════════

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Applicant {
		/**
		 * Type of applicant (PRIMARY or CO-APPLICANT).
		 */
		private ApplicantType applicantType;

		@MaskGeneric
		private String firstName;

		@MaskGeneric
		private String lastName;

		@MaskGeneric
		private String middleName;

		@MaskGeneric
		private String suffix;

		@MaskDOB
		private LocalDate dateOfBirth;

		@MaskSSN
		private String ssn;

		private Address currentAddress;

		private List<Address> previousAddresses;

		private List<Phone> phones;

		private DriverLicense driversLicense;

		private Employment employment;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class InquiryPurpose {
		/**
		 * Purpose type code (e.g., "3F" for credit application).
		 */
		private String purposeType;

		/**
		 * Terms in months (e.g., "012").
		 */
		private String terms;

		/**
		 * Loan amount for the inquiry (e.g., "150" for $150,000).
		 */
		private String amount;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Employment {
		@MaskGeneric
		private String employerName;

		private Address employerAddress;
	}

	// ═══════════════════════════════════════════
	// Legacy Structure (Deprecated)
	// ═══════════════════════════════════════════

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class PersonalInfo {
		@MaskGeneric
		private String prefix;

		@MaskGeneric
		private String firstName;

		@MaskGeneric
		private String middleName;

		@MaskGeneric
		private String lastName;

		@MaskGeneric
		private String generationCode;

		@MaskGeneric
		@Deprecated
		private String suffix;

		@MaskDOB
		private LocalDate dateOfBirth;

		@MaskSSN
		private String ssn;

		private DriverLicense driverLicense;

		private List<Phone> phones;

		@MaskPhoneNumber
		@Deprecated
		private String phoneNumber;

		@MaskEmail
		private String email;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Address {
		@MaskGeneric
		@JsonAlias({"addressLine1", "line1"})
		private String street;

		@MaskGeneric
		@JsonAlias({"addressLine2", "line2"})
		private String street2;

		private String city;
		private String state;
		private String zipCode;
		private String country;
		private AddressType type;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class EmploymentInfo {
		@MaskGeneric
		private String employerName;

		private Address employerAddress;

		@MaskGeneric
		private String jobTitle;

		@MaskGeneric
		private Double annualIncome;

		private Integer yearsEmployed;

		@MaskPhoneNumber
		private String employerPhone;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class DriverLicense {
		@MaskGeneric
		private String number;

		private String state;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Phone {
		@MaskPhoneNumber
		private String number;

		private PhoneType type;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class SecondaryApplicant {
		@MaskGeneric
		private String prefix;

		@MaskGeneric
		private String firstName;

		@MaskGeneric
		private String middleName;

		@MaskGeneric
		private String lastName;

		@MaskGeneric
		private String generationCode;

		@MaskDOB
		private LocalDate dateOfBirth;

		@MaskSSN
		private String ssn;

		private DriverLicense driverLicense;

		private List<Phone> phones;

		@MaskEmail
		private String email;

		private EmploymentInfo employmentInfo;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class FreezeOverride {
		@MaskGeneric
		private String primaryApplicantCode;

		@MaskGeneric
		private String secondaryApplicantCode;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class RequestMetadata {
		private String sourceSystem;
		private String userId;
		private String sessionId;

		@MaskGeneric
		private String ipAddress;

		private String userAgent;
		private String traceId;
	}

	public enum AddressType {
		CURRENT,
		PREVIOUS,
		MAILING
	}

	public enum PhoneType {
		mobile,
		home,
		work
	}

	public enum VendorType {
		EXPERIAN
	}

	public enum ApplicantType {
		PRIMARY,
		CO_APPLICANT
	}
}
