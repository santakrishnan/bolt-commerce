package com.tfs.etp.credit.adapters.exception;

import java.util.Collections;
import java.util.Map;
import lombok.Builder;
import lombok.Getter;
import lombok.Singular;

/**
 * Context object that captures additional error details from vendor-specific errors.
 *
 * This class provides a flexible way to capture vendor-specific error information
 * without coupling the exception handling to specific vendor error formats.
 */
@Getter
@Builder
public class ErrorContext {

	/**
	 * The vendor name (e.g., "EXPERIAN", "EQUIFAX").
	 */
	private final String vendorName;

	/**
	 * HTTP status code from the vendor API (if applicable).
	 */
	private final Integer httpStatusCode;

	/**
	 * Vendor-specific error code.
	 */
	private final String vendorErrorCode;

	/**
	 * Vendor-specific error message.
	 */
	private final String vendorErrorMessage;

	/**
	 * Additional metadata about the error.
	 */
	@Singular("metadatum")
	private final Map<String, String> metadata;

	/**
	 * Field-level validation errors (field name -> error message).
	 */
	@Singular("fieldError")
	private final Map<String, String> fieldErrors;

	/**
	 * Returns a read-only view of metadata.
	 */
	public Map<String, String> getMetadata() {
		return metadata != null ? Collections.unmodifiableMap(metadata) : Collections.emptyMap();
	}

	/**
	 * Returns a read-only view of field errors.
	 */
	public Map<String, String> getFieldErrors() {
		return fieldErrors != null ? Collections.unmodifiableMap(fieldErrors) : Collections.emptyMap();
	}

	/**
	 * Creates a simple error context with just vendor name.
	 */
	public static ErrorContext forVendor(String vendorName) {
		return ErrorContext.builder().vendorName(vendorName).build();
	}

	/**
	 * Creates an error context for vendor API errors.
	 */
	public static ErrorContext forVendorApiError(
			String vendorName, int httpStatusCode, String errorCode, String errorMessage) {
		return ErrorContext.builder()
				.vendorName(vendorName)
				.httpStatusCode(httpStatusCode)
				.vendorErrorCode(errorCode)
				.vendorErrorMessage(errorMessage)
				.build();
	}

	/**
	 * Creates an error context for validation errors with field-level details.
	 */
	public static ErrorContext forValidation(Map<String, String> fieldErrors) {
		return ErrorContext.builder().fieldErrors(fieldErrors).build();
	}
}
