package com.tfs.etp.credit.adapters.domain.service.impl;

import com.tfs.etp.credit.adapters.common.constants.LogMessageConstants;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest.VendorType;
import com.tfs.etp.credit.adapters.domain.service.VendorSelectionStrategy;
import com.tfs.etp.credit.adapters.exception.CreditBureauException;
import com.tfs.etp.credit.adapters.exception.ErrorType;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import lombok.CustomLog;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Default vendor selection strategy implementation.
 *
 * Supports configurable strategies:
 * - COST_OPTIMIZED - prefers Experian
 * - ROUND_ROBIN - distributes evenly across available vendors
 * - FAILOVER - uses default vendor, falls back to others
 */
@CustomLog
@Component
public class VendorSelectionStrategyImpl implements VendorSelectionStrategy {

	private static final List<VendorType> COST_ORDER = List.of(VendorType.EXPERIAN);

	private final String strategy;
	private final VendorType defaultVendor;
	private final AtomicInteger roundRobinCounter = new AtomicInteger(0);

	public VendorSelectionStrategyImpl(
			@Value("${credit-bureau.vendor-selection.strategy:COST_OPTIMIZED}") String strategy,
			@Value("${credit-bureau.vendor-selection.default-vendor:EXPERIAN}") String defaultVendor) {
		this.strategy = strategy;
		this.defaultVendor = VendorType.valueOf(defaultVendor);
	}

	@Override
	public VendorType selectVendor(List<VendorType> availableVendors, CreditCheckRequest request) {
		if (availableVendors.isEmpty()) {
			throw new CreditBureauException(ErrorType.INTERNAL_ERROR, "No available vendors for selection");
		}

		if (availableVendors.size() == 1) {
			return availableVendors.getFirst();
		}

		return switch (strategy) {
			case "ROUND_ROBIN" -> selectRoundRobin(availableVendors);
			case "FAILOVER" -> selectFailover(availableVendors);
			case "COST_OPTIMIZED" -> selectCostOptimized(availableVendors);
			default -> selectCostOptimized(availableVendors);
		};
	}

	private VendorType selectRoundRobin(List<VendorType> availableVendors) {
		int index = Math.abs(roundRobinCounter.getAndIncrement() % availableVendors.size());
		VendorType selected = availableVendors.get(index);
		log.debug(LogMessageConstants.ROUND_ROBIN_SELECTED_VENDOR, selected);
		return selected;
	}

	private VendorType selectFailover(List<VendorType> availableVendors) {
		if (availableVendors.contains(defaultVendor)) {
			return defaultVendor;
		}
		VendorType fallback = availableVendors.getFirst();
		log.info(LogMessageConstants.DEFAULT_VENDOR_FAILOVER, defaultVendor, fallback);
		return fallback;
	}

	private VendorType selectCostOptimized(List<VendorType> availableVendors) {
		return COST_ORDER.stream()
				.filter(availableVendors::contains)
				.findFirst()
				.orElse(availableVendors.getFirst());
	}
}
