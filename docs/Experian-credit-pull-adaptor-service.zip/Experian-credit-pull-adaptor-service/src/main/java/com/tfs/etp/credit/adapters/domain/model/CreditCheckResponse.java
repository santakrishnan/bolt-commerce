package com.tfs.etp.credit.adapters.domain.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Standard API response wrapper for credit check.
 *
 * Follows common REST API pattern with success, message, and data fields.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreditCheckResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("success")
	private Boolean success;

	@JsonProperty("message")
	private String message;

	@JsonProperty("data")
	private CreditReportData data;

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class CreditReportData implements Serializable {

		@JsonProperty("creditProfile")
		private List<CreditProfile> creditProfile;

		@JsonProperty("arf")
		private Arf arf;

		@JsonProperty("tty")
		private Tty tty;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class CreditProfile implements Serializable {

		@JsonProperty("addressInformation")
		private List<AddressInformation> addressInformation;

		@JsonProperty("consumerAssistanceReferralAddress")
		private ConsumerAssistanceReferralAddress consumerAssistanceReferralAddress;

		@JsonProperty("consumerIdentity")
		private ConsumerIdentity consumerIdentity;

		@JsonProperty("directCheck")
		private List<DirectCheck> directCheck;

		@JsonProperty("employmentInformation")
		private List<EmploymentInformation> employmentInformation;

		@JsonProperty("fraudShield")
		private List<FraudShield> fraudShield;

		@JsonProperty("informationalMessage")
		private List<InformationalMessage> informationalMessage;

		@JsonProperty("inquiry")
		private List<Inquiry> inquiry;

		@JsonProperty("mla")
		private Mla mla;

		@JsonProperty("ofac")
		private List<Ofac> ofac;

		@JsonProperty("summaries")
		private List<Summary> summaries;

		@JsonProperty("publicRecord")
		private List<PublicRecord> publicRecord;

		@JsonProperty("staggSelect")
		private StaggSelect staggSelect;

		@JsonProperty("riskModel")
		private List<RiskModel> riskModel;

		@JsonProperty("ssn")
		private List<SsnInfo> ssn;

		@JsonProperty("statement")
		private List<Statement> statement;

		@JsonProperty("tradeline")
		private List<Tradeline> tradeline;

		@JsonProperty("uniqueConsumerIdentifier")
		private UniqueConsumerIdentifier uniqueConsumerIdentifier;

		@JsonProperty("clarityAttributes")
		private Map<String, Object> clarityAttributes;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class AddressInformation implements Serializable {
		private String censusGeoCode;
		private String city;
		private String countyCode;
		private String dwellingType;
		private String firstReportedDate;
		private String lastReportingSubscriberCode;
		private String lastUpdatedDate;
		private String msaCode;
		private String source;
		private String state;
		private String stateCode;
		private String streetName;
		private String streetPrefix;
		private String streetSuffix;
		private String timesReported;
		private String unitId;
		private String unitType;
		private String zipCode;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class ConsumerAssistanceReferralAddress implements Serializable {
		private String cityStateZip;
		private String officeName;
		private String phone;
		private String poBox;
		private String streetName;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class ConsumerIdentity implements Serializable {
		private List<ConsumerName> name;
		private List<ConsumerPhone> phone;
		private ConsumerDob dob;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class ConsumerName implements Serializable {
		private String firstName;
		private String generationCode;
		private String middleName;
		private String secondSurname;
		private String surname;
		private String type;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class ConsumerPhone implements Serializable {
		private String number;
		private String source;
		private String type;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class ConsumerDob implements Serializable {
		private String day;
		private String month;
		private String year;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class DirectCheck implements Serializable {
		private String subscriberAddress;
		private String subscriberCity;
		private String subscriberCode;
		private String subscriberName;
		private String subscriberPhone;
		private String subscriberState;
		private String subscriberZipCode;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class EmploymentInformation implements Serializable {
		private String addressExtraLine;
		private String addressFirstLine;
		private String addressSecondLine;
		private String firstReportedDate;
		private String lastUpdatedDate;
		private String name;
		private String source;
		private String zipCode;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class FraudShield implements Serializable {
		private String addressCount;
		private String addressDate;
		private String addressErrorCode;
		private String dateOfBirth;
		private String dateOfDeath;
		private FraudShieldIndicators fraudShieldIndicators;
		private String sic;
		private String socialCount;
		private String socialDate;
		private String socialErrorCode;
		private String ssnFirstPossibleIssuanceYear;
		private String ssnLastPossibleIssuanceYear;
		private String text;
		private String type;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class FraudShieldIndicators implements Serializable {
		private List<String> indicator;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class InformationalMessage implements Serializable {
		private String messageNumber;
		private String messageNumberDetailed;
		private String messageText;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Inquiry implements Serializable {
		private String amount;
		private String date;
		private String kob;
		private String subscriberCode;
		private String subscriberName;
		private String terms;
		private String type;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Mla implements Serializable {
		private String messageNumber;
		private String messageText;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Ofac implements Serializable {
		private String messageNumber;
		private String messageText;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Summary implements Serializable {
		private String summaryType;
		private List<SummaryAttribute> attributes;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class SummaryAttribute implements Serializable {
		private String id;
		private String value;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class PublicRecord implements Serializable {
		private String adjustmentPercent;
		private String amount;
		private String bankruptcyAssetAmount;
		private String bankruptcyVoluntaryIndicator;
		private String bookPageSequence;
		private String consumerComment;
		private String courtCode;
		private String courtName;
		private String disputeFlag;
		private String ecoa;
		private String evaluation;
		private String filingDate;
		private String plaintiffName;
		private String referenceNumber;
		private String repaymentPercent;
		private String status;
		private String statusDate;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class StaggSelect implements Serializable {
		private String message;
		private List<ModelAttribute> modelAttributes;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class ModelAttribute implements Serializable {
		private String modelTypeIndicator;
		private String variableName;
		private String signofAttribute;
		private String attributeValue;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class RiskModel implements Serializable {
		private String evaluation;
		private String grade;
		private String modelIndicator;
		private String score;
		private List<ScoreFactor> scoreFactors;
		private String scorePercentile;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class ScoreFactor implements Serializable {
		private String importance;
		private String code;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class SsnInfo implements Serializable {
		private String number;
		private String ssnIndicators;
		private String variationIndicator;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Statement implements Serializable {
		private String dateReported;
		private String statementText;
		private String type;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Tradeline implements Serializable {
		private String accountType;
		private String amount1;
		private String amount1Qualifier;
		private String amount2;
		private String amount2Qualifier;
		private String amountBalloonPayment;
		private String amountPastDue;
		private String balanceAmount;
		private String balanceDate;
		private String bankruptcyChapterNumber;
		private String consumerComment;
		private String consumerDisputeFlag;
		private String datePaymentDue;
		private String delinquencies30Days;
		private String delinquencies60Days;
		private String delinquencies90to180Days;
		private String derogCounter;
		private String ecoa;
		private EnhancedPaymentData enhancedPaymentData;
		private String evaluation;
		private String kob;
		private String lastPaymentDate;
		private String maxDelinquencyDate;
		private String monthlyPaymentAmount;
		private String monthlyPaymentType;
		private String monthsHistory;
		private String openDate;
		private String openOrClosed;
		private String originalCreditorName;
		private String paymentHistory;
		private String revolvingOrInstallment;
		private String soldToName;
		private String specialComment;
		private String status;
		private String statusDate;
		private String subscriberCode;
		private String subscriberName;
		private String terms;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class EnhancedPaymentData implements Serializable {
		private String actualPaymentAmount;
		private String chargeoffAmount;
		private String ciiCode;
		private String complianceCondition;
		private String creditLimitAmount;
		private String enhancedAccountCondition;
		private String enhancedAccountType;
		private String enhancedPaymentHistory84;
		private String enhancedPaymentStatus;
		private String enhancedSpecialComment;
		private String enhancedTerms;
		private String enhancedTermsFrequency;
		private String firstDelinquencyDate;
		private String highBalanceAmount;
		private String maxDelinquencyCode;
		private String mortgageId;
		private String originalCreditorClassificationCode;
		private String originalLoanAmount;
		private String paymentLevelDate;
		private String purchasedPortfolioFromName;
		private String secondDelinquencyDate;
		private String secondaryAgencyCode;
		private String secondaryAgencyId;
		private String specialPaymentAmount;
		private String specialPaymentCode;
		private String specialPaymentDate;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class UniqueConsumerIdentifier implements Serializable {
		private String value;
		private String verificationIndicator;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Arf implements Serializable {
		private String arfResponse;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Tty implements Serializable {
		private String ttyResponse;
	}
}
