package com.tfs.etp.credit.adapters.domain.service;

import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest.VendorType;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckResponse;
import com.tfs.etp.credit.adapters.exception.CreditBureauException;
import java.util.Map;

/**
 * Service interface for credit bureau operations.
 *
 * This service acts as the main entry point for credit check requests.
 * It handles:
 * - Vendor selection based on strategy (preference, failover, cost-optimized)
 * - Request routing to the appropriate vendor adapter
 * - Response aggregation and normalization
 * - Metrics collection
 */
public interface CreditBureauService {

	/**
	 * Execute a credit check request.
	 *
	 * The vendor is selected based on:
	 * 1. Customer preference (if specified)
	 * 2. Vendor availability (circuit breaker status)
	 * 3. Cost optimization strategy
	 *
	 * @param request the credit check request
	 * @return the credit check response
	 * @throws CreditBureauException if no vendor is available or the credit check fails
	 */
	CreditCheckResponse checkCredit(CreditCheckRequest request);

	/**
	 * Get the health status of all registered vendor adapters.
	 *
	 * @return map of vendor type to availability status
	 */
	Map<VendorType, Boolean> getVendorHealthStatus();
}
