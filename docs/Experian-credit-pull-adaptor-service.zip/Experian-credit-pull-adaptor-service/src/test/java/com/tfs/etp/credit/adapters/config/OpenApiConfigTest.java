package com.tfs.etp.credit.adapters.config;

import static org.assertj.core.api.Assertions.assertThat;

import io.swagger.v3.oas.models.OpenAPI;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

@DisplayName("OpenApiConfig Tests")
class OpenApiConfigTest {

	@Test
	@DisplayName("Should use configured local and production servers with normalized context path")
	void shouldUseConfiguredLocalAndProductionServersWithNormalizedContextPath() {
		OpenApiProperties properties = buildProperties();
		properties.getServers().setLocal("http://dev.example.com");
		properties.getServers().setProduction("https://prod.example.com");

		OpenApiConfig config = new OpenApiConfig(properties);
		ReflectionTestUtils.setField(config, "serverPort", 9090);
		ReflectionTestUtils.setField(config, "contextPath", "/credit/");

		OpenAPI api = config.creditBureauOpenAPI();

		assertThat(api.getInfo().getTitle()).isEqualTo("Credit Bureau API");
		assertThat(api.getServers()).hasSize(2);
		assertThat(api.getServers().get(0).getUrl()).isEqualTo("http://dev.example.com/credit");
		assertThat(api.getServers().get(1).getUrl()).isEqualTo("https://prod.example.com/credit");
	}

	@Test
	@DisplayName("Should fall back to localhost when local server is not configured")
	void shouldFallbackToLocalhostWhenLocalServerIsNotConfigured() {
		OpenApiProperties properties = buildProperties();
		properties.getServers().setLocal(null);
		properties.getServers().setProduction("https://prod.example.com");

		OpenApiConfig config = new OpenApiConfig(properties);
		ReflectionTestUtils.setField(config, "serverPort", 8085);
		ReflectionTestUtils.setField(config, "contextPath", "/api");

		OpenAPI api = config.creditBureauOpenAPI();

		assertThat(api.getServers().get(0).getUrl()).isEqualTo("http://localhost:8085/api");
		assertThat(api.getServers().get(1).getUrl()).isEqualTo("https://prod.example.com/api");
	}

	@Test
	@DisplayName("Should preserve root context path slash")
	void shouldPreserveRootContextPathSlash() {
		OpenApiProperties properties = buildProperties();
		properties.getServers().setLocal("http://localhost:8080");
		properties.getServers().setProduction("https://prod.example.com");

		OpenApiConfig config = new OpenApiConfig(properties);
		ReflectionTestUtils.setField(config, "serverPort", 8080);
		ReflectionTestUtils.setField(config, "contextPath", "/");

		OpenAPI api = config.creditBureauOpenAPI();

		assertThat(api.getServers().get(0).getUrl()).isEqualTo("http://localhost:8080/");
		assertThat(api.getServers().get(1).getUrl()).isEqualTo("https://prod.example.com/");
	}

	private OpenApiProperties buildProperties() {
		OpenApiProperties properties = new OpenApiProperties();
		properties.getInfo().setTitle("Credit Bureau API");
		properties.getInfo().setDescription("API description");
		properties.getInfo().setVersion("1.0.0");
		properties.getInfo().getContact().setName("Team");
		properties.getInfo().getContact().setEmail("team@example.com");
		properties.getInfo().getLicense().setName("MIT");
		properties.getInfo().getLicense().setUrl("https://example.com/license");
		return properties;
	}
}
