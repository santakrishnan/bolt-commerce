package com.tfs.etp.credit.adapters.domain.service.impl;

import static org.assertj.core.api.Assertions.*;

import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest.VendorType;
import com.tfs.etp.credit.adapters.exception.CreditBureauException;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("VendorSelectionStrategyImpl Tests")
class VendorSelectionStrategyImplTest {

	private CreditCheckRequest dummyRequest;

	@BeforeEach
	void setUp() {
		dummyRequest = CreditCheckRequest.builder().requestId("test-001").build();
	}

	@Test
	@DisplayName("Should select by cost optimization - prefer Experian")
	void shouldSelectCostOptimized() {
		VendorSelectionStrategyImpl strategy = new VendorSelectionStrategyImpl("COST_OPTIMIZED", "EXPERIAN");

		VendorType selected = strategy.selectVendor(List.of(VendorType.EXPERIAN, VendorType.EXPERIAN), dummyRequest);

		assertThat(selected).isEqualTo(VendorType.EXPERIAN);
	}

	@Test
	@DisplayName("Should select round-robin")
	void shouldSelectRoundRobin() {
		VendorSelectionStrategyImpl strategy = new VendorSelectionStrategyImpl("ROUND_ROBIN", "EXPERIAN");

		List<VendorType> vendors = List.of(VendorType.EXPERIAN, VendorType.EXPERIAN);

		VendorType first = strategy.selectVendor(vendors, dummyRequest);
		VendorType second = strategy.selectVendor(vendors, dummyRequest);

		assertThat(first).isEqualTo(second);
	}

	@Test
	@DisplayName("Should failover to default vendor")
	void shouldFailoverToDefault() {
		VendorSelectionStrategyImpl strategy = new VendorSelectionStrategyImpl("FAILOVER", "EXPERIAN");

		VendorType selected = strategy.selectVendor(List.of(VendorType.EXPERIAN, VendorType.EXPERIAN), dummyRequest);

		assertThat(selected).isEqualTo(VendorType.EXPERIAN);
	}

	@Test
	@DisplayName("Should use cost optimized as default for unknown strategy")
	void shouldUseCostOptimizedForUnknownStrategy() {
		VendorSelectionStrategyImpl strategy = new VendorSelectionStrategyImpl("UNKNOWN", "EXPERIAN");

		VendorType selected = strategy.selectVendor(List.of(VendorType.EXPERIAN, VendorType.EXPERIAN), dummyRequest);

		assertThat(selected).isEqualTo(VendorType.EXPERIAN);
	}

	@Test
	@DisplayName("Should return default vendor")
	void shouldReturnDefaultVendor() {
		VendorSelectionStrategyImpl strategy = new VendorSelectionStrategyImpl("FAILOVER", "EXPERIAN");

		VendorType selected = strategy.selectVendor(List.of(VendorType.EXPERIAN), dummyRequest);

		assertThat(selected).isEqualTo(VendorType.EXPERIAN);
	}

	@Test
	@DisplayName("Should return only vendor when single vendor available")
	void shouldReturnSingleVendor() {
		VendorSelectionStrategyImpl strategy = new VendorSelectionStrategyImpl("COST_OPTIMIZED", "EXPERIAN");

		VendorType selected = strategy.selectVendor(List.of(VendorType.EXPERIAN), dummyRequest);

		assertThat(selected).isEqualTo(VendorType.EXPERIAN);
	}

	@Test
	@DisplayName("Should throw on empty vendor list")
	void shouldThrowOnEmptyList() {
		VendorSelectionStrategyImpl strategy = new VendorSelectionStrategyImpl("COST_OPTIMIZED", "EXPERIAN");

		assertThatThrownBy(() -> strategy.selectVendor(List.of(), dummyRequest))
				.isInstanceOf(CreditBureauException.class)
				.hasMessageContaining("No available vendors for selection");
	}
}
