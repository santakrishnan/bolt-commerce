package com.tfs.etp.credit.adapters.domain.model;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("CreditCheckRequest enum tests")
class CreditCheckRequestEnumTest {

	@Test
	@DisplayName("Should expose all address type values")
	void shouldExposeAddressTypeValues() {
		assertThat(CreditCheckRequest.AddressType.values())
				.containsExactly(
						CreditCheckRequest.AddressType.CURRENT,
						CreditCheckRequest.AddressType.PREVIOUS,
						CreditCheckRequest.AddressType.MAILING);
	}
}
