package com.tfs.etp.credit.adapters.api.mapper;

import static org.assertj.core.api.Assertions.*;

import com.tfs.etp.credit.adapters.api.generated.model.Applicant;
import com.tfs.etp.credit.adapters.api.generated.model.ApplicantAddress;
import com.tfs.etp.credit.adapters.api.generated.model.ApplicantEmployment;
import com.tfs.etp.credit.adapters.api.generated.model.CreditCheckApiRequest;
import com.tfs.etp.credit.adapters.api.generated.model.DriverLicense;
import com.tfs.etp.credit.adapters.api.generated.model.InquiryPurpose;
import com.tfs.etp.credit.adapters.api.generated.model.Phone;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@DisplayName("ApiRequestMapper - New Applicant Array Format Tests")
class ApiRequestMapperApplicantArrayTest {

	@Autowired
	private ApiRequestMapper mapper;

	@Test
	@DisplayName("Should map new applicant array format with PRIMARY applicant")
	void shouldMapNewFormatWithPrimaryApplicant() {
		// Create PRIMARY applicant using OpenAPI generated models
		Applicant primaryApplicant = new Applicant()
				.applicantType(Applicant.ApplicantTypeEnum.PRIMARY)
				.firstName("JOHN")
				.lastName("SMITH")
				.middleName("A")
				.suffix("Jr")
				.dateOfBirth(LocalDate.of(1985, 6, 15))
				.ssn("123456789")
				.currentAddress(new ApplicantAddress()
						.addressLine1("456 OAK AVE")
						.addressLine2("APT 7B")
						.city("LOS ANGELES")
						.state("CA")
						.zipCode("90001"))
				.previousAddresses(List.of(new ApplicantAddress()
						.addressLine1("789 ELM ST")
						.addressLine2("APT 5C")
						.city("SAN FRANCISCO")
						.state("CA")
						.zipCode("94102")))
				.phones(List.of(
						new Phone().number("5551234567").type(Phone.TypeEnum.HOME),
						new Phone().number("5559876543").type(Phone.TypeEnum.MOBILE)))
				.driversLicense(new DriverLicense().number("D12345678").state("CA"))
				.employment(new ApplicantEmployment()
						.employerName("ACME CORPORATION")
						.employerAddress(new ApplicantAddress()
								.addressLine1("100 MAIN ST")
								.addressLine2("SUITE 200")
								.city("SAN JOSE")
								.state("CA")
								.zipCode("95101")));

		// Create API request with new structure
		CreditCheckApiRequest apiRequest = new CreditCheckApiRequest()
				.requestId("req-2026-0305-abc123")
				.vendor(CreditCheckApiRequest.VendorEnum.EXPERIAN)
				.applicant(List.of(primaryApplicant))
				.inquiryPurpose(
						new InquiryPurpose().purposeType("3F").terms("012").amount("150"));

		// Map to domain model
		CreditCheckRequest domainRequest = mapper.toDomainRequest(apiRequest);

		// Verify mapping
		assertThat(domainRequest).isNotNull();
		assertThat(domainRequest.getRequestId()).isEqualTo("req-2026-0305-abc123");
		assertThat(domainRequest.getVendor()).isEqualTo("EXPERIAN");
		assertThat(domainRequest.getApplicant()).hasSize(1);

		// Verify primary applicant
		CreditCheckRequest.Applicant mappedPrimary =
				domainRequest.getApplicant().get(0);
		assertThat(mappedPrimary.getApplicantType()).isEqualTo(CreditCheckRequest.ApplicantType.PRIMARY);
		assertThat(mappedPrimary.getFirstName()).isEqualTo("JOHN");
		assertThat(mappedPrimary.getLastName()).isEqualTo("SMITH");
		assertThat(mappedPrimary.getMiddleName()).isEqualTo("A");
		assertThat(mappedPrimary.getSuffix()).isEqualTo("Jr");
		assertThat(mappedPrimary.getDateOfBirth()).isEqualTo(LocalDate.of(1985, 6, 15));
		assertThat(mappedPrimary.getSsn()).isEqualTo("123456789");

		// Verify address
		assertThat(mappedPrimary.getCurrentAddress()).isNotNull();
		assertThat(mappedPrimary.getCurrentAddress().getStreet()).isEqualTo("456 OAK AVE");
		assertThat(mappedPrimary.getCurrentAddress().getStreet2()).isEqualTo("APT 7B");
		assertThat(mappedPrimary.getCurrentAddress().getCity()).isEqualTo("LOS ANGELES");
		assertThat(mappedPrimary.getCurrentAddress().getState()).isEqualTo("CA");
		assertThat(mappedPrimary.getCurrentAddress().getZipCode()).isEqualTo("90001");

		// Verify previous addresses
		assertThat(mappedPrimary.getPreviousAddresses()).hasSize(1);
		assertThat(mappedPrimary.getPreviousAddresses().get(0).getStreet()).isEqualTo("789 ELM ST");

		// Verify phones
		assertThat(mappedPrimary.getPhones()).hasSize(2);
		assertThat(mappedPrimary.getPhones().get(0).getNumber()).isEqualTo("5551234567");
		assertThat(mappedPrimary.getPhones().get(0).getType()).isEqualTo(CreditCheckRequest.PhoneType.home);
		assertThat(mappedPrimary.getPhones().get(1).getNumber()).isEqualTo("5559876543");
		assertThat(mappedPrimary.getPhones().get(1).getType()).isEqualTo(CreditCheckRequest.PhoneType.mobile);

		// Verify driver's license
		assertThat(mappedPrimary.getDriversLicense()).isNotNull();
		assertThat(mappedPrimary.getDriversLicense().getNumber()).isEqualTo("D12345678");
		assertThat(mappedPrimary.getDriversLicense().getState()).isEqualTo("CA");

		// Verify employment
		assertThat(mappedPrimary.getEmployment()).isNotNull();
		assertThat(mappedPrimary.getEmployment().getEmployerName()).isEqualTo("ACME CORPORATION");
		assertThat(mappedPrimary.getEmployment().getEmployerAddress()).isNotNull();
		assertThat(mappedPrimary.getEmployment().getEmployerAddress().getStreet())
				.isEqualTo("100 MAIN ST");

		// Verify inquiry purpose
		assertThat(domainRequest.getInquiryPurpose()).isNotNull();
		assertThat(domainRequest.getInquiryPurpose().getPurposeType()).isEqualTo("3F");
		assertThat(domainRequest.getInquiryPurpose().getTerms()).isEqualTo("012");
		assertThat(domainRequest.getInquiryPurpose().getAmount()).isEqualTo("150");
	}

	@Test
	@DisplayName("Should map new format with both PRIMARY and CO-APPLICANT")
	void shouldMapNewFormatWithPrimaryAndCoApplicant() {
		// Create PRIMARY applicant
		Applicant primaryApplicant = new Applicant()
				.applicantType(Applicant.ApplicantTypeEnum.PRIMARY)
				.firstName("JOHN")
				.lastName("SMITH")
				.middleName("A")
				.suffix("Jr")
				.dateOfBirth(LocalDate.of(1985, 6, 15))
				.ssn("123456789")
				.currentAddress(new ApplicantAddress()
						.addressLine1("456 OAK AVE")
						.addressLine2("APT 7B")
						.city("LOS ANGELES")
						.state("CA")
						.zipCode("90001"))
				.phones(List.of(new Phone().number("5551234567").type(Phone.TypeEnum.HOME)))
				.driversLicense(new DriverLicense().number("D12345678").state("CA"))
				.employment(new ApplicantEmployment().employerName("ACME CORPORATION"));

		// Create CO-APPLICANT
		Applicant coApplicant = new Applicant()
				.applicantType(Applicant.ApplicantTypeEnum.CO_APPLICANT)
				.firstName("JANE")
				.lastName("SMITH")
				.dateOfBirth(LocalDate.of(1987, 3, 22))
				.ssn("987654321")
				.currentAddress(new ApplicantAddress()
						.addressLine1("456 OAK AVE")
						.addressLine2("APT 7B")
						.city("LOS ANGELES")
						.state("CA")
						.zipCode("90001"));

		// Create API request
		CreditCheckApiRequest apiRequest = new CreditCheckApiRequest()
				.requestId("req-2026-0305-002")
				.vendor(CreditCheckApiRequest.VendorEnum.EXPERIAN)
				.applicant(List.of(primaryApplicant, coApplicant))
				.inquiryPurpose(
						new InquiryPurpose().purposeType("3F").terms("012").amount("150"));

		// Map to domain model
		CreditCheckRequest domainRequest = mapper.toDomainRequest(apiRequest);

		// Verify both applicants were mapped
		assertThat(domainRequest.getApplicant()).hasSize(2);

		// Verify primary applicant
		CreditCheckRequest.Applicant mappedPrimary =
				domainRequest.getApplicant().get(0);
		assertThat(mappedPrimary.getApplicantType()).isEqualTo(CreditCheckRequest.ApplicantType.PRIMARY);
		assertThat(mappedPrimary.getFirstName()).isEqualTo("JOHN");

		// Verify co-applicant
		CreditCheckRequest.Applicant mappedCoApplicant =
				domainRequest.getApplicant().get(1);
		assertThat(mappedCoApplicant.getApplicantType()).isEqualTo(CreditCheckRequest.ApplicantType.CO_APPLICANT);
		assertThat(mappedCoApplicant.getFirstName()).isEqualTo("JANE");
		assertThat(mappedCoApplicant.getLastName()).isEqualTo("SMITH");
		assertThat(mappedCoApplicant.getDateOfBirth()).isEqualTo(LocalDate.of(1987, 3, 22));
		assertThat(mappedCoApplicant.getSsn()).isEqualTo("987654321");
	}

	@Test
	@DisplayName("Should handle minimal applicant with only required fields")
	void shouldHandleMinimalApplicant() {
		// Create minimal PRIMARY applicant
		Applicant primaryApplicant = new Applicant()
				.applicantType(Applicant.ApplicantTypeEnum.PRIMARY)
				.firstName("JOHN")
				.lastName("SMITH")
				.dateOfBirth(LocalDate.of(1985, 6, 15))
				.ssn("123456789");

		CreditCheckApiRequest apiRequest = new CreditCheckApiRequest()
				.requestId("req-minimal")
				.vendor(CreditCheckApiRequest.VendorEnum.EXPERIAN)
				.applicant(List.of(primaryApplicant));

		// Map to domain model
		CreditCheckRequest domainRequest = mapper.toDomainRequest(apiRequest);

		// Verify basic mapping
		assertThat(domainRequest).isNotNull();
		assertThat(domainRequest.getApplicant()).hasSize(1);
		CreditCheckRequest.Applicant mapped = domainRequest.getApplicant().get(0);
		assertThat(mapped.getFirstName()).isEqualTo("JOHN");
		assertThat(mapped.getLastName()).isEqualTo("SMITH");

		// Verify optional fields are null
		assertThat(mapped.getCurrentAddress()).isNull();
		assertThat(mapped.getPreviousAddresses()).isNull();
		assertThat(mapped.getPhones()).isNull();
		assertThat(mapped.getDriversLicense()).isNull();
		assertThat(mapped.getEmployment()).isNull();
	}
}
