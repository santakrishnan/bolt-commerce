package com.tfs.etp.credit.adapters.api.mapper;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tfs.etp.credit.adapters.api.generated.model.Address;
import com.tfs.etp.credit.adapters.api.generated.model.CreditCheckApiRequest;
import com.tfs.etp.credit.adapters.api.generated.model.CreditCheckApiResponse;
import com.tfs.etp.credit.adapters.api.generated.model.DriverLicense;
import com.tfs.etp.credit.adapters.api.generated.model.Employment;
import com.tfs.etp.credit.adapters.api.generated.model.FreezeOverride;
import com.tfs.etp.credit.adapters.api.generated.model.InquiryPurpose;
import com.tfs.etp.credit.adapters.api.generated.model.Phone;
import com.tfs.etp.credit.adapters.api.generated.model.SecondaryApplicant;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckResponse;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

@DisplayName("ApiRequestMapper Additional Unit Tests")
class ApiRequestMapperAdditionalTest {

	private final ApiRequestMapper mapper = new ApiRequestMapper(new ObjectMapper());

	@Test
	@DisplayName("Should create minimal domain request when applicant array is missing")
	void shouldBuildMinimalDomainRequestWhenApplicantMissing() {
		CreditCheckApiRequest request = new CreditCheckApiRequest()
				.requestId("req-123")
				.vendor(CreditCheckApiRequest.VendorEnum.EXPERIAN)
				.inquiryPurpose(
						new InquiryPurpose().purposeType("3F").terms("012").amount("150"));

		var result = mapper.toDomainRequest(request);

		assertThat(result).isNotNull();
		assertThat(result.getRequestId()).isEqualTo("req-123");
		assertThat(result.getVendor()).isEqualTo("EXPERIAN");
		assertThat(result.getApplicant()).isNull();
		assertThat(result.getInquiryPurpose()).isNotNull();
		assertThat(result.getInquiryPurpose().getPurposeType()).isEqualTo("3F");
		assertThat(result.getFreezeOverride()).isNull();
		assertThat(result.getRequestTimestamp()).isNotNull();
	}

	@Test
	@DisplayName("Should generate requestId when missing")
	void shouldGenerateRequestIdWhenMissing() {
		CreditCheckApiRequest request = new CreditCheckApiRequest().vendor(CreditCheckApiRequest.VendorEnum.EXPERIAN);

		var result = mapper.toDomainRequest(request);

		assertThat(result.getRequestId()).isNotBlank();
		assertThat(result.getVendor()).isEqualTo("EXPERIAN");
	}

	@Test
	@DisplayName("Should map null vendor when absent")
	void shouldMapNullVendorWhenAbsent() {
		CreditCheckApiRequest request = new CreditCheckApiRequest().requestId("req-null-vendor");

		var result = mapper.toDomainRequest(request);

		assertThat(result.getVendor()).isNull();
	}

	@Test
	@DisplayName("Should map domain response to API response")
	void shouldMapToApiResponse() {
		CreditCheckResponse domainResponse =
				CreditCheckResponse.builder().success(true).message("ok").build();

		CreditCheckApiResponse apiResponse = mapper.toApiResponse(domainResponse);

		assertThat(apiResponse).isNotNull();
		assertThat(apiResponse.getSuccess()).isTrue();
		assertThat(apiResponse.getMessage()).isEqualTo("ok");
	}

	@Test
	@DisplayName("Should map legacy address helper and previous addresses")
	void shouldMapLegacyAddressHelpers() {
		Address address = new Address()
				.street("100 Main")
				.street2("Suite 2")
				.city("Plano")
				.state("TX")
				.zipCode("75024")
				.country("US");

		CreditCheckRequest.Address mapped =
				ReflectionTestUtils.invokeMethod(mapper, "mapAddress", address, CreditCheckRequest.AddressType.CURRENT);
		assertThat(mapped).isNotNull();
		assertThat(mapped.getStreet()).isEqualTo("100 Main");
		assertThat(mapped.getType()).isEqualTo(CreditCheckRequest.AddressType.CURRENT);

		List<CreditCheckRequest.Address> previous =
				ReflectionTestUtils.invokeMethod(mapper, "mapPreviousAddresses", List.of(address));
		assertThat(previous).hasSize(1);
		assertThat(previous.get(0).getType()).isEqualTo(CreditCheckRequest.AddressType.PREVIOUS);

		Object nullAddress = ReflectionTestUtils.invokeMethod(mapper, "mapAddress", null, null);
		Object noPreviousAddresses = ReflectionTestUtils.invokeMethod(mapper, "mapPreviousAddresses", List.of());
		assertThat(nullAddress).isNull();
		assertThat(noPreviousAddresses).isNull();
	}

	@Test
	@DisplayName("Should map employment, secondary applicant and freeze override helpers")
	void shouldMapLegacySecondaryAndFreezeHelpers() {
		Employment employment = new Employment()
				.employerName("ACME")
				.jobTitle("Engineer")
				.annualIncome(125000.0)
				.yearsEmployed(4)
				.employerAddress(
						new Address().street("200 Legacy").city("Irving").state("TX"));

		CreditCheckRequest.EmploymentInfo employmentInfo =
				ReflectionTestUtils.invokeMethod(mapper, "mapEmployment", employment);
		assertThat(employmentInfo).isNotNull();
		assertThat(employmentInfo.getEmployerName()).isEqualTo("ACME");
		assertThat(employmentInfo.getEmployerAddress()).isNotNull();

		SecondaryApplicant secondaryApplicant = new SecondaryApplicant()
				.prefix("Mr")
				.firstName("John")
				.middleName("Q")
				.lastName("Public")
				.generationCode(SecondaryApplicant.GenerationCodeEnum.values()[0])
				.dateOfBirth(LocalDate.of(1990, 1, 1))
				.ssn("123456789")
				.driverLicense(new DriverLicense().number("D111").state("TX"))
				.phones(List.of(new Phone().number("5551112222").type(Phone.TypeEnum.HOME)))
				.email("john@example.com")
				.employment(employment);

		CreditCheckRequest.SecondaryApplicant mappedSecondary =
				ReflectionTestUtils.invokeMethod(mapper, "mapSecondaryApplicant", secondaryApplicant);
		assertThat(mappedSecondary).isNotNull();
		assertThat(mappedSecondary.getGenerationCode()).isNotBlank();
		assertThat(mappedSecondary.getDriverLicense()).isNotNull();
		assertThat(mappedSecondary.getEmploymentInfo()).isNotNull();

		FreezeOverride freezeOverride =
				new FreezeOverride().primaryApplicantCode("P1").secondaryApplicantCode("S1");
		CreditCheckRequest.FreezeOverride mappedFreeze =
				ReflectionTestUtils.invokeMethod(mapper, "mapFreezeOverride", freezeOverride);
		assertThat(mappedFreeze).isNotNull();
		assertThat(mappedFreeze.getPrimaryApplicantCode()).isEqualTo("P1");

		Object nullEmployment = ReflectionTestUtils.invokeMethod(mapper, "mapEmployment", new Object[] {null});
		Object nullSecondary = ReflectionTestUtils.invokeMethod(mapper, "mapSecondaryApplicant", new Object[] {null});
		Object nullFreezeOverride = ReflectionTestUtils.invokeMethod(mapper, "mapFreezeOverride", new Object[] {null});
		assertThat(nullEmployment).isNull();
		assertThat(nullSecondary).isNull();
		assertThat(nullFreezeOverride).isNull();
	}
}
