package com.tfs.etp.credit.adapters.domain.service.impl;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckRequest.VendorType;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckResponse;
import com.tfs.etp.credit.adapters.domain.port.CreditBureauVendorAdapter;
import com.tfs.etp.credit.adapters.domain.service.CreditBureauService;
import com.tfs.etp.credit.adapters.domain.service.VendorSelectionStrategy;
import com.tfs.etp.credit.adapters.exception.CreditBureauException;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
@DisplayName("CreditBureauService Tests")
class CreditBureauServiceImplTest {

	@Mock
	private CreditBureauVendorAdapter experianAdapter;

	@Mock
	private VendorSelectionStrategy vendorSelectionStrategy;

	private MeterRegistry meterRegistry;
	private CreditBureauService service;

	@BeforeEach
	void setUp() {
		meterRegistry = new SimpleMeterRegistry();
		when(experianAdapter.getVendorType()).thenReturn(VendorType.EXPERIAN);
		service = new CreditBureauServiceImpl(List.of(experianAdapter), vendorSelectionStrategy, meterRegistry);
	}

	private CreditCheckRequest createTestRequest() {
		return CreditCheckRequest.builder()
				.requestId("test-req-001")
				.personalInfo(CreditCheckRequest.PersonalInfo.builder()
						.firstName("John")
						.lastName("Doe")
						.dateOfBirth(LocalDate.of(1990, 1, 15))
						.ssn("123-45-6789")
						.build())
				.address(CreditCheckRequest.Address.builder()
						.street("123 Main St")
						.city("New York")
						.state("NY")
						.zipCode("10001")
						.build())
				.build();
	}

	private CreditCheckResponse createTestResponse() {
		// Create a minimal response structure
		CreditCheckResponse.ConsumerIdentity consumerIdentity =
				CreditCheckResponse.ConsumerIdentity.builder().build();

		CreditCheckResponse.CreditProfile creditProfile = CreditCheckResponse.CreditProfile.builder()
				.consumerIdentity(consumerIdentity)
				.build();

		CreditCheckResponse.CreditReportData creditReportData = CreditCheckResponse.CreditReportData.builder()
				.creditProfile(List.of(creditProfile))
				.build();

		return CreditCheckResponse.builder()
				.success(true)
				.message("Credit check completed successfully")
				.data(creditReportData)
				.build();
	}

	@Nested
	@DisplayName("Credit Check Tests")
	class CreditCheckTests {

		@Test
		@DisplayName("Should execute credit check with preferred vendor")
		void shouldCheckCreditWithPreferredVendor() {
			CreditCheckRequest request = createTestRequest();
			request.setPreferredVendor(VendorType.EXPERIAN);
			CreditCheckResponse expectedResponse = createTestResponse();

			when(experianAdapter.isAvailable()).thenReturn(true);
			when(experianAdapter.checkCredit(any())).thenReturn(expectedResponse);

			CreditCheckResponse response = service.checkCredit(request);

			assertThat(response).isNotNull();
			assertThat(response.getSuccess()).isTrue();
			assertThat(response.getData()).isNotNull();
			verify(experianAdapter).checkCredit(request);
		}

		@Test
		@DisplayName("Should throw when preferred vendor is unavailable")
		void shouldThrowWhenPreferredVendorUnavailable() {
			CreditCheckRequest request = createTestRequest();
			request.setPreferredVendor(VendorType.EXPERIAN);

			when(experianAdapter.isAvailable()).thenReturn(false);

			assertThatThrownBy(() -> service.checkCredit(request)).isInstanceOf(CreditBureauException.class);
		}

		@Test
		@DisplayName("Should use vendor selection strategy when no preference")
		void shouldUseStrategyWhenNoPreference() {
			CreditCheckRequest request = createTestRequest();
			CreditCheckResponse expectedResponse = createTestResponse();

			when(experianAdapter.isAvailable()).thenReturn(true);
			when(vendorSelectionStrategy.selectVendor(any(), any())).thenReturn(VendorType.EXPERIAN);
			when(experianAdapter.checkCredit(any())).thenReturn(expectedResponse);

			CreditCheckResponse response = service.checkCredit(request);

			assertThat(response).isNotNull();
			verify(vendorSelectionStrategy).selectVendor(any(), any());
		}

		@Test
		@DisplayName("Should throw when no vendors available")
		void shouldThrowWhenNoVendorsAvailable() {
			CreditCheckRequest request = createTestRequest();

			when(experianAdapter.isAvailable()).thenReturn(false);

			assertThatThrownBy(() -> service.checkCredit(request)).isInstanceOf(CreditBureauException.class);
		}

		@Test
		@DisplayName("Should collect success metrics on successful credit check")
		void shouldCollectSuccessMetrics() {
			CreditCheckRequest request = createTestRequest();
			request.setPreferredVendor(VendorType.EXPERIAN);
			CreditCheckResponse expectedResponse = createTestResponse();

			when(experianAdapter.isAvailable()).thenReturn(true);
			when(experianAdapter.checkCredit(any())).thenReturn(expectedResponse);

			service.checkCredit(request);

			assertThat(meterRegistry
							.counter("credit.check.requests", "vendor", "EXPERIAN", "status", "success")
							.count())
					.isEqualTo(1.0);
		}

		@Test
		@DisplayName("Should catch and rethrow CreditBureauException with error metrics")
		void shouldCatchAndRethrowCreditBureauExceptionWithErrorMetrics() {
			CreditCheckRequest request = createTestRequest();
			request.setPreferredVendor(VendorType.EXPERIAN);

			CreditBureauException vendorFailure = new CreditBureauException(
					com.tfs.etp.credit.adapters.exception.ErrorType.VENDOR_SERVER_ERROR,
					"Vendor failure",
					com.tfs.etp.credit.adapters.exception.ErrorContext.forVendor("EXPERIAN"));

			when(experianAdapter.isAvailable()).thenReturn(true);
			when(experianAdapter.checkCredit(any())).thenThrow(vendorFailure);

			assertThatThrownBy(() -> service.checkCredit(request)).isSameAs(vendorFailure);

			assertThat(meterRegistry
							.counter(
									"credit.check.requests",
									"vendor",
									"EXPERIAN",
									"status",
									"error",
									"error_code",
									"VENDOR_SERVER_ERROR")
							.count())
					.isEqualTo(1.0);
		}

		@Test
		@DisplayName("Should log score extraction branch when risk model exists")
		void shouldCoverScoreExtractionBranchWhenRiskModelExists() {
			CreditCheckRequest request = createTestRequest();
			request.setPreferredVendor(VendorType.EXPERIAN);

			CreditCheckResponse responseWithScore = CreditCheckResponse.builder()
					.success(true)
					.message("ok")
					.data(CreditCheckResponse.CreditReportData.builder()
							.creditProfile(List.of(CreditCheckResponse.CreditProfile.builder()
									.riskModel(List.of(CreditCheckResponse.RiskModel.builder()
											.score("733")
											.build()))
									.build()))
							.build())
					.build();

			when(experianAdapter.isAvailable()).thenReturn(true);
			when(experianAdapter.checkCredit(any())).thenReturn(responseWithScore);

			CreditCheckResponse actual = service.checkCredit(request);

			assertThat(actual).isNotNull();
			assertThat(actual.getData()).isNotNull();
			assertThat(actual.getData().getCreditProfile()).hasSize(1);
			assertThat(actual.getData().getCreditProfile().get(0).getRiskModel())
					.hasSize(1);
			assertThat(actual.getData()
							.getCreditProfile()
							.get(0)
							.getRiskModel()
							.get(0)
							.getScore())
					.isEqualTo("733");
		}
	}

	@Nested
	@DisplayName("Vendor Health Tests")
	class VendorHealthTests {

		@Test
		@DisplayName("Should return health status for all vendors")
		void shouldReturnVendorHealth() {
			when(experianAdapter.isAvailable()).thenReturn(true);

			var health = service.getVendorHealthStatus();

			assertThat(health).containsKey(VendorType.EXPERIAN);
			assertThat(health.get(VendorType.EXPERIAN)).isTrue();
		}

		@Test
		@DisplayName("Should throw when preferred vendor is configured but adapter is missing")
		void shouldThrowWhenPreferredVendorAdapterMissing() {
			CreditBureauService missingAdapterService =
					new CreditBureauServiceImpl(List.of(), vendorSelectionStrategy, meterRegistry);

			CreditCheckRequest request = createTestRequest();
			request.setPreferredVendor(VendorType.EXPERIAN);

			assertThatThrownBy(() -> missingAdapterService.checkCredit(request))
					.isInstanceOf(CreditBureauException.class)
					.hasMessageContaining("No credit bureau vendors are currently available");
		}
	}
}
