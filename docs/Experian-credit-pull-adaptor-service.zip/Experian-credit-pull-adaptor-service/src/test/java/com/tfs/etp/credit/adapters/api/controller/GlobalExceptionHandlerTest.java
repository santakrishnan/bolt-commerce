package com.tfs.etp.credit.adapters.api.controller;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.tfs.etp.credit.adapters.api.generated.model.ApiErrorResponse;
import com.tfs.etp.credit.adapters.exception.CreditBureauException;
import com.tfs.etp.credit.adapters.exception.ErrorContext;
import com.tfs.etp.credit.adapters.exception.ErrorType;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

@DisplayName("GlobalExceptionHandler Unit Tests")
class GlobalExceptionHandlerTest {

	private GlobalExceptionHandler handler;
	private MockHttpServletRequest request;

	@BeforeEach
	void setUp() {
		handler = new GlobalExceptionHandler();
		request = new MockHttpServletRequest();
		request.setRequestURI("/api/v1/credit-bureau/check");
	}

	@Test
	@DisplayName("Should handle HttpMessageNotReadableException with invalid format details")
	void shouldHandleHttpMessageNotReadableWithInvalidFormat() {
		InvalidFormatException ife = InvalidFormatException.from(null, "Invalid value", "abc", Integer.class);
		ife.prependPath(new Object(), "applicantType");
		HttpMessageNotReadableException ex = new HttpMessageNotReadableException("Malformed JSON", ife);

		ResponseEntity<ApiErrorResponse> response = handler.handleHttpMessageNotReadable(ex, request);

		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
		assertThat(response.getBody()).isNotNull();
		assertThat(response.getBody().getSuccess()).isFalse();
		assertThat(response.getBody().getMessage()).isEqualTo("Invalid request format");
		assertThat(response.getBody().getError().getErrorCode()).isEqualTo("VALIDATION_ERROR");
		assertThat(response.getBody().getError().getFieldErrors()).hasSize(1);
		assertThat(response.getBody().getError().getFieldErrors().get(0).getField())
				.isEqualTo("applicantType");
	}

	@Test
	@DisplayName("Should handle MethodArgumentTypeMismatchException")
	void shouldHandleTypeMismatch() {
		MethodArgumentTypeMismatchException ex =
				new MethodArgumentTypeMismatchException("abc", Integer.class, "pageSize", null, null);

		ResponseEntity<ApiErrorResponse> response = handler.handleTypeMismatch(ex, request);

		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
		assertThat(response.getBody()).isNotNull();
		assertThat(response.getBody().getError().getErrorCode()).isEqualTo("VALIDATION_ERROR");
		assertThat(response.getBody().getError().getFieldErrors()).hasSize(1);
		assertThat(response.getBody().getError().getFieldErrors().get(0).getField())
				.isEqualTo("pageSize");
	}

	@Test
	@DisplayName("Should map CreditBureauException with full context and field errors")
	void shouldHandleCreditBureauExceptionWithContext() {
		ErrorContext context = ErrorContext.builder()
				.vendorName("EXPERIAN")
				.httpStatusCode(422)
				.vendorErrorCode("X001")
				.vendorErrorMessage("Invalid input")
				.metadatum("traceId", "t-123")
				.fieldError("ssn", "Invalid SSN")
				.build();

		CreditBureauException ex =
				new CreditBureauException(ErrorType.VENDOR_CLIENT_ERROR, "Client side issue", context);

		ResponseEntity<ApiErrorResponse> response = handler.handleCreditBureauException(ex, request);

		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY);
		assertThat(response.getBody()).isNotNull();
		assertThat(response.getBody().getMessage()).isEqualTo("Client side issue");
		assertThat(response.getBody().getError().getErrorCode()).isEqualTo("VENDOR_CLIENT_ERROR");
		assertThat(response.getBody().getError().getDetail()).contains("Vendor: EXPERIAN");
		assertThat(response.getBody().getError().getDetail()).contains("Status: 422");
		assertThat(response.getBody().getError().getDetail()).contains("Code: X001");
		assertThat(response.getBody().getError().getDetail()).contains("Message: Invalid input");
		assertThat(response.getBody().getError().getDetail()).contains("traceId: t-123");
		assertThat(response.getBody().getError().getFieldErrors()).hasSize(1);
	}

	@Test
	@DisplayName("Should handle CreditBureauException without context")
	void shouldHandleCreditBureauExceptionWithoutContext() {
		CreditBureauException ex = new CreditBureauException(ErrorType.VENDOR_UNAVAILABLE, "Vendor down");

		ResponseEntity<ApiErrorResponse> response = handler.handleCreditBureauException(ex, request);

		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE);
		assertThat(response.getBody()).isNotNull();
		assertThat(response.getBody().getError().getErrorCode()).isEqualTo("VENDOR_UNAVAILABLE");
		assertThat(response.getBody().getError().getDetail()).isNull();
	}

	@Test
	@DisplayName("Should handle unexpected exception")
	void shouldHandleUnexpectedException() {
		RuntimeException ex = new RuntimeException("boom");

		ResponseEntity<ApiErrorResponse> response = handler.handleUnexpectedException(ex, request);

		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
		assertThat(response.getBody()).isNotNull();
		assertThat(response.getBody().getSuccess()).isFalse();
		assertThat(response.getBody().getError().getErrorCode()).isEqualTo("INTERNAL_ERROR");
	}

	@Test
	@DisplayName("Should preserve validation field errors from context helper")
	void shouldHandleValidationContextFieldErrors() {
		ErrorContext context = ErrorContext.forValidation(Map.of("dateOfBirth", "Invalid date"));
		CreditBureauException ex = new CreditBureauException(ErrorType.VALIDATION_ERROR, "Validation failed", context);

		ResponseEntity<ApiErrorResponse> response = handler.handleCreditBureauException(ex, request);

		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
		assertThat(response.getBody()).isNotNull();
		assertThat(response.getBody().getError().getFieldErrors()).hasSize(1);
		assertThat(response.getBody().getError().getFieldErrors().get(0).getField())
				.isEqualTo("dateOfBirth");
	}

	@Test
	@DisplayName("Should handle MethodArgumentNotValidException")
	void shouldHandleValidationErrors() {
		MethodArgumentNotValidException ex = Mockito.mock(MethodArgumentNotValidException.class);
		BindingResult bindingResult = new BeanPropertyBindingResult(new Object(), "request");
		bindingResult.addError(new FieldError("request", "firstName", "must not be blank"));
		// SSN is now optional, so we do not add a validation error for it
		Mockito.when(ex.getBindingResult()).thenReturn(bindingResult);

		ResponseEntity<ApiErrorResponse> response = handler.handleValidationErrors(ex, request);

		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
		assertThat(response.getBody()).isNotNull();
		assertThat(response.getBody().getError().getErrorCode()).isEqualTo("VALIDATION_ERROR");
		assertThat(response.getBody().getError().getFieldErrors()).hasSize(1);
	}
}
