package com.tfs.etp.credit.adapters.exception;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("ErrorContext and CreditBureauException Tests")
class ErrorContextAndCreditBureauExceptionTest {

	@Test
	@DisplayName("Should build vendor context from helper")
	void shouldBuildVendorContext() {
		ErrorContext context = ErrorContext.forVendor("EXPERIAN");
		assertThat(context.getVendorName()).isEqualTo("EXPERIAN");
		assertThat(context.getMetadata()).isEmpty();
		assertThat(context.getFieldErrors()).isEmpty();
	}

	@Test
	@DisplayName("Should build vendor API error context from helper")
	void shouldBuildVendorApiErrorContext() {
		ErrorContext context = ErrorContext.forVendorApiError("EXPERIAN", 503, "E503", "Service unavailable");
		assertThat(context.getVendorName()).isEqualTo("EXPERIAN");
		assertThat(context.getHttpStatusCode()).isEqualTo(503);
		assertThat(context.getVendorErrorCode()).isEqualTo("E503");
		assertThat(context.getVendorErrorMessage()).isEqualTo("Service unavailable");
	}

	@Test
	@DisplayName("Should build validation context from helper")
	void shouldBuildValidationContext() {
		ErrorContext context = ErrorContext.forValidation(Map.of("ssn", "invalid"));
		assertThat(context.getFieldErrors()).containsEntry("ssn", "invalid");
		assertThat(context.getMetadata()).isEmpty();
	}

	@Test
	@DisplayName("Should expose convenience getters from exception context")
	void shouldExposeExceptionConvenienceGetters() {
		ErrorContext context = ErrorContext.builder()
				.vendorName("EXPERIAN")
				.httpStatusCode(422)
				.vendorErrorCode("X001")
				.vendorErrorMessage("Bad input")
				.build();

		CreditBureauException exception =
				new CreditBureauException(ErrorType.VENDOR_CLIENT_ERROR, "Client error", context);

		assertThat(exception.getErrorType()).isEqualTo(ErrorType.VENDOR_CLIENT_ERROR);
		assertThat(exception.getVendorName()).isEqualTo("EXPERIAN");
		assertThat(exception.getHttpStatusCode()).isEqualTo(422);
		assertThat(exception.getVendorErrorCode()).isEqualTo("X001");
		assertThat(exception.getVendorErrorMessage()).isEqualTo("Bad input");
	}

	@Test
	@DisplayName("Should return null convenience getters when context missing")
	void shouldReturnNullGettersWithoutContext() {
		CreditBureauException exception = new CreditBureauException(ErrorType.INTERNAL_ERROR, "boom");
		assertThat(exception.getVendorName()).isNull();
		assertThat(exception.getHttpStatusCode()).isNull();
		assertThat(exception.getVendorErrorCode()).isNull();
		assertThat(exception.getVendorErrorMessage()).isNull();
	}
}
