package com.tfs.etp.credit.adapters.api.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.tfs.etp.credit.adapters.api.generated.model.Applicant;
import com.tfs.etp.credit.adapters.api.generated.model.ApplicantAddress;
import com.tfs.etp.credit.adapters.api.generated.model.CreditCheckApiRequest;
import com.tfs.etp.credit.adapters.api.mapper.ApiRequestMapper;
import com.tfs.etp.credit.adapters.domain.model.CreditCheckResponse;
import com.tfs.etp.credit.adapters.domain.service.CreditBureauService;
import com.tfs.etp.credit.adapters.exception.CreditBureauException;
import com.tfs.etp.credit.adapters.exception.ErrorContext;
import com.tfs.etp.credit.adapters.exception.ErrorType;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.oauth2.client.servlet.OAuth2ClientAutoConfiguration;
import org.springframework.boot.autoconfigure.security.oauth2.client.servlet.OAuth2ClientWebSecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityFilterAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(
		controllers = CreditBureauController.class,
		excludeAutoConfiguration = {
			SecurityAutoConfiguration.class,
			SecurityFilterAutoConfiguration.class,
			OAuth2ClientAutoConfiguration.class,
			OAuth2ClientWebSecurityAutoConfiguration.class
		})
@Import({ApiRequestMapper.class, GlobalExceptionHandler.class})
@DisplayName("CreditBureauController Tests")
class CreditBureauControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private CreditBureauService creditBureauService;

	private ObjectMapper objectMapper;

	@BeforeEach
	void setUp() {
		objectMapper = new ObjectMapper();
		objectMapper.registerModule(new JavaTimeModule());
	}

	private CreditCheckApiRequest createValidRequest() {
		ApplicantAddress address = new ApplicantAddress();
		address.setAddressLine1("123 Main St");
		address.setCity("New York");
		address.setState("NY");
		address.setZipCode("10001");

		Applicant applicant = new Applicant();
		applicant.setApplicantType(Applicant.ApplicantTypeEnum.PRIMARY);
		applicant.setFirstName("John");
		applicant.setLastName("Doe");
		applicant.setDateOfBirth(LocalDate.of(1990, 1, 15));
		applicant.setSsn("123456789");
		applicant.setCurrentAddress(address);

		CreditCheckApiRequest request = new CreditCheckApiRequest();
		request.setRequestId("test-request-123");
		request.setVendor(CreditCheckApiRequest.VendorEnum.EXPERIAN);
		request.setApplicant(List.of(applicant));
		return request;
	}

	private CreditCheckResponse createSuccessResponse() {
		// Create a minimal ConsumerIdentity with required fields
		CreditCheckResponse.ConsumerIdentity consumerIdentity =
				CreditCheckResponse.ConsumerIdentity.builder().build();

		// Create a CreditProfile
		CreditCheckResponse.CreditProfile creditProfile = CreditCheckResponse.CreditProfile.builder()
				.consumerIdentity(consumerIdentity)
				.build();

		// Create CreditReportData with the credit profile
		CreditCheckResponse.CreditReportData creditReportData = CreditCheckResponse.CreditReportData.builder()
				.creditProfile(List.of(creditProfile))
				.build();

		// Return the complete response
		return CreditCheckResponse.builder()
				.success(true)
				.message("Credit check completed successfully")
				.data(creditReportData)
				.build();
	}

	@Nested
	@DisplayName("POST /api/v1/credit-bureau/check")
	class CreditCheckEndpointTests {

		@Test
		@DisplayName("Should return 200 with credit check response on valid request")
		void shouldReturnSuccessOnValidRequest() throws Exception {
			when(creditBureauService.checkCredit(any())).thenReturn(createSuccessResponse());

			mockMvc.perform(post("/api/v1/credit-bureau/check")
							.contentType(MediaType.APPLICATION_JSON)
							.content(objectMapper.writeValueAsString(createValidRequest())))
					.andExpect(status().isOk())
					.andExpect(jsonPath("$.success").value(true))
					.andExpect(jsonPath("$.message").value("Credit check completed successfully"))
					.andExpect(jsonPath("$.data").exists())
					.andExpect(jsonPath("$.data.creditProfile").isArray());
		}

		@Test
		@DisplayName("Should return 400 on missing required fields")
		void shouldReturn400OnMissingFields() throws Exception {
			CreditCheckApiRequest invalidRequest = new CreditCheckApiRequest();

			mockMvc.perform(post("/api/v1/credit-bureau/check")
							.contentType(MediaType.APPLICATION_JSON)
							.content(objectMapper.writeValueAsString(invalidRequest)))
					.andExpect(status().isBadRequest())
					.andExpect(jsonPath("$.error.errorCode").value("VALIDATION_ERROR"))
					.andExpect(jsonPath("$.error.fieldErrors").isArray());
		}

		@Test
		@DisplayName("Should return 400 on invalid SSN format")
		void shouldReturn400OnInvalidSsn() throws Exception {
			CreditCheckApiRequest request = createValidRequest();
			request.getApplicant().get(0).setSsn("invalid-ssn");

			mockMvc.perform(post("/api/v1/credit-bureau/check")
							.contentType(MediaType.APPLICATION_JSON)
							.content(objectMapper.writeValueAsString(request)))
					.andExpect(status().isBadRequest())
					.andExpect(jsonPath("$.error.errorCode").value("VALIDATION_ERROR"));
		}

		@Test
		@DisplayName("Should return 503 when vendor is unavailable")
		void shouldReturn503WhenVendorUnavailable() throws Exception {
			when(creditBureauService.checkCredit(any()))
					.thenThrow(new CreditBureauException(
							ErrorType.VENDOR_UNAVAILABLE,
							"Vendor service is unavailable",
							ErrorContext.forVendor("EXPERIAN")));

			mockMvc.perform(post("/api/v1/credit-bureau/check")
							.contentType(MediaType.APPLICATION_JSON)
							.content(objectMapper.writeValueAsString(createValidRequest())))
					.andExpect(status().isServiceUnavailable())
					.andExpect(jsonPath("$.error.errorCode").value("VENDOR_UNAVAILABLE"));
		}
	}
}
