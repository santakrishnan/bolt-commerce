package com.tfs.etp.buildingblocks.creditbureaucoreadapterservice;

import com.tfs.etp.credit.adapters.Application;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = Application.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ApplicationTest {
	@Test
	void contextLoads() {}
}
