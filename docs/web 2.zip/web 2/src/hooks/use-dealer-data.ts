import { useMemo } from "react";
import { useLocation } from "~/components/providers/location-provider";
import type { DealerInfo, DealerNotes } from "~/lib/data/dealer/dealer-data";
import { getDealerDataByZip, sampleDealerNotes } from "~/lib/data/dealer/dealer-data";

/**
 * useDealerData
 *
 * Reactively derives dealer info and dealer notes from the active zip code.
 *
 * The zip is sourced from `LocationProvider`, which reads the `arrow_manual_zip`
 * cookie whenever a user manually sets a zip in the location block. When no
 * manual override is set it falls back to the fingerprint-detected zip (or
 * the app default).
 *
 * Each time the user changes their zip, this hook re-runs and returns the
 * matching entry from mock-dealers-by-zip.json, ensuring the dealer section
 * always reflects the currently selected location.
 */
export function useDealerData(): {
  dealerInfo: DealerInfo;
  dealerNotes: DealerNotes;
  isLoading: boolean;
} {
  const {
    state: { displayZip, isManualZip },
  } = useLocation();

  // Derive the current dealer data synchronously from the active zip so
  // callers have immediate data on each render. The lookup is local JSON
  // today; if this becomes async in the future we can reintroduce a
  // loading state and fetch logic then.
  const data = useMemo<{ dealerInfo: DealerInfo; dealerNotes: DealerNotes }>(
    () =>
      isManualZip
        ? getDealerDataByZip(displayZip)
        : { dealerInfo: sampleDealerNotes.dealer, dealerNotes: sampleDealerNotes },
    [displayZip, isManualZip]
  );

  return useMemo(
    () => ({ dealerInfo: data.dealerInfo, dealerNotes: data.dealerNotes, isLoading: false }),
    [data]
  );
}
