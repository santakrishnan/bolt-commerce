"use client";

import Image from "next/image";
import { ActionCard } from "~/components/shared/action-card";

export const TradeInCard = () => {
  return (
    <ActionCard
      buttonClassName="w-full rounded-full"
      buttonSize="md"
      buttonText="Accept My Trade-In Offer"
      buttonVariant="secondary"
      description="Get a free estimate in minutes and apply it toward your next vehicle."
      icon={
        <Image
          alt="Arrow inspected icon"
          className="h-(--size-avatar-sm) w-(--size-avatar-sm)"
          height={32}
          src="/images/vdp/Trade.svg"
          width={32}
        />
      }
      title="What's Your Trade-In Value?"
    />
  );
};
