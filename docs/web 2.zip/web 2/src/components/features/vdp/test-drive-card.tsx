"use client";

import Image from "next/image";
import { ActionCard } from "~/components/shared/action-card";

export const TestDriveCard = () => {
  return (
    <ActionCard
      buttonClassName="w-full rounded-full"
      buttonSize="md"
      buttonText="Book an Appointment"
      buttonVariant="tertiary"
      description="See It In Person. Schedule a test drive at Toyota of Fort Worth."
      descriptionTrailing={
        <div className="flex shrink-0 items-center gap-(--spacing-2xs)">
          <Image
            alt="Location"
            className="h-(--spacing-sm) w-(--spacing-sm)"
            height={12}
            src="/images/garage/location.svg"
            width={12}
          />
          <p className="text-(length:--text-xs) font-normal text-(--color-body-muted) leading-normal">
            6 mi
          </p>
        </div>
      }
      icon={
        <Image
          alt="Toyota logo"
          className="h-(--size-avatar-sm) w-(--size-avatar-sm)"
          height={32}
          src="/images/vdp/Toyota-logo.svg"
          width={32}
        />
      }
      title="Schedule a Test drive today."
    />
  );
};
