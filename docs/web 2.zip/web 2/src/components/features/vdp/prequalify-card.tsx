"use client";

import Image from "next/image";
import { ActionCard } from "~/components/shared/action-card";

export const PrequalifyCard = () => {
  return (
    <ActionCard
      buttonClassName="w-full rounded-full"
      buttonSize="md"
      buttonText="Get started"
      buttonVariant="primary"
      description="Get pre-qualified without any impact to your credit"
      icon={
        <Image
          alt="Arrow inspected icon"
          className="h-[var(--size-avatar-sm)] w-[var(--size-avatar-sm)]"
          height={32}
          src="/images/vdp/Inspected-red.svg"
          width={32}
        />
      }
      title="Know Your Buying Power"
    />
  );
};
