"use client";

import { useEffect, useState } from "react";
import { getCookie } from "~/lib/cookie-cache";
import { FLAG_COOKIE_NAME, mockUsers } from "~/lib/flags/config";
import { PrequalifyCard } from "./prequalify-card";
import { TestDriveCard } from "./test-drive-card";
import { TradeInCard } from "./trade-in-card";

export function VdpPromotionCards() {
  const [flags, setFlags] = useState({
    isPreQualified: false,
    isTradeInSubmitted: false,
    isTestDriveScheduled: false,
  });

  useEffect(() => {
    const userKey = getCookie(FLAG_COOKIE_NAME) ?? "firstTimeVisitor";
    const user = mockUsers[userKey] ?? mockUsers.firstTimeVisitor;
    if (user) {
      setFlags({
        isPreQualified: user.flags.customerPreQualified,
        isTradeInSubmitted: user.flags.customerTradeInSubmitted,
        isTestDriveScheduled: user.flags.customerTestDriveScheduled,
      });
    }
  }, []);

  return (
    <>
      {!flags.isPreQualified && <PrequalifyCard />}
      {!flags.isTradeInSubmitted && <TradeInCard />}
      {!flags.isTestDriveScheduled && <TestDriveCard />}
    </>
  );
}
