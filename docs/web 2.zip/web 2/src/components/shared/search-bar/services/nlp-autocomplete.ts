/**
 * NLP-aware autocomplete service
 *
 * Generates contextual typeahead suggestions by parsing the user's partial
 * query and composing completions from the canonical filter data.
 *
 * All body types, features, and price/mileage patterns are derived from
 * `filterSections` — nothing is hardcoded.
 *
 * @module search-bar/services/nlp-autocomplete
 */

import { filterSections } from "~/lib/search/filter-sections";
import type { Vehicle } from "~/lib/search/mock-vehicles";
import type { AutocompleteService, Suggestion } from "../types";

// ── Derived lookup sets (computed once at module load) ──────────────────

const BODY_TYPES = filterSections.bodyStyle;
const BODY_TYPE_SET = new Set(BODY_TYPES.map((s) => s.toLowerCase()));

/** Popular features pulled from filter sections — flat list for suggestion generation. */
const POPULAR_FEATURES = [
  ...filterSections.comfortFeatures.slice(0, 6),
  ...filterSections.techFeatures.slice(0, 4),
  ...filterSections.safetyFeatures.slice(0, 3),
  ...filterSections.exteriorFeatures.slice(0, 3),
];

/** Price thresholds used in NLP suggestion completions. */
const PRICE_TIERS = ["20K", "25K", "30K", "35K", "40K", "50K"];

/** Mileage descriptors used in NLP suggestion completions. */
const MILEAGE_DESCRIPTORS = ["Low Miles", "Under 30K Miles", "Under 50K Miles"];

// ── Suggestion templates ────────────────────────────────────────────────

interface SuggestionTemplate {
  /** Function that returns true if the user's normalised query matches this template. */
  match: (query: string) => boolean;
  /** Generate suggestions for the matched query. */
  generate: (query: string, maxResults: number) => Suggestion[];
}

/**
 * Build body-type completions:
 *   "suv" → "SUV under 35K with Low Miles", "SUV under 35K with Heated Seats", …
 */
function bodyTypeCompletions(bodyType: string, maxResults: number): Suggestion[] {
  const label = BODY_TYPES.find((b) => b.toLowerCase() === bodyType.toLowerCase()) ?? bodyType;
  const suggestions: Suggestion[] = [];

  // Price-based completions
  for (const price of PRICE_TIERS) {
    if (suggestions.length >= maxResults) break;
    suggestions.push({
      text: `${label} under ${price} with`,
      highlight: "Low Miles",
      id: `${bodyType}-price-${price}`,
    });
  }

  // Feature-based completions (with mid-range price)
  for (const feature of POPULAR_FEATURES) {
    if (suggestions.length >= maxResults) break;
    suggestions.push({
      text: `${label} under 35K with`,
      highlight: feature,
      id: `${bodyType}-feat-${feature}`,
    });
  }

  return suggestions.slice(0, maxResults);
}

/**
 * Build price-based completions when user types "under":
 *   "under" → "Cars under $20,000", "SUV under 35K", …
 */
function priceCompletions(query: string, maxResults: number): Suggestion[] {
  const suggestions: Suggestion[] = [];

  // Check if a body type precedes "under"
  const words = query.split(/\s+/);
  const bodyIdx = words.findIndex((w) => BODY_TYPE_SET.has(w));
  const bodyType =
    bodyIdx >= 0
      ? BODY_TYPES.find((b) => b.toLowerCase() === words[bodyIdx]) ?? words[bodyIdx]
      : null;
  const prefix = bodyType ?? "Cars";

  for (const price of PRICE_TIERS) {
    if (suggestions.length >= maxResults) break;
    suggestions.push({
      text: `${prefix} under ${price} with`,
      highlight: "Low Miles",
      id: `price-${price}`,
    });
  }

  return suggestions;
}

/**
 * Build model completions from the vehicle inventory:
 *   "cam" → "Toyota Camry", "Toyota Camry LE", …
 */
function modelCompletions(
  query: string,
  vehicles: Vehicle[],
  maxResults: number
): Suggestion[] {
  const seen = new Map<string, Suggestion>();

  for (const v of vehicles) {
    if (seen.size >= maxResults) break;

    const make = v.make;
    const model = v.model
      .split("-")
      .map((w) => (w.length <= 3 ? w.toUpperCase() : w[0]?.toUpperCase() + w.slice(1)))
      .join(" ");

    const key = `${make} ${model}`.toLowerCase();
    if (key.includes(query) && !seen.has(key)) {
      seen.set(key, {
        text: make,
        highlight: model,
        id: `model-${v.id}`,
      });
    }
  }

  return Array.from(seen.values());
}

// ── Template registry ───────────────────────────────────────────────────

function buildTemplates(vehicles: Vehicle[]): SuggestionTemplate[] {
  return [
    // Body type match: "suv", "sedan", "truck", etc.
    {
      match: (q) => {
        const words = q.split(/\s+/);
        return words.some((w) => BODY_TYPE_SET.has(w));
      },
      generate: (q, max) => {
        const words = q.split(/\s+/);
        const bt = words.find((w) => BODY_TYPE_SET.has(w)) ?? "";
        return bodyTypeCompletions(bt, max);
      },
    },
    // Price intent: "under", "below", "less than"
    {
      match: (q) => /\b(under|below|less than)\b/.test(q),
      generate: (q, max) => priceCompletions(q, max),
    },
    // Mileage intent: "low mile", "miles"
    {
      match: (q) => /\b(low[\s-]?mile|miles?|mileage)\b/.test(q),
      generate: (_q, max) => {
        const suggestions: Suggestion[] = [];
        for (const bt of BODY_TYPES.slice(0, 3)) {
          for (const desc of MILEAGE_DESCRIPTORS) {
            if (suggestions.length >= max) break;
            suggestions.push({
              text: `${bt} with`,
              highlight: desc,
              id: `mile-${bt}-${desc}`,
            });
          }
        }
        return suggestions.slice(0, max);
      },
    },
    // Feature intent: matches a known feature name
    {
      match: (q) =>
        POPULAR_FEATURES.some((f) => f.toLowerCase().includes(q) || q.includes(f.toLowerCase())),
      generate: (q, max) => {
        const matchedFeature = POPULAR_FEATURES.find(
          (f) => f.toLowerCase().includes(q) || q.includes(f.toLowerCase())
        );
        if (!matchedFeature) return [];
        return BODY_TYPES.slice(0, max).map((bt) => ({
          text: `${bt} with`,
          highlight: matchedFeature,
          id: `feat-${bt}-${matchedFeature}`,
        }));
      },
    },
    // Model / make name match against inventory
    {
      match: () => true, // fallback — always runs if nothing above matched
      generate: (q, max) => modelCompletions(q, vehicles, max),
    },
  ];
}

// ── Service class ───────────────────────────────────────────────────────

export class NlpAutocompleteService implements AutocompleteService {
  private readonly templates: SuggestionTemplate[];

  constructor(vehicles: Vehicle[] = []) {
    this.templates = buildTemplates(vehicles);
  }

  async getSuggestions(query: string, maxResults: number): Promise<Suggestion[]> {
    // Simulate network latency
    await new Promise((resolve) => setTimeout(resolve, 50));

    const normalized = query.trim().toLowerCase().replace(/[-_]+/g, " ");
    if (normalized.length === 0) {
      return [];
    }

    // Walk through templates in priority order; return first match that produces results.
    for (const template of this.templates) {
      if (template.match(normalized)) {
        const results = template.generate(normalized, maxResults);
        if (results.length > 0) {
          return results.slice(0, maxResults);
        }
      }
    }

    return [];
  }
}

// ── Quick filter pills generator ────────────────────────────────────────

/**
 * Generate dynamic quick-filter pill labels from the inventory and filter data.
 * Replaces the hardcoded MOCK_SUGGESTED_PILLS array.
 */
export function generateQuickFilterPills(vehicles: Vehicle[]): string[] {
  const pills: string[] = [];

  // Top body types by inventory count
  const bodyCount = new Map<string, number>();
  for (const v of vehicles) {
    bodyCount.set(v.bodyType, (bodyCount.get(v.bodyType) ?? 0) + 1);
  }
  const topBodyTypes = [...bodyCount.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 2)
    .map(([bt]) => bt);

  // Add body-type based pills
  for (const bt of topBodyTypes) {
    pills.push(`${bt} under 35K`);
  }

  // Add a feature-based pill
  pills.push("Low Miles");

  // Add a price-based pill
  pills.push("Cars under $20,000");

  return pills;
}
