import { useCallback, useDeferredValue, useEffect, useRef, useState } from "react";
import type { AutocompleteService, Suggestion } from "../types";

/**
 * Return type for useSearchSuggestions hook
 */
export interface UseSearchSuggestionsReturn {
  /** Clear current suggestions */
  clearSuggestions: () => void;

  /** Error state if autocomplete request fails */
  error: Error | null;

  /** Manually trigger a suggestions fetch */
  fetchSuggestions: (query: string) => void;

  /** Whether suggestions are currently being fetched */
  isLoading: boolean;
  /** Current suggestions from autocomplete service */
  suggestions: Suggestion[];
}

/**
 * Options for useSearchSuggestions hook
 */
export interface UseSearchSuggestionsOptions {
  /** Autocomplete service to use for fetching suggestions */
  autocompleteService?: AutocompleteService;

  /** When false, fetches are suppressed (e.g. programmatic value changes). */
  enabled?: boolean;

  /** Maximum number of suggestions to fetch */
  maxSuggestions?: number;

  /** Minimum characters before fetching suggestions */
  minCharsForSuggestions?: number;
}

/**
 * Custom hook for managing autocomplete suggestions.
 *
 * Uses React 19 `useDeferredValue` instead of manual setTimeout debouncing.
 * React schedules the deferred update at low priority — if the user types
 * again before the fetch completes, React abandons the stale render
 * automatically.  Fast responses show immediately; no artificial delay.
 *
 * @param query - Current search query value
 * @param options - Configuration options
 * @returns Suggestions state and control functions
 */
export function useSearchSuggestions(
  query: string,
  options: UseSearchSuggestionsOptions = {}
): UseSearchSuggestionsReturn {
  const {
    autocompleteService,
    minCharsForSuggestions = 2,
    enabled = true,
    maxSuggestions = 4,
  } = options;

  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  // React 19 — defers the query so rapid keystrokes don't trigger a fetch
  // on every character.  React batches and only processes the latest value.
  const deferredQuery = useDeferredValue(query);

  // Track the latest request to cancel stale in-flight fetches
  const abortControllerRef = useRef<AbortController | null>(null);

  /**
   * Fetch suggestions from the autocomplete service
   */
  const fetchSuggestions = useCallback(
    async (searchQuery: string) => {
      // Cancel any pending request
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }

      if (!autocompleteService) {
        setSuggestions([]);
        setIsLoading(false);
        return;
      }

      if (searchQuery.length < minCharsForSuggestions) {
        setSuggestions([]);
        setIsLoading(false);
        setError(null);
        return;
      }

      const abortController = new AbortController();
      abortControllerRef.current = abortController;

      setIsLoading(true);
      setError(null);

      try {
        const results = await autocompleteService.getSuggestions(searchQuery, maxSuggestions);

        if (!abortController.signal.aborted) {
          setSuggestions(results);
          setIsLoading(false);
        }
      } catch (err) {
        if (!abortController.signal.aborted) {
          console.error("Autocomplete service error:", err);
          const error = err instanceof Error ? err : new Error("Failed to fetch suggestions");
          setError(error);
          setSuggestions([]);
          setIsLoading(false);
        }
      }
    },
    [autocompleteService, minCharsForSuggestions, maxSuggestions]
  );

  /**
   * Clear current suggestions
   */
  const clearSuggestions = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setSuggestions([]);
    setIsLoading(false);
    setError(null);
  }, []);

  // Skip the very first effect — on mount the query may already be populated
  // from URL state but the user hasn't typed anything yet.
  const isFirstRender = useRef(true);

  /**
   * React 19 pattern: fetch when the *deferred* query settles.
   * useDeferredValue naturally batches rapid keystrokes; the effect only
   * fires once the deferred value stabilises, replacing manual debouncing.
   * Gated by `enabled` so programmatic value changes don't trigger a fetch.
   */
  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }

    if (!enabled) {
      return;
    }

    if (!deferredQuery || deferredQuery.length < minCharsForSuggestions) {
      clearSuggestions();
      return;
    }

    fetchSuggestions(deferredQuery);
  }, [deferredQuery, enabled, minCharsForSuggestions, fetchSuggestions, clearSuggestions]);

  /** Cleanup on unmount */
  useEffect(() => {
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  return {
    suggestions,
    isLoading,
    error,
    fetchSuggestions,
    clearSuggestions,
  };
}
