export { type InspectionFeature, inspectionFeatures } from "./inspection/features";
export * from "./vehicle-types";

/** Async wrapper for server components that need vehicle types. */
export async function getVehicleTypes() {
  const { vehicleTypes } = await import("./vehicle-types");
  return vehicleTypes;
}

/** Async wrapper for server components that need inspection features. */
export async function getInspectionFeatures() {
  const { inspectionFeatures } = await import("./inspection/features");
  return inspectionFeatures;
}
