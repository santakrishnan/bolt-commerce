// ── Public API for the tracking feature ──────────────────────────────

// Config & constants
export {
  ARROW_COOKIE,
  ARROW_HEADER,
  ARROW_TTL,
} from "./constants";
// Context providers
export { ArrowProvider, useArrow } from "./context/arrow-provider";
export { FingerprintClientProvider } from "./context/fingerprint-client";
export { ProfileProvider, useProfileContext } from "./context/profile-context";
export {
  useVisitorProfile,
  type VisitorProfile,
  VisitorProfileProvider,
} from "./context/visitor-profile";
// Hooks
export { createEventTracker, useEventTracking } from "./hooks/event-tracker";
export { createArrowClient } from "./lib/client-api";
export { decryptPayload, encryptPayload } from "./lib/encryption";
export {
  extractGeoFromArrowData,
  extractIdentityFromArrowData,
} from "./lib/fingerprint-filter";
export { extractSealedResult, isSdkV4Result } from "./lib/sdk-transforms";
// Lib (infrastructure used by API routes and services)
export {
  ArrowServerError,
  createArrowServerClient,
  extractArrowIds,
} from "./lib/server-api";
// Services (client-safe only — server-only services like fingerprint.service
// and visitor-profile.service use cacheTag/cacheLife and must be imported
// directly: @features/tracking/services/fingerprint.service etc.)
export { trackEvent } from "./services/events.service";
export { unsealFingerprintResult } from "./services/sealed.service";
export type {
  EventTrackerRequest,
  FedFingerprintData,
  FedLocationData,
} from "./types";
