// ── Public API for the favorites feature ─────────────────────────────

export { FavoriteButton } from "./components/favorite-button";
export { FavoritesProvider, useFavorites } from "./context/favorites-provider";
export { savedVehicleQueries } from "./queries/saved-vehicles";
export {
  clearAllSavedVehicles,
  getAllSavedVehicles,
  saveVehicle,
  unsaveVehicle,
} from "./services/saved-vehicles-api";
