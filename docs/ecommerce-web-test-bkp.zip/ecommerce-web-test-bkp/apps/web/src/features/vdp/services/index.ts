export * from "./types";
// vdp.service uses cacheTag/cacheLife (server-only).
// Import directly: @features/vdp/services/vdp.service
