"use client";

import {
  defaultFilterState,
  FilterSidebar,
  type FilterState,
} from "@features/search/components/filter-sidebar";
import { SearchHero } from "@features/search/components/search-hero";
import { VehicleResults } from "@features/search/components/vehicle-results";
import { useSearchContext } from "@features/search/context/search-context";
import {
  parseSearchUrlState,
  type SearchSortOption,
  serializeSearchUrlState,
} from "@features/search/lib/url-filters";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Suspense, useDeferredValue, useEffect, useRef, useState } from "react";

// Progress bar animation helper
function getProgressTransition(progress: number): string {
  if (progress === 100) {
    return "width 0.25s ease-in, opacity 0.4s ease 0.2s";
  }
  if (progress === 0) {
    return "none";
  }
  return "width 1.5s cubic-bezier(0.05, 0.6, 0.1, 1), opacity 0.15s ease";
}

function useDebouncedValue<T>(value: T, delayMs: number): T {
  const timeoutRef = useRef<number | null>(null);
  const [state, setState] = useState(value);

  useEffect(() => {
    if (timeoutRef.current) {
      window.clearTimeout(timeoutRef.current);
    }
    timeoutRef.current = window.setTimeout(() => setState(value), delayMs);
    return () => {
      if (timeoutRef.current) {
        window.clearTimeout(timeoutRef.current);
      }
    };
  }, [value, delayMs]);

  return state;
}

export function SearchClient() {
  const {
    vehiclePool,
    filterState,
    searchQuery,
    setSearchQuery,
    searchQueryRef,
    labelFilter,
    setLabelFilter,
    refineSearchFilters,
    setRefineSearchFilters,
    currentPage,
    setCurrentPage,
    progress,
    isProgressVisible,
    isFilterOpen,
    setIsFilterOpen,
    availableFilters,
    totalCount,
    sortOption,
    setSortOption,
    loadingFacetSections,
    applyFiltersSearch,
  } = useSearchContext();

  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const hydratedFromUrl = useRef(false);
  const lastSerializedUrlState = useRef("");
  const isInternalUpdate = useRef(false);
  const itemsPerPage = 20;

  // URL -> state (supports back/forward navigation)
  useEffect(() => {
    const parsed = parseSearchUrlState(searchParams);

    // Filter out undefined values to preserve defaultFilterState defaults
    const parsedFilterState = Object.fromEntries(
      Object.entries(parsed.filterState).filter(([_, value]) => value !== undefined)
    ) as Partial<FilterState>;

    const nextFilterState: FilterState = {
      ...defaultFilterState,
      ...parsedFilterState,
    };

    const nextSearchQuery = parsed.searchQuery ?? "";
    const nextPage = parsed.page ?? 1;
    const nextSort = (parsed.sortOption ?? "recommended") as SearchSortOption;
    const nextLabelFilter = parsed.labelFilter ?? "";

    const serialized = serializeSearchUrlState({
      filterState: nextFilterState,
      searchQuery: nextSearchQuery,
      page: nextPage,
      sortOption: nextSort,
      labelFilter: nextLabelFilter,
    });

    // On first hydration, let SearchProvider's initial state win
    if (!hydratedFromUrl.current) {
      hydratedFromUrl.current = true;
      lastSerializedUrlState.current = serialized;
      return;
    }

    if (serialized === lastSerializedUrlState.current) {
      return;
    }

    // Skip applying filters if this URL change was triggered by an internal state update
    if (isInternalUpdate.current) {
      isInternalUpdate.current = false;
      lastSerializedUrlState.current = serialized;
      return;
    }

    lastSerializedUrlState.current = serialized;

    setCurrentPage(nextPage);
    setSortOption(nextSort);
    setLabelFilter(nextLabelFilter);
    setSearchQuery(nextSearchQuery);
    searchQueryRef.current = nextSearchQuery;

    applyFiltersSearch(nextFilterState, {
      searchQuery: nextSearchQuery,
      labelFilter: nextLabelFilter,
      refineFilters: refineSearchFilters,
      preservePage: true,
    });
  }, [
    searchParams,
    setCurrentPage,
    setSortOption,
    setLabelFilter,
    setSearchQuery,
    searchQueryRef,
    applyFiltersSearch,
    refineSearchFilters,
  ]);

  const debouncedUrlState = useDebouncedValue(
    {
      filterState,
      searchQuery,
      page: currentPage,
      sortOption,
      labelFilter,
    },
    250
  );

  // state -> URL
  useEffect(() => {
    if (!hydratedFromUrl.current) {
      return;
    }

    const serialized = serializeSearchUrlState(debouncedUrlState);
    if (serialized === lastSerializedUrlState.current) {
      return;
    }

    lastSerializedUrlState.current = serialized;
    isInternalUpdate.current = true;
    const nextUrl = serialized ? `${pathname}?${serialized}` : pathname;
    router.replace(nextUrl, { scroll: false });
  }, [debouncedUrlState, pathname, router]);

  const handleApplyFilters = (newState: FilterState) => {
    applyFiltersSearch(newState, {
      searchQuery,
      labelFilter,
      refineFilters: refineSearchFilters,
    });
  };

  const addSingleFilter = (
    filters: { label: string; type: string; value: string }[],
    value: string,
    type: string
  ) => {
    if (value) {
      filters.push({ label: value, type, value });
    }
  };

  const addArrayFilters = (
    filters: { label: string; type: string; value: string }[],
    arr: string[],
    type: string
  ) => {
    for (const value of arr) {
      filters.push({ label: value, type, value });
    }
  };

  const getActiveFilters = () => {
    const filters: { label: string; type: string; value: string; isRefineSearch?: boolean }[] = [];
    addSingleFilter(filters, filterState.selectedPriceQuick, "price");
    addSingleFilter(filters, filterState.selectedYearQuick, "year");
    addSingleFilter(filters, filterState.selectedMileage, "mileage");
    addArrayFilters(filters, filterState.selectedBodyStyles, "bodyStyle");
    addArrayFilters(filters, filterState.selectedExteriorColors, "exteriorColor");
    addArrayFilters(filters, filterState.selectedInteriorColors, "interiorColor");
    addArrayFilters(filters, filterState.selectedFuelTypes, "fuelType");
    addArrayFilters(filters, filterState.selectedModels, "model");
    addArrayFilters(filters, filterState.selectedSafetyFeatures, "safetyFeature");
    addArrayFilters(filters, filterState.selectedComfortFeatures, "comfortFeature");
    addArrayFilters(filters, filterState.selectedTechFeatures, "techFeature");
    addArrayFilters(filters, filterState.selectedExteriorFeatures, "exteriorFeature");
    addArrayFilters(filters, filterState.selectedPerformanceFeatures, "performanceFeature");
    addArrayFilters(filters, filterState.selectedSeatingCapacity, "seatingCapacity");
    addArrayFilters(filters, filterState.selectedDrivetrains, "drivetrain");
    addArrayFilters(filters, filterState.selectedTransmissions, "transmission");

    if (filterState.inspection160) {
      filters.push({ label: "160-Point Inspection", type: "inspection", value: "160" });
    }
    if (labelFilter) {
      filters.push({ label: labelFilter, type: "label", value: labelFilter });
    }
    for (const refineFilter of refineSearchFilters) {
      filters.push({ label: refineFilter.label, type: "refineSearch", value: refineFilter.id });
    }

    return filters;
  };

  const activeFilters = getActiveFilters();

  // React 19: defer vehicle data so old cards stay visible during re-renders.
  // React renders the new list at low priority; if another update arrives first
  // it abandons the stale render — no loader, no flash.
  const deferredVehicles = useDeferredValue(vehiclePool);
  const deferredTotalCount = useDeferredValue(totalCount);
  const isPending = deferredVehicles !== vehiclePool;

  const removeFilter = (type: string, value: string) => {
    let nextState: FilterState = filterState;
    let nextLabelFilter = labelFilter;
    let nextRefine = refineSearchFilters;

    switch (type) {
      case "price":
        nextState = { ...filterState, selectedPriceQuick: "" };
        break;
      case "year":
        nextState = { ...filterState, selectedYearQuick: "" };
        break;
      case "mileage":
        nextState = { ...filterState, selectedMileage: "" };
        break;
      case "bodyStyle":
        nextState = {
          ...filterState,
          selectedBodyStyles: filterState.selectedBodyStyles.filter((v) => v !== value),
        };
        break;
      case "exteriorColor":
        nextState = {
          ...filterState,
          selectedExteriorColors: filterState.selectedExteriorColors.filter((v) => v !== value),
        };
        break;
      case "interiorColor":
        nextState = {
          ...filterState,
          selectedInteriorColors: filterState.selectedInteriorColors.filter((v) => v !== value),
        };
        break;
      case "fuelType":
        nextState = {
          ...filterState,
          selectedFuelTypes: filterState.selectedFuelTypes.filter((v) => v !== value),
        };
        break;
      case "model":
        nextState = {
          ...filterState,
          selectedModels: filterState.selectedModels.filter((v) => v !== value),
        };
        break;
      case "safetyFeature":
        nextState = {
          ...filterState,
          selectedSafetyFeatures: filterState.selectedSafetyFeatures.filter((v) => v !== value),
        };
        break;
      case "comfortFeature":
        nextState = {
          ...filterState,
          selectedComfortFeatures: filterState.selectedComfortFeatures.filter((v) => v !== value),
        };
        break;
      case "techFeature":
        nextState = {
          ...filterState,
          selectedTechFeatures: filterState.selectedTechFeatures.filter((v) => v !== value),
        };
        break;
      case "exteriorFeature":
        nextState = {
          ...filterState,
          selectedExteriorFeatures: filterState.selectedExteriorFeatures.filter((v) => v !== value),
        };
        break;
      case "performanceFeature":
        nextState = {
          ...filterState,
          selectedPerformanceFeatures: filterState.selectedPerformanceFeatures.filter(
            (v) => v !== value
          ),
        };
        break;
      case "seatingCapacity":
        nextState = {
          ...filterState,
          selectedSeatingCapacity: filterState.selectedSeatingCapacity.filter((v) => v !== value),
        };
        break;
      case "drivetrain":
        nextState = {
          ...filterState,
          selectedDrivetrains: filterState.selectedDrivetrains.filter((v) => v !== value),
        };
        break;
      case "transmission":
        nextState = {
          ...filterState,
          selectedTransmissions: filterState.selectedTransmissions.filter((v) => v !== value),
        };
        break;
      case "inspection":
        nextState = { ...filterState, inspection160: false };
        break;
      case "label":
        nextLabelFilter = "";
        setLabelFilter("");
        break;
      case "refineSearch":
        nextRefine = refineSearchFilters.filter((f) => f.id !== value);
        setRefineSearchFilters(nextRefine);
        break;
      default:
        break;
    }

    applyFiltersSearch(nextState, {
      searchQuery,
      labelFilter: nextLabelFilter,
      refineFilters: nextRefine,
    });
  };

  const resetFilters = () => {
    setLabelFilter("");
    setRefineSearchFilters([]);
    setSearchQuery("");
    searchQueryRef.current = "";
    setCurrentPage(1);
    applyFiltersSearch(defaultFilterState, {
      searchQuery: "",
      labelFilter: "",
      refineFilters: [],
    });
    setCurrentPage(1);
  };

  const applyRefineFilters = (filters: { id: string; label: string }[]) => {
    // Treat the array provided by the modal as the authoritative selection:
    // replace the current refine filters so removals are reflected.
    const unique: { id: string; label: string }[] = [];
    for (const f of filters) {
      if (!unique.some((u) => u.id === f.id)) {
        unique.push(f);
      }
    }
    setRefineSearchFilters(unique);
    applyFiltersSearch(filterState, {
      searchQuery,
      labelFilter,
      refineFilters: unique,
    });
  };

  return (
    <div className="flex min-h-screen flex-col bg-gray-50 lg:px-0">
      <FilterSidebar
        availableFilters={availableFilters}
        filterState={filterState}
        isOpen={isFilterOpen}
        labelFilter={labelFilter}
        loadingFacetSections={loadingFacetSections}
        onApply={handleApplyFilters}
        onClose={() => setIsFilterOpen(false)}
        onReset={resetFilters}
        refineFilters={refineSearchFilters}
        searchQuery={searchQuery}
        vehicleCount={totalCount}
      />

      <main className="relative flex-1 bg-gray-100">
        {/* Suspense boundary for SearchHero's use(quickFiltersPromise) —
            catches the brief suspension on first page load while quick-filter
            pills resolve. After that the promise is cached and renders instantly. */}
        <Suspense fallback={null}>
          <SearchHero
            activeFilters={activeFilters}
            onRemoveFilter={removeFilter}
            onReset={resetFilters}
            onSearch={() => {
              setCurrentPage(1);
            }}
            onSearchChange={(query) => {
              searchQueryRef.current = query;
              setSearchQuery(query);
            }}
            onToggleFilter={() => setIsFilterOpen(true)}
            searchQuery={searchQuery}
            vehicleCount={totalCount}
            vehiclesAvailable={totalCount}
          />
        </Suspense>

        <div className="mx-6 md:mx-0">
          <div className="relative h-px overflow-hidden bg-(--color-structure-interaction-subtle-border)">
            <div
              aria-hidden
              className="absolute top-0 left-0 h-full"
              style={{
                width: `${progress}%`,
                opacity: isProgressVisible ? 1 : 0,
                background: "var(--primary)",
                transition: getProgressTransition(progress),
              }}
            />
          </div>
        </div>

        <VehicleResults
          activeFilters={activeFilters}
          currentPage={currentPage}
          isPending={isPending}
          itemsPerPage={itemsPerPage}
          onApplyRefineFilters={applyRefineFilters}
          onPageChange={setCurrentPage}
          onRemoveFilter={removeFilter}
          onReset={resetFilters}
          onSearch={() => {
            setCurrentPage(1);
          }}
          onToggleFilter={() => setIsFilterOpen(true)}
          searchQuery={searchQuery}
          totalCount={deferredTotalCount}
          vehicles={deferredVehicles}
        />
      </main>
    </div>
  );
}
