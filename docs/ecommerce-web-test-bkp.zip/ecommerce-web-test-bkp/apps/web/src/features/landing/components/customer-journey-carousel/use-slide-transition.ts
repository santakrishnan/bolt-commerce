import { useCallback, useRef, useState } from "react";
import {
  DEFAULT_HIDDEN_STYLE,
  DEFAULT_VISIBLE_STYLE,
  ENTER_DURATION,
  EXIT_DURATION,
  getEnterStartFilter,
  getExitFilter,
  getImageEnterStartTransform,
  getImageExitTransform,
  getTextEnterStartTransform,
  getTextExitTransform,
  getTransition,
} from "./constants";
import type { StyleState } from "./types";

// ─── Container styles hook ──────────────────────────────────────────────────

export function useContainerStyles() {
  const [containerAStyle, setContainerAStyle] = useState<StyleState>(DEFAULT_VISIBLE_STYLE);
  const [containerBStyle, setContainerBStyle] = useState<StyleState>(DEFAULT_HIDDEN_STYLE);
  const [textAStyle, setTextAStyle] = useState<StyleState>(DEFAULT_VISIBLE_STYLE);
  const [textBStyle, setTextBStyle] = useState<StyleState>(DEFAULT_HIDDEN_STYLE);

  return {
    containerAStyle,
    containerBStyle,
    setContainerAStyle,
    setContainerBStyle,
    setTextAStyle,
    setTextBStyle,
    textAStyle,
    textBStyle,
  };
}

// ─── Slide transition hook ──────────────────────────────────────────────────

interface UseSlideTransitionProps {
  containerStyles: ReturnType<typeof useContainerStyles>;
  numSlides: number;
}

export function useSlideTransition({ numSlides, containerStyles }: UseSlideTransitionProps) {
  const [containerAIndex, setContainerAIndex] = useState(0);
  const [containerBIndex, setContainerBIndex] = useState<number | null>(null);
  const [activeContainer, setActiveContainer] = useState<"A" | "B">("A");

  const isAnimatingRef = useRef(false);

  const { setContainerAStyle, setContainerBStyle, setTextAStyle, setTextBStyle } = containerStyles;

  const currentVisibleIndex = activeContainer === "A" ? containerAIndex : containerBIndex;

  const performTransitionToB = useCallback(
    (targetIndex: number) => {
      setContainerBStyle({
        filter: getEnterStartFilter(),
        opacity: 0,
        transform: getImageEnterStartTransform(),
        transition: "none",
      });
      setTextBStyle({
        filter: getEnterStartFilter(),
        opacity: 0,
        transform: getTextEnterStartTransform(),
        transition: "none",
      });
      setContainerBIndex(targetIndex);

      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          setContainerAStyle({
            filter: getExitFilter(),
            opacity: 0,
            transform: getImageExitTransform(),
            transition: getTransition("exit"),
          });
          setTextAStyle({
            filter: getExitFilter(),
            opacity: 0,
            transform: getTextExitTransform(),
            transition: getTransition("exit"),
          });
        });
      });

      setTimeout(() => {
        setContainerBStyle({
          filter: "none",
          opacity: 1,
          transform: "none",
          transition: getTransition("enter"),
        });
        setTextBStyle({
          filter: "none",
          opacity: 1,
          transform: "none",
          transition: getTransition("enter"),
        });

        setActiveContainer("B");

        setTimeout(() => {
          setContainerAStyle({ ...DEFAULT_HIDDEN_STYLE });
          setTextAStyle({ ...DEFAULT_HIDDEN_STYLE });
          isAnimatingRef.current = false;
        }, ENTER_DURATION);
      }, EXIT_DURATION);
    },
    [setContainerAStyle, setContainerBStyle, setTextAStyle, setTextBStyle],
  );

  const performTransitionToA = useCallback(
    (targetIndex: number) => {
      setContainerAStyle({
        filter: getEnterStartFilter(),
        opacity: 0,
        transform: getImageEnterStartTransform(),
        transition: "none",
      });
      setTextAStyle({
        filter: getEnterStartFilter(),
        opacity: 0,
        transform: getTextEnterStartTransform(),
        transition: "none",
      });
      setContainerAIndex(targetIndex);

      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          setContainerBStyle({
            filter: getExitFilter(),
            opacity: 0,
            transform: getImageExitTransform(),
            transition: getTransition("exit"),
          });
          setTextBStyle({
            filter: getExitFilter(),
            opacity: 0,
            transform: getTextExitTransform(),
            transition: getTransition("exit"),
          });
        });
      });

      setTimeout(() => {
        setContainerAStyle({
          filter: "none",
          opacity: 1,
          transform: "none",
          transition: getTransition("enter"),
        });
        setTextAStyle({
          filter: "none",
          opacity: 1,
          transform: "none",
          transition: getTransition("enter"),
        });

        setActiveContainer("A");

        setTimeout(() => {
          setContainerBStyle({ ...DEFAULT_HIDDEN_STYLE });
          setTextBStyle({ ...DEFAULT_HIDDEN_STYLE });
          isAnimatingRef.current = false;
        }, ENTER_DURATION);
      }, EXIT_DURATION);
    },
    [setContainerAStyle, setContainerBStyle, setTextAStyle, setTextBStyle],
  );

  const goToSlide = useCallback(
    (targetIndex: number) => {
      if (isAnimatingRef.current || targetIndex === currentVisibleIndex || numSlides <= 1) {
        return;
      }

      isAnimatingRef.current = true;

      if (activeContainer === "A") {
        performTransitionToB(targetIndex);
      } else {
        performTransitionToA(targetIndex);
      }
    },
    [currentVisibleIndex, numSlides, activeContainer, performTransitionToA, performTransitionToB],
  );

  return {
    activeContainer,
    containerAIndex,
    containerBIndex,
    currentVisibleIndex,
    goToSlide,
    isAnimatingRef,
  };
}
