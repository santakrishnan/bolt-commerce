import { cn } from "@tfs-ucmp/ui";

// ─── Config types ───────────────────────────────────────────────────────────

interface ResponsiveConfig {
  /** Desktop (lg: prefix, ≥ 1024 px) */
  desktop: string;
  /** Mobile-first (no responsive prefix) */
  mobile: string;
  /** Tablet (md: prefix, ≥ 768 px) */
  tablet: string;
}

interface RegionConfig {
  height: ResponsiveConfig;
  objectPosition: ResponsiveConfig;
  width: ResponsiveConfig;
}

// ─── Background image path ──────────────────────────────────────────────────

export const KNOWN_USER_DESKTOP_BG =
  "/images/hero-know-user-content/know-user-images/car-image-temporary.png";

// ─── Defaults ───────────────────────────────────────────────────────────────

const DEFAULT_WIDTH: ResponsiveConfig = {
  desktop: "lg:w-full",
  mobile: "w-full",
  tablet: "md:w-full",
};

const DEFAULT_REGION: RegionConfig = {
  height: { desktop: "lg:h-full", mobile: "h-[60vh]", tablet: "md:h-full" },
  objectPosition: { desktop: "lg:object-[72%_0%]", mobile: "object-[72%_0%]", tablet: "md:object-[72%_0%]" },
  width: DEFAULT_WIDTH,
};

const KNOWN_USER_OVERRIDES = {
  height: { desktop: "lg:h-full", mobile: "h-[45vh]", tablet: "md:h-full" },
  objectPosition: { desktop: "lg:object-[75%_0%]", mobile: "object-[88%_0%]", tablet: "md:object-[80%_0%]" },
} as const;

// ─── Per-region configs ─────────────────────────────────────────────────────

const REGION_CONFIGS: Record<string, RegionConfig> = {
  southeast: {
    height: { desktop: "lg:h-full", mobile: "h-[65vh]", tablet: "md:h-full" },
    objectPosition: { desktop: "lg:object-[52%_50%]", mobile: "object-[52%_0%]", tablet: "md:object-[52%_0%]" },
    width: DEFAULT_WIDTH,
  },
  southwest: {
    height: { desktop: "lg:h-full", mobile: "h-[56vh]", tablet: "md:h-full" },
    objectPosition: { desktop: "lg:object-[72%_52%]", mobile: "object-[72%_0%]", tablet: "md:object-[72%_0%]" },
    width: DEFAULT_WIDTH,
  },
  west: {
    height: { desktop: "lg:h-full", mobile: "h-[65vh]", tablet: "md:h-full" },
    objectPosition: { desktop: "lg:object-[50%_42%]", mobile: "object-[50%_0%]", tablet: "md:object-[50%_0%]" },
    width: DEFAULT_WIDTH,
  },
};

// ─── Resolver helpers ───────────────────────────────────────────────────────

function resolveResponsive(config: ResponsiveConfig): string {
  return cn(config.mobile, config.tablet, config.desktop);
}

export function resolveContainerWidthClass(backgroundImageKey: string): string {
  const region = REGION_CONFIGS[backgroundImageKey] ?? DEFAULT_REGION;
  return resolveResponsive(region.width);
}

export function resolveContainerHeightClass(
  effectiveKnownUser: boolean,
  backgroundImageKey: string,
  bannerHeightClass?: string,
): string {
  if (bannerHeightClass) {
    return "h-full md:h-full lg:h-full";
  }
  if (effectiveKnownUser) {
    return resolveResponsive(KNOWN_USER_OVERRIDES.height);
  }
  const region = REGION_CONFIGS[backgroundImageKey] ?? DEFAULT_REGION;
  return resolveResponsive(region.height);
}

export function resolveObjectPositionClass(
  effectiveKnownUser: boolean,
  backgroundImageKey: string,
): string {
  if (effectiveKnownUser) {
    return resolveResponsive(KNOWN_USER_OVERRIDES.objectPosition);
  }
  const region = REGION_CONFIGS[backgroundImageKey] ?? DEFAULT_REGION;
  return resolveResponsive(region.objectPosition);
}
