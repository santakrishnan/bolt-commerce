import { AppButton } from "@shared/components/button";
import { Card, CardContent, CardHeader, Heading } from "@tfs-ucmp/ui";
import Image from "next/image";
import type { SavedVehicle, TradeInOffer } from "./types";

// ─── Shared formatter ───────────────────────────────────────────────────────

const priceFormatter = new Intl.NumberFormat("en-US", {
  currency: "USD",
  minimumFractionDigits: 0,
  style: "currency",
});

function formatPrice(price: number): string {
  return priceFormatter.format(price);
}

// ─── Great Start Card (Saved Vehicle) ───────────────────────────────────────

interface GreatStartCardProps {
  isPreQualified: boolean;
  onBuyOnline?: () => void;
  savedVehicle: SavedVehicle;
}

export function GreatStartCard({ savedVehicle, isPreQualified, onBuyOnline }: GreatStartCardProps) {
  return (
    <div className="w-full space-y-4 md:flex md:min-w-0 md:flex-1 md:flex-col md:space-y-2" key="saved-vehicle">
      <Heading
        className="text-[length:var(--text-xl)] text-white tracking-wide md:pl-[var(--spacing-md)] md:text-[length:var(--font-size-xs)] lg:text-base xl:text-[length:var(--font-size-xl)]"
        level={2}
        weight="semibold"
      >
        Great Start
      </Heading>
      <Card className="w-full overflow-hidden border-0 bg-white md:flex md:flex-1 md:flex-col">
        <CardHeader
          className="flex flex-row items-center justify-between space-y-0 rounded-t-[16px] bg-background-light py-[12px]"
          style={{ paddingLeft: "16px", paddingRight: "9px" }}
        >
          {isPreQualified && (
            <div className="flex items-center gap-[var(--spacing-sm,8px)]">
              <Image
                alt="Check"
                height={16}
                src="/images/hero-know-user-content/know-user-icons/Verified-tick.svg"
                width={16}
              />
              <Heading
                className="text-center font-semibold text-[color:var(--color-text-primary,#111)] text-[length:var(--font-size-sm)] leading-normal [leading-trim:both] [text-edge:cap] md:text-[length:var(--font-size-sm)]"
                level={3}
                weight="normal"
              >
                Pre-qualified
              </Heading>
            </div>
          )}
          <Heading
            className="text-right text-[length:10px] text-[var(--color-text-primary)] uppercase leading-normal [leading-trim:both] [text-edge:cap] md:text-[length:10px]"
            level={3}
            weight="normal"
          >
            AUTO-FINANCING
          </Heading>
        </CardHeader>
        <CardContent className="flex flex-col gap-y-[var(--spacing-md,16px)] px-[var(--spacing-md,16px)] pb-[var(--spacing-md,16px)] md:flex-1 md:justify-between">
          <div className="flex items-center justify-center gap-[var(--spacing-xs)]">
            {savedVehicle.image && (
              <div className="relative h-[58px] w-[150px] shrink-0 overflow-hidden rounded">
                <Image
                  alt={`${savedVehicle.year} ${savedVehicle.make} ${savedVehicle.model}`}
                  className="object-contain"
                  fill
                  sizes="150px"
                  src="/images/hero-know-user-content/know-user-images/card-car.png"
                  style={{ aspectRatio: "75/29" }}
                />
              </div>
            )}
            <div className="flex min-w-0 flex-col justify-center">
              <span className="font-semibold text-[length:10px] text-[var(--color-text-primary,#111)] capitalize leading-normal [leading-trim:both] [text-edge:cap]">
                Approved Vehicle
              </span>
              <p className="truncate font-bold text-[length:16px] text-[var(--color-text-primary,#111)] leading-normal">
                {savedVehicle.year} {savedVehicle.make} {savedVehicle.model}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 items-center gap-1 text-[10px] lg:grid-cols-5">
            <div>
              <span className="font-semibold text-[length:10px] text-[var(--color-text-primary,#111)] leading-normal opacity-50 [leading-trim:both] [text-edge:cap]">
                VIN
              </span>
              <p className="truncate font-semibold text-[length:12px] text-[var(--color-text-primary,#111)] leading-normal">
                {savedVehicle.stockNumber || "N/A"}
              </p>
            </div>
            <div>
              <span className="font-semibold text-[length:10px] text-[var(--color-text-primary,#111)] leading-normal opacity-50 [leading-trim:both] [text-edge:cap]">
                Miles
              </span>
              <p className="font-semibold text-[length:12px] text-[var(--color-text-primary,#111)] leading-normal">
                {savedVehicle.mileage?.toLocaleString() || "N/A"}
              </p>
            </div>
            <div>
              <span className="font-semibold text-[length:10px] text-[var(--color-text-primary,#111)] leading-normal opacity-50 [leading-trim:both] [text-edge:cap]">
                Price
              </span>
              <p className="font-semibold text-[length:12px] text-[var(--color-text-primary,#111)] leading-normal">
                {formatPrice(savedVehicle.price)}
              </p>
            </div>
            <div>
              <span className="font-semibold text-[length:10px] text-[var(--color-text-primary,#111)] leading-normal opacity-50 [leading-trim:both] [text-edge:cap]">
                Monthly
              </span>
              <p className="font-semibold text-[length:12px] text-[var(--color-text-primary,#111)] leading-normal">
                $468
              </p>
            </div>
            <div>
              <span className="font-semibold text-[length:10px] text-[var(--color-text-primary,#111)] leading-normal opacity-50 [leading-trim:both] [text-edge:cap]">
                APR
              </span>
              <p className="font-semibold text-[length:12px] text-[var(--color-text-primary,#111)] leading-normal">
                5.49%
              </p>
            </div>
          </div>
          <AppButton onClick={onBuyOnline} size="md" variant="primary">
            Buy Online
          </AppButton>
        </CardContent>
      </Card>
    </div>
  );
}

// ─── Ready When You Are Card (Test Drive) ───────────────────────────────────

interface ReadyWhenYouAreCardProps {
  onScheduleTestDrive?: () => void;
  preQualifiedVehicle: SavedVehicle;
}

export function ReadyWhenYouAreCard({ preQualifiedVehicle, onScheduleTestDrive }: ReadyWhenYouAreCardProps) {
  return (
    <div className="w-full space-y-4 md:flex md:min-w-0 md:flex-1 md:flex-col md:space-y-2" key="test-drive">
      <Heading
        className="text-[length:var(--text-xl)] text-white tracking-wide md:pl-[var(--spacing-md)] md:text-[length:var(--font-size-xs)] lg:text-base xl:text-[length:var(--font-size-xl)]"
        level={2}
        weight="semibold"
      >
        Ready when you are
      </Heading>
      <Card className="w-full overflow-hidden border-0 bg-white md:flex md:flex-1 md:flex-col">
        <CardHeader
          className="flex flex-row items-center justify-between space-y-0 rounded-t-[16px] bg-background-light py-[12px]"
          style={{ paddingLeft: "16px", paddingRight: "9px" }}
        >
          <div className="flex items-center gap-2">
            <Image
              alt="Calendar"
              className="h-4 w-4"
              height={16}
              src="/images/hero-know-user-content/know-user-icons/calendar.svg"
              width={16}
            />
            <Heading
              className="text-center font-semibold text-[length:var(--text-sm)] text-[var(--color-card-title,#111)] leading-normal [leading-trim:both] [text-edge:cap] md:text-[length:var(--text-sm)]"
              level={3}
              weight="normal"
            >
              Book Test Drive
            </Heading>
          </div>
          <Heading
            className="text-right font-semibold text-[length:var(--text-2xs)] text-[var(--color-card-title)] uppercase leading-normal [leading-trim:both] [text-edge:cap] md:text-[length:var(--text-2xs)]"
            level={3}
            weight="normal"
          >
            3 SAVED VEHICLES
          </Heading>
        </CardHeader>
        <CardContent className="flex flex-col gap-[var(--spacing-sm,12px)] p-[var(--spacing-md,16px)] md:flex-1 md:justify-between">
          <div className="rounded-[8px] border border-[var(--color-structure-interaction-border-two,rgba(0,0,0,0.1))] px-[var(--spacing-sm,12px)] py-[var(--spacing-xs,8px)]">
            <p className="flex justify-center font-normal text-[length:16px] leading-normal md:justify-start">
              <span className="font-semibold text-[var(--color-card-title,#111)]">Pre-Qualified:</span>{" "}
              <span className="font-normal text-[var(--color-card-title,#111)]">
                {preQualifiedVehicle.year} {preQualifiedVehicle.make} {preQualifiedVehicle.model}
              </span>
            </p>
          </div>
          <div className="flex items-center gap-[var(--spacing-sm,12px)]">
            <Image
              alt="Toyota"
              className="h-8 w-8 shrink-0"
              height={32}
              src="/images/garage/Toyota-logo.svg"
              width={32}
            />
            <div className="flex flex-col">
              <p className="font-semibold text-[length:16px] text-[var(--color-brand-text-primary,#000)] leading-normal">
                Toyota of Fort Worth, TX 76116
              </p>
              <p className="font-normal text-[length:12px] text-[var(--color-brand-text-secondary,#58595B)] leading-normal">
                We are ready to schedule your test drive
              </p>
            </div>
          </div>
          <AppButton onClick={onScheduleTestDrive} size="md" variant="secondary">
            Book Test Drive
          </AppButton>
        </CardContent>
      </Card>
    </div>
  );
}

// ─── Don't Miss Out Card (Trade-In) ─────────────────────────────────────────

interface DontMissOutCardProps {
  onAcceptOffer?: () => void;
  tradeInOffer: TradeInOffer;
}

export function DontMissOutCard({ tradeInOffer, onAcceptOffer }: DontMissOutCardProps) {
  return (
    <div className="w-full space-y-4 md:flex md:min-w-0 md:flex-1 md:flex-col md:space-y-2" key="trade-in">
      <Heading
        className="text-[length:var(--text-xl)] text-white tracking-wide md:pl-[var(--spacing-md)] md:text-[length:var(--font-size-xs)] lg:text-base xl:text-[length:var(--font-size-xl)]"
        level={2}
        weight="semibold"
      >
        Don't miss out
      </Heading>
      <Card className="w-full overflow-hidden border-0 bg-white md:flex md:flex-1 md:flex-col">
        <CardHeader className="flex flex-row items-center gap-2 space-y-0 rounded-t-[16px] bg-[#F2F2F2] px-4 py-[var(--spacing-sm)]">
          <Image
            alt="Trade-in"
            className="h-4 w-4"
            height={16}
            src="/images/hero-know-user-content/know-user-icons/trade-in.svg"
            width={16}
          />
          <Heading
            className="font-semibold text-[length:var(--font-size-sm)] text-[var(--color-text-primary,#111)] md:text-[length:var(--font-size-sm)]"
            level={3}
            weight="normal"
          >
            Trade-In Offer
          </Heading>
        </CardHeader>
        <CardContent className="flex flex-col gap-[var(--spacing-md)] p-[var(--spacing-md)] md:flex-1 md:justify-between">
          <div className="flex flex-col gap-[var(--spacing-xs)] rounded-[8px] border border-[var(--color-structure-interaction-border-two,rgba(0,0,0,0.1))] py-[var(--spacing-xs)]">
            <div className="flex items-center justify-center gap-[var(--spacing-xs)]">
              <p className="font-bold text-[length:var(--font-size-md)] text-[var(--color-card-price,#EB0D1C)] leading-normal">
                {formatPrice(tradeInOffer.offerAmount)}
              </p>
              <p className="font-normal text-[length:var(--font-size-md,16px)] text-[var(--color-card-title,#111)] leading-normal">
                {tradeInOffer.year} {tradeInOffer.make} {tradeInOffer.model}
              </p>
            </div>
            <div className="h-[1px] bg-black opacity-10" />
            <div className="flex items-center justify-around">
              <Image
                alt="Clock"
                className="h-[30px] w-[30px]"
                height={30}
                src="/images/hero-know-user-content/know-user-icons/clock.svg"
                width={30}
              />
              <p className="font-semibold text-[length:var(--text-md,16px)] text-[var(--color-brand-text-primary,#000)] leading-normal">
                Expires in {tradeInOffer.expiresInDays} days
              </p>
              <p className="font-normal text-[length:var(--font-size-xs,12px)] text-[var(--color-brand-text-secondary,#58595B)] leading-normal">
                Don't miss out on this offer!
              </p>
            </div>
          </div>
          <AppButton onClick={onAcceptOffer} size="md" variant="secondary">
            Accept Offer Now
          </AppButton>
        </CardContent>
      </Card>
    </div>
  );
}
