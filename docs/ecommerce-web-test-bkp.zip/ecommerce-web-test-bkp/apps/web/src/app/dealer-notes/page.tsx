"use client";

import { DealerNotesSection } from "@features/vdp/components/dealer-notes-section";

export default function DealerNotesPage() {
  return (
    <div>
      <main className="min-h-screen bg-background">
        <DealerNotesSection />
      </main>
    </div>
  );
}
