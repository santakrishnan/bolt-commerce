/**
 * Flags Discovery Endpoint
 *
 * This endpoint enables the Vercel Flags Explorer integration.
 * It exposes flag metadata for the Vercel toolbar to discover and override flags.
 *
 * @see https://vercel.com/docs/workflow-collaboration/feature-flags/flags-explorer
 */

import * as flags from "@config/flags/flags";
import * as vdpFlags from "@features/vdp/flags/vdp-flags";
import { createFlagsDiscoveryEndpoint, getProviderData } from "flags/next";

export const GET = createFlagsDiscoveryEndpoint(() => {
  const { getUserInfo, ...filteredFlags } = { ...flags, ...vdpFlags };
  return getProviderData(filteredFlags);
});
