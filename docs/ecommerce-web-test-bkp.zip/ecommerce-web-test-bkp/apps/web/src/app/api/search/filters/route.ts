/**
 * Filters API Route
 *
 * POST /api/search/filters — Returns facet/filter data independently from vehicle search.
 *
 * This endpoint is called in parallel with /api/search so that filter counts
 * load asynchronously without blocking vehicle results rendering.
 */

import { defaultFilterState } from "@features/search/components/filter-sidebar/types";
import {
  type MockFilterSearchRequest,
  runMockFilterSearch,
} from "@features/search/lib/mock-faceted-search";
import { type NextRequest, NextResponse } from "next/server";

const isDev = process.env.NODE_ENV === "development";
function noop() {
  /* no-op */
}
const log = isDev ? console.log.bind(console, "[FiltersAPI]") : noop;
const logError = console.error.bind(console, "[FiltersAPI]");

export async function POST(request: NextRequest) {
  try {
    let body: Partial<MockFilterSearchRequest> = {};
    try {
      body = (await request.json()) as Partial<MockFilterSearchRequest>;
    } catch {
      body = {};
    }

    const filterRequest: MockFilterSearchRequest = {
      filterState: body.filterState ?? defaultFilterState,
      searchQuery: body.searchQuery ?? "",
      labelFilter: body.labelFilter ?? "",
      refineFilters: body.refineFilters,
      updatedSections: body.updatedSections,
      searchId: body.searchId,
      filterId: body.filterId,
    };

    log("Filter request:", {
      searchId: filterRequest.searchId,
      sections: filterRequest.updatedSections,
    });

    // Simulate independent latency for the filters endpoint
    const latencyMs = 150;
    await new Promise((resolve) => setTimeout(resolve, latencyMs));

    const result = runMockFilterSearch(filterRequest);

    return NextResponse.json(result);
  } catch (error) {
    logError("POST error:", error);
    return NextResponse.json(
      { error: "Internal server error", code: "INTERNAL_ERROR" },
      { status: 500 }
    );
  }
}
