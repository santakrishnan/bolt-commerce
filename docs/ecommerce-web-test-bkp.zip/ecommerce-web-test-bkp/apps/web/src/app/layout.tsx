import type { Metadata } from "next";
import { cookies } from "next/headers";
import { Suspense } from "react";
import "./globals.css";
import { toyotaType } from "@config/fonts";
import { MANUAL_ZIP_COOKIE, ZIP_RE } from "@config/routes/constants";
import { FavoritesProvider } from "@features/favorites";
import { SearchHistoryProvider } from "@features/search";
import { ArrowProvider } from "@features/tracking";
import { Footer } from "@layout/footer";
import { Header } from "@layout/header";
import { FeatureFlagDebug } from "@shared/components/feature-flag-debug";
import { composeProviders } from "@shared/providers/compose-providers";
import { LocationProvider } from "@shared/providers/location-provider";
import { QueryProvider } from "@shared/providers/query-provider";
import { ThemeProvider } from "@tfs-ucmp/shared/providers";

export const metadata: Metadata = {
  title: "Arrow - Modern E-commerce",
  description: "Arrow - Modern E-commerce",
};

/**
 * Providers are applied outermost-first.
 * Order: ThemeProvider → ArrowProvider → QueryProvider →
 *        SearchHistoryProvider → FavoritesProvider
 *
 * All providers above are synchronous client components — they render
 * immediately and belong OUTSIDE the Suspense boundary so PPR can
 * include their server-rendered HTML in the static shell.
 *
 * LocationProvider is the only async dependency (via LocationInit which
 * reads cookies()) — it lives INSIDE Suspense as a dynamic hole.
 *
 * CartProvider removed — zero consumers on any rendered route.
 */
const SyncProviders = composeProviders(
  ThemeProvider,
  ArrowProvider,
  QueryProvider,
  SearchHistoryProvider,
  FavoritesProvider
);

/**
 * Async Server Component that reads the manual-zip cookie and passes it
 * to the client LocationProvider. Rendered inside <Suspense> so the
 * cookies() call doesn't block the entire layout.
 */
async function LocationInit({ children }: { children: React.ReactNode }) {
  const cookieStore = await cookies();
  const savedZip = cookieStore.get(MANUAL_ZIP_COOKIE)?.value;
  const initialZip = savedZip && ZIP_RE.test(savedZip) ? savedZip : null;

  return <LocationProvider initialZip={initialZip}>{children}</LocationProvider>;
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html className={toyotaType.variable} lang="en" suppressHydrationWarning>
      <body>
        <SyncProviders>
          <Suspense fallback={null}>
            <LocationInit>
              <Header />
              {children}
            </LocationInit>
          </Suspense>
        </SyncProviders>
        {/* Footer is a Server Component with no provider dependencies — keep it outside */}
        <Footer />
        {/* Feature Flag Debug Panel - excluded from production bundle entirely */}
        {process.env.NODE_ENV !== "production" && (
          <Suspense fallback={null}>
            <FeatureFlagDebug />
          </Suspense>
        )}
      </body>
    </html>
  );
}
